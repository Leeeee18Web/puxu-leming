param([ValidateSet('firmware','syn','full')][string]$Stage='full')
$ErrorActionPreference='Stop'
$taskPython=if($env:PUXU_PYTHON){$env:PUXU_PYTHON}else{'python'}
& $taskPython -X utf8 -B (Join-Path $PSScriptRoot 'tools/build_source.py') --stage $Stage
exit $LASTEXITCODE
