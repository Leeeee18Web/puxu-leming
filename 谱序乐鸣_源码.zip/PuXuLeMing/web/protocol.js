(function (root) {
  'use strict';
  const IDENTITY = 0x50385731, FS = 50000000 / 1024, MAX_VOICES = 7;
  const errors = ['成功', '参数无效', '设备忙', '当前模式不能播放', '会话或顺序过期', '曲谱不完整或CRC不匹配'];
  function crc16(bytes, crc=0xffff) { for (const b of bytes) { crc ^= b<<8; for(let i=0;i<8;i++) crc=((crc<<1)^((crc&0x8000)?0x1021:0))&65535; } return crc; }
  function encode({op,seq,session,a=0,b=0,c=0}) {
    const f=new Uint8Array(22),v=new DataView(f.buffer); f.set([80,87,1,op]);v.setUint16(4,seq,true);v.setUint16(6,session,true);
    [a,b,c].forEach((x,i)=>v.setUint32(8+4*i,x,true));v.setUint16(20,crc16(f.subarray(2,20)),true);return f;
  }
  function decode(bytes) {
    const f=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes);if(f.length!==22)throw Error('帧长度错误');
    const v=new DataView(f.buffer,f.byteOffset,f.byteLength);if(f[0]!==80||f[1]!==87||f[2]!==1)throw Error('协议标识错误');
    if(v.getUint16(20,true)!==crc16(f.subarray(2,20)))throw Error('CRC错误');
    return {op:f[3],seq:v.getUint16(4,true),session:v.getUint16(6,true),a:v.getUint32(8,true),b:v.getUint32(12,true),c:v.getUint32(16,true)};
  }
  function entryBytes(e) {const a=new Uint8Array(8),v=new DataView(a.buffer);v.setUint32(0,e.tick,true);v.setUint32(4,e.word,true);return a;}
  function scoreCRC(events) {let crc=65535;for(const e of events)crc=crc16(entryBytes(e),crc);return crc;}
  function validateScore(input) {
    if(!input||input.version!==1||!Array.isArray(input.events)||input.events.length<1||input.events.length>512)throw Error('需要version=1与1至512条events');
    const active=new Set();let last=-1;
    const events=input.events.map((e,i)=>{
      if(!e||typeof e!=='object'||!Number.isFinite(e.ms)||e.ms<0||e.ms<last)throw Error(`第${i+1}条时间无效或未按时间排序`);
      const tick=Math.round(e.ms*FS/1000);if(tick>0x7fffffff)throw Error('时间超出计数范围');last=e.ms;
      if(!Number.isInteger(e.note)||e.note<0||e.note>127)throw Error(`第${i+1}条音高必须为0至127`);
      if(typeof e.on!=='boolean')throw Error('on必须为true或false');
      const velocity=e.on?e.velocity:(e.velocity??0);
      if(!Number.isInteger(velocity)||velocity<0||velocity>127||(e.on&&velocity===0))throw Error('力度必须为1至127（松键允许0）');
      if(e.on){if(active.has(e.note))throw Error('同一音高重复按下');active.add(e.note);if(active.size>MAX_VOICES)throw Error('最多同时演奏7音');}
      else{if(!active.delete(e.note))throw Error('松开了未按下的音符');}
      return {ms:e.ms,note:e.note,on:e.on,velocity,tick,word:e.note|(velocity<<8)|(e.on?65536:0)};
    });
    if(active.size)throw Error('曲谱结尾存在未释放音符，请补充note-off');
    return {version:1,title:String(input.title||'未命名曲谱').slice(0,80),events,duration:events.at(-1).ms};
  }
  class CommandQueue {
    constructor({session,send,onStatus=()=>{},onFailure=()=>{},timeout=180,retries=2}) {
      if(!session)throw Error('会话不能为空');Object.assign(this,{session,send,onStatus,onFailure,timeout,retries});this.seq=0;this.waiting=[];this.current=null;this.closed=false;
    }
    command(op,a=0,b=0,c=0,priority=false) {
      if(this.closed)return Promise.reject(Error('连接已关闭'));
      if(this.waiting.length>=16){if(!priority)return Promise.reject(Error('命令队列已满，请等待FPGA确认'));this.waiting.pop().reject(Error('已被紧急松键或停止取代'));}
      return new Promise((resolve,reject)=>{const task={op,a,b,c,resolve,reject};priority?this.waiting.unshift(task):this.waiting.push(task);this.pump();});
    }
    live(mask,velocity,base) {
      const old=this.waiting.filter(t=>t.op===1);this.waiting=this.waiting.filter(t=>t.op!==1);old.forEach(t=>t.resolve({coalesced:true}));
      return this.command(1,mask,velocity|(base<<8));
    }
    release() {
      const old=this.waiting.filter(t=>t.op===1||t.op===3);this.waiting=this.waiting.filter(t=>t.op!==1&&t.op!==3);old.forEach(t=>t.resolve({coalesced:true}));
      return this.command(2,0,0,0,true);
    }
    pump() {
      if(this.current||this.closed||!this.waiting.length)return;
      const t=this.current=this.waiting.shift();t.seq=this.seq;this.seq=(this.seq+1)&65535;t.frame=encode({...t,session:this.session});t.attempt=0;this.transmit();
    }
    transmit() {
      const t=this.current;if(!t)return;
      try{this.send(t.frame);}catch(e){this.fail(e);return;}
      this.timer=setTimeout(()=>{if(t!==this.current)return;if(t.attempt++<this.retries)this.transmit();else this.fail(Error('FPGA确认超时，已释放网页按键'));},this.timeout);
    }
    receive(frame) {
      let r;try{r=decode(frame);}catch(_){return false;}
      const t=this.current;if(!t||r.session!==this.session||r.seq!==t.seq||r.op!==(t.op|128)||r.c!==IDENTITY)return false;
      clearTimeout(this.timer);this.current=null;
      const status={result:r.a&255,mode:(r.a>>8)&3,muted:!!(r.a&1024),playing:!!(r.a&2048),committed:!!(r.a&4096),count:r.b&65535,position:r.b>>>16};
      if(t.op===0){status.capabilities=r.b>>>16;status.position=0;}
      if(t.op===12){status.verifiedCRC=r.b>>>16;status.position=0;}
      if([13,14,16].includes(t.op))Object.assign(status,{kind:'record',recordCount:(r.a>>>8)&8191,recording:!!(r.a&0x200000),recordReplaying:!!(r.a&0x400000),recordReady:!!(r.a&0x800000),recordFull:!!(r.a&0x1000000),recordTimeLimit:!!(r.a&0x2000000),...(t.op===16?{takeId:r.b}:{recordDuration:r.b})});
      if(t.op===15)Object.assign(status,{kind:'recordChunk',recordPart:(r.b>>>24)-0xe0,recordBytes:[(r.a>>>8)&255,(r.a>>>16)&255,r.a>>>24,r.b&255,(r.b>>>8)&255,(r.b>>>16)&255]});
      if(t.op>=20&&t.op<=24)Object.assign(status,{kind:'keymap',mapNote:(r.a>>>8)&127,mapBase:(r.a>>>16)&127,mapEnabled:!!(r.a&0x1000000),mapCRC:r.b&65535,keySeenIndex:(r.b>>>16)&31,keySeenValid:!!(r.b&0x200000)});
      this.onStatus(status);status.result?t.reject(Error(errors[status.result]||`设备错误${status.result}`)):t.resolve(status);this.pump();return true;
    }
    fail(error) {this.close(error);this.onFailure(error);}
    close(error=Error('连接已关闭')) {
      clearTimeout(this.timer);this.closed=true;const all=[this.current,...this.waiting].filter(Boolean);this.current=null;this.waiting=[];all.forEach(t=>t.reject(error));
    }
  }
  async function uploadScore(queue,score,{cancelled=()=>false,onProgress=()=>{}}={}) {
    const s=validateScore(score);await queue.command(4,s.events.length);
    for(let i=0;i<s.events.length;i++){if(cancelled())throw Error('已取消上传，原曲谱保留');const e=s.events[i];await queue.command(5,i,e.tick,e.word);onProgress(i+1,s.events.length);}
    if(cancelled())throw Error('已取消提交，原曲谱保留');await queue.command(6,scoreCRC(s.events));
    const proof=await queue.command(12);
    if(!proof||proof.count!==s.events.length||proof.verifiedCRC!==scoreCRC(s.events))throw Error('板内曲谱复核失败：事件数或RAM校验不一致，请重新下载。');
    return s;
  }
  function requireScoreDevice(status){if(status?.capabilities!==0x5305)throw Error('FPGA曲谱版本不匹配，请加载本工程Final7.fs，再重新连接。');}
  async function fetchRecording(queue,{onProgress=()=>{},cancelled=()=>false}={}) {
    const info=await queue.command(14),snap=await queue.command(16);
    if(!info.recordReady||!snap.recordReady||!Number.isInteger(info.recordCount)||info.recordCount<1||info.recordCount>4096||info.recordCount!==snap.recordCount)throw Error('请先停止板端录制和回放，再取回演奏。');
    const records=[];let checksum=65535;
    for(let i=0;i<info.recordCount;i++) {
      if(cancelled())throw Error('演奏取回已取消，板端录制仍保留。');
      const bytes=[];
      for(let part=0;part<2;part++) {
        const reply=await queue.command(15,i,part,snap.takeId);
        if(reply.recordPart!==part||reply.recordBytes?.length!==6)throw Error('录制分片不匹配，请重新取回。');
        bytes.push(...reply.recordBytes);
      }
      checksum=crc16(bytes,checksum);records.push(bytes.slice().reverse().map(b=>b.toString(16).padStart(2,'0')).join(''));onProgress(i+1,info.recordCount);
    }
    const end=await queue.command(16),endInfo=await queue.command(14);
    if(end.takeId!==snap.takeId||end.recordCount!==info.recordCount||!end.recordReady||endInfo.recordDuration!==info.recordDuration)throw Error('板端录制已变化，请重新取回，未保存混合数据。');
    return {format:'p8-performance',version:1,title:'我的演奏',sampleRate:FS,takeId:snap.takeId,durationSamples:info.recordDuration,records,crc16:checksum};
  }
  function recordControl(queue,action){if(![0,1,2].includes(action))throw Error('录制控制无效');return queue.command(13,action);}
  function setTimbre(queue,timbre){if(!Number.isInteger(timbre)||timbre<1||timbre>4)throw Error('音色编号必须为1至4');return queue.command(9,timbre);}
  function setPattern(queue,mode,start=false){if(!Number.isInteger(mode)||mode<0||mode>3)throw Error('演奏方式编号必须为0至3');return queue.command(10,mode,start?1:0);}
  function setController(queue,controller,value){if(![1,64,120,123].includes(controller)||!Number.isInteger(value)||value<0||value>127)throw Error('控制器参数无效');return queue.command(11,controller,value);}
  function validateMap(map){if(!map||!Array.isArray(map.notes)||map.notes.length!==25||!map.notes.every(n=>Number.isInteger(n)&&n>=0&&n<=127)||!Number.isInteger(map.base)||map.base<0||map.base>103||typeof map.enabled!=='boolean')throw Error('键位需要25个0至127音高及合法输入起点');return {notes:[...map.notes],base:map.base,enabled:map.enabled};}
  function mapCRC(map){const m=validateMap(map);return crc16([m.base,m.enabled?1:0,...m.notes]);}
  async function readKeymap(queue){let map=null;for(let i=0;i<25;i++){const s=await queue.command(23,i);if(!map)map={notes:[],base:s.mapBase,enabled:s.mapEnabled,crc:s.mapCRC};if(s.mapBase!==map.base||s.mapEnabled!==map.enabled||s.mapCRC!==map.crc)throw Error('设备键位读取中已变化，请重新读取');map.notes.push(s.mapNote);}if(mapCRC(map)!==map.crc)throw Error('设备键位CRC不一致');return map;}
  async function applyKeymap(queue,map,{save=false}={}){const m=validateMap(map);await queue.release();await queue.command(20,m.base,m.enabled?1:0);for(let i=0;i<25;i++)await queue.command(21,i,m.notes[i]);const s=await queue.command(22,mapCRC(m),save?1:0);if(s.mapCRC!==mapCRC(m))throw Error('设备键位提交未确认');return m;}
  const api={validateMap,mapCRC,readKeymap,applyKeymap,IDENTITY,FS,MAX_VOICES,crc16,encode,decode,entryBytes,scoreCRC,validateScore,CommandQueue,uploadScore,requireScoreDevice,fetchRecording,recordControl,setTimbre,setPattern,setController};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.P8WiFi=api;
})(typeof window!=='undefined'?window:globalThis);
