(function(root){
  'use strict';
  class HttpTransport {
    constructor({base,session,onFrame,onFailure,onRetry=()=>{},fetchImpl=root.fetch.bind(root),timeout=2500}) {
      Object.assign(this,{base,session,onFrame,onFailure,onRetry,fetchImpl,timeout});
      this.closed=false;this.pending=null;this.aborter=null;
    }
    send(frame) {
      if(this.closed)throw Error('连接已关闭');
      // The PW queue retries the same frame. Never create overlapping HTTP
      // transactions for a retry while the original response is still pending.
      if(this.pending)return;
      const aborter=this.aborter=new AbortController();
      const timer=setTimeout(()=>aborter.abort(),this.timeout);
      this.pending=(async()=>{
        try {
          const response=await this.fetchImpl(this.base+'/api/command',{
            method:'POST',headers:{'Content-Type':'text/plain'},
            body:Array.from(frame,b=>b.toString(16).padStart(2,'0')).join(''),cache:'no-store',signal:aborter.signal
          });
          if(!response.ok){
            let message=`设备请求失败（${response.status}）`;
            try{message=(await response.json()).error||message;}catch(_){}
            const e=Error(message);e.fatal=response.status>=400&&response.status<500&&response.status!==408&&response.status!==429;throw e;
          }
          const data=await response.arrayBuffer();
          if(data.byteLength!==22)throw Error('设备确认数据不完整，请重新连接。');
          if(!this.closed){
            // receive() can immediately send the next queued command.
            this.pending=null;this.aborter=null;
            this.lastError=null;this.onFrame(data);
          }
        } catch(e) {
          if(!this.closed){this.lastError=e.name==='AbortError'?Error('HTTP响应暂时超时'):e;if(e.fatal)this.onFailure(this.lastError);else this.onRetry(this.lastError);}
        } finally {
          clearTimeout(timer);
          if(this.aborter===aborter){this.pending=null;this.aborter=null;}
        }
      })();
    }
    close() {
      if(this.closed)return;
      this.closed=true;
      if(this.aborter)this.aborter.abort();
      const data=[this.session&255,this.session>>8].map(b=>b.toString(16).padStart(2,'0')).join('');
      if(root.navigator?.sendBeacon){
        root.navigator.sendBeacon(this.base+'/api/release',new Blob([data],{type:'text/plain'}));
      }else{
        this.fetchImpl(this.base+'/api/release',{method:'POST',body:data,headers:{'Content-Type':'text/plain'},keepalive:true}).catch(()=>{});
      }
    }
  }
  if(typeof module!=='undefined'&&module.exports)module.exports=HttpTransport;
  else root.P8HttpTransport=HttpTransport;
})(typeof window!=='undefined'?window:globalThis);
