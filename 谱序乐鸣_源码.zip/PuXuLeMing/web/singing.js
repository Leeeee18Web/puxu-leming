(function installSinging(root){
 'use strict';
 function need(ok,message){if(!ok)throw Error(message);}
 const RATE=8000,HOP=80,SIZE=512,MAX_SECONDS=30;
 function toScore(notes,title='我的清唱'){
  need(notes.length>0,'未识别到稳定旋律，请靠近手机清唱或哼唱后重录');
  need(notes.length<=256,'识别结果超过256个音符（512事件），请分段录音；没有删减结果');
  const events=[];
  for(const n of notes){events.push({ms:Math.round(n.startMs),note:n.note,on:true,velocity:96},{ms:Math.round(n.endMs),note:n.note,on:false,velocity:0});}
  events.sort((a,b)=>a.ms-b.ms||Number(a.on)-Number(b.on));
  return {version:1,title:String(title).slice(0,80),events};
 }
 function resample(input,rate){
  const n=Math.floor(input.length*RATE/rate),x=new Float32Array(n);
  // Average each source interval before downsampling; no microphone/network API.
  for(let i=0;i<n;i++){const start=i*rate/RATE,end=(i+1)*rate/RATE;let sum=0,weight=0;
   for(let j=Math.floor(start);j<Math.ceil(end)&&j<input.length;j++){const w=Math.min(end,j+1)-Math.max(start,j);sum+=input[j]*w;weight+=w;}x[i]=sum/weight;
  }return x;
 }
 function estimate(frame,minLag,maxLag){
  let mean=0;for(const x of frame)mean+=x;mean/=frame.length;
  for(let i=0;i<frame.length;i++)frame[i]-=mean;
  const d=new Float64Array(maxLag+2);let cumulative=0;d[0]=1;
  for(let lag=1;lag<=maxLag+1;lag++){let sum=0;for(let j=0;j<SIZE-maxLag-1;j++){const v=frame[j]-frame[j+lag];sum+=v*v;}cumulative+=sum;d[lag]=cumulative>1e-14?sum*lag/cumulative:1;}
  let lag=-1;
  for(let k=minLag;k<=maxLag;k++)if(d[k]<.16){while(k<maxLag&&d[k+1]<d[k])k++;lag=k;break;}
  if(lag<0)return null;
  // Reject a false octave when a much stronger fit exists at twice the period.
  const twice=lag*2;let best=twice;
  if(d[lag]>.03&&twice+1<=maxLag){for(let k=twice-1;k<=twice+1;k++)if(d[k]<d[best])best=k;if(d[best]<d[lag]*.20)lag=best;}
  const confidence=1-d[lag];if(confidence<.80)return null;
  const den=d[lag-1]-2*d[lag]+d[lag+1];let refined=lag;
  if(Math.abs(den)>1e-9)refined+=Math.max(-.5,Math.min(.5,.5*(d[lag-1]-d[lag+1])/den));
  const pitch=69+12*Math.log2((RATE/refined)/440);
  return {pitch,confidence};
 }
 function transcribe(input,sampleRate,{title='我的清唱',onProgress=()=>{},cancelled=()=>false}={}){
  need(input instanceof Float32Array&&input.length>0&&Number.isInteger(sampleRate)&&sampleRate>=8000&&sampleRate<=192000,'音频采样数据无效');
  need(input.length/sampleRate<=MAX_SECONDS+.001,'每段清唱最长30秒，请分段录音');
  let peak=0;for(const s of input){need(Number.isFinite(s),'音频包含无效采样');peak=Math.max(peak,Math.abs(s));}
  const x=resample(input,sampleRate),count=Math.ceil(x.length/HOP),frames=[];let peakEnergy=0;
  for(let i=0;i<count;i++){let e=0,n=0;for(let j=i*HOP;j<Math.min(x.length,(i+1)*HOP);j++){e+=x[j]*x[j];n++;}e=Math.sqrt(e/Math.max(1,n));frames.push({energy:e,note:-1,confidence:0});peakEnergy=Math.max(peakEnergy,e);}
  const gate=Math.max(.006,peakEnergy*.10),minLag=7,maxLag=130;
  for(let i=0;i<count;i++){
   if(cancelled())throw Error('识别已取消');
   if(frames[i].energy>=gate){const frame=new Float32Array(SIZE),start=i*HOP-SIZE/2;for(let j=0;j<SIZE;j++)frame[j]=x[start+j]||0;
    const f=estimate(frame,minLag,maxLag);if(f&&f.pitch>=35.5&&f.pitch<=84.5){frames[i].note=Math.round(f.pitch);frames[i].confidence=f.confidence;}
   }
   if(i%16===0)onProgress(i/count);
  }
  const original=frames.map(f=>f.note);
  for(let i=1;i<count-1;i++)if(original[i]>=0&&original[i-1]===original[i+1]&&original[i-1]>=0)frames[i].note=original[i-1];
  const notes=[];let start=-1,note=-1,totalConfidence=0;
  for(let i=0;i<=count;i++){
   const next=i<count?frames[i].note:-1;
   if(next!==note){if(start>=0&&(i-start)*10>=70)notes.push({note,startMs:start*10,endMs:Math.min(input.length/sampleRate*1000,i*10),confidence:totalConfidence/(i-start)});start=next>=0?i:-1;note=next;totalConfidence=0;}
   if(next>=0)totalConfidence+=frames[i].confidence;
  }
  const score=toScore(notes,title),warnings=[];if(peak>.98)warnings.push('录音可能过响，下次请离手机稍远一些');
  onProgress(1);return {score,notes,duration:input.length/sampleRate,warnings};
 }
 function workerSource(){return '('+installSinging.toString()+')(self);onmessage=function(e){try{const r=P8Singing.transcribe(new Float32Array(e.data.buffer),e.data.rate,{title:e.data.title,onProgress:p=>postMessage({progress:p})});postMessage({result:r});}catch(e){postMessage({error:e.message});}};';}
 const api={transcribe,toScore,MAX_SECONDS,workerSource};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.P8Singing=api;
})(typeof self!=='undefined'?self:globalThis);
