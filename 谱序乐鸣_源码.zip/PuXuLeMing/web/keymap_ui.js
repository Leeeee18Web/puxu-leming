(function(root){
 'use strict';
 const P=root.P8WiFi,NAMES=['C','C♯','D','D♯','E','F','F♯','G','G♯','A','A♯','B'];
 const defaults=()=>({base:60,enabled:true,notes:Array.from({length:25},(_,i)=>60+i)});
 const clone=m=>P.validateMap(m);
 class Draft {
  constructor(map=defaults()){this.applied=clone(map);this.draft=clone(map);this.selected=new Set([0]);this.dirty=false;}
  select(i,group=false){if(!Number.isInteger(i)||i<0||i>24)throw Error('键号无效');if(!group)this.selected.clear();if(group&&this.selected.has(i)&&this.selected.size>1)this.selected.delete(i);else this.selected.add(i);}
  set(note){if(!Number.isInteger(note)||note<0||note>127)throw Error('音高必须为0至127');for(const i of this.selected)this.draft.notes[i]=note;this.dirty=true;}
  transpose(delta,all=false){const indices=all?Array.from({length:25},(_,i)=>i):[...this.selected];if(indices.some(i=>this.draft.notes[i]+delta<0||this.draft.notes[i]+delta>127))throw Error('移调超出MIDI 0至127，草稿保持不变');for(const i of indices)this.draft.notes[i]+=delta;this.dirty=true;}
  reset(){this.draft=defaults();this.dirty=true;}
  load(map){this.draft=clone(map);this.dirty=true;}
  received(map){this.applied=clone(map);this.draft=clone(map);this.dirty=false;}
  async apply(queue,save=false){const snapshot=clone(this.draft);await P.applyKeymap(queue,snapshot,{save});this.applied=snapshot;this.dirty=JSON.stringify(clone(this.draft))!==JSON.stringify(snapshot);return snapshot;}
 }
 const noteName=n=>NAMES[n%12]+(Math.floor(n/12)-1);
 function mount(){
  const $=id=>document.getElementById(id),host=$('keymap-editor');if(!host)return;
  const model=new Draft();let busy=false,learnTimer=null,audioContext=null;
  const storageKey='p8-poly25-presets-v1';let presets={};try{presets=JSON.parse(localStorage.getItem(storageKey)||'{}');}catch(_){}
  function message(text,error=false){$('map-state').textContent=text;$('map-state').classList.toggle('error',error);}
  function render(){
   $('map-grid').replaceChildren();for(let i=0;i<25;i++){const b=document.createElement('button');b.type='button';b.dataset.mapIndex=i;b.className=model.selected.has(i)?'selected':'';b.setAttribute('aria-pressed',String(model.selected.has(i)));b.textContent=`${i+1} · ${noteName(model.draft.notes[i])}`;b.addEventListener('click',e=>{model.select(i,$('map-group').checked||e.shiftKey);render();});$('map-grid').append(b);}
   const i=[...model.selected][0],n=model.draft.notes[i];$('map-selected').textContent=`原始键 ${[...model.selected].map(x=>x+1).join('、')}`;$('map-note').value=String(n%12);$('map-octave').value=String(Math.floor(n/12)-1);$('map-input-base').value=model.draft.base;$('map-enabled').checked=model.draft.enabled;
   $('map-apply').disabled=busy||!root.P8Session?.connected;$('map-save').disabled=busy||!root.P8Session?.connected;$('map-learn').disabled=busy||!root.P8Session?.connected;
   if(!busy)message(model.dirty?'草稿待应用；当前发声键位保持已应用方案':'设备当前方案已读取');
  }
  function action(fn){try{fn();render();}catch(e){message(e.message,true);}}
  function options(){const select=$('map-presets');select.replaceChildren();for(const name of ['连续 C4–C6',...Object.keys(presets)]){const o=document.createElement('option');o.textContent=name;o.value=name;select.append(o);}}
  async function receive(){stopLearn();const q=root.P8Session?.getQueue();if(!q){render();message('等待连接；草稿可离线编辑');return;}busy=true;render();message('正在读取设备实际25键方案…');try{const map=await P.readKeymap(q);if(root.P8Session.getQueue()!==q)return;model.received(map);root.P8Session.mappingChanged?.(map);}catch(e){message(e.message,true);throw e;}finally{busy=false;render();}}
  async function apply(save){const session=root.P8Session,q=session?.getQueue();if(!q||busy||session.transferBusy)return;busy=true;render();message('正在提交完整25键并核对CRC…');try{await session.release();const map=await model.apply(q,save);session.mappingChanged?.(map);if(save){const name=$('map-name').value.trim().slice(0,40)||'我的方案';presets[name]=clone(map);localStorage.setItem(storageKey,JSON.stringify(presets));options();$('map-presets').value=name;}render();message(save?'FPGA已确认应用；方案已保存到ESP32和本机':'FPGA已确认整表应用');}catch(e){message(e.message,true);}finally{busy=false;$('map-apply').disabled=!session.connected;$('map-save').disabled=!session.connected;$('map-learn').disabled=!session.connected;}}
  async function transposeApplied(delta){
   const session=root.P8Session,q=session?.getQueue();
   if(!q||busy||session.transferBusy)throw Error('请先连接并等待当前传输完成');
   const next=clone(model.applied);next.notes=next.notes.map(n=>n+delta);P.validateMap(next);
   const previousApplied=clone(model.applied),previousDraft=clone(model.draft),wasDirty=model.dirty;
   busy=true;render();message('正在整表应用演奏音区…');
   try{
    await session.release();await P.applyKeymap(q,next);
    if(session.getQueue()!==q)throw Error('连接已变化，请重新读取设备方案');
    model.applied=clone(next);
    // A range choice acts on the audible map, never silently applies a draft.
    if(!wasDirty&&JSON.stringify(clone(model.draft))===JSON.stringify(previousDraft))model.draft=clone(next);
    model.dirty=JSON.stringify(clone(model.draft))!==JSON.stringify(next);
    session.mappingChanged?.(next);return next;
   }catch(e){model.applied=previousApplied;throw e;}
   finally{busy=false;render();}
  }
  function stopLearn(){clearInterval(learnTimer);learnTimer=null;}
  async function learn(){const q=root.P8Session?.getQueue();if(!q||busy)return;stopLearn();await q.command(24,1);message('请按实体25键之一，选择其原始键号…');learnTimer=setInterval(async()=>{if(q!==root.P8Session.getQueue()){stopLearn();return;}if(q.current||q.waiting.length)return;try{const s=await q.command(24);if(s.keySeenValid){stopLearn();model.select(s.keySeenIndex);render();message(`已选中实体键 ${s.keySeenIndex+1}；修改仍为草稿`);}}catch(e){stopLearn();message(e.message,true);}},350);}
  $('map-note').replaceChildren();NAMES.forEach((name,i)=>{const o=document.createElement('option');o.value=i;o.textContent=name;$('map-note').append(o);});
  for(let octave=-1;octave<=9;octave++){const o=document.createElement('option');o.value=octave;o.textContent=octave;$('map-octave').append(o);}
  for(const id of ['map-note','map-octave'])$(id).addEventListener('change',()=>action(()=>model.set((Number($('map-octave').value)+1)*12+Number($('map-note').value))));
  document.querySelectorAll('[data-map-step]').forEach(b=>b.addEventListener('click',()=>action(()=>model.transpose(Number(b.dataset.mapStep),$('map-all').checked))));
  $('map-reset').addEventListener('click',()=>action(()=>model.reset()));$('map-apply').addEventListener('click',()=>apply(false));$('map-save').addEventListener('click',()=>apply(true));$('map-learn').addEventListener('click',()=>learn().catch(e=>message(e.message,true)));
  $('map-load').addEventListener('click',()=>action(()=>model.load($('map-presets').value==='连续 C4–C6'?defaults():presets[$('map-presets').value])));
  $('map-input-base').addEventListener('change',()=>action(()=>{const n=Number($('map-input-base').value);if(!Number.isInteger(n)||n<0||n>103)throw Error('实体输入起点为0至103');model.draft.base=n;model.dirty=true;}));
  $('map-enabled').addEventListener('change',()=>action(()=>{model.draft.enabled=$('map-enabled').checked;model.dirty=true;}));
  $('map-audition').addEventListener('click',()=>{try{audioContext??=new(root.AudioContext||root.webkitAudioContext)();audioContext.resume();const n=model.draft.notes[[...model.selected][0]],o=audioContext.createOscillator(),g=audioContext.createGain(),now=audioContext.currentTime;o.frequency.value=440*2**((n-69)/12);g.gain.setValueAtTime(0,now);g.gain.linearRampToValueAtTime(.12,now+.015);g.gain.exponentialRampToValueAtTime(.001,now+.35);o.connect(g).connect(audioContext.destination);o.start();o.stop(now+.36);message(`手机试听 ${noteName(n)}；未改变设备方案`);}catch(e){message(e.message,true);}});
  options();render();root.P8KeymapUI={model,receive,transposeApplied,connectionChanged:()=>{stopLearn();render();},get busy(){return busy;}};
 }
 const api={Draft,defaults,noteName,mount};if(typeof module!=='undefined'&&module.exports)module.exports=api;else{root.P8Keymap=api;mount();}
})(typeof window!=='undefined'?window:globalThis);
