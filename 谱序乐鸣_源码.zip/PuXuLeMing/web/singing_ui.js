(function(){
 'use strict';
 const $=id=>document.getElementById(id),S=window.P8Singing,P=window.P8WiFi,A=window.P8Performance,B=window.P8Session;
 let result=null,source=null,pcm=null,rate=0,busy=false,rendering=false,uploading=false,gen=0,worker=null,originalURL=null,previewURL=null,wav=null,recorder=null,stream=null,recordTimer=null;
 const noteNames=['C','C♯','D','D♯','E','F','F♯','G','G♯','A','A♯','B'];
 function state(text){$('sing-state').textContent=text;}
 function update(){const block=busy||rendering||uploading||!!recorder;
  $('sing-record').disabled=block;$('sing-file').disabled=block;$('sing-mic').disabled=block;
  $('sing-cancel').disabled=!busy&&!rendering&&!recorder;$('sing-analyze').disabled=!source||block;
  $('sing-preview-button').disabled=!result||block;$('sing-json').disabled=!result||block;
  $('sing-upload').disabled=!result||!wav||block;$('sing-wav').disabled=!wav||block;$('sing-octave').disabled=!result||block;
 }
 function stopStream(){if(stream){stream.getTracks().forEach(t=>t.stop());stream=null;}clearTimeout(recordTimer);recordTimer=null;}
 function cancelWork(){gen++;if(worker){worker.terminate();worker=null;}if(recorder){const old=recorder;recorder=null;if(old.state!=='inactive')old.stop();}stopStream();busy=false;rendering=false;$('sing-stop').hidden=true;state('已取消');$('sing-progress').hidden=true;update();}
 function clearPreview(){wav=null;$('sing-preview').pause();$('sing-preview').removeAttribute('src');if(previewURL){URL.revokeObjectURL(previewURL);previewURL=null;}}
 function clearResult(){result=null;clearPreview();$('sing-notes').replaceChildren();$('sing-summary').textContent='录音就绪后会在手机本地识别。';update();}
 function fail(e){state('未完成');$('sing-info').textContent=e.message||String(e);}
 function db(){return new Promise((resolve,reject)=>{if(!window.indexedDB)return reject(Error('无法缓存'));const q=indexedDB.open('p8-singing-v3',1);q.onupgradeneeded=()=>q.result.createObjectStore('takes');q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error);});}
 async function persist(token=gen){try{const d=await db();if(token!==gen){d.close();return;}const t=d.transaction('takes','readwrite');t.objectStore('takes').put({source,result,saved:Date.now()},'last');t.oncomplete=()=>d.close();t.onerror=()=>d.close();}catch(_){$('sing-info').textContent+=' · 当前浏览器无法缓存，请及时保存JSON';}}
 function attachOriginal(){if(originalURL)URL.revokeObjectURL(originalURL);originalURL=source?URL.createObjectURL(source):null;if(originalURL)$('sing-original').src=originalURL;}
 async function restore(){const token=gen;try{const d=await db(),q=d.transaction('takes').objectStore('takes').get('last');q.onsuccess=()=>{d.close();if(token!==gen||!q.result?.source)return;try{const saved=q.result;source=saved.source;attachOriginal();if(saved.result){P.validateScore(saved.result.score);result=saved.result;showNotes();state('已恢复上次清唱');$('sing-info').textContent='上次录音和识别结果已恢复，可重新试听或保存曲谱。';}else state('已恢复录音');update();}catch(_){source=null;result=null;state('等待清唱');$('sing-info').textContent='上次缓存无效，请重新录音或导入。';update();}};q.onerror=()=>d.close();}catch(_) {}}
 function adjusted(){if(!result)return null;const shift=Number($('sing-octave').value),score={...result.score,events:result.score.events.map(e=>({...e,note:e.note+shift}))};return P.validateScore(score)&&score;}
 function showNotes(){const shift=Number($('sing-octave').value);$('sing-notes').replaceChildren();for(const n of result.notes){const note=n.note+shift,li=document.createElement('li');li.textContent=`${noteNames[note%12]}${Math.floor(note/12)-1} · ${(n.startMs/1000).toFixed(2)}～${(n.endMs/1000).toFixed(2)}秒`;$('sing-notes').append(li);}$('sing-summary').textContent=`${result.notes.length}个音符 · ${result.duration.toFixed(1)}秒 · 保留演唱节奏。请先试听，确认后再传到电子琴。`;}
 async function metadata(blob,token){return new Promise((resolve,reject)=>{const el=document.createElement('audio'),u=URL.createObjectURL(blob);let done=false;const timer=setTimeout(()=>finish(Error('无法读取录音时长，请导出WAV或M4A后重试')),15000);
  function finish(error){if(done)return;done=true;clearTimeout(timer);el.removeAttribute('src');el.load();URL.revokeObjectURL(u);error?reject(error):resolve();}
  el.onloadedmetadata=()=>{if(token!==gen)return finish(Error('识别已取消'));const duration=el.duration;if(!Number.isFinite(duration))return finish();if(duration>30.05)return finish(Error('每段清唱最长30秒，请在手机录音机裁剪后导入'));finish();};el.onerror=()=>finish(Error('浏览器无法读取此录音格式，请转为WAV或M4A后导入'));el.preload='metadata';el.src=u;
 });}
 async function decode(token){await metadata(source,token);if(token!==gen)throw Error('识别已取消');const Context=window.AudioContext||window.webkitAudioContext;if(!Context)throw Error('当前浏览器不支持音频解码，请使用新版安卓浏览器');const ctx=new Context();try{const bytes=await source.arrayBuffer(),audio=await ctx.decodeAudioData(bytes);if(token!==gen)throw Error('识别已取消');if(audio.duration>30.001||audio.numberOfChannels>2)throw Error('请导入30秒以内的单声道或双声道录音');const mono=new Float32Array(audio.length);for(let c=0;c<audio.numberOfChannels;c++){const channel=audio.getChannelData(c);for(let i=0;i<mono.length;i++)mono[i]+=channel[i]/audio.numberOfChannels;}pcm=mono;rate=audio.sampleRate;}finally{await ctx.close();}}
 async function analyze(){if(!source||busy||rendering||uploading)return;const token=++gen;busy=true;clearResult();state('正在读取录音');$('sing-progress').hidden=false;update();try{
  if(!pcm)await decode(token);if(token!==gen)return;
  state('正在识别');const u=URL.createObjectURL(new Blob([S.workerSource()],{type:'text/javascript'}));
  const take=await new Promise((resolve,reject)=>{worker=new Worker(u);URL.revokeObjectURL(u);worker.onmessage=e=>{if(token!==gen)return;if(e.data.progress!==undefined)$('sing-progress').value=Math.round(e.data.progress*100);else if(e.data.error)reject(Error(e.data.error));else if(e.data.result)resolve(e.data.result);};worker.onerror=()=>reject(Error('识别任务未能启动，请使用新版安卓浏览器或重新导入录音'));const transfer=pcm.slice();worker.postMessage({buffer:transfer.buffer,rate,title:'我的清唱'},[transfer.buffer]);});
  if(token!==gen)return;P.validateScore(take.score);result=take;showNotes();state('识别完成');$('sing-info').textContent=take.warnings.length?take.warnings.join('；'):'识别完成，请对照原声试听电子琴旋律。识别可能有误，不代表原曲标准乐谱。';await persist(token);
 }catch(e){if(token===gen){clearResult();fail(e);await persist(token);}}finally{if(token===gen){if(worker){worker.terminate();worker=null;}busy=false;$('sing-progress').hidden=true;update();}}}
 async function importAudio(file){if(!file||uploading)return;cancelWork();const token=gen;source=null;pcm=null;rate=0;clearResult();$('sing-octave').value='0';if(originalURL){$('sing-original').pause();$('sing-original').removeAttribute('src');URL.revokeObjectURL(originalURL);originalURL=null;}
  if(!file.size||file.size>12*1024*1024){fail(Error('录音文件须大于0且不超过12MB，请裁剪为30秒以内'));await persist(token);return;}
  source=file;attachOriginal();await persist(token);if(token!==gen)return;await analyze();
 }
 async function preview(){if(!result||rendering||busy)return;const token=gen,score=adjusted();rendering=true;clearPreview();state('正在生成试听');update();try{const audio=await A.renderWavAsync(score,{cancelled:()=>token!==gen,onProgress:p=>{$('sing-summary').textContent=`正在合成电子琴试听 ${Math.round(p*100)}%`;}});if(token!==gen)return;wav=audio;previewURL=URL.createObjectURL(new Blob([audio.wav],{type:'audio/wav'}));$('sing-preview').src=previewURL;showNotes();state('可试听和下载');try{await $('sing-preview').play();}catch(_) {}}catch(e){if(token===gen)fail(e);}finally{if(token===gen){rendering=false;update();}}}
 function save(blob,name){const u=URL.createObjectURL(blob),el=document.createElement('a');el.href=u;el.download=name;document.body.append(el);el.click();el.remove();setTimeout(()=>URL.revokeObjectURL(u),30000);}
 async function upload(){if(!result||!wav||uploading)return;uploading=true;state('正在下载到电子琴');update();try{await B.submitSingingScore(adjusted());state('板内复核通过');$('sing-info').textContent='曲谱已存入板内RAM，可以点击上方“播放”；原声和识别结果仍保存在手机。';}catch(e){fail(e);}finally{uploading=false;update();}}
 async function mic(){
  if(!window.isSecureContext)return fail(Error('当前热点页面请用“打开手机录音”入口'));
  if(busy||rendering||uploading||recorder)return;
  let token,localStream,localRecorder;
  try{
   B.prepareAudioCapture();token=++gen;busy=true;state('等待麦克风授权');update();
   localStream=await navigator.mediaDevices.getUserMedia({audio:true});
   if(token!==gen){localStream.getTracks().forEach(t=>t.stop());return;}
   stream=localStream;const chunks=[];let size=0;localRecorder=new MediaRecorder(localStream);recorder=localRecorder;
   localRecorder.ondataavailable=e=>{if(token===gen&&e.data.size){chunks.push(e.data);size+=e.data.size;if(size>12*1024*1024)cancelWork();}};
   localRecorder.onstop=()=>{
    localStream.getTracks().forEach(t=>t.stop());
    if(recorder===localRecorder){recorder=null;stream=null;clearTimeout(recordTimer);recordTimer=null;}
    if(token!==gen)return;
    busy=false;$('sing-stop').hidden=true;update();importAudio(new Blob(chunks,{type:localRecorder.mimeType||chunks[0]?.type||'audio/webm'}));
   };
   localRecorder.onerror=()=>{if(token!==gen)return;cancelWork();fail(Error('网页录音失败，请使用手机录音入口或导入已有录音'));};
   localRecorder.start(1000);recordTimer=setTimeout(()=>{if(token===gen&&localRecorder.state!=='inactive')localRecorder.stop();},29000);
   busy=false;$('sing-stop').hidden=false;state('网页录音中');$('sing-info').textContent='请清唱，完成后点击停止；约29秒自动停止。';update();
  }catch(e){if(localStream)localStream.getTracks().forEach(t=>t.stop());if(token===gen||token===undefined){stopStream();recorder=null;busy=false;fail(e);update();}}
 }
 $('sing-record').addEventListener('click',()=>{try{B.prepareAudioCapture();$('sing-capture').value='';$('sing-capture').click();}catch(e){fail(e);}});
 $('sing-capture').addEventListener('change',e=>{const file=e.target.files?.[0];if(file)importAudio(file);});$('sing-file').addEventListener('change',e=>{const file=e.target.files?.[0];if(file)importAudio(file);e.target.value='';});
 $('sing-analyze').addEventListener('click',analyze);$('sing-cancel').addEventListener('click',cancelWork);$('sing-preview-button').addEventListener('click',preview);$('sing-upload').addEventListener('click',upload);
 $('sing-json').addEventListener('click',()=>{if(result)save(new Blob([JSON.stringify(adjusted(),null,2)],{type:'application/json'}),'我的清唱.json');});$('sing-wav').addEventListener('click',()=>{if(wav)save(new Blob([wav.wav],{type:'audio/wav'}),'清唱_电子琴试听.wav');});
 $('sing-octave').addEventListener('change',()=>{clearPreview();showNotes();state('请重新生成试听');update();});
 $('sing-mic').hidden=!(window.isSecureContext&&navigator.mediaDevices?.getUserMedia&&window.MediaRecorder);$('sing-mic').addEventListener('click',mic);$('sing-stop').addEventListener('click',()=>recorder?.stop());
 window.P8SingingUI={get result(){return result;},importAudio,cancel:cancelWork};update();restore();
})();
