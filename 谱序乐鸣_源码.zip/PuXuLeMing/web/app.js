(function(){
 'use strict';
 const P=window.P8WiFi,$=id=>document.getElementById(id),names=['C','C♯','D','D♯','E','F','F♯','G','G♯','A','A♯','B'];
 let socket=null,queue=null,ready=false,heartbeat=null,device=null,base=60,rangeBase=60,activeMap=null,velocity=96,reconnectTimer=null,autoEnabled=true;
 let exportBusy=false,lastHeartbeatAt=0,pollRecord=false;
 let currentScore=null,uploadedScore=null,songPlaying=false,uploadBusy=false,instrument=1,patternMode=0,sustain=false,scoreGeneration=0;
 const pointers=new Map(),captured=new Set();
 const sampleScore={version:1,title:'小星星 · 示例片段',events:[
  {ms:0,note:60,on:true,velocity:96},{ms:380,note:60,on:false},
  {ms:450,note:60,on:true,velocity:96},{ms:830,note:60,on:false},
  {ms:900,note:67,on:true,velocity:96},{ms:1280,note:67,on:false},
  {ms:1350,note:67,on:true,velocity:96},{ms:1730,note:67,on:false},
  {ms:1800,note:69,on:true,velocity:96},{ms:2180,note:69,on:false},
  {ms:2250,note:69,on:true,velocity:96},{ms:2630,note:69,on:false},
  {ms:2700,note:67,on:true,velocity:96},{ms:3080,note:67,on:false}
 ]};
 $('endpoint').value=/^https?:$/.test(location.protocol)?location.origin:'http://192.168.4.1/';
 function notice(text,error=false){$('notice').textContent=text;$('notice').classList.toggle('error',error);}
 function catchError(e){if(ready)notice(e.message,true);}
 function setSongState(text,error=false){$('song-state').textContent=text;$('song-state').style.color=error?'#854b3e':'';}
 function scoreSummary(score){return `${score.title} · ${score.events.length} 个事件 · ${(score.duration/1000).toFixed(1)} 秒`;}
 function updateSongControls(){
  $('score-file').disabled=uploadBusy||exportBusy;$('sample-score').disabled=uploadBusy||exportBusy;
  $('upload').disabled=!ready||!currentScore||uploadBusy||exportBusy;
  $('start').disabled=!ready||!uploadedScore||uploadBusy||exportBusy;
  $('stop').disabled=!ready||uploadBusy||exportBusy||!songPlaying;
 }
 function updatePerformanceControls(){
  document.querySelectorAll('[data-timbre]').forEach(el=>el.classList.toggle('selected',Number(el.dataset.timbre)===instrument));
  document.querySelectorAll('[data-pattern]').forEach(el=>el.classList.toggle('selected',Number(el.dataset.pattern)===patternMode));
  $('pattern-start').disabled=!ready||uploadBusy||exportBusy||songPlaying||patternMode===0;
  $('sustain').classList.toggle('selected',sustain);$('sustain').setAttribute('aria-pressed',String(sustain));
  const blocked=!ready||uploadBusy||exportBusy||songPlaying;
  document.querySelectorAll('[data-timbre],[data-pattern],#sustain').forEach(el=>{el.disabled=blocked;});
 }
 function showScore(input,source='曲谱'){
  if(uploadBusy||exportBusy)throw Error('请等待当前传输完成后再切换曲谱');
  const normalized=window.P8Performance.normalize(input);scoreGeneration++;currentScore=null;uploadedScore=null;
  if(input.format!=='p8-performance'){try{currentScore=P.validateScore(input);}catch(_) {}}
  $('score-info').textContent=currentScore?scoreSummary(currentScore):`${normalized.title} · ${normalized.duration.toFixed(1)} 秒`;
  setSongState(currentScore?`${source}已载入`:'已载入，可在手机试听');updateSongControls();
  window.P8RecorderUI.setSource(input);
  notice(normalized.events.some(e=>e.timbre===4)?'演奏数据已载入，可完整保存JSON；自定义钢琴包络请在板端试听。':currentScore?'曲谱已载入，可下载到FPGA或在手机生成试听。':'演奏数据已载入，可试听、保存JSON和导出WAV。');
 }
 async function readScore(file){
  if(uploadBusy||exportBusy){notice('请等待当前传输完成后再切换曲谱',true);return;}
  const token=++scoreGeneration;
  try{const text=await file.text();if(token!==scoreGeneration)return;showScore(JSON.parse(text.replace(/^\uFEFF/,'')),file.name);}
  catch(e){if(token!==scoreGeneration||uploadBusy||exportBusy)return;currentScore=null;setSongState('曲谱无效',true);$('score-info').textContent='无法读取曲谱';updateSongControls();notice(e.message,true);}
 }
 function openScoreFile(file){if(file)readScore(file);}
 function setupScoreDropzone(){
  const zone=$('score-dropzone');
  zone.addEventListener('click',()=>$('score-file').click());
  zone.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();$('score-file').click();}});
  for(const event of ['dragenter','dragover'])zone.addEventListener(event,e=>{e.preventDefault();zone.classList.add('dragging');});
  for(const event of ['dragleave','drop'])zone.addEventListener(event,e=>{e.preventDefault();zone.classList.remove('dragging');});
  zone.addEventListener('drop',e=>openScoreFile(e.dataTransfer?.files?.[0]));
 }
 function mask(){let m=0;for(const i of pointers.values())m|=1<<i;return m;}
 function refreshKeys(){const m=mask();document.querySelectorAll('.key').forEach(el=>{const down=!!(m&(1<<Number(el.dataset.index)));el.classList.toggle('pressed',down);el.setAttribute('aria-pressed',String(down));});$('voices').textContent=`按住 ${new Set(pointers.values()).size} / ${P.MAX_VOICES} 音`;}
 function sendLive(){refreshKeys();if(ready&&queue&&!uploadBusy&&!exportBusy&&!songPlaying&&!window.P8KeymapUI?.busy)queue.live(mask(),velocity,base).catch(catchError);}
 function safetyRelease(){pointers.clear();captured.clear();refreshKeys();return ready&&queue?queue.release().catch(catchError):Promise.resolve();}
 function status(s){
  if(s.kind==='keymap')return;
  if(s.kind==='record'){window.P8RecorderUI?.recordStatus(s);return;}if(s.kind==='recordChunk')return;
  device=s;songPlaying=s.playing;
  $('live-status').textContent=s.muted?'乐器已静音':s.mode===2?'内置歌曲模式':s.result?'命令未执行':s.playing?'下载歌曲播放中':'FPGA 已确认';
  if(s.playing)setSongState('FPGA 正在播放');
  else if(s.committed&&!uploadedScore)setSongState(`设备已有 ${s.count} 个歌曲事件`);
  updateSongControls();
  updatePerformanceControls();
 }
 function disconnect(message='连接已断开，正在等待乐器恢复。',retry=true){
  clearTimeout(reconnectTimer);reconnectTimer=null;ready=false;clearInterval(heartbeat);heartbeat=null;
  pointers.clear();captured.clear();refreshKeys();songPlaying=false;uploadBusy=false;exportBusy=false;
  if(queue){queue.close();queue=null;}if(socket){const old=socket;socket=null;old.close();}
  $('connection').textContent='未连接';$('connection').classList.remove('online');$('connect').textContent='连接乐器';$('connect').disabled=false;$('live-status').textContent='等待 FPGA 确认';device=null;patternMode=0;sustain=false;updateSongControls();updatePerformanceControls();notice(message,true);window.P8RecorderUI?.connectionChanged();window.P8KeymapUI?.connectionChanged();
  if(retry&&autoEnabled&&!document.hidden)reconnectTimer=setTimeout(connect,1500);
 }
 async function connect(){
  if(socket)return;clearTimeout(reconnectTimer);reconnectTimer=null;autoEnabled=true;
  if(!/^https?:$/.test(location.protocol)){notice('当前为本地预览。请连 PuXu-Instrument，在手机打开 http://192.168.4.1/。');return;}
  let session=window.crypto?.getRandomValues?window.crypto.getRandomValues(new Uint16Array(1))[0]:0;if(!session)session=((Date.now()^Math.floor(Math.random()*65536))&65535)||1;
  const transport=new window.P8HttpTransport({base:location.origin,session,onFrame:data=>{if(socket===transport&&queue)queue.receive(data);},onFailure:e=>{if(socket===transport)disconnect(e.message);},onRetry:e=>{if(socket===transport)notice('链路暂时卡顿，正在重试同一条数据：'+e.message,true);}});
  socket=transport;$('connect').disabled=true;$('connect').textContent='连接中…';notice('正在等待 FPGA 确认连接…');
  queue=new P.CommandQueue({session,send:f=>transport.send(f),timeout:3000,retries:2,onStatus:status,onFailure:e=>{if(socket===transport)disconnect(e.message);}});
  try{
   const hello=await queue.command(0,P.IDENTITY);P.requireScoreDevice(hello);if(socket!==transport)return;ready=true;
   await window.P8KeymapUI?.receive();if(socket!==transport)return;
   if(!device?.committed)uploadedScore=null;else if(!uploadedScore)uploadedScore={title:'板内曲谱',events:Array(device.count)};
   $('connection').textContent='乐器在线';$('connection').classList.add('online');$('connect').textContent='断开连接';$('connect').disabled=false;updateSongControls();updatePerformanceControls();
   notice(device?.muted?'连接成功，请先在乐器屏幕取消静音。':device?.mode===2?'连接成功，请在乐器屏幕选择自由演奏。':'FPGA 已确认连接，可以开始演奏。');
   window.P8RecorderUI?.connectionChanged();
   heartbeat=setInterval(()=>{if(ready&&queue&&!queue.current&&!queue.waiting.length&&!uploadBusy&&!exportBusy&&!window.P8KeymapUI?.busy){const now=Date.now();if(!pointers.size&&now-lastHeartbeatAt<1000)return;lastHeartbeatAt=now;pollRecord=!pollRecord;queue.command(!pointers.size&&pollRecord?14:3).catch(catchError);}},200);
  }catch(e){if(socket===transport)disconnect(e.message);}
 }
 function playable(){if(!ready){notice('请先连接乐器。',true);return false;}if(uploadBusy||exportBusy||songPlaying||window.P8KeymapUI?.busy){notice('歌曲传输或播放中，请先停止歌曲。',true);return false;}if(device?.muted||device?.mode===2){notice('请在乐器屏幕选择自由演奏，并取消静音。',true);return false;}return true;}
 function assignPointer(id,index){
  const others=new Set([...pointers].filter(([key])=>key!==id).map(([,value])=>value));
  if(!others.has(index)&&others.size>=P.MAX_VOICES){notice('最多同时演奏7音，请先松开一个音。',true);return false;}
  if(pointers.get(id)===index)return true;pointers.set(id,index);sendLive();return true;
 }
 function performanceReady(){
  if(!ready){notice('请先连接乐器。',true);return false;}
  if(uploadBusy||exportBusy||songPlaying||window.P8KeymapUI?.busy){notice('歌曲传输或播放中，请先停止歌曲。',true);return false;}
  if(device?.muted||device?.mode===2){notice('请在乐器屏幕选择自由演奏，并取消静音。',true);return false;}
  return true;
 }
 async function selectInstrument(value){
  if(!performanceReady())return;
  try{await safetyRelease();await P.setTimbre(queue,value);instrument=value;updatePerformanceControls();notice(`已切换为${['钢琴','三角钢琴','拨弦音色','柔和萨克斯','自定义钢琴'][value]}。`);}catch(e){catchError(e);}
 }
 async function selectPattern(value){
  if(!performanceReady())return;
  try{await safetyRelease();await P.setPattern(queue,value);patternMode=value;updatePerformanceControls();notice(value===0?'已恢复自由演奏。':`已选择${['','拨弦','和弦','琶音'][value]}模式，请按键后点击开始。`);}catch(e){catchError(e);}
 }
 async function startPattern(){
  if(!performanceReady()||patternMode===0)return;
  try{await P.setPattern(queue,patternMode,true);notice('演奏方式已开始。');}catch(e){catchError(e);}
 }
 async function toggleSustain(){
  if(!performanceReady())return;
  const next=!sustain;
  try{await P.setController(queue,64,next?127:0);sustain=next;updatePerformanceControls();notice(next?'延音已开启。':'延音已关闭。');}catch(e){catchError(e);}
 }
 function createKeys(){
  $('keys').replaceChildren();
  if(activeMap?.enabled){const low=Math.min(...activeMap.notes),high=Math.max(...activeMap.notes);$('range-label').textContent=`${names[low%12]}${Math.floor(low/12)-1} — ${names[high%12]}${Math.floor(high/12)-1} · 自定义`;}
  else $('range-label').textContent=`C${Math.floor(base/12)-1} — C${Math.floor(base/12)+1}`;
  if(!Array.from($('base').options).some(o=>Number(o.value)===rangeBase)){const o=document.createElement('option');o.value=rangeBase;o.textContent=`C${Math.floor(rangeBase/12)-1} · 当前方案`;$('base').append(o);}
  $('base').value=String(rangeBase);
  for(const [start,end,whites] of [[0,12,7],[12,25,8]]){const row=document.createElement('div');row.className='keyboard-row';let white=0;
   for(let i=start;i<end;i++){const note=activeMap?.enabled?activeMap.notes[i]:base+i,physical=60+i,sharp=[1,3,6,8,10].includes(physical%12),el=document.createElement('button'),width=100/whites;
    el.type='button';el.className='key'+(sharp?' sharp':'');el.dataset.index=i;el.style.left=(sharp?(white-.32)*width:white*width)+'%';el.style.width=(sharp?width*.64:width)+'%';if(!sharp)white++;
    el.setAttribute('aria-label',`${names[note%12]}${Math.floor(note/12)-1}, MIDI ${note}`);el.setAttribute('aria-pressed','false');
    const label=document.createElement('span');label.className='note';label.textContent=names[note%12]+(Math.floor(note/12)-1);const midi=document.createElement('span');midi.className='midi';midi.textContent=note;el.append(label,midi);
    el.addEventListener('pointerdown',e=>{e.preventDefault();if(e.button>0||!playable()||!assignPointer(e.pointerId,i))return;captured.add(e.pointerId);el.setPointerCapture(e.pointerId);});
    el.addEventListener('pointermove',e=>{if(!captured.has(e.pointerId))return;const target=document.elementFromPoint(e.clientX,e.clientY)?.closest('.key');if(target&&$('keys').contains(target))assignPointer(e.pointerId,Number(target.dataset.index));else if(pointers.delete(e.pointerId))sendLive();});
    for(const event of ['pointerup','pointercancel','lostpointercapture'])el.addEventListener(event,e=>{captured.delete(e.pointerId);if(pointers.delete(e.pointerId))sendLive();});
    el.addEventListener('contextmenu',e=>e.preventDefault());el.addEventListener('keydown',e=>{if((e.key===' '||e.key==='Enter')&&!e.repeat){e.preventDefault();if(playable())assignPointer('key'+i,i);}});
    for(const event of ['keyup','blur'])el.addEventListener(event,e=>{if(event==='blur'||e.key===' '||e.key==='Enter'){e.preventDefault();if(pointers.delete('key'+i))sendLive();}});row.append(el);
   }$('keys').append(row);
  }
 }
 async function uploadSong(){
  if(!ready||!currentScore||uploadBusy||exportBusy||window.P8KeymapUI?.busy)return;
  const score=currentScore,targetQueue=queue;
  uploadBusy=true;updateSongControls();$('upload-progress').hidden=false;$('upload-progress').max=currentScore.events.length;$('upload-progress').value=0;setSongState('正在下载');$('upload-label').textContent=`正在发送 0 / ${currentScore.events.length} 个事件`;
  try{
   await safetyRelease();
   await P.uploadScore(targetQueue,score,{onProgress:(done,total)=>{$('upload-progress').value=done;$('upload-label').textContent=`正在发送 ${done} / ${total} 个事件`;}});
   uploadedScore=score;songPlaying=false;setSongState('板内复核通过');$('upload-label').textContent='FPGA 已从RAM重读并核对全部事件，现可脱离手机播放';notice(`「${score.title}」已下载到 FPGA，可以点击“播放”。`);
   return score;
  }catch(e){setSongState('下载失败',true);$('upload-label').textContent='尚未通过板内复核；请按错误提示处理后重新下载';notice(e.message,true);}
  finally{uploadBusy=false;$('upload-progress').hidden=true;updateSongControls();}
 }
 async function startSong(){
  if(!ready||!uploadedScore||uploadBusy||exportBusy||window.P8KeymapUI?.busy)return;
  if(patternMode!==0){notice('请先把演奏方式切换为自由，再播放下载歌曲。',true);return;}
  if(device?.muted||device?.mode===2){notice('请在 FPGA 屏幕切换到自由演奏模式，并取消静音。',true);return;}
  try{await safetyRelease();await queue.command(7);songPlaying=true;setSongState('播放中');updateSongControls();notice(`正在播放「${uploadedScore.title}」。`);}catch(e){notice(e.message,true);}
 }
 async function stopSong(){if(!ready||!songPlaying)return;try{await queue.command(8);songPlaying=false;setSongState('已停止');updateSongControls();notice('下载歌曲已停止。');}catch(e){notice(e.message,true);}}
 $('connect').addEventListener('click',()=>{if(socket){autoEnabled=false;safetyRelease();disconnect('已断开连接，网页按键已松开。',false);}else connect();});$('release').addEventListener('click',safetyRelease);
 $('base').addEventListener('change',async()=>{
  const selected=Number($('base').value),previous=rangeBase;
  if(activeMap?.enabled){
   $('base').disabled=true;
   try{if(!playable())return;await window.P8KeymapUI.transposeApplied(selected-previous);rangeBase=selected;createKeys();notice('音区已通过整表CRC确认应用。');}
   catch(e){notice(e.message,true);}
   finally{$('base').disabled=false;createKeys();}
  }else{await safetyRelease();base=selected;rangeBase=selected;createKeys();}
 });$('velocity').addEventListener('input',()=>{velocity=Number($('velocity').value);$('velocity-value').value=velocity;if(pointers.size)sendLive();});
 $('score-file').addEventListener('change',e=>openScoreFile(e.target.files?.[0]));setupScoreDropzone();$('sample-score').addEventListener('click',()=>{try{showScore(sampleScore,'示例曲谱');}catch(e){notice(e.message,true);}});$('upload').addEventListener('click',uploadSong);$('start').addEventListener('click',startSong);$('stop').addEventListener('click',stopSong);
 document.addEventListener('visibilitychange',()=>{if(document.hidden){if(!uploadBusy&&!exportBusy)safetyRelease();}else if(autoEnabled&&!socket)connect();});window.addEventListener('online',()=>{if(autoEnabled&&!socket&&!document.hidden)connect();});window.addEventListener('blur',()=>{if(!uploadBusy&&!exportBusy)safetyRelease();});window.addEventListener('pagehide',()=>{autoEnabled=false;disconnect('已离开琴房。',false);});
 document.querySelectorAll('[data-timbre]').forEach(el=>el.addEventListener('click',()=>selectInstrument(Number(el.dataset.timbre))));
 document.querySelectorAll('[data-pattern]').forEach(el=>el.addEventListener('click',()=>selectPattern(Number(el.dataset.pattern))));
 $('pattern-start').addEventListener('click',startPattern);$('sustain').addEventListener('click',toggleSustain);
 function prepareAudioCapture(){
  if(uploadBusy||exportBusy||songPlaying)throw Error('请先完成传输或停止板端播放，再开始清唱');
  autoEnabled=false;safetyRelease();disconnect('手机录音与识别期间无需保持控制连接，传曲谱时会重新确认。',false);
 }
 async function submitSingingScore(input){
  if(uploadBusy||exportBusy||songPlaying)throw Error('请先完成传输或停止板端播放');
  const validated=P.validateScore(input);
  const snapshot={version:1,title:validated.title,events:validated.events.map(({ms,note,on,velocity})=>({ms,note,on,velocity}))};
  autoEnabled=false;await safetyRelease();disconnect('正在重新确认乐器连接…',false);await connect();
  if(!ready)throw Error('请保持连接PuXu-Instrument并在设备网页上传，识别曲谱仍保存在手机');
  showScore(snapshot,'清唱曲谱');const intended=currentScore,uploaded=await uploadSong();
  if(uploaded!==intended||uploadedScore!==intended)throw Error('尚未完成板内复核，清唱结果保留，可重新下载');
  return true;
 }
 window.P8Session={getQueue:()=>ready?queue:null,get connected(){return ready;},get transferBusy(){return uploadBusy||exportBusy||!!window.P8KeymapUI?.busy;},mappingChanged:map=>{activeMap=map;base=map.base;rangeBase=map.enabled?Math.floor(map.notes[0]/12)*12:base;createKeys();},setExportBusy:v=>{exportBusy=v;updateSongControls();updatePerformanceControls();},release:safetyRelease,notice,prepareAudioCapture,submitSingingScore};
 createKeys();updateSongControls();updatePerformanceControls();if(/^https?:$/.test(location.protocol))connect();else notice('当前为本地预览。请连 PuXu-Instrument，在手机打开 http://192.168.4.1/。');
})();
