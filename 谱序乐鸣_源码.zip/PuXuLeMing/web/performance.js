(function(root){
 'use strict';
 const MAX_SECONDS=300, MAX_VOICES=7;
 function must(ok,message){if(!ok)throw Error(message);}
 function crc(bytes,c=65535){for(const b of bytes){c^=b<<8;for(let k=0;k<8;k++)c=((c<<1)^((c&32768)?0x1021:0))&65535;}return c;}
 function normalize(input){
  must(input&&typeof input==='object','请选择JSON曲谱或演奏记录');let events=[],duration=0;
  if(input.format==='p8-performance'){
   must(input.version===1&&Array.isArray(input.records)&&input.records.length>=1&&input.records.length<=4096,'演奏记录格式或容量无效');
   must(Number.isFinite(input.sampleRate)&&input.sampleRate>0&&input.sampleRate<=192000&&Number.isInteger(input.durationSamples)&&input.durationSamples>=0,'录制时钟无效');
   duration=input.durationSamples/input.sampleRate;must(duration<=60,'板端演奏记录最长60秒');let last=-1,c=65535;
   for(const hex of input.records){
    must(typeof hex==='string'&&/^[0-9a-f]{24}$/i.test(hex),'录制记录必须为96位十六进制');const w=BigInt('0x'+hex),sample=Number(w>>64n);must(sample>=last&&sample<=input.durationSamples,'录制时间未排序或超出时长');last=sample;
    c=crc(Array.from({length:12},(_,i)=>Number((w>>(BigInt(i)*8n))&255n)),c);
    if((w>>63n)&1n)events.push({time:sample/input.sampleRate,ratio:Number((w>>7n)&524287n)/262144,modDepth:Number(w&127n),synthConfig:Number((w>>26n)&4294967295n)});
    else{const voice=Number((w>>57n)&63n),timbre=Number((w>>33n)&7n);must(voice<MAX_VOICES&&timbre<5,'不支持的录制声部或音色');events.push({time:sample/input.sampleRate,voice,gate:!!((w>>56n)&1n),trigger:!!((w>>55n)&1n),note:Number((w>>48n)&127n),gain:Number((w>>36n)&4095n),timbre});}
   }
   if(input.crc16!==undefined)must(input.crc16===c,'演奏JSON校验不一致，文件可能不完整');
  }else{
   must(input.version===1&&Array.isArray(input.events)&&input.events.length>=1&&input.events.length<=8192,'需要version=1事件曲谱');
   const held=new Map(),used=new Set();let last=-1;
   for(const e of input.events){
    must(Number.isFinite(e.ms)&&e.ms>=0&&e.ms>=last,'曲谱时间未排序');last=e.ms;must(Number.isInteger(e.note)&&e.note>=0&&e.note<=127&&typeof e.on==='boolean','曲谱音高或按键状态无效');
    if(e.timbre!==undefined)must(Number.isInteger(e.timbre)&&e.timbre>=0&&e.timbre<5,'音色编号必须为0至4');
    if(e.on){must(!held.has(e.note)&&held.size<MAX_VOICES,'重复音高或同时演奏超过7音');must(Number.isInteger(e.velocity)&&e.velocity>=1&&e.velocity<=127,'力度必须为1至127');let voice=0;while(used.has(voice))voice++;held.set(e.note,voice);used.add(voice);events.push({time:e.ms/1000,voice,gate:true,trigger:true,note:e.note,gain:Math.round(e.velocity*4095/127),timbre:e.timbre});}
    else{must(held.has(e.note),'松开了未按下的音符');const voice=held.get(e.note);events.push({time:e.ms/1000,voice,gate:false,trigger:false,note:e.note});held.delete(e.note);used.delete(voice);}
   }
   must(held.size===0,'曲谱结尾存在未释放音符');duration=Math.max(last,Number.isFinite(input.duration)?input.duration:0)/1000;
  }
  must(Number.isFinite(duration)&&duration>=0,'曲谱时长无效');
  return {title:String(input.title||'我的演奏').slice(0,80),events,duration};
 }
 function engine(input,{sampleRate=44100,timbre=1}={}){
  must(Number.isInteger(sampleRate)&&sampleRate>=8000&&sampleRate<=96000,'采样率不支持');must(Number.isInteger(timbre)&&timbre>=0&&timbre<4,'音色编号无效');
  const s=normalize(input);must(!s.events.some(e=>e.timbre===4),'自定义钢琴包络请在板端试听；演奏JSON可完整保存');must(s.duration<=MAX_SECONDS,'手机试听最长300秒，此曲谱仍可通过原接口下载到FPGA');
  const voiceScale=Math.min(1,4/Math.max(4,...s.events.map(e=>(e.voice??0)+1)));
  const frames=Math.ceil((s.duration+.8)*sampleRate),buffer=new ArrayBuffer(44+frames*2),view=new DataView(buffer);
  function str(pos,text){for(let i=0;i<text.length;i++)view.setUint8(pos+i,text.charCodeAt(i));}
  str(0,'RIFF');view.setUint32(4,36+frames*2,true);str(8,'WAVE');str(12,'fmt ');view.setUint32(16,16,true);view.setUint16(20,1,true);view.setUint16(22,1,true);view.setUint32(24,sampleRate,true);view.setUint32(28,sampleRate*2,true);view.setUint16(32,2,true);view.setUint16(34,16,true);str(36,'data');view.setUint32(40,frames*2,true);
  const voices=Array.from({length:MAX_VOICES},()=>({gate:false,env:0,phase:0,note:60,gain:0,timbre:timbre||1,age:0})),weights=[[1,.3,.1,.04],[1,.42,.2,.07,.03],[1,.23,.08,.03],[1,.5,.3,.17,.08]];let cursor=0,ratio=1,mod=0,synthConfig=0,ended=false;
  // Browser approximation; all zeros retain the original synthesis exactly.
  const chorus=new Float64Array(Math.ceil(sampleRate*.04)+2);let chorusPos=0;
  const combs=[.0306,.0328,.0358,.039].map((t,i)=>({data:new Float64Array(Math.max(1,Math.round(t*sampleRate))),pos:0,lp:0,g:[.839,.828,.814,.799][i]}));
  const allpasses=[.00307,.0043].map(t=>({data:new Float64Array(Math.max(1,Math.round(t*sampleRate))),pos:0}));
  function effects(dry,time){
   const c=synthConfig&3,r=(synthConfig>>>2)&3,cw=[0,.125,.25,.375][c],rw=[0,.125,.2,.3][r];
   let chorusSum=0;
   for(let tap=0;tap<2;tap++){
    const delay=sampleRate*((tap?.018:.015)+.002*Math.sin(2*Math.PI*.8*time+tap*Math.PI/2));
    let read=(chorusPos-delay+chorus.length)%chorus.length;const base=Math.floor(read),fraction=read-base;
    chorusSum+=chorus[base]*(1-fraction)+chorus[(base+1)%chorus.length]*fraction;
   }
   chorus[chorusPos]=dry;chorusPos=(chorusPos+1)%chorus.length;
   const post=c?dry*(1-cw)+chorusSum*.5*cw:dry;let room=0;
   for(const comb of combs){const delayed=comb.data[comb.pos];comb.lp+=(delayed-comb.lp)*.525;comb.data[comb.pos]=(r?post:0)*(1-comb.g)+comb.lp*comb.g;comb.pos=(comb.pos+1)%comb.data.length;room+=delayed*.25;}
   for(const ap of allpasses){const out=ap.data[ap.pos]-.5*room;ap.data[ap.pos]=room+.5*out;ap.pos=(ap.pos+1)%ap.data.length;room=out;}
   return r?post*(1-rw)+room*rw:post;
  }
  function step(from,to){for(let i=from;i<to;i++){
   const time=i/sampleRate;
   while(cursor<s.events.length&&s.events[cursor].time<=time){const e=s.events[cursor++];if(e.voice===undefined){ratio=e.ratio;mod=e.modDepth;synthConfig=e.synthConfig||0;continue;}const v=voices[e.voice],restart=e.gate&&(e.trigger||!v.gate||v.note!==e.note);if(restart){v.phase=0;v.age=0;v.env=0;}v.gate=e.gate;v.note=e.note;if(e.gain!==undefined)v.gain=e.gain;if(e.timbre!==undefined)v.timbre=e.timbre||1;}
   if(!ended&&time>=s.duration){voices.forEach(v=>v.gate=false);ended=true;}
   let sum=0;
   for(const v of voices){
    const attack=[.004,.007,.002,.025][v.timbre],release=[.12,.18,.1,.08][v.timbre];
    if(v.gate){v.age++;const rise=1-Math.exp(-v.age/(attack*sampleRate));v.env=rise*(v.timbre===3?1:Math.exp(-v.age/([2.4,3.5,1.3,10][v.timbre]*sampleRate)));}else v.env*=Math.exp(-1/(release*sampleRate));
    if(v.env<.00001)continue;const bend=1+Math.sin(2*Math.PI*5*time)*Math.max(mod,[0,24,56,96][(synthConfig>>>4)&3])/127*.012,freq=440*Math.pow(2,(v.note-69)/12)*ratio*bend;
    v.phase=(v.phase+freq/sampleRate)%1;let wave=0,total=0;const w=weights[v.timbre];for(let h=0;h<w.length;h++){if(freq*(h+1)<sampleRate*.48){wave+=w[h]*Math.sin(2*Math.PI*v.phase*(h+1));total+=w[h];}}
    sum+=.22*voiceScale*(v.gain/4095)*v.env*wave/Math.max(1,total);
   }
   view.setInt16(44+i*2,Math.round(Math.max(-1,Math.min(1,effects(sum,time)))*32767),true);
  }}
  return {frames,step,result:()=>({wav:buffer,sampleRate,frames,duration:frames/sampleRate,title:s.title,mimeType:'audio/wav'})};
 }
 function renderWav(input,options){const x=engine(input,options);x.step(0,x.frames);return x.result();}
 async function renderWavAsync(input,{onProgress=()=>{},cancelled=()=>false,...options}={}){const x=engine(input,options);for(let i=0;i<x.frames;i+=8192){if(cancelled())throw Error('试听生成已取消');x.step(i,Math.min(i+8192,x.frames));onProgress(Math.min(i+8192,x.frames)/x.frames);await new Promise(resolve=>setTimeout(resolve,0));}return x.result();}
 const api={normalize,renderWav,renderWavAsync};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.P8Performance=api;
})(typeof window!=='undefined'?window:globalThis);
