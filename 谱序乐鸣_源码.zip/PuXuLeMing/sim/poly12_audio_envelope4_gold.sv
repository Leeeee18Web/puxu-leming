`timescale 1ns/1ps
// The existing shared context/divider services four independent note envelopes.
// Times are rounded sample counts at 50MHz/1024; no derived clock or divider LUT.
module final_envelope4_gold(
 input wire clk,rst,sample_tick,input wire[7:0]choices,
 input wire[3:0]gates,triggers,resets,
 output wire[63:0]levels,output wire[11:0]phases,
 output wire[3:0]active,output wire deadline_error
);
 function automatic[31:0]attack(input[1:0]x);
 case(x)0:attack=0;1:attack=244;2:attack=977;3:attack=3906;endcase endfunction
 function automatic[31:0]decay(input[1:0]x);
 case(x)0:decay=2441;1:decay=7324;2:decay=19531;3:decay=39063;endcase endfunction
 function automatic[31:0]sustain(input[1:0]x);
 case(x)0:sustain=13107;1:sustain=26214;2:sustain=45875;3:sustain=65535;endcase endfunction
 function automatic[31:0]release_time(input[1:0]x);
 case(x)0:release_time=3906;1:release_time=9766;2:release_time=24414;3:release_time=58594;endcase endfunction
 wire[111:0]all_levels;wire[20:0]all_phases;
 wire[159:0]cfg={release_time(choices[7:6]),sustain(choices[5:4]),decay(choices[3:2]),attack(choices[1:0]),32'd1};
 project4_envelope_bank bank(.clk(clk),.rst(rst),.sample_tick(sample_tick),.cfg(cfg),
  .gates({3'd0,gates}),.triggers({3'd0,triggers}),.resets({3'b111,resets}),
  .levels(all_levels),.phases(all_phases),.custom(),.busy(),.deadline_error(deadline_error));
 assign levels=all_levels[63:0];assign phases=all_phases[11:0];
 genvar v;generate for(v=0;v<4;v=v+1)begin:status
  assign active[v]=phases[v*3+:3]!=0;
 end endgenerate
endmodule

// One shared signed multiplier scales all four acoustic outputs continuously.
// The existing three-edge mixer and serial output cut points remain unchanged.
module final_envelope4_scale_gold(input wire clk,rst,input wire[63:0]samples,levels,
 output reg[63:0]scaled=0);
 reg[1:0]slot=0,slot_q=0;reg signed[32:0]product=0;
 reg signed[15:0]source_q=0;reg unity_q=0;
 always @(posedge clk)begin
  if(rst)begin slot<=0;slot_q<=0;product<=0;source_q<=0;unity_q<=0;scaled<=0;end
  else begin
   slot<=slot+1'b1;slot_q<=slot;
   source_q<=samples[slot*16+:16];unity_q<=levels[slot*16+:16]==65535;
   product<=$signed(samples[slot*16+:16])*$signed({1'b0,levels[slot*16+:16]});
   scaled[slot_q*16+:16]<=unity_q?source_q:product[31:16];
  end
 end
endmodule
