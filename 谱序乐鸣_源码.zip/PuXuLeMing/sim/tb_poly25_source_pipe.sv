`timescale 1ns/1ps
module tb_poly25_source_pipe;
 reg clk=0;always #10 clk=~clk;reg rst=1;reg[1:0]mode=0;reg panic=0,transition_mute=0,muted=0;
 reg[24:0]live_gates=0,live_triggers=0;reg[174:0]live_notes=0;reg[299:0]live_gains=0;reg[74:0]live_timbres=0;
 wire[24:0]source_gates,source_triggers,gates,triggers;wire[174:0]source_notes,notes;wire[299:0]source_gains,gains;wire[74:0]source_timbres,timbres;
 final_audio_source #(.VOICE_COUNT(25))src(.clk(clk),.rst(rst),.sample_tick(1'b0),.mode(mode),.start_score(1'b0),.stop_score(1'b0),.panic(panic),.transition_mute(transition_mute),.muted(muted),.live_gates(live_gates),.live_triggers(live_triggers),.live_notes(live_notes),.live_gains(live_gains),.live_timbres(live_timbres),.timbre_select(3'd1),.gates(source_gates),.triggers(source_triggers),.notes(source_notes),.gains(source_gains),.timbres(source_timbres),.playing(),.done(),.next_note());
 final_sound_pipe #(.VOICE_COUNT(25))pipe(.clk(clk),.rst(rst),.in_gates(source_gates),.in_triggers(source_triggers),.in_notes(source_notes),.in_gains(source_gains),.in_timbres(source_timbres),.in_ratio(19'd262144),.in_mod(7'd67),.in_config(32'h12345678),.ratio(),.mod_depth(),.config_word(),.*);
 integer i,checks=0;
 task check(input bit ok,input string msg);begin checks++;if(!ok)$fatal(1,"SOURCE25_FAIL %s",msg);end endtask
 initial begin
 repeat(5)@(negedge clk);rst=0;
 live_gates='1;live_triggers='1;for(i=0;i<25;i++)begin live_notes[i*7+:7]=48+i;live_gains[i*12+:12]=987+i;live_timbres[i*3+:3]=i%4;end
 @(negedge clk);check({gates,triggers,notes,gains,timbres}=={live_gates,live_triggers,live_notes,live_gains,live_timbres},"25 full live bus registered together");
 transition_mute=1;@(negedge clk);check(gates==0&&triggers==0&&gains==0,"transition mute all25");transition_mute=0;
 mode=2;force src.score_gates=4'hf;force src.score_notes=28'h1234567;force src.score_gains=48'h123456789abc;force src.score_timbres=12'hdb6;
 repeat(2)@(negedge clk);check(gates==25'hf&&notes==175'h1234567&&gains==300'h123456789abc&&timbres==75'hdb6,"built-in4 score zero padded25");
 release src.score_gates;release src.score_notes;release src.score_gains;release src.score_timbres;
 panic=1;@(negedge clk);check(gates==0&&triggers==0&&gains==0,"panic mutes all25");
 $display("POLY25_SOURCE_PIPE_PASS checks=%0d",checks);$finish;
 end
endmodule
