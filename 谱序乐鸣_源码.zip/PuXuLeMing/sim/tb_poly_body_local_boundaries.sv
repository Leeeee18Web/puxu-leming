`timescale 1ns/1ps
module tb_poly_body_continuous_boundary;
 reg clk=0;always #10 clk=~clk;reg tick=0,piano=0,en=0,load=1;reg[319:0]data=0;
 poly_model_body dut(.clk(clk),.rst(1'b0),.tick(tick),.piano(piano),.drive(22'sd0),.radiation(),.busy(),.ctx_enable(en),.ctx_load(load),.ctx_data(data),.ctx_state());
 initial begin
  data[24+:24]=24'd100;@(posedge clk);@(negedge clk);load=0;
  @(posedge clk);#1;
  if(dut.m[0].spring!==42'sd87700)$fatal(1,"BODY_CONTINUOUS_DSP_BOUNDARY_MISSING spring%0d",dut.m[0].spring);
  $display("POLY_BODY_CONTINUOUS_BOUNDARY_PASS scratch multiplier independent of shared context CE/load/reset");$finish;
 end
endmodule
module tb_poly_body_coeff_boundary;
 reg clk=0;always #10 clk=~clk;reg tick=0,piano=1,en=1,load=0;reg[319:0]data=0;
 poly_model_body dut(.clk(clk),.rst(1'b0),.tick(tick),.piano(piano),.drive(22'sd0),.radiation(),.busy(),.ctx_enable(en),.ctx_load(load),.ctx_data(data),.ctx_state());
 initial begin
  @(negedge clk);tick=1;@(posedge clk);#1;tick=0;
  force dut.piano_q=1'b0;#1;
  if(dut.m[0].k!==18'sd801)$fatal(1,"BODY_COEFFICIENT_BOUNDARY_MISSING k%0d",dut.m[0].k);
  $display("POLY_BODY_COEFF_BOUNDARY_PASS coefficient captured from raw piano at original body tick");$finish;
 end
endmodule
