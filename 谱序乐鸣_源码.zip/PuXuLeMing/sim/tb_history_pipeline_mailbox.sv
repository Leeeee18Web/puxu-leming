`timescale 1ns/1ps
module tb_history_pipeline_mailbox;
 reg clk=0,pixel_clk=0;always #10 clk=~clk;always #9.756 pixel_clk=~pixel_clk;
 reg rst=1,pixel_rstn=0,restart=0,sample_tick=0,recording=0,frame_start=0;
 wire[10:0]a,b;wire[9:0]ca,cb;wire[16:0]sa,sb;
 tone_history #(.PIPELINED_READ(1),.TOTAL_SAMPLES(768)) dut(.clk(clk),.rst(rst),.restart(restart),.sample_tick(sample_tick),.recording(recording),.pitch(11'd960),.pitch_valid(1'b1),.pixel_clk(pixel_clk),.pixel_rstn(pixel_rstn),.frame_start(frame_start),.read_addr(10'd0),.read_enable(1'b1),.pitch_data(a),.visible_count(ca),.curve_sum(sa));
 tone_history_before_pixel_pipeline #(.TOTAL_SAMPLES(768)) original(.clk(clk),.rst(rst),.restart(restart),.sample_tick(sample_tick),.recording(recording),.pitch(11'd960),.pitch_valid(1'b1),.pixel_clk(pixel_clk),.pixel_rstn(pixel_rstn),.frame_start(frame_start),.read_addr(10'd0),.read_enable(1'b1),.pitch_data(b),.visible_count(cb),.curve_sum(sb));
 integer i,checks=0;realtime accepted,delay_ns,min_delay=1.0e30;
 always @(negedge clk)if(!rst&&{dut.writer,dut.column,dut.source_bank,dut.source_count,dut.publish,dut.ack_sync}!=={original.writer,original.column,original.source_bank,original.source_count,original.publish,original.ack_sync})$fatal(1,"HISTORY_MAILBOX_SOURCE_OLD_EQ");
 initial begin
  for(i=0;i<32;i++)begin
   @(negedge clk);rst=1;pixel_rstn=0;restart=0;sample_tick=0;recording=0;frame_start=0;
   repeat(5)@(negedge clk);rst=0;pixel_rstn=1;recording=1;sample_tick=1;
   @(negedge clk);sample_tick=0;wait(dut.publish!=dut.ack_sync[1]);
   @(negedge clk);restart=1;@(negedge clk);restart=0;
   wait(dut.publish_sync[1]!=dut.seen);@(negedge pixel_clk);frame_start=1;
   @(posedge pixel_clk);accepted=$realtime;#1;
   if({dut.display_bank,ca,dut.ack}!=={original.display_bank,cb,original.ack})$fatal(1,"HISTORY_MAILBOX_PIXEL_OLD_EQ");
   @(negedge pixel_clk);frame_start=0;
   @(posedge pixel_clk);if(dut.address_bank!==1'b0)$fatal(1,"HISTORY_OLD_BANK_NOT_READ_ON_SECOND_PIXEL_EDGE");
   #1;wait(dut.writer==0);delay_ns=$realtime-accepted;
   if(delay_ns<40.0)$fatal(1,"HISTORY_ACK_RECYCLE_EARLY %f",delay_ns);
   if(delay_ns<min_delay)min_delay=delay_ns;checks++;
  end
  $display("HISTORY_PIPELINE_MAILBOX_PASS checks%0d earliestWriterReuseNs%0f secondPixelRead19.512ns before2FFack-plus-consume40ns",checks,min_delay);$finish;
 end
 initial begin #1000000;$fatal(1,"HISTORY_PIPELINE_MAILBOX_TIMEOUT");end
endmodule
