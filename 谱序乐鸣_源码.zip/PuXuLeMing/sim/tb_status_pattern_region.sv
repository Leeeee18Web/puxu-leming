`timescale 1ns/1ps
module tb_status_pattern_region;
 reg clk=0,usb_clk=0;always #10 clk=~clk;always #11 usb_clk=~usb_clk;
 reg rst=1,usb_rstn=0,usb_running=0;reg[31:0]diagnostic=0;
 wire pr,tr,er,mirror,opr,otr,oer;
 final_status_bridge #(.PERIOD(5)) dut(.clk(clk),.rst(rst),.usb_clk(usb_clk),.usb_rstn(usb_rstn),.usb_running(usb_running),.diagnostic(diagnostic),.piano_ready(pr),.touch_ready(tr),.esp_ready(er),.esp_ready_patterns(mirror),.status_pattern_raw());
 ref_status_bridge #(.PERIOD(5)) original(.clk(clk),.rst(rst),.usb_clk(usb_clk),.usb_rstn(usb_rstn),.usb_running(usb_running),.diagnostic(diagnostic),.piano_ready(opr),.touch_ready(otr),.esp_ready(oer));
 reg[1:0]mode=0,wifi_mode=0,touch_mode=0;reg override_on=0,sample_tick=0,event_valid=0,event_ready=1;
 reg panic=0,clear_live=0,stop_score=0,mute_enter=0,all_off=0,touch_lost=0,start=0,pedal=0;
 reg[31:0]event_data=0;wire[1:0]pm[0:1];wire enabled[0:1],sel[0:1],cancel[0:1];wire[1:0]ready={oer,mirror};
 wire[6:0]selected[0:1];wire[48:0]notes7[0:1];wire[83:0]gains7[0:1];wire[3:0]gates[0:1],triggers[0:1],pgates[0:1],ptriggers[0:1];
 wire[27:0]notes4[0:1],pnotes[0:1];wire[47:0]gains4[0:1],pgains[0:1];wire[11:0]ptimbres[0:1];wire busy[0:1],full[0:1];wire[2:0]count[0:1];
 genvar v;generate for(v=0;v<2;v++)begin:p
  assign pm[v]=(ready[v]&&override_on)?wifi_mode:touch_mode;
  assign enabled[v]=(mode==1)||(ready[v]&&override_on&&wifi_mode!=0);
  assign sel[v]=enabled[v]&&pm[v]!=0;
  assign cancel[v]=panic||clear_live||stop_score||mute_enter||all_off||!enabled[v]||touch_lost||(event_valid&&event_ready&&sel[v]&&event_data[7:0]==8'hff);
  final_patterns patterns(.clk(clk),.rst(rst),.sample_tick(sample_tick),.cancel(cancel[v]),.pattern_mode(pm[v]),.start(start),.event_valid(event_valid&&event_ready&&sel[v]),.event_data(event_data),.selected(selected[v]),.selected_notes(notes7[v]),.selected_gains(gains7[v]),.gates(gates[v]),.triggers(triggers[v]),.notes(notes4[v]),.gains(gains4[v]),.busy(busy[v]),.count(count[v]),.full(full[v]),.full_touch_mode(2'd0),.full_wifi_mode(2'd0),.full_owner(1'b0),.full_touch_enabled(1'b0),.full_note_request(1'b0),.full_base_cancel(1'b0));
  final_pattern_pedal hold(.clk(clk),.rst(rst),.pedal_down(pedal),.pattern_mode(pm[v]),.cancel(cancel[v]||start),.in_gates(gates[v]),.in_triggers(triggers[v]),.in_notes(notes4[v]),.in_gains(gains4[v]),.timbre_select(3'd1),.gates(pgates[v]),.triggers(ptriggers[v]),.notes(pnotes[v]),.gains(pgains[v]),.timbres(ptimbres[v]));
 end endgenerate
 integer i,checks=0,captures=0,down=0;reg[31:0]rng=32'hfac38127;
 always @(negedge clk)begin #1;
  if({pr,tr,er,mirror}!=={opr,otr,oer,oer})$fatal(1,"STATUS_MIRROR_NOT_SAME_CYCLE");
  if({dut.ready_snapshot.ack,dut.ready_snapshot.publish,dut.ready_snapshot.seen,dut.ready_snapshot.frame_data}!=={original.ready_snapshot.ack,original.ready_snapshot.publish,original.ready_snapshot.seen,original.ready_snapshot.frame_data})$fatal(1,"STATUS_HANDSHAKE_CHANGED");
  if({pm[0],enabled[0],sel[0],cancel[0],selected[0],notes7[0],gains7[0],gates[0],triggers[0],notes4[0],gains4[0],busy[0],full[0],count[0],pgates[0],ptriggers[0],pnotes[0],pgains[0],ptimbres[0]}!=={pm[1],enabled[1],sel[1],cancel[1],selected[1],notes7[1],gains7[1],gates[1],triggers[1],notes4[1],gains4[1],busy[1],full[1],count[1],pgates[1],ptriggers[1],pnotes[1],pgains[1],ptimbres[1]})$fatal(1,"PATTERN_READY_REGION_CHANGED");
  checks++;if(er)captures++;if(!usb_running)down++;
 end
 initial begin
  repeat(8)@(negedge clk);rst=0;usb_rstn=1;
  for(i=0;i<100000;i++)begin
   @(posedge clk);#2;rng=rng*32'd1664525+32'd1013904223;
   diagnostic={26'd0,rng[5:0]};usb_running=rng[7];usb_rstn=(i%997!=0);rst=(i%1999==0);
   mode=rng[9:8];wifi_mode=rng[11:10];touch_mode=rng[13:12];override_on=rng[14];sample_tick=(i%7==0);
   start=(i%61==0);pedal=rng[16];panic=(i%541==0);clear_live=(i%307==0);stop_score=(i%167==0);mute_enter=(i%97==0);all_off=(i%79==0);touch_lost=(i%193==0);
   event_valid=rng[20];event_ready=rng[21];event_data=0;event_data[15:8]=48+(i%24);event_data[23:16]=96;
   case(i%13)0:event_data[7:0]=8'hff;1:begin event_data[7:4]=11;event_data[15:8]=120;event_data[23:16]=0;end 2:begin event_data[7:4]=11;event_data[15:8]=123;event_data[23:16]=0;end 3:event_data[7:4]=8;default:event_data[7:4]=9;endcase
   #1;if(!usb_running&&(mirror!==0||er!==0))$fatal(1,"USB_DOWN_DELAYED");
  end
  if(captures<1000||down<1000)$fatal(1,"STATUS_COVERAGE");
  $display("STATUS_PATTERN_REGION_EQ_PASS checks=%0d esp_ready=%0d usbdown=%0d ACK/modes/events/cancel/pedal same-cycle",checks,captures,down);$finish;
 end
 initial begin #3000000;$fatal(1,"STATUS_REGION_TIMEOUT");end
endmodule
