// Exercises production USB enumeration and FIFO recovery with packet fixtures.
#define USB_WIFI_NO_MAIN
#include "test_usb_wifi_transport.c"
static unsigned host_restarts;
void usb_play_controller_restart(void){
 host_restarts++;memset(&c,0,sizeof(c));
 for(unsigned i=0;i<8;i++)d[i].address=d[i].configured=d[i].toggle=d[i].queue_len=0;
 out_toggle=retry_len=out_timeout=out_nak=serial_silent=0;
}
static void exchange(unsigned expected){
 uint8_t app[22]={80,87,1,3,1,0,7,0},wire[28];unsigned n=envelope(wire,app,22);
 stream(0,wire,n);CHECK(ndelivered==expected+22);CHECK(!memcmp(delivered+expected,app,22));
 memcpy(replies,app,22);nreplies=22;reply_pos=0;unsigned prior=noutbound;tick(20);
 CHECK(noutbound==prior+28&&!memcmp(outbound+prior,wire,28));
}
int main(void){
 baseline_main(0,0);
 serial_fixture(0);CHECK(usb_play_state()&32);exchange(0);
 for(unsigned cycle=0;cycle<3;cycle++){
  unsigned before=ndelivered,resets_before=host_restarts;
  speed=0;tick(5);CHECK(!(usb_play_state()&32)&&host_restarts>resets_before);
  // Replug the same CH340: USB address/configuration and DATA toggles are fresh.
  speed=1;tick(90);CHECK((usb_play_state()&33)==33&&!(usb_play_state()&16));
  exchange(before);
 }
 // A very brief unplug/ESP restart can be missed by the line debounce.
 // The stale address then times out; the host must retry without FPGA reset.
 serial_silent=1;tick(8);CHECK((usb_play_state()&16)&&!(usb_play_state()&32));
 unsigned before=ndelivered,resets_before=host_restarts;
 tick(350);CHECK((usb_play_state()&32)&&!(usb_play_state()&16)&&host_restarts>resets_before);exchange(before);
 // Wrong initial line classification cannot keep root_blocked set forever.
 serial_fixture(0);speed=0;tick(5);speed=2;tick(35);CHECK(usb_play_state()&16);
 speed=1;resets_before=host_restarts;tick(350);
 CHECK((usb_play_state()&32)&&host_restarts>resets_before);exchange(0);
 // Staged reverse data from an old attachment must not be sent to the new one.
 memcpy(replies,"old reply must be lost!",22);nreplies=22;reply_pos=0;out_nak=100;tick(1);
 speed=0;tick(5);nreplies=reply_pos=0;unsigned old_out=noutbound;
 speed=1;tick(90);CHECK(usb_play_state()&32);CHECK(noutbound==old_out);
 printf("USB_HOTPLUG_PASS checks=%u restarts=%u (3 replug cycles, missed detach, blocked retry, stale reply isolation)\n",checks,host_restarts);return 0;
}
