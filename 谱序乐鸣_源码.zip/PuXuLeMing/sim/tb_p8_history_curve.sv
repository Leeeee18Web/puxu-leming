`timescale 1ns/1ps
module tb_p8_history_curve;
 reg clk=0,pclk=0,rst=1,prstn=0,restart=0,record=0,valid=1,tick=0,frame=0;
 always #10 clk=~clk;always #11 pclk=~pclk;
 reg [10:0] pitch=960;reg [9:0] addr=0;wire [10:0] data;wire [9:0] count;wire [16:0] curve;
 tone_history #(.TOTAL_SAMPLES(3072)) dut(.read_enable(1'b1),.clk(clk),.rst(rst),.restart(restart),.sample_tick(tick),.recording(record),.pitch(pitch),.pitch_valid(valid),
 .pixel_clk(pclk),.pixel_rstn(prstn),.frame_start(frame),.read_addr(addr),.pitch_data(data),.visible_count(count),.curve_sum(curve));
 integer cycle=0,pc=0,i,k,index,expected_sum;reg [10:0] raw[0:767];
 always @(negedge clk)begin tick=0;if(!rst)begin cycle=cycle+1;tick=(cycle%4)==0;end end
 always @(negedge pclk)begin pc=pc+1;frame=pc%4==0;end
 task read(input integer a);begin @(negedge pclk);addr=a;repeat(2)@(negedge pclk);end endtask
 initial begin
  repeat(5)@(negedge clk);rst=0;prstn=1;record=1;
  wait(count>=256);pitch=992;wait(count>=512);pitch=1072;wait(dut.column==768);record=0;wait(count==768);
  for(i=0;i<768;i=i+1)begin read(i);raw[i]=data;if(raw[i]!=960&&raw[i]!=992&&raw[i]!=1072)$fatal(1,"invalid note history");end
  read(0);if(data!=960)$fatal(1,"first Do4 pitch");read(767);if(data!=1072)$fatal(1,"last Sol4 pitch");
  for(i=0;i<768;i=i+1)begin
   expected_sum=0;for(k=-3;k<=3;k=k+1)begin index=i+k;if(index<0)index=0;if(index>767)index=767;expected_sum=expected_sum+(7680-(raw[index]-768)*7)*(4-(k<0?-k:k));end
   read(i);if(curve!=expected_sum)$fatal(1,"seven tap interpolation %d",i);
  end
  @(negedge clk);restart=1;pitch=968;record=1;@(negedge clk);restart=0;wait(count==0);wait(count>=8);read(0);if(data!=968)$fatal(1,"restart/bend fractional pitch");
  valid=0;wait(count>=32);read(31);if(data!=2047)$fatal(1,"silent gap sentinel");
  $display("TONE_PASS MIDIQ4 actual notes,768 columns,7tap no overshoot, restart, fractional bend and rests");$finish;
 end
 initial begin #10000000;$fatal(1,"tone history deadline");end
endmodule

