`timescale 1ns/1ps
module tb_k1_control;
 reg clk=0;always #10 clk=~clk;
 reg rst=1,sample_tick=0,event_valid=0,panic=0,centre=0,pedal_down=0;reg[31:0]event_data=0;
 reg[2:0]timbre_select=0;reg[3:0]voice_active=0;reg[1:0]knob_mode=1;
 wire event_ready;wire[3:0]gates,triggers;wire[27:0]notes;wire[47:0]gains;wire[11:0]timbres;
 wire[18:0]ratio;wire[6:0]knob,last_note,last_velocity,mod_depth,raw_knob;wire raw_known,pickup_wait;
 final_voice_control #(.RELATIVE_KNOB(1),.ENABLE_PEDAL(1)) dut(.event_source(2'd0),.map_notes(175'd0),.map_input_base(7'd60),.map_enabled(1'b0),.map_apply(1'b0),.key_seen_valid(),.key_seen_index(),.display_original_keys(),.display_owners(),.display_channels(),.*,.ready_raw());
 reg key_n=1;wire down;project_pedal #(.TICKS(4)) button(.clk(clk),.rst(rst),.key_n(key_n),.down(down));
 integer i,checks=0;reg[27:0]before_notes;
 task check(input bit ok,input string why);begin checks++;if(!ok)$fatal(1,"K1_CONTROL_FAIL %s",why);end endtask
 task clocks(input integer n);repeat(n)@(negedge clk);endtask
 task ev(input bit src,input[7:0]s,input[6:0]a,b);begin
  @(negedge clk);event_data={7'd0,src,1'b0,b,1'b0,a,s};event_valid=1;
  @(negedge clk);event_valid=0;clocks(2);
 end endtask
 task reset_all;begin rst=1;clocks(3);rst=0;pedal_down=0;voice_active=0;clocks(3);end endtask
 initial begin
  reset_all;
  key_n=0;clocks(2);key_n=1;clocks(8);check(!down,"short contact bounce rejected");
  key_n=0;clocks(8);check(down,"stable press level");clocks(10);check(down,"press stays active without pulses");
  key_n=1;clocks(2);key_n=0;clocks(8);check(down,"release bounce rejected");
  key_n=1;clocks(8);check(!down,"stable release level");
  pedal_down=1;
  for(i=0;i<4;i++)ev(0,8'h90,60+i,100);
  voice_active=15;
  for(i=0;i<4;i++)ev(0,8'h80,60+i,0);
  check(gates==15&&dut.held==0,"four pedal only notes");ev(0,8'h90,67,100);
  check(notes[6:0]==67&&gates==15&&dut.held==1,"fifth replaces oldest pedal only slot");
  ev(0,8'h80,60,0);check(dut.held[0]&&gates[0],"stale old pitch off cannot release replacement");
  pedal_down=0;clocks(3);check(gates==1&&gains[23:12]!=0&&triggers==0,"pedal up preserves held and natural release gains");
  ev(0,8'h80,67,0);check(gates==0,"last finger release");pedal_down=1;clocks(3);check(gates==0&&triggers==0,"no reattack on pedal alone");
  reset_all;
  for(i=0;i<4;i++)ev(0,8'h90,70+i,100);
  voice_active=15;before_notes=notes;ev(0,8'h90,80,100);
  check(notes==before_notes&&gates==15,"all four fingers protected");
  reset_all;pedal_down=1;ev(0,8'hb0,64,127);ev(0,8'h90,60,100);ev(1,8'h90,64,100);
  ev(0,8'h80,60,0);ev(1,8'h80,64,0);pedal_down=0;clocks(3);
  check(gates==1,"K1 release respects source specific CC64");ev(0,8'hb0,64,0);check(gates==0,"last pedal releases");
  pedal_down=1;ev(0,8'hb0,64,127);ev(0,8'h90,60,100);ev(0,8'h80,60,0);ev(0,8'hb0,64,0);
  check(gates==1,"CC64 up cannot override K1");
  // Pedal release and source CC64-on arrive at the same clock.
  @(negedge clk);pedal_down=0;event_data=32'h007f40b0;event_valid=1;
  @(negedge clk);event_valid=0;clocks(3);check(gates==1,"coincident CC64 on covers K1 up");
  pedal_down=1;ev(0,8'hb0,123,0);check(gates==1,"all notes off honors pedal");
  ev(0,8'hb0,120,0);check(gates==0&&gains[11:0]==0,"all sound off overrides pedals");
  ev(0,8'h90,60,100);ev(1,8'h90,64,100);ev(0,8'h80,60,0);ev(1,8'h80,64,0);
  ev(0,8'hff,0,0);check(gates==2,"USB disconnect clears USB while touch survives");
  panic=1;clocks(1);panic=0;clocks(3);check(gates==0&&gains==0,"panic dominates held K1");
  $display("K1_CONTROL_PASS checks=%0d",checks);$finish;
 end
endmodule
