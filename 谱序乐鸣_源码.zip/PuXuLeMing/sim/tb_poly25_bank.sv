`timescale 1ns/1ps
module tb_poly25_bank;
 reg clk=0;always #10 clk=~clk;reg rst=1,start=0;
 reg[24:0]gates=25'h1ffffff,triggers=0;reg[599:0]steps=0;reg[299:0]gains=0;reg[74:0]tones=0;
 wire[399:0]samples,envelopes;wire[24:0]active;wire busy,err;
 poly25_bank dut(clk,rst,start,gates,triggers,steps,gains,tones,samples,envelopes,active,busy,err,{12{rst}},1'b1);
 `include "play_note_steps.vh"
 integer f,c,i;reg[24:0]heard=0;
 initial begin
 for(i=0;i<25;i=i+1)begin steps[i*24+:24]=midi_step(48+i);gains[i*12+:12]=1600;tones[i*3+:3]=i%4;end
 repeat(5)@(negedge clk);rst=0;
 for(f=0;f<2200;f=f+1)begin
  triggers=f==0?25'h1ffffff:0;
  if(f==1500)gates[24]=0;if(f==1600)gains[24*12+:12]=0;
  for(c=0;c<1024;c=c+1)begin
   start=c==32;@(negedge clk);
   if(c==1008)begin
    if(busy||err)$fatal(1,"POLY25_BANK_DEADLINE frame%0d",f);
    if(f>100&&f<1500&&active!==25'h1ffffff)$fatal(1,"POLY25_NOT_ALL_ACTIVE frame%0d mask%h",f,active);
    if(f>1602&&active!==25'h0ffffff)$fatal(1,"POLY25_INDEPENDENT_MUTE frame%0d mask%h",f,active);
    for(i=0;i<25;i=i+1)if($signed(samples[i*16+:16])!=0)heard[i]=1;
   end
  end
 end
 if(heard!==25'h1ffffff)$fatal(1,"POLY25_SILENT_VOICES mask%h",heard);
 $display("POLY25_BANK_PASS 2200frames all25 audible independent contexts all4timbres deadline/individual mute");$finish;
 end
 initial begin #60000000;$fatal(1,"POLY25_BANK_TIMEOUT");end
endmodule
