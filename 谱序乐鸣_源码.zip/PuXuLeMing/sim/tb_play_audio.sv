`timescale 1ns/1ps
module tb_play_audio;
 reg clk=0;always #10 clk=~clk;
 reg rst=1;reg [6:0] gates=0,triggers=0,mod_depth=0;reg [48:0] notes=0;reg [83:0] gains=0;reg [18:0] ratio=262144;
 wire sample_tick;wire signed [15:0] pcm;wire hp_bck,hp_ws,hp_din,i2s_bck,i2s_ws,i2s_sd;wire [6:0] active;
 play_audio dut(.*);
 wire [15:0] decoded_l,decoded_r;wire decoded_valid;
 i2s_rx16 receiver(.clk(clk),.rst(rst),.bck(i2s_bck),.ws(i2s_ws),.sd(i2s_sd),.pcm_l(decoded_l),.pcm_r(decoded_r),.frame_valid(decoded_valid));
 integer cycles=0,last_tick=-1,samples=0,nonzero=0,frames=0,hp_words=0,serial_checks=0;
 reg [15:0] expected[0:32767];integer writeptr=0,readptr=0;
 reg hp_bck_q=1,hp_ws_q=0;reg [15:0] hp_shift=0;reg [4:0] hp_bits=0;reg [15:0] hp_right=0;
 integer outfd;integer positive=0,last_positive=0,first_positive=0,crossings=0;reg signed [15:0] previous=0;
 real period_c4,period_c5,period_low,period_high;
 integer k,v;reg [6:0] seen_voices=0;
 reg release_seen=0;
 task check(input bit ok,input string message);begin if(!ok)$fatal(1,"%s",message);end endtask
 always @(posedge clk)begin
  cycles=cycles+1;
  if(rst)begin last_tick=-1;writeptr=0;readptr=0;hp_bck_q=1;hp_ws_q=0;hp_shift=0;hp_bits=0;end
  else begin
   if(sample_tick)begin
    if(last_tick!=-1)check(cycles-last_tick==1024,"sample period exactly1024");last_tick=cycles;
    expected[writeptr]=pcm;writeptr=writeptr+1;samples=samples+1;
    if(pcm!=0)nonzero=nonzero+1;
   end
   if(decoded_valid)begin
    check(decoded_l==decoded_r,"I2S stereo channels agree");
    check(decoded_l===expected[readptr],"I2S decodes actual frame PCM");readptr=readptr+1;frames=frames+1;
   end
   hp_bck_q=hp_bck;
  end
 end
 // PT8211 words have no I2S delay: first bit coincides with WS transition.
 reg [4:0] pt_bit=0;reg [15:0] pt_shift=0;integer pt_frame=0;
 always @(posedge hp_bck)if(!rst)begin
  pt_shift={pt_shift[14:0],hp_din};
  if(pt_bit==15)begin
   if(!hp_ws)hp_right=pt_shift;
   else begin
    check(hp_right==pt_shift,"PT8211 stereo channels agree");
    check(pt_shift===expected[pt_frame],"PT8211 decodes actual frame PCM");pt_frame=pt_frame+1;serial_checks=serial_checks+1;
   end
   pt_bit=0;
  end else pt_bit=pt_bit+1;
 end
 task reset_note(input [6:0] note,input [18:0] bend);
 begin @(negedge clk);rst=1;gates=0;triggers=0;repeat(5)@(negedge clk);notes=0;notes[6:0]=note;gains=0;gains[11:0]=4064;ratio=bend;rst=0;gates=1;triggers=1;@(negedge clk);triggers=0;pt_bit=0;pt_shift=0;pt_frame=0;end endtask
 task measure(output real period);
 integer k;begin
  crossings=0;first_positive=0;last_positive=0;previous=0;
  for(k=0;k<4096;k=k+1)begin
   @(negedge clk);while(!sample_tick)@(negedge clk);
   if(k>1024&&pcm>0&&previous<=0)begin if(crossings==0)first_positive=k;last_positive=k;crossings=crossings+1;end
   previous=pcm;
   if(outfd!=0)$fdisplay(outfd,"%0d",pcm);
  end
  check(crossings>10,"actual synth waveform has periodic crossings");period=1.0*(last_positive-first_positive)/(crossings-1);
 end endtask
 initial begin
  outfd=$fopen("build/audio_pcm_samples.txt","w");
  reset_note(60,262144);measure(period_c4);check(nonzero>100&&active[0],"real electricpiano PCM active");
  reset_note(72,262144);measure(period_c5);
  $display("DIAGNOSTIC actual periods C4=%f C5=%f ratio=%f",period_c4,period_c5,period_c4/period_c5);
  check(period_c4>180&&period_c4<192,"actual C4 period near186.632 samples");
  check(period_c5>90&&period_c5<96,"actual C5 octave period");
  check(period_c4/period_c5>1.98&&period_c4/period_c5<2.02,"actual octave doubles frequency");
  reset_note(60,174960);measure(period_low);reset_note(60,392772);measure(period_high);
  check(period_low/period_c4>1.48&&period_low/period_c4<1.52,"actual low bend ratio");
  check(period_high/period_c4>0.65&&period_high/period_c4<0.69,"actual high bend ratio");
  // All seven actual voice renderers must contribute PCM, including note0/127.
  reset_note(0,262144);
  @(negedge clk);gates=127;triggers=127;
  notes={7'd127,7'd84,7'd72,7'd60,7'd48,7'd36,7'd0};
  for(v=0;v<7;v=v+1)gains[v*12+:12]=12'd3200;
  @(negedge clk);triggers=0;
  for(k=0;k<512;k=k+1)begin
   @(negedge clk);while(!sample_tick)@(negedge clk);
   for(v=0;v<7;v=v+1)if($signed(dut.engine.voice_samples[v*16+:16])!=0)seen_voices[v]=1;
  end
  check(active==127&&seen_voices==127,"seven actual PCM voices and full note range");
  @(negedge clk);gates=0;
  for(k=0;k<32;k=k+1)begin @(negedge clk);while(!sample_tick)@(negedge clk);if(pcm!=0)release_seen=1;end
  check(release_seen,"ordinary note off retains natural release PCM");
  @(negedge clk);gains=0;
  repeat(4)begin @(negedge clk);while(!sample_tick)@(negedge clk);end
  check(pcm==0,"urgent gain-zero mask hard silences all voices");
  reset_note(60,262144);
  @(negedge clk);gates=3;notes[13:7]=64;gains[23:12]=3200;triggers=3;
  @(negedge clk);triggers=0;
  repeat(256)begin @(negedge clk);while(!sample_tick)@(negedge clk);end
  @(negedge clk);gates=2;gains[11:0]=0;
  repeat(4)begin @(negedge clk);while(!sample_tick)@(negedge clk);end
  check(dut.engine.voice_samples[15:0]==0,"urgent USB slot mask silences its PCM");
  check(dut.engine.voice_samples[31:16]!=0&&pcm!=0,"virtual slot PCM continues after USB-only mute");
  check(frames>10000&&serial_checks>10000,"both serial formats decoded");
  $display("PASS tb_play_audio samples=%0d nonzero=%0d I2Sframes=%0d PTframes=%0d C4=%f C5=%f low=%f high=%f",samples,nonzero,frames,serial_checks,period_c4,period_c5,period_low,period_high);
  $fclose(outfd);$finish;
 end
 initial begin #1000000000;$fatal(1,"audio timeout");end
endmodule
