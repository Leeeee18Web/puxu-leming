#pragma once
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <string>
#include <vector>
#include <deque>
#define PROGMEM
#define SERIAL_8N1 0
class String:public std::string {
 public:using std::string::string;String(const std::string& s):std::string(s){}
};
inline uint32_t fakeNow=0;
inline uint32_t millis(){return fakeNow;}
inline void delay(unsigned n){fakeNow+=n;}
struct SerialStub {
 unsigned baud=0,rx=0,tx=0,bufferSize=0,writes=0;bool online=true;
 std::deque<uint8_t> input;std::vector<uint8_t> output;
 void setRxBufferSize(unsigned n){bufferSize=n;}
 void begin(unsigned speed,int,unsigned r,unsigned t){baud=speed;rx=r;tx=t;}
 void setDebugOutput(bool){}
 int available(){return int(input.size());}
 int read(){int c=input.front();input.pop_front();return c;}
 size_t write(const uint8_t*,size_t);
};
inline SerialStub Serial0;
