#pragma once
#include "Arduino.h"
#include <functional>
#include <map>
#define HTTP_GET 1
#define HTTP_POST 2
struct ClientStub {
 std::vector<uint8_t> sent;
 size_t write(const uint8_t* p,size_t n){sent.assign(p,p+n);return n;}
};
struct WebServer {
 explicit WebServer(int){}
 String body,response,mime;int code=0;size_t contentLength=0;ClientStub socket;
 std::map<std::string,std::function<void()>> handlers;
 String arg(const char*){return body;}
 void sendHeader(const char*,const char*){}
 void setContentLength(size_t n){contentLength=n;}
 void send(int n,const char* type,const String& text){code=n;mime=type;response=text;}
 void send_P(int n,const char* type,const char* text){send(n,type,String(text));}
 ClientStub& client(){return socket;}
 void on(const char* path,int,std::function<void()> h){handlers[path]=h;}
 void onNotFound(std::function<void()> h){handlers["404"]=h;}
 void begin(){}void handleClient(){}
};
