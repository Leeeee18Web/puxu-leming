#pragma once
#include <vector>
#include <cstring>
class Preferences {
 public:
 inline static std::vector<uint8_t> stored{};inline static unsigned writes=0;inline static bool failWrite=false;
 bool begin(const char*,bool){return true;}
 size_t getBytesLength(const char*){return stored.size();}
 size_t getBytes(const char*,void* out,size_t n){if(n!=stored.size())return 0;memcpy(out,stored.data(),n);return n;}
 size_t putBytes(const char*,const void* p,size_t n){writes++;if(failWrite)return 0;const auto* bytes=static_cast<const uint8_t*>(p);stored.assign(bytes,bytes+n);return n;}
};
