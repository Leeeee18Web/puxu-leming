#pragma once
#include "Arduino.h"
#define WIFI_AP 1
#define WIFI_AP_STA 3
#define WL_CONNECTED 3
struct IPAddress {
 unsigned a=0,b=0,c=0,d=0;
 IPAddress()=default;
 IPAddress(unsigned w,unsigned x,unsigned y,unsigned z):a(w),b(x),c(y),d(z){}
 String toString()const{return std::to_string(a)+"."+std::to_string(b)+"."+std::to_string(c)+"."+std::to_string(d);}
};
struct WiFiStub {
 String apName;bool ap=false;IPAddress apAddress;int selectedMode=0;
 void persistent(bool){}void setSleep(bool){}void mode(int n){selectedMode=n;}
 bool softAPConfig(IPAddress address,IPAddress,IPAddress){apAddress=address;return true;}
 bool softAP(const char* name,const char*,int,bool,int){apName=name;ap=true;return true;}
 IPAddress softAPIP(){return apAddress;}IPAddress localIP(){return {};}
 int status(){return 0;}
};
inline WiFiStub WiFi;
