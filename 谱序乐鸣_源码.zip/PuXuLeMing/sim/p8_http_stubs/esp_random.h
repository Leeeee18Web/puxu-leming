#pragma once
#include <stdint.h>
inline uint32_t esp_random(){static uint32_t n=0x4d24;return ++n;}
