`timescale 1ns/1ps
module tb_poly_keymap;
 reg clk=0,rst=1,abort_transaction=0,command_valid=0,key_seen_valid=0;always #10 clk=~clk;
 reg[7:0]command_op=0;reg[31:0]command_a=0,command_b=0,command_c=0;reg[4:0]key_seen_index=0;
 wire command_done;wire[7:0]command_result;wire[174:0]map_notes;wire[6:0]map_input_base;wire map_enabled,map_apply;wire[31:0]reply_a,reply_b;
 poly_keymap dut(.map_apply_audio(),.map_apply_fx(),.*);integer checks=0,applies=0,k;reg[15:0]crc;
 function automatic[15:0]cb(input[15:0]c,input[7:0]b);reg[15:0]v;integer n;begin v=c^{b,8'd0};for(n=0;n<8;n=n+1)v=v[15]?(v<<1)^16'h1021:v<<1;cb=v;end endfunction
 task check(input bit ok,input string label);begin checks++;if(!ok)$fatal(1,"KEYMAP_FAIL %s",label);end endtask
 always @(posedge clk)if(!rst&&map_apply)begin applies++;check(map_notes[6:0]==60,"clear pulse precedes visible table");end
 task cmd(input[7:0]op,input[31:0]a,b,input[7:0]result);integer timeout;begin
  @(negedge clk);command_op=op;command_a=a;command_b=b;command_valid=1;
  @(negedge clk);command_valid=0;timeout=0;
  while(!command_done&&timeout<100)begin @(negedge clk);timeout++;end
  check(command_done,"bounded reply");check(command_result==result,"command status");
 end endtask
 initial begin
  repeat(4)@(negedge clk);rst=0;
  for(k=0;k<25;k++)check(map_notes[k*7+:7]==60+k,"default contiguous25");
  cmd(22,0,0,5);cmd(21,0,70,1);cmd(20,104,1,1);cmd(20,48,1,0);
  cmd(21,25,60,1);cmd(21,0,128,1);cmd(21,0,0,0);cmd(22,0,0,5);
  check(map_notes[6:0]==60&&applies==0,"incomplete transaction invisible");
  // Arbitrary-order PUT writes are covered by a 25-bit completeness mask.
  crc=cb(cb(16'hffff,48),1);
  for(k=24;k>=0;k--)cmd(21,k,k==0?0:(k==24?127:67),0);
  for(k=0;k<25;k++)crc=cb(crc,k==0?0:(k==24?127:67));
  cmd(22,crc^1,1,5);check(map_notes[6:0]==60&&applies==0,"CRC failure preserves active table");
  cmd(22,crc,1,0);check(applies==1&&map_notes[6:0]==0&&map_notes[168+:7]==127&&map_input_base==48,"atomic whole25 commit");
  cmd(23,24,0,0);check(reply_a[15:8]==127&&reply_a[23:16]==48&&reply_a[24]&&reply_b[15:0]==crc,"GET actual applied state and CRC");
  cmd(24,1,0,0);check(!reply_b[21],"learn arms empty");
  @(negedge clk);key_seen_valid=1;key_seen_index=24;@(negedge clk);key_seen_valid=0;
  cmd(24,0,0,0);check(reply_b[21]&&reply_b[20:16]==24,"physical key learning");
  cmd(20,60,0,0);cmd(21,0,10,0);@(negedge clk);abort_transaction=1;@(negedge clk);abort_transaction=0;
  cmd(21,1,11,1);cmd(22,crc,0,5);check(map_notes[6:0]==0,"disconnect abort leaves active unchanged");
  $display("POLY_KEYMAP_PASS checks=%0d",checks);$finish;
 end
 initial begin #1000000;$fatal(1,"keymap timeout");end
endmodule
