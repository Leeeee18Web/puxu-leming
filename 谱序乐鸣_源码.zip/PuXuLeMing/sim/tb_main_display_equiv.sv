`timescale 1ns/1ps
module main_display_case #(parameter N=7)(output reg done=0);
 reg clk=0,rst=1;always #10 clk=~clk;reg[N-1:0]gates=0;reg[N*7-1:0]notes=0;reg[N*12-1:0]gains=0;
 wire[3:0]pg,opg;wire[27:0]pn,opn;wire[47:0]pa,opa;
 poly25_display_slots #(.VOICE_COUNT(N)) dut(clk,rst,gates,notes,gains,pg,pn,pa);
 poly_display_before_main #(.VOICE_COUNT(N)) old(clk,rst,gates,notes,gains,opg,opn,opa);
 integer checks=0,i,j,gm,zm,publications=0;
 always @(posedge clk)begin #1;checks++;
  if({pg,pn,pa,dut.index,dut.found,dut.working_notes,dut.working_gains}!=={opg,opn,opa,old.index,old.found,old.working_notes,old.working_gains})$fatal(1,"MAIN_DISPLAY_OLD_EQ N%0d clock%0d",N,checks);
  if(dut.index==0&&pg!=0)publications++;
 end
 initial begin
  repeat(3)@(negedge clk);rst=0;
  if(N==7)for(gm=0;gm<128;gm++)for(zm=0;zm<128;zm++)begin
   gates=gm;for(j=0;j<N;j++)begin gains[j*12+:12]=zm[j]?(12'd1<<((gm+j)%12)):0;notes[j*7+:7]=(gm+j)%128;end
   repeat(8)@(negedge clk);
  end
  for(i=0;i<40000;i++)begin
   gates=$urandom;for(j=0;j<N;j++)begin gains[j*12+:12]=(i%9==0)?0:$urandom;notes[j*7+:7]=$urandom;end
   rst=i%1013==0;@(negedge clk);
  end
  if(publications==0)$fatal(1,"MAIN_DISPLAY_COVERAGE");$display("MAIN_DISPLAY_EQ_PASS N%0d everyClock%0d publications%0d exhaustive7GateZeroMask%0d",N,checks,publications,N==7?16384:0);done=1;
 end
endmodule
module tb_main_display_equiv;
 wire[3:0]done;main_display_case #(.N(1)) n1(done[0]);main_display_case #(.N(4)) n4(done[1]);main_display_case #(.N(7)) n7(done[2]);main_display_case #(.N(25)) n25(done[3]);
 initial begin wait(&done);$finish;end
 initial begin #5000000;$fatal(1,"MAIN_DISPLAY_TIMEOUT");end
endmodule
