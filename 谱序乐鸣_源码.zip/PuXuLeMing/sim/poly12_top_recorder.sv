`timescale 1ns/1ps
module tb_poly12_top_recorder;
 reg clk=0;always #10 clk=~clk;reg rst=1;reg[9:0]phase=0;always @(posedge clk)phase<=phase+1'b1;
 wire sample_tick=phase==1023;
 reg record_toggle=0,replay_toggle=0,panic=0;
 reg[11:0]gates=12'hfff,triggers=0;reg[83:0]notes=0;reg[143:0]gains=0;reg[35:0]timbres=0;
 reg[31:0]cfg_word=32'h9500;wire recording,replaying,full,ready;wire[12:0]count;wire[31:0]duration;
 wire[11:0]out_gates;wire[83:0]out_notes;wire[143:0]out_gains;wire[35:0]out_timbres;wire[31:0]out_config;
 final_recorder #(.VOICE_COUNT(12),.EVENT_CAPACITY(40)) dut(.clk(clk),.rst(rst),.sample_tick(sample_tick),
  .record_toggle(record_toggle),.replay_toggle(replay_toggle),.clear(1'b0),.panic(panic),
  .in_gates(gates),.in_triggers(triggers),.in_notes(notes),.in_gains(gains),.in_timbres(timbres),
  .in_ratio(19'd262144),.in_mod_depth(7'd0),.in_synth_config(cfg_word),
  .out_gates(out_gates),.out_triggers(),.out_notes(out_notes),.out_gains(out_gains),.out_timbres(out_timbres),
  .out_ratio(),.out_mod_depth(),.out_synth_config(out_config),.recording(recording),.replaying(replaying),
  .full(full),.time_limit(),.replay_frame_ready(),.count(count),.time_samples(),.export_address(12'd0),
  .export_word(),.export_ready(ready),.take_id(),.duration_samples(duration),.observer_gains(),
  .preview_rst(1'b0),.preview_gates('0),.preview_notes('0),.preview_gains('0),.preview_timbres('0),
  .preview_ratio('0),.preview_mod_depth('0),.preview_synth_config('0));
 integer checks=0,i,j;reg[95:0]word;
 task check(input bit yes,input string why);begin checks++;if(!yes)$fatal(1,"POLY12_REC_FAIL %s count=%0d",why,count);end endtask
 task frame;begin @(posedge sample_tick);repeat(32)@(negedge clk);end endtask
 task command(input bit play);begin @(negedge clk);if(play)replay_toggle=1;else record_toggle=1;@(negedge clk);record_toggle=0;replay_toggle=0;end endtask
 task reset;begin @(negedge clk);rst=1;repeat(3)@(negedge clk);rst=0;end endtask
 initial begin
  for(i=0;i<12;i++)begin notes[i*7+:7]=48+i;gains[i*12+:12]=1000+i;timbres[i*3+:3]=i%5;end
  reset();command(0);frame();check(recording&&count==13,"whole12-note initial frame and configuration admitted");
  for(i=0;i<12;i++)begin word=dut.event_ram[i];check(!word[63]&&word[62:57]==i,"all12 encoded voice indices");check(word[35:33]==i%5,"all5 timbre IDs survive event RAM");end
  check(dut.event_ram[12][63],"configuration has separate marker");
  frame();command(0);frame();check(!recording&&ready,"stop publishes take");
  command(1);frame();wait(dut.replay_frame_ready);@(negedge clk);check(replaying,"playback starts");
  check(out_gates==12'hfff&&out_notes==notes&&out_gains==gains&&out_timbres==timbres&&out_config==cfg_word,"all12 replay payloads and envelope configuration match");
  @(negedge clk);panic=1;frame();panic=0;check(!replaying&&out_gates==0&&out_gains==0,"panic stops replay frame");
  reset();command(0);frame();
  for(j=0;j<2;j++)begin for(i=0;i<12;i++)notes[i*7+:7]=60+j+i;frame();end
  check(count==37&&recording,"three whole twelve-note frames fit40 entries");
  for(i=0;i<12;i++)notes[i*7+:7]=80+i;cfg_word=32'haa00;frame();
  check(full&&!recording&&count==37,"overflow rejects entire12-note/cfg_word frame without truncation");
  $display("POLY12_RECORDER_PASS checks=%0d",checks);$finish;
 end
 initial begin #1000000;$fatal(1,"POLY12_REC_TIMEOUT");end
endmodule
