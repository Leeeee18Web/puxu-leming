`timescale 1ns/1ps
module tb_final_wifi;
 reg clk=0,rstn=0,rx=1;always #10 clk=~clk;
 tri dp,dm;wire tx;
 hub_play_top dut(.clk(clk),.rstn(rstn),.key1_n(1'b1),.key2_n(1'b1),.uart_rx(rx),.uart_tx(tx),
  .usb_dp(dp),.usb_dm(dm),.hp_bck(),.hp_ws(),.hp_din(),.i2s_bck(),.i2s_ws(),.i2s_sd(),
  .pa_en(),.led_o(),.tmds_clk_p_0(),.tmds_clk_n_0(),.tmds_d_p_0(),.tmds_d_n_0());
 defparam dut.status_bridge.PERIOD=10;
 defparam dut.wifi_control.WATCHDOG_MS=5;
 integer checks=0,replies=0,ti=0,pcm_nz=0,host_fd,host_bytes=0;
 reg[7:0]host_byte;
 integer rec_fd,rec_i,rec_half,physical_on=0,touch_on=0;reg[31:0]take_id,saved_duration;reg[12:0]saved_count;reg[95:0]rec_word;
 initial host_fd=$fopen("final_uart_reply.hex","w");
 always begin
  @(negedge tx);repeat(651)@(negedge clk);
  for(integer h=0;h<8;h++)begin host_byte[h]=tx;repeat(434)@(negedge clk);end
  check(tx,"original UART stop bit");$fdisplay(host_fd,"%02x",host_byte);host_bytes++;
 end
 reg[7:0]reply[0:21];reg[7:0]last_result;reg[15:0]last_seq,reply_crc=16'hffff;
 task check(input bit ok,input string label_text);begin checks++;if(!ok)$fatal(1,"FINAL_WIFI_FAIL %s",label_text);end endtask
 task clocks(input integer count);begin repeat(count)@(negedge clk);end endtask
 task frames(input integer count);integer j;begin for(j=0;j<count;j++)begin @(posedge dut.sample_tick);@(negedge clk);end end endtask
 function automatic[15:0]crc(input[15:0]c,input[7:0]b);reg[15:0]v;integer j;
 begin v=c^{b,8'd0};for(j=0;j<8;j++)v=v[15]?(v<<1)^16'h1021:v<<1;crc=v;end endfunction
 function automatic[15:0]score_crc(input[15:0]start,input[31:0]tick,input[31:0]word);reg[15:0]v;integer j;
  begin v=start;for(j=0;j<4;j++)v=crc(v,tick>>(8*j));for(j=0;j<4;j++)v=crc(v,word>>(8*j));score_crc=v;end endfunction
 always @(posedge clk)if(!dut.rst&&dut.sample_tick)begin
  check(!dut.audio_deadline_error,"audio deadline maintained with mobile ingress");
  if(dut.pcm!=0)pcm_nz++;
 end
 always @(posedge clk)if(dut.touch_update&&dut.touch_status[24])
  $display("TOUCH page=%0d xy=%h hit=%0d head=%0d tab=%0d",dut.page,dut.touch_xy,dut.touch_controls.rec_hit,dut.touch_controls.head,dut.touch_controls.tab);
 always @(posedge clk)if(dut.replay_toggle)$display("REPLAY_PULSE");
 always @(posedge dut.usb_clk)if(dut.soc.wifi_tx_valid&&dut.soc.wifi_tx_ready)begin
  reply[ti]=dut.soc.wifi_tx_data;
  if(ti>=2&&ti<=19)reply_crc=crc(reply_crc,dut.soc.wifi_tx_data);
  if(ti==21)begin
   check(reply[0]=="P"&&reply[1]=="W"&&reply[2]==1,"PW1 response across both CDCs");
   check({reply[21],reply[20]}==reply_crc,"real wire reply CRC");
   check({reply[19],reply[18],reply[17],reply[16]}==32'h50385731,"original ESP identity unchanged");
   last_seq={reply[5],reply[4]};last_result=reply[8];replies++;ti=0;reply_crc=16'hffff;
  end else ti++;
 end
 task command(input[7:0]op,input[15:0]seq,input[31:0]a,b,c,input[7:0]expected);
 reg[7:0]p[0:21];reg[15:0]v;integer j,target,timeout;begin
  p[0]="P";p[1]="W";p[2]=1;p[3]=op;p[4]=seq[7:0];p[5]=seq[15:8];p[6]=8'h34;p[7]=8'h12;
  for(j=0;j<4;j++)begin p[8+j]=a>>(8*j);p[12+j]=b>>(8*j);p[16+j]=c>>(8*j);end
  v=16'hffff;for(j=2;j<20;j++)v=crc(v,p[j]);p[20]=v[7:0];p[21]=v[15:8];
  target=replies+1;for(j=0;j<22;j++)dut.soc.wifi_byte(p[j]);
  timeout=0;while(replies<target&&timeout<20000)begin @(negedge clk);timeout++;end
  check(replies==target&&last_seq==seq,"command gets real matched FPGA ACK");
  if(last_result!=expected)$display("ACK op=%0d result=%0d expected=%0d",op,last_result,expected);
  check(last_result==expected,"expected result from production PW1");clocks(100);
 end endtask
 task tap(input integer x,y);begin
  dut.soc.hid_report(x,y,0,1);clocks(50);dut.soc.hid_report(x,y,1,1);clocks(50);dut.soc.hid_report(x,y,0,1);clocks(50);
 end endtask
 task eventword(input[31:0]word);begin dut.soc.midi_event(word);clocks(150);end endtask
 task serial_byte(input[7:0]b);integer j;begin
  @(negedge clk);rx=0;clocks(434);
  for(j=0;j<8;j++)begin rx=b[j];clocks(434);end
  rx=1;clocks(434);
 end endtask
 task host_hello;reg[7:0]p[0:17];reg[15:0]v;integer j;begin
  p[0]="G";p[1]="S";p[2]=2;p[3]=8'h26;p[4]=1;p[5]=0;p[6]=8;p[7]=0;
  p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]="P";p[13]="8";p[14]="G";p[15]="1";
  v=16'hffff;for(j=2;j<16;j++)v=crc(v,p[j]);p[16]=v[7:0];p[17]=v[15:8];
  for(j=0;j<18;j++)serial_byte(p[j]);
 end endtask
 function automatic integer mobile_count;integer j;begin mobile_count=0;
  for(j=0;j<7;j++)if(dut.live_gates[j]&&dut.voices.owners[j]==3&&dut.voices.channels[j]==14)mobile_count++;
 end endfunction
 function automatic integer physical_count;integer j;begin physical_count=0;
  for(j=0;j<7;j++)if(dut.live_gates[j]&&dut.voices.owners[j]==1)physical_count++;
 end endfunction
 initial begin
  clocks(10);rstn=1;clocks(1000);dut.soc.ptest_debug[255:224]=32'h2c;clocks(150);
  tap(300,280);tap(650,96);check(dut.mode==1,"Final performance mode retained");
  command(0,1,32'h50385731,0,0,0);
  check({reply[15],reply[14]}==16'h5305,"score-capable actual top version");
  // A downloaded song uses the existing PW1 score transaction and seven-voice allocator.
  command(4,2,2,0,0,0);
  command(5,3,0,0,32'h0001643c,0);
  command(5,4,1,100,32'h0000003c,0);
  command(6,5,score_crc(score_crc(16'hffff,0,32'h0001643c),100,32'h0000003c),0,0,0);
  command(7,6,0,0,0,0);frames(10);
  check(dut.wifi_score_playing&&dut.voices.channels[0]==13,"downloaded score starts on Final audio path");
  frames(150);check(!dut.wifi_score_playing,"downloaded score finishes locally");
  command(8,7,0,0,0,0);
  eventword(32'h00643c90);
  command(1,8,32'h11,32'h3c64,0,0);frames(150);
  check(mobile_count()==2&&physical_count()==1,"same-pitch mobile and USB ownership separated");
  $display("GRAND_DIAG pcm_nz=%0d live=%h active=%h tones=%h gains=%h physical_samples=%h",pcm_nz,dut.live_gates,dut.active,dut.audio_timbres,dut.audio_gains,dut.audio.phys_samples);
  check(pcm_nz>10,"mobile controls reach Final real audio synthesis");
  command(1,9,1,32'h3c64,0,0);check(mobile_count()==1&&physical_count()==1,"partial release preserves physical same pitch");
  dut.soc.ptest_debug[255:224]=32'h0c;clocks(500);
  check(mobile_count()==0&&physical_count()==1,"ESP disconnect clears mobile immediately without global panic");
  dut.soc.ptest_debug[255:224]=32'h2c;clocks(150);
  command(0,10,32'h50385731,0,0,0);command(1,11,1,32'h3c64,0,0);
  check(mobile_count()==1&&physical_count()==1,"reconnect works with original identity and protocol");
  clocks(260000);check(mobile_count()==0&&physical_count()==1,"independent mobile lease preserves USB");
  eventword(32'h00003c80);frames(5);
  command(1,12,32'h7f,32'h3c64,0,0);frames(2);
  check($countones(dut.live_gates)==7&&$bits(dut.gates)==7,"all seven mask keys have independent slots in seven-voice path");
  command(2,13,0,0,0,0);check(mobile_count()==0,"explicit phone release clears all its slots");
  tap(100,195);frames(2);check(dut.recording,"Final record start retained");
  command(1,14,1,32'h3c64,0,0);frames(3);command(2,15,0,0,0,0);frames(3);
  $display("RECORD_BEFORE page=%0d mode=%0d rec=%0d count=%0d gates=%h time=%0d",dut.page,dut.mode,dut.recording,dut.record_count,dut.gates,dut.record_samples);
  tap(280,195);frames(3);
  $display("RECORD_AFTER page=%0d rec=%0d replay=%0d count=%0d",dut.page,dut.recording,dut.replaying,dut.record_count);
  check(dut.replaying&&dut.record_count>=2,"phone controls captured by existing Final recorder");
  command(1,16,1,32'h3c64,0,3);frames(20);
  tap(600,32);frames(2);check(!dut.replaying&&!dut.recording,"Final global Stop still controls playback");
  // Actual physical keyboard and touch MIDI enter the shared recorder, then return via PW1.
  command(13,19,1,0,0,0);frames(2);check(dut.recording,"remote explicit record starts on actual top");
  eventword(32'h00643c90);frames(10);
  dut.soc.hid_report(64,500,1,1);clocks(150);frames(10);
  check($countones(dut.live_gates)==2,"physical and touchscreen same pitch coexist while recording");
  eventword(32'h00003c80);frames(10);dut.soc.hid_report(64,500,0,1);clocks(150);frames(10);
  command(13,20,2,0,0,0);check(!dut.recording&&dut.record_export_ready,"remote stop drains actual recorder");
  saved_count=dut.record_count;saved_duration=dut.record_duration;take_id=dut.record_take_id;
  command(14,21,0,0,0,0);check({reply[15],reply[14],reply[13],reply[12]}==saved_duration,"actual duration reported");
  rec_fd=$fopen("record_words.hex","w");
  for(rec_i=0;rec_i<saved_count;rec_i++)begin
   for(rec_half=0;rec_half<2;rec_half++)begin
    command(15,22+2*rec_i+rec_half,rec_i,rec_half,take_id,0);
    check(reply[15]==8'he0+rec_half,"actual half marker");
    rec_word[48*rec_half+:48]={reply[14],reply[13],reply[12],reply[11],reply[10],reply[9]};
   end
   check(rec_word==dut.recorder.event_ram[rec_i],"actual recorder RAM equals returned protocol bytes");
   if(!rec_word[63]&&rec_word[56]&&rec_word[54:48]==60)begin
    if(rec_word[62:57]==0)physical_on++;else touch_on++;
   end
   $fdisplay(rec_fd,"%024x",rec_word);
  end
  $fclose(rec_fd);rec_fd=$fopen("record_meta.txt","w");$fdisplay(rec_fd,"%0d %0d %0d",saved_count,saved_duration,take_id);$fclose(rec_fd);
  check(physical_on>=1&&touch_on>=1,"both keyboard and touch note-ons exported without collapsing unison");
  check(host_bytes==0&&tx,"WiFi never emits unsolicited ASCII on original PC UART");
  command(1,200,1,32'h3c64,0,0);host_hello;
  command(3,201,0,0,0,0);clocks(170000);
  check(host_bytes>20&&mobile_count()==1,"original GS2 reply and WiFi keepalive coexist");
  $fclose(host_fd);
  $display("FINAL_WIFI_PASS checks=%0d replies=%0d pcm=%0d uart_bytes=%0d",checks,replies,pcm_nz,host_bytes);$finish;
 end
 initial begin #60000000;$fatal(1,"FINAL_WIFI_FAIL timeout");end
endmodule
