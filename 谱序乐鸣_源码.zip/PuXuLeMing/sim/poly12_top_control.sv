`timescale 1ns/1ps
module tb_poly12_top_control;
 reg clk=0;always #10 clk=~clk;
 reg rst=1,event_valid=0,panic=0,pedal=0,map_apply=0,map_enabled=1;
 reg[31:0]event_data=0;reg[1:0]event_source=1;reg[174:0]map_notes=0;
 reg[2:0]tone=4;reg[11:0]tails=0;
 wire[11:0]gates,triggers;wire[83:0]notes;wire[143:0]gains;wire[35:0]timbres;
 wire ready,key_seen;wire[4:0]key_index;
 final_voice_control #(.VOICE_COUNT(12),.ENABLE_PEDAL(1)) dut(
  .clk(clk),.rst(rst),.sample_tick(1'b0),.event_valid(event_valid),.event_data(event_data),
  .event_source(event_source),.event_ready(ready),.panic(panic),.centre(1'b0),.pedal_down(pedal),
  .timbre_select(tone),.voice_active(gates|tails),.timbres(timbres),.gates(gates),.notes(notes),
  .gains(gains),.triggers(triggers),.ratio(),.knob(),.last_note(),.last_velocity(),.mod_depth(),
  .knob_mode(2'd1),.raw_knob(),.raw_known(),.pickup_wait(),.map_notes(map_notes),
  .map_input_base(7'd60),.map_enabled(map_enabled),.map_apply(map_apply),
  .key_seen_valid(key_seen),.key_seen_index(key_index),.ready_raw());
 integer checks=0,i,j;
 task check(input bit yes,input string why);begin checks++;if(!yes)$fatal(1,"POLY12_CONTROL_FAIL %s gates=%h",why,gates);end endtask
 task send(input[1:0]src,input[7:0]st,a,b,input[6:0]idx=0);begin
  @(negedge clk);event_source=src;event_data={idx,1'b1,b,a,st};event_valid=1;
  @(posedge clk);while(!ready)@(posedge clk);@(negedge clk);event_valid=0;
 end endtask
 task reset;begin @(negedge clk);rst=1;repeat(3)@(negedge clk);rst=0;tails=0;pedal=0;end endtask
 initial begin
  for(i=0;i<25;i++)map_notes[i*7+:7]=60+i;
  reset();
  for(i=0;i<12;i++)begin
   send(1,8'h90,60+i,100);
   check(key_seen&&key_index==i,"all physical keys report original map index");
   check(timbres[i*3+:3]==4,"fifth custom piano retained on each of12 slots");
  end
  check(gates==12'hfff,"all12 voices independently held");
  send(1,8'h90,100,100);check(gates==12'hfff&&notes[6:0]==60,"13th finger-held note cannot steal held note");
  for(i=0;i<12;i++)begin send(1,8'h80,60+i,0);check($countones(gates)==11-i,"all12 release independently");end
  reset();for(i=0;i<12;i++)send(i%4,8'h90|(i%3),60+i,100);
  for(j=0;j<4;j++)begin send(j,8'hff,0,0);check($countones(gates)==9-j*3,"source-specific disconnect covers12");end
  reset();send(1,8'hb0,64,127);for(i=0;i<12;i++)send(1,8'h90,60+i,100);
  for(i=0;i<12;i++)send(1,8'h80,60+i,0);
  check(gates==12'hfff,"CC64 holds all12");send(0,8'hb0,64,0);check(gates==12'hfff,"unrelated source cannot release pedal");
  send(1,8'hb0,64,0);check(gates==0,"own CC64 releases all12");
  reset();pedal=1;for(i=0;i<12;i++)send(1,8'h90,60+i,100);
  for(i=0;i<12;i++)send(1,8'h80,60+i,0);check(gates==12'hfff,"KEY1 holds all12");
  @(negedge clk);pedal=0;repeat(2)@(negedge clk);check(gates==0,"KEY1 release covers12");
  reset();for(i=0;i<12;i++)send(1,8'h90,60+i,100);
  tails=gates;send(1,8'h80,60,0);send(1,8'h90,100,100);
  check(gates==12'hfff&&notes[6:0]==100,"released tail yields to replacement");
  send(1,8'h80,60,0);check(gates==12'hfff,"old note-off cannot stop replacement");
  @(negedge clk);map_apply=1;@(negedge clk);map_apply=0;
  check(gates==0&&gains==0,"atomic map apply stops all12");
  reset();map_notes[6:0]=72;map_notes[13:7]=72;
  send(1,8'h90,60,100);send(1,8'h90,61,100);check($countones(gates)==2,"duplicate map pitches retain independent identity");
  send(1,8'h80,60,0);check(gates==2,"first mapped off cannot release second");
  panic=1;@(negedge clk);panic=0;check(gates==0&&gains==0,"panic hard-mutes all12");
  $display("POLY12_CONTROL_PASS checks=%0d",checks);$finish;
 end
 initial begin #200000;$fatal(1,"POLY12_CONTROL_TIMEOUT");end
endmodule
