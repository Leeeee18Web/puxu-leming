`timescale 1ns/1ps
module tb_poly_voice_worker;
 reg clk=0;always #10 clk=~clk;reg rst=1,start=0;reg[6:0]gates=0,triggers=0;reg[167:0]steps=0;reg[83:0]gains=0;reg[20:0]tones=0;
 wire[111:0]samples,envelopes;wire[6:0]active;wire busy,err,ov;wire[2:0]oi;wire signed[15:0]os;
 poly_voice_worker #(.CONTEXTS(7)) dut(clk,rst,start,gates,triggers,steps,gains,tones,samples,envelopes,active,busy,err,ov,oi,os,{3{rst}},1'b0,1'b1);
 wire[15:0]gs[0:6],ge[0:6];wire[6:0]ga,gerr,gb;
 genvar k;generate for(k=0;k<7;k=k+1)begin:private_voice
  poly_voice_worker #(.CONTEXTS(1)) refw(.clk(clk),.rst(rst),.start(start),.model_reset({3{rst}}),.gates(gates[k]),.triggers(triggers[k]),.steps(steps[k*24+:24]),.gains(gains[k*12+:12]),.timbres(tones[k*3+:3]),.samples(gs[k]),.envelopes(ge[k]),.active(ga[k]),.busy(gb[k]),.deadline_error(gerr[k]),.out_valid(),.out_index(),.out_sample(),.control_resetn_early(1'b1));
 end endgenerate
 integer f,c,i,count=0,checks=0;reg[6:0]heard=0;
 always @(negedge clk)if(!rst&&ov)count=count+1;
 initial begin repeat(5)@(negedge clk);rst=0;
 for(f=0;f<3000;f=f+1)begin
  count=0;gates=f<2600?7'h7f:0;triggers=(f==0||f==1800)?7'h7f:0;
  for(i=0;i<7;i=i+1)begin steps[i*24+:24]=24'd45000+i*12000+(f%7);gains[i*12+:12]=1000+i*300;tones[i*3+:3]=f<1800?i%4:(i+1)%4;end
  for(c=0;c<1024;c=c+1)begin
   start=c==32;@(negedge clk);
   if(c==1008)begin
    if(count!=7||busy||err||(|gerr))$fatal(1,"WORKER_SCHEDULE_FAIL frame%0d count%0d busy%b err%b refs%b",f,count,busy,err,gerr);
    for(i=0;i<7;i=i+1)begin
     if(samples[i*16+:16]!==gs[i]||envelopes[i*16+:16]!==ge[i]||active[i]!==ga[i])$fatal(1,"WORKER_ISOLATION_FAIL frame%0d row%0d s=%0d/%0d",f,i,$signed(samples[i*16+:16]),$signed(gs[i]));
     if($signed(samples[i*16+:16])!=0)heard[i]=1;checks=checks+1;
    end
   end
  end
 end
 if(heard!==7'h7f)$fatal(1,"WORKER_SILENT_VOICES %b",heard);
 $display("POLY_VOICE_WORKER_PASS frames3000 checks=%0d all4timbres/7contexts/25future schedule/timbre switch/release",checks);$finish;
 end
 initial begin #100000000;$fatal(1,"WORKER_TIMEOUT");end
endmodule
