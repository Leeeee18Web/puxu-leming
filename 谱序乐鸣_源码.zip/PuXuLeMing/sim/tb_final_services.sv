`timescale 1ns/1ps
module tb_final_services;
 reg clk=0,usb_clk=0,rst=1,usb_rstn=0,usb_running=0;
 always #10 clk=~clk;
 always #11 usb_clk=~usb_clk;
 reg[31:0]diag=0;
 wire piano_ready,touch_ready,esp_ready;
 final_status_bridge #(.PERIOD(5)) status_dut(.clk(clk),.rst(rst),.usb_clk(usb_clk),.usb_rstn(usb_rstn),
  .usb_running(usb_running),.diagnostic(diag),.piano_ready(piano_ready),.touch_ready(touch_ready),.esp_ready(esp_ready),.status_pattern_raw());
 reg[3:0]gates=0,active=0;
 reg[27:0]notes=0;reg[47:0]gains=0;reg[95:0]steps=0;reg[63:0]envelopes=0;
 wire[6:0]home_gates;wire[83:0]home_gains;
 final_voice_display display_dut(.clk(clk),.rst(rst),.gates(gates),.gains(gains),.home_gates(home_gates),.home_gains(home_gains));
 wire[6:0]leading_note;wire[10:0]leading_pitch;wire[23:0]leading_step;wire[15:0]leading_envelope;wire leading_valid;
 final_leading_voice leading_dut(.clk(clk),.rst(rst),.active(active),.notes(notes),.gains(gains),.steps(steps),.envelopes(envelopes),
  .leading_note(leading_note),.leading_pitch(leading_pitch),.leading_step(leading_step),.leading_envelope(leading_envelope),.leading_valid(leading_valid));
 reg[1:0]mode=1;reg[6:0]target=127;reg done=0;
 wire[7:0]led;
 final_guide_led led_dut(.mode(mode),.target_note(target),.done(done),.activity(home_gates),.usb_ready(piano_ready||touch_ready),.led_o(led));
 integer checks=0;
 task check(input logic value,input string label_text);begin checks++;if(!value)$fatal(1,"FAIL %s",label_text);end endtask
 task settle;begin repeat(100)@(posedge clk);#1;end endtask
 initial begin
  settle();check(!piano_ready&&!touch_ready,"reset means disconnected");
  rst=0;usb_rstn=1;usb_running=1;diag=32'h2c;settle();
  check(piano_ready&&touch_ready&&esp_ready,"independent configured devices ready without touch/key activity");
  diag=32'h14;settle();check(!piano_ready&&touch_ready&&!esp_ready,"MIDI disconnect leaves touch ready despite historical error");
  diag=32'h18;settle();check(piano_ready&&!touch_ready,"touch disconnect leaves MIDI ready");
  usb_running=0;#1;check(!piano_ready&&!touch_ready,"root clock/reset loss gates stale snapshot");
  usb_running=1;diag=32'h0c;settle();
  gates[3]=1;active[3]=1;notes[3*7+:7]=96;gains[3*12+:12]=3000;
  steps[3*24+:24]=24'd359564;envelopes[3*16+:16]=12345;settle();
  check(home_gates==7'b0001000&&home_gains[83:48]==0&&home_gains[3*12+:12]==3000,"voice3 included in seven-bar overview");
  check(leading_valid&&leading_note==96&&leading_step==359564&&leading_envelope==12345,"leading monitor includes voice3 actual synthesis state");
  gates[0]=1;active[0]=1;notes[0+:7]=60;gains[0+:12]=1000;steps[0+:24]=89891;envelopes[0+:16]=20000;settle();
  check(leading_valid&&leading_note==60&&leading_step==89891,"priority monitor switches coherently to first usable slot");
  mode=3;target=60;#1;check(led[6:0]==7'b1111110,"follow target C drives first active-low LED");
  target=67;#1;check(led[6:0]==7'b1101111,"follow target G uses same lesson note mapping");
  done=1;#1;check(led[6:0]==7'b1111111,"completed lesson clears target LED");
  mode=1;#1;check(led[6:0]==~home_gates,"normal mode retains activity indication");
  $display("PASS final services checks=%0d",checks);$finish;
 end
 initial begin #1000000;$fatal(1,"FAIL timeout");end
endmodule
