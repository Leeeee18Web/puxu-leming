`timescale 1ns/1ps
module history_pipeline_boundary_case #(parameter ORIGINAL=0)(output reg done=0);
 reg clk=0,pixel_clk=0,rst=1,pixel_rstn=0;always #10 clk=~clk;always #9.756 pixel_clk=~pixel_clk;
 reg[9:0]read_addr=100;wire read_enable=1'b1,sample_tick=1'b1;wire[9:0]column;
 wire recording=column<768;wire[10:0]pitch_data;wire[9:0]visible_count;wire[16:0]curve_sum;
 reg[5:0]pixels=0;always @(posedge pixel_clk)pixels<=pixels+1'b1;wire frame_start=pixels==0;
 wire[55:0]indices;
 generate if(ORIGINAL)begin:old
  tone_history_before_pixel_pipeline #(.TOTAL_SAMPLES(768),.READ_GATED(1)) dut(.clk(clk),.rst(rst),.restart(1'b0),.sample_tick(sample_tick),.recording(recording),.pitch(11'd960),.pitch_valid(1'b1),.pixel_clk(pixel_clk),.pixel_rstn(pixel_rstn),.frame_start(frame_start),.read_addr(read_addr),.read_enable(read_enable),.pitch_data(pitch_data),.visible_count(visible_count),.curve_sum(curve_sum));
  assign column=dut.column;
  for(genvar g=0;g<7;g++)assign indices[g*8+:8]=dut.read_index[g];
 end else begin:current
  tone_history #(.TOTAL_SAMPLES(768),.READ_GATED(1),.PIPELINED_READ(1)) dut(.clk(clk),.rst(rst),.restart(1'b0),.sample_tick(sample_tick),.recording(recording),.pitch(11'd960),.pitch_valid(1'b1),.pixel_clk(pixel_clk),.pixel_rstn(pixel_rstn),.frame_start(frame_start),.read_addr(read_addr),.read_enable(read_enable),.pitch_data(pitch_data),.visible_count(visible_count),.curve_sum(curve_sum));
  assign column=dut.column;
  for(genvar g=0;g<7;g++)assign indices[g*8+:8]=dut.read_index[g];
 end endgenerate
 reg[55:0]held;
 initial begin
  repeat(5)@(negedge clk);rst=0;pixel_rstn=1;wait(visible_count==768);
  @(negedge pixel_clk);read_addr=100;@(posedge pixel_clk);#1;held=indices;
  #2;read_addr=700;#1;if(indices!==held)$fatal(1,"HISTORY_REGISTERED_ADDRESS_BOUNDARY_MISSING");
  $display("HISTORY_PIPELINE_BOUNDARY_PASS registered decode to RAM, no between-edge address cone");done=1;
 end
 initial begin #200000;$fatal(1,"HISTORY_PIPELINE_BOUNDARY_TIMEOUT");end
endmodule
module tb_history_pipeline_boundary;wire done;history_pipeline_boundary_case t(done);initial begin wait(done);$finish;end endmodule
module tb_history_pipeline_boundary_old;wire done;history_pipeline_boundary_case #(.ORIGINAL(1)) t(done);initial begin wait(done);$finish;end endmodule
