`timescale 1ns/1ps
module tb_gesture_stop;
 reg clk=0,rst=1,rx=1,ready=0,playable=1;always #10 clk=~clk;
 wire tx,valid;wire[31:0]data;
 // stop_request is checked after the RED phase adds this backwards-compatible port.
 p8_gesture_link #(.CLOCK_HZ(100000),.UART_DIV(8),.WATCHDOG_MS(1000)) dut(
  .clk(clk),.rst(rst),.rx(rx),.tx(tx),.event_valid(valid),.event_data(data),.event_ready(ready),
  .clear_notes(1'b0),.playable(playable),.muted(1'b0),.mode(2'd1),.pattern_mode(2'd0),.page(3'd0),.gates(7'd0),.last_note(7'd0));
 function automatic[15:0]crcbyte(input[15:0]c,input[7:0]b);
  reg[15:0]v;integer k;begin v=c^{b,8'd0};for(k=0;k<8;k=k+1)v=v[15]?(v<<1)^16'h1021:v<<1;crcbyte=v;end
 endfunction
 task byteout(input[7:0]b);integer j;begin
  @(negedge clk);rx=0;repeat(8)@(negedge clk);
  for(j=0;j<8;j=j+1)begin rx=b[j];repeat(8)@(negedge clk);end
  rx=1;repeat(8)@(negedge clk);
 end endtask
 task packet(input[15:0]seq,input[7:0]op,note,vel,input bit bad);
  reg[7:0]b[0:15];reg[15:0]crc;integer j;begin
   b[0]="G";b[1]="S";b[2]=2;b[3]=8'h26;b[4]=seq[7:0];b[5]=seq[15:8];b[6]=8;b[7]=0;
   b[8]=op;b[9]=note;b[10]=vel;b[11]=0;b[12]="P";b[13]="8";b[14]="G";b[15]="1";
   crc=16'hffff;for(j=2;j<16;j=j+1)crc=crcbyte(crc,b[j]);
   for(j=0;j<16;j=j+1)byteout(b[j]);byteout(crc[7:0]);byteout(crc[15:8]^{7'd0,bad});repeat(40)@(negedge clk);
  end
 endtask
 integer checks=0,stops=0;
 always @(posedge clk)if(!rst&&dut.stop_request)stops++;
 task check(input bit ok,input string why);begin checks++;if(!ok)$fatal(1,"GESTURE_STOP_FAIL %s",why);end endtask
 initial begin
  repeat(10)@(negedge clk);rst=0;
  packet(1,1,6,100,0);check(valid&&data[7:0]==8'h9f&&data[14:8]==69,"legacy GS2 note preserved");
  // Stop must work even while the existing two-event queue is backpressured.
  playable=0;packet(2,2,0,0,0);
  check(dut.reply_result==0,"new emergency stop accepted in blocked mode and queue backpressure");
  check(!valid&&dut.held_note==0,"stop flushes queued/held gesture even without event_ready");
  check(stops==1,"stop pulses once");packet(2,2,0,0,0);check(stops==1,"duplicate ACK does not repeat stop");
  packet(3,2,1,0,0);check(dut.reply_result==1,"malformed stop rejected");
  ready=1;playable=1;packet(4,1,2,100,0);check(dut.held_note==2,"legacy note resumes after stop");
  packet(5,2,0,0,1);check(dut.held_note==2,"bad CRC cannot stop or mutate state");
  $display("GESTURE_STOP_PASS checks=%0d legacy/blocked/backpressure/invalid/CRC",checks);$finish;
 end
 initial begin #2000000;$fatal(1,"GESTURE_STOP_TIMEOUT");end
endmodule
