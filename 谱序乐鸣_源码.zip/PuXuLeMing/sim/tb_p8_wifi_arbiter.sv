`timescale 1ns/1ps
module tb_p8_wifi_arbiter;
 reg clk=0,rst=1,flush=0;always #5 clk=~clk;
 reg[31:0]touch_data=1,usb_data=2,gesture_data=3,wifi_data=4;
 reg touch_valid=0,usb_valid=0,gesture_valid=0,wifi_valid=0,ready=0;
 wire[1:0]source_tag;wire touch_ready,usb_ready,gesture_ready,wifi_ready,valid;wire[31:0]data;
 p8_wifi_arbiter dut(.*,.raw_valid());
 integer checks=0,accepts=0,outputs=0;reg[31:0]expected[0:31];reg[1:0]expected_source[0:31];
 task check(input bit ok,input string msg);begin checks++;if(!ok)$fatal(1,"ARBITER_FAIL %s",msg);end endtask
 always @(posedge clk)if(!rst)begin
  if(touch_valid&&touch_ready)begin expected[accepts]=touch_data;expected_source[accepts]=0;accepts++;end
  if(usb_valid&&usb_ready)begin expected[accepts]=usb_data;expected_source[accepts]=1;accepts++;end
  if(gesture_valid&&gesture_ready)begin expected[accepts]=gesture_data;expected_source[accepts]=2;accepts++;end
  if(wifi_valid&&wifi_ready)begin expected[accepts]=wifi_data;expected_source[accepts]=3;accepts++;end
  if(valid&&ready)begin check(outputs<accepts&&data==expected[outputs]&&source_tag==expected_source[outputs],"accepted event order exactly once");outputs++;end
 end
 initial begin
  repeat(3)@(negedge clk);rst=0;
  touch_valid=1;usb_valid=1;gesture_valid=1;wifi_valid=1;
  check(!valid,"no fall-through before capture");
  @(negedge clk);touch_valid=0;
  check(valid&&data==1&&source_tag==0,"touch priority captured into FF");
  repeat(5)begin @(negedge clk);check(valid&&data==1&&source_tag==0&&!usb_ready&&!gesture_ready&&!wifi_ready,"held payload and input backpressure");end
  ready=1;@(negedge clk);check(!valid,"registered non-fall-through slot consumes");
  @(negedge clk);usb_valid=0;
  @(negedge clk);@(negedge clk);gesture_valid=0;
  @(negedge clk);@(negedge clk);wifi_valid=0;
  repeat(3)@(negedge clk);check(outputs==4&&accepts==4,"four priority sources drained");
  ready=0;wifi_valid=1;wifi_data=99;@(negedge clk);wifi_valid=0;
  check(valid&&data==99&&source_tag==3,"pending before flush");
  flush=1;touch_valid=1;touch_data=88;#1;
  check(!valid&&!touch_ready&&!usb_ready&&!gesture_ready&&!wifi_ready,"flush suppresses both consumers and acceptance");
  @(negedge clk);flush=0;touch_valid=0;ready=1;
  repeat(3)@(negedge clk);check(!valid&&outputs==4,"flushed event never consumed");
  $display("P8_WIFI_ARBITER_PASS checks=%0d accepted=%0d delivered=%0d flushed=1",checks,accepts,outputs);$finish;
 end
 initial begin #10000;$fatal(1,"arbiter deadline");end
endmodule
