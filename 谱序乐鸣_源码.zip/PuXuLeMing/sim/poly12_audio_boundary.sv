`timescale 1ns/1ps
module tb_poly12_audio_boundary;
 reg clk=0;always #10 clk=~clk;reg rst=1;
 reg[11:0]gates=0,triggers=0;reg[83:0]notes=0;reg[143:0]gains=0;reg[35:0]tones={12{3'd4}};
 reg[31:0]config_word=0;
 wire tick;wire[11:0]active;wire[191:0]levels;wire error;
 poly25_audio #(.VOICE_COUNT(12),.DISTRIBUTED_RESET(1),.REGIONAL_MODEL_CONTROLS(1)) dut(
  .clk(clk),.rst(rst),.gates(gates),.triggers(triggers),.notes(notes),.gains(gains),.timbres(tones),
  .ratio(19'd262144),.mod_depth(7'd0),.synth_config(config_word),.sample_tick(tick),.pcm(),.pcm_positive(),
  .hp_bck(),.hp_ws(),.hp_din(),.i2s_bck(),.i2s_ws(),.i2s_sd(),.active(active),
  .monitor_steps(),.monitor_envelopes(levels),.deadline_error(error),.clip_active(),.map_apply(1'b0),
  .model_reset({12{rst}}),.control_resetn_early(1'b1));
 wire[191:0]old_levels;wire[35:0]old_phases;wire[11:0]old_active;wire[2:0]old_errors;
 genvar g;generate for(g=0;g<3;g=g+1)begin:old_envelope_service
  final_envelope4_gold old(.clk(clk),.rst(rst),.sample_tick(dut.render_tick),.choices(dut.frame_envelope_choices),
   .gates(dut.frame_gates[g*4+:4]&dut.custom_voice[g*4+:4]),
   .triggers(dut.phys_triggers[g*4+:4]&dut.custom_voice[g*4+:4]),
   .resets(dut.frame_gain_zero[g*4+:4]|~dut.custom_voice[g*4+:4]),
   .levels(old_levels[g*64+:64]),.phases(old_phases[g*12+:12]),.active(old_active[g*4+:4]),.deadline_error(old_errors[g]));
 end endgenerate
 reg[11:0]expected_physical_gates=0;integer gate_checks=0,scaled_checks=0,hidden_gate_changes=0,release_zeros=0;
 reg[11:0]release_seen=0;reg[11:0]prior_active=0;
 function automatic[15:0]scaled(input signed[15:0]sample,input[15:0]level);
  reg signed[32:0]product;
  begin product=sample*$signed({1'b0,level});scaled=level==65535?sample:product[31:16];end
 endfunction
 always @(posedge clk)begin
  if(rst)expected_physical_gates=0;
  else if(tick)begin
   if(error||(|old_errors))$fatal(1,"BOUNDARY_DEADLINE");
   if(dut.custom_active!==old_active||dut.custom_levels!==old_levels)$fatal(1,"BOUNDARY_OLD_ADSR_SAMPLE");
   for(integer v=0;v<12;v=v+1)begin
    if(dut.custom_samples[v*16+:16]!==scaled($signed(dut.phys_samples[v*16+:16]),old_levels[v*16+:16]))$fatal(1,"BOUNDARY_CURRENT_LEVEL_SCALE voice%0d",v);
    if(prior_active[v]&&!old_active[v])begin
     if(dut.custom_samples[v*16+:16]!==0)$fatal(1,"BOUNDARY_RELEASE_ONE_SAMPLE_LATE voice%0d",v);
     release_seen[v]=1;release_zeros=release_zeros+1;
    end
    scaled_checks=scaled_checks+1;
   end
   prior_active=old_active;
   for(integer v=0;v<12;v=v+1)expected_physical_gates[v]=gates[v]||(tones[v*3+:3]==4&&old_active[v]);
  end
  #1;
  if(!rst&&dut.frame_physical_gates!==expected_physical_gates)$fatal(1,"BOUNDARY_GATE_FRAME_SNAPSHOT");
 end
 // The original Envelope4 acoustic gate can drop mid-frame when ADSR becomes
 // Idle. The only differing interval must already have zero custom amplitude.
 always @(negedge clk)if(!rst)begin
  for(integer v=0;v<12;v=v+1)begin
   if(dut.custom_voice[v]&&(dut.frame_gates[v]||old_active[v])!==expected_physical_gates[v])begin
    if(old_levels[v*16+:16]!=0)$fatal(1,"BOUNDARY_AUDIBLE_GATE_DIVERGENCE voice%0d",v);
    hidden_gate_changes=hidden_gate_changes+1;
   end
  end
 end
 genvar w;generate for(w=0;w<2;w=w+1)begin:worker_consumption
  always @(posedge clk)if(!rst&&dut.physical.group[w].worker.running&&dut.physical.group[w].worker.phase==0)begin
   if(dut.physical.group[w].worker.gates[dut.physical.group[w].worker.context_index]!==expected_physical_gates[w*6+dut.physical.group[w].worker.context_index])$fatal(1,"BOUNDARY_WORKER_GATE_OWNER");
   gate_checks=gate_checks+1;
  end
 end endgenerate
 integer f,i;
 initial begin
  for(i=0;i<12;i=i+1)begin notes[i*7+:7]=48+i*2;gains[i*12+:12]=2200;end
  repeat(8)@(negedge clk);rst=0;gates=12'hfff;triggers=12'hfff;
  for(f=0;f<6200;f=f+1)begin
   @(negedge clk);while(!tick)@(negedge clk);triggers=0;
   if(f==100)gates=0;
   if(f==4500)begin gates=12'h555;triggers=12'h555;end
   if(f==4600)begin gates=12'haaa;triggers=12'haaa;end
   if(f==4700)begin tones[0+:3]=0;gains[11*12+:12]=0;end
   if(f==4800)begin tones[0+:3]=4;gates=12'hfff;triggers=12'hfff;gains[11*12+:12]=2200;config_word=32'h00009500;end
   if(f==5000)begin triggers=12'h843;end
  end
  if(release_seen!==12'hfff||gate_checks<6000*12||hidden_gate_changes==0)$fatal(1,"BOUNDARY_COVERAGE release%h gate%0d hidden%0d",release_seen,gate_checks,hidden_gate_changes);
  $display("POLY12_BOUNDARY_PASS gates%0d scales%0d releaseZeros%0d inaudibleIdleGateIntervals%0d oldADSR12/privategate/currentlevel/no-extra-sample",gate_checks,scaled_checks,release_zeros,hidden_gate_changes);$finish;
 end
 initial begin #140000000;$fatal(1,"BOUNDARY_TIMEOUT");end
endmodule
