`timescale 1ns/1ps
module tb_poly25_map_fade;
 reg clk=0;always #10 clk=~clk;reg rst=1,tick=0,apply=0;reg signed[15:0]dry=2000;wire signed[15:0]pcm;wire positive;integer f,c;integer previous;
 poly25_map_fade dut(clk,rst,tick,apply,dry,dry>0,pcm,positive);
 task frame;begin for(c=0;c<1024;c=c+1)begin tick=c==0;@(negedge clk);end tick=0;end endtask
 initial begin
  repeat(4)@(negedge clk);rst=0;repeat(16)@(negedge clk);
  if(pcm!=2000)$fatal(1,"MAP_FADE_BYPASS");
  apply=1;dry=0;@(negedge clk);apply=0;repeat(8)@(negedge clk);
  if(pcm<1900)$fatal(1,"MAP_FADE_MISSING short release must retain old boundary sample");previous=pcm;
  for(f=0;f<64;f=f+1)begin frame;
   if(pcm>previous||pcm<0||pcm>2000)$fatal(1,"MAP_FADE_MONOTONIC");previous=pcm;
   if(f==31&&(pcm<950||pcm>1050))$fatal(1,"MAP_FADE_MIDPOINT %0d",pcm);
  end
  if(pcm!=0)$fatal(1,"MAP_FADE_FINISH");
  dry=-1600;repeat(10)@(negedge clk);apply=1;dry=0;@(negedge clk);apply=0;
  repeat(8)@(negedge clk);if(pcm> -1500||positive)$fatal(1,"MAP_FADE_SIGN");
  for(f=0;f<64;f=f+1)frame;if(pcm!=0)$fatal(1,"MAP_FADE_NEGATIVE_FINISH");
  $display("POLY25_MAP_FADE_PASS exactbypass 64frames/1.31ms monotonic positive/negative release");$finish;
 end
endmodule
