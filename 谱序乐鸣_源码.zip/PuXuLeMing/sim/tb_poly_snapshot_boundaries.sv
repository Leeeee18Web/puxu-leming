`timescale 1ns/1ps
module tb_poly_snapshot_boundary;
 reg clk=0;always #10 clk=~clk;reg rst=1,start=0;
 poly_voice_worker #(.CONTEXTS(1)) dut(.clk(clk),.rst(rst),.start(start),.gates(1'b1),.triggers(1'b1),.steps(24'd31700),.gains(12'd2400),.timbres(3'd3),.samples(),.envelopes(),.active(),.busy(),.deadline_error(),.out_valid(),.out_index(),.out_sample(),.model_reset({3{rst}}),.control_resetn_early(1'b1));
 reg[1716:0]want;
 initial begin
  repeat(3)@(negedge clk);rst=0;start=1;@(negedge clk);start=0;
  wait(dut.running&&dut.phase==2);#1;want=dut.physical_restore;
  // Structural isolation probe only. Legal ring rotation is tested separately.
  force dut.context_data={1777{1'b1}};#1;
  if(dut.physical_restore!==want)$fatal(1,"SNAPSHOT_REGISTER_BOUNDARY_MISSING");
  $display("POLY_SNAPSHOT_BOUNDARY_PASS raw context cannot cross local restore FF midclock");$finish;
 end
 initial begin #100000;$fatal(1,"SNAPSHOT_BOUNDARY_TIMEOUT");end
endmodule
module tb_poly_reed_address_boundary;
 reg clk=0;always #10 clk=~clk;reg rst=1,start=0;
 poly_voice_worker #(.CONTEXTS(1)) dut(.clk(clk),.rst(rst),.start(start),.gates(1'b1),.triggers(1'b1),.steps(24'd31700),.gains(12'd2400),.timbres(3'd3),.samples(),.envelopes(),.active(),.busy(),.deadline_error(),.out_valid(),.out_index(),.out_sample(),.model_reset({3{rst}}),.control_resetn_early(1'b1));
 reg[12:0]want;
 initial begin
  repeat(3)@(negedge clk);rst=0;start=1;@(negedge clk);start=0;
  wait(dut.reed.state==4);#1;want=dut.rra;
  force dut.reed.wp=12'd2049;#1;
  if(dut.rra!==want)$fatal(1,"REED_ADDRESS_REGISTER_BOUNDARY_MISSING");
  $display("POLY_REED_ADDRESS_BOUNDARY_PASS live wp cannot cross read address FF midclock");$finish;
 end
 initial begin #100000;$fatal(1,"REED_ADDRESS_BOUNDARY_TIMEOUT");end
endmodule
