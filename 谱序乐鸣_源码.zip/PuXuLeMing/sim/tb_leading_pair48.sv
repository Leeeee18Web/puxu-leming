`timescale 1ns/1ps
module tb_leading_pair48;
 reg clk=0;always #10 clk=~clk;reg rst=1;
 reg[6:0]active=0;reg[48:0]notes=0;reg[83:0]gains=0;reg[167:0]steps=0;reg[111:0]envelopes=0;
 wire[6:0]n0,n1;wire[10:0]p0,p1;wire[23:0]s0,s1;wire[15:0]e0,e1;wire v0,v1;
 final_leading_voice #(.VOICE_COUNT(7)) dut(.leading_note(n0),.leading_pitch(p0),.leading_step(s0),.leading_envelope(e0),.leading_valid(v0),.*);
 leading_before_pair48 #(.VOICE_COUNT(7)) old(.leading_note(n1),.leading_pitch(p1),.leading_step(s1),.leading_envelope(e1),.leading_valid(v1),.*);
 integer i,j,checks=0,publishes=0,valids=0,empty=0;reg[31:0]rng=32'h1234abcd;
 always @(posedge clk)begin #1;
  if({n0,p0,s0,e0,v0}!=={n1,p1,s1,e1,v1})$fatal(1,"LEADING_PUBLIC_CYCLE_CHANGED check%0d",checks);
  if({dut.state,dut.address,dut.base,dut.bit_index,dut.q}!=={old.state,old.address,old.base,old.bit_index,old.q})$fatal(1,"LEADING_ROM_SCHEDULE_CHANGED");
  // State1 is the original ROM wait. Its new private selection finishes
  // before state2 reads the held payload; publications remain exact.
  if(dut.state!=1&&{dut.held_note,dut.held_step,dut.held_env,dut.held_valid}!=={old.held_note,old.held_step,old.held_env,old.held_valid})$fatal(1,"LEADING_CONSUMED_COHORT_CHANGED");
  checks++;if(!rst&&dut.state==0)begin publishes++;if(v0)valids++;else empty++;end
 end
 initial begin
  for(i=0;i<200000;i++)begin
   @(negedge clk);rng=rng*1664525+1013904223;rst=i<5||i%997<2;active=i%7==0?0:rng[6:0];
   for(j=0;j<7;j++)begin
    rng=rng*1664525+1013904223;notes[j*7+:7]=rng[6:0];steps[j*24+:24]=rng[23:0];
    rng=rng*1664525+1013904223;gains[j*12+:12]=i%11==0?0:rng[11:0];envelopes[j*16+:16]=rng[15:0];
   end
  end
  @(negedge clk);if(publishes<8000||valids<1000||empty<1000)$fatal(1,"LEADING_COVERAGE_MISSING %0d/%0d/%0d",publishes,valids,empty);
  $display("LEADING_PAIR48_EQ_PASS checks%0d publish%0d valid%0d empty%0d randomizedEveryCycle resetAndAllPayloadSamePublicationEdge",checks,publishes,valids,empty);$finish;
 end
endmodule
