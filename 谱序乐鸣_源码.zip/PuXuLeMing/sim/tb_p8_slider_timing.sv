`timescale 1ns/1ps
module p8_geometry_before;
 `include "sim/fixtures/p8_geometry_reference.vh"
endmodule
module p8_geometry_after;
 `include "p8_geometry.vh"
endmodule
module tb_p8_slider_timing;
 p8_geometry_before before_dut();p8_geometry_after after_dut();
 integer x,old_value,new_value,checks=0;
 initial begin
  for(x=-1024;x<66560;x=x+1)begin
   old_value=before_dut.p8_slider_value(x);
   new_value=after_dut.p8_slider_value(x);
   if(old_value!==new_value)$fatal(1,"slider changed x%0d old%0d new%0d",x,old_value,new_value);
   checks=checks+1;
  end
  $display("PASS tb_p8_slider_timing exact_all_16bit_and_outside=%0d",checks);$finish;
 end
endmodule
