`timescale 1ns/1ps
module tb_regional170_root;
 reg clk=0,rstn=0;always #10 clk=~clk;tri dp,dm,odp,odm;
 wire[23:0]pins,opins;
 hub_play_top dut(.clk(clk),.rstn(rstn),.key1_n(1'b1),.key2_n(1'b1),.uart_rx(1'b1),.usb_dp(dp),.usb_dm(dm),
  .uart_tx(pins[0]),.hp_bck(pins[1]),.hp_ws(pins[2]),.hp_din(pins[3]),.pa_en(pins[4]),.i2s_bck(pins[5]),.i2s_ws(pins[6]),.i2s_sd(pins[7]),.led_o(pins[15:8]),
  .tmds_clk_p_0(pins[16]),.tmds_clk_n_0(pins[17]),.tmds_d_p_0(pins[20:18]),.tmds_d_n_0(pins[23:21]));
 hub_before_regional170 old(.clk(clk),.rstn(rstn),.key1_n(1'b1),.key2_n(1'b1),.uart_rx(1'b1),.usb_dp(odp),.usb_dm(odm),
  .uart_tx(opins[0]),.hp_bck(opins[1]),.hp_ws(opins[2]),.hp_din(opins[3]),.pa_en(opins[4]),.i2s_bck(opins[5]),.i2s_ws(opins[6]),.i2s_sd(opins[7]),.led_o(opins[15:8]),
  .tmds_clk_p_0(opins[16]),.tmds_clk_n_0(opins[17]),.tmds_d_p_0(opins[20:18]),.tmds_d_n_0(opins[23:21]));
 defparam dut.status_bridge.PERIOD=10;defparam old.status_bridge.PERIOD=10;
 reg[6:0]probe_depth=0;reg[1:0]probe_level=0;integer depthUi=0,depthMidi=0;
 reg[1:0]mode=1,pattern=0;reg rec=0,rep=0;reg wifi_owner=0;reg[1:0]wifi_mode=0;
 integer checks=0,pcm=0,leading=0,patterns=0,records=0,replays=0,usbdown=0,resets=0,events=0,saveEdges=0,wifiOwnerCycles=0;
 initial begin
  force dut.mode=mode;force old.mode=mode;
  force dut.wifi_pattern_override=wifi_owner;force old.wifi_pattern_override=wifi_owner;
  force dut.wifi_pattern_mode=wifi_mode;force old.wifi_pattern_mode=wifi_mode;
  force dut.touch_pattern_mode=pattern;force old.touch_pattern_mode=pattern;
  force dut.mod_depth=probe_depth;force old.mod_depth=probe_depth;
  force dut.synth_config[5:4]=probe_level;force old.synth_config[5:4]=probe_level;
  force dut.record_toggle=rec;force old.record_toggle=rec;
  force dut.replay_toggle=rep;force old.replay_toggle=rep;
 end
 // Dedicated timing address must equal the original panel request on every pixel.
 always @(posedge dut.pixel_clk)begin #1;
  if(dut.history_addr!==dut.tone_addr)$fatal(1,"HISTORY12_ROOT_ADDRESS_EDGE");
 end
 always @(posedge clk)begin
  #1;checks++;
  if(dut.model_resetn[8]!==dut.audio_reset[2]||dut.model_resetn[9]!==dut.audio_reset[2]||dut.recorder.rst!==dut.rst||dut.audio.rst!==dut.rst)$fatal(1,"REGIONAL170_RESET_EDGE");
  if(!dut.rst&&dut.observer_gains!==dut.gains)$fatal(1,"REGIONAL170_OBSERVER_GAIN_NORMAL");
  if(dut.pattern_usb_up!==dut.usb_region_up[0]||dut.pattern_usb_up!==dut.usb_region_up[1])$fatal(1,"PAT113_LOCAL_USB_FINAL_STAGE");
  if({dut.pattern_local_owner,dut.pattern_local_mode,dut.pattern_local_enabled,dut.pattern_local_select,dut.pattern_local_panic,dut.pattern_local_valid,dut.pattern_local_ready,dut.pattern_local_all_off,dut.pattern_local_disconnect,dut.pattern_local_cancel}!==
     {dut.pattern_owner,dut.pattern_mode,dut.pattern_enabled,dut.pattern_select,dut.panic_all,dut.selected_valid,dut.selected_ready,dut.pattern_all_off,dut.pattern_disconnect,dut.pattern_cancel})$fatal(1,"PAT113_COMPLETE_ROOT_CONTROL_WAVE");
  if(dut.rst!==old.rst||dut.usb_up_sync!==old.usb_up_sync||dut.panic_all!==old.panic_all)$fatal(1,"REGIONAL170_ROOT_CONTROL");
  if(pins[23:0]!==opins[23:0])$fatal(1,"REGIONAL170_ROOT_PINS");
  if({dut.selected_valid,dut.selected_ready,dut.selected_data,dut.selected_source,dut.live_gates,dut.live_notes,dut.live_gains,dut.live_triggers,dut.gates,dut.notes,dut.gains,dut.triggers,dut.active,dut.monitor_steps,dut.monitor_envelopes,dut.sample_tick,dut.pcm}!==
     {old.selected_valid,old.selected_ready,old.selected_data,old.selected_source,old.live_gates,old.live_notes,old.live_gains,old.live_triggers,old.gates,old.notes,old.gains,old.triggers,old.active,old.monitor_steps,old.monitor_envelopes,old.sample_tick,old.pcm})$fatal(1,"REGIONAL170_ROOT_AUDIO");
  if({dut.audio.ui_depth,dut.audio.effective_depth,dut.audio.mod_phase,dut.audio.mod_triangle,dut.audio.mod_depth_product,dut.audio.mod_offset,dut.audio.mod_bend_product,dut.audio.modulated_ratio,dut.audio.frame_ratio,dut.audio.frame_gates,dut.audio.frame_notes,dut.audio.frame_gains,dut.audio.frame_timbres,dut.audio.frame_triggers,dut.audio.pending_triggers,dut.audio.event_steps,dut.audio.index,dut.audio.product,dut.audio.render_wait}!==
     {old.audio.ui_depth,old.audio.effective_depth,old.audio.mod_phase,old.audio.mod_triangle,old.audio.mod_depth_product,old.audio.mod_offset,old.audio.mod_bend_product,old.audio.modulated_ratio,old.audio.frame_ratio,old.audio.frame_gates,old.audio.frame_notes,old.audio.frame_gains,old.audio.frame_timbres,old.audio.frame_triggers,old.audio.pending_triggers,old.audio.event_steps,old.audio.index,old.audio.product,old.audio.render_wait})$fatal(1,"REPAIR72_ROOT_ALL_AUDIO_PIPELINE_SAME_CLOCK");
  if({dut.leading.held_step,dut.leading.held_note,dut.leading.held_env,dut.leading.held_valid,dut.leading_note,dut.leading_pitch,dut.leading_step,dut.leading_envelope,dut.leading_valid}!==
     {old.leading.held_step,old.leading.held_note,old.leading.held_env,old.leading.held_valid,old.leading_note,old.leading_pitch,old.leading_step,old.leading_envelope,old.leading_valid})$fatal(1,"REGIONAL170_LEADING_SAME_CLOCK");
  if({dut.pattern_selected,dut.pattern_notes,dut.pattern_selected_gains,dut.pattern_gates,dut.pattern_gains,dut.pattern_triggers,dut.pattern_busy,dut.pattern_count,dut.pattern_full,dut.patterns.state}!==
     {old.pattern_selected,old.pattern_notes,old.pattern_selected_gains,old.pattern_gates,old.pattern_gains,old.pattern_triggers,old.pattern_busy,old.pattern_count,old.pattern_full,old.patterns.state})$fatal(1,"REGIONAL170_ROOT_PATTERN");
  if({dut.patterns.previous_mode,dut.patterns.run_mode,dut.patterns.snapshot_selected,dut.patterns.snapshot_notes,dut.patterns.snapshot_gains,dut.patterns.remaining,dut.patterns.scan,dut.patterns.rank,dut.patterns.run_index,dut.patterns.best_note,dut.patterns.best_mask,dut.patterns.sorted,dut.patterns.clear_sample,dut.patterns.interval_left,dut.patterns.hold_left,dut.patterns.arp_age,dut.patterns.full_left}!==
     {old.patterns.previous_mode,old.patterns.run_mode,old.patterns.snapshot_selected,old.patterns.snapshot_notes,old.patterns.snapshot_gains,old.patterns.remaining,old.patterns.scan,old.patterns.rank,old.patterns.run_index,old.patterns.best_note,old.patterns.best_mask,old.patterns.sorted,old.patterns.clear_sample,old.patterns.interval_left,old.patterns.hold_left,old.patterns.arp_age,old.patterns.full_left})$fatal(1,"PAT113_ROOT_PRIVATE_STATE_SAME_CLOCK");
  for(integer pq=0;pq<7;pq=pq+1)if(dut.patterns.order[pq]!==old.patterns.order[pq])$fatal(1,"PAT113_ROOT_ORDER_SAME_CLOCK");
  if({dut.recording,dut.replaying,dut.record_full,dut.record_time_limit,dut.record_count,dut.record_samples,dut.record_duration,dut.replay_frame_ready,dut.recorder.capture_busy,dut.recorder.replay_state,dut.recorder.replay_index,dut.recorder.write_index}!==
     {old.recording,old.replaying,old.record_full,old.record_time_limit,old.record_count,old.record_samples,old.record_duration,old.replay_frame_ready,old.recorder.capture_busy,old.recorder.replay_state,old.recorder.replay_index,old.recorder.write_index})$fatal(1,"REGIONAL170_ROOT_RECORDER");
  if(dut.audio.ui_depth>dut.audio.mod_depth)depthUi++;else depthMidi++;
  if(dut.sample_tick&&dut.pcm!=0)pcm++;if(dut.leading_valid)leading++;if(dut.pattern_busy)patterns++;
  if(dut.recording)records++;if(dut.replaying)replays++;if(!dut.usb_up_sync[1])usbdown++;if(dut.rst)resets++;
  if(dut.selected_valid&&dut.selected_ready)events++;
  if(dut.audio.physical.group[0].worker.ctx_save)saveEdges++;
  if(dut.pattern_owner)wifiOwnerCycles++;
 end
 task clocks(input integer n);repeat(n)@(negedge clk);endtask
 task frames(input integer n);repeat(n)begin @(posedge dut.sample_tick);@(negedge clk);end endtask
 task eventword(input[31:0]word);begin fork dut.soc.midi_event(word);old.soc.midi_event(word);join clocks(20);end endtask
 task pulse_rec;begin rec=1;frames(1);rec=0;frames(1);end endtask
 task pulse_rep;begin rep=1;frames(1);rep=0;frames(1);end endtask
 task clear_publication;begin
  // Match actual usb_play_soc reset publication (source request is0 at reset).
  dut.soc.midi_request=0;old.soc.midi_request=0;dut.soc.midi_data=0;old.soc.midi_data=0;
 end endtask
 initial begin
  clocks(5);rstn=1;clocks(250);
  eventword(32'h00643c90);frames(150);pulse_rec;eventword(32'h00644090);frames(4);eventword(32'h00003c80);frames(3);pulse_rec;pulse_rep;frames(12);pulse_rep;
  // Actual recorder transport carries changing depth/config into the audio pipeline.
  for(integer d=0;d<4;d=d+1)begin
   probe_level=d;probe_depth=127;frames(2);probe_depth=0;frames(3);
   pulse_rec;probe_depth=17+d*27;frames(2);probe_depth=0;frames(2);pulse_rec;pulse_rep;frames(6);pulse_rep;
  end
  probe_depth=0;probe_level=0;
  pattern=1;clocks(4);eventword(32'h00644390);eventword(32'h00644790);
  force dut.pattern_start=1;force old.pattern_start=1;clocks(1);release dut.pattern_start;release old.pattern_start;frames(8);
  // Loss/recovery of the actual USB PLL boundary is observed through both
  // original sync stages; do not force the synchronized application signal.
  force dut.usb_pll.lock=0;force old.usb_pll.lock=0;clear_publication;clocks(13);
  release dut.usb_pll.lock;release old.usb_pll.lock;force dut.usb_pll.lock=1;force old.usb_pll.lock=1;clocks(70);
  eventword(32'h00644390);eventword(32'h00644790);pattern=2;clocks(4);
  force dut.pattern_start=1;force old.pattern_start=1;clocks(1);release dut.pattern_start;release old.pattern_start;frames(8);
  pattern=3;clocks(4);force dut.pattern_start=1;force old.pattern_start=1;clocks(1);release dut.pattern_start;release old.pattern_start;frames(8);
  pattern=0;clocks(4);eventword(32'h00644890);frames(8);
  // Real status mailbox plus UI-equivalent WiFi owner changes exercise the local owner cone.
  dut.soc.ptest_debug[255:224]=32'h2c;old.soc.ptest_debug[255:224]=32'h2c;clocks(200);
  if(!dut.esp_ready_patterns||!old.esp_ready_patterns)$fatal(1,"PAT113_WIFI_STATUS_MAILBOX_NOT_READY");
  wifi_owner=1;wifi_mode=1;clocks(10);eventword(32'h00644390);eventword(32'h00644790);
  force dut.pattern_start=1;force old.pattern_start=1;clocks(1);release dut.pattern_start;release old.pattern_start;frames(5);
  wifi_mode=2;clocks(5);force dut.pattern_start=1;force old.pattern_start=1;clocks(1);release dut.pattern_start;release old.pattern_start;frames(5);
  wifi_mode=0;clocks(5);eventword(32'h00643c90);frames(3);
  wifi_mode=3;clocks(5);force dut.pattern_start=1;force old.pattern_start=1;clocks(1);release dut.pattern_start;release old.pattern_start;frames(5);
  force dut.usb_pll.lock=0;force old.usb_pll.lock=0;clear_publication;clocks(13);
  release dut.usb_pll.lock;release old.usb_pll.lock;force dut.usb_pll.lock=1;force old.usb_pll.lock=1;clocks(200);
  wifi_owner=0;wifi_mode=0;frames(3);
  // Asynchronous assertion between clock edges and original third-edge release.
  #3;rstn=0;clear_publication;#2;
  if(dut.recorder.rst!==1||dut.audio.rst!==1||old.rst!==1)$fatal(1,"REGIONAL170_ASYNC_ASSERT");
  clocks(5);#3;rstn=1;clocks(250);eventword(32'h00643c90);frames(10);
  if(pcm==0||leading==0||patterns==0||records==0||replays==0||events<8||saveEdges==0||wifiOwnerCycles<1000)$fatal(1,"REGIONAL170_ROOT_COVERAGE pcm%0d leading%0d pattern%0d rec%0d replay%0d event%0d",pcm,leading,patterns,records,replays,events);
  if(depthUi==0||depthMidi==0)$fatal(1,"REPAIR72_ROOT_DEPTH_SELECTOR_COVERAGE");
  $display("REPAIR72_ROOT_DEPTH_PASS ui%0d midi%0d",depthUi,depthMidi);
  $display("PAT113_WIFI_OWNER_PASS cycles%0d",wifiOwnerCycles);
  $display("REGIONAL170_ROOT_PASS everyClock%0d PCM%0d leading%0d pattern%0d recording%0d replay%0d usbdown%0d reset%0d events%0d save%0d",checks,pcm,leading,patterns,records,replays,usbdown,resets,events,saveEdges);$finish;
 end
 initial begin #10000000;$fatal(1,"REGIONAL170_ROOT_TIMEOUT");end
endmodule
