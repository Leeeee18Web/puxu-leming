`timescale 1ns/1ps
module tb_strings_audition;
 reg clk=0,rst=1,tick=0,gate=0,trigger=0;always #10 clk=~clk;
 reg[23:0]step=90000;reg[11:0]gain=1800;reg[2:0]tone=1;
 wire signed[15:0]a,b;wire[15:0]ae,be;wire aa,ba,ab,bb,ad,bd;
 `include "play_note_steps.vh"
 ref_r1_phys_string_voice old_model(clk,rst,tick,gate,trigger,step,gain,tone,a,ae,aa,ab,ad);
 phys_string_voice new_model(clk,rst,tick,gate,trigger,step,gain,tone,b,be,ba,bb,bd);
 integer file,mode,segment,i,frames=0,nonzero_a=0,nonzero_b=0;integer key;
 task frame;begin
  @(negedge clk);tick=1;@(negedge clk);tick=0;trigger=0;
  repeat(1022)@(negedge clk);
  if(ad||bd)$fatal(1,"AUDITION_DEADLINE frame=%0d",frames);
  if(a!=0)nonzero_a++;if(b!=0)nonzero_b++;
  $fdisplay(file,"%0d %0d",a,b);frames++;
 end endtask
 initial begin
  for(mode=1;mode<=2;mode++)begin
   rst=1;gate=0;trigger=0;repeat(10)@(negedge clk);tone=mode;rst=0;
   if(mode==1)file=$fopen("grand_r1_r2.txt","w");else file=$fopen("guitar_r1_r2.txt","w");
   if(!file)$fatal(1,"AUDITION_FILE_OPEN");
   for(segment=0;segment<6;segment++)begin
    case(segment)0:key=48;1:key=55;2:key=60;3:key=64;4:key=67;default:key=72;endcase
    step=midi_step(key);gain=segment<3?1800:3200;gate=1;trigger=1;
    for(i=0;i<16384;i++)frame;
   end
   gate=0;for(i=0;i<32768;i++)frame;
   $fclose(file);
  end
  if(nonzero_a<10000||nonzero_b<10000)$fatal(1,"AUDITION_SILENT");
  $display("STRINGS_AUDITION_PASS frames=%0d nonzero=%0d/%0d original1024clockcadence",frames,nonzero_a,nonzero_b);$finish;
 end
 initial begin #(64'd6000000000);$fatal(1,"AUDITION_TIMEOUT");end
endmodule
