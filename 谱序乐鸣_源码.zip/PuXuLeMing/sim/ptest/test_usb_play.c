/* Protocol fixture, not recorded hardware: real host enumeration/control code
 * sees packetized device/config/HID/hub descriptors and port status replies.
 * Breaks caught: address/config/interface confusion, endpoint DATA toggle reuse,
 * MIDI padding interpreted as data, stale note/touch after disconnect/fault. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "usb_play.h"
#define CHECK(x) do{checks++;if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);exit(1);}}while(0)
static unsigned checks;
static const uint8_t report[]={
 5,0x0d,9,4,0xa1,1,0x85,7,9,0x42,9,0x47,0x15,0,0x25,1,
 0x75,1,0x95,2,0x81,2,0x75,6,0x95,1,0x81,3,
 5,1,9,0x30,9,0x31,0x15,0,0x26,0xff,0x7f,0x75,16,0x95,2,0x81,2,0xc0};
/* Configuration value=5, MIDI interface=3/endpoint=5. Deliberately not 1/0. */
static const uint8_t midi_config[]={
 9,2,52,0,1,5,0,0x80,50, 9,4,3,0,1,1,3,0,0,
 7,0x24,1,0,1,22,0, 6,0x24,2,1,1,0,
 9,0x24,3,1,2,1,1,1,0,
 7,5,0x85,2,64,0,0, 5,0x25,1,1,2};
static const uint8_t hid_config[]={
 9,2,34,0,1,7,0,0x80,50, 9,4,4,0,1,3,0,0,0,
 9,0x21,0x11,1,0,1,0x22,sizeof(report),0, 7,5,0x83,3,8,0,1};
static const uint8_t hub_config[]={
 9,2,25,0,1,2,0,0xe0,0, 9,4,0,0,1,9,0,0,0, 7,5,0x81,3,1,0,12};
/* USB-IF midi10.pdf AppendixB TablesB2..B14, literal descriptor sizes,
 * jack graph and9-byte endpoints; configuration total is101 bytes. */
static const uint8_t appendix_config[]={
 9,2,101,0,2,1,0,0x80,50,
 9,4,0,0,0,1,1,0,0, 9,0x24,1,0,1,9,0,1,1,
 9,4,1,0,2,1,3,0,0, 7,0x24,1,0,1,65,0,
 6,0x24,2,1,1,0, 6,0x24,2,2,2,0,
 9,0x24,3,1,3,1,2,1,0, 9,0x24,3,2,4,1,1,1,0,
 9,5,1,2,64,0,0,0,0, 5,0x25,1,1,1,
 9,5,0x81,2,64,0,0,0,0, 5,0x25,1,1,3};
enum { MIDI=1,HID=2,HUB=3,BAD=4,MIDI2=5,APPENDIX=6 };
typedef struct {
 unsigned kind,address,configured,halt_clears,set_idle,endpoint_calls;
 unsigned halt,timeout,duplicate,malformed,short_report,queue_len,toggle;
 uint8_t queue[64];
} fake_device;
static fake_device d[8];
static unsigned speed,root_kind,port_status[8],port_change[8],power[8],resets[8],clear_changes[8];
static unsigned port_queries[8];
static unsigned reset_stuck,clear_halt_fail,bad_config,midi2,nested,hub_ports,hub_desc_bad;
static unsigned setup_nak,data_nak,status_nak,root_resets,hub_interrupts,ep0packet,mutation,idle_stall,control_duplicate;
static uint32_t ms,events[256],touch[6];
static unsigned nevents,ntouch;
static unsigned emit_touch;
static unsigned idle_line=1;
typedef struct {unsigned device,type,request,value,index,length,off,toggle;uint8_t data[2048];unsigned size;} ctrl;
static ctrl c;
static unsigned le(const uint8_t *p){return p[0]|((unsigned)p[1]<<8);}
uint32_t usb_play_now_ms(void){return ms;}
void usb_play_delay_ms(unsigned n){ms+=n;}
unsigned usb_play_root_speed(void){return speed;}
unsigned usb_play_root_idle(void){return idle_line;}
void usb_play_root_reset(void){root_resets++;ms+=40;for(unsigned i=0;i<8;i++)d[i].address=d[i].configured=d[i].toggle=0;}
void usb_play_publish(uint32_t a,uint32_t v){
 if(emit_touch&&a>=0x02000200&&a<=0x02000214)printf("%08X %08X\n",(unsigned)a,(unsigned)v);
 if(a==0x02000220){CHECK(nevents<256);events[nevents++]=v;}
 if(a>=0x02000200&&a<=0x02000214){touch[(a-0x02000200)/4]=v;if(a==0x02000214)ntouch++;}
}
static unsigned active(unsigned addr){
 if(addr){for(unsigned i=0;i<8;i++)if(d[i].kind&&d[i].address==addr)return i;}
 else {if(root_kind!=HUB&&d[0].address==0)return 0;for(unsigned i=1;i<=hub_ports&&i<8;i++)if((port_status[i]&3)==3&&d[i].address==0)return i;if(d[0].address==0)return 0;}
 return 99;
}
static void control_setup(unsigned slot,const uint8_t *p){
 c.device=slot;c.type=p[0];c.request=p[1];c.value=le(p+2);c.index=le(p+4);c.length=le(p+6);c.off=0;c.toggle=1;c.size=0;
 fake_device *f=&d[slot];
 if(c.request==6){
  unsigned dtype=c.value>>8;
  if(dtype==1){uint8_t dev[]={18,1,0x10,1,0,0,0,8,0x34,0x12,0x78,0x56,0,1,0,0,0,1};dev[7]=(uint8_t)ep0packet;if(f->kind==HUB)dev[4]=9;memcpy(c.data,dev,18);c.size=18;}
  else if(dtype==2){const uint8_t *p2=f->kind==HUB?hub_config:f->kind==HID?hid_config:f->kind==APPENDIX?appendix_config:midi_config;c.size=f->kind==HUB?sizeof(hub_config):f->kind==HID?sizeof(hid_config):f->kind==APPENDIX?sizeof(appendix_config):sizeof(midi_config);memcpy(c.data,p2,c.size);if(bad_config)c.data[9]=0;if(f->kind==MIDI2)c.data[22]=2;
   if(f->kind==APPENDIX&&mutation>=9)c.data[41]=(uint8_t)(mutation==9?37:66);
   if(f->kind==MIDI){if(mutation==1)c.data[51]=99; /* jack reference */
    if(mutation==2)c.data[36]=2; /* malformed OUT jack pins vs bLength */
    if(mutation==3)c.data[49]=2; /* bad CS subtype */
    if(mutation==4)c.data[44]=128; /* endpoint mps=128 */
    if(mutation==5)c.data[9]=8; /* short interface */
    if(mutation==6)c.data[4]=2; /* nonexistent second interface */
    if(mutation==7)c.data[23]=99; /* class total length wrong */
    if(mutation==8)c.data[46]=255; /* nonconforming bulk interval: ignore */
   }
  }
  else if(dtype==0x22){CHECK(c.type==0x81&&c.index==4);memcpy(c.data,report,sizeof(report));c.size=sizeof(report);}
  else if(dtype==0x29){CHECK(c.type==0xa0);uint8_t hd[]={9,0x29,0,0,0,10,0,0,0xff};hd[2]=(uint8_t)hub_ports;if(hub_desc_bad)hd[0]=2;memcpy(c.data,hd,9);c.size=9;}
  else CHECK(0);
 } else if(c.request==0&&c.type==0xa3){CHECK(slot==0&&c.index>=1&&c.index<=hub_ports);port_queries[c.index]++;unsigned ps=port_status[c.index],pc=port_change[c.index];c.data[0]=ps;c.data[1]=ps>>8;c.data[2]=pc;c.data[3]=pc>>8;c.size=4;}
 else if(c.request==0&&c.type==0xa0){memset(c.data,0,4);c.size=4;}
 else if(c.request==5){CHECK(c.type==0&&c.index==0&&c.value>=1&&c.value<=8);}
 else if(c.request==9){CHECK(c.type==0&&c.value==(f->kind==HUB?2u:f->kind==HID?7u:f->kind==APPENDIX?1u:5u));}
 else if(c.request==3&&c.type==0x23){CHECK(slot==0);if(c.value==8){power[c.index]++;port_status[c.index]|=0x100;}else if(c.value==4){resets[c.index]++;d[c.index].address=0;d[c.index].toggle=0;if(!reset_stuck){port_status[c.index]|=2;port_change[c.index]|=16;}else port_status[c.index]|=16;}else CHECK(0);}
 else if(c.request==1&&c.type==0x23){CHECK(slot==0);if(c.value>=16&&c.value<=20){clear_changes[c.index]++;port_change[c.index]&=~(1u<<(c.value-16));}else if(c.value==1)port_status[c.index]&=~2u;else CHECK(0);}
 else if(c.request==1&&c.type==2){CHECK(c.value==0&&c.index==(f->kind==HID?0x83u:f->kind==HUB?0x81u:0x85u));f->halt_clears++;f->toggle=0;}
 else if(c.request==10&&c.type==0x21){CHECK(c.index==4);f->set_idle++;}
 else CHECK(0);
 if(c.size>c.length)c.size=c.length;
}
int usb_play_transaction(unsigned addr,unsigned pid,unsigned ep,unsigned tog,const uint8_t *tx,unsigned tn,uint8_t *rx,unsigned cap,unsigned *rpid){
 ms++;unsigned slot=active(addr);if(slot==99)return USB_PLAY_TIMEOUT;fake_device *f=&d[slot];
 if(pid==USB_PLAY_SETUP){CHECK(ep==0&&tog==0&&tn==8);if(setup_nak){setup_nak--;return USB_PLAY_NAK;}control_setup(slot,tx);return 0;}
 if(ep==0){
  CHECK(slot==c.device);
  if(pid==USB_PLAY_OUT){CHECK(c.length>0&&tog==1&&tn==0&&c.off==c.size);if(status_nak){status_nak--;return USB_PLAY_NAK;}return 0;}
  CHECK(pid==USB_PLAY_IN);
  if(data_nak){data_nak--;return USB_PLAY_NAK;}
  if(!c.length){
   CHECK(tog==1);if(c.request==1&&c.type==2&&clear_halt_fail)return USB_PLAY_STALL;
   if(c.request==10&&idle_stall)return USB_PLAY_STALL;
   if(c.request==5)f->address=c.value;
   if(c.request==9)f->configured=c.value;
   *rpid=USB_PLAY_DATA1;return 0;
  }
  unsigned n=c.size-c.off;unsigned mp=c.request==6&&(c.value>>8)==1&&c.length==8?8:ep0packet;if(n>mp)n=mp;CHECK(cap>=n);CHECK(tog==c.toggle);memcpy(rx,c.data+c.off,n);
  if(control_duplicate){control_duplicate--;*rpid=c.toggle?USB_PLAY_DATA0:USB_PLAY_DATA1;return (int)n;}
  c.off+=n;*rpid=c.toggle?USB_PLAY_DATA1:USB_PLAY_DATA0;c.toggle^=1;return (int)n;
 }
 CHECK(f->configured&&pid==USB_PLAY_IN);f->endpoint_calls++;
 if(f->halt){f->halt--;return USB_PLAY_STALL;}
 if(f->timeout){f->timeout--;return USB_PLAY_TIMEOUT;}
 if(f->kind==HUB){CHECK(ep==1);hub_interrupts++;return USB_PLAY_NAK;}
 CHECK(ep==(f->kind==HID?3u:f->kind==APPENDIX?1u:5u));
 if(f->duplicate){f->duplicate--;*rpid=f->toggle?USB_PLAY_DATA0:USB_PLAY_DATA1;memcpy(rx,f->queue,f->queue_len);return f->queue_len;}
 if(!f->queue_len)return USB_PLAY_NAK;
 CHECK(tog==f->toggle&&cap>=f->queue_len);*rpid=f->toggle?USB_PLAY_DATA1:USB_PLAY_DATA0;f->toggle^=1;unsigned n=f->queue_len;memcpy(rx,f->queue,n);f->queue_len=0;return n;
}
static void fixture(unsigned kind){
 memset(d,0,sizeof(d));memset(port_status,0,sizeof(port_status));memset(port_change,0,sizeof(port_change));memset(power,0,sizeof(power));memset(resets,0,sizeof(resets));memset(clear_changes,0,sizeof(clear_changes));memset(touch,0,sizeof(touch));
 memset(&c,0,sizeof(c));memset(port_queries,0,sizeof(port_queries));speed=1;idle_line=1;root_kind=kind;d[0].kind=kind;ms=nevents=ntouch=0;hub_ports=2;reset_stuck=clear_halt_fail=bad_config=midi2=nested=hub_desc_bad=0;setup_nak=data_nak=status_nak=root_resets=hub_interrupts=0;mutation=idle_stall=control_duplicate=0;ep0packet=8;usb_play_init();
}
static void tick(unsigned n){while(n--){ms+=10;usb_play_poll();}}
static void queue(unsigned slot,const uint8_t *p,unsigned n){CHECK(n<=64);memcpy(d[slot].queue,p,n);d[slot].queue_len=n;}
static void direct_midi(void){
 fixture(MIDI);setup_nak=data_nak=status_nak=1;tick(20);CHECK((usb_play_state()&8)!=0);CHECK(d[0].address==1&&d[0].configured==5);
 const uint8_t p[]={9,0x91,60,100, 0x0c,0xc1,127,0xfe, 0x0b,0xb1,74,64, 0x0e,0xe1,0,64, 8,0x81,60,0};queue(0,p,sizeof(p));tick(2);
 CHECK(nevents==5);CHECK(events[0]==0x00643c91&&events[1]==0x00007fc1&&events[2]==0x00404ab1&&events[3]==0x004000e1&&events[4]==0x00003c81);
 unsigned before=nevents;queue(0,p,4);d[0].duplicate=1;tick(1);CHECK(nevents==before);tick(2);CHECK(nevents==before+1);
 tick(40);CHECK(nevents==before+1); /* NAK has no panic and leaves toggle. */
 d[0].halt=1;tick(1);CHECK(d[0].halt_clears==1&&events[nevents-1]==255);queue(0,p,4);tick(2);CHECK(events[nevents-1]==0x00643c91);
 speed=0;tick(2);CHECK(events[nevents-1]==255&&!(usb_play_state()&8));unsigned detach=nevents;tick(4);CHECK(nevents==detach);
}
static void hub_pair(void){
 fixture(HUB);d[1].kind=HID;d[2].kind=MIDI;port_status[1]=port_status[2]=1;port_change[1]=port_change[2]=1;tick(60);
 CHECK((usb_play_state()&14)==14);CHECK(power[1]&&power[2]&&resets[1]&&resets[2]&&clear_changes[1]&&clear_changes[2]);CHECK(hub_interrupts>0);
 CHECK(d[1].address==2&&d[2].address==3&&d[1].configured==7&&d[2].configured==5&&d[1].set_idle==1);
 const uint8_t h[]={7,3,0,0x40,0,0x40},m[]={9,0x90,64,90};queue(1,h,6);queue(2,m,4);tick(4);
 CHECK((touch[0]&(1u<<24))&&touch[1]==(511u|(299u<<16)));CHECK(touch[3]==0x56781234&&touch[4]==0x04070103);CHECK(events[nevents-1]==0x005a4090);
 unsigned mcount=nevents;port_status[2]=0;port_change[2]=1;tick(8);CHECK(!(usb_play_state()&8)&&(usb_play_state()&4)&&events[nevents-1]==255&&nevents==mcount+1);
 port_status[2]=1;port_change[2]=1;d[2].address=d[2].configured=0;tick(30);CHECK((usb_play_state()&8)&&resets[2]==2);queue(2,m,4);tick(3);CHECK(events[nevents-1]==0x005a4090);
 port_status[1]=0;port_change[1]=1;tick(8);CHECK(!(touch[0]&(1u<<24))&&!(touch[0]&(64u<<8))&&!(usb_play_state()&4));
}
static void faults(void){
 fixture(MIDI);bad_config=1;tick(20);CHECK((usb_play_state()&16)&&!(usb_play_state()&8));
 fixture(MIDI2);tick(20);CHECK((usb_play_state()&16)&&!(usb_play_state()&8));
 fixture(HUB);hub_ports=8;tick(20);CHECK((usb_play_state()&16)&&!(usb_play_state()&8));
 /* Cascaded hubs are covered by test_ptest.c with an actual parent/port fixture. */
 fixture(HUB);d[1].kind=MIDI;port_status[1]=0x201;port_change[1]=1;tick(30);CHECK((usb_play_state()&16)&&!resets[1]&&!(usb_play_state()&8));
 fixture(HUB);d[1].kind=MIDI;port_status[1]=1;port_change[1]=1;reset_stuck=1;uint32_t start=ms;tick(35);CHECK((usb_play_state()&16)&&!(usb_play_state()&8)&&ms-start<5000);
 fixture(MIDI);tick(20);const uint8_t p[]={9,0x90,60,90};queue(0,p,4);tick(2);d[0].timeout=3;tick(5);CHECK(events[nevents-1]==255&&!(usb_play_state()&8));
 fixture(MIDI);tick(20);queue(0,p,3);tick(2);CHECK(events[nevents-1]==255&&!(usb_play_state()&8));
 fixture(MIDI);tick(20);d[0].halt=1;clear_halt_fail=1;tick(2);CHECK((usb_play_state()&16)&&!(usb_play_state()&8));
 fixture(HID);tick(20);const uint8_t h[]={7,3,0,0x40,0,0x40};queue(0,h,6);tick(2);CHECK(touch[0]&(1u<<24));queue(0,h,3);tick(2);CHECK(!(touch[0]&(1u<<24))&&!(usb_play_state()&4));
 fixture(MIDI);speed=2;tick(20);CHECK((usb_play_state()&16)&&!root_resets);
}
static void touch_without_keyboard(void){
 const uint8_t h[]={7,3,0,0x40,0,0x40},up[]={7,0,0,0x40,0,0x40};
 fixture(HID);idle_stall=1;tick(30);CHECK((usb_play_state()&4)&&!(usb_play_state()&8));queue(0,h,6);tick(2);CHECK(touch[0]&(1u<<24));queue(0,up,6);tick(2);CHECK(!(touch[0]&(1u<<24)));CHECK(nevents==0);
 fixture(HUB);d[1].kind=HID;port_status[1]=1;port_change[1]=1;tick(40);CHECK((usb_play_state()&4)&&!(usb_play_state()&8));queue(1,h,6);tick(3);CHECK(touch[0]&(1u<<24));
 d[2].kind=MIDI;port_status[2]=0x201;port_change[2]=1;tick(25);CHECK((usb_play_state()&4)&&!(usb_play_state()&8));CHECK(touch[0]&(1u<<24));queue(1,up,6);tick(3);CHECK(!(touch[0]&(1u<<24)));CHECK(nevents==0);
 fixture(HUB);hub_ports=7;d[1].kind=HID;d[7].kind=MIDI;port_status[1]=port_status[7]=1;port_change[1]=port_change[7]=1;tick(100);CHECK((usb_play_state()&14)==14&&d[7].address==8);
 speed=0;tick(2);CHECK(!(usb_play_state()&14)&&!(touch[0]&(1u<<24))&&events[nevents-1]==255);
}
static void descriptor_edges(void){
 for(unsigned mp=8;mp<=64;mp*=2){fixture(MIDI);ep0packet=mp;control_duplicate=3;tick(25);CHECK(usb_play_state()&8);}
 for(unsigned i=1;i<=7;i++){fixture(MIDI);mutation=i;tick(25);CHECK((usb_play_state()&16)&&!(usb_play_state()&8));}
 fixture(MIDI);tick(25);const uint8_t p[]={0,0,0,0,0x0f,0xff,0,0,0x09,0x80,60,90,0x09,0x90,0x80,90,0x0c,0xc0,23,0xff};queue(0,p,sizeof(p));tick(2);CHECK(nevents==1&&events[0]==0x000017c0);
 fixture(HUB);hub_desc_bad=1;tick(25);CHECK((usb_play_state()&16)&&!(usb_play_state()&2));
 fixture(MIDI);data_nak=1000;tick(25);CHECK((usb_play_state()&16)&&!(usb_play_state()&8)&&ms<5000);
 /* USB-MIDI1 specifies bInterval0. This robustness fixture deliberately
  * violates that reset value; bulk scheduling must still ignore the field. */
 fixture(MIDI);mutation=8;tick(20);CHECK(usb_play_state()&8);
 const uint8_t fast[]={9,0x90,60,100};queue(0,fast,4);tick(1);CHECK(nevents==1&&events[0]==0x00643c90);
 CHECK(sizeof(appendix_config)==101);
 fixture(APPENDIX);tick(25);CHECK((usb_play_state()&8)&&d[0].configured==1);queue(0,fast,4);tick(1);CHECK(nevents==1&&events[0]==0x00643c90);
 fixture(APPENDIX);mutation=9;tick(25);CHECK(usb_play_state()&8);
 fixture(APPENDIX);mutation=10;tick(25);CHECK((usb_play_state()&16)&&!(usb_play_state()&8));
}
static void reconnect_debounce(void){
 fixture(HUB);d[1].kind=MIDI;port_status[1]=1;port_change[1]=1;
 for(unsigned i=0;i<40&&!port_queries[1];i++)tick(1);
 CHECK(port_queries[1]>0);tick(4);CHECK(!resets[1]);
 /* A change event means a new attachment even if unplug was between polls.
  * Restart its full100ms debounce before resetting the default address. */
 port_change[1]=1;unsigned before=resets[1];tick(4);CHECK(resets[1]==before);
 tick(30);CHECK(usb_play_state()&8);
}
static void independent_faults(void){
 fixture(HUB);d[1].kind=HID;d[2].kind=MIDI;port_status[1]=port_status[2]=1;port_change[1]=port_change[2]=1;tick(50);
 const uint8_t h[]={7,3,0,0x40,0,0x40},m[]={9,0x90,65,120};queue(1,h,6);queue(2,m,4);tick(3);CHECK((touch[0]&(1u<<24))&&nevents==1);
 d[0].halt=1;tick(3);CHECK(d[0].halt_clears==1&&nevents==1&&(usb_play_state()&12)==12);
 d[1].halt=1;tick(2);CHECK(d[1].halt_clears==1&&nevents==1&&!(touch[0]&(1u<<24)));queue(1,h,6);queue(2,m,4);tick(3);CHECK((touch[0]&(1u<<24))&&nevents==2);
 d[2].halt=1;tick(2);CHECK(d[2].halt_clears==1&&events[nevents-1]==255&&(touch[0]&(1u<<24)));queue(2,m,4);tick(2);CHECK(events[nevents-1]==0x00784190);
 port_status[2]|=8;port_change[2]|=8;tick(8);CHECK((usb_play_state()&4)&&!(usb_play_state()&8)&&(touch[0]&(1u<<24))&&events[nevents-1]==255);
 fixture(HUB);d[1].kind=MIDI;port_status[1]=0x401;port_change[1]=1;tick(30);CHECK((usb_play_state()&16)&&!resets[1]&&!(usb_play_state()&8));
}
static void export_touch_trace(unsigned p8){
 /* Real direct HID enumeration -> synthetic absolute USB reports -> production
  * hid_decode -> five-field MMIO+EVENT. No predecoded coordinate injection. */
 static const unsigned legacy_points[][3]={{40,500,1},{40,500,0},{600,40,1},{600,40,0},{40,500,1},{40,500,0},{280,40,1},{280,40,0}};
 static const unsigned p8_points[][3]={{300,280,1},{300,280,0},{656,96,1},{656,96,0},{40,500,1},{40,500,0},{280,200,1},{280,200,0},{40,500,1},{40,500,0},{800,96,1},{800,96,0},{40,32,1},{40,32,0},{832,430,1},{832,430,0}};
 const unsigned (*points)[3]=p8?p8_points:legacy_points;
 unsigned count=p8?sizeof(p8_points)/sizeof(p8_points[0]):sizeof(legacy_points)/sizeof(legacy_points[0]);
 fixture(HID);tick(30);CHECK(usb_play_state()&4);emit_touch=1;
 for(unsigned i=0;i<count;i++){
  unsigned x=points[i][0],y=points[i][1],down=points[i][2];
  unsigned rawx=(x*32767u+1022u)/1023u,rawy=(y*32767u+598u)/599u;
  uint8_t r[]={7,(uint8_t)(down?3:0),(uint8_t)rawx,(uint8_t)(rawx>>8),(uint8_t)rawy,(uint8_t)(rawy>>8)};
  queue(0,r,sizeof(r));tick(1);CHECK(touch[1]==(x|(y<<16)));CHECK(((touch[0]>>24)&1)==down);
 }
 emit_touch=0;
}
static void root_line_filter(void){
 fixture(MIDI);tick(25);CHECK(usb_play_state()&8);unsigned before=nevents;
 idle_line=0;speed=0;tick(1);CHECK((usb_play_state()&8)&&nevents==before);
 speed=2;tick(1);CHECK((usb_play_state()&8)&&nevents==before);
 idle_line=1;speed=1;ms++;usb_play_poll();
 speed=0;ms++;usb_play_poll();CHECK(usb_play_state()&8);
 speed=1;ms++;usb_play_poll();CHECK(usb_play_state()&8);
 speed=0;ms++;usb_play_poll();CHECK(usb_play_state()&8);
 ms+=4;usb_play_poll();CHECK(!(usb_play_state()&8)&&events[nevents-1]==255&&nevents==before+1);
}
static void export_p8_midi_trace(void){
 /* Synthetic USB-MIDI packets decoded by unchanged production firmware.
  * First wrong D5 pair, then complete42-note Twinkle at virtual base72. */
 static const unsigned offsets[42]={0,0,7,7,9,9,7,5,5,4,4,2,2,0,7,7,5,5,4,4,2,7,7,5,5,4,4,2,0,0,7,7,9,9,7,5,5,4,4,2,2,0};
 fixture(MIDI);tick(30);CHECK(usb_play_state()&8);
 for(unsigned i=0;i<43;i++){
  unsigned note=i?72+offsets[i-1]:74;
  const uint8_t on[]={9,0x90,(uint8_t)note,100},off[]={8,0x80,(uint8_t)note,0};
  unsigned before=nevents;queue(0,on,4);tick(2);CHECK(nevents==before+1);CHECK(events[before]==((100u<<16)|(note<<8)|0x90u));printf("%08X\n",(unsigned)events[before]);
  before=nevents;queue(0,off,4);tick(2);CHECK(nevents==before+1);CHECK(events[before]==((note<<8)|0x80u));printf("%08X\n",(unsigned)events[before]);
 }
}
int main(int argc,char **argv){if(argc==2&&!strcmp(argv[1],"--emit-p8-midi")){export_p8_midi_trace();return 0;}if(argc==2&&!strcmp(argv[1],"--emit-p8-touch")){export_touch_trace(1);return 0;}if(argc==2&&!strcmp(argv[1],"--emit-touch")){export_touch_trace(0);return 0;}root_line_filter();direct_midi();hub_pair();faults();touch_without_keyboard();descriptor_edges();reconnect_debounce();independent_faults();printf("USB_PLAY_PASS checks=%u (transaction-level direct+hub HID/MIDI, malformed, NAK, STALL, detach, DATA toggles)\n",checks);return 0;}

