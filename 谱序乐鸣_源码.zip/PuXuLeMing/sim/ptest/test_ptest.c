/* Packet-level tests. Real production host/parser; physical bus is simulated. */
#define main baseline_main
#define usb_play_transaction baseline_transaction
#define usb_play_publish baseline_publish
#include "test_usb_play.c"
#undef main
#undef usb_play_transaction
#undef usb_play_publish

static const uint8_t pointer_report[]={
 5,1,9,2,0xa1,1,0x85,9,9,1,0xa1,0,
 5,9,0x19,1,0x29,3,0x15,0,0x25,1,0x75,1,0x95,3,0x81,2,
 0x75,5,0x95,1,0x81,3,5,1,9,0x30,9,0x31,0x15,0,
 0x26,0xff,0x7f,0x75,16,0x95,2,0x81,2,0xc0,0xc0};
static unsigned parents[8],physical_port[8],ps[8][8],pc[8][8],pwr[8][8],rst[8][8];
static unsigned nested_mode,zlp,transient,diag_events;
static uint32_t diag_words[8];
void usb_play_publish(uint32_t a,uint32_t v){
 if(a>=0x02000230u&&a<0x02000250u){diag_words[(a-0x02000230u)/4]=v;diag_events++;}
 baseline_publish(a,v);
}
static unsigned bus_device(unsigned addr){
 for(unsigned i=0;i<8;i++)if(d[i].kind){
  if(addr&&d[i].address==addr)return i;
  if(!addr&&!d[i].address&&(!i||(d[parents[i]].configured&&(ps[parents[i]][physical_port[i]]&3)==3)))return i;
 }
 return 99;
}
int usb_play_transaction(unsigned addr,unsigned pid,unsigned ep,unsigned tog,const uint8_t *tx,unsigned tn,uint8_t *rx,unsigned cap,unsigned *rpid){
 if(!nested_mode){
  if(ep&&pid==USB_PLAY_IN&&zlp&&d[active(addr)].kind==HID){zlp=0;*rpid=tog?USB_PLAY_DATA1:USB_PLAY_DATA0;d[active(addr)].toggle^=1;return 0;}
  return baseline_transaction(addr,pid,ep,tog,tx,tn,rx,cap,rpid);
 }
 ms++;unsigned slot=bus_device(addr);if(slot==99)return USB_PLAY_TIMEOUT;
 fake_device *f=&d[slot];
 if(pid==USB_PLAY_SETUP){
  CHECK(ep==0&&tog==0&&tn==8);c.device=slot;c.type=tx[0];c.request=tx[1];c.value=le(tx+2);c.index=le(tx+4);c.length=le(tx+6);c.off=0;c.toggle=1;c.size=0;
  if(c.request==6){
   unsigned type=c.value>>8;
   if(type==1){uint8_t b[]={18,1,0x10,1,0,0,0,8,0x34,0x12,0x78,0x56,0,1,0,0,0,1};if(f->kind==HUB)b[4]=9;memcpy(c.data,b,18);c.size=18;}
   else if(type==2){const uint8_t *b=f->kind==HUB?hub_config:f->kind==HID?hid_config:midi_config;c.size=f->kind==HUB?sizeof(hub_config):f->kind==HID?sizeof(hid_config):sizeof(midi_config);memcpy(c.data,b,c.size);}
   else if(type==0x22){memcpy(c.data,report,sizeof(report));c.size=sizeof(report);}
   else {CHECK(type==0x29);uint8_t b[]={9,0x29,2,0,0,10,0,0,0xff};memcpy(c.data,b,9);c.size=9;}
  }else if(c.request==0&&c.type==0xa3){CHECK(f->kind==HUB&&c.index>=1&&c.index<=2);unsigned s=ps[slot][c.index],ch=pc[slot][c.index];c.data[0]=s;c.data[1]=s>>8;c.data[2]=ch;c.data[3]=ch>>8;c.size=4;}
  else if(c.request==0&&c.type==0xa0){memset(c.data,0,4);c.size=4;}
  else if(c.type==0x23){CHECK(f->kind==HUB&&c.index>=1&&c.index<=2);unsigned p=c.index;
   if(c.request==3&&c.value==8){pwr[slot][p]++;ps[slot][p]|=0x100;}
   else if(c.request==3&&c.value==4){rst[slot][p]++;ps[slot][p]|=2;pc[slot][p]|=16;for(unsigned i=1;i<8;i++)if(parents[i]==slot&&physical_port[i]==p)d[i].address=d[i].configured=d[i].toggle=0;}
   else if(c.request==1&&c.value>=16&&c.value<=20)pc[slot][p]&=~(1u<<(c.value-16));
   else {CHECK(c.request==1&&c.value==1);ps[slot][p]&=~2u;}
  }else CHECK(c.request==5||c.request==9||c.request==10||(c.request==1&&c.type==2));
  if(c.size>c.length)c.size=c.length;
  return 0;
 }
 if(!ep){CHECK(c.device==slot);if(pid==USB_PLAY_OUT){CHECK(c.off==c.size&&tog==1);return 0;}
  if(!c.length){if(c.request==5)f->address=c.value;if(c.request==9)f->configured=c.value;*rpid=USB_PLAY_DATA1;return 0;}
  unsigned n=c.size-c.off;if(n>8)n=8;CHECK(tog==c.toggle&&cap>=n);memcpy(rx,c.data+c.off,n);c.off+=n;*rpid=c.toggle?USB_PLAY_DATA1:USB_PLAY_DATA0;c.toggle^=1;return n;
 }
 CHECK(f->configured&&pid==USB_PLAY_IN);f->endpoint_calls++;
 if(f->kind==HUB)return USB_PLAY_NAK;
 if(transient&&f->kind==HID){transient--;return USB_PLAY_TIMEOUT;}
 if(!f->queue_len)return USB_PLAY_NAK;
 CHECK(tog==f->toggle&&cap>=f->queue_len);*rpid=f->toggle?USB_PLAY_DATA1:USB_PLAY_DATA0;f->toggle^=1;unsigned n=f->queue_len;memcpy(rx,f->queue,n);f->queue_len=0;return n;
}
static void pointer(void){hid_layout m;touch_sample s;
 CHECK(hid_parse_descriptor(pointer_report,sizeof(pointer_report),&m));
 uint8_t p[]={9,1,0,0x40,0,0x40};CHECK(hid_decode(&m,p,sizeof(p),1024,600,&s)==1&&s.valid&&s.down&&s.x==511&&s.y==299);
 p[1]=0;CHECK(hid_decode(&m,p,sizeof(p),1024,600,&s)==1&&s.valid&&!s.down);
 uint8_t relative[sizeof(pointer_report)];memcpy(relative,pointer_report,sizeof(relative));relative[sizeof(relative)-3]=6;
 CHECK(!hid_parse_descriptor(relative,sizeof(relative),&m));
}
static void empty_packet(void){hid_layout layout;touch_sample sample;uint8_t empty=0;
 CHECK(hid_parse_descriptor(report,sizeof(report),&layout));layout.uses_id=0;
 CHECK(hid_decode(&layout,&empty,0,1024,600,&sample)==0);
 fixture(HID);tick(30);CHECK(usb_play_state()&4);unsigned before=ntouch;zlp=1;tick(1);CHECK((usb_play_state()&4)&&ntouch==before);const uint8_t h[]={7,3,0,0x40,0,0x40};queue(0,h,6);tick(2);CHECK(touch[0]&(1u<<24));}
static void touch_retry(void){
 fixture(HID);tick(30);const uint8_t h[]={7,3,0,0x40,0,0x40},up[]={7,0,0,0x40,0,0x40};queue(0,h,6);tick(2);
 CHECK(touch[0]&(1u<<24));unsigned commits=ntouch;
 d[0].timeout=1;tick(1);CHECK((touch[0]&(1u<<24))&&ntouch==commits);
 tick(1);d[0].timeout=2;tick(2);CHECK((touch[0]&(1u<<24))&&ntouch==commits);
 queue(0,up,6);tick(2);CHECK(!(touch[0]&(1u<<24))&&(usb_play_state()&4));
 queue(0,h,6);tick(2);d[0].timeout=3;tick(4);CHECK(!(touch[0]&(1u<<24))&&!(usb_play_state()&4));
}
static void cascade(void){
 fixture(HUB);nested_mode=1;memset(ps,0,sizeof(ps));memset(pc,0,sizeof(pc));memset(pwr,0,sizeof(pwr));memset(rst,0,sizeof(rst));
 d[1].kind=HUB;d[2].kind=MIDI;d[3].kind=HID;parents[1]=parents[2]=0;physical_port[1]=1;physical_port[2]=2;parents[3]=1;physical_port[3]=2;
 ps[0][1]=ps[0][2]=ps[1][2]=1;pc[0][1]=pc[0][2]=pc[1][2]=1;tick(180);
 CHECK((usb_play_state()&14)==14);CHECK(d[1].configured&&d[2].configured&&d[3].configured);CHECK(d[1].address!=d[2].address&&d[1].address!=d[3].address&&d[2].address!=d[3].address);
 CHECK(pwr[0][1]&&pwr[0][2]&&pwr[1][1]&&pwr[1][2]);
 const uint8_t h[]={7,3,0,0x40,0,0x40},m[]={9,0x90,64,90};queue(3,h,6);queue(2,m,4);tick(4);CHECK((touch[0]&(1u<<24))&&nevents==1);
 /* Three lost packets isolate/retry the affected leaf; no physical unplug. */
 transient=3;tick(5);CHECK(!(usb_play_state()&4)&&(usb_play_state()&8));tick(200);CHECK((usb_play_state()&12)==12&&rst[1][2]>=2);
 queue(3,h,6);tick(4);CHECK(touch[0]&(1u<<24));
 ps[0][1]=0;pc[0][1]=1;tick(40);CHECK(!(usb_play_state()&4)&&(usb_play_state()&8));queue(2,m,4);tick(4);CHECK(nevents==2);
 d[1].address=d[1].configured=0;ps[0][1]=pc[0][1]=1;tick(180);CHECK((usb_play_state()&12)==12);
 /* Retry budget is finite even if the peripheral remains unresponsive. */
 transient=1000;tick(1000);unsigned reset_count=rst[1][2];CHECK(reset_count>=2&&reset_count<=6);tick(300);CHECK(rst[1][2]==reset_count&&(usb_play_state()&8));transient=0;
 CHECK(usb_play_state()&16);
 CHECK(diag_events>0);nested_mode=0;
}
int main(int argc,char **argv){CHECK(argc==2);if(!strcmp(argv[1],"pointer"))pointer();else if(!strcmp(argv[1],"empty"))empty_packet();else if(!strcmp(argv[1],"cascade"))cascade();else if(!strcmp(argv[1],"touch_retry"))touch_retry();else CHECK(0);printf("PTEST_PASS %s checks=%u\n",argv[1],checks);return 0;}
