`timescale 1ns/1ps
module tb_global13_patterns;
 reg clk=0,rst=1,tick=0,cancel=0,start=0,valid=0;reg[1:0]mode=1;reg[31:0]data=0;
 always #10 clk=~clk;
 wire[6:0]s,os;wire[48:0]n,on;wire[83:0]g,og;wire[3:0]a,oa,tr,otr;
 wire[27:0]sn,osn;wire[47:0]sg,osg;wire busy,obusy,full,ofull;wire[2:0]count,ocount;
 final_patterns #(.SAMPLE_HZ(64),.STRUM_SAMPLES(3),.ARP_SAMPLES(5),.HOLD_SAMPLES(7)) dut(clk,rst,tick,cancel,mode,start,valid,data,s,n,g,a,tr,sn,sg,busy,count,full,2'd0,2'd0,1'b0,1'b0,1'b0,1'b0);
 final_patterns_before_global13 #(.SAMPLE_HZ(64),.STRUM_SAMPLES(3),.ARP_SAMPLES(5),.HOLD_SAMPLES(7)) old(clk,rst,tick,cancel,mode,start,valid,data,os,on,og,oa,otr,osn,osg,obusy,ocount,ofull);
 integer checks=0,activeGain=0,chord=0,arp=0,strum=0,cancels=0,disabled=0;integer i,j,m,mask;
 always @(posedge clk)begin
  #1;checks++;
  if({s,n,g,a,tr,sn,sg,busy,count,full}!=={os,on,og,oa,otr,osn,osg,obusy,ocount,ofull})$fatal(1,"PATTERN_GLOBAL13_OUTPUT clk%0d",checks);
  if({dut.state,dut.previous_mode,dut.run_mode,dut.snapshot_selected,dut.remaining,dut.snapshot_notes,dut.snapshot_gains,dut.scan,dut.rank,dut.run_index,dut.best_note,dut.best_mask,dut.sorted,dut.clear_sample,dut.interval_left,dut.hold_left,dut.arp_age,dut.full_left}!==
     {old.state,old.previous_mode,old.run_mode,old.snapshot_selected,old.remaining,old.snapshot_notes,old.snapshot_gains,old.scan,old.rank,old.run_index,old.best_note,old.best_mask,old.sorted,old.clear_sample,old.interval_left,old.hold_left,old.arp_age,old.full_left})$fatal(1,"PATTERN_GLOBAL13_STATE");
  for(integer q=0;q<7;q++)if(dut.order[q]!==old.order[q])$fatal(1,"PATTERN_GLOBAL13_ORDER");
  if(|sg)activeGain++;if(dut.state==2)strum++;if(dut.state==3)chord++;if(dut.state==4)arp++;
  if(cancel)cancels++;if(!valid)disabled++;
 end
 task step;begin @(negedge clk);tick=~tick;end endtask
 task event_note(input integer note,input integer velocity);begin valid=1;data={8'd0,1'b0,velocity[6:0],1'b0,note[6:0],8'h90};step;valid=0;step;end endtask
 task reset;begin rst=1;valid=0;start=0;cancel=0;step;step;rst=0;step;end endtask
 initial begin
  reset;
  // All128 selection masks are built through real note transactions. Chord
  // entry truncation and each full strum/arp use the unchanged old oracle.
  for(mask=0;mask<128;mask++)for(m=1;m<=3;m++)begin
   mode=1;reset;
   for(j=0;j<7;j++)if(mask[j])event_note(48+j,40+j*10);
   mode=m;step;step;start=1;step;start=0;
   repeat(230)step;
   // Cancel has priority over simultaneous selection/start.
   cancel=1;valid=1;start=1;data=32'h00643c90;step;cancel=0;start=0;valid=0;step;
  end
  for(i=0;i<50000;i++)begin
   valid=$urandom_range(0,3)==0;cancel=$urandom_range(0,97)==0;start=$urandom_range(0,37)==0;
   if(i%113==0)mode=$urandom_range(0,3);
   data=$urandom;case(i%7)
    0,1,2:data={8'd0,1'b0,7'($urandom_range(1,127)),1'b0,7'($urandom_range(45,57)),8'h90};
    3:data=32'h000000ff;4:data=32'h00003c80;default:begin end
   endcase
   rst=i%1973==0;step;
  end
  rst=0;cancel=0;start=0;valid=0;repeat(260)step;
  if(activeGain==0||chord==0||arp==0||strum==0||cancels==0||disabled==0)$fatal(1,"PATTERN_GLOBAL13_COVERAGE");
  $display("GLOBAL13_PATTERNS_PASS checks%0d masks128x3 activeGain%0d chord%0d arp%0d strum%0d cancel%0d noEvent%0d",checks,activeGain,chord,arp,strum,cancels,disabled);$finish;
 end
 initial begin #10000000;$fatal(1,"PATTERN_GLOBAL13_TIMEOUT");end
endmodule
