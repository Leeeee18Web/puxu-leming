`timescale 1ns/1ps
module tb_p8_navigation;
 reg clk=0;always #10 clk=~clk;
 reg rst=1,update=0,valid=1,down=0,ready=1,pk=0,ckey=0;
 reg [15:0]x=0,y=0;
 wire ev;wire [31:0]data;wire [2:0]page;wire [1:0]mode,km,zoom;
 wire [6:0]base;wire centre,panic,clear_live,start,stop;wire [5:0]xy;
 p8_navigation nav(.clk(clk),.rst(rst),.touch_update(update),.touch_valid(valid),.touch_down(down),
  .touch_x(x),.touch_y(y),.event_ready(ready),.panic_key(pk),.centre_key(ckey),.event_valid(ev),.event_data(data),
  .page(page),.mode(mode),.knob_mode(km),.base_note(base),.centre(centre),.panic(panic),
  .clear_live(clear_live),.start_score(start),.stop_score(stop),.xy_config(xy),.spectrum_zoom(zoom),.muted(),.restart_lesson(),.pattern_mode(),.pattern_start());
 integer n=0,ons=0,offs=0,bends=0,k,key_x[0:24],on_before,off_before;reg [31:0]last=0;reg[6:0]bend=64;
 always @(posedge clk)if(!rst&&ev&&ready)begin
  last=data;
  if(data[7:4]==9)ons=ons+1;
  if(data[7:4]==8)offs=offs+1;
  if(data[7:4]==14)begin bends=bends+1;bend=data[22:16];end
 end
 task check(input bit good,input string msg);begin n=n+1;if(!good)$fatal(1,"%s",msg);end endtask
 task report(input bit d,input integer xx,yy);begin
  @(negedge clk);x=xx;y=yy;down=d;update=1;
  @(negedge clk);update=0;repeat(8)@(negedge clk);
 end endtask
 task click(input integer xx,yy);begin report(1,xx,yy);report(0,xx,yy);end endtask
 reg[31:0]stalled;
 initial begin
  repeat(4)@(negedge clk);rst=0;repeat(3)@(negedge clk);
  check(page==0&&mode==0&&km==1&&base==60,"home defaults");
  report(1,300,280);check(page==1&&mode==1,"home perform selection");
  report(1,48,500);check(ons==0,"held home contact cannot play new underlying piano");report(0,48,500);
  click(656,96);check(page==5,"piano tab geometry");
  report(1,48,500);check(ons==1&&last[15:8]==60,"virtual C4 without USB MIDI");
  report(1,110,300);check(ons==2&&offs==1&&last[15:8]==61,"glissando black key C sharp");
  report(0,110,300);check(offs==2,"release always off");
  click(280,200);check(base==72,"virtual octave up exactly once");
  report(1,48,500);check(last[15:8]==72,"virtual C5 actual MIDI note");
  valid=0;repeat(12)@(negedge clk);check(offs==3,"disconnect releases virtual note");valid=1;
  click(800,96);check(page==7,"guide occupies sixth tab");
  click(950,96);check(page==7,"old seventh tab is blank");
  click(192,290);click(512,290);report(1,832,290);report(1,2000,400);report(0,2000,400);
  click(200,450);click(500,450);click(700,450);
  check(bends==0&&km==1,"removed control regions emit no bend or mode changes");
  click(48,32);click(300,430);report(1,700,430);report(0,700,430);
  check(page==0&&bends==0&&km==1,"HOME strip is readonly");
  click(48,32);check(page==0&&mode==1,"home preserves current playing source");
  click(500,280);check(mode==2&&page==1,"home playback selection");
  click(656,96);report(1,48,500);check(ons==3,"playback piano never leaks live on");report(0,48,500);
  click(164,32);check(mode==1&&page==1,"perform switches back");
  click(368,96);check(page==3,"XY page");click(300,520);check(xy[1:0]==1,"XY ratio selection");click(850,570);check(xy[4:2]==4&&!xy[5],"XY fixed phase selection");
  click(230,96);click(850,150);check(page==2&&zoom==1,"spectrum zoom selection");
  pk=1;@(negedge clk);pk=0;repeat(3)@(negedge clk);check(!ev,"panic flushes queued events");
  click(164,32);click(656,96);
  key_x[0]=64;key_x[1]=96;key_x[2]=128;key_x[3]=160;key_x[4]=192;
  key_x[5]=256;key_x[6]=288;key_x[7]=320;key_x[8]=352;key_x[9]=384;
  key_x[10]=416;key_x[11]=448;key_x[12]=512;key_x[13]=544;key_x[14]=576;
  key_x[15]=608;key_x[16]=640;key_x[17]=704;key_x[18]=736;key_x[19]=768;
  key_x[20]=800;key_x[21]=832;key_x[22]=864;key_x[23]=896;key_x[24]=960;
  for(k=0;k<25;k=k+1)begin
   on_before=ons;off_before=offs;
   case(k)1,3,6,8,10,13,15,18,20,22:report(1,key_x[k],320);default:report(1,key_x[k],550);endcase
   check(ons==on_before+1&&last[7:0]==8'h90&&last[15:8]==base+k,"all25 actual touch note mappings");
   report(0,key_x[k],550);check(offs==off_before+1,"all25 touch release mappings");
  end
  click(950,96);check(page==5,"blank seventh tab does not navigate from piano");
  click(800,96);check(page==7,"guide reachable from piano");
  check(bends==0&&km==1,"no virtual bend or mode UI remains");
  $display("PASS tb_p8_navigation checks=%0d on=%0d off=%0d bend=%0d",n,ons,offs,bends);$finish;
 end
 initial begin #200000;$fatal(1,"timeout");end
endmodule
