`timescale 1ns/1ps
module recorder_voice_compare_case #(parameter N=7)(output reg done=0);
 reg [N-1:0] gates=0,triggers=0,pgates=0,pending=0;
 reg [N*7-1:0] notes=0,pnotes=0;reg [N*12-1:0] gains=0,pgains=0;reg [N*3-1:0] timbres=0,ptimbres=0;
 final_recorder #(.VOICE_COUNT(N),.EVENT_CAPACITY(3)) dut(.observer_gains(),.clk(1'b0),.rst(1'b1),.sample_tick(1'b0),.record_toggle(1'b0),.replay_toggle(1'b0),.clear(1'b0),.panic(1'b0),
 .in_gates(gates),.in_triggers(triggers),.in_notes(notes),.in_gains(gains),.in_timbres(timbres),.in_ratio(19'd0),.in_mod_depth(7'd0),.in_synth_config(32'd0),.export_address(12'd0),
 .out_gates(),.out_triggers(),.out_notes(),.out_gains(),.out_timbres(),.out_ratio(),.out_mod_depth(),.out_synth_config(),
 .recording(),.replaying(),.full(),.time_limit(),.replay_frame_ready(),.count(),.time_samples(),.export_word(),.export_ready(),.take_id(),.duration_samples(),.preview_rst(1'b0),.preview_gates('0),.preview_notes('0),.preview_gains('0),.preview_timbres('0),.preview_ratio('0),.preview_mod_depth('0),.preview_synth_config('0));
 recorder_before_voice_compare #(.VOICE_COUNT(N),.EVENT_CAPACITY(3)) reference(.clk(1'b0),.rst(1'b1),.sample_tick(1'b0),.record_toggle(1'b0),.replay_toggle(1'b0),.clear(1'b0),.panic(1'b0),
 .in_gates(gates),.in_triggers(triggers),.in_notes(notes),.in_gains(gains),.in_timbres(timbres),.in_ratio(19'd0),.in_mod_depth(7'd0),.in_synth_config(32'd0),.export_address(12'd0),
 .out_gates(),.out_triggers(),.out_notes(),.out_gains(),.out_timbres(),.out_ratio(),.out_mod_depth(),.out_synth_config(),
 .recording(),.replaying(),.full(),.time_limit(),.replay_frame_ready(),.count(),.time_samples(),.export_word(),.export_ready(),.take_id(),.duration_samples());
 integer i,j,v,checks=0,seed=32'h36875b91;
 reg [22:0] a,b;
 task compare;begin #1;
  if({dut.changed,dut.initial_changed,dut.changed_count,dut.initial_count} !== {reference.changed,reference.initial_changed,reference.changed_count,reference.initial_count})$fatal(1,"VOICE_COMPARE_OLD_EQ N=%0d check=%0d",N,checks);
  checks++;
 end endtask
 task set_voice(input integer voice,input [22:0] current_value,previous_value);begin
  {gates[voice],notes[voice*7+:7],gains[voice*12+:12],timbres[voice*3+:3]}=current_value;
  {pgates[voice],pnotes[voice*7+:7],pgains[voice*12+:12],ptimbres[voice*3+:3]}=previous_value;
 end endtask
 initial begin
  force dut.previous_gates=pgates;force reference.previous_gates=pgates;
  force dut.previous_notes=pnotes;force reference.previous_notes=pnotes;
  force dut.previous_gains=pgains;force reference.previous_gains=pgains;
  force dut.previous_timbres=ptimbres;force reference.previous_timbres=ptimbres;
  force dut.pending_triggers=pending;force reference.pending_triggers=pending;
  for(v=0;v<N;v++)begin
   for(i=0;i<23;i++)begin
    set_voice(v,23'd1<<i,23'd0);compare;
    set_voice(v,23'd1<<i,23'd1<<i);compare;
    set_voice(v,23'd0,23'd1<<i);compare;
   end
   for(i=0;i<23;i++)for(j=0;j<23;j++)begin set_voice(v,(23'd1<<i)|(23'd1<<j),23'd0);compare;end
   set_voice(v,23'd0,23'd0);pending[v]=1;compare;pending[v]=0;triggers[v]=1;compare;triggers[v]=0;
   set_voice(v,23'bx,23'd0);compare;set_voice(v,23'd0,23'd0);
  end
  for(i=0;i<65536;i++)begin
   for(v=0;v<N;v++)begin a=$random(seed);b=(i%2)?a:$random(seed);set_voice(v,a,b);end
   triggers=(i%4==0)?$random(seed):0;pending=(i%4==1)?$random(seed):0;compare;
  end
  $display("RECORDER_VOICE_COMPARE_PASS N=%0d checks=%0d 23bitAllBitsPairsEqualXTriggersRandom oldRTL",N,checks);done=1;
 end
endmodule
module tb_recorder_voice_compare;
 wire[2:0]done;recorder_voice_compare_case #(.N(4)) a(done[0]);recorder_voice_compare_case #(.N(7)) b(done[1]);recorder_voice_compare_case #(.N(25)) c(done[2]);
 initial begin wait(&done);$finish;end
endmodule
