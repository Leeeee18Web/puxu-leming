`timescale 1ns/1ps
module tb_score2_panel;
 reg clk=0;always #5 clk=~clk;reg rstn=0;reg[13:0]x=0,y=0;reg[31:0]cfg=0;wire[23:0]rgb;
 final_panel dut(.pixel_clk(clk),.rstn(rstn),.den(1'b1),.hsync(1'b1),.vsync(1'b1),.x(x),.y(y),.page(3'd5),.mode(2'd1),.playing(1'b0),.muted(1'b0),.note_valid(1'b0),.next_note(7'd0),.base_note(7'd60),.gates(4'd0),.notes(28'd0),.gains(48'd0),.home_gates(7'd0),.home_gains(84'd0),.piano_ready(1'b1),.touch_ready(1'b1),.recording(1'b0),.replaying(1'b0),.record_full(1'b0),.record_count(13'd0),.record_milliseconds(16'd0),.timbre(3'd0),.timbre_open(1'b1),.xy_overview(1'b0),.synth_config(cfg),.envelope_choices(8'h95),.preview_busy(1'b0),.knob(7'd64),.raw_knob(7'd64),.raw_known(1'b1),.pickup_wait(1'b0),.touch_state(2'd3),.pattern_mode(2'd0),.pattern_selected(7'd0),.pattern_notes(49'd0),.pattern_busy(1'b0),.pattern_count(3'd0),.pattern_full(1'b0),.lesson_target(7'd60),.lesson_feedback_note(7'd0),.lesson_feedback(2'd0),.lesson_position(6'd0),.lesson_done(1'b0),.knob_mode(2'd1),.last_note(7'd60),.last_velocity(7'd100),.mod_depth(7'd0),.wave_data(48'd0),.spectrum_data(8'd0),.spectrum_peak(8'd0),.spectrum_zoom(2'd0),.visual_valid(1'b0),.tone_data(11'd0),.tone_curve(17'd0),.tone_count(10'd0),.xy_data(1'b0),.xy_valid(1'b0),.xy_settings(6'd0),.wave_addr(),.spectrum_addr(),.tone_addr(),.xy_addr(),.rgb(rgb),.den_out(),.hsync_out(),.vsync_out());
 task point;input integer xx,yy;begin @(negedge clk);x=xx;y=yy;repeat(30)@(negedge clk);end endtask
 integer i,j;
 initial begin repeat(5)@(negedge clk);rstn=1;
  for(i=0;i<3;i=i+1)begin
   point(735,304+44*i);if(dut.label0!=118+i||!dut.text_on0)$fatal(1,"FX_NAME_LABEL %d %d",i,dut.label0);
   for(j=0;j<4;j=j+1)begin cfg=j<<(i*2);point(935,304+44*i);if(dut.label0!=121+j||!dut.text_on0)$fatal(1,"FX_LEVEL_LABEL %d %d",i,j);
    point(720,314+44*i);if(rgb!==(j==0?24'h192933:24'h254a43))$fatal(1,"FX_BACKGROUND %d %d %h",i,j,rgb);
   end
  end
  $display("SCORE2_PANEL_PASS actual glyph labels and all 12 level backgrounds");$finish;
 end
endmodule
