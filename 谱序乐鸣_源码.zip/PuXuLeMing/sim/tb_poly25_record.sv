`timescale 1ns/1ps
module tb_poly25_record;
 reg clk=0;always #10 clk=~clk;reg rst=1;reg[7:0]phase=0;always @(posedge clk)phase<=phase+1'b1;
 wire sample_tick=phase==255;reg record_toggle=0,replay_toggle=0,clear=0,panic=0;
 reg[24:0]in_gates=0,in_triggers=0;reg[174:0]in_notes=0;reg[299:0]in_gains=0;reg[74:0]in_timbres=0;
 wire[24:0]out_gates,out_triggers;wire[174:0]out_notes;wire[299:0]out_gains;wire[74:0]out_timbres;
 wire[18:0]out_ratio;wire[6:0]out_mod_depth;wire[31:0]out_synth_config;wire recording,replaying,full,time_limit,replay_frame_ready,export_ready;
 wire[12:0]count;wire[31:0]time_samples,take_id,duration_samples;reg[11:0]export_address=0;wire[95:0]export_word;
 final_recorder #(.VOICE_COUNT(25),.EVENT_CAPACITY(4096),.MAX_SAMPLES(100))dut(.clk(clk),.rst(rst),.sample_tick(sample_tick),.record_toggle(record_toggle),.replay_toggle(replay_toggle),.clear(clear),.panic(panic),.in_gates(in_gates),.in_triggers(in_triggers),.in_notes(in_notes),.in_gains(in_gains),.in_timbres(in_timbres),.in_ratio(19'd262144),.in_mod_depth(7'd45),.in_synth_config(32'h12345678),.observer_gains(),.*,.preview_rst(1'b0),.preview_gates('0),.preview_notes('0),.preview_gains('0),.preview_timbres('0),.preview_ratio('0),.preview_mod_depth('0),.preview_synth_config('0));
 integer checks=0,i;reg[24:0]seen=0;
 task check(input bit ok,input string msg);begin checks++;if(!ok)$fatal(1,"POLY25_RECORD_FAIL %s count%0d gates%h",msg,count,out_gates);end endtask
 task frame(input bit rec,play);begin @(negedge clk);while(phase!=10)@(negedge clk);record_toggle=rec;replay_toggle=play;@(negedge clk);record_toggle=0;replay_toggle=0;@(posedge sample_tick);repeat(4)@(negedge clk);end endtask
 initial begin
 repeat(5)@(negedge clk);rst=0;for(i=0;i<25;i++)begin in_notes[i*7+:7]=48+i;in_gains[i*12+:12]=1000+i;in_timbres[i*3+:3]=i%4;end
 in_gates=25'h1ffffff;frame(1,0);repeat(30)@(negedge clk);check(recording&&count==26,"whole25 onset+configuration reserved");
 frame(0,0);in_gates=0;frame(0,0);frame(1,0);repeat(30)@(negedge clk);check(!recording&&export_ready&&count==51,"whole25 release captured");
 for(i=0;i<51;i++)begin export_address=i;repeat(2)@(negedge clk);if(!export_word[63]&&export_word[56])begin check(export_word[62:57]<25,"export voice field within25");seen[export_word[62:57]]=1;check(export_word[54:48]==48+export_word[62:57],"export payload matches each voice");end end
 check(seen==25'h1ffffff,"all25 distinct exported voice IDs");
 frame(0,1);wait(replay_frame_ready);@(negedge clk);check(out_gates==25'h1ffffff&&out_notes==in_notes&&out_gains==in_gains&&out_timbres==in_timbres,"atomic25 replay first frame");
 check(dut.replay_triggers==25'h1ffffff,"held-at-start25 envelope initialization");check(out_ratio==262144&&out_mod_depth==45&&out_synth_config==32'h12345678,"configuration restored");
 frame(0,0);wait(replay_frame_ready);frame(0,0);wait(replay_frame_ready);@(negedge clk);check(out_gates==0,"atomic25 release replay");
 frame(0,0);frame(0,0);check(!replaying,"take completes");
 $display("POLY25_RECORD_PASS checks=%0d count=%0d",checks,count);$finish;
 end
 initial begin #1000000;$fatal(1,"record timeout");end
endmodule
