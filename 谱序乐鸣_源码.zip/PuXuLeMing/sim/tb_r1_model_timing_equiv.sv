`timescale 1ns/1ps
module tb_r1_model_timing_equiv;
 reg clk=0,rst=1,tick=0,trigger=0,gate=0;always #10 clk=~clk;
 reg[23:0]step=90000;reg[11:0]gain=0;reg[2:0]tone=1;
 wire[15:0]ss,rs,se,re,es,er,ee,ere;wire sa,ra,sb,rb,sd,rd,ea,era,eb,erb,ed,erd;
 phys_string_voice strings(.clk(clk),.rst(rst),.render_tick(tick),.gate(gate),.trigger(trigger),.step(step),.gain(gain),.timbre(tone),.sample(ss),.envelope(se),.active(sa),.busy(sb),.deadline_error(sd));
 ref_r2_phys_string_voice strings_ref(.clk(clk),.rst(rst),.render_tick(tick),.gate(gate),.trigger(trigger),.step(step),.gain(gain),.timbre(tone),.sample(rs),.envelope(re),.active(ra),.busy(rb),.deadline_error(rd));
 phys_ep_voice ep(.clk(clk),.rst(rst),.render_tick(tick),.gate(gate),.trigger(trigger),.step(step),.gain(gain),.sample(es),.envelope(ee),.active(ea),.busy(eb),.deadline_error(ed));
 ref_r1_phys_ep_voice ep_ref(.clk(clk),.rst(rst),.render_tick(tick),.gate(gate),.trigger(trigger),.step(step),.gain(gain),.sample(er),.envelope(ere),.active(era),.busy(erb),.deadline_error(erd));
 integer clocks=0,frames=0,string_nonzero=0,ep_nonzero=0,scene,i;
 always @(negedge clk)begin #1;
  if(!rst)begin
   clocks++;
   if(strings.a.state==16 && strings.bridge_total_q!==($signed({{2{strings.incident0[17]}},strings.incident0})+$signed({{2{strings.incident1[17]}},strings.incident1})+(tone==1?$signed({{2{strings.incident2[17]}},strings.incident2}):20'sd0)))$fatal(1,"BRIDGE_TOTAL_NOT_SAME_SAMPLE");
   if(strings.launch && ((strings.a.phase_compensation_q!==strings.a.phase_compensation_now) || (strings.b.phase_compensation_q!==strings.b.phase_compensation_now) || (strings.c.phase_compensation_q!==strings.c.phase_compensation_now)))$fatal(1,"TUNING_NOT_SETTLED_BEFORE_LAUNCH");

   if({ss,se,sa,sb,sd,es,ee,ea,eb,ed}!=={rs,re,ra,rb,rd,er,ere,era,erb,erd})$fatal(1,"MIXED_R2_MODEL_EQ_FAIL frame=%0d clock=%0d tone=%0d",frames,clocks,tone);
   if(sd||ed)$fatal(1,"MIXED_R2_MODEL_DEADLINE frame=%0d",frames);
   if(ss!=0)string_nonzero++;if(es!=0)ep_nonzero++;
  end
 end
 task frame;begin
  @(negedge clk);tick=1;@(negedge clk);tick=0;trigger=0;
  repeat(1022)@(negedge clk);frames++;
 end endtask
 initial begin
  repeat(8)@(negedge clk);rst=0;
  for(scene=0;scene<8;scene++)begin
   gain=scene[0]?12'd3200:12'd1200;tone=scene[1]?3'd2:3'd1;step=scene<4?24'd90000:24'd176128;
   gate=1;trigger=1;
   for(i=0;i<1024;i++)begin
    if(i==500)gate=0;
    if(i==620)begin gate=1;trigger=1;end
    if(i>300&&i<480)step=step+7;
    if(i==960)gain=0;
    frame;
   end
  end
  if(string_nonzero<100000||ep_nonzero<100000)$fatal(1,"MIXED_R2_MODEL_AUDIO_COVERAGE %0d %0d",string_nonzero,ep_nonzero);
  $display("MIXED_R2_MODEL_TIMING_EQ_PASS clocks=%0d frames=%0d strings=%0d ep=%0d 8scenes pitch/glide/release/retrigger/gain0",clocks,frames,string_nonzero,ep_nonzero);$finish;
 end
 initial begin #200000000;$fatal(1,"MIXED_R2_MODEL_EQ_TIMEOUT");end
endmodule
