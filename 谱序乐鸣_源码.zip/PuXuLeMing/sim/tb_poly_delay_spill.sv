`timescale 1ns/1ps
module tb_poly_delay_spill;
 reg clk=0;always #10 clk=~clk;reg rst=1,en=0,load=0;reg[2:0]idx=0;
 reg[12:0]ra=0,rb=0,rc=0,wa=0,wb=0,wc=0;reg ea=0,eb=0,ec=0;
 reg[19:0]da=0;reg[17:0]db=0,dc=0;reg[55:0]restore=0;
 wire[19:0]qa;wire[17:0]qb,qc;wire[55:0]snap;
 poly_delay_pool #(.CONTEXTS(7),.LENGTH(2048),.A_EXTRA(2)) dut(clk,rst,en,load,idx,restore,snap,ra,rb,rc,wa,wb,wc,ea,eb,ec,da,db,dc,qa,qb,qc,1'b0,13'd0,20'd0);
 reg[19:0]ga[0:14349];reg[17:0]gb[0:14335],gc[0:14335];
 integer i,j,n,checks=0,spill_reads=0;reg[19:0]expected_a;reg[17:0]expected_b,expected_c;
 initial begin repeat(3)@(negedge clk);rst=0;en=1;
 for(i=0;i<7;i=i+1)for(j=0;j<2050;j=j+1)begin
  idx=i;wa=j;ea=1;da=20'h80000^(i*28717+j*79);ga[i*2050+j]=da;
  eb=j<2048;ec=eb;wb=j%2048;wc=wb;db=18'h13000^(i*913+j*5);dc=18'h21000^(i*137+j*31);
  if(eb)begin gb[i*2048+j]=db;gc[i*2048+j]=dc;end
  @(negedge clk);
 end
 ea=0;eb=0;ec=0;
 for(n=0;n<12000;n=n+1)begin
  idx=n%7;ra=n%3==0?2048+n%2:(n*137)%2048;rb=(n*11)%2048;rc=(n*17)%2048;
  wa=ra;wb=rb;wc=rc;ea=n%2;eb=n%3==1;ec=n%5==1;
  da=n*929^20'h75abc;db=n*179;dc=n*271;
  expected_a=ga[idx*2050+ra];expected_b=gb[idx*2048+rb];expected_c=gc[idx*2048+rc];
  @(negedge clk);
  if(qa!==expected_a||qb!==expected_b||qc!==expected_c)$fatal(1,"SPILL_READ_FIRST_FAIL n%0d ctx%0d ra%0d got%h want%h",n,idx,ra,qa,expected_a);
  if(ea)ga[idx*2050+wa]=da;if(eb)gb[idx*2048+wb]=db;if(ec)gc[idx*2048+wc]=dc;
  checks++;if(ra>=2048)spill_reads++;
  ea=0;eb=0;ec=0;en=0;load=1;restore=56'habcdef01234567^n;
  @(negedge clk);load=0;if(snap!==restore)$fatal(1,"SPILL_RESTORE_FAIL");
  idx=(idx+3)%7;@(negedge clk);if(snap!==restore)$fatal(1,"SPILL_PAUSE_FAIL");en=1;
 end
 if(spill_reads!=4000)$fatal(1,"SPILL_COVERAGE");
 $display("POLY_DELAY_SPILL_PASS checks=%0d spill_reads=%0d private20bit/read-first/restore/pause/2048+2",checks,spill_reads);$finish;
 end
 initial begin #3000000;$fatal(1,"SPILL_TIMEOUT");end
endmodule
