`timescale 1ns/1ps
module tb_p8_lesson;
 reg clk=0; always #5 clk=~clk;
 reg rst=1,sample_tick=0,enabled=0,restart=0,event_valid=0,panic=0;
 reg [6:0] base_note=60;
 reg [31:0] event_data=0;
 wire [6:0] target_note,feedback_note,correct_count;
 wire [1:0] feedback;
 wire [5:0] position;
 wire done; wire [15:0] wrong_count;
 integer checks=0,i,s;
 integer song[0:41];
 p8_lesson dut(.*);
 task check(input bit ok,input string label);
  begin checks=checks+1;if(!ok)$fatal(1,"lesson %s pos=%0d target=%0d fb=%0d note=%0d good=%0d bad=%0d",label,position,target_note,feedback,feedback_note,correct_count,wrong_count);end
 endtask
 task ev(input integer src,status,note,vel);
  begin @(negedge clk);event_valid=1;event_data=(src<<24)|(vel<<16)|(note<<8)|status;
   @(negedge clk);event_valid=0;event_data=0;@(negedge clk);end
 endtask
 task fresh;
  begin @(negedge clk);enabled=1;restart=1;@(negedge clk);restart=0;@(negedge clk);end
 endtask
 initial begin
  song[0]=0;song[1]=0;song[2]=7;song[3]=7;song[4]=9;song[5]=9;song[6]=7;
  song[7]=5;song[8]=5;song[9]=4;song[10]=4;song[11]=2;song[12]=2;song[13]=0;
  song[14]=7;song[15]=7;song[16]=5;song[17]=5;song[18]=4;song[19]=4;song[20]=2;
  song[21]=7;song[22]=7;song[23]=5;song[24]=5;song[25]=4;song[26]=4;song[27]=2;
  song[28]=0;song[29]=0;song[30]=7;song[31]=7;song[32]=9;song[33]=9;song[34]=7;
  song[35]=5;song[36]=5;song[37]=4;song[38]=4;song[39]=2;song[40]=2;song[41]=0;
  repeat(3)@(negedge clk);rst=0;fresh();
  check(target_note==60 && position==0 && feedback==0,"reset target");
  ev(0,8'h90,61,100);check(position==0 && feedback==2 && feedback_note==61 && wrong_count==1,"wrong holds target");
  ev(0,8'h90,61,100);check(wrong_count==1,"duplicate wrong no extra count");
  ev(0,8'h90,61,0);ev(0,8'h90,61,100);check(wrong_count==2,"velocity zero releases");
  ev(0,8'h90,60,0);check(position==0,"zero velocity never advances");
  ev(0,8'h90,60,100);check(position==1 && target_note==60 && feedback==1 && feedback_note==60,"first repeated note");
  ev(0,8'h90,60,127);check(position==1,"held repeated ON rejected");
  ev(1,8'h80,60,0);ev(0,8'h90,60,100);check(position==1,"touch off cannot release physical");
  ev(0,8'h81,60,0);ev(0,8'h90,60,100);check(position==1,"other channel off cannot release");
  ev(1,8'h90,60,100);check(position==2 && target_note==67,"touch independent press accepted");
  fresh();ev(1,8'h90,60,100);ev(0,8'hff,0,0);ev(1,8'h90,60,100);check(position==1,"disconnect preserves touch held");
  ev(0,8'h90,60,100);check(position==2,"disconnect physical new press");
  fresh();ev(0,8'h90,60,100);ev(0,8'hff,0,0);ev(0,8'h90,60,100);check(position==2,"disconnect clears physical held");
  fresh();ev(0,8'h90,60,100);ev(0,8'hb0,64,127);ev(0,8'h80,60,0);ev(0,8'h90,60,100);check(position==2,"pedal does not block actual key release");
  fresh();ev(0,8'h90,60,100);ev(0,8'hb1,123,0);ev(0,8'h90,60,100);check(position==1,"CC wrong channel preserves hold");
  ev(0,8'hb0,123,0);ev(0,8'h90,60,100);check(position==2,"CC123 releases same channel");
  fresh();ev(1,8'h90,60,100);ev(0,8'hb0,120,0);ev(1,8'h90,60,100);check(position==1,"CC120 source ownership");
  ev(1,8'hb0,120,0);ev(1,8'h90,60,100);check(position==2,"CC120 releases owner");
  fresh();ev(0,8'h90,60,100);
  @(negedge clk);panic=1;@(negedge clk);panic=0;@(negedge clk);
  check(position==1 && feedback==0,"panic retains progress clears feedback");
  ev(0,8'h90,60,100);check(position==2,"panic clears holds");
  fresh();ev(0,8'h90,188,100);ev(0,8'h90,60,228);check(position==0 && wrong_count==0,"malformed MIDI ignored");
  ev(0,8'h90,0,100);check(position==0 && feedback==2 && feedback_note==0,"legal out-of-keyboard pitch wrong");
  ev(0,8'h80,0,0);ev(0,8'h90,127,100);check(wrong_count==2 && feedback_note==127,"top MIDI pitch wrong");
  fresh();ev(0,8'h90,60,100);
  @(negedge clk);sample_tick=1;repeat(14648)@(negedge clk);
  check(feedback==1,"feedback held for 14647 sample ticks");
  @(negedge clk);sample_tick=0;@(negedge clk);check(feedback==0 && target_note==60,"feedback expires after 14648 ticks");
  for(s=0;s<2;s=s+1)begin
   fresh();
   for(i=0;i<42;i=i+1)begin
    check(target_note==60+song[i] && !done,"song oracle target");
    ev(s,8'h90,60+song[i],100);
    check(position==i+1 && feedback==1 && feedback_note==60+song[i] && correct_count==i+1,"song advance");
    ev(s,8'h90,60+song[i],100);check(position==i+1,"song duplicate ignored");
    ev(s,8'h80,60+song[i],0);
   end
   check(done && target_note==127 && correct_count==42,"full song done");
   ev(s,8'h90,62,100);check(done && position==42 && wrong_count==0,"done does not regrade");
  end
  @(negedge clk);base_note=72;repeat(2)@(negedge clk);check(position==0 && target_note==72 && !done,"base change resets");
  ev(1,8'h90,60,100);check(position==0 && feedback==2,"exact octave required");
  ev(1,8'h90,72,100);check(position==1,"transposed base accepted");
  @(negedge clk);enabled=0;repeat(2)@(negedge clk);check(position==0 && feedback==0,"disable resets");
  @(negedge clk);enabled=1;event_valid=1;event_data=32'h01644890;
  @(negedge clk);event_valid=0;@(negedge clk);check(position==1,"mode entry first event accepted");
  @(negedge clk);restart=1;event_valid=1;event_data=32'h00644890;
  @(negedge clk);restart=0;event_valid=0;@(negedge clk);check(position==1 && correct_count==1,"restart first event accepted");
  @(negedge clk);base_note=60;event_valid=1;event_data=32'h00643c90;
  @(negedge clk);event_valid=0;@(negedge clk);check(position==1 && target_note==60,"base change first event accepted");
  @(negedge clk);rst=1;@(negedge clk);rst=0;check(position==0 && feedback==0 && correct_count==0 && wrong_count==0,"global reset");
  $display("PASS tb_p8_lesson checks=%0d",checks);$finish;
 end
endmodule
