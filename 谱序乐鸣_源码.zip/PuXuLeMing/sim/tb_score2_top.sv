`timescale 1ns/1ps
// Native PLL/physical pads and firmware publication boundary are modeled.
// Every production navigation, CDC, arbiter, allocator, source, recorder,
// voice engine, serial output and display module is instantiated by real top.
module tb_score2_top;
 reg clk=0,rstn=0;always #10 clk=~clk;
 tri dp,dm;wire[7:0]led;wire bck,ws,sd,ib,iw,idata;
 hub_play_top dut(.clk(clk),.rstn(rstn),.key1_n(1'b1),.key2_n(1'b1),.uart_rx(1'b1),.uart_tx(),
  .usb_dp(dp),.usb_dm(dm),.hp_bck(bck),.hp_ws(ws),.hp_din(sd),.i2s_bck(ib),.i2s_ws(iw),.i2s_sd(idata),
  .pa_en(),.led_o(led),.tmds_clk_p_0(),.tmds_clk_n_0(),.tmds_d_p_0(),.tmds_d_n_0());
 defparam dut.status_bridge.PERIOD=10;
 integer checks=0,nz=0,cycles=0,i,j,dual_left=0,dual_right=0,dual_mixed=0;
 reg dual_phase=0;
 reg[23:0]physical_step;
 reg[11:0]physical_gain;
 reg[6:0]physical_slot,touch_slot;
 always @(posedge clk)if(!dut.rst)begin
  cycles++;
  if(dut.sample_tick)begin
   check(!dut.audio_deadline_error,"all audio engines meet sample deadline");
   if(dut.pcm!=0)nz++;
   if(dual_phase)begin
    if(dut.audio.smooth_sample[0]!=0)dual_left++;
    if(dut.audio.smooth_sample[1]!=0)dual_right++;
    if(dut.pcm!=0)dual_mixed++;
   end
   if(dut.replaying)check(dut.replay_frame_ready,"coherent replay staged before render");
  end
 end
 task check(input bit ok,input string label_text);begin checks++;if(!ok)$fatal(1,"FINAL_TOP_FAIL %s",label_text);end endtask
 task waitclks(input integer count);begin repeat(count)@(negedge clk);end endtask
 task frames(input integer count);integer k;begin for(k=0;k<count;k++)begin @(posedge dut.sample_tick);@(negedge clk);end end endtask
 task touch(input integer x,y,input bit down);begin dut.soc.hid_report(x,y,down,1);waitclks(40);end endtask
 task tap(input integer x,y);begin touch(x,y,0);touch(x,y,1);touch(x,y,0);end endtask
 task eventword(input[31:0]word);begin dut.soc.midi_event(word);waitclks(50);end endtask
 task reset_all;begin rstn=0;waitclks(10);rstn=1;waitclks(1000);end endtask
 integer found;
 initial begin
  reset_all;dut.soc.ptest_debug[255:224]=32'h0c;waitclks(80);tap(300,280);tap(650,96);
  tap(100,195);frames(2);check(dut.recording,"record begins");
  eventword(32'h00643c90);frames(2);
  tap(800,30);tap(800,304);tap(800,354);tap(800,399);frames(650);
  check(dut.synth_config[5:0]==6'h15&&dut.sound_config[5:0]==6'h15,"all three live effects reach real recorded sound config");
  check(dut.audio.effects.processor.engine.c_input!=0&&dut.audio.effects.processor.engine.r_input!=0&&dut.audio.ui_depth==24,"chorus reverb vibrato actually active");
  found=0;for(i=0;i<dut.record_count;i=i+1)if(dut.recorder.event_ram[i][63]&&dut.recorder.event_ram[i][31:26]==6'h15)found=1;
  check(found!=0,"effect configuration retained in actual recording RAM");
  tap(500,240);tap(100,195);frames(3);check(!dut.recording,"record stopped");
  tap(800,30);for(i=0;i<3;i=i+1)begin tap(800,304);tap(800,354);tap(800,399);end
  tap(500,240);frames(200);check(dut.synth_config[5:0]==0,"live config off before replay");
  tap(280,195);frames(40);check(dut.replaying&&dut.sound_config[5:0]==6'h15,"replay restores saved effects while live menu is off");
  tap(600,32);frames(200);check(!dut.replaying,"stop replay");
  check(!dut.audio_deadline_error,"no combined effect deadline error");
  $display("SCORE2_TOP_PASS real HID menu MIDI mailbox record RAM replay effects checks=%0d",checks);$finish;
 end
 initial begin #100000000;$fatal(1,"TIMEOUT");end
endmodule
