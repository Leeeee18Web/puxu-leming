`timescale 1ns/1ps
// Production composition. Native and lesson phases use only touch.
// Separate physical phase replays production firmware-decoded USB-MIDI words via actual CDC.
module tb_p8_e2e;
reg clk=0,pixel_clk=0,usb_clk=0;
always #10 clk=~clk;
always #9.756097561 pixel_clk=~pixel_clk;
always #10.416666667 usb_clk=~usb_clk;
reg rst=1,pixel_rstn=0,frame_start=0,frames_on=1;
wire [1:0]usb_up_sync=2'b11;
wire usb_event_valid;wire[31:0]usb_event_data;wire usb_event_ready;
reg[31:0]midi_source_data=0;reg midi_source_request=0;wire midi_source_ack;
play_event_cdc midi_mailbox(.source_clk(usb_clk),.source_rst(rst),.source_data(midi_source_data),.source_request(midi_source_request),.source_ack(midi_source_ack),.clk(clk),.rst(rst),.valid(usb_event_valid),.data(usb_event_data),.ready(usb_event_ready));
reg[31:0] midi_trace[0:85];
wire panic_key=0;reg centre_key=0;
reg [13:0]x=0,y=0;wire den=1,hs=1,vs=1;
wire [1:0]video_up_sync=2'b11;
reg [31:0] touch_status_source=0,touch_xy_source=0,touch_raw_source=0,touch_vidpid_source=0,touch_meta_source=0;
reg touch_toggle=0;
reg[31:0] trace_words[0:191];
reg[31:0]shadow_status=0,shadow_xy=0,shadow_raw=0,shadow_vidpid=0,shadow_meta=0;
integer pc=0;
always @(negedge pixel_clk)begin pc=pc+1;frame_start=frames_on&&pc%1000==0;end
 wire[31:0]touch_status,touch_xy;wire touch_report;
 usb_touch_bridge touch_bridge(.pixel_clk(clk),.rstn(!rst),.source_toggle(touch_toggle),.source_status(touch_status_source),
  .source_xy(touch_xy_source),.source_raw(touch_raw_source),.source_vidpid(touch_vidpid_source),.source_meta(touch_meta_source),
  .status_q(touch_status),.xy_q(touch_xy),.raw_q(),.vidpid_q(),.meta_q(),.report_valid(touch_report));
 wire touch_good=touch_status[14]&&touch_status[12]&&usb_up_sync[1];reg previous_touch_good=0;
 always @(posedge clk)if(rst)previous_touch_good<=0;else previous_touch_good<=touch_good;
 wire touch_update=touch_report||(previous_touch_good&&!touch_good);
 wire [1:0] touch_state={touch_status[12]&&usb_up_sync[1],touch_good&&touch_status[24]};

 wire [2:0]page;wire [1:0]mode,knob_mode,spectrum_zoom;wire [5:0]xy_config;
 wire centre_touch,panic_touch,clear_live,start_score,stop_score,touch_event_valid,touch_event_ready,muted,restart_lesson;
 wire [6:0]base_note;wire[31:0]touch_event_data;
 wire[1:0]pattern_mode;wire pattern_start;

 p8_navigation touch_controls(.clk(clk),.rst(rst),.touch_update(touch_update),.touch_valid(touch_good),
  .touch_down(touch_status[24]&&touch_status[12]),.touch_x(touch_xy[15:0]),.touch_y(touch_xy[31:16]),
  .event_ready(touch_event_ready),.event_valid(touch_event_valid),.event_data(touch_event_data),.panic_key(panic_key),.centre_key(centre_key),
  .page(page),.mode(mode),.knob_mode(knob_mode),.base_note(base_note),.centre(centre_touch),.panic(panic_touch),
  .clear_live(clear_live),.start_score(start_score),.stop_score(stop_score),.muted(muted),.restart_lesson(restart_lesson),.xy_config(xy_config),.spectrum_zoom(spectrum_zoom),.pattern_mode(pattern_mode),.pattern_start(pattern_start));
 wire[6:0]live_gates,live_triggers,knob,last_note,last_velocity,mod_depth,raw_knob;
 wire raw_known,pickup_wait;wire[48:0]live_notes;wire[83:0]live_gains;wire[18:0]ratio;
 wire sample_tick;wire signed[15:0]pcm;
 wire selected_valid=touch_event_valid||usb_event_valid;wire selected_ready,controller_ready;
 wire[31:0]selected_data=touch_event_valid?touch_event_data:usb_event_data;
 assign touch_event_ready=selected_ready;assign usb_event_ready=selected_ready&&!touch_event_valid;
 wire panic_all=panic_touch||panic_key||!usb_up_sync[1];
 assign selected_ready=controller_ready&&!clear_live&&!panic_all;
 wire pattern_select=mode==1&&pattern_mode!=0;
 wire selected_note_event=selected_data[7:4]==8||selected_data[7:4]==9;
 play_voice_control #(.RELATIVE_KNOB(1)) voices(.clk(clk),.rst(rst),.sample_tick(sample_tick),.event_valid(selected_valid&&selected_ready&&!(pattern_select&&selected_note_event)),.event_data(selected_data),.event_ready(controller_ready),
  .panic(panic_all||clear_live),.centre(centre_touch||centre_key),.gates(live_gates),.notes(live_notes),.gains(live_gains),.triggers(live_triggers),
  .ratio(ratio),.knob(knob),.last_note(last_note),.last_velocity(last_velocity),.mod_depth(mod_depth),
  .knob_mode(knob_mode),.raw_knob(raw_knob),.raw_known(raw_known),.pickup_wait(pickup_wait));
 reg touch_connected_q=0,muted_q=0;
 always @(posedge clk)if(rst)begin touch_connected_q<=0;muted_q<=0;end
 else begin touch_connected_q<=touch_state[1];muted_q<=muted;end
 wire touch_lost=touch_connected_q&&!touch_state[1];
 wire mute_enter=muted&&!muted_q;
 wire pattern_all_off=selected_valid&&selected_ready&&selected_data[7:4]==11&&
  !selected_data[15]&&!selected_data[23]&&(selected_data[14:8]==120||selected_data[14:8]==123);
 wire[6:0]pattern_selected,pattern_gates,pattern_triggers;
 wire[48:0]pattern_notes,pattern_sound_notes;wire[83:0]pattern_selected_gains,pattern_gains;
 wire pattern_busy,pattern_full;wire[2:0]pattern_count;
 p8_patterns patterns(.clk(clk),.rst(rst),.sample_tick(sample_tick),
  .cancel(panic_all||clear_live||stop_score||mute_enter||pattern_all_off||mode!=1||touch_lost),
  .pattern_mode(pattern_mode),.start(pattern_start),
  .event_valid(selected_valid&&selected_ready&&pattern_select),.event_data(selected_data),
  .selected(pattern_selected),.selected_notes(pattern_notes),.selected_gains(pattern_selected_gains),
  .gates(pattern_gates),.triggers(pattern_triggers),.notes(pattern_sound_notes),.gains(pattern_gains),
  .busy(pattern_busy),.count(pattern_count),.full(pattern_full));
 wire[6:0]perform_gates=pattern_select?pattern_gates:live_gates;
 wire[6:0]perform_triggers=pattern_select?pattern_triggers:live_triggers;
 wire[48:0]perform_notes=pattern_select?pattern_sound_notes:live_notes;
 wire[83:0]perform_gains=pattern_select?pattern_gains:live_gains;
 wire[6:0]gates,triggers,active;wire[48:0]notes;wire[83:0]gains;wire playing,score_done;wire[6:0]next_note;
 p8_audio_source sources(.clk(clk),.rst(rst),.sample_tick(sample_tick),.mode(mode),.start_score(start_score),.stop_score(stop_score),.panic(panic_all),.transition_mute(clear_live),.muted(muted),
  .live_gates(perform_gates),.live_triggers(perform_triggers),.live_notes(perform_notes),.live_gains(perform_gains),
  .gates(gates),.triggers(triggers),.notes(notes),.gains(gains),.playing(playing),.done(score_done),.next_note(next_note));
 wire[167:0]monitor_steps;wire[111:0]monitor_envelopes;
 play_audio audio(.clk(clk),.rst(rst),.gates(gates),.notes(notes),.gains(gains),.triggers(triggers),.ratio(ratio),.mod_depth(mod_depth),
  .sample_tick(sample_tick),.pcm(pcm),.hp_bck(hp_bck),.hp_ws(hp_ws),.hp_din(hp_din),
  .i2s_bck(i2s_bck),.i2s_ws(i2s_ws),.i2s_sd(i2s_sd),.active(active),.monitor_steps(monitor_steps),.monitor_envelopes(monitor_envelopes));
 wire[6:0]lesson_target,lesson_feedback_note,lesson_correct;wire[1:0]lesson_feedback;wire[5:0]lesson_position;wire lesson_done;wire[15:0]lesson_wrong;
 p8_lesson lesson(.clk(clk),.rst(rst),.sample_tick(sample_tick),.enabled(mode==3),.restart(restart_lesson),.base_note(base_note),
  .event_valid(selected_valid&&selected_ready),.event_data(selected_data),.panic(panic_all),
  .target_note(lesson_target),.feedback_note(lesson_feedback_note),.feedback(lesson_feedback),.position(lesson_position),.done(lesson_done),.correct_count(lesson_correct),.wrong_count(lesson_wrong));
 wire[6:0]ui_next_note=mode==3?lesson_target:mode==2?next_note:7'd127;
 wire[6:0]leading_note;wire[10:0]leading_pitch;wire[23:0]leading_step;wire[15:0]leading_envelope;wire leading_valid;
 wire[290:0]view;
 instrument_snapshot #(.WIDTH(291),.PERIOD(500)) ui_snapshot(.clk(clk),.rstn(!rst),
  .source_data({page,mode,playing,base_note,gates,notes,gains,knob,raw_knob,raw_known,pickup_wait,knob_mode,leading_note,last_velocity,mod_depth,spectrum_zoom,muted,leading_valid,ui_next_note,lesson_target,lesson_feedback_note,lesson_feedback,lesson_position,lesson_done,touch_state,pattern_mode,pattern_selected,pattern_notes,pattern_busy,pattern_count,pattern_full}),
  .pixel_clk(pixel_clk),.pixel_rstn(pixel_rstn),.frame_start(frame_start),.data(view));
 wire[2:0]vpage;wire[1:0]vmode,vknob_mode,vzoom;wire vplaying,vraw_known,vpickup,vmuted,vnote_valid,vlesson_done;
 wire[6:0]vnext,vlesson_target,vlesson_note;wire[1:0]vlesson_feedback;wire[5:0]vlesson_position;
 wire[1:0]vtouch_state,vpattern_mode;wire[6:0]vpattern_selected;wire[48:0]vpattern_notes;wire vpattern_busy,vpattern_full;wire[2:0]vpattern_count;
 wire[6:0]vbase,vgates,vknob,vraw,vnote,vvelocity,vmod;wire[48:0]vnotes;wire[83:0]vgains;
 assign {vpage,vmode,vplaying,vbase,vgates,vnotes,vgains,vknob,vraw,vraw_known,vpickup,vknob_mode,vnote,vvelocity,vmod,vzoom,vmuted,vnote_valid,vnext,vlesson_target,vlesson_note,vlesson_feedback,vlesson_position,vlesson_done,vtouch_state,vpattern_mode,vpattern_selected,vpattern_notes,vpattern_busy,vpattern_count,vpattern_full}=view;

 p8_leading_voice leading(.clk(clk),.rst(rst),.active(active),.notes(notes),.gains(gains),.steps(monitor_steps),.envelopes(monitor_envelopes),
  .leading_note(leading_note),.leading_pitch(leading_pitch),.leading_step(leading_step),.leading_envelope(leading_envelope),.leading_valid(leading_valid));
 wire[9:0]wave_addr,tone_addr;wire[6:0]spectrum_addr;wire[15:0]xy_addr;
 wire[47:0]wave_data;wire[7:0]spectrum_data,spectrum_peak;wire visual_valid,xy_data,xy_valid;
 wire[10:0]tone_data;wire[16:0]tone_curve;wire[9:0]tone_count;wire[5:0]xy_settings;
 p8_visuals visual(.clk(clk),.rst(rst||!video_up_sync[1]),.sample_tick(sample_tick),.pcm(pcm),
  .leading_note(leading_note),.leading_pitch(leading_pitch),.leading_step(leading_step),.leading_envelope(leading_envelope),.leading_valid(leading_valid),
  .restart(clear_live||start_score),.requested_config(xy_config),.pixel_clk(pixel_clk),.pixel_rstn(pixel_rstn),.frame_start(frame_start),
  .page(vpage),.x(x),.wave_addr(wave_addr),.spectrum_addr(spectrum_addr),.tone_addr(tone_addr),.xy_addr(xy_addr),
  .wave_data(wave_data),.spectrum_data(spectrum_data),.spectrum_peak(spectrum_peak),.visual_valid(visual_valid),
  .tone_data(tone_data),.tone_curve(tone_curve),.tone_count(tone_count),.xy_data(xy_data),.xy_valid(xy_valid),.xy_settings(xy_settings));
 wire[23:0]rgb;wire de,ohs,ovs;
 p8_panel panel(.pixel_clk(pixel_clk),.rstn(pixel_rstn),.den(den),.hsync(hs),.vsync(vs),.x(x),.y(y),
  .pattern_mode(vpattern_mode),.pattern_selected(vpattern_selected),.pattern_notes(vpattern_notes),.pattern_busy(vpattern_busy),.pattern_count(vpattern_count),.pattern_full(vpattern_full),
  .touch_state(vtouch_state),.page(vpage),.mode(vmode),.playing(vplaying),.muted(vmuted),.note_valid(vnote_valid),.next_note(vnext),
  .lesson_target(vlesson_target),.lesson_feedback_note(vlesson_note),.lesson_feedback(vlesson_feedback),.lesson_position(vlesson_position),.lesson_done(vlesson_done),.base_note(vbase),.gates(vgates),.notes(vnotes),.gains(vgains),
  .knob(vknob),.raw_knob(vraw),.raw_known(vraw_known),.pickup_wait(vpickup),.knob_mode(vknob_mode),.last_note(vnote),.last_velocity(vvelocity),.mod_depth(vmod),.spectrum_zoom(vzoom),
  .wave_data(wave_data),.spectrum_data(spectrum_data),.spectrum_peak(spectrum_peak),.visual_valid(visual_valid),
  .tone_data(tone_data),.tone_curve(tone_curve),.tone_count(tone_count),.xy_data(xy_data),.xy_valid(xy_valid),.xy_settings(xy_settings),
  .rgb(rgb),.den_out(de),.hsync_out(ohs),.vsync_out(ovs),.wave_addr(wave_addr),.spectrum_addr(spectrum_addr),.tone_addr(tone_addr),.xy_addr(xy_addr));

integer checks=0,accepted=0,commits=0,samples=0,nonzero=0,pubcount=0,i,physical_fixture_events=0,physical_note_events=0,events_before=0,mailbox_sent=0,handoff_cycles=0;
reg physical_fixture_phase=0;
reg[15:0] expected[0:2047];reg old_bank=0;
always @(posedge clk)if(!rst)begin
 if(clear_live||panic_all)begin check(!selected_ready,"source mode handoff revokes shared READY before voice/lesson accept");handoff_cycles=handoff_cycles+1;end
 if(selected_valid&&selected_ready)begin
  if(!selected_data[24])begin
   if(!physical_fixture_phase)$fatal(1,"physical MIDI forbidden in touch-only phase");physical_fixture_events=physical_fixture_events+1;
   if(selected_data[7:4]==8||selected_data[7:4]==9)physical_note_events=physical_note_events+1;
  end else accepted=accepted+1;
 end
 if(sample_tick)begin samples=samples+1;if(pcm!=0)nonzero=nonzero+1;end
 if(visual.fft.state==1&&sample_tick)expected[{visual.fft.bank,visual.fft.capture_index}]=pcm;
end
always @(posedge pixel_clk)begin #1;
 if(pixel_rstn&&visual.fft.display_bank!=old_bank)begin
  if(!frame_start)$fatal(1,"FFT bank changed inside frame");pubcount=pubcount+1;
 end
 old_bank=visual.fft.display_bank;
end
task check(input bit ok,input string msg);begin checks=checks+1;if(!ok)$fatal(1,"%s",msg);end endtask
task report(input integer index);
integer w;reg[31:0]address,value;begin
 for(w=0;w<6;w=w+1)begin
 @(negedge usb_clk);address=trace_words[index*12+w*2];value=trace_words[index*12+w*2+1];
 case(address)
 32'h02000200:shadow_status=value;32'h02000204:shadow_xy=value;
 32'h02000208:shadow_raw=value;32'h0200020c:shadow_vidpid=value;32'h02000210:shadow_meta=value;
 32'h02000214:begin touch_status_source=shadow_status;touch_xy_source=shadow_xy;touch_raw_source=shadow_raw;touch_vidpid_source=shadow_vidpid;touch_meta_source=shadow_meta;touch_toggle=~touch_toggle;commits=commits+1;end
 default:$fatal(1,"non-touch MMIO address");endcase end
 repeat(30)@(negedge clk);
end endtask
// Separate synthetic touch fixture used ONLY for additional lesson and disconnect coverage.
// Native HID->MMIO trace coverage remains exactly the first16 reports /96 pairs.
task fixture(input integer xx,yy,input bit down,valid);begin
 @(negedge usb_clk);touch_xy_source={yy[15:0],xx[15:0]};
 touch_status_source=shadow_status;touch_status_source[24]=down;touch_status_source[14]=valid;touch_status_source[12]=valid;
 touch_toggle=~touch_toggle;repeat(30)@(negedge clk);
end endtask
task tap(input integer xx,yy);begin fixture(xx,yy,1,1);fixture(xx,yy,0,1);end endtask
task syncview;begin repeat(3000)@(negedge pixel_clk);end endtask
task pixel(input integer xx,yy,input[23:0]want);begin
 @(negedge pixel_clk);x=xx;y=yy;repeat(12)@(negedge pixel_clk);
 if(rgb!==want)$display("pixel%0d,%0d got%h want%h",xx,yy,rgb,want);
 check(rgb===want,"production font/panel RGB");end endtask
task measure(output real period);
integer k,n,first,last;reg signed[15:0]prev;begin n=0;prev=0;first=0;last=0;
 for(k=0;k<2400;k=k+1)begin
 @(negedge clk);while(!sample_tick)@(negedge clk);
 if(k>800&&pcm>0&&prev<=0)begin if(!n)first=k;last=k;n=n+1;end
 prev=pcm;
 end
 check(n>=6,"actual final PCM periodic crossings");period=1.0*(last-first)/(n-1);
end endtask
integer a,maxbin,maxvalue;reg bankheld;real c4,c5;
task verify_graph(output integer fftbin);
integer q,pub;begin
 pub=pubcount;wait(pubcount>pub);frames_on=0;repeat(5)@(negedge pixel_clk);bankheld=visual.fft.display_bank;
 for(q=0;q<1024;q=q+1)begin
 @(negedge pixel_clk);x=q;y=300;repeat(2)@(negedge pixel_clk);
 check(wave_data[47:16]===0&&wave_data[15:0]===expected[{bankheld,q[9:0]}],"wave equals1024 consecutive actual mixed PCM samples");
 end
 // Address via production panel on spectrum page, zoom2 gives every bin.
 // Read producer data through direct read address force only during this DSP probe.
 maxvalue=0;maxbin=0;
 for(q=0;q<128;q=q+1)begin
 force spectrum_addr=q;repeat(2)@(negedge pixel_clk);
 if(spectrum_data>maxvalue)begin maxvalue=spectrum_data;maxbin=q;end
 end
 release spectrum_addr;fftbin=maxbin;check(maxvalue>0,"FFT nonzero actual PCM response");frames_on=1;
end endtask
task physical_word(input[31:0]word);begin
 @(negedge usb_clk);midi_source_data=word;midi_source_request=~midi_source_request;mailbox_sent=mailbox_sent+1;
 wait(midi_source_ack==midi_source_request);repeat(5)@(negedge clk);
end endtask
task physical_pc(input[6:0]raw);begin physical_word({16'd0,1'b0,raw,8'hc0});end endtask
integer song_i,physical_nonzero;
integer bin4,bin5;
initial begin
 $readmemh("sim/p8_touch_mmio_trace.hex",trace_words);
 $readmemh("sim/p8_midi_canonical_trace.hex",midi_trace);
 repeat(8)@(negedge clk);rst=0;pixel_rstn=1;
 // Enumeration/layout-ready is connected even before a valid input report.
 @(negedge usb_clk);touch_status_source=32'h00001f05;touch_toggle=~touch_toggle;
 repeat(30)@(negedge clk);syncview();
 check(!touch_good&&vtouch_state==2'b10,"configured HID before first touch displays connected/released");
 report(0);report(1);check(mode==1&&page==1,"native HID home perform");
 report(2);report(3);check(page==5,"native HID piano tab");
 report(4);check(live_gates==1&&live_notes[6:0]==60&&last_velocity==100,"native HID C4 allocation");
 measure(c4);check(active[0]&&nonzero>100,"touch without keyboard synthesizes real PCM");
 syncview();check(vgates==1&&vnotes[6:0]==60,"real snapshot C4");check(vtouch_state==2'b11,"native HID press reaches real frame-owned touch status");pixel(40,550,24'hf5c767);pixel(40,564,24'hf5c767);
 verify_graph(bin4);report(5);check(live_gates==0,"native HID C4 release");syncview();check(vtouch_state==2'b10,"native HID release remains connected and displays released");
 report(6);report(7);check(base_note==72,"native HID virtual octave");
 report(8);check(live_gates==1&&live_notes[6:0]==72,"native HID C5 allocation");measure(c5);
 check(c4>180&&c4<192&&c5>90&&c5<96&&c4/c5>1.98&&c4/c5<2.02,"actual PCM octave ratio");
 verify_graph(bin5);check(bin4>=5&&bin4<=6&&bin5>=10&&bin5<=12,"actual FFT follows touch octave");
 report(9);check(live_gates==0,"native HID C5 release");
 events_before=accepted;report(10);report(11);check(page==7&&page!=6,"native old controls slot now opens guide; removed page6 unreachable");
 tap(944,96);check(page==7,"removed seventh tab slot stays blank and cannot enter controls");
 tap(832,290);check(page==7&&knob==64&&accepted==events_before,"removed control slider has no bend event on guide");
 report(12);report(13);check(page==0&&knob_mode==1,"native HOME retains default relative knob mode1");
 report(14);report(15);check(knob==64&&accepted==events_before,"native HOME read-only strip emits zero note/bend events");
 check(commits==16&&accepted==4,"native96MMIOpairs16commits4virtualevents; removed slider produces no fifth E0");
 // Supplemental visual oracle: all15 independent white bodies and10 dark black bodies,
 // with the two repeated2+3 black-key groups and both edges of every2px seam.
 tap(180,32);tap(656,96);check(mode==1&&page==5,"piano remains reachable after removed control slot");
 syncview();
 for(i=0;i<15;i=i+1)begin
  pixel(40+64*i,550,24'hffffff);
  pixel(32+64*i,550,24'h36434e);pixel(33+64*i,550,24'h36434e);
 end
 for(i=0;i<14;i=i+1)begin
  if(i==0||i==1||i==3||i==4||i==5||i==7||i==8||i==10||i==11||i==12)pixel(96+64*i,320,24'h101010);
  else pixel(104+64*i,320,24'hffffff);
 end
 fixture(96,320,1,1);check(live_gates==1&&live_notes[6:0]==73,"touch black Csharp5 owns actual synthesis slot");
 syncview();pixel(96,320,24'hf5c767);pixel(78,320,24'hf5c767);pixel(90,444,24'hf5c767);
 fixture(96,320,0,1);check(live_gates==0,"touch black key releases actual synthesis slot");
 // Lesson fixture passes real bridge/nav/controller/lesson/snapshot/panel. No lesson output is injected.
 tap(480,32);check(muted,"follow prelude intentionally enables global mute");
 tap(40,32);tap(660,280);check(mode==3&&page==5&&lesson_target==72&&!muted,"follow entry retains virtual octave and restores audible mode");
 syncview();pixel(40,550,24'hf5c767);pixel(40,564,24'hf5c767);
 fixture(40,550,1,1);check(lesson_feedback==1&&lesson_position==1&&lesson_correct==1,"virtual correct note grades once");
 syncview();check(vlesson_feedback==1&&vlesson_note==72,"correct feedback crosses frame snapshot");pixel(40,550,24'h78e6af);pixel(40,564,24'h78e6af);
 fixture(40,550,0,1);fixture(96,320,1,1);check(lesson_feedback==2&&lesson_position==1&&lesson_wrong==1,"virtual wrong black note holds target");
 syncview();check(vlesson_feedback==2&&vlesson_note==73,"black wrong feedback crosses frame snapshot");
 pixel(96,320,24'he56c79);pixel(78,320,24'he56c79);pixel(90,444,24'he56c79);
 fixture(96,320,1,0);check(live_gates==0,"touch disconnect releases virtual black voice");syncview();check(vtouch_state==0,"disconnect clears both displayed touch state bits");
 // Explicit supplemental physical-controller fixture; native/lesson phase above remained0MIDI.
 check(physical_fixture_events==0,"all native/lesson PCM+RGB checks used zero physical events");
 tap(40,32);check(page==0,"home display-only strip");
 // User removed only the header CENTRE; actual hardware KEY2 shortcut retained.
 @(negedge clk);centre_key=1;@(negedge clk);centre_key=0;repeat(5)@(negedge clk);
 check(knob==64,"explicit simulated hardware KEY2 shortcut centres actual controller");
 physical_fixture_phase=1;
 physical_pc(110);check(raw_known&&raw_knob==110&&knob==64,"first physical110 anchors relative64");
 syncview();check(vknob==64&&vraw==110,"physical anchor across actual frame snapshot");pixel(522,410,24'h162630);
 physical_pc(111);check(raw_knob==111&&knob==65,"physical111 increments shared relative65");
 syncview();check(vknob==65&&vraw==111,"physical increment crosses actual frame snapshot");pixel(522,410,24'hf5c767);
 events_before=accepted;fixture(260,430,1,1);fixture(770,430,1,1);fixture(770,430,0,1);
 check(accepted==events_before&&knob==65&&page==0,"home display-only strip ignores touch and drag without E0 packet");
 check(physical_fixture_events==2,"exact2 supplemental physical PC packets");
 // Actual production firmware-decoded canonical words cross real USB48/audio50 CDC.
 tap(480,32);check(muted,"perform prelude intentionally enables global mute");
 tap(180,32);tap(656,96);check(mode==1&&page==5&&!muted,"physical perform entry restores audible mode");
 physical_word(midi_trace[2]);check(live_gates==1&&live_notes[6:0]==72,"physical NoteOn through mailbox allocates live voice");
 physical_nonzero=0;
 repeat(256)begin @(negedge clk);while(!sample_tick)@(negedge clk);if(pcm!=0)physical_nonzero=physical_nonzero+1;end
 check(active[0]&&physical_nonzero>100,"physical-source perform produces actual synthesized PCM");
 syncview();check(vgates==1&&vnotes[6:0]==72,"physical live note crosses frame snapshot");pixel(40,550,24'hf5c767);pixel(40,564,24'hf5c767);
 physical_word(midi_trace[3]);check(live_gates==0,"physical mailbox NoteOff releases only its note");
 // Same-pitch virtual and physical ownership coexist and release independently in BOTH orders.
 physical_word(midi_trace[2]);fixture(40,550,1,1);
 check(live_gates==3&&live_notes[6:0]==72&&live_notes[13:7]==72,"same note two sources own separate live slots");
 physical_word(midi_trace[3]);check(live_gates==2,"physical NoteOff leaves virtual same-pitch slot held");
 fixture(40,550,0,1);check(live_gates==0,"virtual release clears remaining own slot");
 fixture(40,550,1,1);physical_word(midi_trace[2]);check(live_gates==3,"reverse allocation still owns two independent slots");
 fixture(40,550,0,1);check(live_gates==2,"virtual NoteOff leaves physical same-pitch slot held");
 physical_word(midi_trace[3]);check(live_gates==0,"physical final release clears remaining own slot");
 // Complete physical42-note lesson, with actual wrong/red and correct/green rendering.
 tap(40,32);tap(660,280);check(mode==3&&page==5&&lesson_position==0&&lesson_target==72,"physical lesson starts with same target as virtual lesson");
 physical_word(midi_trace[0]);check(lesson_feedback==2&&lesson_wrong==1&&lesson_position==0&&live_gates==1,"physical wrong note heard and graded without advancing target");
 syncview();check(vlesson_feedback==2&&vlesson_note==74,"physical wrong feedback crosses frame snapshot");pixel(110,550,24'he56c79);pixel(110,564,24'he56c79);
 physical_word(midi_trace[1]);check(live_gates==0,"physical wrong note releases through CDC");
 for(song_i=0;song_i<42;song_i=song_i+1)begin
  physical_word(midi_trace[2+song_i*2]);
  check(lesson_feedback==1&&lesson_position==song_i+1&&lesson_correct==song_i+1&&live_gates==1,"each physical Twinkle press grades and owns actual audio voice");
  if(song_i==0)begin
   syncview();check(vlesson_feedback==1&&vlesson_note==72,"physical correct feedback crosses frame snapshot");pixel(40,550,24'h78e6af);pixel(40,564,24'h78e6af);
  end
  physical_word(midi_trace[3+song_i*2]);check(live_gates==0,"every physical Twinkle release clears actual live gate");
 end
 check(lesson_done&&lesson_correct==42&&lesson_wrong==1,"complete physical42-note Twinkle preserves wrong count");
 check(handoff_cycles==5,"real navigation mode entries exercised gated READY");
 check(physical_note_events==92&&physical_fixture_events==94&&mailbox_sent==94,"canonical physical note/PC count accepted exactly once via real mailbox");
 $display("P8_E2E_PASS checks=%0d native_pairs=96 native_commits=%0d native_virtual_events=4 total_virtual_events=%0d noMIDIphaseEvents=0 samples=%0d nonzero=%0d exactPCM=2048 C4=%f C5=%f ratio=%f FFT4=%0d FFT5=%0d physicalPC=2 physicalNotes=%0d mailboxEvents=%0d physicalLessonNotes=42 physicalPCMnonzero=%0d handoffCycles=%0d UIlatency=8",checks,commits,accepted,samples,nonzero,c4,c5,c4/c5,bin4,bin5,physical_note_events,physical_fixture_events,physical_nonzero,handoff_cycles);$finish;
end
initial begin #400000000;$fatal(1,"P8 E2E deadline");end
endmodule
