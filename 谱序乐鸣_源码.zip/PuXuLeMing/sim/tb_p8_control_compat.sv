`timescale 1ns/1ps
module tb_p8_control_compat;
 reg clk=0;always #10 clk=~clk;
 reg rst=1,sample_tick=0,event_valid=0,panic=0,centre=0;reg[31:0]event_data=0;reg[1:0]knob_mode=1;
 wire event_ready,event_ready_r,event_ready_p;
 wire[6:0]gates,triggers,knob,last_note,last_velocity,mod_depth,raw_knob;
 wire raw_known,pickup_wait;
 wire[6:0]gates_r,triggers_r,knob_r,last_note_r,last_velocity_r,mod_depth_r;
 wire[6:0]gates_p,triggers_p,knob_p,last_note_p,last_velocity_p,mod_depth_p;
 wire[48:0]notes,notes_r,notes_p;wire[83:0]gains,gains_r,gains_p;wire[18:0]ratio,ratio_r,ratio_p;
 play_voice_control dut(.*);
 play_voice_control_p8_baseline baseline(.clk(clk),.rst(rst),.sample_tick(sample_tick),.event_valid(event_valid),.event_data(event_data),.panic(panic),.centre(centre),.event_ready(event_ready_r),.gates(gates_r),.triggers(triggers_r),.notes(notes_r),.gains(gains_r),.ratio(ratio_r),.knob(knob_r),.last_note(last_note_r),.last_velocity(last_velocity_r),.mod_depth(mod_depth_r));
 play_voice_control #(.RELATIVE_KNOB(1)) p8(.knob_mode(knob_mode),.raw_knob(),.raw_known(),.pickup_wait(),.clk(clk),.rst(rst),.sample_tick(sample_tick),.event_valid(event_valid),.event_data(event_data),.panic(panic),.centre(centre),.event_ready(event_ready_p),.gates(gates_p),.triggers(triggers_p),.notes(notes_p),.gains(gains_p),.ratio(ratio_p),.knob(knob_p),.last_note(last_note_p),.last_velocity(last_velocity_p),.mod_depth(mod_depth_p));
 reg[31:0]rng=32'h24b6c831;integer k,cycles=0,events=0;
 task random_next;begin rng=rng^(rng<<13);rng=rng^(rng>>17);rng=rng^(rng<<5);end endtask
 always @(posedge clk)begin
  #1;
  if({event_ready,gates,triggers,notes,gains,ratio,knob,last_note,last_velocity,mod_depth}!=={event_ready_r,gates_r,triggers_r,notes_r,gains_r,ratio_r,knob_r,last_note_r,last_velocity_r,mod_depth_r})
   $fatal(1,"legacy all-output cycle mismatch cycle%0d event%h",cycles,event_data);
  if({event_ready_p,gates_p,triggers_p,notes_p,gains_p,last_note_p,last_velocity_p,mod_depth_p}!=={event_ready_r,gates_r,triggers_r,notes_r,gains_r,last_note_r,last_velocity_r,mod_depth_r})
   $fatal(1,"P8 notes/MOD ownership cycle mismatch cycle%0d event%h",cycles,event_data);
  cycles++;
 end
 initial begin
  repeat(5)@(negedge clk);rst=0;
  for(k=0;k<100000;k++)begin
   @(negedge clk);random_next();
   event_valid=rng[1:0]!=0;sample_tick=rng[4:2]==0;panic=rng[15:4]==0;centre=rng[18:8]==0;
   knob_mode=rng[10:9];
   event_data={7'd0,rng[31],1'b0,rng[30:24],1'b0,rng[23:17],4'h9,2'd0,rng[16:15]};
   case(rng[7:5])
    0,1,2:event_data[7:4]=9;
    3:event_data[7:4]=8;
    4:begin event_data[7:4]=11;case(rng[10:8])0:event_data[15:8]=64;1:event_data[15:8]=120;2:event_data[15:8]=123;3:event_data[15:8]=74;default:event_data[15:8]=1;endcase end
    5:event_data[7:4]=12;
    6:event_data[7:4]=14;
    7:if(rng[12])event_data[7:0]=8'hff;
   endcase
   if(event_valid)events++;
  end
  @(negedge clk);event_valid=0;panic=0;centre=0;repeat(10)@(negedge clk);
  $display("PASS tb_p8_control_compat cycles=%0d events=%0d legacy alloutputs/P8 notes+MOD cycle exact",cycles,events);$finish;
 end
endmodule
