`timescale 1ns/1ps
module tb_p8_gesture_watchdog;
 reg clk=0,rst=1,rx=1;always #10 clk=~clk;
 wire tx,valid;wire[31:0]data;
 p8_gesture_link dut(.clk(clk),.rst(rst),.rx(rx),.tx(tx),.event_valid(valid),.event_data(data),.event_ready(1'b1),
  .clear_notes(1'b0),.playable(1'b1),.muted(1'b0),.mode(2'd0),.pattern_mode(2'd0),.page(3'd0),.gates(7'd0),.last_note(7'd0));
 reg[7:0]stimulus[0:611];string outdir;
 integer cycles=0,on_at=0,off_at=0,ons=0,offs=0;
 always @(posedge clk)if(!rst)begin
  cycles=cycles+1;
  if(valid&&data[7:4]==9)begin ons=ons+1;on_at=cycles;end
  if(valid&&data[7:4]==8)begin offs=offs+1;off_at=cycles;end
 end
 task send_byte(input[7:0]b);integer j;begin
  @(negedge clk);rx=0;repeat(434)@(negedge clk);
  for(j=0;j<8;j=j+1)begin rx=b[j];repeat(434)@(negedge clk);end
  rx=1;repeat(434)@(negedge clk);
 end endtask
 integer k;
 initial begin
  if(!$value$plusargs("OUTDIR=%s",outdir))$fatal(1,"OUTDIR required");
  $readmemh({outdir,"/stimulus.hex"},stimulus);
  repeat(10)@(negedge clk);rst=0;
  for(k=18;k<36;k=k+1)send_byte(stimulus[k]);
  repeat(25100000)@(negedge clk);
  if(ons!=1||offs!=1||off_at-on_at<24950000||off_at-on_at>25000010)$fatal(1,"actual500ms watchdog incorrect %0d/%0d delta=%0d",ons,offs,off_at-on_at);
  $display("P8_GESTURE_WATCHDOG_PASS ons=%0d offs=%0d delta_cycles=%0d",ons,offs,off_at-on_at);$finish;
 end
endmodule
