`timescale 1ns/1ps
module map_apply_local_case #(parameter BOUNDARY_ONLY=0)(output reg done=0);
 reg clk=0;always #10 clk=~clk;
 reg rst=1,abort_transaction=0,command_valid=0,key_seen_valid=0;
 reg[7:0]command_op=0;reg[31:0]command_a=0,command_b=0,command_c=0;reg[4:0]key_seen_index=0;
 wire cd[0:1],ma[0:1],me[0:1];wire[7:0]res[0:1];wire[174:0]mn[0:1];wire[6:0]mb[0:1];wire[31:0]ra[0:1],rb[0:1];
 wire local_audio,local_fx;
 poly_keymap dut(.command_done(cd[0]),.command_result(res[0]),.map_notes(mn[0]),.map_input_base(mb[0]),.map_enabled(me[0]),.map_apply(ma[0]),.reply_a(ra[0]),.reply_b(rb[0]),.map_apply_audio(local_audio),.map_apply_fx(local_fx),.*);
 poly_keymap_before_local_apply reference(.command_done(cd[1]),.command_result(res[1]),.map_notes(mn[1]),.map_input_base(mb[1]),.map_enabled(me[1]),.map_apply(ma[1]),.reply_a(ra[1]),.reply_b(rb[1]),.*);
 function automatic[15:0]cb(input[15:0]c,input[7:0]b);
  reg[15:0]v;integer n;begin v=c^{b,8'd0};for(n=0;n<8;n++)v=v[15]?(v<<1)^16'h1021:v<<1;cb=v;end
 endfunction
 integer copy_checks=0;
 always @(negedge clk)begin
  #1;
  if({local_audio,local_fx} !== {2{ma[0]}})$fatal(1,"MAP_COPY_CYCLE_EQ");
  if({cd[0],res[0],mn[0],mb[0],me[0],ma[0],ra[0],rb[0]} !== {cd[1],res[1],mn[1],mb[1],me[1],ma[1],ra[1],rb[1]})$fatal(1,"MAP_CURRENT_REFERENCE_CYCLE_EQ");
  copy_checks++;
 end
 integer ticks=0,apply_cycle[0:1],applies[0:1],checks=0,transactions=0,crc_decisions=0,abort_checks=0,phase3_aborts=0,commit_aborts=0;
 always @(posedge clk)ticks++;
 always @(negedge clk)if(!rst)begin
  if(ma[0])begin apply_cycle[0]=ticks;applies[0]++;if(dut.phase!=2||cd[0])$fatal(1,"CRC_APPLY_COMMIT_ORDER");end
  if(ma[1])begin apply_cycle[1]=ticks;applies[1]++;end
 end
 task command(input[7:0]op,input[31:0]a,b,input integer shift,input[7:0]expected);
  integer t,d0,d1;reg g0,g1;reg[7:0]r0,r1;
  begin
   @(negedge clk);command_op=op;command_a=a;command_b=b;command_c=0;command_valid=1;
   @(negedge clk);command_valid=0;g0=0;g1=0;t=0;d0=0;d1=0;
   while(!(g0&&g1)&&t<80)begin
    if(cd[0]&&!g0)begin g0=1;d0=t;r0=res[0];end
    if(cd[1]&&!g1)begin g1=1;d1=t;r1=res[1];end
    @(negedge clk);t++;
   end
   if(!g0||!g1||r0!==r1||r0!==expected||d0-d1!=shift)$fatal(1,"CRC_COMMAND_ORACLE op%0d status%0d/%0d delay%0d/%0d expectShift%0d",op,r0,r1,d0,d1,shift);
   if({mn[0],mb[0],me[0],ra[0],rb[0]}!=={mn[1],mb[1],me[1],ra[1],rb[1]})$fatal(1,"CRC_TRANSACTION_STATE_EQ op%0d",op);
   if(op==22&&d0>1)begin
    crc_decisions++;
    if(expected==0&&(apply_cycle[0]-apply_cycle[1]!=0||ticks-apply_cycle[0]!=2))$fatal(1,"CRC_CLEAR_BEFORE_COMMIT");
   end
   checks++;transactions++;
  end
 endtask
 reg[31:0]rng=32'h35c97ae1;reg[6:0]table_notes[0:24];reg[15:0]checksum;
 integer round,k,idx,offset;reg[6:0]base;reg enabled;
 initial begin
  for(k=0;k<2;k++)begin apply_cycle[k]=-1000;applies[k]=0;end
  repeat(4)@(negedge clk);rst=0;
  if(BOUNDARY_ONLY)begin
   command(20,60,1,0,0);checksum=cb(cb(16'hffff,60),1);
   for(k=0;k<25;k++)begin command(21,k,60+k,0,0);checksum=cb(checksum,60+k);end
   @(negedge clk);command_op=22;command_a=checksum;command_b=0;command_valid=1;
   @(negedge clk);command_valid=0;
   wait(dut.phase==1&&dut.crc_index==26);@(posedge clk);#1;
   if(dut.phase!==2'd3||dut.crc!==checksum||ma[0])$fatal(1,"CRC_FINAL_REGISTER_BOUNDARY_MISSING");
   force dut.next_crc=16'h0000;
   @(posedge clk);#1;if(!ma[0]||cd[0])$fatal(1,"CRC_REGISTER_DECISION_FAILED");
   @(posedge clk);#1;if(!cd[0]||res[0]!=0||rb[0][15:0]!=checksum)$fatal(1,"CRC_REGISTER_COMMIT_FAILED");
   release dut.next_crc;
   $display("KEYMAP_CRC_BOUNDARY_PASS finalCRCregister before compare,apply-before-bank,oneClockCompletion");done=1;
  end else begin
   command(22,0,0,0,5);command(21,0,67,0,1);
   for(round=0;round<64;round++)begin
    rng={rng[30:0],rng[31]^rng[21]^rng[1]^rng[0]};base=rng%104;enabled=rng[9];
    command(20,base,enabled,0,0);
    for(k=0;k<25;k++)begin
     rng={rng[30:0],rng[31]^rng[21]^rng[1]^rng[0]};table_notes[k]=k==0?0:k==24?127:rng[6:0];
    end
    for(k=0;k<25;k++)begin idx=(k*7+round)%25;command(21,idx,table_notes[idx],0,0);end
    checksum=cb(cb(16'hffff,base),enabled);for(k=0;k<25;k++)checksum=cb(checksum,table_notes[k]);
    command(22,checksum^16'h4001,1,0,5);command(22,checksum,0,0,0);
    for(k=0;k<25;k++)begin command(23,k,0,0,0);if(ra[0][15:8]!=={1'b0,table_notes[k]})$fatal(1,"CRC_ALL25_GET");end
   end
   for(offset=0;offset<=28;offset++)begin
    @(negedge clk);rst=1;abort_transaction=0;command_valid=0;repeat(3)@(negedge clk);rst=0;
    command(20,48,0,0,0);checksum=cb(cb(16'hffff,48),0);
    for(k=0;k<25;k++)begin command(21,k,67,0,0);checksum=cb(checksum,67);end
    @(negedge clk);command_op=22;command_a=checksum;command_b=0;command_valid=1;if(offset==0)abort_transaction=1;
    @(negedge clk);command_valid=0;
    if(offset>0)begin repeat(offset-1)@(negedge clk);if(dut.phase==3)phase3_aborts++;abort_transaction=1;@(negedge clk);end
    if(!cd[0]||!cd[1]||res[0]!=4||res[1]!=4||{mn[0],mb[0],me[0],rb[0]}!=={mn[1],mb[1],me[1],rb[1]})$fatal(1,"CRC_ABORT_ORACLE offset%0d",offset);
    abort_transaction=0;repeat(35)@(negedge clk);
    if(dut.phase!=0||dut.uploading||mb[0]!=60||mn[0][6:0]!=60)$fatal(1,"CRC_ABORT_LATE_COMMIT");abort_checks++;
   end
   // The additional clock also moves the final cancelable commit edge.
   // At this wall clock the old transaction has already completed; compare
   // the candidate to its pre-transaction bank, not to an artificially delayed old ACK.
   @(negedge clk);rst=1;repeat(3)@(negedge clk);rst=0;
   command(20,48,0,0,0);checksum=cb(cb(16'hffff,48),0);
   for(k=0;k<25;k++)begin command(21,k,67,0,0);checksum=cb(checksum,67);end
   @(negedge clk);command_op=22;command_a=checksum;command_b=0;command_valid=1;
   @(negedge clk);command_valid=0;wait(dut.phase==2);@(negedge clk);abort_transaction=1;
   @(negedge clk);
   if(!cd[0]||res[0]!=4||mb[0]!=60||!me[0])$fatal(1,"CRC_COMMIT_EDGE_ABORT");
   for(k=0;k<25;k++)if(mn[0][k*7+:7]!=60+k)$fatal(1,"CRC_COMMIT_EDGE_BANK_CHANGED");
   abort_transaction=0;repeat(35)@(negedge clk);if(dut.phase!=0||dut.uploading||mn[0][6:0]!=60)$fatal(1,"CRC_COMMIT_EDGE_LATE_SWAP");commit_aborts++;
   if(phase3_aborts==0||crc_decisions!=128||abort_checks!=29||commit_aborts!=1)$fatal(1,"CRC_COVERAGE");
   $display("MAP_APPLY_LOCAL_EQUIV_PASS transactions%0d checks%0d crcDecisions%0d tables64 GET1600 abortOffsets29 phase3aborts%0d commitEdgeAbort%0d privateOldCRC/table/statusEqual sameClockCopies",transactions,checks,crc_decisions,phase3_aborts,commit_aborts);done=1;
  end
 end
 initial begin #20000000;$fatal(1,"CRC_TEST_TIMEOUT");end
endmodule
module tb_map_apply_local_equiv;
 wire done;map_apply_local_case t(done);initial begin wait(done);$finish;end
endmodule
