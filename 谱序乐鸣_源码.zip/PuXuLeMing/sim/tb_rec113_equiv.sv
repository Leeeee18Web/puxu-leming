`timescale 1ns/1ps
module rec113_case #(parameter N=7,CAP=64,CASE_ID=0,FRAME=64,PREVIEW=0)(output reg done=0);
 reg clk=0,rst=1;always #10 clk=~clk;
 reg[$clog2(FRAME)-1:0]phase=0;always @(posedge clk)phase<=phase+1'b1;
 wire sample_tick=phase==FRAME-1;
 reg record_toggle=0,replay_toggle=0,clear=0,panic=0;
 reg[N-1:0]in_gates=0,in_triggers=0;reg[N*7-1:0]in_notes=0;
 reg[N*12-1:0]in_gains=0;reg[N*3-1:0]in_timbres=0;reg[18:0]in_ratio=262144;
 reg[6:0]in_mod_depth=0;reg[31:0]in_synth_config=0;
 wire[N-1:0]g[0:1],t[0:1];wire[N*7-1:0]n[0:1];wire[N*12-1:0]v[0:1];wire[N*3-1:0]tm[0:1];wire[18:0]r[0:1];wire[6:0]m[0:1];wire[31:0]c[0:1];
 wire rec[0:1],play[0:1],full[0:1],limit[0:1],ready[0:1];wire[12:0]count[0:1];wire[31:0]time_samples[0:1],duration[0:1];
 wire[95:0] exported[0:1];wire er[0:1];wire[31:0]take[0:1];

 reg pipe_rst=0;
 wire[N-1:0] admitted_gates,admitted_triggers;
 wire[N*7-1:0] admitted_notes;wire[N*12-1:0] admitted_gains;wire[N*3-1:0] admitted_timbres;
 wire[18:0] admitted_ratio;wire[6:0] admitted_mod_depth;wire[31:0] admitted_synth_config;
 generate if(PREVIEW)begin:real_pipe
  final_sound_pipe #(.VOICE_COUNT(N)) ingress(.clk(clk),.rst(pipe_rst),
   .in_gates(in_gates),.in_triggers(in_triggers),.in_notes(in_notes),.in_gains(in_gains),.in_timbres(in_timbres),
   .in_ratio(in_ratio),.in_mod(in_mod_depth),.in_config(in_synth_config),
   .gates(admitted_gates),.triggers(admitted_triggers),.notes(admitted_notes),.gains(admitted_gains),.timbres(admitted_timbres),
   .ratio(admitted_ratio),.mod_depth(admitted_mod_depth),.config_word(admitted_synth_config));
 end else begin:direct
 assign admitted_gates=in_gates;
 assign admitted_triggers=in_triggers;
 assign admitted_notes=in_notes;
 assign admitted_gains=in_gains;
 assign admitted_timbres=in_timbres;
 assign admitted_ratio=in_ratio;
 assign admitted_mod_depth=in_mod_depth;
 assign admitted_synth_config=in_synth_config;
 end endgenerate
 final_recorder #(.EVENT_CAPACITY(CAP),.MAX_SAMPLES(40),.VOICE_COUNT(N),.PREVIEW_INPUT(PREVIEW))dut(.preview_rst(pipe_rst),.preview_gates(in_gates),.preview_notes(in_notes),.preview_gains(in_gains),.preview_timbres(in_timbres),.preview_ratio(in_ratio),.preview_mod_depth(in_mod_depth),.preview_synth_config(in_synth_config),.observer_gains(),.clk(clk),.rst(rst),.sample_tick(sample_tick),.record_toggle(record_toggle),.replay_toggle(replay_toggle),.clear(clear),.panic(panic),
  .in_gates(admitted_gates),.in_triggers(admitted_triggers),.in_notes(admitted_notes),.in_gains(admitted_gains),.in_timbres(admitted_timbres),.in_ratio(admitted_ratio),.in_mod_depth(admitted_mod_depth),.in_synth_config(admitted_synth_config),
  .out_gates(g[0]),.out_triggers(t[0]),.out_notes(n[0]),.out_gains(v[0]),.out_timbres(tm[0]),.out_ratio(r[0]),.out_mod_depth(m[0]),.out_synth_config(c[0]),
  .recording(rec[0]),.replaying(play[0]),.full(full[0]),.time_limit(limit[0]),.replay_frame_ready(ready[0]),.count(count[0]),.time_samples(time_samples[0]),.duration_samples(duration[0]),.export_address(12'd0),.export_word(exported[0]),.export_ready(er[0]),.take_id(take[0]));
 rec113_old_recorder #(.EVENT_CAPACITY(CAP),.MAX_SAMPLES(40),.VOICE_COUNT(N))reference(.observer_gains(),.clk(clk),.rst(rst),.sample_tick(sample_tick),.record_toggle(record_toggle),.replay_toggle(replay_toggle),.clear(clear),.panic(panic),
  .in_gates(admitted_gates),.in_triggers(admitted_triggers),.in_notes(admitted_notes),.in_gains(admitted_gains),.in_timbres(admitted_timbres),.in_ratio(admitted_ratio),.in_mod_depth(admitted_mod_depth),.in_synth_config(admitted_synth_config),
  .out_gates(g[1]),.out_triggers(t[1]),.out_notes(n[1]),.out_gains(v[1]),.out_timbres(tm[1]),.out_ratio(r[1]),.out_mod_depth(m[1]),.out_synth_config(c[1]),
  .recording(rec[1]),.replaying(play[1]),.full(full[1]),.time_limit(limit[1]),.replay_frame_ready(ready[1]),.count(count[1]),.time_samples(time_samples[1]),.duration_samples(duration[1]),.export_address(12'd0),.export_word(exported[1]),.export_ready(er[1]),.take_id(take[1]));
 integer voice_index;
 reg prior_export_ready=0;
 reg prior_capture_busy=0;
 integer writes=0,reject_capacity=0,reject_limit=0,reject_busy=0,clear_busy=0,new_takes=0,late_events=0,late_replay=0,boundary_priority=0;reg previous_difference=0;
 integer ram_checks=0,ram_index,prep_cycles=0,max_prep=0,raw_differences=0;
 integer checks=0,frames=0,plays=0,fulls=0,limits=0,seed=32'h31415926,k,j;
 wire scratch_difference={dut.previous_gates,dut.previous_notes,dut.previous_gains,dut.previous_timbres,dut.previous_ratio,dut.previous_mod,dut.previous_config,
  dut.capture_mask,dut.captured_time,dut.captured_gates,dut.captured_triggers,dut.captured_notes,dut.captured_gains,dut.captured_timbres,dut.captured_ratio,dut.captured_mod,dut.captured_config} !==
  {reference.previous_gates,reference.previous_notes,reference.previous_gains,reference.previous_timbres,reference.previous_ratio,reference.previous_mod,reference.previous_config,
  reference.capture_mask,reference.captured_time,reference.captured_gates,reference.captured_triggers,reference.captured_notes,reference.captured_gains,reference.captured_timbres,reference.captured_ratio,reference.captured_mod,reference.captured_config};
 reg dw,rw;reg[12:0]wa;
 always @(posedge clk)if(!rst)begin
  if(dut.recording&&!dut.capture_busy&&dut.capacity_limits_q!==dut.capacity_exceeded)$fatal(1,"CAPACITY_LIMITS_NOT_SETTLED_BEFORE_ADMISSION");
  // Observe actual old/new write transactions before the edge, then compare
  // their real RAM words after NBA. No synthesized implementation is the expect.
  dw=dut.capture_busy&&dut.capture_mask[dut.capture_index];
  rw=reference.capture_busy&&reference.capture_mask[reference.capture_index];wa=reference.write_index;
  if(dw!==rw||(rw&&dut.write_index!==reference.write_index))$fatal(1,"PREPARE_WRITE_INTENT");
  if(sample_tick)begin
   if(reference.cmd_clear||reference.cmd_panic)begin if(reference.capture_busy)clear_busy++;end
   else if(reference.start_take)new_takes++;
   else if(reference.recording)begin
    if(reference.capture_busy)reject_busy++;
    else if(reference.record_time+1>=40)reject_limit++;
    else if(reference.record_capacity_exceeded)reject_capacity++;
   end
  end
  #1;if(rw)begin
   if($isunknown(dut.event_ram[wa[11:0]])||dut.event_ram[wa[11:0]]!==reference.event_ram[wa[11:0]])$fatal(1,"PREPARE_ACTUAL_RAM_TRANSACTION");writes++;
  end
 end
 always @(negedge clk)if(!rst)begin
  checks++;
  if({dut.changed,dut.initial_changed,dut.changed_count,dut.initial_count,dut.observer_gains} !==
     {reference.changed,reference.initial_changed,reference.changed_count,reference.initial_count,reference.observer_gains})
   $fatal(1,"REC113_COMPARE_COHORT_EVERY_CLOCK N%0d PRV%0d clk%0d phase%0d changed%h ref%h",N,PREVIEW,checks,phase,dut.changed,reference.changed);
  if(scratch_difference)$fatal(1,"REC113_ALL_SCRATCH_STRICT");
  if(scratch_difference)begin
   if(dut.recording||dut.capture_busy)$fatal(1,"PREPARE_LIVE_FRAME_SCRATCH");
   if(!previous_difference&&!full[0]&&!limit[0])$fatal(1,"PREPARE_UNEXPLAINED_FIRST_SCRATCH_DELTA");
  end
  previous_difference=scratch_difference;
  if({dut.capture_busy,dut.capture_index,dut.write_index}!=={reference.capture_busy,reference.capture_index,reference.write_index})$fatal(1,"RECORDER_WRITER_TIMING");
  if(prior_capture_busy&&!dut.capture_busy)begin
   for(ram_index=0;ram_index<count[0];ram_index=ram_index+1)begin
    if($isunknown(dut.event_ram[ram_index])||dut.event_ram[ram_index]!==reference.event_ram[ram_index])$fatal(1,"RECORDER_RAM_DATA address=%0d",ram_index);
    ram_checks++;
   end
  end
  prior_capture_busy=dut.capture_busy;
  if({dut.replay_state,dut.replay_index,dut.read_address,dut.record_time,dut.replay_time,dut.replay_after_capture,dut.mute_frame} !==
     {reference.replay_state,reference.replay_index,reference.read_address,reference.record_time,reference.replay_time,reference.replay_after_capture,reference.mute_frame})$fatal(1,"CONFIG_CAPACITY_INTERNAL_EVERY_CLOCK");
  // Admission controls remain exact. Only rejected, unconsumed frame scratch
  // may differ; a live writer must always consume the original mask/time.
  if({dut.capture_mask,dut.captured_time}!=={reference.capture_mask,reference.captured_time})begin
   if(dut.capture_busy||dut.recording)$fatal(1,"CONFIG_CAPACITY_CONSUMED_SCRATCH");
   raw_differences++;
  end
  if(play[0]&&!ready[0])begin prep_cycles++;if(prep_cycles>max_prep)max_prep=prep_cycles;end else prep_cycles=0;
  if({g[0],t[0],n[0],v[0],tm[0],r[0],m[0],c[0],ready[0]}!=={g[1],t[1],n[1],v[1],tm[1],r[1],m[1],c[1],ready[1]})$fatal(1,"CONFIG_CAPACITY_PUBLIC_EVERY_CLOCK");
  // Capacity-only refactor: every output and internal transport state stays same-clock.
  if({er[0],take[0],rec[0],play[0],full[0],limit[0],count[0],time_samples[0],duration[0]}!==
     {er[1],take[1],rec[1],play[1],full[1],limit[1],count[1],time_samples[1],duration[1]})
   $fatal(1,"RECORDER_METADATA clock=%0d phase=%0d",checks,phase);
  if(er[0]&&prior_export_ready&&exported[0]!==exported[1])$fatal(1,"RECORDER_EXPORT_WORD");
  prior_export_ready=er[0];
  if(sample_tick)begin
   if(ready[0]!==ready[1]||(FRAME>N+1&&play[0]&&!ready[0]))$fatal(1,"RECORDER_FRAME_NOT_READY");
   if({g[0],t[0],n[0],v[0],tm[0],r[0],m[0],c[0]}!=={g[1],t[1],n[1],v[1],tm[1],r[1],m[1],c[1]})
    $fatal(1,"RECORDER_AUDIO_FRAME clock=%0d",checks);
  end
  if(sample_tick)begin frames++;if(play[0])plays++;if(full[0])fulls++;if(limit[0])limits++;end
 end
 task frame(input bit record_cmd,replay_cmd);begin
  @(posedge clk);while(phase!=10)@(posedge clk);
  @(negedge clk);record_toggle=record_cmd;replay_toggle=replay_cmd;
  @(negedge clk);record_toggle=0;replay_toggle=0;
  @(posedge sample_tick);repeat(3)@(posedge clk);
 end endtask
 task last_cycle_event(input [6:0] pitch_value,input bit request_replay);begin
  @(negedge clk);while(phase!=(PREVIEW?FRAME-2:FRAME-1))@(negedge clk);
  // Arrive after the immediately preceding clock: no earlier admission preview
  // may replace the bundle that the original sample boundary actually sees.
  in_gates=1;in_notes=0;in_notes[6:0]=pitch_value;in_gains=0;in_gains[11:0]=2000+pitch_value;
  in_timbres=0;in_triggers=1;replay_toggle=request_replay;
  if(PREVIEW)@(negedge clk);
  @(posedge clk);#2;
  if(!dut.capture_busy||dut.captured_notes[6:0]!==pitch_value||!dut.capture_mask[0]||dut.captured_gains[11:0]!==12'(2000+pitch_value))$fatal(1,"ADMIT_LATE_EVENT_CAPTURE_SAME_SAMPLE");
  late_events++;if(request_replay)begin
   if(dut.recording||!dut.replay_after_capture)$fatal(1,"ADMIT_LATE_RECORD_TO_REPLAY_ORDER");late_replay++;
  end
  @(negedge clk);in_triggers=0;replay_toggle=0;
 end endtask
 initial begin
  repeat(5)@(negedge clk);rst=0;
  if(PREVIEW)begin
   for(k=0;k<4*FRAME;k++)begin
    @(negedge clk);
    in_notes=$random(seed);in_gains=$random(seed);in_timbres=$random(seed);in_gates=$random(seed);
    in_ratio=$random(seed);in_mod_depth=$random(seed);in_synth_config=$random(seed);
    in_triggers=$random(seed);record_toggle=k==3||k==2*FRAME;replay_toggle=k==FRAME;
    pipe_rst=(k==2*FRAME+2);rst=(k==2*FRAME+6);
   end
   @(negedge clk);rst=0;pipe_rst=0;record_toggle=0;replay_toggle=0;in_triggers=0;
   clear=1;frame(0,0);clear=0;frame(0,0);
  end
  // All voices plus a high-bit config event share timestamp0; Record->Replay
  // then waits for a second dense capture. Config must not alias voice1.
  if(CAP>=N+1)begin
   in_gates='1;in_synth_config=32'h80000a55;in_mod_depth=127;
   for(voice_index=0;voice_index<N;voice_index=voice_index+1)begin
    in_notes[voice_index*7+:7]=48+voice_index;in_gains[voice_index*12+:12]=1000+voice_index;in_timbres[voice_index*3+:3]=voice_index%4;
   end
   frame(1,0);repeat(2)frame(0,0);
   in_notes=in_notes+1'b1;in_synth_config=32'h000005aa;in_ratio=300001;frame(0,1);
   repeat(8)frame(0,0);clear=1;frame(0,0);clear=0;
   in_gates=0;in_notes=0;in_gains=0;in_timbres=0;in_synth_config=0;in_mod_depth=0;in_ratio=262144;
  end
  // Explicit same-boundary priorities, followed by a clean new take.
  clear=1;panic=1;frame(1,1);clear=0;panic=0;
  if(rec[0]||play[0]||count[0]!=0||dut.capture_busy)$fatal(1,"ADMIT_CLEAR_PANIC_OVER_RECORD_REPLAY");boundary_priority++;
  frame(0,0); // Retire pending clear/panic from their held input pulse.
  in_gates=0;in_triggers=0;in_notes=0;in_gains=0;in_timbres=0;in_ratio=262144;in_mod_depth=0;in_synth_config=0;
  frame(1,1);if(!rec[0]||play[0]||count[0]!=1)$fatal(1,"ADMIT_NEW_TAKE_OVER_REPLAY");boundary_priority++;
  if(FRAME>N+1)begin
   last_cycle_event(7'd65,0);last_cycle_event(7'd66,1);repeat(4)frame(0,0);
  end
  clear=1;frame(0,0);clear=0;
  in_gates=1;in_gains=100;in_notes=60;frame(1,0);
  repeat(4)frame(0,0);in_triggers=1;in_notes=62;frame(0,1);in_triggers=0;
  repeat(15)frame(0,0);frame(1,0);repeat(45)frame(0,0);frame(0,1);repeat(45)frame(0,0);
  clear=1;frame(0,0);clear=0;frame(1,0);
  for(k=0;k<15;k++)begin in_notes=k;in_gates=k;in_gains=k*987;in_timbres=k;frame(0,0);end
  frame(0,1);repeat(20)frame(0,0);
  for(k=0;k<700;k++)begin
   j=$unsigned($random(seed))%32;
   if(j<12)begin
    in_gates=$random(seed);in_triggers=$random(seed);
    for(voice_index=0;voice_index<N;voice_index=voice_index+1)begin
     in_notes[voice_index*7+:7]=$random(seed);in_gains[voice_index*12+:12]=$random(seed);in_timbres[voice_index*3+:3]=$random(seed);
    end
   end
   if(j==12)begin in_ratio=$random(seed);in_mod_depth=$random(seed);in_synth_config=$random(seed);end
   clear=j==13;panic=j==14;frame(j==15||j==17,j==16||j==17);in_triggers=0;clear=0;panic=0;
  end
  if(plays==0||fulls==0||(FRAME>N+1&&limits==0))$fatal(1,"RECORDER_EQ coverage incomplete plays=%0d full=%0d limit=%0d",plays,fulls,limits);
  if(ram_checks==0)$fatal(1,"RECORDER_RAM_COVERAGE");
  $display("RECORDER_EQ_PASS N%0d frame%0d clocks=%0d frames=%0d replayframes=%0d fullframes=%0d limitframes=%0d RAM%0d maxprep%0d rawdelta%0d",N,FRAME,checks,frames,plays,fulls,limits,ram_checks,max_prep,raw_differences);$display("PREPARE_TRANSACTION_PASS N%0d FRAME%0d writes%0d capReject%0d maxReject%0d busyReject%0d clearBusy%0d newTake%0d inactiveScratchClocks%0d",N,FRAME,writes,reject_capacity,reject_limit,reject_busy,clear_busy,new_takes,raw_differences);
  if(FRAME<=N+1&&reject_busy==0)$fatal(1,"PREPARE_BUSY_REJECT_MISSING");
  if(FRAME>N+1&&(late_events!=2||late_replay!=1))$fatal(1,"ADMIT_LATE_EDGE_COVERAGE");
  if(boundary_priority!=2)$fatal(1,"ADMIT_BOUNDARY_PRIORITY_COVERAGE");
  $display("ADMIT_CE_EDGE_PASS N%0d FRAME%0d lateEvents%0d lateRecordReplay%0d priority%0d",N,FRAME,late_events,late_replay,boundary_priority);done=1;
 end
 initial begin #30000000;if(!done)$fatal(1,"RECORDER_EQ timeout");end
endmodule

module rec113_defaults #(parameter PREVIEW=0)(output reg done=0);
 localparam N=7,CAP=4096,MAX=2929688;
 reg clk=0,rst=1,tick=0,record_cmd=0,replay_cmd=0;always #10 clk=~clk;
 reg[18:0]ratio=0;reg[11:0]address=0;
 wire rec[0:1],play[0:1],full[0:1],limit[0:1],ready[0:1],er[0:1];wire[12:0]count[0:1];wire[31:0]time_value[0:1],duration[0:1],take[0:1];wire[95:0]word[0:1];
 wire[18:0] admitted_ratio;
 generate if(PREVIEW)begin:real_pipe
  final_sound_pipe #(.VOICE_COUNT(N)) ingress(.clk(clk),.rst(rst),
   .in_gates(7'd0),.in_triggers(7'd0),.in_notes(49'd0),.in_gains(84'd0),.in_timbres(21'd0),
   .in_ratio(ratio),.in_mod(7'd0),.in_config(32'd0),.gates(),.triggers(),.notes(),.gains(),.timbres(),
   .ratio(admitted_ratio),.mod_depth(),.config_word());
 end else assign admitted_ratio=ratio;endgenerate
 final_recorder #(.VOICE_COUNT(N),.PREVIEW_INPUT(PREVIEW)) dut(.preview_rst(rst),.preview_gates(7'd0),.preview_notes(49'd0),.preview_gains(84'd0),.preview_timbres(21'd0),.preview_ratio(ratio),.preview_mod_depth(7'd0),.preview_synth_config(32'd0),.observer_gains(),.clk(clk),.rst(rst),.sample_tick(tick),.record_toggle(record_cmd),.replay_toggle(replay_cmd),.clear(1'b0),.panic(1'b0),
 .in_gates(7'd0),.in_triggers(7'd0),.in_notes(49'd0),.in_gains(84'd0),.in_timbres(21'd0),.in_ratio(admitted_ratio),.in_mod_depth(7'd0),.in_synth_config(32'd0),.export_address(address),
 .out_gates(),.out_triggers(),.out_notes(),.out_gains(),.out_timbres(),.out_ratio(),.out_mod_depth(),.out_synth_config(),.recording(rec[0]),.replaying(play[0]),.full(full[0]),.time_limit(limit[0]),.replay_frame_ready(ready[0]),.count(count[0]),.time_samples(time_value[0]),.duration_samples(duration[0]),.export_word(word[0]),.export_ready(er[0]),.take_id(take[0]));
 rec113_old_recorder #(.VOICE_COUNT(N)) reference(.observer_gains(),.clk(clk),.rst(rst),.sample_tick(tick),.record_toggle(record_cmd),.replay_toggle(replay_cmd),.clear(1'b0),.panic(1'b0),
 .in_gates(7'd0),.in_triggers(7'd0),.in_notes(49'd0),.in_gains(84'd0),.in_timbres(21'd0),.in_ratio(admitted_ratio),.in_mod_depth(7'd0),.in_synth_config(32'd0),.export_address(address),
 .out_gates(),.out_triggers(),.out_notes(),.out_gains(),.out_timbres(),.out_ratio(),.out_mod_depth(),.out_synth_config(),.recording(rec[1]),.replaying(play[1]),.full(full[1]),.time_limit(limit[1]),.replay_frame_ready(ready[1]),.count(count[1]),.time_samples(time_value[1]),.duration_samples(duration[1]),.export_word(word[1]),.export_ready(er[1]),.take_id(take[1]));
 integer i,checks=0,exported=0;
 always @(negedge clk)if(!rst)begin
  if({rec[0],play[0],full[0],limit[0],ready[0],count[0],time_value[0],duration[0],er[0],take[0],dut.replay_state,dut.replay_index,dut.capture_busy} !==
     {rec[1],play[1],full[1],limit[1],ready[1],count[1],time_value[1],duration[1],er[1],take[1],reference.replay_state,reference.replay_index,reference.capture_busy})$fatal(1,"DEFAULT4096_60S_EVERY_CLOCK");
  if({dut.changed,dut.initial_changed,dut.out_gates,dut.out_triggers,dut.out_notes,dut.out_gains,dut.out_timbres,dut.out_ratio,dut.out_mod_depth,dut.out_synth_config,dut.observer_gains,
      dut.capture_mask,dut.captured_time,dut.capture_index,dut.write_index,dut.read_address,dut.record_time,dut.replay_time,dut.previous_ratio} !==
     {reference.changed,reference.initial_changed,reference.out_gates,reference.out_triggers,reference.out_notes,reference.out_gains,reference.out_timbres,reference.out_ratio,reference.out_mod_depth,reference.out_synth_config,reference.observer_gains,
      reference.capture_mask,reference.captured_time,reference.capture_index,reference.write_index,reference.read_address,reference.record_time,reference.replay_time,reference.previous_ratio})
   $fatal(1,"REC113_DEFAULTS_ALL_PUBLIC_SCRATCH_EVERY_CLOCK");
  checks++;
 end
 task frame(input bit record_value,replay_value);begin
  if(PREVIEW)@(negedge clk);
  @(negedge clk);tick=1;record_cmd=record_value;replay_cmd=replay_value;
  @(negedge clk);tick=0;record_cmd=0;replay_cmd=0;repeat(12)@(negedge clk);
 end endtask
 initial begin
  repeat(4)@(negedge clk);rst=0;frame(1,0);
  for(i=1;i<CAP;i++)begin ratio=i;frame(0,0);end
  if(count[0]!=4096||!rec[0]||full[0]||dut.capture_busy)$fatal(1,"DEFAULT4096_LAST_ENTRY");
  frame(0,0);if(count[0]!=4096||!rec[0]||full[0])$fatal(1,"DEFAULT4096_ZERO_INCREMENT_ALLOWED");
  ratio=4096;frame(0,0);if(count[0]!=4096||rec[0]||!full[0]||!er[0])$fatal(1,"DEFAULT4096_NEXT_CONFIG_REJECTED");
  for(i=0;i<4096;i++)begin
   @(negedge clk);address=i;@(negedge clk);
   if($isunknown(word[0])||word[0]!==word[1]||dut.event_ram[i]!==reference.event_ram[i])$fatal(1,"DEFAULT4096_EXPORTED_WORD address%0d",i);exported++;
  end
  // Counter fixture reaches the real60s edge without simulating billions of clocks.
  rst=1;repeat(4)@(negedge clk);rst=0;ratio=0;frame(1,0);
  @(negedge clk);dut.record_time=MAX-2;reference.record_time=MAX-2;dut.duration_samples=MAX-2;reference.duration_samples=MAX-2;
  frame(0,0);if(!rec[0]||duration[0]!=MAX-1||limit[0])$fatal(1,"REAL60S_LAST_SAMPLE_ADMITTED");
  frame(0,1);if(rec[0]||!limit[0]||full[0]||!play[0]||!ready[0]||duration[0]!=MAX-1||count[0]!=1)$fatal(1,"REAL60S_NEXT_SAMPLE_STOP_REPLAY_SAME_EDGE");
  $display("CONFIG_CAPACITY_DEFAULTS_PASS checks%0d exported%0d realCapacity4096_zeroDeltaAtFull_nextConfigRejected realMAX2929688_prevSampleAdmitted_exactStopAndReplayReady",checks,exported);done=1;
 end
endmodule

module tb_rec113_equiv;
 wire[11:0]done;
 rec113_case #(.N(4),.CAP(32)) g4(done[0]);
 rec113_case #(.N(7),.CAP(64),.FRAME(1024)) g7(done[1]);
 rec113_case #(.N(25),.CAP(128),.FRAME(256)) g25(done[2]);
 rec113_case #(.N(7),.CAP(3)) gs(done[3]);
 rec113_case #(.N(25),.CAP(128),.FRAME(16)) gb(done[4]);
 rec113_defaults gd(done[5]);
 rec113_case #(.N(4),.CAP(32),.PREVIEW(1)) p4(done[6]);
 rec113_case #(.N(7),.CAP(64),.FRAME(1024),.PREVIEW(1)) p7(done[7]);
 rec113_case #(.N(25),.CAP(128),.FRAME(256),.PREVIEW(1)) p25(done[8]);
 rec113_case #(.N(7),.CAP(3),.PREVIEW(1)) ps(done[9]);
 rec113_case #(.N(25),.CAP(128),.FRAME(16),.PREVIEW(1)) pb(done[10]);
 rec113_defaults #(.PREVIEW(1)) pd(done[11]);
 initial begin wait(&done);$display("REC113_ALL_PASS exactCompleteOldOracle direct0_realSoundPipe1 N4_7_25 small3 busy16 production1024 capacity4096_real60s");$finish;end
endmodule
