`timescale 1ns/1ps
module tb_poly_fill_unsigned_full;
 `include "src/poly/poly_model_layout.vh"
 reg clk=0,rst=0,tick=0,trig=0,en=0,load=0;
 poly_model_line dut(.clk(clk),.rst(rst),.tick(tick),.trigger(trig),.gate(1'b1),.kind(3'd1),.velocity(12'd2400),.step(24'd151197),.rate_shift(2'd0),.period_q10(24'd100000),.sample(),.envelope(),.busy(),.deadline_error(),.bridge_return(18'sd0),.bridge_incident(),.piano_mode(1'b1),.bridge_incident_next(),.ctx_enable(1'b0),.ctx_load(load),.ctx_data({`POLY_MODEL_LINE_W{1'b0}}),.ctx_state(),.mem_q(18'd1800),.mem_raddr(),.mem_waddr(),.mem_we(),.mem_data(),.shared_tuning(16'd0),.shared_impact(18'sd0),.impact_phase());
 integer i,j,checks=0;reg[17:0]value;reg signed[25:0]old_a,old_b;reg signed[51:0]old_product;
 initial begin
  for(j=0;j<2;j++)for(i=0;i<262144;i++)begin
   value=i;dut.fill_numerator=value;dut.fill_soft=j;#1;
   old_a=$signed({8'd0,value});old_b=j?26'sd174763:26'sd299594;old_product=old_a*old_b;
   if(dut.fill_mul!==old_product[36:0])$fatal(1,"FILL_UNSIGNED_PRODUCT value%0d soft%0d got%h want%h",value,j,dut.fill_mul,old_product[36:0]);checks++;
  end
  $display("POLY_FILL_UNSIGNED_FULL_PASS %0d all18bit inputs both19bit constants exact old26x26 low37",checks);$finish;
 end
endmodule
