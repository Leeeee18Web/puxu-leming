`timescale 1ns/1ps
module tb_poly12_top_integrated;
 reg clk=0,rstn=0;always #10 clk=~clk;
 tri dp,dm;
 hub_play_top dut(.clk(clk),.rstn(rstn),.key1_n(1'b1),.key2_n(1'b1),.uart_rx(1'b1),.uart_tx(),
  .usb_dp(dp),.usb_dm(dm),.hp_bck(),.hp_ws(),.hp_din(),.i2s_bck(),.i2s_ws(),.i2s_sd(),
  .pa_en(),.led_o(),.tmds_clk_p_0(),.tmds_clk_n_0(),.tmds_d_p_0(),.tmds_d_n_0());
 defparam dut.status_bridge.PERIOD=10;
 integer checks=0,nz=0,i,record_voice6=0,replay7=0;
 reg[95:0]word;
 task check(input bit yes,input string why);begin checks++;if(!yes)$fatal(1,"POLY12_TOP_FAIL %s",why);end endtask
 task clocks(input integer n);begin repeat(n)@(negedge clk);end endtask
 task frames(input integer n);begin repeat(n)begin @(posedge dut.sample_tick);@(negedge clk);end end endtask
 task touch(input integer x,y,input bit down);begin dut.soc.hid_report(x,y,down,1);clocks(40);end endtask
 task tap(input integer x,y);begin touch(x,y,0);touch(x,y,1);touch(x,y,0);end endtask
 always @(posedge clk)if(!dut.rst&&dut.sample_tick)begin
  if(dut.pcm!=0)nz++;
  check(!dut.audio_deadline_error,"integrated renderer meets1024-clock deadline");
  if(dut.replaying&&dut.gates==7'h7f)replay7++;
 end
 initial begin
  check($bits(dut.live_gates)==7&&$bits(dut.gains)==84,"production buses expose all7 voices");
  clocks(10);rstn=1;clocks(1000);
  dut.soc.ptest_debug[255:224]=32'h0c;clocks(80);
  tap(300,280);tap(796,96);
  check(dut.page==6,"HID reaches envelope tab");
  dut.soc.ptest_debug[255:224]=32'h2c;clocks(100);
  dut.wifi_control.wifi_timbre=2;dut.wifi_control.wifi_timbre_override=1;clocks(2);
  check(dut.esp_ready&&dut.timbre_select==2,"existing WiFi selection owns timbre");
  tap(430,180);tap(900,572);frames(2);
  check(dut.timbre_select==4&&!dut.wifi_timbre_override,"Apply reclaims selection from WiFi");
  check(dut.synth_config[15:8]==8'h95,"exact default choice applied");
  tap(520,540);frames(250);
  check(dut.preview_busy&&dut.audio_timbres[11:0]=={4{3'd4}}&&dut.audio_timbres[20:12]==0,"preview is original four notes padded to7");
  check(nz>100,"preview emits nonzero HDL PCM");
  check(!dut.recording&&dut.record_count==0,"audition never writes saved performance");
  tap(520,540);frames(3);check(!dut.preview_busy&&dut.audio_gates==dut.gates,"Stop returns normal source");
  tap(70,96);frames(3);check(dut.page==1,"normal page returns");
  tap(70,150);frames(2);check(dut.recording,"real HID starts recorder");
  for(i=0;i<7;i++)dut.soc.midi_event(32'h00640090|((60+i)<<8));
  frames(80);
  check(dut.live_gates==7'h7f&&dut.gates==7'h7f,"7 real USB MIDI inputs sound concurrently");
  for(i=0;i<7;i++)begin
   check(dut.live_notes[i*7+:7]==60+i,"all7 independent pitches");
   check(dut.live_timbres[i*3+:3]==4&&dut.audio_timbres[i*3+:3]==4,"fifth timbre reaches each of7 voices");
  end
  check(dut.active==7'h7f,"all7 custom envelopes active");
  for(i=0;i<7;i++)dut.soc.midi_event(32'h00000080|((60+i)<<8));
  frames(3);check(dut.live_gates==0,"all7 real MIDI noteoffs released");
  tap(70,150);frames(3);check(!dut.recording&&dut.record_export_ready,"stop drains recorder");
  for(i=0;i<dut.record_count;i++)begin
   word=dut.recorder.event_ram[i];
   if(!word[63]&&word[62:57]==6)begin
    record_voice6++;
    check(word[35:33]==4&&word[54:48]==66,"record format preserves voice6/timbre4/note71");
   end
  end
  check(record_voice6>=2,"voice6 on and off both recorded");
  tap(250,150);frames(90);check(replay7>0,"saved take replays all7 voices");
  tap(580,30);frames(3);check(!dut.replaying,"transport stop exits replay");
  tap(450,30);frames(3);check(dut.muted&&dut.audio_gains==0,"mute hard-stops every audio gain");
  $display("POLY12_TOP_PASS checks=%0d nonzero=%0d recorded_voice6=%0d replay7=%0d",checks,nz,record_voice6,replay7);$finish;
 end
 initial begin #100000000;$fatal(1,"POLY12_TOP_TIMEOUT");end
endmodule
