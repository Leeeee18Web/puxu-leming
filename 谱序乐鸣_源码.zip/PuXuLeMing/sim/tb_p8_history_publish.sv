`timescale 1ns/1ps
module tb_p8_history_publish;
 reg clk=0,pclk=0,rst=1,prstn=0,tick=0,frame=0,restart=0;
 always #10 clk=~clk; always #13 pclk=~pclk;
 wire[10:0] data; wire[16:0] curve; wire[9:0] count;
 tone_history #(.TOTAL_SAMPLES(3072)) dut(.clk(clk),.rst(rst),.restart(restart),.sample_tick(tick),.recording(1'b1),.pitch(11'd960),.pitch_valid(1'b1),.pixel_clk(pclk),.pixel_rstn(prstn),.frame_start(frame),.read_addr(10'd0),.read_enable(1'b1),.pitch_data(data),.visible_count(count),.curve_sum(curve));
 integer cycle=0; reg[9:0] held; reg heldbank,heldtoggle;
 always @(negedge clk)begin cycle=cycle+1;tick=cycle%4==0;end
 initial begin
 repeat(5)@(negedge clk);rst=0;prstn=1;
 wait(dut.publish!=0);@(negedge clk);held=dut.source_count;heldbank=dut.source_bank;heldtoggle=dut.publish;
 repeat(100)@(negedge clk);
 if(dut.source_count!==held||dut.source_bank!==heldbank||dut.publish!==heldtoggle)$fatal(1,"FAIL outstanding history payload must remain held until frame acknowledgement");
 repeat(5)@(negedge pclk); frame=1;@(negedge pclk);frame=0;
 repeat(20)@(negedge clk);if(count!==held)$fatal(1,"history frame coherent count");
 $display("P8_HISTORY_MAILBOX_PASS held payload and frame acknowledgement");$finish;
 end
 initial begin #100000;$fatal(1,"history deadline");end
endmodule
