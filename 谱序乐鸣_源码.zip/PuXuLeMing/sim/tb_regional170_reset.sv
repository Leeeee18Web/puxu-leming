`timescale 1ns/1ps
module regional170_reset_case #(parameter N=4)(output reg done=0);
 reg clk=0;always #10 clk=~clk;reg resetn=0,start=0;
 reg[2:0]audio_reset=0;
 (* syn_preserve=1,syn_keep=1 *)reg[11:0]model_resetn=0;
 always @(posedge clk or negedge resetn)if(!resetn)begin audio_reset<=0;model_resetn<=0;end
 else begin audio_reset<={audio_reset[1:0],1'b1};model_resetn<={12{audio_reset[1]}};end
 wire rst=!model_resetn[9];wire control_resetn_early=audio_reset[1];
 reg[N-1:0]gates=0,triggers=0;reg[N*24-1:0]steps=0;reg[N*12-1:0]gains=0;reg[N*3-1:0]tones=0;
 wire[N*16-1:0]sa,sb,ea,eb;wire[N-1:0]aa,ab;wire ba,bb,da,db,va,vb;wire[2:0]ia,ib;wire signed[15:0]oa,ob;
 poly_voice_worker #(.REGIONAL_MODEL_CONTROLS(1),.CONTEXTS(N),.LOCAL_MEMORY_RESET(1),.PRECALC_SLOT_GATES(1),.LOCAL_CONTROL(1)) dut(.clk(clk),.rst(rst),.start(start),.gates(gates),.triggers(triggers),.steps(steps),.gains(gains),.timbres(tones),.samples(sa),.envelopes(ea),.active(aa),.busy(ba),.deadline_error(da),.out_valid(va),.out_index(ia),.out_sample(oa),.model_reset({3{rst}}),.memory_reset(rst),.control_resetn_early(control_resetn_early));
 regional170_worker_old #(.CONTEXTS(N),.LOCAL_MEMORY_RESET(1),.PRECALC_SLOT_GATES(1),.LOCAL_CONTROL(1)) reference(.clk(clk),.rst(rst),.start(start),.gates(gates),.triggers(triggers),.steps(steps),.gains(gains),.timbres(tones),.samples(sb),.envelopes(eb),.active(ab),.busy(bb),.deadline_error(db),.out_valid(vb),.out_index(ib),.out_sample(ob),.model_reset({3{rst}}),.memory_reset(rst));
 integer control_checks=0,reset_checks=0,warm_zero=0;
 always @(posedge clk or negedge clk or negedge resetn)begin
  #1;
  if({dut.ep_enabled.ep.ctx_enable,dut.reed.ctx_enable,dut.strings.ctx_enable,dut.strings.a.ctx_enable,dut.strings.b.ctx_enable,dut.strings.c.ctx_enable,dut.strings.body.ctx_enable}!==
     {reference.ep.ctx_enable,reference.reed.ctx_enable,reference.strings.ctx_enable,reference.strings.a.ctx_enable,reference.strings.b.ctx_enable,reference.strings.c.ctx_enable,reference.strings.body.ctx_enable})$fatal(1,"REGIONAL170_CE_STRICT phase%0d reset%b early%b",dut.phase,rst,control_resetn_early);
  if({dut.ep_enabled.ep.ctx_load,dut.reed.ctx_load,dut.strings.ctx_load,dut.strings.a.ctx_load,dut.strings.b.ctx_load,dut.strings.c.ctx_load,dut.strings.body.ctx_load}!==
     {reference.ep.ctx_load,reference.reed.ctx_load,reference.strings.ctx_load,reference.strings.a.ctx_load,reference.strings.b.ctx_load,reference.strings.c.ctx_load,reference.strings.body.ctx_load})$fatal(1,"REGIONAL170_LOAD_STRICT");
  if({dut.ep_enabled.ep.render_tick,dut.reed.render_tick,dut.strings.render_tick,dut.ep_enabled.ep.trigger,dut.reed.trigger,dut.strings.trigger}!==
     {reference.ep.render_tick,reference.reed.render_tick,reference.strings.render_tick,reference.ep.trigger,reference.reed.trigger,reference.strings.trigger})$fatal(1,"REGIONAL170_RENDER_TRIGGER_STRICT");
  if({dut.ep_enabled.ep.rst,dut.reed.rst,dut.strings.rst,dut.strings.body.rst,dut.strings.body.ctx_local_reset}!==
     {reference.ep.rst,reference.reed.rst,reference.strings.rst,reference.strings.body.rst,reference.strings.body.ctx_local_reset})$fatal(1,"REGIONAL170_COMPLETE_RESET_STRICT phase%0d",dut.phase);
  if({dut.strings.a.rst,dut.strings.b.rst,dut.strings.c.rst,dut.strings.a.tick,dut.strings.b.tick,dut.strings.c.tick,dut.strings.a.trigger,dut.strings.b.trigger,dut.strings.c.trigger,dut.strings.body.tick}!==
     {reference.strings.a.rst,reference.strings.b.rst,reference.strings.c.rst,reference.strings.a.tick,reference.strings.b.tick,reference.strings.c.tick,reference.strings.a.trigger,reference.strings.b.trigger,reference.strings.c.trigger,reference.strings.body.tick})$fatal(1,"REGIONAL170_LINE_BODY_PORTS_STRICT");
  if(model_resetn!=={12{model_resetn[9]}})$fatal(1,"REGIONAL170_ALL12_RESETS_SAME_PHASE");
  control_checks++;if(rst)reset_checks++;
  if(dut.is_strings&&dut.warm_busy&&dut.gain==0&&dut.phase>=2&&dut.phase<=4)warm_zero++;
 end


 integer mode,t,p,k,body_target,frames,reset_events=0,body_resets=0;
 reg[135:0]phase_coverage=0;reg[6:0]body_coverage=0;
 task frame_once;
  begin
   start=1;@(negedge clk);start=0;
   repeat(1023)@(negedge clk);
  end
 endtask
 task release_reset;
  begin
   start=0;#37;resetn=1;repeat(5)@(negedge clk);
  end
 endtask
 task pulse_at(input integer offset_mode);
  begin
   // Called on negedge; assert 2ns before, exactly on, or2ns after posedge.
   case(offset_mode)0:#8;1:#10;2:#12;endcase
   resetn=0;reset_events++;
   release_reset;
   if(ba||bb||da||db||sa!==0||sb!==0)$fatal(1,"REGIONAL170_RESET_QUIET");
  end
 endtask
 always @(negedge clk)begin
  #2;
  if({sa,ea,aa,ba,da,va,ia,oa,dut.phase,dut.context_index,dut.ctx_save,dut.context_data,dut.known}!==
     {sb,eb,ab,bb,db,vb,ib,ob,reference.phase,reference.context_index,reference.ctx_save,reference.context_data,reference.known})$fatal(1,"REGIONAL170_RESET_PUBLIC_CONTEXT");
 end
 always @(posedge clk)begin
  if(!rst)begin
   if(dut.ctx_save&&dut.context_state!==reference.context_state)$fatal(1,"REGIONAL170_RESET_CONTEXT_SAVE");
   if({dut.memory.enable,dut.memory.ctx_load,dut.memory.rst,dut.memory.we_a,dut.memory.we_b,dut.memory.we_c,dut.memory.wa,dut.memory.wb,dut.memory.wc,dut.memory.da,dut.memory.db,dut.memory.dc}!==
      {reference.memory.enable,reference.memory.ctx_load,reference.memory.rst,reference.memory.we_a,reference.memory.we_b,reference.memory.we_c,reference.memory.wa,reference.memory.wb,reference.memory.wc,reference.memory.da,reference.memory.db,reference.memory.dc})$fatal(1,"REGIONAL170_RESET_RAM_TRANSACTIONS");
  end
 end
 initial begin
  repeat(5)@(negedge clk);resetn=1;repeat(5)@(negedge clk);
  for(t=0;t<4;t=t+1)begin
   for(k=0;k<N;k=k+1)begin steps[k*24+:24]=45000;gains[k*12+:12]=1000+k*700;tones[k*3+:3]=t;end
   gates={N{1'b1}};
   for(p=0;p<136;p=p+1)for(mode=0;mode<3;mode=mode+1)begin
    triggers={N{1'b1}};frame_once;triggers=0;frame_once;
    start=1;@(negedge clk);start=0;
    while(!(dut.running&&dut.context_index==N-1&&dut.phase==p))@(negedge clk);
    phase_coverage[p]=1;pulse_at(mode);
   end
  end
  // Reach each actual body calculation state before asserting reset, including
  // in-flight initialization/rebuild and all six mode-consumer windows.
  for(body_target=0;body_target<7;body_target=body_target+1)for(mode=0;mode<3;mode=mode+1)begin
   for(k=0;k<N;k=k+1)begin steps[k*24+:24]=45000;gains[k*12+:12]=1800;tones[k*3+:3]=1;end
   gates={N{1'b1}};triggers={N{1'b1}};frame_once;triggers=0;frames=0;
   while(dut.strings.body.state!=body_target)begin
    start=1;@(negedge clk);start=0;
    while(ba&&dut.strings.body.state!=body_target)@(negedge clk);
    if(!ba)begin @(negedge clk);frames++;end
    if(frames>100)$fatal(1,"REGIONAL170_BODY_STATE_COVERAGE state%0d",body_target);
   end
   body_coverage[body_target]=1;body_resets++;pulse_at(mode);
  end
  if(!(&phase_coverage)||!(&body_coverage)||reset_events!=1653||body_resets!=21)$fatal(1,"REGIONAL170_RESET_COVERAGE");
  $display("REGIONAL170_RESET_PASS N%0d controls%0d resets%0d assertions%0d all136phases4tones3offsets body0to6",N,control_checks,reset_checks,reset_events);done=1;
 end
endmodule
module tb_regional170_reset;
 wire[1:0]done;
 regional170_reset_case #(.N(4))n4(done[0]);regional170_reset_case #(.N(3))n3(done[1]);
 initial begin wait(&done);$finish;end
endmodule
