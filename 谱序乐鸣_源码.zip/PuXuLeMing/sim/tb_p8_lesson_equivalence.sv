`timescale 1ns/1ps
module tb_p8_lesson_equivalence;
 reg clk=0;always #5 clk=~clk;
 reg rst=1,sample_tick=0,enabled=1,restart=0,event_valid=0,panic=0;
 reg [6:0]base_note=60;
 reg [31:0]event_data=0;
 wire [6:0]target_note,feedback_note,correct_count;
 wire [1:0]feedback;wire [5:0]position;wire done;wire[15:0]wrong_count;
 wire [6:0]ref_target,ref_fbnote,ref_good;
 wire [1:0]ref_fb;wire [5:0]ref_pos;wire ref_done;wire[15:0]ref_bad;
 integer cycles=0,events=0,src,ch,n,i,op;
 reg [31:0]rng=32'h8a607e12;
 // Reference receives the complete input context one clock later, matching
 // the production predecode latency. Reset flushes both pipelines immediately.
 reg ref_sample_tick=0,ref_enabled=0,ref_restart=0,ref_event_valid=0,ref_panic=0;
 reg [6:0]ref_base_note=60;reg[31:0]ref_event_data=0;
 always @(posedge clk)begin
  if(rst)begin
   ref_sample_tick<=0;ref_enabled<=0;ref_restart<=0;ref_event_valid<=0;ref_panic<=0;
   ref_base_note<=base_note;ref_event_data<=0;
  end else begin
   ref_sample_tick<=sample_tick;ref_enabled<=enabled;ref_restart<=restart;
   ref_event_valid<=event_valid;ref_panic<=panic;ref_base_note<=base_note;ref_event_data<=event_data;
  end
 end
 p8_lesson dut(.*);
 p8_lesson_reference reference(.clk(clk),.rst(rst),.sample_tick(ref_sample_tick),.enabled(ref_enabled),.restart(ref_restart),
  .event_valid(ref_event_valid),.event_data(ref_event_data),.panic(ref_panic),.base_note(ref_base_note),
  .target_note(ref_target),.feedback_note(ref_fbnote),.correct_count(ref_good),
  .feedback(ref_fb),.position(ref_pos),.done(ref_done),.wrong_count(ref_bad));
 always @(posedge clk)begin
  #1;cycles=cycles+1;if(event_valid)events=events+1;
  if({target_note,feedback_note,correct_count,feedback,position,done,wrong_count} !==
     {ref_target,ref_fbnote,ref_good,ref_fb,ref_pos,ref_done,ref_bad})
   $fatal(1,"lesson same-cycle outputs differ cycle%0d event=%08x pos=%0d/%0d",cycles,event_data,position,ref_pos);
  if(dut.held!==reference.held)$fatal(1,"lesson 4096 hold bits differ cycle%0d event=%08x",cycles,event_data);
  if(dut.feedback_ticks!==reference.feedback_ticks)$fatal(1,"feedback timer differs cycle%0d",cycles);
 end
 task ev(input integer s,status,note,vel);
  begin @(negedge clk);event_valid=1;event_data=(s<<24)|(vel<<16)|(note<<8)|status;end
 endtask
 task next_rng;
  begin rng=rng^(rng<<13);rng=rng^(rng>>17);rng=rng^(rng<<5);end
 endtask
 initial begin
  repeat(3)@(negedge clk);rst=0;
  // Every source/channel/pitch receives a distinct press, duplicate, stale
  // release from another owner, real release, and re-press at one event/clk.
  for(src=0;src<2;src=src+1)for(ch=0;ch<16;ch=ch+1)for(n=0;n<128;n=n+1)begin
   ev(src,8'h90|ch,n,100);ev(src,8'h90|ch,n,100);
   ev(src^1,8'h80|ch,n,0);ev(src,8'h80|ch,n,0);ev(src,8'h90|ch,n,99);
  end
  // Clear one channel without disturbing the other 31 banks, then refill.
  for(src=0;src<2;src=src+1)for(ch=0;ch<16;ch=ch+1)begin
   ev(src,8'hb0|ch,123,0);
   for(n=0;n<128;n=n+1)ev(src,8'h90|ch,n,127);
   ev(src,8'hb0|ch,120,0);
   for(n=0;n<128;n=n+1)ev(src,8'h90|ch,n,64);
  end
  ev(1,8'hff,255,255);
  for(src=0;src<2;src=src+1)for(ch=0;ch<16;ch=ch+1)for(n=0;n<128;n=n+1)begin
   ev(src,8'h90|ch,n,100);ev(src,8'h90|ch,n,0);
  end
  // Simultaneous mode/restart/panic/base changes and malformed/non-note MIDI.
  for(i=0;i<30000;i=i+1)begin
   @(negedge clk);next_rng();event_data=rng;event_valid=(rng[2:0]!=0);
   rst=(rng[14:0]==0);enabled=(rng[8:5]!=0);restart=(rng[13:9]==0);
   panic=(rng[19:14]==0);sample_tick=rng[20];
   if(rng[26:21]==0)base_note=rng[6:0];
   op=rng[31:27];
   if(op<12)begin event_data[7:4]=9;event_data[15]=0;event_data[23]=0;end
   else if(op<20)begin event_data[7:4]=8;event_data[15]=0;event_data[23]=0;end
   else if(op==20)event_data[7:0]=8'hff;
   else if(op<24)begin event_data[7:4]=11;event_data[15:8]=op[0]?123:120;event_data[23]=0;end
   else if(op<26)begin event_data[7:4]=9;event_data[23:16]=0;event_data[15]=0;end
  end
  @(negedge clk);rst=0;enabled=1;restart=1;panic=0;event_valid=0;base_note=60;
  @(negedge clk);restart=0;
  ev(0,8'h90,60,100);
  @(negedge clk);event_valid=0;sample_tick=1;
  repeat(14650)@(negedge clk);
  $display("PASS tb_p8_lesson_equivalence cycles=%0d events=%0d all4096holds/alloutputs fixed1clock latency",cycles,events);$finish;
 end
endmodule
