`timescale 1ns/1ps
module tb_poly25_audio;
 parameter FRAMES=19000,TEST_TONE=0;
 reg clk=0;always #10 clk=~clk;reg rst=1;reg[24:0]gates=25'h1ffffff,triggers=0;reg[174:0]notes=0;reg[299:0]gains=0;reg[74:0]tones=0;reg[18:0]ratio=262144;reg[6:0]modulation=0;reg[31:0]config_word=0;
 wire tick;wire signed[15:0]pcm;wire positive,hb,hw,hd,ib,iw,id;wire[24:0]active;wire[599:0]steps;wire[399:0]env;wire error,clip;
 poly25_audio #(.ENABLE_FX(1)) dut(.clk(clk),.rst(rst),.gates(gates),.triggers(triggers),.notes(notes),.gains(gains),.timbres(tones),.ratio(ratio),.mod_depth(modulation),.synth_config(config_word),.sample_tick(tick),.pcm(pcm),.pcm_positive(positive),.hp_bck(hb),.hp_ws(hw),.hp_din(hd),.i2s_bck(ib),.i2s_ws(iw),.i2s_sd(id),.active(active),.monitor_steps(steps),.monitor_envelopes(env),.deadline_error(error),.clip_active(clip),.map_apply(1'b0),.model_reset(12'd0),.control_resetn_early(1'b1));
 `include "play_note_steps.vh"
 integer i,f,fd,c=0,last=0;reg[24:0]heard=0;integer first_audio=-1;
 initial begin
  for(i=0;i<25;i=i+1)begin notes[i*7+:7]=60+i;gains[i*12+:12]=2200;tones[i*3+:3]=TEST_TONE;end
  fd=$fopen("poly25_pcm.csv","w");if(!fd)$fatal(1,"PCM_FILE_OPEN");
  repeat(8)@(negedge clk);rst=0;triggers=25'h1ffffff;
  for(f=0;f<FRAMES;f=f+1)begin
   @(negedge clk);while(!tick)begin @(negedge clk);c=c+1;end
   if(f>0&&c-last!=1023)$fatal(1,"SAMPLE_CADENCE frame%0d clocks%0d",f,c-last);last=c;
   if(error||dut.physical.busy)$fatal(1,"AUDIO_DEADLINE frame%0d",f);
   if(f>100&&f<17500&&active!==25'h1ffffff)$fatal(1,"AUDIO_25_ACTIVE frame%0d mask%h",f,active);
   if(f>0&&pcm!=0&&first_audio<0)first_audio=f;
   if(f>=1024&&f<17408)begin
    $fwrite(fd,"%0d",pcm);for(i=0;i<25;i=i+1)$fwrite(fd,",%0d",$signed(dut.phys_samples[i*16+:16]));$fwrite(fd,"\n");
   end
   for(i=0;i<25;i=i+1)if($signed(dut.phys_samples[i*16+:16])!=0)heard[i]=1;
   triggers=0;
   if(f==17500)begin gates[24]=0;gains[24*12+:12]=0;config_word=15;end
   if(f>17504&&active!==25'h0ffffff)$fatal(1,"AUDIO_INDEPENDENT_OFF frame%0d mask%h",f,active);
   if(f==18000)begin ratio=280000;modulation=72;end
  end
  $fclose(fd);if(first_audio<0||first_audio>488||heard!==25'h1ffffff)$fatal(1,"AUDIO_MISSING_OR_LATENCY %0d %h",first_audio,heard);
  $display("POLY25_AUDIO_PASS frames%0d first_audio%0d all25 actual PCM FX/modulation independent-off/cadence/deadline",FRAMES,first_audio);$finish;
 end
 initial begin #450000000;$fatal(1,"POLY25_AUDIO_TIMEOUT");end
endmodule

module tb_poly25_audio_1;tb_poly25_audio #(.TEST_TONE(1)) test();endmodule
module tb_poly25_audio_2;tb_poly25_audio #(.TEST_TONE(2)) test();endmodule
module tb_poly25_audio_3;tb_poly25_audio #(.TEST_TONE(3)) test();endmodule
