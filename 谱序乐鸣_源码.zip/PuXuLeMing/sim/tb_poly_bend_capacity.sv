`timescale 1ns/1ps
// Four held contexts: center->minimum bend and upper+maximum vibrato->lower-maximum vibrato,
// each with grand and guitar. Threshold-adjacent trigger steps also exercise all rate boundaries.
module tb_poly_bend_capacity;
 localparam LENGTH=2048,CAPACITY_Q10=(LENGTH-4)*1024;
 `include "play_note_steps.vh"
 reg clk=0;always #10 clk=~clk;
 reg rst=1,start=0;reg[3:0]gates=15,triggers=0;
 reg[95:0]steps=0;reg[47:0]gains={4{12'd2400}};reg[11:0]tones={3'd2,3'd1,3'd2,3'd1};
 wire[63:0]samples,envelopes;wire[3:0]active;wire busy,err;
 poly_voice_worker #(.CONTEXTS(4),.LENGTH(LENGTH)) dut(.clk(clk),.rst(rst),.start(start),.model_reset({3{rst}}),.gates(gates),.triggers(triggers),.steps(steps),.gains(gains),.timbres(tones),.samples(samples),.envelopes(envelopes),.active(active),.busy(busy),.deadline_error(err),.out_valid(),.out_index(),.out_sample(),.control_resetn_early(1'b1));
 localparam integer RMIN=174960+((64'sd174960*(-3810))>>>18),RMAX=392772+((64'sd392772*3809)>>>18);
 integer testno,f,c,k,base,trigger_step[0:3],held_step[0:3],saved_rate[0:3];
 integer checks=0,reads=0,held_checks=0;reg[63:0]wanted;
 function integer selected_rate(input integer s);
 begin selected_rate=s>=19456?0:s>=9728?1:s>=4864?2:3;end endfunction
 always @(posedge clk)if(!rst&&dut.core_enable&&dut.running&&dut.phase>=5)begin
  if(dut.sra>=LENGTH||dut.srb>=LENGTH||dut.src>=LENGTH)$fatal(1,"BEND_READ_BOUNDS case%0d",testno);
  reads=reads+1;
  if(f>=100&&dut.strings.rebuild)$fatal(1,"BEND_HELD_REBUILT case%0d",testno);
 end
 initial begin
 for(testno=0;testno<50;testno=testno+1)begin
  rst=1;start=0;triggers=0;repeat(5)@(negedge clk);rst=0;
  if(testno<41)begin
   base=midi_step(testno);
   for(k=0;k<4;k=k+1)begin
    trigger_step[k]=k<2?base:((64'd1*base*RMAX)>>18);
    held_step[k]=(64'd1*base*(k<2?174960:RMIN))>>18;
   end
  end else begin
   base=(testno<44?4864:testno<47?9728:19456)+(testno-41)%3-1;
   for(k=0;k<4;k=k+1)begin
    trigger_step[k]=base;
    // floor of the smallest possible base that can produce this trigger value.
    held_step[k]=((64'd1*base*RMIN)/RMAX)-1;
   end
  end
  for(k=0;k<4;k=k+1)begin steps[k*24+:24]=trigger_step[k];saved_rate[k]=selected_rate(trigger_step[k]);end
  for(f=0;f<120;f=f+1)begin
   triggers=f==0?15:0;
   if(f==100)for(k=0;k<4;k=k+1)steps[k*24+:24]=held_step[k];
   for(c=0;c<1024;c=c+1)begin
    start=c==32;@(negedge clk);
    if(err)$fatal(1,"BEND_DEADLINE case%0d frame%0d",testno,f);
    if(dut.running&&dut.phase==133)begin
     k=dut.context_index;
     if(dut.strings.rate_shift!==saved_rate[k])$fatal(1,"BEND_CADENCE case%0d context%0d trigger%0d got%0d expected%0d",testno,k,trigger_step[k],dut.strings.rate_shift,saved_rate[k]);
     if(f>=110)begin
      wanted=64'd17179869184/(held_step[k]<<saved_rate[k]);
      if(wanted>CAPACITY_Q10||wanted+(wanted>>11)>CAPACITY_Q10)$fatal(1,"BEND_TEST_CAPACITY case%0d wanted%0d",testno,wanted);
      if(dut.strings.period_q10!==wanted[23:0])$fatal(1,"BEND_PERIOD_CLIPPED case%0d context%0d trigger%0d held%0d wanted%0d actual%0d",testno,k,trigger_step[k],held_step[k],wanted,dut.strings.period_q10);
      if(!dut.string_active||dut.string_initializing||dut.strings.init_pending||!gates[k])$fatal(1,"BEND_HELD_STATE case%0d context%0d",testno,k);
      checks=checks+1;held_checks=held_checks+1;
     end
    end
   end
  end
  $display("BEND_CASE_PASS case%0d step%0d trigger_max%0d held_min%0d rate%0d",testno,base,trigger_step[3],held_step[3],saved_rate[3]);
 end
 if(checks!=2000||reads<1000000||held_checks!=2000)$fatal(1,"BEND_COVERAGE %0d %0d",checks,reads);
 $display("POLY_BEND_CAPACITY_PASS cases=50 held_period_checks=%0d readchecks=%0d MIDI0..40 both timbres all rate thresholds",checks,reads);$finish;
 end
 initial begin #150000000;$fatal(1,"BEND_TIMEOUT");end
endmodule
