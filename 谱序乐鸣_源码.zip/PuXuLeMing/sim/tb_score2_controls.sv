`timescale 1ns/1ps
module tb_score2_controls;
 reg clk=0;always #10 clk=~clk;
 reg rst=1,update=0,valid=1,down=0;reg[15:0]x=0,y=0;wire[31:0]cfg;wire[2:0]page;wire opened,ev;
 final_navigation dut(.touch_key_base(7'd60),.clk(clk),.rst(rst),.touch_update(update),.touch_valid(valid),.touch_down(down),.touch_x(x),.touch_y(y),.event_ready(1'b1),.panic_key(1'b0),.centre_key(1'b0),.synth_config(cfg),.page(page),.timbre_open(opened),.event_valid(ev),.event_data(),.mode(),.knob_mode(),.base_note(),.centre(),.panic(),.clear_live(),.start_score(),.stop_score(),.muted(),.restart_lesson(),.xy_config(),.spectrum_zoom(),.pattern_mode(),.pattern_start(),.record_toggle(),.replay_toggle(),.transport_stop(),.xy_overview(),.timbre());
 task contact;input integer xx,yy;input dd;begin @(negedge clk);x=xx;y=yy;down=dd;update=1;@(negedge clk);update=0;repeat(3)@(negedge clk);end endtask
 task click;input integer xx,yy;begin contact(xx,yy,1);contact(xx,yy,0);end endtask
 integer i,j;
 initial begin repeat(4)@(negedge clk);rst=0;click(200,30); // header play
  if(page==0)$fatal(1,"ENTER_PLAY");
  click(800,30);if(!opened)$fatal(1,"OPEN_MENU");
  click(800,304);if(cfg[1:0]!=1)$fatal(1,"CHORUS_NOT_ENABLED");
  contact(800,304,1);repeat(8)@(negedge clk);if(cfg[1:0]!=2)$fatal(1,"CONTACT_EDGE");
  contact(800,304,1);if(cfg[1:0]!=2)$fatal(1,"HELD_REPEAT");contact(800,304,0);
  click(800,354);click(800,399);if(cfg[5:0]!=6'b010110)$fatal(1,"INDEPENDENT_FX %h",cfg);
  if(!opened)$fatal(1,"MENU_CLOSED_AFTER_FX");
  for(j=0;j<3;j=j+1)for(i=0;i<4;i=i+1)click(800,304+44*j);
  if(cfg[5:0]!=6'b010110)$fatal(1,"LEVEL_WRAP");
  contact(800,450,1);contact(800,500,1);if(ev)$fatal(1,"MODAL_TOUCH_BECAME_NOTE");contact(800,450,0);
  if(opened)$fatal(1,"OUTSIDE_CLOSE");
  rst=1;repeat(3)@(negedge clk);rst=0;if(cfg!=32'h9500)$fatal(1,"DEFAULTS_NOT_OFF");
  $display("SCORE2_CONTROLS_PASS independent levels held contact modal reset");$finish;
 end
 initial begin #1000000;$fatal(1,"TIMEOUT");end
endmodule
