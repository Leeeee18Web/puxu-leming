`timescale 1ns/1ps
module tb_audio_gain_flags;
 reg clk=0,rst=1;always #10 clk=~clk;
 reg[3:0]gates=0,triggers=0;reg[27:0]notes=0;reg[47:0]gains=0;reg[11:0]timbres=0;
 reg[18:0]ratio=262144;reg[6:0]mod_depth=0;
 wire[3:0]active[0:1];wire[95:0]steps[0:1];wire[63:0]envs[0:1];wire[15:0]pcm[0:1];
 wire[7:0]pins[0:1];wire deadline[0:1],clip[0:1];
 final_audio dut(.clk(clk),.rst(rst),.gates(gates),.triggers(triggers),.notes(notes),.gains(gains),.timbres(timbres),.ratio(ratio),.mod_depth(mod_depth),.synth_config(32'd0),.sample_tick(pins[0][0]),.pcm(pcm[0]),.hp_bck(pins[0][1]),.hp_ws(pins[0][2]),.hp_din(pins[0][3]),.i2s_bck(pins[0][4]),.i2s_ws(pins[0][5]),.i2s_sd(pins[0][6]),.active(active[0]),.monitor_steps(steps[0]),.monitor_envelopes(envs[0]),.deadline_error(deadline[0]),.clip_active(clip[0]));
 final_audio_gain_reference original(.clk(clk),.rst(rst),.gates(gates),.triggers(triggers),.notes(notes),.gains(gains),.timbres(timbres),.ratio(ratio),.mod_depth(mod_depth),.synth_config(32'd0),.sample_tick(pins[1][0]),.pcm(pcm[1]),.hp_bck(pins[1][1]),.hp_ws(pins[1][2]),.hp_din(pins[1][3]),.i2s_bck(pins[1][4]),.i2s_ws(pins[1][5]),.i2s_sd(pins[1][6]),.active(active[1]),.monitor_steps(steps[1]),.monitor_envelopes(envs[1]),.deadline_error(deadline[1]),.clip_active(clip[1]));
 integer cycles=0,frames=0,checks=0,nz=0,j,seed=32'h5a1100a7;reg[31:0]r;
 always @(posedge clk)if(!rst&&pins[0][0])frames++;
 always @(negedge clk)if(!rst)begin
  cycles++;checks++;
  if({pins[0][6:0],pcm[0],active[0],steps[0],envs[0],deadline[0],clip[0]}!=={pins[1][6:0],pcm[1],active[1],steps[1],envs[1],deadline[1],clip[1]})$fatal(1,"GAIN_FLAGS_FAIL complete audio port mismatch cycle=%0d",cycles);
  for(j=0;j<4;j++)if(dut.smooth_sample[j]!==original.smooth_sample[j])$fatal(1,"GAIN_FLAGS_FAIL crossfade sample mismatch");
  if(pcm[0]!=0)nz++;
  if(cycles%137==0||cycles%1024==1023)begin
   r=$random(seed);gates=r[3:0];triggers=r[7:4];ratio=131072+($unsigned($random(seed))%262144);mod_depth=cycles%7?0:127;
   for(j=0;j<4;j++)begin
    notes[j*7+:7]=36+($unsigned($random(seed))%48);timbres[j*3+:3]=(cycles/541+j)%4;
    case((cycles/137+j)%5)
     0:gains[j*12+:12]=0;
     1:gains[j*12+:12]=1;
     2:gains[j*12+:12]=4095;
     default:gains[j*12+:12]=$random(seed);
    endcase
   end
  end else triggers=0;
  if(frames>=4096)begin
   if(nz<100||deadline[0])$fatal(1,"GAIN_FLAGS_FAIL insufficient audio/deadline coverage");
   $display("GAIN_FLAGS_EQ_PASS clocks=%0d frames=%0d nonzero=%0d four timbres/retriggers/gain0,1,4095/random, every PCM and serial output identical",checks,frames,nz);$finish;
  end
 end
 initial begin repeat(8)@(negedge clk);rst=0;end
 initial begin #120000000;$fatal(1,"GAIN_FLAGS_FAIL timeout");end
endmodule
