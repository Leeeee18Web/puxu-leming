`timescale 1ns/1ps
module tb_candidate_frames;
 reg pixel_clk=0;always #9.756 pixel_clk=~pixel_clk;
 reg rstn=0,pedal_down=0,den=0,hsync=0,vsync=0;reg[13:0]x=0,y=0;reg[2:0]page=5;reg[1:0]mode=1;
 reg clk=0;always #10 clk=~clk;
 reg[7:0]choices=8'h95;reg busy=0;
 reg playing=1,muted=0,note_valid=1;reg[6:0]next_note=64,base_note=60;
 reg[3:0]gates=9;reg[27:0]notes=0;reg[47:0]gains=0;
 reg[6:0]home_gates=7'h55;reg[83:0]home_gains=0;
 reg piano_ready=1,touch_ready=1,recording=1,replaying=0,record_full=0;
 reg[12:0]record_count=321;reg[15:0]record_milliseconds=4321;
 reg[2:0]timbre=1;reg timbre_open=0,xy_overview=0;reg[31:0]synth_config=32'h123456;
 reg[6:0]knob=64,raw_knob=93;reg raw_known=1,pickup_wait=0;reg[1:0]touch_state=2;
 reg[1:0]pattern_mode=1;reg[6:0]pattern_selected=2;reg[48:0]pattern_notes=49'h10204081;
 reg pattern_busy=0;reg[2:0]pattern_count=4;reg pattern_full=0;
 reg[6:0]lesson_target=60,lesson_feedback_note=62;reg[1:0]lesson_feedback=1;
 reg[5:0]lesson_position=3;reg lesson_done=0;
 reg[1:0]knob_mode=1;reg[6:0]last_note=60,last_velocity=96,mod_depth=32;
 reg[47:0]wave_data=0;reg[7:0]spectrum_data=0,spectrum_peak=128;
 reg[1:0]spectrum_zoom=2;reg visual_valid=1,xy_data=0,xy_valid=1;reg[5:0]xy_settings=6'b101000;
 wire[9:0]wave_addr0,wave_addr1,tone_addr0,tone_addr1;wire[6:0]spectrum_addr0,spectrum_addr1;
 wire[15:0]xy_addr0,xy_addr1;wire[23:0]rgb0,rgb1,rgb7;wire de0,de1,hs0,hs1,vs0,vs1,de7,hs7,vs7;
 wire[10:0]tone0=2047,tone1=2047;wire[16:0]curve0=0,curve1=0;wire[9:0]count0=0,count1=0;

 reg map_enabled=0,live_mode=1;reg[6:0]map_input_base=60;reg[174:0]map_notes=0;
 reg[11:0]live_gates=0;reg[83:0]live_notes=0,original_keys=0;reg[23:0]owners=0;reg[47:0]channels=0;
 wire[24:0]key_held,visible_held;wire[374:0]key_labels,visible_labels;reg frame_start=0;
 final_keyboard_view keyboard_view(.clk(clk),.rst(!rstn),.live_mode(live_mode),.map_enabled(map_enabled),.base_note(base_note),.map_input_base(map_input_base),.map_notes(map_notes),.live_gates(live_gates),.live_notes(live_notes),.gates(live_gates),.notes(live_notes),.original_keys(original_keys),.owners(owners),.channels(channels),.key_held(key_held),.key_labels(key_labels));
 final_snapshot #(.WIDTH(400),.PERIOD(16)) snapshot(.clk(clk),.rstn(rstn),.source_data({key_held,key_labels}),.pixel_clk(pixel_clk),.pixel_rstn(rstn),.frame_start(frame_start),.data({visible_held,visible_labels}));
 final_panel #(.SHOW_PEDAL(1),.KEYBOARD_VIEW(1)) candidate(.keyboard_held(visible_held),.keyboard_labels(visible_labels),.envelope_choices(choices),.preview_busy(busy),.tone_data(tone0),.tone_curve(curve0),.tone_count(count0),.wave_addr(),.spectrum_addr(),.tone_addr(),.xy_addr(),.rgb(rgb0),.den_out(de0),.hsync_out(hs0),.vsync_out(vs0),.*);
 mature_pif #(.SHOW_PEDAL(1)) reference(.tone_data(tone0),.tone_curve(curve0),.tone_count(count0),.wave_addr(),.spectrum_addr(),.tone_addr(),.xy_addr(),.rgb(rgb1),.den_out(de1),.hsync_out(hs1),.vsync_out(vs1),.*);
 integer f,k,i,xx,yy,fc,fp,stats,nout,differences,unexpected,checks=0;reg capture=0;reg[399:0]frozen_view;reg[24:0]expected;
 task tick(input integer tx,ty,input bit d);begin
  @(negedge pixel_clk);x=tx;y=ty;den=d;
  @(posedge pixel_clk);#1;
  if(capture&&de0)begin
   if($isunknown({rgb0,rgb1}))$fatal(1,"FRAME_UNKNOWN_PIXEL");
   if({visible_held,visible_labels}!==frozen_view)$fatal(1,"KEY_METADATA_CHANGED_DURING_FRAME");
   if({de0,hs0,vs0}!=={de1,hs1,vs1})$fatal(1,"FRAME_PIXEL_SYNC");
   $fwrite(fc,"%c%c%c",rgb0[23:16],rgb0[15:8],rgb0[7:0]);$fwrite(fp,"%c%c%c",rgb1[23:16],rgb1[15:8],rgb1[7:0]);
   if(rgb0!==rgb1)begin
    differences++;
    if(!((nout%1024)>=728&&(nout%1024)<864&&(nout/1024)>=72&&(nout/1024)<120))unexpected++;
   end
   nout++;checks++;
  end
 end endtask
 task publish_view;begin
  repeat(120)tick(0,0,0);frame_start=1;tick(0,0,0);frame_start=0;
  repeat(120)tick(0,0,0);frame_start=1;tick(0,0,0);frame_start=0;repeat(16)tick(0,0,0);
 end endtask
 initial begin
  stats=$fopen("STATS.txt","w");repeat(12)tick(0,0,0);rstn=1;
  page=5;mode=1;playing=0;recording=0;replaying=0;gates=0;pattern_selected=0;pattern_count=0;home_gates=0;timbre=0;timbre_open=0;
  for(k=0;k<25;k++)map_notes[k*7+:7]=60+k;
  for(i=0;i<12;i++)begin original_keys[i*7+:7]=60+i;live_notes[i*7+:7]=60+i;end
  for(f=0;f<12;f++)begin
   case(f)
    0:begin map_enabled=0;live_gates=0;end
    1:begin map_enabled=1;live_gates=12'hfff;end
    2:begin map_input_base=36;live_gates=3;owners=0;channels=0;for(k=0;k<25;k++)map_notes[k*7+:7]=36+(k*7)%61;for(i=0;i<12;i++)begin original_keys[i*7+:7]=36+i;live_notes[i*7+:7]=map_notes[i*7+:7];end end
    3:begin map_input_base=84;live_gates=3;for(k=0;k<25;k++)map_notes[k*7+:7]=96-k;for(i=0;i<12;i++)begin original_keys[i*7+:7]=84+i;live_notes[i*7+:7]=map_notes[i*7+:7];end end
    4:begin map_input_base=60;for(k=0;k<25;k++)map_notes[k*7+:7]=60+k;map_notes[0+:7]=64;map_notes[7+:7]=64;original_keys[0+:7]=60;original_keys[7+:7]=61;owners[3:2]=1;live_notes[0+:7]=64;live_notes[7+:7]=64;live_gates=3;end
    5:begin live_gates=2;end
    6:begin live_gates=0;end
    7:begin page=6;choices=8'h95;busy=0;end
    8:begin choices=8'hff;busy=1;end
    9:begin page=5;busy=0;timbre_open=1;timbre=4;end
    10:begin page=0;timbre_open=0;timbre=0;end
    11:begin page=3;xy_overview=1;end
   endcase
   publish_view;frozen_view={visible_held,visible_labels};
   if(f==1&&visible_held!=25'hfff)$fatal(1,"FRAME_ALL12_MASK %h",visible_held);
   if(f==4&&visible_held!=3)$fatal(1,"FRAME_DUPLICATE_MASK");if(f==5&&visible_held!=2)$fatal(1,"FRAME_DUPLICATE_RELEASE_MASK");
   fc=$fopen($sformatf("candidate_%0d.rgb",f),"wb");fp=$fopen($sformatf("pif_%0d.rgb",f),"wb");nout=0;differences=0;unexpected=0;capture=1;
   for(yy=0;yy<635;yy++)for(xx=0;xx<1344;xx++)begin
    tick(xx,yy,xx<1024&&yy<600);
    if(f==1&&yy==300&&xx==512)begin live_gates=2;owners[3:2]=3;channels[7:4]=14;original_keys[7+:7]=24;live_notes[7+:7]=84;map_notes[0+:7]=37;end
   end
   repeat(12)tick(0,0,0);capture=0;$fclose(fc);$fclose(fp);
   if(nout!=614400)$fatal(1,"FRAME_COUNT %0d",nout);
   if(f==1&&key_held!=(25'b1<<24))$fatal(1,"APP_OBSERVER_OWNER_CHANGE_MISSING");
   if(f==0&&unexpected!=0)$fatal(1,"DEFAULT_PIF_PIXELS_CHANGED_OUTSIDE_REPLACED_TAB %0d",unexpected);
   if(f==10&&differences!=0)$fatal(1,"HOME_PIF_CHANGED %0d",differences);
   $fdisplay(stats,"state=%0d page=%0d mask=%h count=%0d diffpif=%0d outside_tab=%0d",f,page,visible_held,nout,differences,unexpected);
   $display("CANDIDATE_FRAME %0d mask%h diffPIF%0d outsideTab%0d",f,visible_held,differences,unexpected);
  end
  $fdisplay(stats,"pixel_checks=%0d",checks);$fclose(stats);$display("CANDIDATE_FRAMES_PASS");$finish;
 end
endmodule
