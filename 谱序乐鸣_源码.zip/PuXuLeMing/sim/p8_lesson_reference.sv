`timescale 1ns/1ps
// Follow-along grades the same accepted event stream as the live instrument.
// It never supplies notes to the audio engine. One source/channel/key press
// can grade only once until an actual release, channel clear, or disconnect.
module p8_lesson_reference(
 input wire clk,rst,sample_tick,enabled,restart,
 input wire [6:0] base_note,
 input wire event_valid,input wire [31:0] event_data,input wire panic,
 output wire [6:0] target_note,
 output reg [6:0] feedback_note=127,
 output reg [1:0] feedback=0,
 output reg [5:0] position=0,
 output wire done,
 output reg [6:0] correct_count=0,
 output reg [15:0] wrong_count=0
);
 reg [4095:0] held=0;
 reg [6:0] previous_base=60;
 reg previous_enabled=0;
 reg [13:0] feedback_ticks=0;
 wire src=event_data[24];
 wire [7:0] status=event_data[7:0];
 wire [6:0] note=event_data[14:8],velocity=event_data[22:16];
 wire legal_data=!event_data[15]&&!event_data[23];
 wire [11:0] key_index={src,status[3:0],note};
 wire [4:0] channel_index={src,status[3:0]};
 wire new_session=restart || !previous_enabled || base_note!=previous_base;
 wire [5:0] current_position=new_session?6'd0:position;
 function automatic [3:0] song_offset(input [5:0] p);
  begin
   case(p)
    0,1,13,28,29,41:song_offset=0;
    2,3,6,14,15,21,22,30,31,34:song_offset=7;
    4,5,32,33:song_offset=9;
    7,8,16,17,23,24,35,36:song_offset=5;
    9,10,18,19,25,26,37,38:song_offset=4;
    11,12,20,27,39,40:song_offset=2;
    default:song_offset=0;
   endcase
  end
 endfunction
 wire [7:0] target_sum={1'b0,base_note}+{4'd0,song_offset(position)};
 wire [7:0] current_target={1'b0,base_note}+{4'd0,song_offset(current_position)};
 assign done=position==42;
 assign target_note=done||target_sum>127?7'd127:target_sum[6:0];
 always @(posedge clk)begin
  previous_base<=base_note;
  previous_enabled<=enabled;
  if(rst || !enabled)begin
   held<=0;position<=0;feedback<=0;feedback_note<=127;
   correct_count<=0;wrong_count<=0;feedback_ticks<=0;
  end else begin
   if(new_session)begin
    held<=0;position<=0;feedback<=0;feedback_note<=127;
    correct_count<=0;wrong_count<=0;feedback_ticks<=0;
   end else if(sample_tick && feedback_ticks!=0)begin
    feedback_ticks<=feedback_ticks-1'b1;
    if(feedback_ticks==1)begin feedback<=0;feedback_note<=127;end
   end
   if(panic)begin
    held<=0;feedback<=0;feedback_note<=127;feedback_ticks<=0;
   end else if(event_valid)begin
    if(status==8'hff)held[2047:0]<=0;
    else if(legal_data)begin
     if(status[7:4]==8 || (status[7:4]==9 && velocity==0))
      held[key_index]<=0;
     else if(status[7:4]==11 && (note==120 || note==123))
      held[{channel_index,7'd0}+:128]<=0;
     else if(status[7:4]==9 && velocity!=0)begin
      held[key_index]<=1;
      if((new_session || !held[key_index]) && current_position<42)begin
       feedback_note<=note;feedback_ticks<=14'd14648;
       if(current_target<=127 && note==current_target[6:0])begin
        feedback<=1;position<=current_position+1'b1;
        correct_count<=new_session?7'd1:correct_count+1'b1;
       end else begin
        feedback<=2;
        if(new_session)wrong_count<=1;
        else if(wrong_count!=16'hffff)wrong_count<=wrong_count+1'b1;
       end
      end
     end
    end
   end
  end
 end
endmodule

