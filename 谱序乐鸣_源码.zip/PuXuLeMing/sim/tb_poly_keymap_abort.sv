`timescale 1ns/1ps
module tb_poly_keymap_abort;
 reg clk=0,rst=1,abort_transaction=0,command_valid=0,key_seen_valid=0;always #10 clk=~clk;
 reg[7:0]command_op=0;reg[31:0]command_a=0,command_b=0,command_c=0;reg[4:0]key_seen_index=0;
 wire command_done;wire[7:0]command_result;wire[174:0]map_notes;wire[6:0]map_input_base;wire map_enabled,map_apply;wire[31:0]reply_a,reply_b;
 poly_keymap dut(.map_apply_audio(),.map_apply_fx(),.*);integer checks=0,offset,k;reg[15:0]checksum,old_crc;
 function automatic[15:0]cb(input[15:0]c,input[7:0]b);reg[15:0]v;integer n;begin v=c^{b,8'd0};for(n=0;n<8;n=n+1)v=v[15]?(v<<1)^16'h1021:v<<1;cb=v;end endfunction
 task check(input bit ok,input string label);begin checks++;if(!ok)$fatal(1,"MAP_ABORT_FAIL offset=%0d %s",offset,label);end endtask
 task cmd(input[7:0]op,input[31:0]a,b);begin
  @(negedge clk);command_op=op;command_a=a;command_b=b;command_valid=1;
  @(negedge clk);command_valid=0;while(!command_done)@(negedge clk);check(command_result==0,"setup acknowledged");
 end endtask
 initial begin
  for(offset=0;offset<=28;offset++)begin
   @(negedge clk);rst=1;abort_transaction=0;command_valid=0;repeat(3)@(negedge clk);rst=0;old_crc=reply_b[15:0];
   cmd(20,48,0);checksum=cb(cb(16'hffff,48),0);
   for(k=0;k<25;k++)begin cmd(21,k,67);checksum=cb(checksum,67);end
   @(negedge clk);command_op=22;command_a=checksum;command_b=0;command_valid=1;if(offset==0)abort_transaction=1;
   @(negedge clk);command_valid=0;
   if(offset>0)begin repeat(offset-1)@(negedge clk);abort_transaction=1;@(negedge clk);end
   check(command_done&&command_result==4,"abort returns failure acknowledgement");
   check(map_input_base==60&&map_enabled&&reply_b[15:0]==old_crc,"failed ACK leaves base/enabled/CRC unchanged");
   for(k=0;k<25;k++)check(map_notes[k*7+:7]==60+k,"failed ACK leaves every old note unchanged");
   abort_transaction=0;repeat(35)@(negedge clk);check(map_notes[6:0]==60&&dut.phase==0&&!dut.uploading,"no delayed swap after abort");
  end
  // With no abort, the exact same complete transaction must still commit.
  cmd(20,48,0);checksum=cb(cb(16'hffff,48),0);for(k=0;k<25;k++)begin cmd(21,k,67);checksum=cb(checksum,67);end
  cmd(22,checksum,0);check(map_input_base==48&&!map_enabled&&map_notes[6:0]==67&&reply_b[15:0]==checksum,"non-aborted transaction commits");
  $display("POLY_KEYMAP_ABORT_PASS offsets=0..28 checks=%0d",checks);$finish;
 end
 initial begin #10000000;$fatal(1,"abort test timeout");end
endmodule
