`timescale 1ns/1ps
module tb_pixel_timing_equiv;
 reg clk=0,rstn=0,sync=0;always #10 clk=~clk;
 wire[13:0]h,v,x,y,rh,rv,rx,ry;wire vs,hs,de,ls,rvs,rhs,rde,rls;
 final_video_timing_ctrl #(.video_hlength(1344),.video_vlength(635),.video_hsync_len(20),.video_hbp_len(140),.video_h_visible(1024),.video_vsync_len(3),.video_vbp_len(20),.video_v_visible(600)) dut(clk,rstn,sync,h,v,x,y,vs,hs,de,ls,);
 reference_pixel_timing #(.video_hlength(1344),.video_vlength(635),.video_hsync_len(20),.video_hbp_len(140),.video_h_visible(1024),.video_vsync_len(3),.video_vbp_len(20),.video_v_visible(600)) refdut(clk,rstn,sync,rh,rv,rx,ry,rvs,rhs,rde,rls);
 integer checks=0;
 always @(negedge clk)begin
  if({h,v,x,y,vs,hs,de,ls}!=={rh,rv,rx,ry,rvs,rhs,rde,rls})$fatal(1,"PIXEL_TIMING_EQ_FAIL check=%0d xy=%0d,%0d ref=%0d,%0d",checks,x,y,rx,ry);
  checks++;
 end
 initial begin
  repeat(4)@(posedge clk);#1;rstn=1;
  repeat(1800000)@(posedge clk);#1;sync=1;
  repeat(3)@(posedge clk);#1;sync=0;
  repeat(1000)@(posedge clk);#1;rstn=0;
  repeat(4)@(posedge clk);#1;rstn=1;
  repeat(900000)@(posedge clk);#1;
  $display("PIXEL_TIMING_EQ_PASS checks=%0d sync/reset/frame/blanking",checks);$finish;
 end
endmodule
