`timescale 1ns/1ps
module tb_poly25_keymap_top;
 reg clk=0,rstn=0,rx=1;always #10 clk=~clk;
 tri dp,dm;wire tx;
 hub_play_top dut(.clk(clk),.rstn(rstn),.key1_n(1'b1),.key2_n(1'b1),.uart_rx(rx),.uart_tx(tx),
  .usb_dp(dp),.usb_dm(dm),.hp_bck(),.hp_ws(),.hp_din(),.i2s_bck(),.i2s_ws(),.i2s_sd(),
  .pa_en(),.led_o(),.tmds_clk_p_0(),.tmds_clk_n_0(),.tmds_d_p_0(),.tmds_d_n_0());
 defparam dut.status_bridge.PERIOD=10;
 defparam dut.wifi_control.WATCHDOG_MS=5;
 integer checks=0,replies=0,ti=0,pcm_nz=0,host_fd,host_bytes=0;
 reg[7:0]host_byte;
 integer rec_fd,rec_i,rec_half,physical_on=0,touch_on=0;reg[31:0]take_id,saved_duration;reg[12:0]saved_count;reg[95:0]rec_word;
 initial host_fd=$fopen("final_uart_reply.hex","w");
 always begin
  @(negedge tx);repeat(651)@(negedge clk);
  for(integer h=0;h<8;h++)begin host_byte[h]=tx;repeat(434)@(negedge clk);end
  check(tx,"original UART stop bit");$fdisplay(host_fd,"%02x",host_byte);host_bytes++;
 end
 reg[7:0]reply[0:21];reg[7:0]last_result;reg[15:0]last_seq,reply_crc=16'hffff;
 task check(input bit ok,input string label_text);begin checks++;if(!ok)$fatal(1,"FINAL_WIFI_FAIL %s",label_text);end endtask
 task clocks(input integer count);begin repeat(count)@(negedge clk);end endtask
 task frames(input integer count);integer j;begin for(j=0;j<count;j++)begin @(posedge dut.sample_tick);@(negedge clk);end end endtask
 function automatic[15:0]crc(input[15:0]c,input[7:0]b);reg[15:0]v;integer j;
 begin v=c^{b,8'd0};for(j=0;j<8;j++)v=v[15]?(v<<1)^16'h1021:v<<1;crc=v;end endfunction
 function automatic[15:0]score_crc(input[15:0]start,input[31:0]tick,input[31:0]word);reg[15:0]v;integer j;
  begin v=start;for(j=0;j<4;j++)v=crc(v,tick>>(8*j));for(j=0;j<4;j++)v=crc(v,word>>(8*j));score_crc=v;end endfunction
 always @(posedge clk)if(!dut.rst&&dut.sample_tick)begin
  check(!dut.audio_deadline_error,"audio deadline maintained with mobile ingress");
  if(dut.pcm!=0)pcm_nz++;
 end
 always @(posedge clk)if(dut.touch_update&&dut.touch_status[24])
  $display("TOUCH page=%0d xy=%h hit=%0d head=%0d tab=%0d",dut.page,dut.touch_xy,dut.touch_controls.rec_hit,dut.touch_controls.head,dut.touch_controls.tab);
 always @(posedge clk)if(dut.replay_toggle)$display("REPLAY_PULSE");
 always @(posedge dut.usb_clk)if(dut.soc.wifi_tx_valid&&dut.soc.wifi_tx_ready)begin
  reply[ti]=dut.soc.wifi_tx_data;
  if(ti>=2&&ti<=19)reply_crc=crc(reply_crc,dut.soc.wifi_tx_data);
  if(ti==21)begin
   check(reply[0]=="P"&&reply[1]=="W"&&reply[2]==1,"PW1 response across both CDCs");
   check({reply[21],reply[20]}==reply_crc,"real wire reply CRC");
   check({reply[19],reply[18],reply[17],reply[16]}==32'h50385731,"original ESP identity unchanged");
   last_seq={reply[5],reply[4]};last_result=reply[8];replies++;ti=0;reply_crc=16'hffff;
  end else ti++;
 end
 task command(input[7:0]op,input[15:0]seq,input[31:0]a,b,c,input[7:0]expected);
 reg[7:0]p[0:21];reg[15:0]v;integer j,target,timeout;begin
  p[0]="P";p[1]="W";p[2]=1;p[3]=op;p[4]=seq[7:0];p[5]=seq[15:8];p[6]=8'h34;p[7]=8'h12;
  for(j=0;j<4;j++)begin p[8+j]=a>>(8*j);p[12+j]=b>>(8*j);p[16+j]=c>>(8*j);end
  v=16'hffff;for(j=2;j<20;j++)v=crc(v,p[j]);p[20]=v[7:0];p[21]=v[15:8];
  target=replies+1;for(j=0;j<22;j++)dut.soc.wifi_byte(p[j]);
  timeout=0;while(replies<target&&timeout<20000)begin @(negedge clk);timeout++;end
  check(replies==target&&last_seq==seq,"command gets real matched FPGA ACK");
  if(last_result!=expected)$display("ACK op=%0d result=%0d expected=%0d",op,last_result,expected);
  check(last_result==expected,"expected result from production PW1");clocks(100);
 end endtask
 task tap(input integer x,y);begin
  dut.soc.hid_report(x,y,0,1);clocks(50);dut.soc.hid_report(x,y,1,1);clocks(50);dut.soc.hid_report(x,y,0,1);clocks(50);
 end endtask
 task eventword(input[31:0]word);begin dut.soc.midi_event(word);clocks(150);end endtask
 task serial_byte(input[7:0]b);integer j;begin
  @(negedge clk);rx=0;clocks(434);
  for(j=0;j<8;j++)begin rx=b[j];clocks(434);end
  rx=1;clocks(434);
 end endtask
 task host_hello;reg[7:0]p[0:17];reg[15:0]v;integer j;begin
  p[0]="G";p[1]="S";p[2]=2;p[3]=8'h26;p[4]=1;p[5]=0;p[6]=8;p[7]=0;
  p[8]=0;p[9]=0;p[10]=0;p[11]=0;p[12]="P";p[13]="8";p[14]="G";p[15]="1";
  v=16'hffff;for(j=2;j<16;j++)v=crc(v,p[j]);p[16]=v[7:0];p[17]=v[15:8];
  for(j=0;j<18;j++)serial_byte(p[j]);
 end endtask
 function automatic integer mobile_count;integer j;begin mobile_count=0;
  for(j=0;j<25;j++)if(dut.live_gates[j]&&dut.voices.owners[j]==3&&dut.voices.channels[j]==14)mobile_count++;
 end endfunction
 function automatic integer physical_count;integer j;begin physical_count=0;
  for(j=0;j<25;j++)if(dut.live_gates[j]&&dut.voices.owners[j]==1)physical_count++;
 end endfunction

 function automatic[6:0]mapped_note(input integer index);
 begin mapped_note=index==0||index==1?72:index==24?55:60+index;end endfunction
 function automatic integer held_count(input[1:0]source,input[6:0]note);
 integer n;begin held_count=0;for(n=0;n<25;n=n+1)if(dut.live_gates[n]&&dut.voices.owners[n]==source&&dut.live_notes[n*7+:7]==note)held_count++;end endfunction
 integer n;reg[15:0]map_crc;integer applies=0;
 always @(posedge clk)if(!dut.rst&&dut.map_apply)applies++;
 initial begin
  clocks(10);rstn=1;clocks(1000);dut.soc.ptest_debug[255:224]=32'h2c;clocks(150);
  tap(300,280);tap(650,96);command(0,1,32'h50385731,0,0,0);
  tap(100,195);frames(2);check(dut.recording,"recording before mapping");
  eventword(32'h00643c90);eventword(32'h00643d90);eventword(32'h00645490);frames(110);
  eventword(32'h007f40b0);eventword(32'h00003c80);eventword(32'h00003d80);eventword(32'h00005480);frames(2);
  check($countones(dut.live_gates)==3,"old pedal holds three notes");
  command(20,2,60,1,0,0);
  map_crc=crc(crc(16'hffff,60),1);
  for(n=0;n<25;n=n+1)begin command(21,3+n,n,mapped_note(n),0,0);map_crc=crc(map_crc,mapped_note(n));end
  command(22,28,map_crc,0,0,0);
  check(applies==1&&dut.map_notes[0+:7]==72&&dut.map_notes[168+:7]==55,"atomic actual table and single apply pulse");
  $display("MAP_COMMIT_OBS gates%h sustain%h replay%b rec%b count%0d audio%h",dut.live_gates,dut.voices.sustain,dut.replaying,dut.recording,dut.record_count,dut.gates);
  check(dut.live_gates==0&&dut.voices.sustain==0&&!dut.replaying,"commit immediately clears old note and pedal ownership");frames(2);
  check(!dut.replaying&&!dut.recording&&dut.record_count>0,"sample-boundary recorder panic preserves captured take");
  check(dut.audio.map_release.weight!=0,"actual output mapping fade engaged");frames(70);
  check(dut.gates==0&&!dut.audio.map_release.weight,"no old ingress ghosts after fade");
  eventword(32'h00643c90);eventword(32'h00643d90);frames(6);
  check(held_count(1,72)==2,"two physical original keys map to independent same-pitch owners");
  eventword(32'h00003c80);frames(3);check(held_count(1,72)==1,"physical duplicate independent release");
  command(1,29,32'h1000003,32'h3c64,0,0);frames(80);
  check(held_count(3,72)==2&&held_count(3,55)==1&&held_count(1,72)==1,"phone three indexed keys and physical source coexist with mapping");
  command(1,30,32'h1000002,32'h3c64,0,0);frames(2);
  check(held_count(3,72)==1&&held_count(3,55)==1&&held_count(1,72)==1,"phone duplicate noteoff matches original key ID");
  command(23,31,24,0,0,0);check(reply[9]==55&&reply[10]==60,"readback actual FPGA applied map");
  command(2,32,0,0,0,0);frames(3);check(held_count(3,72)==0&&held_count(3,55)==0&&held_count(1,72)==1,"scoped phone release preserves physical unison");
  $display("POLY25_KEYMAP_TOP_PASS checks%0d atomic mapping pedal/record/fade duplicates/source/readback",checks);$finish;
 end
 initial begin #20000000;$fatal(1,"POLY25_KEYMAP_TOP_TIMEOUT");end
endmodule
