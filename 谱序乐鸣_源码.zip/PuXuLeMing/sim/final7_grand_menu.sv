`timescale 1ns/1ps
module tb_final7_grand_menu;
 reg clk=0,rst=1,update=0,valid=1,down=0;always #10 clk=~clk;
 reg[15:0]x=0,y=0;wire[2:0]tone;wire[2:0]page;
 final_navigation #(.DEFAULT_TIMBRE(1),.HIDE_EP(1)) dut(.clk(clk),.rst(rst),.touch_update(update),.touch_valid(valid),.touch_down(down),.touch_key_base(7'd60),.touch_x(x),.touch_y(y),.event_ready(1'b1),.panic_key(1'b0),.centre_key(1'b0),.preview_busy(1'b0),.timbre(tone),.page(page));
 task tap(input integer px,py);begin @(negedge clk);x=px;y=py;update=1;down=1;@(negedge clk);down=0;@(negedge clk);update=0;repeat(2)@(negedge clk);end endtask
 initial begin repeat(4)@(negedge clk);rst=0;repeat(2)@(negedge clk);if(tone!==1)$fatal(1,"GRAND_DEFAULT");tap(300,280);if(page==0)$fatal(1,"FREE_PAGE");
 for(integer i=1;i<=4;i++)begin tap(800,30);tap(800,94+44*(i-1));if(tone!==i)$fatal(1,"FOUR_MENU_ID got%0d expected%0d",tone,i);end
 tap(800,30);tap(800,270);if(tone!==4)$fatal(1,"REMOVED_ROW_CHANGED_TONE");
 $display("FINAL7_GRAND_MENU_PASS default1/fourIDs1to4/noEP/oldfifthrowinactive");$finish;end
 initial begin #1000000;$fatal(1,"TIMEOUT");end
endmodule
