module p8_wifi_control #(parameter CLOCK_HZ=50000000,WATCHDOG_MS=500)(
 input clk,rst,sample_tick,playable,clear_notes,input[1:0]mode,input muted,
 input[7:0]rx_data,input rx_valid,output rx_ready,output[7:0]tx_data,
 output tx_valid,input tx_ready,output[31:0]event_data,output event_valid,input event_ready,
 output score_playing,output[8:0]score_position,score_count);
 assign rx_ready=1;assign tx_data=0;assign tx_valid=0;assign event_data=0;
 assign event_valid=0;assign score_playing=0;assign score_position=0;assign score_count=0;
endmodule
