`timescale 1ns/1ps
module tb_poly_context_ring;
 parameter N=7,W=97;
 reg clk=0;always #10 clk=~clk;reg rst=1,save=0;reg[2:0]index=0;reg[W-1:0]data=0;wire[W-1:0]out;wire valid;
 poly_context_store #(.WIDTH(W),.COUNT(N),.ROTATING(1)) dut(clk,rst,save,index,data,out,valid);
 reg[W-1:0]model[0:N-1];reg[N-1:0]known=0;reg[W-1:0]before_value;reg before_valid;integer round,i,bit_index,head=0,checks=0;
 task compare;begin
  if(valid!==known[head]||out!==(known[head]?model[head]:97'd0))$fatal(1,"RING_HEAD_FAIL N%0d turn%0d head%0d valid%b want%b",N,round,head,valid,known[head]);checks++;
 end endtask
 initial begin repeat(4)@(negedge clk);rst=0;
 for(round=0;round<12000;round=round+1)begin
  index=head;compare;before_value=out;before_valid=valid;
  data={32'h51abcdef,32'h112a3456,32'h00004321,1'b1}^(round*97'd72983)^head;save=1;
  if(W>97)for(bit_index=97;bit_index<W;bit_index=bit_index+1)data[bit_index]=((round*13+bit_index*17+head)>>(bit_index%11))&1;
  @(negedge clk);save=0;
  if(out!==before_value||valid!==before_valid)$fatal(1,"RING_SAVE_NOT_LOCALLY_REGISTERED");
  model[head]=data;known[head]=1;
  @(negedge clk);head=(head+1)%N;index=head;compare;
  repeat(round%5+1)begin @(negedge clk);compare;end
  if(round%499==498)begin rst=1;@(negedge clk);rst=0;known=0;head=0;index=0;compare;end
 end
 $display("POLY_CONTEXT_RING_PASS N%0d checks%0d delayedlocalCE/rotation/reset/idle",N,checks);$finish;
 end
endmodule
module tb_poly_context_ring6;tb_poly_context_ring #(.N(6)) t();endmodule
module tb_poly_context_ring1;tb_poly_context_ring #(.N(1)) t();endmodule
module tb_poly_context_ring1777;tb_poly_context_ring #(.N(2),.W(1777)) t();endmodule
module tb_poly_context_ring1777n1;tb_poly_context_ring #(.N(1),.W(1777)) t();endmodule
