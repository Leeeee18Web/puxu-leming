`timescale 1ns/1ps
module tb_poly_tuning_operand_boundary;
 `include "src/poly/poly_model_layout.vh"
 reg clk=0;always #10 clk=~clk;reg rst=1,tick=0,trig=0,en=1,load=0;
 poly_model_line dut(.clk(clk),.rst(rst),.tick(tick),.trigger(trig),.gate(1'b1),.kind(3'd1),.velocity(12'd2400),.step(24'd151197),.rate_shift(2'd0),.period_q10(24'd100000),.sample(),.envelope(),.busy(),.deadline_error(),.bridge_return(18'sd0),.bridge_incident(),.piano_mode(1'b1),.bridge_incident_next(),.ctx_enable(en),.ctx_load(load),.ctx_data({`POLY_MODEL_LINE_W{1'b0}}),.ctx_state(),.mem_q(18'd1800),.mem_raddr(),.mem_waddr(),.mem_we(),.mem_data(),.shared_tuning(16'd0),.shared_impact(18'sd0),.impact_phase());
 reg signed[17:0]want_a,want_b;
 reg signed[25:0]want_mul_a,want_mul_b;
 initial begin
  repeat(3)@(negedge clk);rst=0;repeat(2)@(negedge clk);tick=1;@(negedge clk);tick=0;
  wait(dut.state==25);#1;want_mul_a=dut.mul_a;want_mul_b=dut.mul_b;
  if(want_mul_a==0||want_mul_b==0)$fatal(1,"TUNING_BOUNDARY_EMPTY");
  force dut.state=6'd0;#1;
  if(dut.mul_a!==want_mul_a||dut.mul_b!==want_mul_b)$fatal(1,"TUNING_OPERAND_REGISTER_BOUNDARY_MISSING");
  $display("POLY_TUNING_OPERAND_BOUNDARY_PASS live state cannot cross tuning operands FF midclock");$finish;
 end
 initial begin #100000;$fatal(1,"FILTER_OPERAND_BOUNDARY_TIMEOUT");end
endmodule
