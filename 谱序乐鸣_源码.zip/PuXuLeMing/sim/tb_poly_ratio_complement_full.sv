`timescale 1ns/1ps
module tb_poly_ratio_complement_full;
 `include "src/poly/poly_model_layout.vh"
 reg clk=0,rst=0,tick=0,trig=0,en=0,load=0;
 poly_model_line dut(.clk(clk),.rst(rst),.tick(tick),.trigger(trig),.gate(1'b1),.kind(3'd1),.velocity(12'd2400),.step(24'd151197),.rate_shift(2'd0),.period_q10(24'd100000),.sample(),.envelope(),.busy(),.deadline_error(),.bridge_return(18'sd0),.bridge_incident(),.piano_mode(1'b1),.bridge_incident_next(),.ctx_enable(1'b0),.ctx_load(load),.ctx_data({`POLY_MODEL_LINE_W{1'b0}}),.ctx_state(),.mem_q(18'd1800),.mem_raddr(),.mem_waddr(),.mem_we(),.mem_data(),.shared_tuning(16'd0),.shared_impact(18'sd0),.impact_phase());
 integer i;reg[24:0]value,want,got;reg[3:0]borrow;
 initial begin
  for(i=0;i<33554432;i=i+1)begin
   value=i;borrow={|value[19:0],|value[14:0],|value[9:0],|value[4:0]};
   want=25'd20971520-value;got=dut.ratio_complement(value,borrow);
   if(got!==want)$fatal(1,"RATIO_COMPLEMENT_FULL value%h borrow%b got%h want%h",value,borrow,got,want);
  end
  $display("POLY_RATIO_COMPLEMENT_FULL_PASS 33554432 all25bit inputs exact original modulo2^25 subtract every5/10/15/20bit borrow boundary");$finish;
 end
endmodule
