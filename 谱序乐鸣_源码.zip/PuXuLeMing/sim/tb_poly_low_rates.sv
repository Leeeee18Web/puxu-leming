`timescale 1ns/1ps
module tb_poly_low_rates #(parameter LENGTH=2112);
 localparam REED_LENGTH=LENGTH==2048?2050:LENGTH;
 reg clk=0;always #10 clk=~clk;reg rst=1,start=0;reg[6:0]gates=7'h7f,triggers=0;reg[167:0]steps=0;reg[83:0]gains=0;reg[20:0]tones=0;
 wire[111:0]samples,envelopes;wire[6:0]active;wire busy,err;
 poly_voice_worker #(.CONTEXTS(7),.LENGTH(LENGTH)) dut(.clk(clk),.rst(rst),.start(start),.model_reset({3{rst}}),.gates(gates),.triggers(triggers),.steps(steps),.gains(gains),.timbres(tones),.samples(samples),.envelopes(envelopes),.active(active),.busy(busy),.deadline_error(err),.out_valid(),.out_index(),.out_sample(),.control_resetn_early(1'b1));
 integer f,c,i,reads=0;
 always @(posedge clk)if(!rst&&dut.core_enable&&dut.running&&dut.phase>=5)begin
  if(dut.is_reed&&dut.rra>=REED_LENGTH)$fatal(1,"LOW_REED_READ_OUT_OF_REGION context%0d addr%0d",dut.context_index,dut.rra);
  if(dut.is_strings&&(dut.sra>=LENGTH||dut.srb>=LENGTH||dut.src>=LENGTH))$fatal(1,"LOW_STRING_READ_OUT_OF_REGION");
  reads=reads+1;
 end
 initial begin
 for(i=0;i<7;i=i+1)begin steps[i*24+:24]=(i<3)?1874:(i==3?8192:i==4?2048:i==5?8192:1874);gains[i*12+:12]=2400;tones[i*3+:3]=i==0?1:i==1?2:i==6?0:3;end
 repeat(5)@(negedge clk);rst=0;
 for(f=0;f<2000;f=f+1)begin
  triggers=f==0?7'h7f:0;
  for(c=0;c<1024;c=c+1)begin start=c==32;@(negedge clk);if(c==1008&&err)$fatal(1,"LOW_RATE_DEADLINE frame%0d",f);end
 end
 if(reads<100000)$fatal(1,"LOW_RATE_COVERAGE");
 $display("POLY_LOW_RATE_PASS readchecks=%0d lowest MIDI0 with min ratio/thresholds/all memory regions bounded",reads);$finish;
 end
 initial begin #60000000;$fatal(1,"LOW_RATE_TIMEOUT");end
endmodule
module tb_poly_low_rates2048;tb_poly_low_rates #(.LENGTH(2048)) t();endmodule
