`timescale 1ns/1ps
module phys_strings_tb;
reg clk=0; always #10 clk=~clk;
reg rst=1,tick=0,gate=0,trigger=0;
reg[23:0]step=151183;reg[11:0]gain=3400;reg[2:0]timbre=1;
wire signed[15:0]sample;wire[15:0]envelope;wire active,busy,deadline_error;
phys_string_voice dut(clk,rst,tick,gate,trigger,step,gain,timbre,sample,envelope,active,busy,deadline_error);
integer f,n,i,t,fd,cycle=0,maxbusy=0,peak;
task frame;
begin
 @(negedge clk);tick=1;@(negedge clk);tick=0;
 repeat(1022)@(negedge clk);
 if(deadline_error)$fatal(1,"FAIL deadline");
end endtask
task onset;
begin gate=1;trigger=1;@(negedge clk);trigger=0;repeat(10000)@(negedge clk);end endtask
initial begin
 repeat(4)@(negedge clk);rst=0;
 for(t=1;t<=2;t=t+1)begin
 timbre=t;
 for(n=0;n<4;n=n+1)begin
 case(n)0:step=37800;1:step=75599;2:step=151197;3:step=302394;endcase
 onset();fd=$fopen($sformatf("strings_%0d_%0d.txt",t,n),"w");
 peak=0;for(i=0;i<9000;i=i+1)begin frame();$fdisplay(fd,"%0d",sample);if(sample>peak)peak=sample;end
 if(peak<20)$fatal(1,"FAIL no string motion");
 $fclose(fd);
 end
 step=151197;onset();fd=$fopen($sformatf("strings_dynamic_%0d.txt",t),"w");
 for(i=0;i<20000;i=i+1)begin
 if(i==6000)step=226190;
 if(i==12000)gate=0;
 if(i==18000)gain=0;
 frame();$fdisplay(fd,"%0d",sample);
 if(i>=18000&&(sample!==0||active!==0||envelope!==0))$fatal(1,"FAIL hard mute");
 end
 $fclose(fd);gain=3400;
 end
 $display("PASS phys_strings frames=112000 pitch/dynamic/gate/mute");$finish;
end
endmodule
