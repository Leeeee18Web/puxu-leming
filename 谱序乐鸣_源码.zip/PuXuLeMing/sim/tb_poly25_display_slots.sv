`timescale 1ns/1ps
module tb_poly25_display_slots;
reg clk=0;always #10 clk=~clk;reg rst=1;reg[24:0]gates=0;reg[174:0]notes=0;reg[299:0]gains=0;wire[3:0]pg;wire[27:0]pn;wire[47:0]pa;integer i;
poly25_display_slots dut(clk,rst,gates,notes,gains,pg,pn,pa);
initial begin
 for(i=0;i<25;i=i+1)begin notes[i*7+:7]=40+i;gains[i*12+:12]=1000+i;end
 repeat(4)@(negedge clk);rst=0;gates[24]=1;repeat(55)@(negedge clk);
 if(pg!==8||pn[21+:7]!==64||pa[36+:12]!==1024)$fatal(1,"PANEL_VOICE24");
 gates[3]=1;gates[9]=1;gates[14]=1;gates[20]=1;repeat(55)@(negedge clk);
 if(pg!==15||pn!=={7'd60,7'd54,7'd49,7'd43})$fatal(1,"PANEL_GROUP_SELECTION %h",pn);
 gates=0;repeat(55)@(negedge clk);if(pg||pn||pa)$fatal(1,"PANEL_RELEASE");
 $display("POLY25_PANEL_PASS voice24/allgroups/lowestslot/release");$finish;
end
endmodule
