`timescale 1ns/1ps
module hw113_phase_case #(parameter T=1464844)(output reg done=0);
 reg clk=0;always #10 clk=~clk;
 reg rst=1,sample_tick=0;integer n;
 tone_history #(.TOTAL_SAMPLES(T),.PREDICT_WRITE(1)) dut(
 .clk(clk),.rst(rst),.restart(1'b0),.sample_tick(sample_tick),.recording(1'b1),.pitch(11'd960),.pitch_valid(1'b1),
 .pixel_clk(clk),.pixel_rstn(!rst),.frame_start(1'b1),.read_addr(10'd0),.read_enable(1'b0),.pitch_data(),.visible_count(),.curve_sum());
 reg[20:0]expected;
 initial begin
  repeat(4)@(negedge clk);rst=0;sample_tick=1;
  // Coherent deposits cover all 21-bit phase states, including unreachable
  // extremes, so the next comparison is independent of a sparse-tick contract.
  for(n=0;n<2097152;n++)begin
   @(negedge clk);dut.phase=n;dut.phase_bin_ready=n>=T-768;dut.column=0;dut.last_recording=1;dut.restart_pending=0;
   expected=n>=T-768?n+768-T:n+768;
   @(posedge clk);#1;
   if(dut.phase!==expected||dut.phase_bin_ready!==(expected>=T-768))$fatal(1,"HW113_EXHAUSTIVE_PHASE T%0d old%0d phase%0d expected%0d flag%0b",T,n,dut.phase,expected,dut.phase_bin_ready);
  end
  $display("HW113_EXHAUSTIVE_PHASE_PASS T%0d all2097152phaseValues sameEdge/consecutiveTicks/21bitWrap",T);done=1;
 end
 initial begin #50000000;$fatal(1,"HW113_PHASE_TIMEOUT");end
endmodule
module tb_hw113_phase;
 wire[3:0]done;
 hw113_phase_case #(.T(1464844)) production(done[0]);
 hw113_phase_case #(.T(2003)) both_thresholds(done[1]);
 hw113_phase_case #(.T(1536)) equality_boundary(done[2]);
 hw113_phase_case #(.T(2097152)) width_boundary(done[3]);
 initial begin wait(&done);$finish;end
endmodule
