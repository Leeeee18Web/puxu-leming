`timescale 1ns/1ps
module tb_performance_export;
reg clk=0;always #5 clk=~clk;reg rst=1;reg[3:0]phase=0;always @(posedge clk)phase<=phase+1'b1;wire sample_tick=phase==15;
reg[3:0]gates=0,triggers=0;reg[27:0]notes={7'd0,7'd0,7'd64,7'd60};reg[47:0]gains={12'd0,12'd0,12'd1800,12'd3000};wire recording,replaying,full,time_limit,export_ready;wire[12:0]record_count;wire[31:0]duration,take_id;wire[11:0]export_address;wire[95:0]export_word;wire toggle_record;
final_recorder rec(.observer_gains(),.clk(clk),.rst(rst),.sample_tick(sample_tick),.record_toggle(toggle_record),.replay_toggle(1'b0),.clear(1'b0),.panic(1'b0),.in_gates(gates),.in_triggers(triggers),.in_notes(notes),.in_gains(gains),.in_timbres(12'd16),.in_ratio(19'd262144),.in_mod_depth(7'd0),.in_synth_config(32'd0),.recording(recording),.replaying(replaying),.full(full),.time_limit(time_limit),.count(record_count),.duration_samples(duration),.export_address(export_address),.export_word(export_word),.export_ready(export_ready),.take_id(take_id),.preview_rst(1'b0),.preview_gates('0),.preview_notes('0),.preview_gains('0),.preview_timbres('0),.preview_ratio('0),.preview_mod_depth('0),.preview_synth_config('0));
reg[7:0]rx=0;reg rv=0;wire rr;wire[7:0]tx;wire tv;
p8_wifi_control #(.CLOCK_HZ(100000)) dut(.map_apply_audio(),.map_apply_fx(),.clk(clk),.rst(rst),.sample_tick(sample_tick),.playable(1'b1),.clear_notes(1'b0),.live_link_lost(1'b0),.mode(2'd0),.muted(1'b0),.rx_data(rx),.rx_valid(rv),.rx_ready(rr),.tx_data(tx),.tx_valid(tv),.tx_ready(1'b1),.event_ready(1'b1),.recording(recording),.record_replaying(replaying),.record_full(full),.record_time_limit(time_limit),.record_export_ready(export_ready),.record_count(record_count),.record_duration(duration),.record_take_id(take_id),.record_read_word(export_word),.record_read_address(export_address),.record_toggle_request(toggle_record));
reg[7:0]p[0:21],reply[0:21];integer ri=0,seq=0,checks=0,n,k,i,fd;reg[15:0]crc;reg[31:0]a,b,id;reg[95:0]word;reg[47:0]part;reg[12:0]saved_count;
function automatic[15:0]cb(input[15:0]c,input[7:0]v);integer j;reg[15:0]x;begin x=c^{v,8'd0};for(j=0;j<8;j++)x=x[15]?(x<<1)^16'h1021:x<<1;cb=x;end endfunction
task check(input bit ok,input string msg);begin checks++;if(!ok)$fatal(1,"FAIL %s",msg);end endtask
always @(posedge clk)if(tv)begin reply[ri]=tx;ri++;end
task command(input integer op,input[31:0]x,y,z,input[7:0]expected);begin
ri=0;p[0]=80;p[1]=87;p[2]=1;p[3]=op;p[4]=seq;p[5]=seq>>8;p[6]=37;p[7]=0;
for(k=0;k<4;k++)begin p[8+k]=x>>(8*k);p[12+k]=y>>(8*k);p[16+k]=z>>(8*k);end
crc=16'hffff;for(k=2;k<20;k++)crc=cb(crc,p[k]);p[20]=crc;p[21]=crc>>8;
for(k=0;k<22;k++)begin @(negedge clk);n=0;while(!rr)begin @(negedge clk);n++;if(n>100000)$fatal(1,"FAIL rx");end rx=p[k];rv=1;@(negedge clk);rv=0;end
n=0;while(ri<22)begin @(negedge clk);n++;if(n>100000)$fatal(1,"FAIL reply op=%0d",op);end
check(reply[8]==expected,"command result");check({reply[19],reply[18],reply[17],reply[16]}==32'h50385731,"identity retained");a={reply[11],reply[10],reply[9],reply[8]};b={reply[15],reply[14],reply[13],reply[12]};seq++;
end endtask
task samples(input integer count);begin repeat(count)begin @(posedge sample_tick);@(negedge clk);end end endtask
initial begin repeat(5)@(negedge clk);rst=0;command(0,32'h50385731,0,0,0);command(13,1,0,0,0);check(recording,"explicit record start");gates=1;samples(5);gates=3;samples(5);gates=2;samples(5);gates=0;samples(5);command(13,2,0,0,0);check(!recording&&export_ready,"stop drains writes");saved_count=record_count;id=take_id;
fd=$fopen("record_words.hex","w");for(i=0;i<saved_count;i++)begin command(15,i,0,id,0);part={b[23:0],a[31:8]};check(b[31:24]==8'he0,"part0 marker");word[47:0]=part;command(15,i,1,id,0);word[95:48]={b[23:0],a[31:8]};check(b[31:24]==8'he1,"part1 marker");check(word==rec.event_ram[i],"exact recorder readout");$fdisplay(fd,"%024x",word);end $fclose(fd);
command(15,saved_count,0,id,1);command(13,1,0,0,0);check(take_id!=id,"new recording changes generation");command(15,0,0,id,2);samples(4);command(13,2,0,0,0);command(15,0,0,id,4);check(record_count>0,"new take retained");
$display("PERFORMANCE_EXPORT_PASS checks=%0d count=%0d duration=%0d",checks,saved_count,duration);$finish;end
initial begin #100000000;$fatal(1,"FAIL timeout");end
endmodule
