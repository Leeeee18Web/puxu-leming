`timescale 1ns/1ps
// Exact same-edge comparison against the complete best96 module.
module hw113_count_case #(parameter P=1)(output reg done=0);
 reg clk=0,pclk=0;always #10 clk=~clk;always #9.756 pclk=~pclk;
 reg rst=1,prstn=0,restart=0,tick=0,recording=0,frame_start=0,enable=1;
 reg[9:0]addr=0;reg[10:0]pitch=960;
 wire[10:0]a,b;wire[9:0]ca,cb;wire[16:0]sa,sb;
 tone_history #(.PREDICT_WRITE(1),.TOTAL_SAMPLES(2003),.READ_GATED(1),.PIPELINED_READ(P)) dut(
 .clk(clk),.rst(rst),.restart(restart),.sample_tick(tick),.recording(recording),.pitch(pitch),.pitch_valid(1'b1),
 .pixel_clk(pclk),.pixel_rstn(prstn),.frame_start(frame_start),.read_addr(addr),.read_enable(enable),.pitch_data(a),.visible_count(ca),.curve_sum(sa));
 hw113_old_history #(.TOTAL_SAMPLES(2003),.READ_GATED(1),.PIPELINED_READ(P)) old(
 .clk(clk),.rst(rst),.restart(restart),.sample_tick(tick),.recording(recording),.pitch(pitch),.pitch_valid(1'b1),
 .pixel_clk(pclk),.pixel_rstn(prstn),.frame_start(frame_start),.read_addr(addr),.read_enable(enable),.pitch_data(b),.visible_count(cb),.curve_sum(sb));
 genvar g;
 generate for(g=0;g<7;g++)begin:init_banks
  if(P)begin:stage1_check
   always @(posedge pclk)begin #1;
    if({dut.taps[g].clamp_pipeline.zero_q,dut.taps[g].clamp_pipeline.last_q,dut.taps[g].clamp_pipeline.address_zero_q}!=={old.taps[g].clamp_pipeline.zero_q,old.taps[g].clamp_pipeline.last_q,old.taps[g].clamp_pipeline.address_zero_q})$fatal(1,"ZERO68_STAGE1_CHANGED");
   end
  end
  integer j;initial for(j=0;j<256;j++)begin dut.banks[g].samples[j]=(j*157+g*911+13)&8191;old.banks[g].samples[j]=(j*157+g*911+13)&8191;end
  always @(posedge pclk)begin #1;
   if({dut.read_index[g],dut.qselect[g],dut.bank_q[g]}!=={old.read_index[g],old.qselect[g],old.bank_q[g]})$fatal(1,"HISTORY_ROM_BANK P%0d bank%0d",P,g);
  end
 end
 for(g=0;g<4;g++)begin:init_heads
  integer j;initial for(j=0;j<8;j++)begin dut.head_reads[g].head_samples[j]=(j*743+g*131+33)&8191;old.head_reads[g].head_samples[j]=(j*743+g*131+33)&8191;end
 end endgenerate
 integer checks=0,native_publish=0,native_banks=0;reg last_seen=0,last_bank=0;
 always @(posedge pclk)begin #1;checks++;
  if(P&&$isunknown({addr,ca}))$fatal(1,"HISTORY_ROM_PRODUCTION_ADDRESS_UNKNOWN");
  if({a,sa,ca,dut.display_bank,dut.seen,dut.ack,dut.qdisabled,dut.qzero,dut.qfirst}!==
     {b,sb,cb,old.display_bank,old.seen,old.ack,old.qdisabled,old.qzero,old.qfirst})$fatal(1,"HISTORY_ROM_PUBLIC P%0d cycle%0d",P,checks);
  if({dut.address_window,dut.address_edge,dut.address_right,dut.address_empty,dut.address_bank,dut.address_enable,dut.address_valid,dut.address_count,dut.address_column,dut.address_base_mask,dut.address_last_mask}!==
     {old.address_window,old.address_edge,old.address_right,old.address_empty,old.address_bank,old.address_enable,old.address_valid,old.address_count,old.address_column,old.address_base_mask,old.address_last_mask})$fatal(1,"HISTORY_ROM_STAGE1_EPOCH P%0d cycle%0d",P,checks);
  if(dut.seen!=last_seen)native_publish++;last_seen=dut.seen;
  if(dut.display_bank!=last_bank)native_banks++;last_bank=dut.display_bank;
 end
 always @(posedge clk)begin #1;
  if({dut.writer,dut.column,dut.phase,dut.source_bank,dut.source_count,dut.publish,dut.ack_sync,dut.restart_pending,dut.dirty}!==
     {old.writer,old.column,old.phase,old.source_bank,old.source_count,old.publish,old.ack_sync,old.restart_pending,old.dirty})$fatal(1,"HISTORY_ROM_NATIVE_SOURCE P%0d",P);
 end
 integer i,j,bank,n,x;
 initial begin
  for(i=0;i<2048;i++)begin dut.history[i]=(i*37)&2047;old.history[i]=(i*37)&2047;end
  for(i=0;i<8;i++)begin dut.first_sample[i]=i*97+319;old.first_sample[i]=i*97+319;end
  for(i=0;i<2;i++)begin dut.first_pitch[i]=960+i*32;old.first_pitch[i]=960+i*32;end
  repeat(8)@(negedge pclk);rst=0;prstn=1;
  // Native producers/CDC, reset, frame acceptance, restart and bank swaps.
  for(i=0;i<20000;i++)begin
   @(negedge pclk);addr=$urandom;enable=i%5!=0;frame_start=i%13==0;
   rst=i%4093<3;prstn=!(i%6131<3);restart=i%1193==0;tick=1;recording=i%3000<2500;pitch=768+i%590;
  end
  if(native_publish<20||native_banks<3)$fatal(1,"HISTORY_ROM_NATIVE_COVERAGE P%0d %0d/%0d",P,native_publish,native_banks);
  @(negedge pclk);rst=1;prstn=0;frame_start=0;restart=0;tick=0;recording=0;
  repeat(8)@(negedge pclk);rst=0;prstn=1;
  // Direct metadata fixtures cover the complete arithmetic domain; native
  // behavior is independently checked above and by actual-raster publication.
  for(bank=0;bank<2;bank++)for(n=0;n<=1024;n++)for(x=0;x<1024;x++)begin
   @(negedge pclk);dut.visible_count=n;old.visible_count=n;dut.display_bank=bank;old.display_bank=bank;
   addr=x;enable=(x%7!=0);
  end
  repeat(4)@(negedge pclk);
  // Legacy generic API retains case/default behavior for unknown addresses.
  if(!P)begin addr=10'bx;repeat(3)@(negedge pclk);addr=10'bz;repeat(3)@(negedge pclk);addr=0;end
  repeat(4)@(negedge pclk);
  $display("HISTORY_ROM_EQ_PASS P%0d checks%0d nativePublish%0d nativeBankSwitch%0d all1025countInputs/all1024addresses/bothbanks/readgate/signedwrap stage1all49bits oldSameEdge",P,checks,native_publish,native_banks);done=1;
 end
 initial begin #80000000;$fatal(1,"HISTORY_ROM_EQ_TIMEOUT");end
endmodule
module tb_hw113_counts;
 wire[1:0]done;hw113_count_case #(.P(1)) p1(done[0]);hw113_count_case #(.P(0)) p0(done[1]);
 initial begin wait(&done);$finish;end
endmodule
