`timescale 1ns/1ps
module tb_score2_audio;
 reg clk=0;always #10 clk=~clk;reg rst=1;reg[31:0]cfg=0;reg[6:0]cc1=0;reg[18:0]ratio=262144;reg[3:0]triggers=0;
 wire tick,rtick;wire signed[15:0]pcm,rpcm;wire deadline;wire[95:0]steps;
 final_audio #(.ENABLE_FX(1)) dut(.clk(clk),.rst(rst),.gates(4'b1),.triggers(triggers),.notes({7'd60,7'd60,7'd60,7'd60}),.gains(48'd1800),.timbres(12'd0),.ratio(ratio),.mod_depth(cc1),.synth_config(cfg),.sample_tick(tick),.pcm(pcm),.monitor_steps(steps),.deadline_error(deadline));
 final_audio reference(.clk(clk),.rst(rst),.gates(4'b1),.triggers(triggers),.notes({7'd60,7'd60,7'd60,7'd60}),.gains(48'd1800),.timbres(12'd0),.ratio(ratio),.mod_depth(cc1),.synth_config(32'd0),.sample_tick(rtick),.pcm(rpcm));
 reg compare=1;integer frames=0;
 always @(negedge clk)if(!rst)begin
  if(dut.pcm_positive!==($signed(pcm)>0))$fatal(1,"AUDIO_POSITIVE_METADATA");
  if(compare&&(pcm!==rpcm||tick!==rtick))$fatal(1,"BYPASS_ACTUAL_CORE");
  if(deadline)$fatal(1,"AUDIO_DEADLINE");
 end
 task frame;begin @(posedge tick);@(negedge clk);repeat(180)@(negedge clk);frames=frames+1;end endtask
 integer i,lo,hi,crossings,last_cross,period,last_period;reg neg;reg[95:0]center_steps;
 initial begin repeat(5)@(negedge clk);rst=0;triggers=1;frame;triggers=0;
  for(i=0;i<500;i=i+1)frame;
  center_steps=steps;compare=0;cfg=32'h20;lo=999999;hi=0;crossings=0;last_cross=0;period=0;last_period=0;neg=0;
  for(i=0;i<21000;i=i+1)begin
   frame;
   if(i>500)begin
    if(dut.frame_ratio<lo)lo=dut.frame_ratio;
    if(dut.frame_ratio>hi)hi=dut.frame_ratio;
    if(neg&&dut.frame_ratio>=262144)begin last_period=period;period=i-last_cross;last_cross=i;crossings=crossings+1;end
    neg=dut.frame_ratio<262144;
   end
  end
  if(lo>=261000||hi<=263000||((hi+lo)/2<262130)||((hi+lo)/2>262158))$fatal(1,"VIBRATO_DEPTH_CENTER %0d %0d",lo,hi);
  if(crossings<2||period<9760||period>9770)$fatal(1,"VIBRATO_RATE %0d %0d",crossings,period);
  ratio=300000;lo=999999;hi=0;
  for(i=0;i<10000;i=i+1)begin frame;if(dut.frame_ratio<lo)lo=dut.frame_ratio;if(dut.frame_ratio>hi)hi=dut.frame_ratio;end
  if((hi+lo)/2<299980||(hi+lo)/2>300020)$fatal(1,"BEND_CENTER_LOST %0d %0d",lo,hi);
  cc1=100;repeat(150)frame;if(dut.effective_depth!=100)$fatal(1,"CC1_COMBINATION");
  cfg=0;cc1=0;repeat(200)frame;if(dut.effective_depth!=0||dut.frame_ratio!=300000)$fatal(1,"VIBRATO_OFF");
  $display("SCORE2_AUDIO_PASS bypass every clock vibrato5Hz period=%0d bendcenter=%0d frames=%0d",period,(hi+lo)/2,frames);$finish;
 end
 initial begin #1000000000;$fatal(1,"TIMEOUT");end
endmodule
