#include <cassert>
#include <iostream>
#include "P8_WiFi_Web.ino"

size_t SerialStub::write(const uint8_t* data,size_t size){
 assert(size==28&&data[0]=='W'&&data[1]=='F'&&p8::crc(data+2,24)==p8::u16(data+26));
 writes++;output.assign(data,data+size);
 if(online){
  uint8_t reply[28];memcpy(reply,data,28);uint8_t* p=reply+4;p[3]|=128;memset(p+8,0,12);
  for(unsigned i=0;i<4;i++)p[16+i]=p8::IDENTITY>>(8*i);
  p8::put16(p+20,p8::crc(p+2,18));p8::put16(reply+26,p8::crc(reply+2,24));
  for(uint8_t b:reply)input.push_back(b);
 }
 return size;
}
String hex(const uint8_t* p,size_t n){String s;const char* digits="0123456789abcdef";while(n--){s+=digits[*p>>4];s+=digits[*p++&15];}return s;}
void request(unsigned op,unsigned seq,unsigned session,uint32_t a=0,uint32_t b=0){
 uint8_t p[22]={80,87,1,uint8_t(op)};p8::put16(p+4,seq);p8::put16(p+6,session);
 for(unsigned i=0;i<4;i++){p[8+i]=uint8_t(a>>(8*i));p[12+i]=uint8_t(b>>(8*i));}
 if(!op)for(unsigned i=0;i<4;i++)p[8+i]=p8::IDENTITY>>(8*i);
 p8::put16(p+20,p8::crc(p+2,18));http.body=hex(p,22);command();
}
int main(){
 setup();assert(Serial0.baud==115200&&Serial0.rx==3&&Serial0.tx==1&&Serial0.bufferSize==2048);
 assert(WiFi.ap&&WiFi.apAddress.toString()=="192.168.4.1"&&WiFi.apName=="PuXu-Instrument");
 http.handlers["/"]();assert(http.code==200&&pageRequests==1&&http.response.find("http_transport")==String::npos);
 // Binary NULs must be carried as text hex rather than truncated plain bodies.
 http.body=String("PW\1\0",4);command();assert(http.code==400&&Serial0.writes==0);
 request(0,0,0x0100);assert(http.code==200&&owner==0x0100&&Serial0.writes==1);
 assert(http.contentLength==22&&http.socket.sent.size()==22&&p8::valid(http.socket.sent.data()));
 request(1,1,0x0100,0xfff,96|(60<<8));assert(http.code==200&&p8::u32(Serial0.output.data()+12)==0xfff);
 request(9,2,0x0100,4);assert(http.code==200&&p8::u32(Serial0.output.data()+12)==4);
 unsigned before=Serial0.writes;request(0,0,0x0200);assert(http.code==423&&Serial0.writes==before);
 request(3,1,0x0100);assert(http.code==200&&lastSequence==1);
 http.body="0101";release();assert(owner==0x0100); // delayed beacon from another session
 http.body="0001";release();assert(owner==0&&Serial0.output[7]==2);
 request(3,3,0x0100);assert(http.code==409);
 request(0,0,0x0300);assert(owner==0x0300&&http.code==200);
 fakeNow+=1501;expireController();assert(owner==0x0300); // brief pause keeps the session
 Serial0.online=false;unsigned sameOwnerWrites=Serial0.writes;request(5,1,0x0300);assert(http.code==503&&owner==0x0300&&Serial0.writes==sameOwnerWrites+3&&lastSequence==1);
 Serial0.online=true;request(5,1,0x0300);assert(http.code==200&&owner==0x0300); // identical retry allowed
 fakeNow+=30001;expireController();assert(owner==0);
 Serial0.online=false;before=Serial0.writes;
 request(0,0,0x0400);assert(http.code==503&&owner==0&&Serial0.writes==before+3);
 assert(fpgaLink.stats.timeouts==2&&http.response.find("FPGA")!=String::npos);
 unsigned attempts=Serial0.writes;request(17,4,0x0400);assert(http.code==400&&Serial0.writes==attempts);
 Serial0.online=true;request(0,0,0x0500);assert(http.code==200);
 for(unsigned op:{4,5,6,7,8,12,13,14,15,16}){request(op,op,0x0500);assert(http.code==200&&Serial0.output[7]==op);}
 status();assert(http.code==200&&http.response.find("P8-SCORE-HTTP-6")!=String::npos);
 assert(http.response.find("Final7-Grand-WiFi-2")!=String::npos&&http.response.find("\"voice_count\":7")!=String::npos&&http.response.find("\"timbre_count\":4")!=String::npos);
 std::cout<<"P8_HTTP_HANDLERS_PASS: physical UART configuration, fixed AP, NUL-safe encoding, real-ACK gating, busy/session/lease/release, missing FPGA fails offline\n";
}
