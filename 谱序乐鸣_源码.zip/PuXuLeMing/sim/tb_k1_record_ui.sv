`timescale 1ns/1ps
module tb_k1_record_ui;
 reg clk=0,rstn=0,key1_n=1;always #10 clk=~clk;
 tri dp,dm;
 hub_play_top dut(.clk(clk),.rstn(rstn),.key1_n(key1_n),.key2_n(1'b1),.uart_rx(1'b1),.usb_dp(dp),.usb_dm(dm),
 .uart_tx(),.hp_bck(),.hp_ws(),.hp_din(),.pa_en(),.i2s_bck(),.i2s_ws(),.i2s_sd(),.led_o(),
 .tmds_clk_p_0(),.tmds_clk_n_0(),.tmds_d_p_0(),.tmds_d_n_0());
 defparam dut.status_bridge.PERIOD=10;
 defparam dut.ui_snapshot.PERIOD=10;
 defparam dut.pedal_button.TICKS=4;
 defparam dut.patterns.HOLD_SAMPLES=8;
 integer checks=0,n,m,x,y,yellow=0,grey=0,on_frames=0,off_frames=0;
 reg[13:0]probe_x=64,probe_y=550;
 always @(dut.pattern_selected)$display("K1_SELECTED_CHANGE time=%t selected=%b chord=%b",$time,dut.pattern_selected,dut.patterns.chord_selection);
 task check(input bit ok,input string why);begin checks++;if(!ok)$fatal(1,"K1_RECORD_UI_FAIL %s",why);end endtask
 task waitclks(input integer n);repeat(n)@(negedge clk);endtask
 task frames(input integer n);repeat(n)begin @(posedge dut.sample_tick);@(negedge clk);end endtask
 task touch(input integer x,y,input bit down);begin dut.soc.hid_report(x,y,down,1);waitclks(40);end endtask
 task tap(input integer x,y);begin touch(x,y,0);touch(x,y,1);touch(x,y,0);end endtask
 task ev(input[31:0]w);begin dut.soc.midi_event(w);waitclks(100);end endtask
 task pedal(input bit down);begin key1_n=!down;waitclks(100);end endtask
 task reset_all;begin rstn=0;key1_n=1;waitclks(20);rstn=1;waitclks(2000);dut.soc.ptest_debug[255:224]=32'h0c;waitclks(100);tap(300,280);tap(650,96);end endtask
 initial begin
  force dut.frame_start=1'b1;force dut.x=probe_x;force dut.y=probe_y;force dut.den=1'b1;
  reset_all;pedal(1);waitclks(300);
  check(dut.vpedal_down&&dut.panel.pedal_o,"K1 crosses existing UI snapshot");
  for(y=24;y<40;y++)for(x=688;x<720;x++)begin probe_x=x;probe_y=y;waitclks(30);if(dut.rgb==24'hf5c767)yellow++;end
  check(yellow>20,"actual rendered pedal glyph is yellow when pressed");
  pedal(0);waitclks(300);
  for(y=24;y<40;y++)for(x=688;x<720;x++)begin probe_x=x;probe_y=y;waitclks(30);if(dut.rgb==24'h9aabb5)grey++;end
  check(grey==yellow&&!dut.vpedal_down,"same glyph grey on release");
  // Silent selection and actual timed pattern through source/recorder ingress.
  $display("K1_BEFORE_CHORD selected=%b chord=%b",dut.pattern_selected,dut.patterns.chord_selection);
  tap(600,195);$display("K1_AFTER_CHORD selected=%b chord=%b",dut.pattern_selected,dut.patterns.chord_selection);
  touch(64,500,1);touch(64,500,0);touch(200,500,1);touch(200,500,0);
  $display("K1_SELECTION_DIAG mode=%d pattern=%d count=%d notes=%h selected=%b gates=%b",dut.mode,dut.pattern_mode,dut.pattern_count,dut.pattern_notes,dut.pattern_selected,dut.perform_gates);
  check(dut.pattern_count==2&&dut.perform_gates==0,"K1 UI does not alter silent chord selection");
  pedal(1);tap(900,195);frames(20);
  check(!dut.pattern_busy&&dut.pattern_gates==0&&dut.perform_gates!=0&&dut.gates!=0,"pattern end retained through actual audio and recorder boundary");
  pedal(0);frames(3);check(dut.perform_gates==0&&dut.perform_gains!=0,"pattern release preserves physical decay gain");
  // A new selection explicitly cancels a pedal-held pattern.
  pedal(1);tap(900,195);frames(4);touch(400,500,1);touch(400,500,0);frames(3);
  check(dut.perform_gates==0&&dut.perform_gains==0,"new selection cancels old pattern despite pedal");
  reset_all;pedal(1);tap(100,195);frames(3);check(dut.recording,"start recording");
  ev(32'h00643c90);frames(5);ev(32'h00003c80);frames(8);
  check(dut.gates!=0,"recording receives held K1 note off");
  pedal(0);frames(10);check(dut.gates==0,"recording receives actual pedal release");
  tap(100,195);frames(3);check(!dut.recording&&dut.record_count>0,"take finalized");
  pedal(1);tap(280,195);frames(2);
  check(dut.replaying,"replay command admitted");
  while(dut.replaying)begin
   @(posedge dut.sample_tick);@(negedge clk);
   if(dut.gates!=0)on_frames++;else off_frames++;
  end
  $display("K1_REPLAY_DIAG count=%0d duration=%0d on=%0d off=%0d live=%b out=%b",dut.record_count,dut.record_duration,on_frames,off_frames,dut.live_gates,dut.gates);
  check(on_frames>=10&&off_frames>=5,"recorded hold and release replay with K1 still down");
  frames(3);check(dut.gates==0,"K1 cannot extend recorded take after replay");
  $display("K1_RECORD_UI_PASS checks=%0d glyph=%0d replayFrames=%0d/%0d",checks,yellow,on_frames,off_frames);$finish;
 end
 initial begin #20000000;$fatal(1,"K1_RECORD_UI_FAIL timeout");end
endmodule
