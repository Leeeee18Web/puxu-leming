`timescale 1ns/1ps
module tb_poly_line_context #(parameter LENGTH=2112);
 `include "src/poly/poly_model_layout.vh"
 localparam MW=`POLY_MODEL_LINE_W,W=MW+56;reg clk=0;always #10 clk=~clk;
 reg rst=1,first_reset=0,en=0,load=0,save=0,tick=0,trig=0,gate=1;reg[2:0]idx=0,kind=1;
 reg[23:0]step=24'd45000,period=0;reg[11:0]gain=12'd2400;
 wire[MW-1:0]snapshot;wire[W-1:0]restore;wire known;wire signed[17:0]s,incident,pred;wire[15:0]e;wire busy,err;
 wire[12:0]ra,wa;wire we;wire[17:0]wd;wire[19:0]qa;wire[17:0]qb,qc;wire[55:0]ms;
 poly_context_store #(.WIDTH(W),.COUNT(7),.INDEX_WIDTH(3)) bank(clk,rst,save,idx,{snapshot,ms},restore,known);
 poly_delay_pool #(.CONTEXTS(7),.LENGTH(LENGTH)) mem(clk,rst,en,load,idx,restore[55:0],ms,ra,13'd0,13'd0,wa,13'd0,13'd0,we,1'b0,1'b0,{2'd0,wd},18'd0,18'd0,qa,qb,qc);
 poly_model_line #(.LENGTH(LENGTH),.INDEX(0),.PREDECODE_PIANO(1),.PRECALC_TUNING(1)) dut(.clk(clk),.rst(rst||first_reset),.tick(tick),.trigger(trig),.gate(gate),.kind(kind),.velocity(gain),.step(step),.rate_shift(2'd0),.period_q10(period),.sample(s),.envelope(e),.busy(busy),.deadline_error(err),.bridge_return(incident),.bridge_incident(incident),.piano_mode(kind==1),.bridge_incident_next(pred),.ctx_enable(en),.ctx_load(load),.ctx_data(restore[W-1:56]),.ctx_state(snapshot),.mem_q(qa[17:0]),.mem_raddr(ra),.mem_waddr(wa),.mem_we(we),.mem_data(wd));
 wire signed[17:0]gs[0:6],gi[0:6];wire[15:0]ge[0:6];wire[6:0]gb,gerr;
 genvar k;generate for(k=0;k<7;k=k+1)begin:refvoice
  wire gc=clk&&(rst||(en&&idx==k));
  phys_strings_line #(.INDEX(0),.PREDECODE_PIANO(1),.PRECALC_TUNING(1)) refm(.clk(gc),.rst(rst||first_reset),.tick(tick),.trigger(trig),.gate(gate),.kind(kind),.velocity(gain),.step(step),.half_rate(1'b0),.period_q10(period),.sample(gs[k]),.envelope(ge[k]),.busy(gb[k]),.deadline_error(gerr[k]),.bridge_return(gi[k]),.bridge_incident(gi[k]),.piano_mode(kind==1),.bridge_incident_next());
 end endgenerate
 integer round,c,checks=0,wraps=0;
 always @(posedge clk)if(en&&!load&&dut.state==18&&dut.wr==LENGTH-1)wraps=wraps+1;
 initial begin repeat(4)@(negedge clk);rst=0;
 for(round=0;round<24000;round=round+1)begin
  @(negedge clk);idx=round%7;load=1;en=0;save=0;step=24'd45000+idx*24'd12000;period=64'd17179869184/step;gain=12'd1000+idx*12'd330;kind=idx[0]?1:2;gate=round<22000;
  #1;first_reset=!known;
  @(negedge clk);load=0;en=1;
  if(first_reset)begin @(negedge clk);first_reset=0;end
  tick=round>=490;trig=round<7;
  for(c=0;c<128+round%7;c=c+1)begin
   @(negedge clk);
   tick=0;trig=0;
  end
  if(dut.state>3)$fatal(1,"LINE_SLOT_OVERRUN state%0d",dut.state);
  // Internal state18 occurs one clock later; completed slot values stay exact.
  if(round>=490)begin
   if(s!==gs[idx]||e!==ge[idx]||busy!==gb[idx]||err!==gerr[idx]||incident!==gi[idx])$fatal(1,"LINE_CONTEXT_SLOT_EQ visit%0d row%0d s=%0d/%0d",round,idx,s,gs[idx]);
   checks=checks+1;
  end
  en=0;save=1;@(negedge clk);save=0;
 end
 if(wraps<7)$fatal(1,"LINE_RING_WRAP_NOT_EXERCISED count%0d",wraps);
 $display("POLY_LINE_CONTEXT_PASS checks=%0d wraps=%0d exact R2 completed slots across7voices; internal bridge wait+1; ring/init crop/idle scratch",checks,wraps);$finish;
 end
 initial begin #100000000;$fatal(1,"LINE_CONTEXT_TIMEOUT");end
endmodule
module tb_poly_line_context2048;tb_poly_line_context #(.LENGTH(2048)) t();endmodule
