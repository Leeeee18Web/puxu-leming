`timescale 1ns/1ps
module tb_play_panel_pipeline;
 reg pixel_clk=0;always #5 pixel_clk=~pixel_clk;
 reg rstn=0,den=1,hsync=1,vsync=1,page=0;
 reg[13:0]x=0,y=0;reg[6:0]base_note=60,gates=1,knob=64,last_note=60,last_velocity=100;
 reg[48:0]notes=49'd60;reg[31:0]usb_status=32'h01007f05;
 reg signed[15:0]wave_data=0;reg signed[15:0]samples[0:1023];
 wire[23:0]rgb,oldrgb;wire den_out,hsync_out,vsync_out,oldde,oldhs,oldvs;
 wire[9:0]wave_addr,oldaddr;
 play_panel dut(.*);
 play_panel_reference reference(.pixel_clk(pixel_clk),.rstn(rstn),.den(den),.hsync(hsync),.vsync(vsync),
 .x(x),.y(y),.page(page),.base_note(base_note),.gates(gates),.notes(notes),.knob(knob),
 .last_note(last_note),.last_velocity(last_velocity),.usb_status(usb_status),.wave_data(wave_data),
 .rgb(oldrgb),.den_out(oldde),.hsync_out(oldhs),.vsync_out(oldvs),.wave_addr(oldaddr));
 reg[26:0]gold[0:2];integer checks=0,i,xx,yy,frame;integer seed=32'h54e23c19;
 always @(posedge pixel_clk)begin
 wave_data<=samples[wave_addr];
 #1;
 if(!rstn)begin gold[0]=0;gold[1]=0;gold[2]=0;end
 else begin
  if({rgb,den_out,hsync_out,vsync_out}!==gold[2])
   $fatal(1,"pipeline mismatch check%0d xy%0d/%0d actual%h expected%h",checks,x,y,{rgb,den_out,hsync_out,vsync_out},gold[2]);
  if(wave_addr!==oldaddr)$fatal(1,"wave address changed");
  gold[2]=gold[1];gold[1]=gold[0];gold[0]={oldrgb,oldde,oldhs,oldvs};checks=checks+1;
 end
 end
 initial begin
 $readmemh("build/preview/actual_pcm.hex",samples);
 repeat(5)@(negedge pixel_clk);rstn=1;
 for(frame=0;frame<2;frame=frame+1)begin
 page=frame;
 for(yy=0;yy<600;yy=yy+1)for(xx=0;xx<1024;xx=xx+1)begin
 @(negedge pixel_clk);x=xx;y=yy;
 end
 end
 // Dynamic every-cycle context, blanking and coordinates expose retiming bugs.
 for(i=0;i<100000;i=i+1)begin
 @(negedge pixel_clk);x=$random(seed)&14'h7ff;y=$random(seed)&14'h3ff;
 page=$random(seed);base_note=12+12*($unsigned($random(seed))%8);gates=$random(seed);
 notes={$random(seed),$random(seed)};knob=$random(seed);last_note=$random(seed);last_velocity=$random(seed);
 usb_status=$random(seed);den=$random(seed);hsync=$random(seed);vsync=$random(seed);
 end
 repeat(10)@(negedge pixel_clk);
 $display("PASS pipeline %0d cycles: 1228800 fullframepixels +100000 dynamiccontexts RGB/DE/HS/VS identical with +3cycle delay; waveaddr unchanged",checks);$finish;
 end
endmodule
