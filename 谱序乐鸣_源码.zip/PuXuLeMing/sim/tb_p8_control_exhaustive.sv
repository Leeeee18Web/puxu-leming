`timescale 1ns/1ps
module tb_p8_control_exhaustive;
 reg clk=0;always #10 clk=~clk;
 reg rst=1,sample_tick=0,event_valid=0,panic=0,centre=0;reg[31:0]event_data=0;reg[1:0]knob_mode=1;
 wire event_ready;wire[6:0]gates,triggers,knob,last_note,last_velocity,mod_depth,raw_knob;
 wire[48:0]notes;wire[83:0]gains;wire[18:0]ratio;wire raw_known,pickup_wait;
 play_voice_control #(.RELATIVE_KNOB(1)) dut(.*);
 task send(input[7:0]st,a,b);begin @(negedge clk);event_data={8'd0,b,a,st};event_valid=1;@(negedge clk);event_valid=0;end endtask
 integer m,a,b,k,v,expected,delta,cases=0;
 initial begin
 repeat(3)@(negedge clk);rst=0;
 for(m=0;m<=2;m++)begin
  @(negedge clk);knob_mode=m;repeat(2)@(negedge clk);
  for(k=0;k<6;k++)begin
   case(k)0:v=0;1:v=1;2:v=63;3:v=64;4:v=126;default:v=127;endcase
   for(a=0;a<128;a++)for(b=0;b<128;b++)begin
    send(8'hff,0,0);send(8'he0,0,v);send(8'hc0,a,0);
    if(knob!==v)$fatal(1,"anchor changed value mode%0d raw%0d initial%0d got%0d",m,a,v,knob);
    send(8'hb0,74,b);
    delta=b-a;
    if(m==2)begin if(delta>63)delta=delta-128;else if(delta< -64)delta=delta+128;end
    expected=v+delta;if(expected<0)expected=0;else if(expected>127)expected=127;
    if(m==0)begin
     if(a==v||b==v||(a<v&&b>v)||(a>v&&b<v))expected=b;
     else expected=v;
    end
    if(knob!==expected||raw_knob!==b||!raw_known||(pickup_wait!==((m==0)&&!(a==v||b==v||(a<v&&b>v)||(a>v&&b<v))))||!event_ready)
     $fatal(1,"mode%0d before%0d raw%0d->%0d want%0d got%0d",m,v,a,b,expected,knob);
    cases++;
   end
  end
 end
 $display("PASS tb_p8_control_exhaustive cases=%0d full raw-pair domain modes0/1/2 at6 boundary bends",cases);$finish;
 end
endmodule
