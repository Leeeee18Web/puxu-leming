`timescale 1ns/1ps
// True production RTL raster export, no substitute drawing implementation.
module tb_play_preview;
 reg pixel_clk=0;always #5 pixel_clk=~pixel_clk;
 reg rstn=0,den=1,hsync=1,vsync=1,page=0;
 reg[13:0]x=0,y=0;reg[6:0]base_note=60,gates=1,knob=64,last_note=60,last_velocity=100;
 reg[48:0]notes=49'd60;reg[31:0]usb_status=32'h01007f05;
 reg signed[15:0]wave_data=0;
 wire[23:0]rgb;wire den_out,hsync_out,vsync_out;wire[9:0]wave_addr;
 reg signed[15:0]samples[0:1023];
 integer fd,xx,yy,n=0,latency_fill,tail;
 play_panel dut(.*);
 always @(posedge pixel_clk)wave_data<=samples[wave_addr];
 task render(input[255:0]path);
 begin
 fd=$fopen(path,"wb");if(!fd)$fatal(1,"cannot create preview");
 $fwrite(fd,"P6\n1024 600\n255\n");latency_fill=0;
 for(yy=0;yy<600;yy=yy+1)for(xx=0;xx<1024;xx=xx+1)begin
 @(negedge pixel_clk);x=xx;y=yy;@(posedge pixel_clk);#1;
 if(latency_fill>=4)begin $fwrite(fd,"%c%c%c",rgb[23:16],rgb[15:8],rgb[7:0]);n=n+1;end
 latency_fill=latency_fill+1;
 end
 for(tail=0;tail<4;tail=tail+1)begin
 @(negedge pixel_clk);x=0;y=0;@(posedge pixel_clk);#1;
 $fwrite(fd,"%c%c%c",rgb[23:16],rgb[15:8],rgb[7:0]);n=n+1;
 end
 $fclose(fd);
 end endtask
 initial begin
 $readmemh("build/preview/actual_pcm.hex",samples);
 repeat(4) @(negedge pixel_clk);rstn=1;repeat(4) @(negedge pixel_clk);
 render("build/preview/keyboard.ppm");page=1;repeat(4) @(negedge pixel_clk);
 render("build/preview/pcm_wave.ppm");
 if(n!=1228800)$fatal(1,"frame pixel count");
 $display("PASS preview 1228800 pixels from actual play_panel, PCM file from real play_audio");$finish;
 end
endmodule
