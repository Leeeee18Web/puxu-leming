`timescale 1ns/1ps
module tb_poly_body_local_equiv;
 reg clk=0;always #10 clk=~clk;reg rst=1,en=0,load=0,tick=0,piano=0;reg signed[21:0]drive=0;reg[319:0]data=0;
 wire signed[31:0]a,b;wire ba,bb;wire[319:0]sa,sb;
 poly_model_body dut(.clk(clk),.rst(rst),.tick(tick),.piano(piano),.drive(drive),.radiation(a),.busy(ba),.ctx_enable(en),.ctx_load(load),.ctx_data(data),.ctx_state(sa));
 poly_body_before_local reference(.clk(clk),.rst(rst),.tick(tick),.piano(piano),.drive(drive),.radiation(b),.busy(bb),.ctx_enable(en),.ctx_load(load),.ctx_data(data),.ctx_state(sb));
 reg[31:0]rng=32'h715fa392;integer i,k,checks=0,loads=0,pauses=0,starts=0,consumes2=0,consumes4=0,resets=0;
 initial begin
  repeat(4)@(negedge clk);rst=0;
  for(i=0;i<50000;i++)begin
   rng={rng[30:0],rng[31]^rng[21]^rng[1]^rng[0]};en=rng[2:0]!=0;load=!bb&&i%31==0;tick=!bb&&rng[3];piano=rng[4];drive=rng[25:4];rst=i%997==996;
   if(load)begin for(k=0;k<10;k++)begin rng={rng[30:0],rng[31]^rng[21]^rng[1]^rng[0]};data[k*32+:32]=rng;end loads++;end
   if(!en)pauses++;if(rst)resets++;if(en&&!load&&!rst&&reference.state==0&&tick)starts++;
   #1;
   if(en&&!load&&!rst&&reference.state==2)begin
    if({dut.m[0].spring,dut.m[0].damping,dut.m[1].spring,dut.m[1].damping,dut.m[2].spring,dut.m[2].damping,dut.m[3].spring,dut.m[3].damping,dut.m[4].spring,dut.m[4].damping,dut.m[5].spring,dut.m[5].damping}!==
       {reference.m[0].spring,reference.m[0].damping,reference.m[1].spring,reference.m[1].damping,reference.m[2].spring,reference.m[2].damping,reference.m[3].spring,reference.m[3].damping,reference.m[4].spring,reference.m[4].damping,reference.m[5].spring,reference.m[5].damping})$fatal(1,"BODY_CONSUMER2_EQ cycle%0d",i);
    consumes2++;
   end
   if(en&&!load&&!rst&&reference.state==4)begin
    if({dut.m[0].motion,dut.m[1].motion,dut.m[2].motion,dut.m[3].motion,dut.m[4].motion,dut.m[5].motion}!=={reference.m[0].motion,reference.m[1].motion,reference.m[2].motion,reference.m[3].motion,reference.m[4].motion,reference.m[5].motion})$fatal(1,"BODY_CONSUMER4_EQ cycle%0d",i);
    consumes4++;
   end
   @(posedge clk);#1;
   if({a,ba,sa,dut.state,dut.input_q}!=={b,bb,sb,reference.state,reference.input_q})$fatal(1,"BODY_PERSISTENT_OUTPUT_EQ cycle%0d state%0d",i,dut.state);
   checks++;@(negedge clk);
  end
  if(loads==0||pauses==0||starts==0||consumes2==0||consumes4==0||resets==0)$fatal(1,"BODY_EQ_COVERAGE");
  $display("POLY_BODY_LOCAL_EQ_PASS checks%0d loads%0d pauses%0d starts%0d consumer2%0d consumer4%0d resets%0d full320state/all6mode product consumers/rawpiano",checks,loads,pauses,starts,consumes2,consumes4,resets);$finish;
 end
endmodule
