`timescale 1ns/1ps
module tb_history_prefetch_wiring;
 reg pixel_clk=0;always #9.756 pixel_clk=~pixel_clk;
 reg clk=0;always #10 clk=~clk;
 reg rstn=0,den=0,hsync=0,vsync=0,pedal_down=0;
 reg[13:0]x=0,y=0;wire[13:0]next_x=x==1023?14'd0:x+14'd1;reg[2:0]page=0;reg[1:0]mode=0;
 reg playing=1,muted=0,note_valid=1;reg[6:0]next_note=64,base_note=60;
 reg[3:0]gates=9;reg[27:0]notes=0;reg[47:0]gains=0;
 wire[24:0]keyboard_held=25'h1001;
 wire[374:0]keyboard_labels=375'h5422a63d487688e501b9e35386668c4c16962b2852489c8128e1d1836286440b8615082608440067e0af811e81bc02;
 reg[7:0]envelope_choices=8'h95;reg preview_busy=0;
 reg[6:0]home_gates=7'h55;reg[83:0]home_gains=0;
 reg piano_ready=1,touch_ready=1,recording=1,replaying=0,record_full=0;
 reg[12:0]record_count=321;reg[15:0]record_milliseconds=4321;
 reg[2:0]timbre=1;reg timbre_open=0,xy_overview=0;reg[31:0]synth_config=32'h123456;
 reg[6:0]knob=64,raw_knob=93;reg raw_known=1,pickup_wait=0;reg[1:0]touch_state=2;
 reg[1:0]pattern_mode=1;reg[6:0]pattern_selected=2;reg[48:0]pattern_notes=49'h10204081;
 reg pattern_busy=0;reg[2:0]pattern_count=4;reg pattern_full=0;
 reg[6:0]lesson_target=60,lesson_feedback_note=62;reg[1:0]lesson_feedback=1;
 reg[5:0]lesson_position=3;reg lesson_done=0;
 reg[1:0]knob_mode=1;reg[6:0]last_note=60,last_velocity=96,mod_depth=32;
 reg[47:0]wave_data=0;reg[7:0]spectrum_data=0,spectrum_peak=128;
 reg[1:0]spectrum_zoom=2;reg visual_valid=1,xy_data=0,xy_valid=1;reg[5:0]xy_settings=6'b101000;
 wire[9:0]wave_addr0,wave_addr1,tone_addr0,tone_addr1;wire[6:0]spectrum_addr0,spectrum_addr1;
 wire[15:0]xy_addr0,xy_addr1;wire[23:0]rgb0,rgb1;wire de0,de1,hs0,hs1,vs0,vs1;
 wire[10:0]tone0,tone1;wire[16:0]curve0,curve1;wire[9:0]count0,count1;
 final_panel #(.SHOW_PEDAL(1),.HISTORY_PREFETCH(1),.KEYBOARD_VIEW(1)) dut(.envelope_choices(envelope_choices),.preview_busy(preview_busy),.tone_data(tone0),.tone_curve(curve0),.tone_count(count0),
  .wave_addr(wave_addr0),.spectrum_addr(spectrum_addr0),.tone_addr(tone_addr0),.xy_addr(xy_addr0),
  .rgb(rgb0),.den_out(de0),.hsync_out(hs0),.vsync_out(vs0),.*);
 final_panel_before_pixel_pipeline #(.SHOW_PEDAL(1),.KEYBOARD_VIEW(1)) reference(.x(next_x),.tone_data(tone1),.tone_curve(curve1),.tone_count(count1),
  .wave_addr(wave_addr1),.spectrum_addr(spectrum_addr1),.tone_addr(tone_addr1),.xy_addr(xy_addr1),
  .rgb(rgb1),.den_out(de1),.hsync_out(hs1),.vsync_out(vs1),.*);

 p8_visuals #(.HISTORY_SAMPLES(768),.XY_POINTS(8),.HISTORY_READ_PIPELINE(1)) actual(.clk(clk),.rst(!rstn),.sample_tick(1'b0),.pcm(16'sd0),.pcm_positive(1'b0),.leading_note(7'd60),.leading_pitch(11'd960),.leading_step(24'd45000),.leading_envelope(16'd1000),.leading_valid(1'b1),.restart(1'b0),.requested_config(6'b101000),.pixel_clk(pixel_clk),.pixel_rstn(rstn),.frame_start(1'b0),.page(page),.x(x),.wave_addr(wave_addr0),.spectrum_addr(spectrum_addr0),.tone_addr(tone_addr0),.xy_addr(xy_addr0),.wave_data(),.spectrum_data(),.spectrum_peak(),.visual_valid(),.tone_data(tone0),.tone_curve(curve0),.tone_count(count0),.xy_data(),.xy_valid(),.xy_settings());
 p8_visuals_before_pixel_pipeline #(.HISTORY_SAMPLES(768),.XY_POINTS(8)) original(.clk(clk),.rst(!rstn),.sample_tick(1'b0),.pcm(16'sd0),.pcm_positive(1'b0),.leading_note(7'd60),.leading_pitch(11'd960),.leading_step(24'd45000),.leading_envelope(16'd1000),.leading_valid(1'b1),.restart(1'b0),.requested_config(6'b101000),.pixel_clk(pixel_clk),.pixel_rstn(rstn),.frame_start(1'b0),.page(page),.x(next_x),.wave_addr(wave_addr1),.spectrum_addr(spectrum_addr1),.tone_addr(tone_addr1),.xy_addr(xy_addr1),.wave_data(),.spectrum_data(),.spectrum_peak(),.visual_valid(),.tone_data(tone1),.tone_curve(curve1),.tone_count(count1),.xy_data(),.xy_valid(),.xy_settings());
 integer p,k,checks=0;
 initial begin
  repeat(5)@(negedge pixel_clk);rstn=1;
  for(p=0;p<8;p++)for(k=0;k<1101;k++)begin
   @(negedge pixel_clk);page=p;x=k;#1;
   if(tone_addr0!==tone_addr1||actual.history.read_addr!==original.history.read_addr||actual.history.read_enable!==original.history.read_enable)$fatal(1,"HISTORY_PRODUCTION_PREFETCH_WIRING p%0d x%0d",p,k);
   if(actual.history.PIPELINED_READ!=1)$fatal(1,"HISTORY_PRODUCTION_PIPELINE_DISABLED");checks++;
  end
  $display("HISTORY_PREFETCH_WIRING_PASS checks%0d actualPanelVisual versus completeOldPanelVisual nextRasterX allpages/windowedges/blanking",checks);$finish;
 end
endmodule
