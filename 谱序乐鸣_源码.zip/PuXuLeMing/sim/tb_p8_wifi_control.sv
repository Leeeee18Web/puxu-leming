`timescale 1ns/1ps
module tb_p8_wifi_control;
 wire trace_valid;wire[175:0]trace_frame;wire[15:0]trace_expected;wire[7:0]trace_result,trace_size;
 wire[31:0]good_frames,bad_crc,bad_version,gap_timeouts,watchdog_count;
 wire live_link_lost=1'b0;wire[2:0]wifi_timbre;wire wifi_timbre_override;wire[1:0]wifi_pattern_mode;wire wifi_pattern_override,wifi_pattern_start;
 wire recording=0,record_replaying=0,record_full=0,record_time_limit=0,record_export_ready=0;
 wire[12:0]record_count=0;wire[31:0]record_duration=0,record_take_id=0;wire[95:0]record_read_word=0;wire[11:0]record_read_address;wire record_toggle_request;
 reg clk=0,rst=1;always #10 clk=~clk;
 reg[7:0]rx_data=0;reg rx_valid=0,tx_ready=1,event_ready=1;
 wire rx_ready,tx_valid,event_valid;wire[7:0]tx_data;wire[31:0]event_data;
 reg playable=1,clear_notes=0;reg[1:0]mode=0;reg muted=0;
 reg[3:0]sample_phase=0;wire sample_tick=sample_phase==15;
 always @(posedge clk)sample_phase<=sample_phase+1'b1;
 wire score_playing;wire[9:0]score_position,score_count;
 p8_wifi_control #(.CLOCK_HZ(1000000),.WATCHDOG_MS(3)) dut(.local_timbre_commit(1'b0),.map_notes(),.map_input_base(),.map_enabled(),.map_apply(),.map_key_seen_valid(1'b0),.map_key_seen_index(5'd0),.map_apply_audio(),.map_apply_fx(),.*);
 integer checks=0,events=0,replies=0,txindex=0,i,old_events;
 reg[31:0]seen[0:2047];reg[7:0]reply[0:21];reg[7:0]last_result=0;
 reg[15:0]last_reply_seq=0,crc_reply=16'hffff;
 task check(input bit ok,input string label);begin checks++;if(!ok)$fatal(1,"WIFI_CHECK_FAILED %s",label);end endtask
 function automatic[15:0]crc(input[15:0]c,input[7:0]b);
 reg[15:0]v;integer k;begin v=c^{b,8'd0};for(k=0;k<8;k++)v=v[15]?(v<<1)^16'h1021:v<<1;crc=v;end endfunction
 always @(posedge clk)begin
  if(!rst&&event_valid&&event_ready)begin seen[events]=event_data;events++;end
  if(!rst&&tx_valid&&tx_ready)begin
   reply[txindex]=tx_data;
   if(txindex>=2&&txindex<=19)crc_reply=crc(crc_reply,tx_data);
   if(txindex==21)begin
    check(reply[0]=="P"&&reply[1]=="W"&&reply[2]==1,"reply identity header");
    check({tx_data,reply[20]}==crc_reply,"reply CRC from actual wire");
    check({reply[19],reply[18],reply[17],reply[16]}==32'h50385731,"P8 WiFi identity");
    last_reply_seq={reply[5],reply[4]};last_result=reply[8];replies++;txindex=0;crc_reply=16'hffff;
   end else txindex++;
  end
 end
 task byte_in(input[7:0]b);begin
  @(negedge clk);rx_data=b;rx_valid=1;
  do @(posedge clk);while(!rx_ready);
  @(negedge clk);rx_valid=0;
 end endtask
 reg[7:0]packet[0:21];integer expected_replies;reg[15:0]c;
 task command(input[7:0]op,input[15:0]seq,session,input[31:0]a,b,d,input bit corrupt,input[7:0]result);
 integer j,timeout;begin
  packet[0]="P";packet[1]="W";packet[2]=1;packet[3]=op;
  packet[4]=seq[7:0];packet[5]=seq[15:8];packet[6]=session[7:0];packet[7]=session[15:8];
  for(j=0;j<4;j++)begin packet[8+j]=a>>(j*8);packet[12+j]=b>>(j*8);packet[16+j]=d>>(j*8);end
  c=16'hffff;for(j=2;j<20;j++)c=crc(c,packet[j]);packet[20]=c[7:0];packet[21]=c[15:8]^{7'd0,corrupt};
  expected_replies=replies+1;
  for(j=0;j<22;j++)byte_in(packet[j]);
  if(!corrupt)begin
   timeout=0;while(replies<expected_replies&&timeout<4000)begin @(negedge clk);timeout++;end
   check(replies==expected_replies,"command receives FPGA ACK");
   check(last_reply_seq==seq,"ACK sequence");
   if(last_result!=result)$display("op=%0d seq=%0d result=%0d expected=%0d",op,seq,last_result,result);
   check(last_result==result,"ACK result");
  end else begin repeat(80)@(negedge clk);check(replies==expected_replies-1,"bad CRC has no ACK or execution");end
 end endtask
 function automatic[15:0]score_crc(input[15:0]start,input[31:0]t,data);
 reg[15:0]v;integer k;begin v=start;for(k=0;k<4;k++)v=crc(v,t>>(8*k));for(k=0;k<4;k++)v=crc(v,data>>(8*k));score_crc=v;end endfunction
 reg[15:0]sc;integer before_reply;
 initial begin
  repeat(5)@(negedge clk);rst=0;
  command(0,1,16'h1234,32'h50385731,0,0,0,0);
  command(1,2,16'h1234,3,32'h3c64,0,0,0);
  check(events==2&&seen[0]==32'h01643c9e&&seen[1]==32'h03643d9e,"two finger live notes");
  old_events=events;command(1,2,16'h1234,3,32'h3c64,0,0,0);check(events==old_events,"retry idempotent");
  command(1,2,16'h1234,1,32'h3c64,0,0,4);check(events==old_events,"same seq different payload rejected");
  command(1,3,16'h1234,0,32'h3c64,0,1,0);check(events==old_events,"CRC never releases or triggers");
  command(1,3,16'h1234,0,32'h3c64,0,0,0);
  check(events==4&&seen[2]==32'h01003c8e&&seen[3]==32'h03003d8e,"full snapshot releases exact old MIDI pitches");
  command(1,4,16'h1234,1,32'h3c64,0,0,0);
  repeat(3100)@(negedge clk);check(events==6&&seen[5]==32'h010078be,"lease clears only mobile channel14");
  command(1,5,16'h1234,32'h02000000,32'h3c64,0,0,1);
  command(1,6,16'h1234,1,32'h6864,0,0,1);
  command(3,7,16'h9999,0,0,0,0,4);
  command(3,4,16'h1234,0,0,0,0,4);
  command(4,7,16'h1234,2,0,0,0,0);
  command(5,8,16'h1234,1,100,32'h00013c40,0,1);
  command(5,9,16'h1234,0,0,32'h00013c40,0,0);
  command(6,10,16'h1234,0,0,0,0,5);
  command(5,11,16'h1234,1,8,32'h00000040,0,0);
  sc=score_crc(16'hffff,0,32'h00013c40);sc=score_crc(sc,8,32'h00000040);
  command(6,12,16'h1234,sc^1,0,0,0,5);
  command(6,13,16'h1234,sc,0,0,0,0);
  check(score_count==2,"committed score count");
  old_events=events;command(7,14,16'h1234,0,0,0,0,0);
  repeat(300)@(negedge clk);
  check(!score_playing,"score ends locally");
  check(events>=old_events+3,"score on off and scoped clear");
  check(seen[old_events][7:0]==8'h9d&&seen[old_events][14:8]==64,"score MIDI pitch");
  check(seen[old_events+1][7:0]==8'h8d,"score explicit note off");
  command(4,15,16'h1234,2,0,0,0,0);
  command(5,16,16'h1234,0,100,32'h00013c40,0,0);
  command(5,17,16'h1234,1,99,32'h00000040,0,1);
  command(6,18,16'h1234,0,0,0,0,5);
  check(score_count==2,"failed upload preserves active bank");
  playable=0;mode=2;
  command(7,19,16'h1234,0,0,0,0,3);
  command(1,20,16'h1234,1,32'h3c64,0,0,3);
  playable=1;mode=0;
  command(0,16'hfffe,16'h2345,32'h50385731,0,0,0,0);
  command(3,16'hffff,16'h2345,0,0,0,0,0);
  command(3,0,16'h2345,0,0,0,0,0);
  // Hold output ready low: every reply byte must remain stable.
  tx_ready=0;fork begin command(3,1,16'h2345,0,0,0,0,0);end
   begin wait(tx_valid);repeat(10)begin @(negedge clk);check(tx_data==8'h50,"reply holds under backpressure");end tx_ready=1;end join
  old_events=events;command(1,2,16'h2345,32'h01000000,32'h6764,0,0,0);
  check(seen[old_events]==32'h31647f9e,"highest legal base+key gives MIDI127");
  command(2,3,16'h2345,0,0,0,0,0);
  // Long score continues on the FPGA after the phone lease expires.
  command(4,4,16'h2345,2,0,0,0,0);
  command(5,5,16'h2345,0,0,32'h0001643c,0,0);
  command(5,6,16'h2345,1,300,32'h0000003c,0,0);
  sc=score_crc(16'hffff,0,32'h0001643c);sc=score_crc(sc,300,32'h0000003c);
  command(6,7,16'h2345,sc,0,0,0,0);
  command(7,8,16'h2345,0,0,0,0,0);
  repeat(3200)@(negedge clk);check(score_playing,"uploaded score independent of phone heartbeat");
  command(4,9,16'h2345,2,0,0,0,2);
  clear_notes=1;repeat(20)@(negedge clk);clear_notes=0;
  check(!score_playing,"mode/panic stops mobile score");
  command(3,10,16'h2345,0,0,0,0,0);
  // A foreign malformed HELLO must not poison this controller's sequence.
  command(0,1000,16'h9999,0,0,0,0,1);
  command(3,11,16'h2345,0,0,0,0,0);
  command(4,12,16'h2345,2,0,0,0,0);
  command(5,13,16'h2345,0,0,32'h00016440,0,0);
  command(5,14,16'h2345,1,8,32'h00000040,0,0);
  sc=score_crc(16'hffff,0,32'h00016440);sc=score_crc(sc,8,32'h00000040);
  command(7,15,16'h2345,0,0,0,0,0);
  command(6,16,16'h2345,sc,0,0,0,2);
  command(8,17,16'h2345,0,0,0,0,0);
  command(6,18,16'h2345,sc,0,0,0,0);
  $display("P8_WIFI_CONTROL_PASS checks=%0d events=%0d replies=%0d",checks,events,replies);$finish;
 end
 initial begin #10000000;$fatal(1,"WIFI control timeout");end
endmodule
