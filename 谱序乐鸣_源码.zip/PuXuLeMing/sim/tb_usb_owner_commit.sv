`timescale 1ns/1ps
// CPU port master only; both complete SoCs retain their real bus, USB/SIE/PHY,
// UART, FIFOs and official SP RAM primitive. This does not replace peripheral ACK.
module VexRiscv(input clk,reset,timerInterrupt,externalInterrupt,softwareInterrupt,
 output iBus_cmd_valid,input iBus_cmd_ready,output[31:0]iBus_cmd_payload_pc,
 input iBus_rsp_valid,iBus_rsp_payload_error,input[31:0]iBus_rsp_payload_inst,
 output dBus_cmd_valid,input dBus_cmd_ready,output dBus_cmd_payload_wr,
 output[31:0]dBus_cmd_payload_address,dBus_cmd_payload_data,output[1:0]dBus_cmd_payload_size,
 output[3:0]dBus_cmd_payload_mask,input dBus_rsp_ready,dBus_rsp_error,input[31:0]dBus_rsp_data);
 assign iBus_cmd_valid=0;assign iBus_cmd_payload_pc=0;assign dBus_cmd_payload_mask=0;
 assign dBus_cmd_valid=tb_usb_owner_commit.master_valid&&!reset;
 assign dBus_cmd_payload_wr=tb_usb_owner_commit.master_wr;
 assign dBus_cmd_payload_address=tb_usb_owner_commit.master_address;
 assign dBus_cmd_payload_data=tb_usb_owner_commit.master_data;
 assign dBus_cmd_payload_size=tb_usb_owner_commit.master_size;
endmodule
module tb_usb_owner_commit;
 GSR GSR(.GSRI(1'b1));
 reg clk=0,resetn=0;always #10.416667 clk=~clk;
 reg master_valid=0,master_wr=0;reg[31:0]master_address=0,master_data=0;reg[1:0]master_size=0;
 tri dp0,dm0,dp1,dm1;assign(weak1,weak0)dp0=1'b1;assign(weak1,weak0)dm0=1'b0;
 assign(weak1,weak0)dp1=1'b1;assign(weak1,weak0)dm1=1'b0;
 wire[31:0]status[0:1],xy[0:1],raw[0:1],vidpid[0:1],meta[0:1],reports[0:1],midi[0:1],play[0:1];
 wire toggle[0:1],request[0:1],tx[0:1],rx_valid[0:1],tx_ready[0:1];wire[7:0]rx_data[0:1];
 wire[767:0]diag[0:1];wire[255:0]ptest[0:1];
 reg midi_ack=0;reg hold_wifi=0;integer cycles=0,midi_age=0;
 wire wifi_ready=!hold_wifi&&(cycles%19>=8);wire wifi_valid=cycles%7!=0;wire[7:0]wifi_data=cycles;
 usb_play_soc #(.LOCAL_PHY_RESET(1)) dut(.clk(clk),.resetn(resetn),.phy_resetn(resetn),.uart_rx(1'b1),.uart_tx(tx[0]),.usb_dp(dp0),.usb_dm(dm0),
  .debug_status(status[0]),.debug_xy(xy[0]),.debug_raw(raw[0]),.debug_vidpid(vidpid[0]),.debug_meta(meta[0]),.debug_valid_reports(reports[0]),.debug_toggle(toggle[0]),
  .midi_data(midi[0]),.midi_request(request[0]),.midi_ack(midi_ack),.play_status(play[0]),.wifi_rx_data(rx_data[0]),.wifi_rx_valid(rx_valid[0]),.wifi_rx_ready(wifi_ready),
  .wifi_tx_data(wifi_data),.wifi_tx_valid(wifi_valid),.wifi_tx_ready(tx_ready[0]),.link_diagnostics(diag[0]),.ptest_debug(ptest[0]));
 usb_soc_before_owner_commit #(.LOCAL_PHY_RESET(1)) original(.clk(clk),.resetn(resetn),.phy_resetn(resetn),.uart_rx(1'b1),.uart_tx(tx[1]),.usb_dp(dp1),.usb_dm(dm1),
  .debug_status(status[1]),.debug_xy(xy[1]),.debug_raw(raw[1]),.debug_vidpid(vidpid[1]),.debug_meta(meta[1]),.debug_valid_reports(reports[1]),.debug_toggle(toggle[1]),
  .midi_data(midi[1]),.midi_request(request[1]),.midi_ack(midi_ack),.play_status(play[1]),.wifi_rx_data(rx_data[1]),.wifi_rx_valid(rx_valid[1]),.wifi_rx_ready(wifi_ready),
  .wifi_tx_data(wifi_data),.wifi_tx_valid(wifi_valid),.wifi_tx_ready(tx_ready[1]),.link_diagnostics(diag[1]),.ptest_debug(ptest[1]));
 always @(negedge clk)begin
  if(!resetn)begin midi_ack<=0;midi_age<=0;end
  else if(request[0]!=midi_ack)begin if(midi_age==13)begin midi_ack<=request[0];midi_age<=0;end else midi_age<=midi_age+1;end
  else midi_age<=0;
 end
 reg[66:0]expected[$];reg[66:0]tag;
 reg[159:0]before_bundle,before_shadow;reg before_pending,commit_now,unknown_debug;
 reg[6:0]before_guard;reg before_report_pending;
 integer accepts=0,retires=0,aborts=0,checks=0,publishes=0,shadows=0,unknowns=0;
 integer usb_waits=0,uart_waits=0,midi_waits=0,wifi_waits=0,touch_waits=0,guard_one=0,guard_reload=0;
 always @(posedge clk)begin
  cycles=cycles+1;
  if({dut.cpu_dbus_ready,dut.dbus_cmd_valid,dut.dbus_cmd_ready,dut.dbus_pending,dut.dbus_cmd_a,dut.dbus_cmd_data,dut.dbus_cmd_wr,dut.dbus_cmd_size} !==
     {original.cpu_dbus_ready,original.dbus_cmd_valid,original.dbus_cmd_ready,original.dbus_pending,original.dbus_cmd_a,original.dbus_cmd_data,original.dbus_cmd_wr,original.dbus_cmd_size})$fatal(1,"USB_OWNER_ACCEPT_RETIRE_EDGE");
  if(!resetn)begin aborts+=expected.size();expected.delete();end
  else begin
   if(master_valid&&dut.cpu_dbus_ready)begin expected.push_back({master_wr,master_size,master_address,master_data});accepts++;end
   if(dut.dbus_cmd_valid&&dut.dbus_cmd_ready)begin
    if(expected.size()!=1)$fatal(1,"USB_OWNER_SLOT_SEQUENCE");tag=expected.pop_front();
    if({dut.dbus_cmd_wr,dut.dbus_cmd_size,dut.dbus_cmd_a,dut.dbus_cmd_data}!==tag)$fatal(1,"USB_OWNER_SLOT_PAYLOAD");retires++;
   end
   if(dut.usb_sel&&!dut.usb_ack)usb_waits++;
   if(dut.simpleuart_reg_dat_sel&&dut.simpleuart_reg_dat_wait)uart_waits++;
   if(dut.dbus_cmd_valid&&dut.midi_event_wait)midi_waits++;
   if(dut.dbus_cmd_valid&&dut.wifi_event_wait)wifi_waits++;
   if(dut.dbus_cmd_valid&&dut.touch_event_wait)touch_waits++;
   if(dut.dbus_cmd_valid&&dut.dbus_cmd_a==32'h02000214&&dut.touch_publish_guard==1)guard_one++;
  end
  before_bundle={status[1],xy[1],raw[1],vidpid[1],meta[1]};
  before_shadow={original.shadow_status,original.shadow_xy,original.shadow_raw,original.shadow_vidpid,original.shadow_meta};
  before_report_pending=original.valid_report_pending;before_guard=original.touch_publish_guard;
  commit_now=resetn&&original.touch_event_commit;
  unknown_debug=resetn&&original.dbus_cmd_valid&&original.dbus_cmd_ready&&original.dbus_cmd_wr&&original.dbus_cmd_a[31:8]==24'h020002&&
   !(original.dbus_cmd_a[7:0] inside {8'h00,8'h04,8'h08,8'h0c,8'h10,8'h14});
  #1;checks++;
  if({status[0],xy[0],raw[0],vidpid[0],meta[0],reports[0],toggle[0],midi[0],request[0],play[0],tx[0],rx_data[0],rx_valid[0],tx_ready[0],diag[0],ptest[0],dp0,dm0} !==
     {status[1],xy[1],raw[1],vidpid[1],meta[1],reports[1],toggle[1],midi[1],request[1],play[1],tx[1],rx_data[1],rx_valid[1],tx_ready[1],diag[1],ptest[1],dp1,dm1})$fatal(1,"USB_OWNER_PUBLIC_CYCLE");
  if({dut.dbus_rsp_ready,dut.dbus_rsp_error,dut.dbus_rdata,dut.ibus_rsp_ready,dut.usb_ack,dut.usb_sel,dut.usb_rdata,dut.usb_host_resetn,dut.out_dp,dut.out_dn,dut.out_tx_oen} !==
     {original.dbus_rsp_ready,original.dbus_rsp_error,original.dbus_rdata,original.ibus_rsp_ready,original.usb_ack,original.usb_sel,original.usb_rdata,original.usb_host_resetn,original.out_dp,original.out_dn,original.out_tx_oen})$fatal(1,"USB_OWNER_CPU_AND_NATIVE_PERIPHERAL");
  if({dut.shadow_status,dut.shadow_xy,dut.shadow_raw,dut.shadow_vidpid,dut.shadow_meta,dut.valid_report_pending,dut.touch_publish_guard,dut.debug_valid_reports} !==
     {original.shadow_status,original.shadow_xy,original.shadow_raw,original.shadow_vidpid,original.shadow_meta,original.valid_report_pending,original.touch_publish_guard,original.debug_valid_reports})$fatal(1,"USB_OWNER_ALL_SIDE_EFFECTS");
  if(resetn)begin
   if(commit_now)begin
    if({status[0],xy[0],raw[0],vidpid[0],meta[0]}!==before_shadow||dut.touch_publish_guard!==7'd64)$fatal(1,"USB_OWNER_ATOMIC_PUBLISH");publishes++;guard_reload++;
   end else if({status[0],xy[0],raw[0],vidpid[0],meta[0]}!==before_bundle)$fatal(1,"USB_OWNER_UNEXPECTED_PUBLICATION");
   if(unknown_debug)begin
    if({dut.shadow_status,dut.shadow_xy,dut.shadow_raw,dut.shadow_vidpid,dut.shadow_meta}!==before_shadow||dut.valid_report_pending!==before_report_pending)$fatal(1,"USB_OWNER_UNKNOWN_SIDE_EFFECT");unknowns++;
   end
  end
 end
 task submit(input[31:0]address,data,input bit wr,input[1:0]size);integer wait_cycles;bit accepted;begin
  @(negedge clk);master_address=address;master_data=data;master_wr=wr;master_size=size;master_valid=1;wait_cycles=0;accepted=0;
  while(!accepted)begin @(posedge clk);if(dut.cpu_dbus_ready)accepted=1;wait_cycles++;if(wait_cycles>2000)$fatal(1,"USB_OWNER_CPU_ACCEPT_TIMEOUT");end
  @(negedge clk);master_valid=0;
 end endtask
 task drain;integer wait_cycles;begin
  wait_cycles=0;while(dut.dbus_pending)begin @(negedge clk);wait_cycles++;if(wait_cycles>2000)$fatal(1,"USB_OWNER_RETIRE_TIMEOUT addr%h",master_address);end
  @(negedge clk);
 end endtask
 task command(input[31:0]address,data,input bit wr,input[1:0]size);begin submit(address,data,wr,size);drain;end endtask
 integer i,j,pg,sz,rw,seed=32'h13572468;reg[31:0]address,value;
 initial begin
  repeat(8)@(negedge clk);resetn=1;
  command(32'h02000010,3,1,2);for(i=0;i<6;i++)command(32'h02000014,8'h41+i,1,2);
  for(i=0;i<5;i++)command(32'h02000200+i*4,32'h10203040+i,1,2);
  command(32'h02000200,32'h00007005,1,2);repeat(4)command(32'h02000214,0,1,2);
  for(i=0;i<8;i++)command(32'h02000220,32'h100+i,1,2);
  for(i=0;i<8;i++)begin command(32'h02000220,i,1,2);command(32'h02000218,i,1,2);command(32'h0200021c,0,0,2);end
  // All offsets on each actual peripheral page, both directions and all sizes.
  for(pg=0;pg<3;pg++)for(sz=0;sz<4;sz++)for(rw=0;rw<2;rw++)for(i=0;i<256;i++)begin
   address=32'h02000000+(pg<<8)+i;value=(i*32'h10203)^32'h5a0034;
   if(address==32'h02000010)value=3;
   if(pg==1)value=0; // Native USB registers/FIFOs still acknowledge; no fake USB ACK.
   command(address,value,rw,sz);
  end
  for(i=0;i<512;i++)begin
   command(32'h03000200+i,32'hdeadbeef,1,i%4);
   command(32'h02010200+i,32'h76543210,1,i%4);
  end
  // Legal master command abort under a real externally stalled WiFi transfer.
  @(negedge clk);hold_wifi=1;submit(32'h02000218,32'h44,1,2);
  repeat(4)@(negedge clk);if(!dut.dbus_pending)$fatal(1,"USB_OWNER_RESET_PENDING_NOT_REACHED");resetn=0;
  repeat(6)@(negedge clk);master_valid=0;hold_wifi=0;resetn=1;
  for(i=0;i<128;i++)begin
   command(32'h02000200,32'h00007005,1,2);command(32'h02000204,32'h00400080+i,1,2);
   command(32'h02000214,0,1,2);command(32'h02000214,0,1,2);
   command(32'h02000104,0,0,2);
  end
  repeat(100)@(negedge clk);
  if(accepts!=retires+aborts||expected.size()!=0||aborts==0||publishes<250||usb_waits==0||uart_waits==0||midi_waits==0||wifi_waits==0||touch_waits==0||guard_one==0||unknowns<100)$fatal(1,"USB_OWNER_COVERAGE a%0d/r%0d/abort%0d pub%0d wait%0d/%0d/%0d/%0d/%0d one%0d unknown%0d",accepts,retires,aborts,publishes,usb_waits,uart_waits,midi_waits,wifi_waits,touch_waits,guard_one,unknowns);
  $display("USB_OWNER_COMMIT_PASS clocks%0d accepts%0d retires%0d aborts%0d publishes%0d USBwait%0d UARTwait%0d MIDIwait%0d WiFiwait%0d guardwait%0d guard1to0%0d reload64%0d unknown%0d nativeUSB_SIE_PHY_UART independentPins all256offsets3pages4sizes2directions exactOldSoCPerClock",checks,accepts,retires,aborts,publishes,usb_waits,uart_waits,midi_waits,wifi_waits,touch_waits,guard_one,guard_reload,unknowns);$finish;
 end
 initial begin #30000000;$fatal(1,"USB_OWNER_GLOBAL_TIMEOUT");end
endmodule
