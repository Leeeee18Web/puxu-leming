`timescale 1ns/1ps
module tb_poly12_bank;
 reg clk=0;always #10 clk=~clk;reg rst=1,start=0;
 reg[11:0]gates=0,triggers=0;reg[287:0]steps=0;reg[143:0]gains=0;reg[35:0]tones=0;
 wire[191:0]samples,envelopes;wire[11:0]active;wire busy,error;
 wire[15:0]gold_sample[0:11],gold_envelope[0:11];wire[11:0]gold_active,gold_error,gold_busy;
 poly25_bank #(.VOICE_COUNT(12),.REGIONAL_MODEL_CONTROLS(1)) dut(clk,rst,start,gates,triggers,steps,gains,tones,samples,envelopes,active,busy,error,{12{rst}},1'b1);
 genvar v;generate for(v=0;v<12;v=v+1)begin:private_reference
  poly_voice_worker #(.CONTEXTS(1),.LOCAL_MEMORY_RESET(1),.PRECALC_SLOT_GATES(1),.LOCAL_CONTROL(1),.REGIONAL_MODEL_CONTROLS(1)) oracle(
   .clk(clk),.rst(rst),.start(start),.gates(gates[v]),.triggers(triggers[v]),.steps(steps[v*24+:24]),.gains(gains[v*12+:12]),.timbres(tones[v*3+:3]),
   .samples(gold_sample[v]),.envelopes(gold_envelope[v]),.active(gold_active[v]),.busy(gold_busy[v]),.deadline_error(gold_error[v]),
   .out_valid(),.out_index(),.out_sample(),.model_reset({3{rst}}),.memory_reset(rst),.control_resetn_early(1'b1));
 end endgenerate
 integer f,c,i,checks=0,last_busy=0,max_busy=0;reg[11:0]heard=0;
 initial begin
  repeat(8)@(negedge clk);rst=0;
  for(f=0;f<3500;f=f+1)begin
   gates=f<3000?12'hfff:0;triggers=(f==0||f==1700)?12'hfff:0;
   for(i=0;i<12;i=i+1)begin
    steps[i*24+:24]=24'd45000+i*12000+(f%7);gains[i*12+:12]=1000+i*250;
    tones[i*3+:3]=f<1700?i%4:(i+1)%4;
   end
   if(f>=1800&&f<1900)begin gates[11]=0;gains[11*12+:12]=0;end
   if(f==1900)triggers[11]=1;
   last_busy=0;
   for(c=0;c<1024;c=c+1)begin
    start=c==32;@(negedge clk);
    if(busy)last_busy=c;
    if(c==928)begin
     if(busy||error||(|gold_error)||(|gold_busy))$fatal(1,"BANK12_DEADLINE frame%0d",f);
     for(i=0;i<12;i=i+1)begin
      if(samples[i*16+:16]!==gold_sample[i]||envelopes[i*16+:16]!==gold_envelope[i]||active[i]!==gold_active[i])
       $fatal(1,"BANK12_PRIVATE_GOLD frame%0d voice%0d sample%0d/%0d",f,i,$signed(samples[i*16+:16]),$signed(gold_sample[i]));
      if($signed(samples[i*16+:16])!=0)heard[i]=1;
      checks=checks+1;
     end
    end
   end
   if(last_busy>max_busy)max_busy=last_busy;
  end
  if(heard!==12'hfff)$fatal(1,"BANK12_SILENT_VOICE %h",heard);
  $display("POLY12_BANK_PASS checks%0d all12private-reference 4tones/switch/release/localreset/spill maxBusy%0d",checks,max_busy);$finish;
 end
 initial begin #80000000;$fatal(1,"BANK12_TIMEOUT");end
endmodule
