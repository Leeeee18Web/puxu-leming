`timescale 1ns/1ps
module tb_score2_sign_audio;
 reg clk=0;always #10 clk=~clk;reg rst=1;reg[31:0]cfg=0;reg[3:0]gates=0,triggers=0;reg[27:0]notes={7'd72,7'd67,7'd64,7'd60};reg[47:0]gains={12'd1500,12'd1600,12'd1700,12'd1800};reg[11:0]timbres={3'd3,3'd2,3'd1,3'd0};reg[18:0]ratio=262144;reg[6:0]depth=0;
 wire tick,rtick,positive,deadline,rdeadline,clip,rclip;wire signed[15:0]pcm,rpcm;wire[5:0]pins,rpins;wire[3:0]active,ractive;wire[95:0]steps,rsteps;wire[63:0]envs,renvs;
 final_audio #(.ENABLE_FX(1)) dut(.clk(clk),.rst(rst),.gates(gates),.triggers(triggers),.notes(notes),.gains(gains),.timbres(timbres),.ratio(ratio),.mod_depth(depth),.synth_config(cfg),.sample_tick(tick),.pcm(pcm),.pcm_positive(positive),.hp_bck(pins[0]),.hp_ws(pins[1]),.hp_din(pins[2]),.i2s_bck(pins[3]),.i2s_ws(pins[4]),.i2s_sd(pins[5]),.active(active),.monitor_steps(steps),.monitor_envelopes(envs),.deadline_error(deadline),.clip_active(clip));
 final_audio_sign_ref #(.ENABLE_FX(1)) reference(.clk(clk),.rst(rst),.gates(gates),.triggers(triggers),.notes(notes),.gains(gains),.timbres(timbres),.ratio(ratio),.mod_depth(depth),.synth_config(cfg),.sample_tick(rtick),.pcm(rpcm),.hp_bck(rpins[0]),.hp_ws(rpins[1]),.hp_din(rpins[2]),.i2s_bck(rpins[3]),.i2s_ws(rpins[4]),.i2s_sd(rpins[5]),.active(ractive),.monitor_steps(rsteps),.monitor_envelopes(renvs),.deadline_error(rdeadline),.clip_active(rclip));
 integer checks=0,i,frames=0;reg[31:0]random=32'h31415926;
 always @(negedge clk)begin #1;
  if({pcm,pins,tick,active,steps,envs,deadline,clip}!=={rpcm,rpins,rtick,ractive,rsteps,renvs,rdeadline,rclip})$fatal(1,"SIGN_TIMING_CHANGED_AUDIO frame=%0d",frames);
  if(positive!==($signed(pcm)>0))$fatal(1,"POSITIVE_NOT_SAME_CYCLE frame=%0d",frames);
  checks=checks+1;
 end
 initial begin repeat(5)@(negedge clk);rst=0;
  for(i=0;i<5000;i=i+1)begin
   @(posedge tick);@(negedge clk);frames=frames+1;
   random={random[30:0],random[31]^random[21]^random[1]^random[0]};
   gates=random[3:0];triggers=random[7:4]&gates;
   cfg={26'd0,random[13:8]};depth=random[20:14];ratio=200000+{2'd0,random[31:16]};
   if(i%59==0)cfg[31]=1;
   if(i%137==0)begin repeat(4)@(negedge clk);rst=1;repeat(3)@(negedge clk);rst=0;end
  end
  $display("SIGN_AUDIO_EQ_PASS checks=%0d frames=%0d PCM all6pins metadata clear reset same cycle",checks,frames);$finish;
 end
 initial begin #120000000;$fatal(1,"TIMEOUT");end
endmodule
