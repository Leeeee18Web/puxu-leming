`timescale 1ns/1ps
module final_ui_raster;
 reg clk=0;always #9.756 clk=~clk;
 reg rstn=0,den=0,hs=0,vs=0;
 reg [13:0]x=0,y=0;reg [2:0]page=0;reg [1:0]mode=0;
 reg [6:0]gates=127,base=60;reg valid=1;reg [48:0]notes=0;reg [83:0]gains=0;
 reg [3:0]all_gates=0;reg [27:0]all_notes=0;reg [47:0]all_gains=0;
 reg [6:0]feedback_note=62,next=64,target=60;reg [1:0]feedback=0;
 reg [1:0]touch_state=0,pattern_mode=0;reg [6:0]pattern_selected=0;reg [48:0]pattern_notes=0;
 reg pattern_busy=0,pattern_full=0;reg [2:0]pattern_count=0;
 reg piano_ready=1,touch_ready=1,recording=0,replaying=0,record_full=0,dropdown=0,overview=0;
 reg [2:0]timbre=0;reg [5:0]settings=6'b101000;
 wire [23:0]rgb,ref_rgb;wire de,ho,vo,ref_de,ref_ho,ref_vo;
 wire [9:0]wa,ta;wire [6:0]sa;wire [15:0]xa;
 reg [47:0]wave=0;reg [7:0]spectrum=0;reg [10:0]tone=60;reg [16:0]curve=0;reg xy=0;
 final_panel dut(.envelope_choices(8'h95),.preview_busy(1'b0),.pixel_clk(clk),.rstn(rstn),.den(den),.hsync(hs),.vsync(vs),.x(x),.y(y),
 .page(page),.mode(mode),.playing(1'b1),.muted(1'b0),.note_valid(1'b1),.next_note(next),.base_note(base),.gates(all_gates),.notes(all_notes),.gains(all_gains),
 .home_gates(gates),.home_gains(gains),.piano_ready(piano_ready),.touch_ready(touch_ready),
 .recording(recording),.replaying(replaying),.record_full(record_full),.record_count(13'd4096),.record_milliseconds(16'd12345),
 .timbre(timbre),.timbre_open(dropdown),.xy_overview(overview),.synth_config(32'd0),
 .knob(7'd64),.raw_knob(7'd93),.raw_known(1'b1),.pickup_wait(1'b0),.knob_mode(2'd1),
 .touch_state(touch_state),
 .pattern_mode(pattern_mode),.pattern_selected(pattern_selected),.pattern_notes(pattern_notes),
 .pattern_busy(pattern_busy),.pattern_count(pattern_count),.pattern_full(pattern_full),
 .lesson_target(target),.lesson_feedback_note(feedback_note),.lesson_feedback(feedback),.lesson_position(6'd0),.lesson_done(1'b0),
 .last_note(7'd60),.last_velocity(7'd96),.mod_depth(7'd32),.wave_data(wave),
 .spectrum_data(spectrum),.spectrum_peak(8'd128),.spectrum_zoom(2'd2),.visual_valid(valid),
 .tone_data(tone),.tone_curve(curve),.tone_count(10'd768),.xy_data(xy),.xy_valid(1'b1),
 .xy_settings(settings),.wave_addr(wa),.spectrum_addr(sa),.tone_addr(ta),.xy_addr(xa),
 .rgb(rgb),.den_out(de),.hsync_out(ho),.vsync_out(vo));
 p8_panel reference_panel(.pixel_clk(clk),.rstn(rstn),.den(den),.hsync(hs),.vsync(vs),.x(x),.y(y),
 .page(page),.mode(mode),.playing(1'b1),.muted(1'b0),.note_valid(1'b1),.next_note(next),.base_note(base),.gates(gates),.notes(notes),.gains(gains),
 .knob(7'd64),.raw_knob(7'd93),.raw_known(1'b1),.pickup_wait(1'b0),.knob_mode(2'd1),
 .touch_state(touch_state),
 .pattern_mode(pattern_mode),.pattern_selected(pattern_selected),.pattern_notes(pattern_notes),
 .pattern_busy(pattern_busy),.pattern_count(pattern_count),.pattern_full(pattern_full),
 .lesson_target(target),.lesson_feedback_note(feedback_note),.lesson_feedback(feedback),.lesson_position(6'd0),.lesson_done(1'b0),
 .last_note(7'd60),.last_velocity(7'd96),.mod_depth(7'd32),.wave_data(wave),
 .spectrum_data(spectrum),.spectrum_peak(8'd128),.spectrum_zoom(2'd2),.visual_valid(valid),
 .tone_data(tone),.tone_curve(curve),.tone_count(10'd768),.xy_data(xy),.xy_valid(1'b1),
 .xy_settings(6'b101000),.wave_addr(),.spectrum_addr(),.tone_addr(),.xy_addr(),
 .rgb(ref_rgb),.den_out(ref_de),.hsync_out(ref_ho),.vsync_out(ref_vo));
 integer xx,yy,i,j,fh,pixels=0,checks=0,a,b,k;
 integer d[0:8],h[0:8],v[0:8];reg [23:0]ref_rgb_prev=0;reg comparing=0,capture=0;
 string out_dir=".",filename;
 // Explicit synthetic graph input fixtures; product rendering is genuine RTL.
 always @(posedge clk)begin
  wave[15:0]<=$signed({1'b0,wa[7:0]})*128-16384;spectrum<=sa[3:0]*8;curve<=(240+ta/4)<<8;
  a=$signed({1'b0,xa[7:0]})-128;b=$signed({1'b0,xa[15:8]})-128;
  xy<=a*a+b*b>9200&&a*a+b*b<10400;
 end
 task tick;begin
  @(posedge clk);#1;
  for(j=8;j>0;j=j-1)begin d[j]=d[j-1];h[j]=h[j-1];v[j]=v[j-1];end
  d[0]=den;h[0]=hs;v[0]=vs;
  if(de!==d[8]||ho!==h[8]||vo!==v[8])$fatal(1,"FINAL_UI_FAIL 9cycle sync pipeline");
  if(comparing&&rgb!==ref_rgb_prev)$fatal(1,"FINAL_UI_FAIL Home differs from legacy pixel(%0d,%0d) rgb=%h ref=%h",x,y,rgb,ref_rgb_prev);
  ref_rgb_prev=ref_rgb;
  if(de&&capture)begin $fwrite(fh,"%c%c%c",rgb[23:16],rgb[15:8],rgb[7:0]);pixels=pixels+1;end
  checks=checks+1;@(negedge clk);
 end endtask
 task probe(input integer pg,ax,ay,input [23:0]expected);begin
  page=pg;x=ax;y=ay;den=1;repeat(12)tick;
  if(rgb!==expected)$fatal(1,"FINAL_UI_FAIL pixel p%0d (%0d,%0d) wanted=%h got=%h",pg,ax,ay,expected,rgb);
 end endtask
 task frame(input string name);begin
  den=0;capture=0;repeat(12)tick;
  filename=$sformatf("%s/%s.ppm",out_dir,name);fh=$fopen(filename,"wb");
  if(!fh)$fatal(1,"FINAL_UI_FAIL open raster");$fwrite(fh,"P6\n1024 600\n255\n");pixels=0;capture=1;
  for(yy=0;yy<600;yy=yy+1)for(xx=0;xx<1024;xx=xx+1)begin
   x=xx;y=yy;den=1;hs=xx>=1000;vs=yy>=598;tick;
  end
  den=0;hs=0;vs=0;repeat(12)tick;capture=0;$fclose(fh);
  if(pixels!=614400)$fatal(1,"FINAL_UI_FAIL raster pixel count=%0d",pixels);
  $display("FINAL_UI_FRAME %s pixels=%0d",name,pixels);
 end endtask
 initial begin
  if($value$plusargs("OUTDIR=%s",out_dir))begin end
  for(i=0;i<9;i=i+1)begin d[i]=0;h[i]=0;v[i]=0;end
  for(i=0;i<7;i=i+1)begin notes[i*7+:7]=60+i;gains[i*12+:12]=(i+1)*512;end
  repeat(4)@(negedge clk);rstn=1;
  // Strongest Home invariant: compare all614400 output pixels against legacy.
  comparing=1;frame("home_exact");comparing=0;
  // Every actual engine slot controls full white and black key fill.
  mode=1;
  for(i=0;i<4;i=i+1)begin
   all_gates=4'b1<<i;all_notes=0;all_notes[i*7+:7]=61;
   probe(5,96,320,24'hf5c767);probe(5,78,320,24'hf5c767);
   all_notes[i*7+:7]=60;probe(5,64,550,24'hf5c767);
  end
  all_gates=0;probe(5,96,320,24'h101010);
  mode=3;target=61;feedback_note=61;feedback=1;
  probe(5,96,320,24'h78e6af);feedback=2;probe(5,96,320,24'he56c79);
  feedback_note=60;feedback=1;probe(5,64,550,24'h78e6af);feedback=2;probe(5,64,550,24'he56c79);
  feedback=0;target=60;mode=1;
  // Separate readiness is color data from independent configured inputs.
  piano_ready=0;touch_ready=1;probe(5,880,72,24'h162630);
  all_gates=(4'b1<<3)|1;all_notes[6:0]=60;all_notes[3*7+:7]=61;
  page=5;pattern_mode=2;pattern_selected=7'b101;pattern_notes[6:0]=60;pattern_notes[20:14]=67;pattern_count=2;
  frame("keyboard_ready_independent");piano_ready=1;recording=1;frame("keyboard_recording");recording=0;replaying=1;frame("keyboard_replaying");replaying=0;
  record_full=1;frame("keyboard_record_full");record_full=0;
  mode=3;target=60;feedback=2;feedback_note=62;frame("lesson_feedback");mode=1;feedback=0;
  for(k=0;k<4;k=k+1)begin timbre=k;dropdown=1;frame($sformatf("dropdown_%0d",k));end
  dropdown=0;timbre=0;page=3;frame("lissajous_big");overview=1;frame("lissajous_matrix_auto");settings=6'b010011;frame("lissajous_matrix_selected");overview=0;frame("lissajous_selected");
  mode=2;page=1;recording=1;frame("song_recording");recording=0;replaying=1;frame("song_replaying");replaying=0;
  page=2;frame("spectrum");page=4;frame("wave");page=7;frame("guide");
  $display("FINAL_UI_PASS raster checks=%0d Home_pixel_identical=1 all4_highlight=1",checks);$finish;
 end
endmodule
