`timescale 1ns/1ps
module tb_bridge_equiv;
 reg[2:0]kind=1;reg signed[17:0]a=0,b=0,c=0;
 wire signed[17:0]ra,rb,rc,xa,xb,xc;
 phys_string_bridge #(.PREDECODE_PIANO(1)) dut(kind,a,b,c,ra,rb,rc,kind==1,20'sd0);
 ref_r2_phys_string_bridge reference(kind,a,b,c,xa,xb,xc);
 integer total,left,checks=0,k;reg[31:0]rng=32'hc481a923;
 function automatic integer bound(input integer x);begin bound=x< -131072?-131072:x>131071?131071:x;end endfunction
 task check;begin #1;if({ra,rb,rc}!=={xa,xb,xc})$fatal(1,"BRIDGE_EQ_FAIL kind=%0d inputs=%0d,%0d,%0d",kind,a,b,c);checks++;end endtask
 initial begin
  kind=1;for(total=-393216;total<=393213;total++)begin a=bound(total);left=total-$signed(a);b=bound(left);c=left-$signed(b);check;end
  kind=2;for(total=-262144;total<=262142;total++)begin a=bound(total);b=total-$signed(a);c=18'sd131071;check;end
  for(k=0;k<100000;k++)begin
   rng=rng*32'd1664525+32'd1013904223;a=rng[17:0];rng=rng*32'd1664525+32'd1013904223;b=rng[17:0];rng=rng*32'd1664525+32'd1013904223;c=rng[17:0];kind=(k%2)+1;check;
  end
  $display("BRIDGE_EQ_PASS checks=%0d exhaustive_reachable_totals_plus_100k_wave_distributions",checks);$finish;
 end
endmodule
