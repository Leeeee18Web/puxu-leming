#include <cassert>
#include <iostream>
#include "p8_map_store.h"
#include "p8_link.h"
int main(){
 p8::MapTracker t;uint8_t req[22]={},ack[22]={};unsigned saves=0;
 auto command=[&](unsigned op,uint32_t a,uint32_t b,uint8_t result=0){memset(req,0,22);memset(ack,0,22);req[3]=uint8_t(op);for(unsigned i=0;i<4;i++){req[8+i]=uint8_t(a>>(i*8));req[12+i]=uint8_t(b>>(i*8));}ack[8]=result;uint16_t c=p8::mapCRC(t.draft);p8::put16(ack+12,c);bool save=t.ack(req,ack);if(save)saves++;return save;};
 assert(!command(20,60,1));assert(!command(21,0,0));assert(!command(22,p8::mapCRC(t.draft),1));assert(saves==0);
 for(unsigned i=0;i<25;i++)assert(!command(21,i,i==24?127:67));
 const auto good=p8::mapCRC(t.draft);assert(!command(22,good^1,1));assert(!command(22,good,1,5));assert(saves==0);
 assert(command(22,good,1));assert(saves==1&&p8::mapValid(t.draft));
 assert(command(22,good,1));assert(saves==2); // HTTP retry after failed NVS write remains saveable.
 auto corrupt=t.draft;corrupt.notes[24]^=1;assert(!p8::mapValid(corrupt));
 assert(!command(0,0,0));assert(!command(22,good,1));assert(saves==2);
 for(unsigned op:{0u,1u,16u,20u,21u,22u,23u,24u}){uint8_t p[22]={'P','W',1,uint8_t(op)};p8::put16(p+6,1);if(op==0){for(unsigned i=0;i<4;i++)p[8+i]=uint8_t(p8::IDENTITY>>(i*8));}p8::put16(p+20,p8::crc(p+2,18));assert(p8::requestValid(p));}
 for(unsigned op:{17u,18u,19u,25u,127u}){uint8_t p[22]={'P','W',1,uint8_t(op)};p8::put16(p+6,1);p8::put16(p+20,p8::crc(p+2,18));assert(!p8::requestValid(p));}
 std::cout<<"POLY25_MAP_STORE_PASS ACK-only persistence, incomplete/badCRC/failedACK/reset/retry/schema, PW1 old/new opcode allowlist\n";
}
