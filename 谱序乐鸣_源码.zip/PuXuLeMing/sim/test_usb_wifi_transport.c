/* Transaction fixture: production enumeration/control/parser/poll code,
 * synthetic USB packets. No PC driver or physical board. */
#define main baseline_main
#define usb_play_transaction baseline_transaction
#define usb_play_publish baseline_publish
#include "test_usb_play.c"
#undef main
#undef usb_play_transaction
#undef usb_play_publish
#define SERIAL 7u
static const uint8_t serial_config[]={9,2,39,0,1,6,0,0x80,50,
 9,4,2,0,3,0xff,1,2,0,
 7,5,0x84,2,16,0,0, 7,5,0x06,2,8,0,0, 7,5,0x81,3,8,0,1};
static uint8_t delivered[4096],replies[4096],outbound[4096],retry_data[64];
static unsigned ndelivered,nreplies,reply_pos,noutbound,out_nak,out_timeout,out_calls,out_toggle,retry_len,retry_toggle,serial_setups;
static unsigned block_after;
uint32_t usb_play_wifi_ready(void){return block_after&&ndelivered>=block_after&&reply_pos<22?0:0x80000000u;}
static unsigned serial_version=0x30,serial_bad_pair,serial_duplicate;
static unsigned serial_silent;
uint32_t usb_play_wifi_read(void){return reply_pos<nreplies?0x80000000u|replies[reply_pos++]:0;}
void usb_play_publish(uint32_t a,uint32_t v){if(a==0x02000218u){CHECK(ndelivered<sizeof(delivered));CHECK(usb_play_wifi_ready()&0x80000000u);delivered[ndelivered++]=(uint8_t)v;if(block_after&&ndelivered==block_after){memset(replies,0xa5,22);nreplies=22;reply_pos=0;}}else baseline_publish(a,v);}
int usb_play_transaction(unsigned addr,unsigned pid,unsigned ep,unsigned tog,const uint8_t *tx,unsigned tn,uint8_t *rx,unsigned cap,unsigned *rpid){
 if(serial_silent&&addr){ms++;return USB_PLAY_TIMEOUT;}
 unsigned slot=active(addr);
 if(slot==99||d[slot].kind!=SERIAL)return baseline_transaction(addr,pid,ep,tog,tx,tn,rx,cap,rpid);
 ms++;fake_device *f=&d[slot];
 if(pid==USB_PLAY_SETUP){
  CHECK(ep==0&&tog==0&&tn==8);c.device=slot;c.type=tx[0];c.request=tx[1];c.value=le(tx+2);c.index=le(tx+4);c.length=le(tx+6);c.off=0;c.toggle=1;c.size=0;
  if(c.request==6){if(c.value==0x100){uint8_t dev[]={18,1,0x10,1,0xff,0,0,8,0x86,0x1a,0x23,0x75,0,1,0,0,0,1};memcpy(c.data,dev,18);c.size=18;}
   else {CHECK(c.value==0x200);memcpy(c.data,serial_config,sizeof(serial_config));c.size=sizeof(serial_config);if(serial_bad_pair)c.data[27]=0x86;}}
  else if(c.request==0x5f){CHECK(c.type==0xc0&&c.length==2);c.data[0]=(uint8_t)serial_version;c.data[1]=0;c.size=2;serial_setups|=1;}
  else if(c.request==0xa1){CHECK(c.type==0x40&&c.value==0&&c.index==0);serial_setups|=2;}
  else if(c.request==0x9a){CHECK(c.type==0x40);if(c.value==0x1312){CHECK(c.index==(serial_version>0x27?0xcc83u:0xcc03u));serial_setups|=4;}else if(c.value==0x2518){CHECK(c.index==0xc3&&serial_version>=0x30);serial_setups|=8;}else {CHECK(c.value==0x0f2c&&c.index==8&&serial_version<0x30);serial_setups|=8;}}
  else if(c.request==0xa4){CHECK(c.value==0xffff&&c.index==0);serial_setups|=16;}
  else if(c.request==5){CHECK(c.value>=1&&c.value<=8);}
  else if(c.request==9){CHECK(c.value==6);}
  else if(c.request==1&&c.type==2){CHECK(c.index==6||c.index==0x84);f->halt_clears++;if(c.index==6)out_toggle=0;else f->toggle=0;}
  else CHECK(0);
  if(c.size>c.length)c.size=c.length;
  return 0;
 }
 if(ep==0){CHECK(c.device==slot);if(pid==USB_PLAY_OUT){CHECK(c.length&&c.off==c.size&&tog==1);return 0;}
  if(!c.length){if(c.request==5)f->address=c.value;if(c.request==9)f->configured=c.value;*rpid=USB_PLAY_DATA1;return 0;}
  unsigned n=c.size-c.off;if(n>8)n=8;CHECK(cap>=n&&tog==c.toggle);memcpy(rx,c.data+c.off,n);c.off+=n;*rpid=c.toggle?USB_PLAY_DATA1:USB_PLAY_DATA0;c.toggle^=1;return (int)n;
 }
 CHECK(f->configured);
 if(pid==USB_PLAY_IN){CHECK(ep==4);f->endpoint_calls++;if(!f->queue_len)return USB_PLAY_NAK;
  unsigned n=f->queue_len;CHECK(n<=16&&cap>=n);memcpy(rx,f->queue,n);
  if(serial_duplicate){serial_duplicate--;*rpid=f->toggle?USB_PLAY_DATA0:USB_PLAY_DATA1;return (int)n;}
  CHECK(tog==f->toggle);*rpid=f->toggle?USB_PLAY_DATA1:USB_PLAY_DATA0;f->toggle^=1;f->queue_len=0;return (int)n;
 }
 CHECK(pid==USB_PLAY_OUT&&ep==6&&tn<=8);out_calls++;CHECK(tog==out_toggle);
 if(retry_len){CHECK(tn==retry_len&&tog==retry_toggle&&!memcmp(tx,retry_data,tn));}
 if(out_nak||out_timeout){memcpy(retry_data,tx,tn);retry_len=tn;retry_toggle=tog;if(out_nak){out_nak--;return USB_PLAY_NAK;}out_timeout--;return USB_PLAY_TIMEOUT;}
 retry_len=0;CHECK(noutbound+tn<=sizeof(outbound));memcpy(outbound+noutbound,tx,tn);noutbound+=tn;out_toggle^=1;return 0;
}
static uint16_t ref_crc(uint16_t crc,uint8_t b){crc^=(uint16_t)b<<8;for(unsigned i=0;i<8;i++)crc=(uint16_t)((crc<<1)^((crc&0x8000)?0x1021:0));return crc;}
static unsigned envelope(uint8_t *dst,const uint8_t *data,unsigned n){uint16_t crc=0xffff;dst[0]='W';dst[1]='F';dst[2]=1;dst[3]=(uint8_t)n;for(unsigned i=2;i<4;i++)crc=ref_crc(crc,dst[i]);for(unsigned i=0;i<n;i++){dst[4+i]=data[i];crc=ref_crc(crc,data[i]);}dst[n+4]=(uint8_t)crc;dst[n+5]=(uint8_t)(crc>>8);return n+6;}
static void serial_fixture(unsigned hub){fixture(hub?HUB:SERIAL);serial_silent=0;ndelivered=nreplies=reply_pos=noutbound=out_nak=out_timeout=out_calls=out_toggle=retry_len=serial_setups=serial_bad_pair=serial_duplicate=block_after=0;
 if(hub){hub_ports=3;d[1].kind=HID;d[2].kind=MIDI;d[3].kind=SERIAL;for(unsigned i=1;i<=3;i++)port_status[i]=port_change[i]=1;}tick(90);}
static void stream(unsigned slot,const uint8_t *p,unsigned n){unsigned total=n;while(n){unsigned take=n>11?11:n;queue(slot,p,take);tick(1);p+=take;n-=take;}tick(total+70);}
#ifndef USB_WIFI_NO_MAIN
int main(void){baseline_main(0,0);
 for(unsigned old=0;old<2;old++){
 serial_version=old?0x27:0x30;serial_fixture(0);CHECK((usb_play_state()&32)!=0&&serial_setups==31&&d[0].configured==6);
 const uint8_t app[]={0x50,0x57,1,3,0,1,0,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};uint8_t wire[70];unsigned n=envelope(wire,app,sizeof(app));
 uint8_t noise[]={0,0x57,0,0x57,0x46,2,4,8};stream(0,noise,sizeof(noise));CHECK(ndelivered==0);wire[n-1]^=1;stream(0,wire,n);CHECK(ndelivered==0);wire[n-1]^=1;
 serial_duplicate=1;queue(0,wire,11);tick(1);tick(1);stream(0,wire+11,n-11);CHECK(ndelivered==sizeof(app)&&!memcmp(delivered,app,sizeof(app)));
 /* A partial stale WF1 frame cannot swallow the next complete frame. */
 stream(0,wire,5);ms+=251;stream(0,wire,n);CHECK(ndelivered==sizeof(app)*2);
 memcpy(replies,app,sizeof(app));nreplies=sizeof(app);out_nak=4;out_timeout=1;unsigned in_before=d[0].endpoint_calls;tick(20);
 CHECK(reply_pos==sizeof(app)&&noutbound==n&&out_calls>=8&&d[0].endpoint_calls>in_before);CHECK(!memcmp(outbound,wire,n));
 }
 /* Full-duplex progress when an outer64-byte payload contains multiple
  * application commands and FPGA blocks RX until its first ACK is read. */
 serial_fixture(0);block_after=22;uint8_t many[64],mw[70];for(unsigned i=0;i<64;i++)many[i]=(uint8_t)i;
 unsigned mn=envelope(mw,many,sizeof(many));stream(0,mw,mn);tick(100);
 CHECK(ndelivered==64&&!memcmp(delivered,many,64)&&reply_pos==22&&noutbound==28);
 serial_fixture(1);CHECK((usb_play_state()&46)==46);const uint8_t h[]={7,3,0,0x40,0,0x40},m[]={9,0x90,64,90};queue(1,h,6);queue(2,m,4);out_nak=100;memset(replies,'P',22);nreplies=22;tick(4);CHECK(nevents==1&&events[0]==0x005a4090&&(touch[0]&(1u<<24))&&out_calls>0);
 unsigned before=nevents;port_status[3]=0;port_change[3]=1;tick(15);CHECK((usb_play_state()&12)==12&&!(usb_play_state()&32)&&nevents==before);CHECK((touch[0]&(1u<<24))!=0);
 /* Frames and staged ACK bytes from the removed UART never leak to reconnect. */
 nreplies=reply_pos=0;out_nak=0;d[3].address=d[3].configured=0;port_status[3]=port_change[3]=1;tick(50);CHECK(usb_play_state()&32);CHECK(noutbound==0);
 serial_fixture(0);speed=0;tick(3);CHECK(!(usb_play_state()&32)&&nevents==0);
 printf("USB_WIFI_PASS checks=%u (CH340 versions, WF1 CRC/split/duplicate/gap, reverse split/NAK/timeout retention, hub fairness/disconnect isolation)\n",checks);return 0;}
#endif
