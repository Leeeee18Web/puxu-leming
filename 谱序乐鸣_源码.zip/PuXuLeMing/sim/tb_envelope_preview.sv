`timescale 1ns/1ps
module tb_envelope_preview;
 reg clk=0;always #10 clk=~clk;
 reg rst=1,tick=0,toggle=0,stop=0;reg[7:0]choices=8'h95;
 wire busy;wire[3:0]gates,triggers;wire[27:0]notes;wire[47:0]gains;wire[11:0]timbres;wire[7:0]captured;
 envelope_preview #(.NOTE_FRAMES(4),.TAIL_FRAMES(6)) dut(clk,rst,tick,toggle,stop,choices,busy,gates,triggers,notes,gains,timbres,captured);
 integer checks=0,starts=0;reg[3:0]heard=0;
 task check(input bit ok,input string msg);begin checks++;if(!ok)$fatal(1,"PREVIEW_FAIL %s",msg);end endtask
 task step;begin @(negedge clk);tick=1;@(negedge clk);tick=0;end endtask
 task press;begin @(negedge clk);toggle=1;@(negedge clk);toggle=0;end endtask
 always @(negedge clk)if(!rst)begin
  heard=heard|triggers;if(triggers!=0)starts++;
  if(busy)check(timbres=={4{3'd4}},"all preview slots use custom piano");
 end
 initial begin
  repeat(3)@(negedge clk);rst=0;press;
  check(busy&&gates==1&&captured==8'h95,"first note and draft snapshot");
  choices=8'hff;repeat(3)step;
  check(captured==8'h95,"editing cannot change playing comparison");
  step;check(gates==2,"second note at exact segment boundary");
  repeat(4)step;check(gates==4,"third note");
  repeat(4)step;check(gates==8,"fourth note");
  repeat(4)step;check(gates==15,"four voice chord");
  repeat(8)step;check(gates==0&&busy&&gains!=0,"tail retains source gains");
  repeat(6)step;check(!busy&&gains==0,"preview finishes and mutes");
  check(heard==15,"all four voices triggered");
  press;check(busy&&captured==8'hff,"new audition uses current candidate");
  press;check(!busy&&gates==0&&gains==0,"second press stops");
  press;stop=1;@(negedge clk);stop=0;check(!busy,"page/panic stop");
  $display("ENVELOPE_PREVIEW_PASS checks=%0d starts=%0d",checks,starts);$finish;
 end
 initial begin #100000;$fatal(1,"PREVIEW_TIMEOUT");end
endmodule
