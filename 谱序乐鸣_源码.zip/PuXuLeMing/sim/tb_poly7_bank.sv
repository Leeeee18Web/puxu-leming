`timescale 1ns/1ps
module tb_poly7_bank;
 `include "play_note_steps.vh"
 reg clk=0;always #10 clk=~clk;reg rst=1,start=0;
 reg[6:0]gates=7'h7f,triggers=0;reg[167:0]steps=0;reg[83:0]gains=0;reg[20:0]tones=0;
 wire[111:0]samples,envelopes;wire[6:0]active;wire busy,err;
 poly25_bank #(.VOICE_COUNT(7)) dut(clk,rst,start,gates,triggers,steps,gains,tones,samples,envelopes,active,busy,err,{12{rst}},1'b1);
 wire[15:0]gold_s[0:6],gold_e[0:6];wire[6:0]gold_a,gold_b,gold_err;
 genvar v;generate for(v=0;v<7;v=v+1)begin:reference
  poly_voice_worker #(.CONTEXTS(1)) private_voice(clk,rst,start,gates[v],triggers[v],steps[v*24+:24],gains[v*12+:12],tones[v*3+:3],gold_s[v],gold_e[v],gold_a[v],gold_b[v],gold_err[v],,,,{3{rst}},1'b0,1'b1);
 end endgenerate
 integer f,c,i,checks=0,max_finish=0;reg[6:0]heard=0;
 initial begin
 if($bits(dut.worker_busy)!=2||$bits(dut.group[0].worker.gates)!=4||$bits(dut.group[1].worker.gates)!=3)$fatal(1,"TWO_WORKER_PARTITION_MISSING");
 repeat(5)@(negedge clk);rst=0;
 for(f=0;f<1300;f=f+1)begin
  triggers=(f==0||f==700)?7'h7f:0;
  for(i=0;i<7;i=i+1)begin
   steps[i*24+:24]=midi_step(48+i)+(f%7);gains[i*12+:12]=(f>=1200&&i==6)?0:1800+i*200;
   tones[i*3+:3]=(i+(f>=700))%4;
  end
  if(f>=1100)gates[6]=0;
  for(c=0;c<1024;c=c+1)begin
   start=c==32;@(negedge clk);
   if(busy&&c>max_finish)max_finish=c;
   if(c==1008)begin
    if(max_finish>=580)$fatal(1,"TWO_WORKER_FRAME_BUDGET max%0d",max_finish);
    if(busy||err||(|gold_b)||(|gold_err))$fatal(1,"POLY7_BANK_DEADLINE frame%0d",f);
    for(i=0;i<7;i=i+1)begin
     if(samples[i*16+:16]!==gold_s[i]||envelopes[i*16+:16]!==gold_e[i]||active[i]!==gold_a[i])$fatal(1,"POLY7_BANK_CONTEXT_FAIL frame%0d voice%0d",f,i);
     if(samples[i*16+:16]!=0)heard[i]=1;
     checks++;
    end
    if(f>1202&&active!==7'h3f)$fatal(1,"POLY7_BANK_INDEPENDENT_MUTE");
   end
  end
 end
 if(heard!==7'h7f)$fatal(1,"POLY7_BANK_SILENT_VOICE");
 $display("POLY7_BANK_PASS checks=%0d 4/3 vs7 private workers mixed4timbres/retune/retrigger/mute finish%0d before580of1024",checks,max_finish);$finish;
 end
 initial begin #40000000;$fatal(1,"POLY7_BANK_TIMEOUT");end
endmodule
