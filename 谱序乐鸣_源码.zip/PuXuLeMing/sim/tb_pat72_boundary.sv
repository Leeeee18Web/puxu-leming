`timescale 1ns/1ps
module tb_pat72_boundary;
 reg clk=0;always #10 clk=~clk;
 reg rst=1,sample_tick=1;
 reg [31:0]touch_event_data=0,usb_event_data=0,gesture_event_data=0,wifi_event_data=0;
 reg touch_event_valid=0,usb_event_valid=0,gesture_event_valid=0,wifi_event_valid=0;
 reg clear_live=0,panic_touch=0,gesture_stop=0,map_apply=0,stop_score=0,mute_enter=0,touch_lost=0;
 reg [3:0]usb_region_up=15;reg pattern_usb_up=1,status_pattern_raw=0,wifi_pattern_override=0;
 reg [1:0]wifi_pattern_mode=1,touch_pattern_mode=1,mode=1;reg pattern_start=0;
 reg [174:0]map_notes=0;reg [6:0]map_input_base=36;reg map_enabled=0,pedal_down=0;
 reg [2:0]timbre_select=0;reg [6:0]active=0;reg [1:0]knob_mode=1;
 pat72_new_boundary dut(.*);
 pat72_old_boundary old(.*);
 integer checks=0,stalls=0,cc120=0,cc123=0,mobile=0,ff=0,note0=0,illegal=0,held=0,resetx=0,resetz=0;
 integer captures[0:3];reg[7:0]counts=0;reg[4:0]states=0;reg [31:0]rng=32'hdab57271;
 wire[3:0]expected_decode={dut.selected_data[7:4]==8||dut.selected_data[7:4]==9,
  !dut.selected_data[15]&&!dut.selected_data[23]&&dut.selected_data[7:4]==9&&dut.selected_data[22:16]!=0,
  !(dut.selected_data[24]&&(dut.selected_data[3:0]==13||dut.selected_data[3:0]==14))&&dut.selected_data[7:4]==11&&
  !dut.selected_data[15]&&!dut.selected_data[23]&&(dut.selected_data[14:8]==120||dut.selected_data[14:8]==123),dut.selected_data[7:0]==8'hff};
 task compare;
 begin
  if({dut.selected_data,dut.selected_source,dut.selected_valid,dut.selected_raw_valid,
      dut.touch_event_ready,dut.usb_event_ready,dut.gesture_event_ready,dut.wifi_event_ready,dut.selected_ready,
      dut.pattern_local_owner,dut.pattern_local_mode,dut.pattern_local_enabled,dut.pattern_local_select,dut.pattern_local_panic,
      dut.pattern_local_ready,dut.pattern_local_valid,dut.pattern_local_all_off,dut.pattern_local_disconnect,dut.pattern_local_base_cancel,dut.pattern_local_cancel}!==
     {old.selected_data,old.selected_source,old.selected_valid,old.selected_raw_valid,
      old.touch_event_ready,old.usb_event_ready,old.gesture_event_ready,old.wifi_event_ready,old.selected_ready,
      old.pattern_local_owner,old.pattern_local_mode,old.pattern_local_enabled,old.pattern_local_select,old.pattern_local_panic,
      old.pattern_local_ready,old.pattern_local_valid,old.pattern_local_all_off,old.pattern_local_disconnect,old.pattern_local_base_cancel,old.pattern_local_cancel})
   $fatal(1,"BOUNDARY_ROOT check%0d",checks);
  if(dut.pattern_event_decode!==expected_decode)$fatal(1,"BOUNDARY_DECODE check%0d actual%h expected%h data%h",checks,dut.pattern_event_decode,expected_decode,dut.selected_data);
  if({dut.event_arbiter.pending_data,dut.event_arbiter.pending_valid,dut.event_arbiter.pending_source}!==
     {old.event_arbiter.pending_data,old.event_arbiter.pending_valid,old.event_arbiter.pending_source})$fatal(1,"BOUNDARY_ARBITER");
  if({dut.pattern_selected,dut.pattern_notes,dut.pattern_selected_gains,dut.pattern_gates,dut.pattern_triggers,
      dut.pattern_sound_notes,dut.pattern_gains,dut.pattern_busy,dut.pattern_count,dut.pattern_full}!==
     {old.pattern_selected,old.pattern_notes,old.pattern_selected_gains,old.pattern_gates,old.pattern_triggers,
      old.pattern_sound_notes,old.pattern_gains,old.pattern_busy,old.pattern_count,old.pattern_full})$fatal(1,"BOUNDARY_PUBLIC check%0d",checks);
  if({dut.patterns.state,dut.patterns.previous_mode,dut.patterns.run_mode,dut.patterns.snapshot_selected,dut.patterns.remaining,
      dut.patterns.snapshot_notes,dut.patterns.snapshot_gains,dut.patterns.scan,dut.patterns.rank,dut.patterns.run_index,
      dut.patterns.best_note,dut.patterns.best_mask,dut.patterns.sorted,dut.patterns.clear_sample,dut.patterns.interval_left,
      dut.patterns.hold_left,dut.patterns.arp_age,dut.patterns.full_left}!==
     {old.patterns.state,old.patterns.previous_mode,old.patterns.run_mode,old.patterns.snapshot_selected,old.patterns.remaining,
      old.patterns.snapshot_notes,old.patterns.snapshot_gains,old.patterns.scan,old.patterns.rank,old.patterns.run_index,
      old.patterns.best_note,old.patterns.best_mask,old.patterns.sorted,old.patterns.clear_sample,old.patterns.interval_left,
      old.patterns.hold_left,old.patterns.arp_age,old.patterns.full_left})$fatal(1,"BOUNDARY_PRIVATE check%0d",checks);
  for(integer q=0;q<7;q++)if(dut.patterns.order[q]!==old.patterns.order[q])$fatal(1,"BOUNDARY_ORDER");
  if({dut.controller_ready,dut.controller_ready_raw,dut.live_gates,dut.live_notes,dut.live_gains,dut.live_triggers,dut.live_timbres,
      dut.ratio,dut.knob,dut.last_note,dut.last_velocity,dut.mod_depth,dut.raw_knob,dut.raw_known,dut.pickup_wait,dut.map_key_seen_valid,dut.map_key_seen_index}!==
     {old.controller_ready,old.controller_ready_raw,old.live_gates,old.live_notes,old.live_gains,old.live_triggers,old.live_timbres,
      old.ratio,old.knob,old.last_note,old.last_velocity,old.mod_depth,old.raw_knob,old.raw_known,old.pickup_wait,old.map_key_seen_valid,old.map_key_seen_index})$fatal(1,"BOUNDARY_VOICE");
  checks++;
 end endtask
 always @(posedge clk)begin
  if(dut.selected_valid&&!dut.selected_ready)stalls++;
  if(dut.pattern_local_all_off&&dut.selected_data[14:8]==120)cc120++;
  if(dut.pattern_local_all_off&&dut.selected_data[14:8]==123)cc123++;
  if(dut.selected_valid&&dut.mobile_scoped_event)mobile++;
  if(dut.pattern_local_disconnect)ff++;
  if(dut.selected_valid&&dut.selected_data[14:8]==0)note0++;
  if(dut.selected_valid&&(dut.selected_data[15]||dut.selected_data[23]))illegal++;
  if(dut.selected_raw_valid)held++;
  if(dut.touch_event_ready&&touch_event_valid)captures[0]++;
  if(dut.usb_event_ready&&usb_event_valid)captures[1]++;
  if(dut.gesture_event_ready&&gesture_event_valid)captures[2]++;
  if(dut.wifi_event_ready&&wifi_event_valid)captures[3]++;
  if(rst===1'bx)resetx++;if(rst===1'bz)resetz++;
  #1;compare();counts[dut.pattern_count]=1;states[dut.patterns.state]=1;
 end
 always @(negedge clk)begin #1;compare();end
 task step;begin @(negedge clk);end endtask
 task quiet;
 begin touch_event_valid=0;usb_event_valid=0;gesture_event_valid=0;wifi_event_valid=0;pattern_start=0;
 clear_live=0;panic_touch=0;gesture_stop=0;map_apply=0;stop_score=0;mute_enter=0;touch_lost=0;end endtask
 task send(input integer source,input[31:0]data);
 begin
  step();quiet();
  case(source)0:begin touch_event_valid=1;touch_event_data=data;end
   1:begin usb_event_valid=1;usb_event_data=data;end
   2:begin gesture_event_valid=1;gesture_event_data=data;end
   3:begin wifi_event_valid=1;wifi_event_data=data;end endcase
  @(posedge clk);
  while(!(source==0?dut.touch_event_ready:source==1?dut.usb_event_ready:source==2?dut.gesture_event_ready:dut.wifi_event_ready))@(posedge clk);
  step();quiet();repeat(4)step();
 end endtask
 integer i,j,m;reg [31:0]data;
 initial begin
  for(i=0;i<4;i++)captures[i]=0;
  for(i=0;i<25;i++)map_notes[i*7+:7]=36+(i*5)%61;
  repeat(3)step();rst=0;repeat(3)step();
  for(m=1;m<=3;m++)begin
   rst=1;step();rst=0;touch_pattern_mode=m;wifi_pattern_mode=m;mode=1;status_pattern_raw=0;wifi_pattern_override=0;repeat(3)step();
   for(j=0;j<(m==2?4:7);j++)send(j%4,(100<<16)|((40+j*4)<<8)|32'h90);
   pattern_start=1;step();pattern_start=0;repeat(100000)step();
   send(0,32'h00642890);send(1,32'h00640090);
  end
  // Real PIPELINED_EVENTS controller stalls on non-note commands.
  send(1,32'h006478b0);send(2,32'h00647bb0);send(3,32'h016478be);send(0,32'h000000ff);
  // Full four-state held payload semantics and unknown priority selection.
  for(i=0;i<32;i++)begin
   data=32'h00643c90;data[i]=1'bx;send(i%4,data);clear_live=1;step();clear_live=0;repeat(2)step();
   data=32'h00643c90;data[i]=1'bz;send(i%4,data);clear_live=1;step();clear_live=0;repeat(2)step();
  end
  step();quiet();touch_event_valid=1'bx;usb_event_valid=1;touch_event_data=32'h00643c80;usb_event_data=32'h00643c90;
  step();quiet();repeat(4)step();
  step();rst=1'bx;step();rst=1'bz;step();rst=1;step();rst=0;repeat(3)step();
  for(i=0;i<300000;i++)begin
   step();quiet();rng=rng*1664525+1013904223;
   rst=(i%2053)<2;sample_tick=rng[0];pattern_start=rng[5:2]==0;
   if(i%71==0)begin touch_pattern_mode=rng[7:6];wifi_pattern_mode=rng[9:8];mode=rng[11:10];end
   status_pattern_raw=rng[12];wifi_pattern_override=rng[13];
   usb_region_up=(i%137>5)?15:0;pattern_usb_up=usb_region_up[0];
   touch_event_valid=rng[15:14]==0;usb_event_valid=rng[17:16]==0;gesture_event_valid=rng[19:18]==0;wifi_event_valid=rng[21:20]==0;
   clear_live=rng[24:20]==0;panic_touch=rng[25:21]==0;gesture_stop=rng[26:22]==0;map_apply=rng[27:23]==0;
   stop_score=rng[28:24]==0;mute_enter=rng[29:25]==0;touch_lost=rng[30:26]==0;
   map_enabled=rng[31];pedal_down=rng[1];timbre_select=rng[4:2]%4;active=rng[11:5];knob_mode=rng[13:12];
   rng=rng*1664525+1013904223;data=rng;
   case(i%12)
    0,1,2,3,4,5:data={7'd0,rng[24],1'b0,rng[22:16],1'b0,rng[14:8],4'h9,rng[3:0]};
    6:data=32'h00003c90;7:data=32'h00640090;
    8:data=i%24==8?32'h00647bb0:32'h006478b0;
    9:data=32'h016478be;10:data=32'h000000ff;11:data=32'h0080ff90;
   endcase
   touch_event_data=data;usb_event_data=data;gesture_event_data=data;wifi_event_data=data;
   // Input jitter between edges while a held payload can be stalled/consumed.
   #3;touch_event_data=data^32'h80000000;usb_event_data=data^32'h40000000;
   #1;compare();
  end
  step();quiet();rst=0;repeat(3)step();
  if(counts!=8'hff||states!=5'h1f||stalls<100||cc120<3||cc123<3||mobile<3||ff<3||note0<3||illegal<3||held<100||resetx<1||resetz<1)
   $fatal(1,"BOUNDARY_COVER counts%h states%h stalls%0d cc120%0d cc123%0d mobile%0d ff%0d",counts,states,stalls,cc120,cc123,mobile,ff);
  for(i=0;i<4;i++)if(captures[i]<100)$fatal(1,"BOUNDARY_SOURCE_COVER source%0d captures%0d",i,captures[i]);
  $display("PAT72_BOUNDARY_PASS checks%0d counts%h states%h stalls%0d cc120%0d cc123%0d mobile%0d disconnect%0d note0%0d illegal%0d held%0d resetX%0d resetZ%0d captures%0d/%0d/%0d/%0d",checks,counts,states,stalls,cc120,cc123,mobile,ff,note0,illegal,held,resetx,resetz,captures[0],captures[1],captures[2],captures[3]);
  $finish;
 end
 initial begin #40000000;$fatal(1,"BOUNDARY_TIMEOUT i%0d j%0d m%0d ready%h valid%h raw%h data%h rst%h checks%0d",i,j,m,dut.selected_ready,{touch_event_valid,usb_event_valid,gesture_event_valid,wifi_event_valid},dut.selected_raw_valid,dut.selected_data,rst,checks);end
endmodule
