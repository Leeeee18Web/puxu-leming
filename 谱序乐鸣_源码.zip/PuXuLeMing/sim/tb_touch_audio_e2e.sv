`timescale 1ns/1ps
// No MIDI injector: actual HOST_TEST HID -> MMIO trace is the ONLY event input.
module tb_touch_audio_e2e;
 reg clk=0;always #10 clk=~clk;
 reg usb_clk=0;always #10.416666667 usb_clk=~usb_clk;
 reg pixel_clk=0;always #9.756097561 pixel_clk=~pixel_clk;
 reg rst=1,pixel_rstn=0,frame_start=0;
 reg [31:0] trace_words[0:95];
 reg [31:0] shadow_status=0,shadow_xy=0,shadow_raw=0,shadow_vidpid=0,shadow_meta=0;
 reg [31:0] source_status=0,source_xy=0,source_raw=0,source_vidpid=0,source_meta=0;
 reg source_toggle=0;
 wire [31:0] touch_status,touch_xy;wire touch_report;
 usb_touch_bridge bridge(.pixel_clk(clk),.rstn(!rst),.source_toggle(source_toggle),
 .source_status(source_status),.source_xy(source_xy),.source_raw(source_raw),
 .source_vidpid(source_vidpid),.source_meta(source_meta),.status_q(touch_status),
 .xy_q(touch_xy),.raw_q(),.vidpid_q(),.meta_q(),.report_valid(touch_report));
 wire touch_good=touch_status[12]&&touch_status[14];reg previous_good=0;
 always @(posedge clk)if(rst)previous_good<=0;else previous_good<=touch_good;
 wire touch_update=touch_report||(previous_good&&!touch_good);
 wire event_valid,event_ready,page,centre,panic;wire[31:0]event_data;wire[6:0]base_note;
 play_touch_controller touch(.clk(clk),.rst(rst),.touch_update(touch_update),
 .touch_valid(touch_good),.touch_down(touch_status[24]&&touch_status[12]),
 .touch_x(touch_xy[15:0]),.touch_y(touch_xy[31:16]),.event_ready(event_ready),
 .event_valid(event_valid),.event_data(event_data),.page(page),.base_note(base_note),.centre(centre),.panic(panic));
 wire sample_tick;wire signed[15:0]pcm;
 wire[6:0]gates,triggers,active,knob,last_note,last_velocity;wire[48:0]notes;
 wire[83:0]gains;wire[18:0]ratio;
 wire[6:0]mod_depth;
 play_voice_control control(.clk(clk),.rst(rst),.sample_tick(sample_tick),
 .event_valid(event_valid),.event_data(event_data),.event_ready(event_ready),
 .panic(panic),.centre(centre),.gates(gates),.notes(notes),.gains(gains),.triggers(triggers),
 .ratio(ratio),.knob(knob),.last_note(last_note),.last_velocity(last_velocity),.mod_depth(mod_depth));
 wire hp_bck,hp_ws,hp_din,i2s_bck,i2s_ws,i2s_sd;
 play_audio audio(.clk(clk),.rst(rst),.gates(gates),.notes(notes),.gains(gains),.triggers(triggers),.ratio(ratio),.mod_depth(mod_depth),
 .sample_tick(sample_tick),.pcm(pcm),.active(active),.hp_bck(hp_bck),.hp_ws(hp_ws),.hp_din(hp_din),
 .i2s_bck(i2s_bck),.i2s_ws(i2s_ws),.i2s_sd(i2s_sd));
 reg[13:0]x=0,y=0;
 wire[116:0]view;
 instrument_snapshot #(.WIDTH(117),.PERIOD(500)) snapshot(.clk(clk),.rstn(!rst),
 .source_data({page,base_note,gates,notes,knob,last_note,last_velocity,touch_status}),
 .pixel_clk(pixel_clk),.pixel_rstn(pixel_rstn),.frame_start(frame_start),.data(view));
 wire[9:0]wave_addr;wire signed[15:0]wave_data;wire wave_valid;
 play_wave_capture capture(.clk(clk),.rst(rst),.sample_tick(sample_tick),.pcm(pcm),
 .pixel_clk(pixel_clk),.pixel_rstn(pixel_rstn),.frame_start(frame_start),.read_addr(wave_addr),
 .read_data(wave_data),.valid(wave_valid));
 wire[23:0]rgb;wire den_out,hsync_out,vsync_out;
 play_panel panel(.pixel_clk(pixel_clk),.rstn(pixel_rstn),.den(1'b1),.hsync(1'b1),.vsync(1'b1),
 .x(x),.y(y),.page(view[116]),.base_note(view[115:109]),.gates(view[108:102]),.notes(view[101:53]),
 .knob(view[52:46]),.last_note(view[45:39]),.last_velocity(view[38:32]),.usb_status(view[31:0]),
 .wave_data(wave_valid?wave_data:16'sd0),.rgb(rgb),.den_out(den_out),.hsync_out(hsync_out),.vsync_out(vsync_out),.wave_addr(wave_addr));
 integer samples=0,accepted=0,nonzero=0,publications=0,checks=0,commits=0;
 reg signed[15:0]stream[0:16383],window[0:1023];reg request_seen=0;
 integer j;integer pcmfd;
 always @(posedge clk)if(!rst)begin
  if(event_valid&&event_ready)begin
   if(!event_data[24])$fatal(1,"forbidden physical MIDI event");accepted=accepted+1;
  end
  if(sample_tick)begin stream[samples]=pcm;samples=samples+1;if(pcm!=0)nonzero=nonzero+1;end
  #1;
  if(capture.request!=request_seen)begin
   request_seen=capture.request;publications=publications+1;
   if(samples<1024)$fatal(1,"premature capture publication");
   for(j=0;j<1024;j=j+1)window[j]=stream[samples-1024+j];
  end
 end
 task check(input bit ok,input string message);
 begin checks=checks+1;if(!ok)$fatal(1,"%s",message);end endtask
 task report(input integer index);
 integer w;reg[31:0]address,value;
 begin
 for(w=0;w<6;w=w+1)begin
  @(negedge usb_clk);address=trace_words[index*12+w*2];value=trace_words[index*12+w*2+1];
  case(address)
   32'h02000200:shadow_status=value;32'h02000204:shadow_xy=value;
   32'h02000208:shadow_raw=value;32'h0200020c:shadow_vidpid=value;32'h02000210:shadow_meta=value;
   32'h02000214:begin
    source_status=shadow_status;source_xy=shadow_xy;source_raw=shadow_raw;
    source_vidpid=shadow_vidpid;source_meta=shadow_meta;source_toggle=~source_toggle;commits=commits+1;
   end
   default:$fatal(1,"trace contains non-touch MMIO address");
  endcase
 end
 repeat(20)@(negedge clk);
 end endtask
 task commit_frame;
 integer f;
 begin for(f=0;f<2;f=f+1)begin
 repeat(1000)@(negedge pixel_clk);frame_start=1;
 @(negedge pixel_clk);frame_start=0;repeat(8)@(negedge pixel_clk);
 $display("FRAME source_note=%0d held_note=%0d visible_note=%0d base=%0d",last_note,snapshot.held[45:39],view[45:39],view[115:109]);
 end end endtask
 task pixel(input integer xx,yy,input[23:0]expected);
 begin @(negedge pixel_clk);x=xx;y=yy;repeat(6)@(negedge pixel_clk);
 check(rgb===expected,"actual panel highlight/label pixel");end endtask
 task measure(output real period);
 integer k,crossings,first,last;reg signed[15:0]prev;
 begin crossings=0;first=0;last=0;prev=0;
 for(k=0;k<3072;k=k+1)begin
  @(negedge clk);while(!sample_tick)@(negedge clk);
  if(k>1024&&pcm>0&&prev<=0)begin if(!crossings)first=k;last=k;crossings=crossings+1;end
  prev=pcm;$fdisplay(pcmfd,"%0d",pcm);
 end
 check(crossings>6,"actual PCM periodic crossings");period=1.0*(last-first)/(crossings-1);
 end endtask
 task verify_window(input[255:0]path);
 integer i,fd;
 begin check(wave_valid,"wave has adopted actual PCM");fd=$fopen(path,"w");
 for(i=0;i<1024;i=i+1)begin
  @(negedge pixel_clk);x=i;y=300;@(posedge pixel_clk);#1;
  check(wave_data===window[i],"capture equals consecutive actual final PCM stream");
  $fdisplay(fd,"%04h",wave_data);
 end
 $fclose(fd);
 end endtask
 real c4,c5;
 initial begin
 $readmemh("sim/touch_mmio_trace.hex",trace_words);pcmfd=$fopen("build/touch_e2e_pcm_samples.txt","w");
 repeat(8)@(negedge clk);rst=0;pixel_rstn=1;
 report(0);check(gates==1&&notes[6:0]==60&&last_note==60&&last_velocity==100,"C4 from real HID trace without MIDI");
 check(mod_depth==0,"touch-only fixture leaves physical MOD neutral");
 measure(c4);check(nonzero>100&&active[0],"touch-alone real PCM audible digital activity");
 commit_frame();check(view[45:39]==60&&view[108:102]==1,"C4 frame snapshot metadata");
 pixel(40,500,24'hf4ce63);pixel(128,174,24'h10151b);verify_window("build/touch_e2e_c4_wave.hex");
 report(1);check(gates==0,"real HID lift releases C4");
 report(2);check(base_note==72,"real HID OCT+ changes virtual range");
 report(3);report(4);check(gates==1&&notes[6:0]==72&&last_note==72,"same touch key now C5, no double transpose");
 measure(c5);check(c4>180&&c4<192&&c5>90&&c5<96,"C4/C5 physical sample periods");
 check(c4/c5>1.98&&c4/c5<2.02,"virtual OCT+ halves actual PCM period");
 commit_frame();check(view[45:39]==72&&view[115:109]==72,"C5 frame snapshot metadata");
 pixel(40,500,24'hf4ce63);pixel(128,174,24'hf4ce63);verify_window("build/touch_e2e_c5_wave.hex");
 report(5);check(gates==0,"real HID second lift releases C5");report(6);report(7);
 check(page==1&&accepted==4&&commits==8,"all48 real MMIO pairs /8commits, only4virtual on/off events");
 commit_frame();check(view[116]&&view[45:39]==72,"wave page preserves last note/audio state");
 check(publications>=2,"both actual PCM banks published");
 $fclose(pcmfd);
 $display("PASS touch_audio_e2e checks=%0d MMIOpairs=48 commits=%0d events=%0d MIDIevents=0 samples=%0d nonzero=%0d exactPCM=2048 C4period=%f C5period=%f ratio=%f",checks,commits,accepted,samples,nonzero,c4,c5,c4/c5);$finish;
 end
 initial begin #500000000;$fatal(1,"endtoend timeout");end
endmodule
