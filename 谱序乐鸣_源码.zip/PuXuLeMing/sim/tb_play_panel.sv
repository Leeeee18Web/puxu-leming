`timescale 1ns/1ps
module tb_play_panel;
 reg pixel_clk=0;always #5 pixel_clk=~pixel_clk;
 reg rstn=0,den=1,hsync=1,vsync=1,page=0;
 reg[13:0] x=0,y=0;reg[6:0]base_note=60,gates=0,knob=64,last_note=60,last_velocity=100;
 reg[48:0]notes=0;reg[31:0]usb_status=0;reg signed[15:0] wave_data=0;
 wire[23:0]rgb;wire den_out,hsync_out,vsync_out;wire[9:0]wave_addr;
 play_panel dut(.*);
 integer checks=0;
 task pixel(input integer xx,yy,input[23:0] expected);
 begin @(negedge pixel_clk);x=xx;y=yy;repeat(6) @(negedge pixel_clk);
 checks=checks+1;if(rgb!==expected) $fatal(1,"pixel %d,%d got%h expected%h",xx,yy,rgb,expected);
 if(!den_out||!hsync_out||!vsync_out) $fatal(1,"sync latency");end endtask
 initial begin
 repeat(6) @(negedge pixel_clk);rstn=1;
 pixel(40,500,24'hdce3e8);pixel(96,300,24'h17202a);pixel(96,450,24'h36434e);
 notes[6:0]=61;gates=1;pixel(96,300,24'hf4ce63);
 pixel(40,500,24'hdce3e8);notes[6:0]=60;pixel(40,500,24'hf4ce63);
 // C4 and upper C6 label numeric pixels. Octave changes label to C3/C5.
 pixel(70,534,24'h17202a); // digit 4 row 0 column3
 pixel(68,534,24'hf4ce63); // digit 4 col2 is background
 base_note=48;pixel(68,534,24'h17202a); // digit 3 col2 is ink
 page=1;gates=1;notes[6:0]=60;
 pixel(400,420,24'hf4ce63);pixel(400,430,24'h141c25);
 wave_data=16'sd2560;pixel(400,410,24'hf4ce63);pixel(400,420,24'h46515b);
 if(wave_addr!=400) $fatal(1,"sample addr");
 last_note=0;pixel(116,180,24'hf4ce63); // actual C-1: '-' row3 col0
 pixel(132,174,24'hf4ce63); // following '1' row0 col2
 pixel(32,580,24'h9cabb8); // footer U row0 col0 must not be truncated
 usb_status=1;pixel(970,582,24'h36434e); // nonzero NO_DEVICE must stay dark
 usb_status=32'h1000;pixel(970,582,24'h36434e); // configured, no valid report
 usb_status=32'h5000;pixel(970,582,24'hf4ce63); // configured AND valid
 den=0;repeat(6) @(negedge pixel_clk);if(rgb!=0||den_out) $fatal(1,"blanking");
 $display("PASS panel %0d pixels, physical note highlights, octave labels, real PCM displacement, sync",checks);$finish;
 end
endmodule
