`timescale 1ns/1ps
module tb_p8_wifi_top;
 reg clk=0,rstn=0,rx=1;always #10 clk=~clk;
 tri dp,dm;wire tx,bck,ws,sd,ib,iw,idata;
 hub_play_top dut(.clk(clk),.rstn(rstn),.key1_n(1'b1),.key2_n(1'b1),.uart_rx(rx),.uart_tx(tx),
  .usb_dp(dp),.usb_dm(dm),.hp_bck(bck),.hp_ws(ws),.hp_din(sd),.i2s_bck(ib),.i2s_ws(iw),.i2s_sd(idata),
  .pa_en(),.led_o(),.tmds_clk_p_0(),.tmds_clk_n_0(),.tmds_d_p_0(),.tmds_d_n_0());
 defparam dut.wifi_control.WATCHDOG_MS=20;
 integer checks=0,pcm_nz=0,i2s_nz=0,pt_nz=0,wifi_events=0,replies=0,ti=0,k;
 reg[7:0]reply[0:21];reg[7:0]last_result=0;reg[15:0]last_seq=0,reply_crc=16'hffff;
 wire[15:0]left,right;wire audio_valid;
 i2s_rx16 decoder(.clk(clk),.rst(dut.rst),.bck(ib),.ws(iw),.sd(idata),.pcm_l(left),.pcm_r(right),.frame_valid(audio_valid));
 reg[15:0]pt_shift=0;integer pt_bits=0;
 always @(posedge bck)if(!dut.rst)begin pt_shift={pt_shift[14:0],sd};pt_bits++;
  if(pt_bits==16)begin if(pt_shift!=0)pt_nz++;pt_bits=0;end end
 always @(posedge clk)if(!dut.rst)begin
  if(dut.sample_tick&&dut.pcm!=0)pcm_nz++;
  if(audio_valid&&(left!=0||right!=0))i2s_nz++;
  if(dut.wifi_event_valid&&dut.wifi_event_ready)wifi_events++;
 end
 task check(input bit ok,input string label);begin checks++;if(!ok)$fatal(1,"WIFI_TOP_FAIL %s",label);end endtask
 function automatic[15:0]crc(input[15:0]c,input[7:0]b);reg[15:0]v;integer j;
 begin v=c^{b,8'd0};for(j=0;j<8;j++)v=v[15]?(v<<1)^16'h1021:v<<1;crc=v;end endfunction
 always @(posedge dut.usb_clk)if(dut.soc.wifi_tx_valid&&dut.soc.wifi_tx_ready)begin
  reply[ti]=dut.soc.wifi_tx_data;
  if(ti>=2&&ti<=19)reply_crc=crc(reply_crc,dut.soc.wifi_tx_data);
  if(ti==21)begin
   check(reply[0]=="P"&&reply[1]=="W"&&reply[2]==1,"reply traverses both real CDC domains");
   check({reply[21],reply[20]}==reply_crc,"reply CRC after real reverse CDC");
   last_seq={reply[5],reply[4]};last_result=reply[8];replies++;ti=0;reply_crc=16'hffff;
  end else ti++;
 end
 task command(input[7:0]op,input[15:0]seq,input[31:0]a,b,c,input[7:0]expect_result);
 reg[7:0]p[0:21];reg[15:0]v;integer j,target,timeout;begin
  p[0]="P";p[1]="W";p[2]=1;p[3]=op;p[4]=seq[7:0];p[5]=seq[15:8];p[6]=8'h34;p[7]=8'h12;
  for(j=0;j<4;j++)begin p[8+j]=a>>(8*j);p[12+j]=b>>(8*j);p[16+j]=c>>(8*j);end
  v=16'hffff;for(j=2;j<20;j++)v=crc(v,p[j]);p[20]=v[7:0];p[21]=v[15:8];
  target=replies+1;for(j=0;j<22;j++)dut.soc.wifi_byte(p[j]);
  timeout=0;while(replies<target&&timeout<20000)begin @(negedge clk);timeout++;end
  check(replies==target&&last_seq==seq&&last_result==expect_result,"real top command/ACK");
  repeat(40)@(negedge clk);
 end endtask
 task serial_byte(input[7:0]b);integer j;begin
  @(negedge clk);rx=0;repeat(434)@(negedge clk);
  for(j=0;j<8;j++)begin rx=b[j];repeat(434)@(negedge clk);end
  rx=1;repeat(434)@(negedge clk);
 end endtask
 task tap(input integer x,y);begin
  dut.soc.hid_report(x,y,0,1);repeat(3000)@(negedge clk);
  dut.soc.hid_report(x,y,1,1);repeat(3000)@(negedge clk);
  dut.soc.hid_report(x,y,0,1);repeat(3000)@(negedge clk);
 end endtask
 task gesture(input[15:0]seq,input[7:0]note);reg[7:0]p[0:17];reg[15:0]v;integer j;begin
  p[0]="G";p[1]="S";p[2]=2;p[3]=8'h26;p[4]=seq[7:0];p[5]=seq[15:8];p[6]=8;p[7]=0;
  p[8]=1;p[9]=note;p[10]=note==0?0:100;p[11]=0;p[12]="P";p[13]="8";p[14]="G";p[15]="1";
  v=16'hffff;for(j=2;j<16;j++)v=crc(v,p[j]);p[16]=v[7:0];p[17]=v[15:8];
  for(j=0;j<18;j++)serial_byte(p[j]);repeat(400)@(negedge clk);
 end endtask
 function automatic[15:0]score_crc(input[15:0]start,input[31:0]t,data);reg[15:0]v;integer j;
 begin v=start;for(j=0;j<4;j++)v=crc(v,t>>(j*8));for(j=0;j<4;j++)v=crc(v,data>>(j*8));score_crc=v;end endfunction
 reg[15:0]sc;integer ev_before;
 initial begin
  repeat(10)@(negedge clk);rstn=1;repeat(1000)@(negedge clk);
  check(dut.page==0&&dut.mode==0,"original P8 startup preserved");
  command(0,1,32'h50385731,0,0,0);
  command(1,2,32'h91,32'h3c64,0,0); // C4 E4 G4
  check($countones(dut.live_gates)==3,"phone chord owns three voices");
  repeat(150000)@(negedge clk);
  check(pcm_nz>30&&i2s_nz>30&&pt_nz>30,"actual HDL PCM and decoded I2S/PT8211 nonzero");
  dut.soc.midi_event(32'h00643c90);repeat(400)@(negedge clk);
  check($countones(dut.live_gates)==4,"physical and phone same pitch separate owners");
  gesture(1,1);check($countones(dut.live_gates)==5,"phone USB and computer gesture coexist");
  command(2,3,0,0,0,0);
  check($countones(dut.live_gates)==2,"phone release preserves USB and gesture");
  gesture(2,0);check($countones(dut.live_gates)==1,"gesture still uses original UART");
  command(1,4,1,32'h3c64,0,0);
  repeat(1010000)@(negedge clk);
  check($countones(dut.live_gates)==1,"phone lease timeout preserves physical same-pitch note");
  dut.soc.midi_event(32'h00003c80);repeat(400)@(negedge clk);check(dut.live_gates==0,"physical noteoff remains effective");
  command(4,5,2,0,0,0);
  command(5,6,0,0,32'h00016440,0);
  command(5,7,1,128,32'h00000040,0);
  sc=score_crc(16'hffff,0,32'h00016440);sc=score_crc(sc,128,32'h00000040);
  command(6,8,sc,0,0,0);check(dut.wifi_score_count==2,"score committed through real top");
  ev_before=wifi_events;command(7,9,0,0,0,0);
  repeat(150000)@(negedge clk);
  check(!dut.wifi_score_playing&&dut.live_gates==0&&wifi_events>=ev_before+3,"sample-clocked score ends and releases");
  check(dut.last_note==64,"uploaded E4 reaches real seven-voice controller");
  tap(300,280);tap(656,96);tap(620,200);
  check(dut.mode==1&&dut.pattern_mode==2,"unchanged physical chord mode");
  dut.soc.midi_event(32'h00643c90);dut.soc.midi_event(32'h00003c80);
  tap(928,200);repeat(5000)@(negedge clk);
  check(dut.pattern_busy&&dut.pattern_gates!=0,"physical chord running before phone release");
  command(2,10,0,0,0,0);
  check(dut.pattern_busy&&dut.pattern_gates!=0,"phone release preserves physical pattern");
  command(8,11,0,0,0,0);
  check(dut.pattern_busy&&dut.pattern_gates!=0,"phone score stop preserves physical pattern");
  $display("P8_WIFI_TOP_PASS checks=%0d wifi_events=%0d replies=%0d PCM=%0d I2S=%0d PT=%0d",checks,wifi_events,replies,pcm_nz,i2s_nz,pt_nz);$finish;
 end
 initial begin #80000000;$fatal(1,"WiFi top deadline");end
endmodule
