`timescale 1ns/1ps
module poly_audio_static_case #(parameter N=7)(output reg done=0);
 reg clk=0;always #10 clk=~clk;reg rst=1,map_apply=0;
 reg[N-1:0]gates=0,triggers=0;reg[N*7-1:0]notes=0;reg[N*12-1:0]gains=0;reg[N*3-1:0]tones=0;reg[18:0]ratio=262144;
 wire ticka,tickb,posa,posb,hba,hbb,hwa,hwb,hda,hdb,iba,ibb,iwa,iwb,ida,idb,erra,errb,clipa,clipb;
 wire signed[15:0]pcma,pcmb;wire[N-1:0]activea,activeb;wire[N*24-1:0]stepa,stepb;wire[N*16-1:0]enva,envb;
 poly25_audio #(.VOICE_COUNT(N)) dut(.clk(clk),.rst(rst),.gates(gates),.triggers(triggers),.notes(notes),.gains(gains),.timbres(tones),.ratio(ratio),.mod_depth(7'd0),.synth_config(32'd0),
 .sample_tick(ticka),.pcm(pcma),.pcm_positive(posa),.hp_bck(hba),.hp_ws(hwa),.hp_din(hda),.i2s_bck(iba),.i2s_ws(iwa),.i2s_sd(ida),.active(activea),.monitor_steps(stepa),.monitor_envelopes(enva),.deadline_error(erra),.clip_active(clipa),.map_apply(map_apply),.model_reset({12{rst}}),.control_resetn_early(1'b1));
 poly_audio_before_static #(.VOICE_COUNT(N)) reference(.clk(clk),.rst(rst),.gates(gates),.triggers(triggers),.notes(notes),.gains(gains),.timbres(tones),.ratio(ratio),.mod_depth(7'd0),.synth_config(32'd0),
 .sample_tick(tickb),.pcm(pcmb),.pcm_positive(posb),.hp_bck(hbb),.hp_ws(hwb),.hp_din(hdb),.i2s_bck(ibb),.i2s_ws(iwb),.i2s_sd(idb),.active(activeb),.monitor_steps(stepb),.monitor_envelopes(envb),.deadline_error(errb),.clip_active(clipb),.map_apply(map_apply),.model_reset({12{rst}}));
 integer checks=0,frames=0,writes=0,v;reg[127:0]notes_seen=0;
 initial begin
  repeat(5)@(negedge clk);rst=0;
  while(frames<128)begin
   @(negedge clk);
   if(ticka)begin
    for(v=0;v<N;v++)begin
     notes[v*7+:7]=(frames+v*23)%128;notes_seen[(frames+v*23)%128]=1;
     gains[v*12+:12]=(frames%17==0)?0:1000+(v*53)%3000;tones[v*3+:3]=(frames/16+v)%4;
    end
    gates=(frames%9==0)?0:{N{1'b1}};triggers=(frames%7==0)?{N{1'b1}}:0;
    ratio=frames%3==0?174763:frames%3==1?262144:393216;map_apply=frames==69;frames++;
   end
   #1;
   if({ticka,pcma,posa,hba,hwa,hda,iba,iwa,ida,activea,stepa,enva,erra,clipa}!=={tickb,pcmb,posb,hbb,hwb,hdb,ibb,iwb,idb,activeb,stepb,envb,errb,clipb})$fatal(1,"AUDIO_STATIC_EQ N%0d frame%0d index%0d",N,frames,dut.index);
   if(dut.index>=2&&dut.index<=N+1)writes++;
   checks++;
  end
  if(notes_seen!=={128{1'b1}}||writes<120*N)$fatal(1,"AUDIO_STATIC_COVERAGE N%0d writes%0d",N,writes);
  $display("POLY_AUDIO_STATIC_EQ_PASS N%0d checks%0d frames%0d writes%0d all128notes/3ratios/all4tones/map/gate/trigger actual audio serial and monitors cycle-exact",N,checks,frames,writes);done=1;
 end
endmodule
module tb_poly_audio_static_equiv;
 wire[2:0]done;poly_audio_static_case #(.N(4)) n4(done[0]);poly_audio_static_case #(.N(7)) n7(done[1]);poly_audio_static_case #(.N(25)) n25(done[2]);
 initial begin wait(&done);$finish;end
endmodule
