`timescale 1ns/1ps
module tb_regional68_equiv;
 reg clk=0,rstn=0,key1_n=1;always #10 clk=~clk;
 tri dp,dm,odp,odm;
 hub_play_top dut(.clk(clk),.rstn(rstn),.key1_n(key1_n),.key2_n(1'b1),.uart_rx(1'b1),.usb_dp(dp),.usb_dm(dm),.uart_tx(),.hp_bck(),.hp_ws(),.hp_din(),.pa_en(),.i2s_bck(),.i2s_ws(),.i2s_sd(),.led_o(),.tmds_clk_p_0(),.tmds_clk_n_0(),.tmds_d_p_0(),.tmds_d_n_0());
 hub_before_regional68 old(.clk(clk),.rstn(rstn),.key1_n(key1_n),.key2_n(1'b1),.uart_rx(1'b1),.usb_dp(odp),.usb_dm(odm),.uart_tx(),.hp_bck(),.hp_ws(),.hp_din(),.pa_en(),.i2s_bck(),.i2s_ws(),.i2s_sd(),.led_o(),.tmds_clk_p_0(),.tmds_clk_n_0(),.tmds_d_p_0(),.tmds_d_n_0());
 defparam dut.status_bridge.PERIOD=10,old.status_bridge.PERIOD=10;
 defparam dut.pedal_button.TICKS=4,old.pedal_button.TICKS=4;
 defparam dut.patterns.HOLD_SAMPLES=8,old.patterns.HOLD_SAMPLES=8;
 integer checks=0,usb_down=0,changes=0,played=0,selected=0,i;
 reg previous_up=0;
 always @(negedge clk)begin #1;
  if(dut.usb_up_sync!==old.usb_up_sync)$fatal(1,"USB_SYNC_CHANGED");
  if(dut.usb_region_up!=={4{old.usb_up_sync[1]}})$fatal(1,"REGION_FINAL_STAGE_EPOCH_CHANGED");
  if({dut.panic_all,dut.touch_good,dut.touch_state,dut.piano_ready,dut.touch_ready,dut.esp_ready,dut.esp_ready_patterns,dut.pattern_mode,dut.pattern_select,dut.selected_valid,dut.selected_ready,dut.selected_data,dut.pattern_cancel,dut.pattern_selected,dut.pattern_notes,dut.pattern_selected_gains,dut.pattern_count,dut.pattern_gates,dut.pattern_triggers,dut.pedal_pattern_gates,dut.pedal_pattern_triggers,dut.pedal_pattern_notes,dut.pedal_pattern_gains,dut.pattern_timbres,dut.live_gates,dut.live_notes,dut.live_gains,dut.gates,dut.notes,dut.gains,dut.recording,dut.replaying,dut.record_count,dut.pcm,dut.hp_bck,dut.hp_ws,dut.hp_din,dut.i2s_bck,dut.i2s_ws,dut.i2s_sd}!==
     {old.panic_all,old.touch_good,old.touch_state,old.piano_ready,old.touch_ready,old.esp_ready,old.esp_ready_patterns,old.pattern_mode,old.pattern_select,old.selected_valid,old.selected_ready,old.selected_data,old.pattern_cancel,old.pattern_selected,old.pattern_notes,old.pattern_selected_gains,old.pattern_count,old.pattern_gates,old.pattern_triggers,old.pedal_pattern_gates,old.pedal_pattern_triggers,old.pedal_pattern_notes,old.pedal_pattern_gains,old.pattern_timbres,old.live_gates,old.live_notes,old.live_gains,old.gates,old.notes,old.gains,old.recording,old.replaying,old.record_count,old.pcm,old.hp_bck,old.hp_ws,old.hp_din,old.i2s_bck,old.i2s_ws,old.i2s_sd})$fatal(1,"REGIONAL68_ROOT_PUBLIC_MISMATCH cycle%0d",checks);
  checks++;if(!dut.usb_up_sync[1])usb_down++;
  if(previous_up!=dut.usb_up_sync[1])changes++;
  previous_up=dut.usb_up_sync[1];
  if(dut.perform_gates!=0)played++;
  if(dut.pattern_selected!=0)selected++;
 end
 task clocks(input integer n);repeat(n)@(negedge clk);endtask
 task touch(input integer x,y,input bit down);begin fork dut.soc.hid_report(x,y,down,1);old.soc.hid_report(x,y,down,1);join clocks(40);end endtask
 task tap(input integer x,y);begin touch(x,y,0);touch(x,y,1);touch(x,y,0);end endtask
 task ev(input[31:0]w);begin fork dut.soc.midi_event(w);old.soc.midi_event(w);join clocks(100);end endtask
 task frames(input integer n);repeat(n)begin @(posedge dut.sample_tick);@(negedge clk);end endtask
 initial begin
  clocks(20);rstn=1;clocks(2000);
  dut.soc.ptest_debug[255:224]=32'h2c;old.soc.ptest_debug[255:224]=32'h2c;clocks(100);
  tap(300,280);tap(650,96);tap(600,195);
  touch(64,500,1);touch(64,500,0);touch(200,500,1);touch(200,500,0);
  key1_n=0;clocks(100);tap(900,195);frames(20);
  if(dut.perform_gates==0||dut.pattern_count!=2)$fatal(1,"REGION_STIMULUS_NO_HELD_PATTERN");
  ev(32'h000000ff);frames(3);tap(900,195);frames(20);
  for(i=0;i<12;i++)begin
   @(negedge clk);#2;dut.usb_pll.lock=0;old.usb_pll.lock=0;clocks(23+i);
   @(negedge clk);#2;dut.usb_pll.lock=1;old.usb_pll.lock=1;clocks(120);
   dut.soc.ptest_debug[255:224]=(i%2)?32'h0c:32'h2c;old.soc.ptest_debug[255:224]=(i%2)?32'h0c:32'h2c;
   key1_n=i[0];clocks(111);ev((32'd100<<16)|((32'd60+i)<<8)|32'h90);
  end
  rstn=0;clocks(17);rstn=1;clocks(1500);
  tap(300,280);tap(650,96);ev(32'h00643c90);frames(50);ev(32'h00003c80);frames(3);
  if(usb_down<200||changes<20||played<1000||selected<1000)$fatal(1,"REGION_COVERAGE_MISSING");
  $display("REGIONAL68_ROOT_EQ_PASS checks%0d usbdown%0d transitions%0d sounding%0d selected%0d allControlsAndPCMSerialSameCycle",checks,usb_down,changes,played,selected);$finish;
 end
 initial begin #20000000;$fatal(1,"REGION_TIMEOUT");end
endmodule
