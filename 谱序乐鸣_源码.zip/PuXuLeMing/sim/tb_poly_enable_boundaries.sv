`timescale 1ns/1ps
module poly_enable_boundary #(parameter PROBE=0);
 reg clk=0;always #10 clk=~clk;reg rst=1,start=0;
 poly_voice_worker #(.CONTEXTS(1)) dut(.clk(clk),.rst(rst),.start(start),.gates(1'b1),.triggers(1'b1),.steps(24'd45000),.gains(12'd2400),.timbres(3'd1),.samples(),.envelopes(),.active(),.busy(),.deadline_error(),.out_valid(),.out_index(),.out_sample(),.model_reset({3{rst}}),.control_resetn_early(1'b1));
 reg want;reg[4:0]want_shift;
 initial begin
  repeat(3)@(negedge clk);rst=0;start=1;@(negedge clk);start=0;
  if(PROBE==0)begin
   wait(dut.phase==114&&dut.core_enable&&dut.string_initializing&&dut.string_phase==5);#1;want=dut.core_enable;
   force dut.strings.state=6'd10;#1;
   if(dut.core_enable!==want)$fatal(1,"REGIONAL_ENABLE_REGISTER_BOUNDARY_MISSING");
   $display("REGIONAL_ENABLE_BOUNDARY_PASS live parentFSM cannot reach current child CE midclock");
  end else if(PROBE==1)begin
   wait(dut.phase==20);#1;want=dut.strings.local_reset;
   if(want!==0)$fatal(1,"GAIN_ZERO_BOUNDARY_EMPTY");
   force dut.gain=12'd0;#1;
   if(dut.strings.local_reset!==want)$fatal(1,"GAIN_ZERO_REGISTER_BOUNDARY_MISSING");
   $display("GAIN_ZERO_BOUNDARY_PASS raw gain cannot reach body reset/DSP control midclock");
  end else begin
   wait(dut.phase==20);#1;want_shift=dut.strings.b.dc_shift;
   if(want_shift<=3)$fatal(1,"PICKUP_SHIFT_BOUNDARY_EMPTY");
   force dut.strings.step_snapshot=24'd4194304;#1;
   if(dut.strings.b.dc_shift!==want_shift)$fatal(1,"PICKUP_SHIFT_REGISTER_BOUNDARY_MISSING");
   $display("PICKUP_SHIFT_BOUNDARY_PASS raw step threshold cannot reach pickup shift midclock");
  end
  $finish;
 end
 initial begin #100000;$fatal(1,"ENABLE_BOUNDARY_TIMEOUT");end
endmodule
module tb_poly_enable_boundary;poly_enable_boundary #(.PROBE(0)) test();endmodule
module tb_poly_gain_zero_boundary;poly_enable_boundary #(.PROBE(1)) test();endmodule
module tb_poly_pickup_shift_boundary;poly_enable_boundary #(.PROBE(2)) test();endmodule
