`timescale 1ns/1ps
module tb_final_snapshot;
 reg clk=0,pixel_clk=0,rstn=0,pixel_rstn=0,frame_start=0;
 always #10 clk=~clk;
 always #13 pixel_clk=~pixel_clk;
 reg[392:0] source=1;
 wire[392:0] actual,reference;
 final_snapshot #(.PERIOD(7),.WIDTH(393)) dut(.clk(clk),.rstn(rstn),.source_data(source),
  .pixel_clk(pixel_clk),.pixel_rstn(pixel_rstn),.frame_start(frame_start),.data(actual));
 instrument_snapshot #(.PERIOD(7),.WIDTH(393)) mature(.clk(clk),.rstn(rstn),.source_data(source),
  .pixel_clk(pixel_clk),.pixel_rstn(pixel_rstn),.frame_start(frame_start),.data(reference));
 integer phase=0,checks=0,publications=0;
 reg[392:0] previous=0;
 always @(negedge clk)source<={source[360:0],source[392:361]^{32{source[392]^source[221]^source[7]}}};
 always @(negedge pixel_clk)begin
  if(actual!==reference)$fatal(1,"FINAL_SNAPSHOT_FAIL mature atomic publication changed");
  if(pixel_rstn)begin
   if(actual!=previous)publications++;
   if(actual!=previous&&!frame_start)$fatal(1,"FINAL_SNAPSHOT_FAIL unacknowledged publication");
   checks++;
  end
  previous=actual;phase=phase+1;frame_start=phase%17==0;
 end
 initial begin
  repeat(10)@(negedge clk);rstn=1;pixel_rstn=1;
  repeat(10000)@(negedge clk);
  rstn=0;pixel_rstn=0;repeat(8)@(negedge clk);rstn=1;pixel_rstn=1;
  repeat(10000)@(negedge clk);
  if(publications<100)$fatal(1,"FINAL_SNAPSHOT_FAIL coverage");
  $display("FINAL_SNAPSHOT_PASS checks=%0d publications=%0d",checks,publications);$finish;
 end
endmodule
