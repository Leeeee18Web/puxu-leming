`timescale 1ns/1ps
module phys_strings_edges;
reg clk=0;always #10 clk=~clk;
reg rst=1,tick=0,gate=0,trigger=0;reg[23:0]step=2809;
reg[11:0]gain=4095;reg[2:0]timbre=1;
wire signed[15:0]sample;wire[15:0]envelope;wire active,busy,deadline_error;
phys_string_voice dut(clk,rst,tick,gate,trigger,step,gain,timbre,sample,envelope,active,busy,deadline_error);
integer t,i,j,fd,debugfd,peak,latency,maxlat=0;
reg[5:0] body_seen=0;integer busy_hits=0;reg signed[31:0]body_sum;
task frame;
begin
 @(negedge clk);tick=1;@(negedge clk);tick=0;
 latency=1;
 repeat(1022)begin @(negedge clk);if(busy)latency=latency+1;end
 if(latency>maxlat)maxlat=latency;
 if(deadline_error)$fatal(1,"FAIL edge deadline");
 if(^sample===1'bx)$fatal(1,"FAIL unknown output");
end endtask
task retrigger_while_busy(input integer target);
 integer cycles;
 begin
  @(negedge clk);tick=1;@(negedge clk);tick=0;cycles=0;
  while(!(dut.state==target&&busy&&!dut.initializing&&
          (target==5?dut.b0:dut.body_busy))&&cycles<160)begin
   @(negedge clk);cycles=cycles+1;
  end
  if(cycles>=160)$fatal(1,"FAIL busy retrigger state%0d not reached",target);
  busy_hits=busy_hits+1;trigger=1;@(negedge clk);trigger=0;
  if(dut.state!==1||!dut.initializing||!dut.init_pending||sample!==0)
   $fatal(1,"FAIL busy trigger did not abort/rebuild state%0d",target);
  repeat(10000)@(negedge clk);
  if(busy)$fatal(1,"FAIL busy retrigger init deadline");
 end
endtask
task onset;
begin gate=1;trigger=1;@(negedge clk);trigger=0;
 repeat(10000)@(negedge clk);
 if(busy)$fatal(1,"FAIL init >200us");end endtask
initial begin
 repeat(4)@(negedge clk);rst=0;
 for(t=1;t<=2;t=t+1)begin
 timbre=t;step=2809;onset();fd=$fopen($sformatf("strings_low_%0d.txt",t),"w");
 for(i=0;i<24000;i=i+1)begin if(i==10000)step=1874;frame();$fdisplay(fd,"%0d",sample);end
 $fclose(fd);
 step=6456432;onset();fd=$fopen($sformatf("strings_high_%0d.txt",t),"w");
 debugfd=$fopen($sformatf("strings_high_debug_%0d.txt",t),"w");
 peak=0;body_seen=0;
 for(i=0;i<3000;i=i+1)begin
  frame();$fdisplay(fd,"%0d",sample);
  $fdisplay(debugfd,"%0d %0d %0d %0d %0d %0d %0d %0d %0d",dut.mixed,
   dut.body.position[0],dut.body.position[1],dut.body.position[2],
   dut.body.position[3],dut.body.position[4],dut.body.position[5],dut.body_radiation,dut.out_q8);
  body_sum=0;
  for(j=0;j<6;j=j+1)begin
   if(dut.body.position[j]!=0)body_seen[j]=1;
   body_sum=body_sum+$signed(dut.body.position[j]);
  end
  if(body_sum!==dut.body_radiation)$fatal(1,"FAIL six-mode radiation sum");
  if(sample>peak)peak=sample;
 end
 if(body_seen!==6'b111111)$fatal(1,"FAIL six-mode coverage %b",body_seen);
 if(peak<10)$fatal(1,"FAIL high range silent");$fclose(fd);$fclose(debugfd);
 // A trigger exactly during another computation must abort/rebuild locally.
 step=151197;onset();for(i=0;i<500;i=i+1)frame();
 retrigger_while_busy(5);for(i=0;i<50;i=i+1)frame();
 retrigger_while_busy(12);
 peak=0;for(i=0;i<3000;i=i+1)begin frame();if(sample>peak)peak=sample;end
 if(peak<20)$fatal(1,"FAIL retrigger");
 gain=0;@(negedge clk);if(sample!==0||active!==0||envelope!==0)$fatal(1,"FAIL immediate gain zero");
 gain=1200;step=151197;onset();fd=$fopen($sformatf("strings_soft_%0d.txt",t),"w");
 for(i=0;i<6000;i=i+1)begin frame();$fdisplay(fd,"%0d",sample);end $fclose(fd);
 gain=4095;
 end
 if(busy_hits!=4)$fatal(1,"FAIL busy retrigger coverage %0d",busy_hits);
 $display("PASS phys_strings_edges six-mode radiation/low/high/fullbend/busy-retrigger4/shorttrigger/soft maxframebusy=%0d",maxlat);$finish;
end
endmodule
