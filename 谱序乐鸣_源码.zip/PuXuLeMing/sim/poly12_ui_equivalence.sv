`timescale 1ns/1ps
module poly12_ui_equivalence_case(output reg done=0);
 reg pixel_clk=0;always #9.756 pixel_clk=~pixel_clk;
 reg clk=0;always #10 clk=~clk;
 reg rstn=0,pedal_down=0;wire den,hsync,vsync;
 wire[13:0]x,y;reg[2:0]page=0;reg[1:0]mode=0;integer frames=0;
 final_video_timing_ctrl #(.video_hlength(1344),.video_vlength(635),.video_hsync_len(20),.video_hbp_len(140),.video_h_visible(1024),.video_vsync_len(3),.video_vbp_len(20),.video_v_visible(600)) timing(.pixel_clock(pixel_clk),.rstn(rstn),.ext_sync(1'b0),.timing_h_pos(),.timing_v_pos(),.pixel_x(x),.pixel_y(y),.video_vsync(vsync),.video_hsync(hsync),.video_den(den),.video_line_start(),.history_addr());
 reg playing=1,muted=0,note_valid=1;reg[6:0]next_note=64,base_note=60;
 reg[3:0]gates=9;reg[27:0]notes=0;reg[47:0]gains=0;
 wire[24:0]keyboard_held=25'h1001;
 wire[374:0]keyboard_labels=375'h5422a63d487688e501b9e35386668c4c16962b2852489c8128e1d1836286440b8615082608440067e0af811e81bc02;
 reg[7:0]envelope_choices=8'h95;reg preview_busy=0;
 reg[6:0]home_gates=7'h55;reg[83:0]home_gains=0;
 reg piano_ready=1,touch_ready=1,recording=1,replaying=0,record_full=0;
 reg[12:0]record_count=321;reg[15:0]record_milliseconds=4321;
 reg[2:0]timbre=1;reg timbre_open=0,xy_overview=0;reg[31:0]synth_config=32'h123456;
 reg[6:0]knob=64,raw_knob=93;reg raw_known=1,pickup_wait=0;reg[1:0]touch_state=2;
 reg[1:0]pattern_mode=1;reg[6:0]pattern_selected=2;reg[48:0]pattern_notes=49'h10204081;
 reg pattern_busy=0;reg[2:0]pattern_count=4;reg pattern_full=0;
 reg[6:0]lesson_target=60,lesson_feedback_note=62;reg[1:0]lesson_feedback=1;
 reg[5:0]lesson_position=3;reg lesson_done=0;
 reg[1:0]knob_mode=1;reg[6:0]last_note=60,last_velocity=96,mod_depth=32;
 reg[47:0]wave_data=0;reg[7:0]spectrum_data=0,spectrum_peak=128;
 reg[1:0]spectrum_zoom=2;reg visual_valid=1,xy_data=0,xy_valid=1;reg[5:0]xy_settings=6'b101000;
 wire[9:0]wave_addr0,wave_addr1,tone_addr0,tone_addr1;wire[6:0]spectrum_addr0,spectrum_addr1;
 wire[15:0]xy_addr0,xy_addr1;wire[23:0]rgb0,rgb1;wire de0,de1,hs0,hs1,vs0,vs1;
 wire[10:0]tone0,tone1;wire[16:0]curve0,curve1;wire[9:0]count0,count1;
 final_panel #(.SHOW_PEDAL(1),.HISTORY_PREFETCH(1),.KEYBOARD_VIEW(1)) dut(.envelope_choices(envelope_choices),.preview_busy(preview_busy),.tone_data(tone0),.tone_curve(curve0),.tone_count(count0),
  .wave_addr(wave_addr0),.spectrum_addr(spectrum_addr0),.tone_addr(tone_addr0),.xy_addr(xy_addr0),
  .rgb(rgb0),.den_out(de0),.hsync_out(hs0),.vsync_out(vs0),.*);
 poly12_panel_envelope4_reference #(.SHOW_PEDAL(1),.HISTORY_PREFETCH(1),.KEYBOARD_VIEW(1)) reference(.envelope_choices(envelope_choices),.preview_busy(preview_busy),.tone_data(tone1),.tone_curve(curve1),.tone_count(count1),
  .wave_addr(wave_addr1),.spectrum_addr(spectrum_addr1),.tone_addr(tone_addr1),.xy_addr(xy_addr1),
  .rgb(rgb1),.den_out(de1),.hsync_out(hs1),.vsync_out(vs1),.*);
 reg sample_tick=1,audio_recording=0,audio_restart=0;reg[10:0]pitch=768;reg pitch_valid=1;
 wire frame_start=den&&x==0&&y==0;
 wire read_enable=page==1&&x>=127&&x<895;wire old_read_enable=read_enable;
 tone_history #(.TOTAL_SAMPLES(768),.READ_GATED(1),.PIPELINED_READ(1)) history_new(
  .clk(clk),.rst(!rstn),.restart(audio_restart),.sample_tick(sample_tick),.recording(audio_recording),.pitch(pitch),.pitch_valid(pitch_valid),
  .pixel_clk(pixel_clk),.pixel_rstn(rstn),.frame_start(frame_start),.read_addr(tone_addr0),.read_enable(read_enable),
  .pitch_data(tone0),.visible_count(count0),.curve_sum(curve0));
 tone_history #(.TOTAL_SAMPLES(768),.READ_GATED(1),.PIPELINED_READ(1)) history_old(
  .clk(clk),.rst(!rstn),.restart(audio_restart),.sample_tick(sample_tick),.recording(audio_recording),.pitch(pitch),.pitch_valid(pitch_valid),
  .pixel_clk(pixel_clk),.pixel_rstn(rstn),.frame_start(frame_start),.read_addr(tone_addr1),.read_enable(old_read_enable),
  .pitch_data(tone1),.visible_count(count1),.curve_sum(curve1));
 integer ai=0;
 always @(negedge clk)begin
  if(rstn)begin
   audio_recording=1;
   pitch=768+((ai*17)%590);pitch_valid=ai%19!=0;ai++;
  end
 end
 always @(posedge pixel_clk)begin
  playing<=x[6];muted<=x[7];piano_ready<=x[8];touch_ready<=y[5];
  wave_data<={32'd0,({6'd0,x[9:0]}<<5)};spectrum_data<={spectrum_addr0,1'b0};
  xy_data<=xy_addr0[7:0]==xy_addr0[15:8]||xy_addr0[7:0]==~xy_addr0[15:8];
 end

 integer i,p,k,checks=0,visible_checks=0,curve_checks=0,accepts=0,bank_switches=0,recycles=0;
 integer per_page[0:7];reg previous_seen=0,retiring=0,retired_bank=0;realtime retirement_time=0,min_recycle=1000000;
 always @(posedge pixel_clk)if(rstn&&frame_start)begin
  if(history_new.publish_sync[1]!=history_new.seen&&history_new.source_bank!=history_new.display_bank)begin
   retiring=1;retired_bank=history_new.display_bank;retirement_time=$realtime;bank_switches++;
  end
  frames<=frames+1;page<=frames<6?1:((frames-6)%8==7?6:(frames-6)%8);
  envelope_choices<=frames>=6&&(frames-6)%8==7?8'hff:8'h95;preview_busy<=frames>=6&&(frames-6)%8==7;mode<=frames%4;
  timbre<=frames%4;timbre_open<=frames[0];pedal_down<=frames[1];
 end
 always @(negedge clk)if(rstn)begin
  if({history_new.writer,history_new.column,history_new.phase,history_new.source_bank,history_new.source_count,history_new.publish,history_new.ack_sync}!==
     {history_old.writer,history_old.column,history_old.phase,history_old.source_bank,history_old.source_count,history_old.publish,history_old.ack_sync})$fatal(1,"HISTORY_PRODUCER_OR_MAILBOX_CHANGED");
  if(retiring&&history_new.store_sample&&history_new.writer==retired_bank)begin
   if($realtime-retirement_time<40.0)$fatal(1,"HISTORY_ACK_RECYCLED_BEFORE_SECOND_PIXEL_READ");
   if(recycles==0||$realtime-retirement_time<min_recycle)min_recycle=$realtime-retirement_time;
   retiring=0;recycles++;
  end
 end
 task cycle;begin
  @(posedge pixel_clk);#1;
  if({history_new.display_bank,count0,history_new.seen,history_new.ack}!=={history_old.display_bank,count1,history_old.seen,history_old.ack})$fatal(1,"HISTORY_PIPELINE_FRAME_META_CHANGED");
  if({dut.base_color3,dut.base_ink3,dut.base_label3,dut.base_text_on3}!=={reference.base_color3,reference.base_ink3,reference.base_label3,reference.base_text_on3})$fatal(1,"PANEL_HARDEN_STAGE3_CHANGED raw%0d/%0d px%0d/%0d pre%0d/%0d header%0d/%0d edge%0b expected%0b got%h/%0d/%0b want%h/%0d/%0b",x,y,dut.px,dut.py,dut.px1,dut.py1,dut.header_hit2,reference.p8_header_hit(reference.px,reference.py),dut.header_edge2,reference.edgebox(reference.b_bx,8,reference.b_bx+reference.b_bw,56),dut.base_color3,dut.base_label3,dut.base_text_on3,reference.base_color3,reference.base_label3,reference.base_text_on3);
  if({rgb0,de0,hs0,vs0}!=={rgb1,de1,hs1,vs1})$fatal(1,"HISTORY_PIPELINE_RASTER_RGB frame%0d page%0d raw%0d/%0d DE%b got%h want%h",frames,page,x,y,de0,rgb0,rgb1);
  if(de0)visible_checks++;
  if(den)begin per_page[page]++;if(page==6&&preview_busy)per_page[7]++;end
  if(page==1&&x>=128&&x<896&&count0!=0)begin
   if({tone0,curve0}!=={tone1,curve1})$fatal(1,"HISTORY_PIPELINE_VISIBLE_DATA frame%0d x%0d count%0d got%h/%h want%h/%h",frames,x,count0,tone0,curve0,tone1,curve1);
   curve_checks++;
  end
  if(history_new.seen!=previous_seen)begin accepts++;previous_seen=history_new.seen;end
  checks++;@(negedge pixel_clk);
 end endtask
 initial begin
  for(i=0;i<4;i++)begin notes[i*7+:7]=60+i*4;gains[i*12+:12]=(i+1)*700;end
  for(i=0;i<7;i++)home_gains[i*12+:12]=(i+1)*500;
  for(i=0;i<8;i++)per_page[i]=0;
  repeat(6)cycle;rstn=1;
  while(frames<15)cycle;repeat(12)cycle;
  for(p=0;p<8;p++)if(per_page[p]<600000)$fatal(1,"HISTORY_FULL_RASTER_PAGE_MISSING p%0d n%0d",p,per_page[p]);
  if(curve_checks<1000000||accepts<8||bank_switches<3||recycles<3)$fatal(1,"HISTORY_PIPELINE_MAILBOX_COVERAGE %0d/%0d/%0d/%0d",curve_checks,accepts,bank_switches,recycles);
  $display("HISTORY_PIPELINE_RASTER_PASS checks%0d visible%0d curve%0d accepts%0d switch%0d recycled%0d minReuseNs%0f all7pagesAndEnvelopePreview actual1344x635/1024x600/blanking RGBsyncCycleExact oldFullPanelHistory",checks,visible_checks,curve_checks,accepts,bank_switches,recycles,min_recycle);done=1;
 end
 initial begin #400000000;$fatal(1,"HISTORY_PIPELINE_RASTER_TIMEOUT");end
endmodule
module tb_poly12_ui_equivalence;wire done;poly12_ui_equivalence_case t(done);initial begin wait(done);$finish;end endmodule
