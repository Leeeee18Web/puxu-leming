`timescale 1ns/1ps
module poly_fresh_test #(parameter N=2);
 reg clk=0;always #10 clk=~clk;reg rst=1,start=0;
 reg[N-1:0]gates=0,triggers=0;reg[N*24-1:0]steps=0;reg[N*12-1:0]gains=0;reg[N*3-1:0]timbres=0;
 wire[N*16-1:0]samples,rsamples,envelopes,renvelopes;wire[N-1:0]active,ractive;
 wire busy,rbusy,error,rerror,valid,rvalid;wire[2:0]tag,rtag;
 poly_voice_worker #(.CONTEXTS(N)) dut(.clk(clk),.rst(rst),.start(start),.gates(gates),.triggers(triggers),.steps(steps),.gains(gains),.timbres(timbres),
  .samples(samples),.envelopes(envelopes),.active(active),.busy(busy),.deadline_error(error),.out_valid(valid),.out_index(tag),.out_sample(),.model_reset({3{rst}}),.control_resetn_early(1'b1));
 poly_worker_before_fresh #(.CONTEXTS(N)) reference(.clk(clk),.rst(rst),.start(start),.gates(gates),.triggers(triggers),.steps(steps),.gains(gains),.timbres(timbres),
  .samples(rsamples),.envelopes(renvelopes),.active(ractive),.busy(rbusy),.deadline_error(rerror),.out_valid(rvalid),.out_index(rtag),.out_sample(),.model_reset({3{rst}}));
 integer frame,slot,c,k,checks=0,warm_checks=0,unknown_slots=0,repeated_slots=0,changed_slots=0;
 reg functional=0,expected_fresh=1,forced_known=0;reg[2:0]forced_tone=0;
 always @(negedge clk)if(functional&&!rst)begin
  if(dut.phase!==reference.phase||dut.context_index!==reference.context_index||dut.ctx_load!==reference.ctx_load||dut.ctx_save!==reference.ctx_save||
     dut.render_fire!==reference.render_fire||dut.trigger_fire!==reference.trigger_fire||dut.context_clear!==reference.context_clear||
     dut.warm_enable!==reference.warm_enable||dut.core_enable!==reference.core_enable)$fatal(1,"FRESH_TIMING_EQUIVALENCE N%0d phase%0d frame%0d",N,dut.phase,frame);
  if(samples!==rsamples||envelopes!==renvelopes||active!==ractive||valid!==rvalid||tag!==rtag||busy!==rbusy||error!==rerror)$fatal(1,"FRESH_OUTPUT_EQUIVALENCE N%0d phase%0d frame%0d",N,dut.phase,frame);
  checks=checks+1;
  if(dut.running&&dut.phase==1)begin
   if(!dut.known)unknown_slots=unknown_slots+1;
   else if(dut.saved_tone==dut.tone)repeated_slots=repeated_slots+1;
   else changed_slots=changed_slots+1;
  end
  if(dut.running&&dut.phase>=2&&dut.phase<=4)warm_checks=warm_checks+1;
 end
 initial begin
  for(k=0;k<N;k=k+1)begin steps[k*24+:24]=45000+k*16000;gains[k*12+:12]=1000;end
  repeat(5)@(negedge clk);rst=0;
  // Perturb only head metadata after its restore edge to demonstrate the new local boundary.
  for(frame=0;frame<3;frame=frame+1)begin
   start=1;@(negedge clk);start=0;
   for(slot=0;slot<N;slot=slot+1)begin
    wait(dut.running&&dut.phase==1);#1;
    expected_fresh=!dut.known||dut.saved_tone!=dut.tone;
    @(posedge clk);@(negedge clk); // Phase1 restore/capture completed; now phase2.
    forced_known=expected_fresh;forced_tone=dut.tone;
    force dut.known=forced_known;force dut.context_data[2:0]=forced_tone;#1;
    for(c=2;c<=4;c=c+1)begin
     if(dut.context_clear!==expected_fresh)$fatal(1,"FRESH_BOUNDARY_MISSING N%0d frame%0d slot%0d phase%0d",N,frame,slot,dut.phase);
     if(dut.warm_enable!==(expected_fresh||!dut.selected_busy))$fatal(1,"FRESH_WARM_BOUNDARY");
     @(negedge clk);
    end
    release dut.known;release dut.context_data[2:0];
    wait(dut.phase==135);@(negedge clk);
   end
   wait(!busy);@(negedge clk);
  end
  rst=1;repeat(5)@(negedge clk);rst=0;functional=1;
  // Original worker remains the timing/numerical oracle under the real stable-head contract.
  for(frame=0;frame<20;frame=frame+1)begin
   for(k=0;k<N;k=k+1)begin
    steps[k*24+:24]=45000+k*16000+frame*19;gains[k*12+:12]=frame==9?0:1000+k*300;
    timbres[k*3+:3]=(frame/3+k)%4;
   end
   gates=frame<17?{N{1'b1}}:0;triggers=frame%3==0?{N{1'b1}}:0;
   start=1;@(negedge clk);start=0;repeat(399)@(negedge clk);
   if(busy||error||rerror)$fatal(1,"FRESH_DEADLINE N%0d frame%0d",N,frame);
  end
  if(unknown_slots<N||repeated_slots==0||changed_slots==0||warm_checks!=20*N*3)$fatal(1,"FRESH_COVERAGE N%0d unknown%0d repeated%0d changed%0d warm%0d",N,unknown_slots,repeated_slots,changed_slots,warm_checks);
  $display("POLY_FRESH_LOCAL_PASS N%0d checks%0d warm%0d unknown%0d repeated%0d changed%0d same phase2..4 clear/warm/core/load/save/render/output",N,checks,warm_checks,unknown_slots,repeated_slots,changed_slots);$finish;
 end
 initial begin #1000000;$fatal(1,"FRESH_TIMEOUT");end
endmodule
module tb_poly_fresh_local;poly_fresh_test #(.N(2)) test();endmodule
module tb_poly_fresh_local1;poly_fresh_test #(.N(1)) test();endmodule
