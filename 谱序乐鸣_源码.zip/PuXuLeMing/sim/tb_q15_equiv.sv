`timescale 1ns/1ps
module tb_q15_equiv;
 reg clk=0;always #10 clk=~clk;
 phys_strings_line dut(.clk(clk),.rst(1'b1),.tick(1'b0),.trigger(1'b0),.gate(1'b0),.kind(3'd1),.velocity(12'd0),.step(24'd1),.half_rate(1'b0),.period_q10(24'd2304),.sample(),.envelope(),.busy(),.deadline_error(),.bridge_return(18'sd0),.bridge_incident(),.piano_mode(1'b1),.bridge_incident_next());
 ref_r1_phys_strings_line reference(.clk(clk),.rst(1'b1),.tick(1'b0),.trigger(1'b0),.gate(1'b0),.kind(3'd1),.velocity(12'd0),.step(24'd1),.half_rate(1'b0),.period_q10(24'd2304),.sample(),.envelope(),.busy(),.deadline_error());
 reg[35:0]x=0,rng=36'hf973491ac;integer h,l,k,checks=0;
 task check;begin
  if(dut.q15($signed(x))!==reference.q15($signed(x)))$fatal(1,"Q15_EQ_FAIL x=%h new=%h old=%h",x,dut.q15($signed(x)),reference.q15($signed(x)));
  checks++;
 end endtask
 initial begin
  for(h=0;h<16;h++)for(l=0;l<32768;l++)begin
   case(h)
    0:x={21'd0,l[14:0]};1:x={21'd1,l[14:0]};2:x={21'h1fffff,l[14:0]};3:x={21'h100000,l[14:0]};
    4:x={21'h0fffff,l[14:0]};5:x={21'h000fff,l[14:0]};6:x={21'h1ff000,l[14:0]};7:x={21'h1ffffe,l[14:0]};
    default:x={(21'h13579*(h-7)),l[14:0]};
   endcase
   check;#1;
  end
  for(k=0;k<1000000;k++)begin rng={rng[34:0],rng[35]^rng[24]^rng[9]^rng[0]};x=rng;check;#1;end
  $display("Q15_EQ_PASS vectors=%0d all32768residues/16highpatterns/1Mrandom",checks);$finish;
 end
endmodule
