`timescale 1ns/1ps
module regional170_patterns_case #(parameter DIRECT=0)(output reg done=0);
 reg clk=0;always #10 clk=~clk;
 reg rst=1,sample_tick=0,start=0;
 reg[1:0] touch_mode=0,wifi_mode=0,ui_mode=0,direct_mode=0;
 reg esp_ready=0,wifi_override=0,selected_valid=0,controller_ready=0;
 reg map_apply=0,panic_all=0,clear_live=0,stop_score=0,mute_enter=0,touch_lost=0,direct_cancel=0;
 reg[31:0] selected_data=0;
 wire owner=esp_ready&&wifi_override;
 wire[1:0] mode= DIRECT?direct_mode:(owner?wifi_mode:touch_mode);
 // Frozen original production root qualification, including ready stalls,
 // non-note controls, mobile-scoped CC and FF disconnect behavior.
 wire wifi_active=esp_ready&&wifi_override&&wifi_mode!=0;
 wire enabled=(ui_mode==1)||wifi_active;
 wire pattern_select=enabled&&mode!=0;
 wire note_event=selected_data[7:4]==8||selected_data[7:4]==9;
 wire selected_ready=(pattern_select&&note_event?1'b1:controller_ready)&&!clear_live&&!panic_all&&!map_apply;
 wire mobile_scoped=selected_data[24]&&(selected_data[3:0]==13||selected_data[3:0]==14);
 wire all_off=selected_valid&&selected_ready&&!mobile_scoped&&selected_data[7:4]==11&&
              !selected_data[15]&&!selected_data[23]&&(selected_data[14:8]==120||selected_data[14:8]==123);
 wire disconnect=selected_valid&&selected_ready&&pattern_select&&selected_data[7:0]==8'hff;
 wire base_cancel=map_apply||panic_all||clear_live||stop_score||mute_enter||all_off||touch_lost;
 wire cancel=DIRECT?direct_cancel:(base_cancel||!enabled||disconnect);
 wire event_valid=DIRECT?selected_valid:(selected_valid&&selected_ready&&pattern_select);
 wire request=selected_valid&&!selected_data[15]&&!selected_data[23]&&selected_data[7:4]==9&&selected_data[22:16]!=0;
 wire[6:0]sel0,sel1;wire[48:0]sn0,sn1;wire[83:0]sg0,sg1;wire[3:0]g0,g1,t0,t1;
 wire[27:0]n0,n1;wire[47:0]a0,a1;wire b0,b1,f0,f1;wire[2:0]c0,c1;
 final_patterns #(.SAMPLE_HZ(7),.STRUM_SAMPLES(3),.ARP_SAMPLES(7),.HOLD_SAMPLES(9),.BRANCH_FULL_RELOAD(!DIRECT)) dut(
  .clk(clk),.rst(rst),.sample_tick(sample_tick),.cancel(cancel),.pattern_mode(mode),.start(start),.event_valid(event_valid),.event_data(selected_data),
  .selected(sel0),.selected_notes(sn0),.selected_gains(sg0),.gates(g0),.triggers(t0),.notes(n0),.gains(a0),.busy(b0),.count(c0),.full(f0),
  .full_touch_mode(touch_mode),.full_wifi_mode(wifi_mode),.full_owner(owner),.full_touch_enabled(ui_mode==1),.full_note_request(request),.full_base_cancel(base_cancel));
 patterns_before_regional170 #(.SAMPLE_HZ(7),.STRUM_SAMPLES(3),.ARP_SAMPLES(7),.HOLD_SAMPLES(9)) old(
  .clk(clk),.rst(rst),.sample_tick(sample_tick),.cancel(cancel),.pattern_mode(mode),.start(start),.event_valid(event_valid),.event_data(selected_data),
  .selected(sel1),.selected_notes(sn1),.selected_gains(sg1),.gates(g1),.triggers(t1),.notes(n1),.gains(a1),.busy(b1),.count(c1),.full(f1));
 integer checks=0,i,j,m,ov=0,reload_at_one=0,cancel_tick=0,stalls=0,illegal=0,zero_velocity=0,disconnects=0,simultaneous=0;
 reg[7:0]count_seen=0;reg[4:0]state_seen=0;reg[3:0]mode_seen=0;reg[1:0]owner_seen=0;
 reg[31:0]rng=32'hc0ffee12;
 always @(posedge clk)begin
  if(!DIRECT)begin
   if(pattern_select!==(owner?(wifi_mode!=0):(ui_mode==1&&touch_mode!=0)))$fatal(1,"ROOT_SELECT_FORMULA");
   if(dut.branch_admit!==(dut.legacy_eligible&&dut.selection_event&&dut.legacy_accept))$fatal(1,"ROOT_ADMISSION check%0d",checks);
   if(dut.branch_reload!==(dut.legacy_eligible&&dut.selection_event&&!dut.legacy_accept))$fatal(1,"ROOT_RELOAD check%0d",checks);
   if(dut.chord_entry!==(mode==2&&mode!=dut.previous_mode))$fatal(1,"ROOT_CHORD_ENTRY");
  end
  if(dut.full_reload&&!rst)begin ov++;if(dut.full_left==1&&sample_tick)reload_at_one++;end
  if(cancel&&sample_tick&&dut.full_left!=0)cancel_tick++;
  if(selected_valid&&!selected_ready)stalls++;
  if(selected_valid&&(selected_data[15]||selected_data[23]))illegal++;
  if(selected_valid&&selected_data[7:4]==9&&selected_data[22:16]==0)zero_velocity++;
  if(disconnect)disconnects++;
  if(start&&dut.selection_event&&!cancel)simultaneous++;
  #1;
  if({sel0,sn0,sg0,g0,t0,n0,a0,b0,c0,f0}!=={sel1,sn1,sg1,g1,t1,n1,a1,b1,c1,f1})$fatal(1,"PATTERN_PUBLIC DIRECT%0d check%0d",DIRECT,checks);
  if({dut.state,dut.previous_mode,dut.run_mode,dut.snapshot_selected,dut.remaining,dut.snapshot_notes,dut.snapshot_gains,
      dut.scan,dut.rank,dut.run_index,dut.best_note,dut.best_mask,dut.sorted,dut.clear_sample,dut.interval_left,dut.hold_left,dut.arp_age,dut.full_left}!==
     {old.state,old.previous_mode,old.run_mode,old.snapshot_selected,old.remaining,old.snapshot_notes,old.snapshot_gains,
      old.scan,old.rank,old.run_index,old.best_note,old.best_mask,old.sorted,old.clear_sample,old.interval_left,old.hold_left,old.arp_age,old.full_left})$fatal(1,"PATTERN_PRIVATE DIRECT%0d check%0d",DIRECT,checks);
  for(integer q=0;q<7;q++)if(dut.order[q]!==old.order[q])$fatal(1,"PATTERN_ORDER");
  checks++;count_seen[c0]=1;state_seen[dut.state]=1;mode_seen[mode]=1;owner_seen[owner]=1;
 end
 task step;begin @(negedge clk);end endtask
 task quiet;begin selected_valid=0;selected_data=0;start=0;direct_cancel=0;map_apply=0;panic_all=0;clear_live=0;stop_score=0;mute_enter=0;touch_lost=0;end endtask
 task reset_mode(input[1:0] mm);begin
  step();quiet();rst=1;sample_tick=1;touch_mode=mm;wifi_mode=mm;direct_mode=mm;ui_mode=1;esp_ready=0;wifi_override=0;controller_ready=1;
  repeat(3)step();rst=0;step();
 end endtask
 task noteon(input integer pitch,input integer vel);begin
  selected_valid=1;selected_data=(vel<<16)|(pitch<<8)|32'h90;step();selected_valid=0;step();
 end endtask
 initial begin
  // Counts 0..7, all modes, selection/start priority and legal MIDI zero.
  for(m=1;m<=3;m++)begin
   reset_mode(m);
   for(j=0;j<(m==2?4:7);j++)noteon(36+j*3,1+j*19);
   start=1;selected_valid=1;selected_data=(100<<16)|(120<<8)|32'h90;step();start=0;selected_valid=0;
   // Leave six decrements so reload lands exactly on full_left==1.
   repeat(6)step();selected_valid=1;selected_data=(101<<16)|(121<<8)|32'h90;start=1;step();selected_valid=0;start=0;
   direct_cancel=1;stop_score=1;step();direct_cancel=0;stop_score=0;
   repeat(9)step();start=1;step();start=0;repeat(160)step();
   noteon(36,91);noteon(0,100); // duplicate removal and MIDI0.
  end
  // Directed control collisions: change into chord trims on cancel/event/start.
  reset_mode(1);for(j=0;j<7;j++)noteon(40+j,90);
  touch_mode=2;wifi_mode=2;direct_mode=2;direct_cancel=1;touch_lost=1;start=1;selected_valid=1;selected_data=32'h00645590;step();quiet();
  touch_mode=0;wifi_mode=0;direct_mode=0;step();
  if(DIRECT)begin
   // Default0 retains original procedural four-state if/else behavior.
   reset_mode(1);for(j=0;j<7;j++)noteon(50+j,90);
   selected_valid=1;selected_data=32'h00647890;direct_cancel=1'bx;step();quiet();
  end
  // Dynamic owner with matching and changing mode, stale/illegal/control data,
  // ready stalls, reset, sample tick and every cancel source independently.
  for(i=0;i<240000;i++)begin
   step();rng=rng*1664525+1013904223;rst=i%2053<2;sample_tick=rng[0];start=rng[5:2]==0;
   if(i%71==0)begin touch_mode=rng[7:6];wifi_mode=rng[9:8];direct_mode=rng[11:10];ui_mode=rng[13:12];end
   esp_ready=rng[14];wifi_override=rng[15];selected_valid=rng[16];controller_ready=rng[17];
   direct_cancel=rng[22:18]==0;map_apply=rng[23:19]==0;panic_all=rng[24:20]==0;clear_live=rng[25:21]==0;
   stop_score=rng[26:22]==0;mute_enter=rng[27:23]==0;touch_lost=rng[28:24]==0;
   rng=rng*1664525+1013904223;selected_data=rng;
   case(i%12)
    0,1,2,3,4,5: selected_data={7'd0,rng[24],1'b0,rng[22:16],1'b0,rng[14:8],4'h9,rng[3:0]};
    6:selected_data=32'h00003c90; // velocity0
    7:selected_data=32'h00640090; // legal note0
    8:selected_data=32'h00647bb0; // CC123
    9:selected_data=32'h006478be; // mobile-scoped all-off
    10:selected_data=32'h000000ff; // disconnect
    11:selected_data=32'h0080ff90; // illegal data bits
   endcase
  end
  step();quiet();rst=0;repeat(3)step();
  if(count_seen!=8'hff||state_seen!=5'h1f||mode_seen!=4'hf||owner_seen!=3||reload_at_one<3||cancel_tick<3||ov<3||stalls<100||illegal<100||zero_velocity<100||disconnects<100||simultaneous<3)
   $fatal(1,"COVERAGE DIRECT%0d count%h state%h mode%h owner%h one%0d cancel%0d ov%0d stalls%0d illegal%0d zero%0d dis%0d sim%0d",DIRECT,count_seen,state_seen,mode_seen,owner_seen,reload_at_one,cancel_tick,ov,stalls,illegal,zero_velocity,disconnects,simultaneous);
  $display("REGIONAL170_PATTERNS_PASS DIRECT%0d checks%0d states%h counts%h reloadAtOne%0d cancelTick%0d overflow%0d stalls%0d illegal%0d zeroVelocity%0d disconnect%0d selectionStart%0d",DIRECT,checks,state_seen,count_seen,reload_at_one,cancel_tick,ov,stalls,illegal,zero_velocity,disconnects,simultaneous);
  done=1;
 end
endmodule
module tb_regional170_patterns;
 wire d0,d1;
 regional170_patterns_case #(.DIRECT(0)) integrated(d0);
 regional170_patterns_case #(.DIRECT(1)) default_legacy(d1);
 initial begin wait(d0&&d1);$display("REGIONAL170_PATTERNS_ALL_PASS");$finish;end
 initial begin #20000000;$fatal(1,"TIMEOUT");end
endmodule
