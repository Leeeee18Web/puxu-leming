`timescale 1ns/1ps
// Runs copied pre-extension synth against HARD_MUTE=0 with X on the new input.
module tb_play_hardmute_compat;
 reg clk=0;always #10 clk=~clk;
 reg rst=1;reg [6:0] gates=0,triggers=0;reg [48:0] notes=0;reg [83:0] gains=0;reg [18:0] ratio=262144;
 wire tick_a,tick_b;wire signed [15:0] pcm_a,pcm_b;
 wire [5:0] serial_a,serial_b;wire [6:0] active_a,active_b;
 play_audio_reference old(.clk(clk),.rst(rst),.gates(gates),.notes(notes),.gains(gains),.triggers(triggers),.ratio(ratio),.sample_tick(tick_a),.pcm(pcm_a),.hp_bck(serial_a[0]),.hp_ws(serial_a[1]),.hp_din(serial_a[2]),.i2s_bck(serial_a[3]),.i2s_ws(serial_a[4]),.i2s_sd(serial_a[5]),.active(active_a));
 play_audio_default updated(.clk(clk),.rst(rst),.gates(gates),.notes(notes),.gains(gains),.triggers(triggers),.ratio(ratio),.sample_tick(tick_b),.pcm(pcm_b),.hp_bck(serial_b[0]),.hp_ws(serial_b[1]),.hp_din(serial_b[2]),.i2s_bck(serial_b[3]),.i2s_ws(serial_b[4]),.i2s_sd(serial_b[5]),.active(active_b));
 integer cycles=0,k;
 always @(negedge clk)if(!rst)begin
  if({tick_a,pcm_a,serial_a,active_a}!=={tick_b,pcm_b,serial_b,active_b})$fatal(1,"default hardmute extension changed original synth output");
  cycles=cycles+1;
 end
 initial begin
  repeat(5)@(negedge clk);rst=0;
  notes={7'd84,7'd79,7'd76,7'd72,7'd67,7'd64,7'd60};gains={7{12'd3200}};gates=127;triggers=127;
  @(negedge clk);triggers=0;
  repeat(300000)@(negedge clk);
  gates=0;repeat(10000)@(negedge clk);
  $display("PASS tb_play_hardmute_compat cycles=%0d original PCM/active/I2S/PT exact with HARD_MUTE0 and X mask",cycles);$finish;
 end
endmodule
