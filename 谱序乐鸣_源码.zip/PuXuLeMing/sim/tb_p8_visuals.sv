`timescale 1ns/1ps
module tb_p8_visuals;
 reg clk=0,pclk=0,rst=1,prstn=0,tick=0,frame=0,frames_on=1;
 always #10 clk=~clk;always #13 pclk=~pclk;
 reg signed[15:0] pcm=0;
 reg[6:0] note=60;reg[10:0] pitch=960;reg[23:0] step=24'd151183;
 reg[15:0] envelope=40000;reg active=1,restart=0;
 reg[5:0] settings=6'b101000;reg[2:0] page=1;reg[13:0] x=256;
 reg[9:0] wa=0,ta=0;reg[6:0] sa=0;reg[15:0] xa=0;
 wire[47:0] wd;wire[7:0] sd,peak;wire vv;wire[10:0] td;wire[16:0] tc;wire[9:0] count;wire xd,xv;wire[5:0] xs;
 p8_visuals #(.HISTORY_SAMPLES(3072),.XY_POINTS(32)) dut(
 .clk(clk),.rst(rst),.sample_tick(tick),.pcm(pcm),.pcm_positive($signed(pcm)>0),.leading_note(note),.leading_pitch(pitch),.leading_step(step),.leading_envelope(envelope),.leading_valid(active),.restart(restart),.requested_config(settings),
 .pixel_clk(pclk),.pixel_rstn(prstn),.frame_start(frame),.page(page),.x(x),.wave_addr(wa),.spectrum_addr(sa),.tone_addr(ta),.xy_addr(xa),.wave_data(wd),.spectrum_data(sd),.spectrum_peak(peak),.visual_valid(vv),.tone_data(td),.tone_curve(tc),.tone_count(count),.xy_data(xd),.xy_valid(xv),.xy_settings(xs));
 integer cyc=0,pc=0,sample=0,bin=16,i,maxvalue,maxbin,wpos,wneg,xyones,checks=0,pubcount=0;
 reg signed[15:0] expected[0:2047];
 reg old_fb=0,old_xb=0,old_hb=0;
 reg[12:0] published_meta[0:1];reg[1:0] published_banks=0;
 integer fft_publications=0,meta_checks=0,wave_ownership_checks=0;
 reg previous_valid;reg[15:0] expected_read_word;
 initial begin published_meta[0]=0;published_meta[1]=0;end
 always @(dut.fft.publish_toggle)if(!rst)begin
  published_meta[dut.fft.bank]=dut.fft.meta_source;
  published_banks[dut.fft.bank]=1;fft_publications=fft_publications+1;
 end
 always @(negedge clk)begin
  tick=0;if(!rst)begin cyc=cyc+1;if(cyc%32==0)begin tick=1;pcm=$rtoi(6000.0*$sin(6.283185307179586*bin*sample/1024.0));sample=sample+1;end end
 end
 always @(posedge clk)begin
  if(!dut.fft.rst&&dut.fft.sample_tick&&dut.fft.state==1)expected[{dut.fft.bank,dut.fft.capture_index}]=dut.fft.pcm;
  if(!dut.fft.rst&&vv&&dut.fft.state==1&&dut.fft.sample_tick&&dut.fft.bank==dut.fft.display_bank)$fatal(1,"FFT overwrites displayed bank");
  if(!rst&&xv&&(dut.xy.state==0||dut.xy.state==5)&&dut.xy.bank==dut.xy.display_bank)$fatal(1,"XY overwrites displayed bitmap");
 end
 always @(negedge pclk)begin pc=pc+1;frame=frames_on&&pc%3000==0;end
 always @(posedge pclk)begin
  previous_valid=vv;expected_read_word=expected[{dut.fft.display_bank,wa}];
  #1;
  if(prstn&&previous_valid)begin
   if(wd!=={32'd0,expected_read_word})$fatal(1,"published wave bank ownership mismatch");
   wave_ownership_checks=wave_ownership_checks+1;
  end
  if(prstn&&vv)begin
   if(dut.fft.meta!==published_meta[dut.fft.display_bank])$fatal(1,"published FFT metadata belongs to another bank");
   meta_checks=meta_checks+1;
  end
  if(prstn)begin
   if((dut.fft.display_bank!=old_fb||dut.xy.display_bank!=old_xb||dut.history.display_bank!=old_hb)&&!frame)$fatal(1,"graph bank changes inside frame");
   if(dut.fft.display_bank!=old_fb)pubcount=pubcount+1;
  end
  old_fb=dut.fft.display_bank;old_xb=dut.xy.display_bank;old_hb=dut.history.display_bank;
 end
 task read_wave(input integer a);begin @(negedge pclk);wa=a;@(negedge pclk);end endtask
 task read_spectrum(input integer a);begin @(negedge pclk);sa=a;@(negedge pclk);end endtask
 task read_tone(input integer a);begin @(negedge pclk);ta=a;@(negedge pclk);end endtask
 task check_spectrum(input integer want);
  integer k;begin
   maxvalue=0;maxbin=0;
   for(k=0;k<128;k=k+1)begin read_spectrum(k);if(sd>maxvalue)begin maxvalue=sd;maxbin=k;end end
   if(maxbin!=want||maxvalue<150||peak!=maxvalue)$fatal(1,"FFT real PCM bin expected%0d got%0d mag%0d peak%0d",want,maxbin,maxvalue,peak);
   checks=checks+128;
  end
 endtask
 task check_xy(output integer ones);
  integer k;begin
   ones=0;
   for(k=0;k<65536;k=k+1)begin
    @(negedge pclk);xa=k;@(negedge pclk);
    if(xd===1)ones=ones+1;else if(xd!==0)$fatal(1,"unknown published XY pixel%0d",k);
   end
  end
 endtask
 reg bankheld;reg[47:0] waveheld;reg[16:0] curve_low;integer oldpub,resttarget;
 initial begin
  repeat(6)@(negedge clk);rst=0;prstn=1;
  wait(vv);frames_on=0;repeat(4)@(negedge pclk);
  bankheld=dut.fft.display_bank;wpos=0;wneg=0;
  for(i=0;i<1024;i=i+1)begin
   read_wave(i);
   if(wd[47:16]!==0||wd[15:0]!==expected[{bankheld,i[9:0]}])$fatal(1,"actual waveform mismatch%0d got%h expected%h",i,wd,expected[{bankheld,i[9:0]}]);
   if($signed(wd[15:0])>5000)wpos=wpos+1;if($signed(wd[15:0])< -5000)wneg=wneg+1;
  end
  if(wpos<100||wneg<100)$fatal(1,"wave lacks both real polarities");checks=checks+1024;
  check_spectrum(16);read_wave(17);waveheld=wd;
  repeat(160000)@(negedge clk);
  if(dut.fft.display_bank!==bankheld||wd!==waveheld)$fatal(1,"frame stall corrupted held PCM");
  // Leading pitch stays fixed; changing the real PCM must move the FFT.
  bin=32;frames_on=1;oldpub=pubcount;wait(pubcount>=oldpub+2);frames_on=0;repeat(5)@(negedge pclk);check_spectrum(32);
  // New pass and higher octave must move the actual mapped seven-tap curve.
  @(negedge clk);restart=1;@(negedge clk);restart=0;frames_on=1;
  wait(count==0);wait(count>=12);frames_on=0;repeat(4)@(negedge pclk);read_tone(0);curve_low=tc;
  if(td!==960)$fatal(1,"low pitch not from actual selected voice");
  pitch=1152;note=72;@(negedge clk);restart=1;@(negedge clk);restart=0;frames_on=1;
  wait(count==0);wait(count>=12);frames_on=0;repeat(4)@(negedge pclk);read_tone(0);
  if(td!==1152||curve_low-tc!==17'd21504)$fatal(1,"octave must shift pitch curve by84px low%0d high%0d",curve_low,tc);
  // Rest occupies a real time column; it does not extend a held note.
  active=0;resttarget=dut.history.column+8;frames_on=1;wait(count>=resttarget);frames_on=0;repeat(4)@(negedge pclk);read_tone(count-1);if(td!==2047)$fatal(1,"rest sentinel not recorded");
  active=1;frames_on=1;wait(xv);frames_on=0;repeat(4)@(negedge pclk);check_xy(xyones);if(xyones<30)$fatal(1,"XY empty active reference");
  settings=6'b000011;frames_on=1;wait(xs==settings);frames_on=0;repeat(4)@(negedge pclk);check_xy(xyones);if(xyones<30)$fatal(1,"XY config empty reference");
  active=0;frames_on=1;repeat(2)begin bankheld=dut.xy.display_bank;wait(dut.xy.display_bank!=bankheld);end
  frames_on=0;repeat(4)@(negedge pclk);check_xy(xyones);if(xyones!=0)$fatal(1,"idle XY stale");
  // Parent contract: stalled pixel clock is accompanied by producer reset.
  rst=1;prstn=0;repeat(5)@(negedge clk);if(vv||xv||count)$fatal(1,"reset must revoke publications");
  rst=0;prstn=1;frames_on=1;active=1;wait(vv&&xv);checks=checks+8;
  $display("P8_VISUALS_CONTINUOUS fft_publications%0d display_publications%0d banks%b metadata_checks%0d wave_ownership_checks%0d",fft_publications,pubcount,published_banks,meta_checks,wave_ownership_checks);
  if(fft_publications<3||published_banks!=2'b11||meta_checks<1024||wave_ownership_checks<1024)$fatal(1,"continuous FFT publication coverage");
  $display("P8_VISUALS_PASS checks%0d PCM1024 exact/signed FFT16->32 while fixedpitch octave84px rests frameowned XYconfig/idle/reset",checks);$finish;
 end
 initial begin #150000000;$fatal(1,"P8 visuals deadline");end
endmodule


