`timescale 1ns/1ps
module poly_warm_busy_equiv_case #(parameter N=2)(output reg done=0);
 reg clk=0;always #10 clk=~clk;reg rst=1,start=0;
 reg[N-1:0]gates=0,triggers=0;reg[N*24-1:0]steps=0;reg[N*12-1:0]gains=0;reg[N*3-1:0]timbres=0;
 wire[N*16-1:0]sa,sb,ea,eb;wire[N-1:0]aa,ab;wire ba,bb,da,db,va,vb;wire[2:0]ia,ib;wire signed[15:0]oa,ob;
 poly_voice_worker #(.CONTEXTS(N)) dut(.clk(clk),.rst(rst),.start(start),.gates(gates),.triggers(triggers),.steps(steps),.gains(gains),.timbres(timbres),.samples(sa),.envelopes(ea),.active(aa),.busy(ba),.deadline_error(da),.out_valid(va),.out_index(ia),.out_sample(oa),.model_reset({3{rst}}),.control_resetn_early(1'b1));
 poly_worker_before_control #(.CONTEXTS(N)) reference(.clk(clk),.rst(rst),.start(start),.gates(gates),.triggers(triggers),.steps(steps),.gains(gains),.timbres(timbres),.samples(sb),.envelopes(eb),.active(ab),.busy(bb),.deadline_error(db),.out_valid(vb),.out_index(ib),.out_sample(ob),.model_reset({3{rst}}));
 integer frame,k,c,checks=0,warm_busy_count=0,warm_idle_count=0,fresh_count=0,legal_saves=0,init_saves=0;
 always @(negedge clk)if(!rst)begin
  if({sa,ea,aa,ba,da,va,ia,oa,dut.phase,dut.context_index,dut.ctx_load,dut.ctx_save,dut.render_fire,dut.trigger_fire,dut.context_clear,dut.warm_enable,dut.core_enable,dut.context_data}!==
     {sb,eb,ab,bb,db,vb,ib,ob,reference.phase,reference.context_index,reference.ctx_load,reference.ctx_save,reference.render_fire,reference.trigger_fire,reference.context_clear,reference.warm_enable,reference.core_enable,reference.context_data})$fatal(1,"WARM_BUSY_EQ N%0d frame%0d phase%0d",N,frame,dut.phase);
  if(dut.running&&dut.phase>=2&&dut.phase<=4)begin
   if(dut.warm_busy!==reference.selected_busy&&!dut.fresh_context)$fatal(1,"WARM_BUSY_SNAPSHOT_EQ N%0d frame%0d phase%0d",N,frame,dut.phase);
   if(dut.fresh_context)fresh_count++;else if(dut.warm_busy)warm_busy_count++;else warm_idle_count++;
  end
  if(dut.ctx_save)begin
   if(dut.strings.a.state>3||dut.strings.b.state>3||dut.strings.c.state>3)$fatal(1,"WORKER_LEGAL_LINE_SAVE N%0d frame%0d states%0d/%0d/%0d",N,frame,dut.strings.a.state,dut.strings.b.state,dut.strings.c.state);
   legal_saves++;if(dut.strings.a.state!=0||dut.strings.b.state!=0||dut.strings.c.state!=0)init_saves++;
  end
  checks++;
 end
 initial begin
  repeat(5)@(negedge clk);rst=0;
  for(frame=0;frame<100;frame=frame+1)begin
   for(k=0;k<N;k=k+1)begin
    steps[k*24+:24]=45000+k*16000+frame*19;gains[k*12+:12]=frame==41?0:1000+k*300;
    timbres[k*3+:3]=(frame/16+k)%4;
   end
   gates=frame<92?{N{1'b1}}:0;triggers=frame%19==0?{N{1'b1}}:0;
   start=1;@(negedge clk);start=0;repeat(399)@(negedge clk);
   if(ba||da||db)$fatal(1,"WARM_BUSY_DEADLINE N%0d frame%0d",N,frame);
  end
  if(warm_busy_count==0||warm_idle_count==0||fresh_count==0)$fatal(1,"WARM_BUSY_COVERAGE N%0d busy%0d idle%0d fresh%0d",N,warm_busy_count,warm_idle_count,fresh_count);
  if(legal_saves!=100*N||init_saves==0)$fatal(1,"WORKER_SAVE_COVERAGE N%0d saves%0d init%0d",N,legal_saves,init_saves);
  $display("POLY_WARM_BUSY_EQ_PASS N%0d checks%0d warmbusy%0d warmidle%0d fresh%0d legalSaves%0d initSaves%0d original worker same all control/memory/output edges",N,checks,warm_busy_count,warm_idle_count,fresh_count,legal_saves,init_saves);done=1;
 end
endmodule
module tb_poly_warm_busy_equiv;
 wire[1:0]done;poly_warm_busy_equiv_case #(.N(2)) n2(done[0]);poly_warm_busy_equiv_case #(.N(1)) n1(done[1]);
 initial begin wait(&done);$finish;end
endmodule
