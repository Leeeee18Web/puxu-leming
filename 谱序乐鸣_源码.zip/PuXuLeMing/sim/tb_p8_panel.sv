`timescale 1ns/1ps
module tb_p8_panel;
 reg clk=0;always #9.756 clk=~clk;
 reg rstn=0,den=0,hs=0,vs=0;
 reg [13:0] x=0,y=0;reg [2:0] page=0;reg [1:0] mode=0;
 reg [6:0] gates=127,base=60;reg valid=1,capture=1;reg [48:0] notes=0;reg [83:0] gains=0;
 reg [6:0] feedback_note=62,next=64,target=60;reg [1:0] feedback=0;reg special=0;
 reg [1:0] touch_state=0;
 reg [1:0] pattern_mode=0;reg [6:0] pattern_selected=0;reg [48:0] pattern_notes=0;
 reg pattern_busy=0,pattern_full=0;reg [2:0] pattern_count=0;
 string out_dir="build/sim/tb_p8_panel";
 wire [23:0] rgb;wire de,ho,vo;wire [9:0] wa,ta;wire [6:0] sa;wire [15:0] xa;
 reg [47:0] wave=0;reg [7:0] spectrum=0;reg [10:0] tone=60;reg [16:0] curve=0;reg xy=0;
 p8_panel dut(.pixel_clk(clk),.rstn(rstn),.den(den),.hsync(hs),.vsync(vs),.x(x),.y(y),
 .page(page),.mode(mode),.playing(1'b1),.muted(1'b0),.note_valid(1'b1),.next_note(next),.base_note(base),.gates(gates),.notes(notes),.gains(gains),
 .knob(7'd64),.raw_knob(7'd93),.raw_known(1'b1),.pickup_wait(1'b0),.knob_mode(2'd1),
 .touch_state(touch_state),
 .pattern_mode(pattern_mode),.pattern_selected(pattern_selected),.pattern_notes(pattern_notes),
 .pattern_busy(pattern_busy),.pattern_count(pattern_count),.pattern_full(pattern_full),
 .lesson_target(target),.lesson_feedback_note(feedback_note),.lesson_feedback(feedback),.lesson_position(6'd0),.lesson_done(1'b0),
 .last_note(7'd60),.last_velocity(7'd96),.mod_depth(7'd32),.wave_data(wave),
 .spectrum_data(spectrum),.spectrum_peak(8'd128),.spectrum_zoom(2'd2),.visual_valid(valid),
 .tone_data(tone),.tone_curve(curve),.tone_count(10'd768),.xy_data(xy),.xy_valid(1'b1),
 .xy_settings(6'b101000),.wave_addr(wa),.spectrum_addr(sa),.tone_addr(ta),.xy_addr(xa),
 .rgb(rgb),.den_out(de),.hsync_out(ho),.vsync_out(vo));
 integer p,xx,yy,i,j,fh[0:7],count[0:7],checks=0;
 integer xp[0:7],yp[0:7],pp[0:7],d[0:7],h[0:7],v[0:7];
 integer a,b,kb,kx,kn,kw;
 // These are explicit synthetic input fixtures only for rendering the real RTL.
 // Product graph data are exclusively supplied by p8_visuals.
 always @(posedge clk)begin
  wave[15:0]<=$signed({1'b0,wa[7:0]})*128-16384;
  spectrum<=sa[3:0]*8;
  curve<=(240+ta/4)<<8;
  a=$signed({1'b0,xa[7:0]})-128;b=$signed({1'b0,xa[15:8]})-128;
  xy<=a*a+b*b>9200&&a*a+b*b<10400;
 end
 task tick;
 begin
  @(posedge clk);#1;
  for(j=7;j>0;j=j-1)begin xp[j]=xp[j-1];yp[j]=yp[j-1];pp[j]=pp[j-1];d[j]=d[j-1];h[j]=h[j-1];v[j]=v[j-1];end
  xp[0]=x;yp[0]=y;pp[0]=page;d[0]=den;h[0]=hs;v[0]=vs;
  if(de!==d[7]||ho!==h[7]||vo!==v[7])$fatal(1,"FAIL RGB/sync pipeline %d,%d",x,y);
  checks=checks+1;
  if(de&&capture)begin
   $fwrite(fh[pp[7]],"%c%c%c",rgb[23:16],rgb[15:8],rgb[7:0]);count[pp[7]]=count[pp[7]]+1;
   if(!special)begin
   if(pp[7]==0&&xp[7]==40&&yp[7]==467&&rgb!==24'h60d9ed)$fatal(1,"FAIL home left actual gain bar %h",rgb);
   if(pp[7]==0&&xp[7]==836&&yp[7]==467&&rgb!==24'h78e6af)$fatal(1,"FAIL home right actual gain bar %h",rgb);
   if(pp[7]==5&&xp[7]==62&&yp[7]==494&&rgb!==24'hf5c767)$fatal(1,"FAIL C4 has no octave dot %h",rgb);
   if(pp[7]==5&&xp[7]==510&&yp[7]==494&&rgb!==24'h17202a)$fatal(1,"FAIL C5 upper dot %h",rgb);
   if(pp[7]==5&&xp[7]==958&&yp[7]==487&&rgb!==24'h17202a)$fatal(1,"FAIL C6 second upper dot %h",rgb);
   end
  end
  @(negedge clk);
 end endtask
 task probe(input integer p0,x0,y0,input [23:0] expected);
 begin page=p0;x=x0;y=y0;den=1;repeat(12)tick;
  if(rgb!==expected)$fatal(1,"FAIL dynamic p%0d(%0d,%0d) want%h got%h",p0,x0,y0,expected,rgb);
 end endtask
 initial begin
  if($value$plusargs("OUTDIR=%s",out_dir))begin end
  for(i=0;i<8;i=i+1)begin
   fh[i]=$fopen($sformatf("%s/page%0d.ppm",out_dir,i),"wb");
   $fwrite(fh[i],"P6\n1024 600\n255\n");count[i]=0;
   if(i<7)begin notes[i*7+:7]=60+i;gains[i*12+:12]=(i+1)*512;end
  end
  for(i=0;i<8;i=i+1)begin d[i]=0;h[i]=0;v[i]=0;xp[i]=0;yp[i]=0;pp[i]=0;end
  repeat(4)@(negedge clk);rstn=1;
  capture=0;gates=0;
  probe(5,36,240,24'h9aabb5); // disconnected touch status: first glyph at16px
  probe(7,36,552,24'h9aabb5);
  touch_state=2;probe(5,36,240,24'h78e6af);probe(7,36,552,24'h78e6af);
  touch_state=3;probe(5,36,240,24'h78e6af);probe(7,36,552,24'h78e6af);
  touch_state=0;
  probe(5,94,535,24'h36434e); // strong white right edge
  gates=127;
  probe(5,96,320,24'hf5c767); // held C-sharp entire interior yellow
  probe(5,78,320,24'hf5c767); // held black inner indicator
  probe(5,96,444,24'hf5c767); // held black bottom strip
  probe(5,96,340,24'hf5c767); // notation-independent body
  mode=3;target=61;gates=0;
  probe(5,96,320,24'hf5c767);probe(5,78,320,24'hf5c767);
  feedback_note=61;feedback=1;probe(5,78,320,24'h78e6af);probe(5,96,320,24'h78e6af);
  feedback=2;probe(5,78,320,24'he56c79);probe(5,96,320,24'he56c79);
  feedback=0;target=60;mode=0;gates=127;
  probe(1,950,96,24'h10151b);probe(6,192,260,24'h10151b);probe(6,672,224,24'h10151b);
  den=0;repeat(10)tick;capture=1;
  if(dut.degree(60)!=1||dut.degree(62)!=2||dut.degree(71)!=7)$fatal(1,"FAIL notation degrees");
  if(dut.p8_glyph(0,0)==dut.p8_glyph(1,0))$fatal(1,"FAIL distinct Chinese labels");
  if(dut.p8_tab_hit(8,72)!=1||dut.p8_tab_hit(800,119)!=7||dut.p8_tab_hit(1005,119)!=0||dut.p8_tab_hit(144,119)!=0)$fatal(1,"FAIL tab geometry");
  if(dut.p8_header_hit(560,32)!=7||dut.p8_header_hit(687,32)!=7||dut.p8_header_hit(688,32)!=0||dut.p8_header_hit(704,32)!=0||dut.p8_header_hit(1007,32)!=0)$fatal(1,"FAIL compact stop and reserved geometry");
  if(dut.p8_glyph(35,2)!=dut.p8_glyph(dut.digit_label(3),0)||dut.p8_glyph(36,0)!=dut.p8_glyph(dut.digit_label(2),0))$fatal(1,"FAIL XY ratio labels 1:3/2:3");
  for(p=0;p<8;p=p+1)begin
   for(yy=0;yy<600;yy=yy+1)for(xx=0;xx<1024;xx=xx+1)begin
    x=xx;y=yy;page=p;den=1;hs=xx>=1000;vs=yy>=598;tick;
   end
  end
  den=0;hs=0;vs=0;repeat(10)tick;
  for(i=0;i<8;i=i+1)begin
   $fclose(fh[i]);if(count[i]!=614400)$fatal(1,"FAIL page%0d pixels%0d",i,count[i]);
  end
  capture=0;
  for(xx=704;xx<1008;xx=xx+1)probe(0,xx,32,24'h202830);
  probe(0,244,344,24'h10151b);probe(0,244,392,24'h536975);
  if(dut.p8_home_thumb(0)!=244||dut.p8_home_thumb(64)!=514||dut.p8_home_thumb(127)!=780)$fatal(1,"FAIL home thumb endpoints");
  for(i=0;i<128;i=i+1)if(dut.p8_home_thumb(i)!=244+(i*536+63)/127)$fatal(1,"FAIL home thumb exhaustive");
  probe(3,32,496,24'h10151b);probe(3,32,500,24'h536975);
  probe(3,32,548,24'h10151b);probe(3,32,552,24'h536975);
  next=127;mode=0;
  for(yy=224;yy<352;yy=yy+1)for(xx=576;xx<704;xx=xx+1)probe(7,xx,yy,24'h10151b);
  next=64;
  probe(0,16,72,24'h10151b);
  if(dut.p8_thumb(0)!=192||dut.p8_thumb(64)!=515||dut.p8_thumb(127)!=832)$fatal(1,"FAIL exact thumb endpoints");
  for(i=0;i<128;i=i+1)if(dut.p8_thumb(i)!=192+(i*640+63)/127)$fatal(1,"FAIL thumb exhaustive");
  gates=0;probe(0,40,467,24'h1c2a34);
  gates=127;probe(0,40,467,24'h60d9ed);
  mode=1;probe(0,40,467,24'h60d9ed);mode=2;probe(0,40,467,24'h60d9ed);
  mode=0;probe(4,400,368,24'hf5c767);
  valid=0;probe(4,400,368,24'h0d1821);valid=1;
  gates=0;base=48;probe(5,62,535,24'h17202a);
  base=60;probe(5,62,535,24'hffffff);
  mode=2;probe(7,384,128,24'h78e6af);
  mode=3;base=60;gates=0;probe(5,62,494,24'hf5c767);probe(5,40,564,24'hf5c767);
  feedback=1;feedback_note=60;probe(5,62,494,24'h78e6af);probe(5,40,564,24'h78e6af);
  feedback=2;feedback_note=62;probe(5,126,494,24'he56c79);probe(5,120,564,24'he56c79);
  capture=0;
  // All25 outlines stay fixed; every active interior uses the full state color.
  mode=1;gates=0;
  for(kw=0;kw<15;kw=kw+1)begin
   probe(5,32+kw*64,550,24'h36434e);probe(5,33+kw*64,550,24'h36434e);
   probe(5,94+kw*64,550,24'h36434e);probe(5,95+kw*64,550,24'h36434e);
   probe(5,64+kw*64,568,24'h36434e);probe(5,64+kw*64,569,24'h36434e);
   probe(5,64+kw*64,550,24'hffffff);
   case(kw)
    0:kn=60;1:kn=62;2:kn=64;3:kn=65;4:kn=67;5:kn=69;6:kn=71;
    7:kn=72;8:kn=74;9:kn=76;10:kn=77;11:kn=79;12:kn=81;13:kn=83;14:kn=84;
   endcase
   notes[6:0]=kn;gates=1;probe(5,64+kw*64,550,24'hf5c767);
   mode=3;target=kn;probe(5,64+kw*64,460,24'hf5c767);
   feedback=1;feedback_note=kn;probe(5,64+kw*64,550,24'h78e6af);
   feedback=2;probe(5,64+kw*64,550,24'he56c79);
   probe(5,32+kw*64,550,24'h36434e);
   feedback=0;probe(5,64+kw*64,550,24'hf5c767);
   mode=1;probe(5,64+kw*64,550,24'hf5c767);
   gates=0;probe(5,64+kw*64,550,24'hffffff);
  end
  for(kb=0;kb<10;kb=kb+1)begin
   case(kb)
    0:begin kx=76;kn=61;end 1:begin kx=140;kn=63;end
    2:begin kx=268;kn=66;end 3:begin kx=332;kn=68;end 4:begin kx=396;kn=70;end
    5:begin kx=524;kn=73;end 6:begin kx=588;kn=75;end
    7:begin kx=716;kn=78;end 8:begin kx=780;kn=80;end 9:begin kx=844;kn=82;end
   endcase
   mode=1;gates=0;probe(5,kx+20,320,24'h101010);
   probe(5,kx,320,24'h0a1118);probe(5,kx+39,320,24'h0a1118);
   notes[6:0]=kn;gates=1;probe(5,kx+20,320,24'hf5c767);probe(5,kx+2,320,24'hf5c767);
   probe(5,kx+15,379,24'h17202a); // active sharp uses dark ink
   if(kn>=72)probe(5,kx+20,386,24'h17202a); // upper octave dot
   mode=3;target=kn;probe(5,kx+20,320,24'hf5c767);probe(5,kx+2,320,24'hf5c767);
   feedback=1;feedback_note=kn;probe(5,kx+20,320,24'h78e6af);probe(5,kx+20,444,24'h78e6af);
   feedback=2;probe(5,kx+20,320,24'he56c79);probe(5,kx+20,444,24'he56c79);
   // Feedback expires while target+held remain, then target moves and held releases.
   feedback=0;probe(5,kx+20,320,24'hf5c767);
   target=60;mode=1;probe(5,kx+20,320,24'hf5c767);
   gates=0;probe(5,kx+20,320,24'h101010);
  end
  for(i=0;i<7;i=i+1)notes[i*7+:7]=60+i;
  target=60;feedback=0;
  den=0;repeat(10)tick;
  special=1;capture=1;page=5;mode=3;gates=0;base=60;
  for(p=0;p<2;p=p+1)begin
   feedback=p==0?1:2;feedback_note=p==0?60:62;
   fh[5]=$fopen($sformatf("%s/lesson_%0d.ppm",out_dir,p),"wb");
   $fwrite(fh[5],"P6\n1024 600\n255\n");
   for(yy=0;yy<600;yy=yy+1)for(xx=0;xx<1024;xx=xx+1)begin x=xx;y=yy;den=1;tick;end
   den=0;repeat(10)tick;$fclose(fh[5]);
  end
  for(p=0;p<10;p=p+1)begin
   mode=p<4?1:3;gates=0;target=60;feedback=0;feedback_note=60;
   case(p)
    1:gates=127;
    2:begin gates=1;notes[6:0]=60;end
    3:begin gates=1;notes[6:0]=61;end
    4:target=60;
    5:begin target=60;feedback=1;feedback_note=60;end
    6:begin target=60;feedback=2;feedback_note=62;end
    7:target=61;
    8:begin target=61;feedback=1;feedback_note=61;end
    9:begin target=61;feedback=2;feedback_note=61;end
   endcase
   if(p==1)for(i=0;i<7;i=i+1)notes[i*7+:7]=60+i;
   fh[5]=$fopen($sformatf("%s/keyboard_%0d.ppm",out_dir,p),"wb");
   $fwrite(fh[5],"P6\n1024 600\n255\n");
   for(yy=0;yy<600;yy=yy+1)for(xx=0;xx<1024;xx=xx+1)begin x=xx;y=yy;den=1;tick;end
   den=0;repeat(10)tick;$fclose(fh[5]);
  end
  mode=1;gates=0;feedback=0;
  for(kb=0;kb<2;kb=kb+1)begin
   page=kb==0?5:7;
   for(p=0;p<3;p=p+1)begin
    touch_state=p==0?0:p==1?2:3;
    fh[page]=$fopen($sformatf("%s/touch_%0d_%0d.ppm",out_dir,page,p),"wb");
    $fwrite(fh[page],"P6\n1024 600\n255\n");
    for(yy=0;yy<600;yy=yy+1)for(xx=0;xx<1024;xx=xx+1)begin x=xx;y=yy;den=1;tick;end
    den=0;repeat(10)tick;$fclose(fh[page]);
   end
  end
  page=5;mode=1;touch_state=0;feedback=0;
  for(p=0;p<7;p=p+1)begin
   pattern_mode=(p%3)+1;pattern_selected=p==6?0:p>=4?127:3;
   for(i=0;i<7;i=i+1)pattern_notes[i*7+:7]=60+i;
   pattern_count=p>=4&&p<6?7:p==6?0:2;pattern_full=p==5;
   pattern_busy=p==3||p==5;gates=0;
   if(p==3)begin gates=1;notes[6:0]=60;end
   if(p==5)begin gates=1;notes[6:0]=61;end
   fh[5]=$fopen($sformatf("%s/pattern_%0d.ppm",out_dir,p),"wb");
   $fwrite(fh[5],"P6\n1024 600\n255\n");
   for(yy=0;yy<600;yy=yy+1)for(xx=0;xx<1024;xx=xx+1)begin x=xx;y=yy;den=1;tick;end
   den=0;repeat(10)tick;$fclose(fh[5]);
  end
  $display("PASS P8 panel 8 diagnostic pages plus12 keyboard state frames,6 touch-state frames,7 pattern frames; %0d cycle sync checks; dynamic gain/PCM/modes/lower dots;128 exact HOME strip positions; all25key outlines+full-body held/target/correct/wrong/recovery and dark black notation; C4/C5/C6; guide/replay/labels/geometry; touch disconnected/connectedreleased/pressed; pattern3modes/selected/sounding/busy/count/full",checks);$finish;
 end
endmodule


