`timescale 1ns/1ps
module tb_xy_motion_20261025_green;
 parameter P=64;
 reg clk=0,pclk=0,rst=1,prstn=0,tick=0,frame=0,active=1,ticks_enabled=1;
 reg[23:0] step=1048576;reg[15:0] env=50000,addr=0;reg[5:0] cfg=8;
 wire data,valid;wire[5:0] shown;
 dynamic_xy #(.POINTS(P)) dut(.clk(clk),.rst(rst),.sample_tick(tick),.active(active),.note_step(step),.envelope(env),.requested_config(cfg),.pixel_clk(pclk),.pixel_rstn(prstn),.frame_start(frame),.read_addr(addr),.data(data),.valid(valid),.shown_config(shown));
 always #5 clk=~clk;always #7 pclk=~pclk;
 integer render_start=0,max_render_cycles=0; integer cyc=0,checks=0,f=0,i,j,r,a,n,fd,meta;reg oldbank;reg[5:0] cfg_hold;reg[23:0] phase_hold,head_hold;reg[15:0] env_hold;reg active_hold,tracking=0;
 always @(negedge clk)begin cyc=cyc+1;tick=!rst&&ticks_enabled&&cyc%32==0;end
 always @(posedge clk)begin
  if(!rst)begin if(dut.state==0&&dut.clear_addr==0)render_start=cyc; if(dut.state==6&&cyc-render_start>max_render_cycles)max_render_cycles=cyc-render_start;
   if(valid&&(dut.state==0||dut.state==5)&&dut.bank==dut.display_bank)$fatal(1,"write displayed bank");
   if(dut.state==0&&dut.clear_addr==1)begin cfg_hold=dut.settings;phase_hold=dut.frame_phase;head_hold=dut.frame_head;env_hold=dut.frame_envelope;active_hold=dut.frame_active;tracking=1;end
   if(tracking&&!(dut.state==0&&dut.clear_addr==0))begin
    if(dut.settings!==cfg_hold||dut.frame_phase!==phase_hold||dut.frame_head!==head_hold||dut.frame_envelope!==env_hold||dut.frame_active!==active_hold)$fatal(1,"frame controls torn");
   end
  end else tracking=0;
 end
 reg lastbank=0;reg[5:0] lastshown=0;
 always @(posedge pclk)begin
  #1;if(prstn&&((dut.display_bank!=lastbank)||(shown!=lastshown))&&!frame)$fatal(1,"pixel bank/cfg switched outside boundary");lastbank=dut.display_bank;lastshown=shown;
 end
 task capture(input integer scenario);
 integer k,ones;begin
 wait(dut.state==7);repeat(5)@(negedge pclk);oldbank=dut.display_bank;frame=1;@(negedge pclk);frame=0;wait(dut.display_bank!=oldbank);
 if(shown!==dut.settings)$fatal(1,"published settings mismatch");
 fd=$fopen($sformatf("frame_%03d.bits",f),"w");ones=0;
 for(k=0;k<65536;k=k+1)begin
 if(dut.bitmap[{dut.display_bank,k[15:0]}]!==0&&dut.bitmap[{dut.display_bank,k[15:0]}]!==1)$fatal(1,"unknown pixel");
 $fwrite(fd,"%b",dut.bitmap[{dut.display_bank,k[15:0]}]);if(dut.bitmap[{dut.display_bank,k[15:0]}])ones=ones+1;
 end
 $fclose(fd);
 $fwrite(meta,"%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d\n",f,scenario,P,dut.settings,dut.frame_phase,dut.frame_head,dut.frame_envelope,dut.frame_active,step,ones);
 // Check the actual synchronous pixel read port while publication stalls.
 for(k=0;k<16;k=k+1)begin @(negedge pclk);addr=(k*4051)%65536;@(negedge pclk);if(data!==dut.bitmap[{dut.display_bank,addr}])$fatal(1,"pixel read port mismatch");end
 checks=checks+65552;f=f+1;wait(dut.state!=7);
 end endtask
 initial begin
 meta=$fopen("frames.csv","w");$fwrite(meta,"frame,scenario,points,cfg,phase,head,envelope,active,step,ones\n");
 repeat(6)@(negedge clk);rst=0;prstn=1;
 // All twenty exact fixed ratio/angle combinations; published pairs must move.
 for(a=0;a<5;a=a+1)for(r=0;r<4;r=r+1)begin
 cfg=a*4+r;step=(r%2)?24'd1048576:24'd37800;capture(a*4+r);capture(a*4+r);capture(a*4+r);
 end
 // Low and high notes, fixed and automatic phase, held envelope.
 for(n=0;n<4;n=n+1)begin
 cfg=n[0]?6'd40:6'd8;step=n<2?24'd37800:24'd1048576;
 capture(30+n);capture(30+n);capture(30+n);capture(30+n);
 end
 // Deliberately change controls during render and while waiting for ACK.
 cfg=6'd3;capture(40);wait(dut.state==5);cfg=6'd16;env=65535;step=24'd151183;
 wait(dut.state==7);cfg=6'd9;env=1;repeat(5000)@(negedge clk);capture(41);capture(42);capture(42);
 // Inactive and zero step must become completely blank without deadlock.
 active=0;capture(50);capture(50);capture(50);
 active=1;step=0;capture(51);capture(51);
 step=24'd1048576;env=65535;cfg=0;capture(52);capture(52);capture(52);
 // Parent reset contract: both domains reset together, including ACK stall.
 wait(dut.state==7);rst=1;prstn=0;repeat(6)@(negedge clk);if(valid||shown!=0)$fatal(1,"reset publications");rst=0;prstn=1;capture(60);capture(60);
 cfg=8;step=1048576;env=65535;wait(dut.base_phase==24'h400000);ticks_enabled=0;capture(70);capture(70);capture(70);ticks_enabled=1;wait(dut.base_phase==24'hc00000);ticks_enabled=0;capture(71);capture(71);capture(71);ticks_enabled=1;wait(dut.base_phase==0);ticks_enabled=0;capture(72);capture(72);capture(72);ticks_enabled=1;wait(dut.base_phase==24'h800000);ticks_enabled=0;capture(73);capture(73);capture(73);$display("XY_RENDER_MAX_CYCLES=%0d",max_render_cycles);$fclose(meta);$display("XY_MOTION_GREEN_PASS P=%0d frames=%0d checks=%0d all20 low/high fixed/auto controls coherent ACK-stall blank reset pixel-port",P,f,checks);$finish;
 end
 initial begin #300000000;$fatal(1,"green timeout");end
endmodule



