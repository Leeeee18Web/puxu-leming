`timescale 1ns/1ps
module voice_local_masks #(parameter N=7,PEDAL=1)(output reg done=0);
 reg [N-1:0] m,f,t,p;integer i,seed=93+N+PEDAL,checks=0;
 final_voice_control #(.VOICE_COUNT(N),.ENABLE_PEDAL(PEDAL)) dut(.clk(1'b0),.rst(1'b0),.sample_tick(1'b0),.event_valid(1'b0),.event_data(32'd0),.event_ready(),
 .panic(1'b0),.centre(1'b0),.pedal_down(1'b0),.timbre_select(3'd0),.voice_active({N{1'b0}}),
 .timbres(),.gates(),.notes(),.gains(),.triggers(),.ratio(),.knob(),.last_note(),.last_velocity(),
 .mod_depth(),.knob_mode(2'd0),.raw_knob(),.raw_known(),.pickup_wait(),.event_source(2'd0),
 .map_notes(175'd0),.map_input_base(7'd48),.map_enabled(1'b0),.map_apply(1'b0),.key_seen_valid(),.key_seen_index(),.ready_raw());
 final_voice_control_local_reference #(.VOICE_COUNT(N),.ENABLE_PEDAL(PEDAL)) ref_old(.clk(1'b0),.rst(1'b0),.sample_tick(1'b0),.event_valid(1'b0),.event_data(32'd0),.event_ready(),
 .panic(1'b0),.centre(1'b0),.pedal_down(1'b0),.timbre_select(3'd0),.voice_active({N{1'b0}}),
 .timbres(),.gates(),.notes(),.gains(),.triggers(),.ratio(),.knob(),.last_note(),.last_velocity(),
 .mod_depth(),.knob_mode(2'd0),.raw_knob(),.raw_known(),.pickup_wait(),.event_source(2'd0),
 .map_notes(175'd0),.map_input_base(7'd48),.map_enabled(1'b0),.map_apply(1'b0),.key_seen_valid(),.key_seen_index());
 initial begin
  force dut.match_slots=m;force dut.free_slots=f;force dut.oldest_tails=t;force dut.oldest_pedals=p;
  force ref_old.match_slots=m;force ref_old.free_slots=f;force ref_old.oldest_tails=t;force ref_old.oldest_pedals=p;
  // N4 exhausts all four masks. N7 exhausts match/free pairs with random
  // tail/pedal masks; N25 samples independent wide masks and one-hot gaps.
  for(i=0;i<((N==4)?65536:((N==7)?16384:40000));i=i+1)begin
   if(N==4)begin m=i;f=i>>4;t=i>>8;p=i>>12;end
   else if(N==7)begin m=i;f=i>>7;t=$random(seed);p=$random(seed);end
   else begin m=$random(seed);f=$random(seed);t=$random(seed);p=$random(seed);end
   #1;checks=checks+1;if(dut.selected_present!==( |ref_old.selected_slots))$fatal(1,"VOICE_CLASS_REDUCTION N%0d",N);if(dut.selected_slots!==ref_old.selected_slots)$fatal(1,"MASK N%0d pedal%0d m%h f%h t%h p%h",N,PEDAL,m,f,t,p);
  end
  // Empty higher classes expose every lower-class bit and tie position.
  for(i=0;i<4*N*N;i=i+1)begin
   m=0;f=0;t=0;p=0;
   case(i/(N*N))
    0:m=(1<<(i%N))|(1<<((i/N)%N));
    1:f=(1<<(i%N))|(1<<((i/N)%N));
    2:t=(1<<(i%N))|(1<<((i/N)%N));
    3:p=(1<<(i%N))|(1<<((i/N)%N));
   endcase
   #1;checks=checks+1;if(dut.selected_present!==( |ref_old.selected_slots))$fatal(1,"VOICE_CLASS_REDUCTION N%0d",N);if(dut.selected_slots!==ref_old.selected_slots)$fatal(1,"MASK_GAP N%0d i%0d",N,i);
  end
  $display("PASS VOICE_MASKS N%0d pedal%0d checks%0d",N,PEDAL,checks);done=1;
 end
endmodule
module tb_voice_control_local_masks;
 wire [3:0] done;
 voice_local_masks #(.N(7)) c7(done[0]);voice_local_masks #(.N(4)) c4(done[1]);
 voice_local_masks #(.N(25)) c25(done[2]);voice_local_masks #(.N(4),.PEDAL(0)) c4legacy(done[3]);
 initial begin wait(&done);$display("PASS VOICE_MASKS_ALL");$finish;end
endmodule
