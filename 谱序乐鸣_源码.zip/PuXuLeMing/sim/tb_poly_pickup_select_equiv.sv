`timescale 1ns/1ps
module tb_poly_pickup_select_equiv;
 `include "src/poly/poly_model_layout.vh"
 reg clk=0;always #10 clk=~clk;reg[23:0]step=0;
 poly_model_line #(.PRECALC_PICKUP(1)) dut(
 .clk(clk),.rst(1'b0),.tick(1'b0),.trigger(1'b0),.gate(1'b1),.kind(3'd1),.velocity(12'd2400),.step(step),.rate_shift(2'd0),.period_q10(24'd100000),.sample(),.envelope(),.busy(),.deadline_error(),.bridge_return(18'sd0),.bridge_incident(),.piano_mode(1'b1),.bridge_incident_next(),.ctx_enable(1'b0),.ctx_load(1'b0),.ctx_data({`POLY_MODEL_LINE_W{1'b0}}),.ctx_state(),.mem_q(18'd0),.mem_raddr(),.mem_waddr(),.mem_we(),.mem_data(),.shared_tuning(16'd0),.shared_impact(18'sd0),.impact_phase());
 poly_line_before_enable reference(
 .clk(clk),.rst(1'b0),.tick(1'b0),.trigger(1'b0),.gate(1'b1),.kind(3'd1),.velocity(12'd2400),.step(step),.rate_shift(2'd0),.period_q10(24'd100000),.sample(),.envelope(),.busy(),.deadline_error(),.bridge_return(18'sd0),.bridge_incident(),.piano_mode(1'b1),.bridge_incident_next(),.ctx_enable(1'b0),.ctx_load(1'b0),.ctx_data({`POLY_MODEL_LINE_W{1'b0}}),.ctx_state(),.mem_q(18'd0),.mem_raddr(),.mem_waddr(),.mem_we(),.mem_data(),.shared_tuning(16'd0),.shared_impact(18'sd0),.impact_phase());
 integer i,b,d,checks=0,seed=32'h2ac71;reg[7:0]seen=0;
 task check;begin @(posedge clk);#1;if(dut.dc_shift!==reference.dc_shift)$fatal(1,"PICKUP_SELECT_EQ step%0d got%0d want%0d",step,dut.dc_shift,reference.dc_shift);seen[dut.dc_shift-3]=1;checks++;@(negedge clk);end endtask
 initial begin
  for(b=15;b<=21;b++)for(d=-1;d<=1;d++)begin step=(1<<b)+d;check;end
  step=0;check;step=24'hffffff;check;
  for(i=0;i<10000;i++)begin step=$random(seed);check;end
  if(seen!==8'hff)$fatal(1,"PICKUP_SELECT_COVERAGE %b",seen);
  $display("PICKUP_SELECT_EQ_PASS checks%0d all8original thresholds edgeMinus1/equal/plus1 random24bit no arithmetic changes",checks);$finish;
 end
endmodule
