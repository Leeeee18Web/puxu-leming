`timescale 1ns/1ps
module final_audio_allocator_tb;
 reg clk=0;always #10 clk=~clk;reg rst=1;
 reg event_valid=0;reg [31:0] event_data=0;reg [2:0] timbre_select=0;
 wire [3:0] gates,triggers,active;wire [27:0] notes;wire [47:0] gains;wire [11:0] timbres;
 wire sample_tick;wire signed [15:0] pcm;wire hp_bck,hp_ws,hp_din,i2s_bck,i2s_ws,i2s_sd;
 wire [95:0] monitor_steps;wire [63:0] monitor_envelopes;wire deadline_error,clip_active;
 wire [18:0] ratio=262144;wire [6:0] mod_depth=0;wire [31:0] synth_config=0;
 final_audio audio(.*);
 final_voice_control control(.clk(clk),.rst(rst),.sample_tick(sample_tick),.event_valid(event_valid),.event_data(event_data),.timbre_select(timbre_select),.voice_active(active),.event_ready(),.panic(1'b0),.centre(1'b0),.gates(gates),.triggers(triggers),.notes(notes),.gains(gains),.timbres(timbres),.ratio(),.knob(),.last_note(),.last_velocity(),.mod_depth(),.knob_mode(2'd0),.raw_knob(),.raw_known(),.pickup_wait(),.ready_raw());
 task check(input bit ok,input string msg);if(!ok)$fatal(1,"%s",msg);endtask
 task event_send(input bit source,input [7:0] status,input [6:0] d1,d2);begin
  @(negedge clk);event_data={7'd0,source,1'b0,d2,1'b0,d1,status};event_valid=1;
  @(negedge clk);event_valid=0;@(negedge clk);
 end endtask
 task frames(input integer n);integer k;begin for(k=0;k<n;k=k+1)begin @(negedge clk);while(!sample_tick)@(negedge clk);end end endtask
 reg [27:0] original;integer i;
 always @(posedge clk)if(!rst&&deadline_error)$fatal(1,"integrated render deadline");
 initial begin
  repeat(6)@(negedge clk);rst=0;
  for(i=0;i<4;i=i+1)begin timbre_select=i;event_send(i%2,8'h90|i,60+i*3,80);end
  frames(256);check(active==4'hf&&gates==4'hf,"four actual held renderer slots");original=notes;
  event_send(0,8'h90,100,100);frames(128);check(notes==original&&active==4'hf,"fifth actual held note rejected without loss");
  event_send(1,8'h81,63,0);frames(8);check(!gates[1]&&active[1],"actual released voice tail retained");
  timbre_select=3;event_send(1,8'h91,75,100);frames(128);check(gates==4'hf&&notes[13:7]==75&&active==4'hf,"actual busy tail reclaimed and remains globally four");
  event_send(1,8'h81,63,0);check(gates[1],"stale old off cannot kill replaced actual sound");
  event_send(0,8'hb2,64,127);event_send(0,8'h82,66,0);frames(8);check(gates[2],"actual pedal holds only owned channel");
  event_send(1,8'hb2,64,0);check(gates[2],"virtual pedal cannot release physical owner");
  event_send(0,8'hb2,64,0);check(!gates[2],"actual pedal release starts tail");
  event_send(0,8'hff,0,0);frames(4);check(!active[0]&&!active[2]&&active[1]&&active[3],"actual USB urgent mute isolates virtual sound");
  $display("PASS final_audio_allocator_tb actual sound four/fifth/off/tail/sustain/disconnect");$finish;
 end
endmodule
