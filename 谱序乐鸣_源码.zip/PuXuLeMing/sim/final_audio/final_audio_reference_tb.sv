`timescale 1ns/1ps
module final_audio_reference_tb;
 reg clk=0;always #10 clk=~clk;reg rst=1;reg [3:0] gates=0,triggers=0;reg [27:0] notes=0;
 reg [47:0] gains=0;reg [11:0] timbres=0;reg [18:0] ratio=262144;reg [6:0] mod_depth=0;reg [31:0] synth_config=0;
 wire sample_tick;wire signed [15:0] pcm;wire hp_bck,hp_ws,hp_din,i2s_bck,i2s_ws,i2s_sd;
 wire [3:0] active;wire [95:0] monitor_steps;wire [63:0] monitor_envelopes;wire deadline_error,clip_active;
 final_audio dut(.pcm_positive(),.*);
 wire signed [15:0] reference_pcm;wire reference_tick,hb,hw,hd,ib,iw,id;
 play_audio baseline(.clk(clk),.rst(rst),.gates({3'd0,gates}),.triggers({3'd0,triggers}),.notes({21'd0,notes}),.gains({36'd0,gains}),.ratio(ratio),.mod_depth(mod_depth),.sample_tick(reference_tick),.pcm(reference_pcm),.hp_bck(hb),.hp_ws(hw),.hp_din(hd),.i2s_bck(ib),.i2s_ws(iw),.i2s_sd(id),.active(),.monitor_steps(),.monitor_envelopes());
 integer checks=0;
 always @(posedge clk)if(!rst)begin
  if({pcm,sample_tick,hp_bck,hp_ws,hp_din,i2s_bck,i2s_ws,i2s_sd}!=={reference_pcm,reference_tick,hb,hw,hd,ib,iw,id})$fatal(1,"piano baseline mismatch");
  if(deadline_error)$fatal(1,"render deadline missed");checks=checks+1;
 end
 task frames(input integer n);integer i;begin for(i=0;i<n;i=i+1)begin @(negedge clk);while(!sample_tick)@(negedge clk);end end endtask
 initial begin repeat(6)@(negedge clk);rst=0;gates=1;notes[6:0]=60;gains[11:0]=3200;triggers=1;
  @(negedge clk);triggers=0;frames(512);gates=4'hf;notes={7'd72,7'd67,7'd64,7'd60};gains={12'd600,12'd700,12'd800,12'd3200};triggers=4'b1110;@(negedge clk);triggers=0;frames(512);synth_config=32'hffffffff;ratio=392772;frames(256);mod_depth=127;frames(256);gates=0;frames(512);
  $display("PASS final_audio_reference_tb exact pcm+I2S+PT8211 clocks=%0d incl bend/mod/release",checks);$finish;
 end
endmodule
