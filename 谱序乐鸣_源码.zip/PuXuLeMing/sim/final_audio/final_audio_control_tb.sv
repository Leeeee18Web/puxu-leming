`timescale 1ns/1ps
module final_audio_control_tb;
 reg clk=0;always #10 clk=~clk;
 reg rst=1,sample_tick=0,event_valid=0,panic=0,centre=0;reg [31:0] event_data=0;
 reg [2:0] timbre_select=0;reg [3:0] voice_active=0;reg [1:0] knob_mode=1;
 wire event_ready;wire [3:0] gates,triggers;wire [27:0] notes;wire [47:0] gains;wire [11:0] timbres;
 wire [18:0] ratio;wire [6:0] knob,last_note,last_velocity,mod_depth,raw_knob;wire raw_known,pickup_wait;
 final_voice_control #(.RELATIVE_KNOB(1)) dut(.event_source(2'd0),.map_notes(175'd0),.map_input_base(7'd60),.map_enabled(1'b0),.map_apply(1'b0),.key_seen_valid(),.key_seen_index(),.pedal_down(1'b0),.*,.ready_raw());
 wire [18:0] reference_ratio;wire [6:0] reference_knob,reference_raw;wire reference_known,reference_pickup;
 play_voice_control #(.RELATIVE_KNOB(1)) reference(.clk(clk),.rst(rst),.sample_tick(sample_tick),.event_valid(event_valid),.event_data(event_data),.event_ready(),.panic(panic),.centre(centre),.gates(),.notes(),.gains(),.triggers(),.ratio(reference_ratio),.knob(reference_knob),.last_note(),.last_velocity(),.mod_depth(),.knob_mode(knob_mode),.raw_knob(reference_raw),.raw_known(reference_known),.pickup_wait(reference_pickup));
 task check(input bit ok,input string msg);if(!ok)$fatal(1,"%s",msg);endtask
 task event_send(input bit source,input [7:0] status,input [6:0] d1,d2);begin
  @(negedge clk);event_data={7'd0,source,1'b0,d2,1'b0,d1,status};event_valid=1;
  @(negedge clk);event_valid=0;@(negedge clk);
 end endtask
 task tick;begin @(negedge clk);sample_tick=1;@(negedge clk);sample_tick=0;@(negedge clk);end endtask
 integer i,j,count;reg [27:0] before_notes;
 initial begin
  repeat(5)@(negedge clk);rst=0;
  for(i=0;i<4;i=i+1)begin timbre_select=i;event_send(i%2,8'h90|i,60+i,100);end
  check(gates==4'hf,"four held tuples allocated");before_notes=notes;voice_active=4'hf;
  event_send(0,8'h90,100,110);check(notes==before_notes&&gates==4'hf,"fifth held note must reject");
  timbre_select=2;event_send(0,8'h90,60,101);check(notes==before_notes&&gains[11:0]==3232&&timbres[2:0]==2,"same tuple retriggers slot");
  event_send(1,8'h81,61,0);check(!gates[1],"independent source channel release");
  event_send(0,8'h90,101,90);check(notes[13:7]==101&&gates==4'hf,"released active tail reclaimed first");
  event_send(1,8'h81,61,0);check(gates[1],"stale off cannot kill replacement");
  event_send(0,8'hb2,64,127);event_send(0,8'h82,62,0);check(gates[2],"sustain retains owner channel note");
  event_send(1,8'hb2,64,0);check(gates[2],"other source pedal isolated");
  event_send(0,8'hb2,64,0);check(!gates[2],"pedal release closes unheld note");
  event_send(0,8'h92,62,90);check(gates[2]&&notes[20:14]==62,"released existing tuple retriggers own slot");
  event_send(0,8'hff,0,0);
  for(i=0;i<4;i=i+1)if(i!=3)check(!gates[i]&&gains[i*12+:12]==0,"USB disconnect isolated mute");else check(gates[i],"virtual ownership survives disconnect");
  for(j=0;j<3;j=j+1)begin knob_mode=j;
   for(i=0;i<128;i=i+7)begin event_send(0,8'hb0,74,i);repeat(3)tick;
    check({ratio,knob,raw_knob,raw_known,pickup_wait}=={reference_ratio,reference_knob,reference_raw,reference_known,reference_pickup},"knob mode exact legacy behavior");end
  end
  event_send(0,8'he0,0,127);repeat(300)tick;check(ratio==reference_ratio,"smoothed bend preserved");
  @(negedge clk);panic=1;@(negedge clk);panic=0;check(gates==0&&gains==0,"panic four");
  $display("PASS final_audio_control_tb four tuples, timbre, fifth reject, tail reclaim, staleoff, sustain, disconnect, all knob modes");$finish;
 end
endmodule
