`timescale 1ns/1ps
module final_audio_preset_tb;
 reg clk=0;always #10 clk=~clk;reg rst=1,render_tick=0;
 reg [3:0] gates=0,triggers=0;reg [95:0] steps=0;reg [47:0] gains=0;reg [11:0] timbres=0;
 wire [63:0] fixed_samples,stale_samples,fixed_envelopes,stale_envelopes;
 wire [3:0] fixed_active,stale_active;wire fixed_busy,stale_busy,fixed_deadline,stale_deadline;
 final_modal_bank fixed_preset(.clk(clk),.rst(rst),.render_tick(render_tick),.gates(gates),.triggers(triggers),.steps(steps),.gains(gains),.timbres(timbres),.adsr_cfg(160'd0),.samples(fixed_samples),.active(fixed_active),.envelopes(fixed_envelopes),.busy(fixed_busy),.deadline_error(fixed_deadline));
 // Simulates a stale recording/configuration requesting zeroA/maxS/zeroR.
 final_modal_bank stale_custom(.clk(clk),.rst(rst),.render_tick(render_tick),.gates(gates),.triggers(triggers),.steps(steps),.gains(gains),.timbres(timbres),.adsr_cfg({32'd0,32'd65535,32'd0,32'd0,32'd1}),.samples(stale_samples),.active(stale_active),.envelopes(stale_envelopes),.busy(stale_busy),.deadline_error(stale_deadline));
 integer i,checks=0;reg [3:0] audible=0;reg release_pcm=0;
 task frame;begin @(negedge clk);render_tick=1;@(negedge clk);render_tick=0;repeat(1022)@(negedge clk);end endtask
 always @(posedge clk)if(!rst)begin
  if({fixed_samples,fixed_envelopes,fixed_active}!={stale_samples,stale_envelopes,stale_active})$fatal(1,"preset-only requirement: stale custom ADSR must not change actual envelope/PCM");
  if(fixed_deadline||stale_deadline)$fatal(1,"preset renderer deadline");checks=checks+1;
 end
 initial begin
  for(i=0;i<4;i=i+1)begin steps[i*24+:24]=90000+i*1000;gains[i*12+:12]=1000;timbres[i*3+:3]=1+i%3;end
  repeat(6)@(negedge clk);rst=0;repeat(6)@(negedge clk);gates=4'hf;triggers=gates;
  frame;triggers=0;
  repeat(128)begin frame;for(i=0;i<4;i=i+1)if($signed(fixed_samples[i*16+:16])!=0)audible[i]=1;end
  if(audible!=4'hf)$fatal(1,"allfour preset voices actually audible");
  gates=0;repeat(64)begin frame;if(fixed_samples!=0)release_pcm=1;end
  if(!release_pcm)$fatal(1,"fixed preset release must remain natural");
  $display("PASS final_audio_preset_tb staleADSRignored actualPCM exact checks=%0d allfour three modal presets naturalrelease",checks);$finish;
 end
endmodule
