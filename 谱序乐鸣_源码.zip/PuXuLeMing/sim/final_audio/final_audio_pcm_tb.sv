`timescale 1ns/1ps
module final_audio_pcm_tb;
 reg clk=0;always #10 clk=~clk;reg rst=1;
 reg [3:0] gates=0,triggers=0;reg [27:0] notes=0;reg [47:0] gains=0;reg [11:0] timbres=0;
 reg [18:0] ratio=262144;reg [6:0] mod_depth=0;reg [31:0] synth_config=0;
 wire sample_tick;wire signed [15:0] pcm;wire hp_bck,hp_ws,hp_din,i2s_bck,i2s_ws,i2s_sd;
 wire [3:0] active;wire [95:0] monitor_steps;wire [63:0] monitor_envelopes;wire deadline_error,clip_active;
 final_audio dut(.pcm_positive(),.*);
 integer i,j,k,fd,cycles=0,last_tick=0,start=0,max_busy=0,nonzero=0;reg [3:0] contributed=0;
 task check(input bit ok,input string msg);if(!ok)$fatal(1,"%s",msg);endtask
 task frame;begin @(negedge clk);while(!sample_tick)@(negedge clk);end endtask
 task reset;begin @(negedge clk);rst=1;gates=0;triggers=0;notes=0;gains=0;timbres=0;repeat(6)@(negedge clk);rst=0;last_tick=0;start=0;end endtask
 always @(posedge clk)begin
  cycles=cycles+1;
  if(!rst)begin
   if(sample_tick)begin
    if(last_tick!=0)check(cycles-last_tick==1024,"exact sample period");last_tick=cycles;
    check(!deadline_error,"piano and modal shared service deadlines");
   end
   if(dut.render_tick)start=cycles;
   if(start!=0&&!dut.modal_busy&&cycles-start>2)begin
    check(cycles-start<=89,"four modal slots finish in 88 work clocks");
    if(cycles-start>max_busy)max_busy=cycles-start;start=0;
   end
  end
 end
 initial begin
  for(j=0;j<4;j=j+1)begin
   reset;gates=1;notes[6:0]=60;gains[11:0]=3200;timbres[2:0]=j;triggers=1;@(negedge clk);triggers=0;
   fd=$fopen($sformatf("final_audio_%0d.pcm",j),"w");nonzero=0;
   for(k=0;k<8192;k=k+1)begin frame;$fdisplay(fd,"%0d",pcm);if(pcm!=0)nonzero=nonzero+1;end
   $fclose(fd);check(nonzero>6000,"each of four tones produces real PCM");check(active[0],"tone active");
   $display("PASS timbre%0d nonzero=%0d",j,nonzero);
   gates=0;repeat(j==0?24000:7000)frame;check(active==0,"fixed instrument release completes");
  end
  reset;gates=4'hf;triggers=4'hf;notes={7'd72,7'd67,7'd64,7'd60};
  timbres={3'd3,3'd2,3'd1,3'd0};gains={12'd800,12'd800,12'd800,12'd800};
  @(negedge clk);triggers=0;repeat(256)frame;
  check(active==4'hf,"four distinct mixed tones active together");
  fd=$fopen("final_audio_summary.txt","w");
  for(k=0;k<8192;k=k+1)begin
   frame;$fwrite(fd,"%0d",pcm);
   for(i=0;i<4;i=i+1)begin
    if(dut.selected[i]!=0)contributed[i]=1;
    $fwrite(fd,",%0d",dut.selected[i]);
   end
   $fwrite(fd,"\n");
  end
  $fclose(fd);check(contributed==4'hf,"all four independent PCM slots contribute");check(!clip_active,"mixed fixture unclipped");
  check(monitor_steps[23:0]!=monitor_steps[47:24]&&monitor_steps[47:24]!=monitor_steps[71:48]&&monitor_steps[71:48]!=monitor_steps[95:72],"all four independent frequency steps");
  gates[1]=0;repeat(32)frame;check(active==4'hf&&gates==4'b1101,"one independent note-off preserves other held and released tail");
  gates[1]=1;notes[13:7]=69;timbres[5:3]=2;triggers[1]=1;@(negedge clk);triggers=0;repeat(128)frame;
  check(active==4'hf,"released tail replacement stays four slots");
  gates=0;repeat(24000)frame;check(active==0,"mixed four natural releases finish");
  $display("PASS final_audio_pcm_tb four tones and independent notes, mixed/release/reclaim, max_modal_cycles=%0d",max_busy);$finish;
 end
 initial begin #4000000000;$fatal(1,"PCM timeout");end
endmodule
