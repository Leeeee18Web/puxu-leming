`timescale 1ns/1ps
module tb_k1_audio;
 reg clk=0,rstn=0,key1_n=1;always #10 clk=~clk;
 tri dp,dm;
 hub_play_top dut(.clk(clk),.rstn(rstn),.key1_n(key1_n),.key2_n(1'b1),.uart_rx(1'b1),.usb_dp(dp),.usb_dm(dm),
 .uart_tx(),.hp_bck(),.hp_ws(),.hp_din(),.pa_en(),.i2s_bck(),.i2s_ws(),.i2s_sd(),.led_o(),
 .tmds_clk_p_0(),.tmds_clk_n_0(),.tmds_d_p_0(),.tmds_d_n_0());
 defparam dut.status_bridge.PERIOD=10;defparam dut.pedal_button.TICKS=4;
 integer checks=0,t,n,s,nz=0,peak=0,previous_nz;reg[15:0]old_env;
 task check(input bit ok,input string why);begin checks++;if(!ok)$fatal(1,"K1_AUDIO_FAIL %s",why);end endtask
 task waitclks(input integer n);repeat(n)@(negedge clk);endtask
 task frames(input integer n);repeat(n)begin @(posedge dut.sample_tick);@(negedge clk);end endtask
 task touch(input integer x,y,input bit down);begin dut.soc.hid_report(x,y,down,1);waitclks(40);end endtask
 task tap(input integer x,y);begin touch(x,y,0);touch(x,y,1);touch(x,y,0);end endtask
 task ev(input[31:0]w);begin dut.soc.midi_event(w);waitclks(100);end endtask
 always @(posedge clk)if(!dut.rst&&dut.sample_tick)begin
  check(!dut.audio_deadline_error,"audio sample deadline");
  check(!dut.audio_clip,"seven voice pedal mix headroom");
  if(dut.pcm!=0)nz++;
  if($signed(dut.pcm)>peak)peak=$signed(dut.pcm);
  if(-$signed(dut.pcm)>peak)peak=-$signed(dut.pcm);
 end
 initial begin
  waitclks(20);rstn=1;waitclks(2000);dut.soc.ptest_debug[255:224]=32'h0c;waitclks(100);tap(300,280);tap(650,96);
  for(t=1;t<=4;t++)begin
   tap(800,32);tap(800,94+44*(t-1));check(dut.timbre_select==t,"actual timbre menu");
   key1_n=0;waitclks(100);previous_nz=nz;
   for(n=0;n<10;n++)begin
    ev((32'd100<<16)|((32'd60+n)<<8)|32'h90);frames(40);
    check(dut.last_note==60+n,"new pedal melody note admitted after four slots");
    ev(((32'd60+n)<<8)|32'h80);frames(2);check(dut.live_gates!=0,"audio gates remain after finger release");
   end
   check(nz>previous_nz+100,"sustained voice produces nonzero PCM");
   frames(150);s=0;for(n=0;n<7;n++)if(dut.live_notes[n*7+:7]==69)s=n;
   old_env=dut.monitor_envelopes[s*16+:16];key1_n=1;waitclks(100);frames(80);
   check(dut.live_gates==0&&dut.live_gains!=0,"pedal release uses damping not zero gain");
   check(dut.monitor_envelopes[s*16+:16]<old_env,"actual envelope decays after pedal release");
   tap(440,32);frames(3);tap(440,32);frames(3);
  end
  $display("K1_AUDIO_PASS checks=%0d nonzero=%0d peak=%0d",checks,nz,peak);$finish;
 end
 initial begin #100000000;$fatal(1,"K1_AUDIO_FAIL timeout");end
endmodule
