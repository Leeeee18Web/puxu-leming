`timescale 1ns/1ps
module tb_play_voice_control;
 reg clk=0; always #10 clk=~clk;
 reg rst=1,sample_tick=0,event_valid=0,panic=0,centre=0;
 reg [31:0] event_data=0;
 wire event_ready; wire [6:0] gates,triggers,knob,last_note,last_velocity,mod_depth;
 wire [48:0] notes; wire [83:0] gains; wire [18:0] ratio;
 wire [1:0] knob_mode=1;wire [6:0] raw_knob;wire raw_known,pickup_wait;
 play_voice_control dut(.*);
 integer i,j,n,oldslot; reg [18:0] before_ratio;
 task check(input bit ok,input string msg); begin if(!ok)$fatal(1,"%s",msg);end endtask
 task event_send(input bit src,input [7:0] st,input [7:0] d1,input [7:0] d2);
 begin @(negedge clk);event_data={7'd0,src,d2,d1,st};event_valid=1;@(negedge clk);event_valid=0;end endtask
 function integer count; input [6:0] g;integer k;begin count=0;for(k=0;k<7;k=k+1)count=count+g[k];end endfunction
 task ticks(input integer amount);integer k;begin for(k=0;k<amount;k=k+1)begin @(negedge clk);sample_tick=1;@(negedge clk);sample_tick=0;end end endtask
 task reset;begin @(negedge clk);rst=1;repeat(3)@(negedge clk);rst=0;end endtask
 initial begin
 reset();check(event_ready&&gates==0&&ratio==262144&&knob==64,"reset neutral");
 event_send(0,8'h90,60,100);check(count(gates)==1&&notes[6:0]==60&&gains[11:0]==3200&&triggers[0],"USB note on velocity and trigger");
 event_send(0,8'h90,60,80);check(count(gates)==1&&gains[11:0]==2560&&triggers[0],"duplicate retriggers same slot");
  event_send(1,8'h90,60,90);check(last_note==60&&last_velocity==90,"virtual source updates UI note velocity");
  event_send(0,8'h91,60,70);check(count(gates)==3,"source and channel ownership");
 event_send(0,8'h80,60,0);check(count(gates)==2,"off only exact source channel");
  event_send(0,8'hff,0,0);check(count(gates)==1&&gates[1],"disconnect USB only");
  check(gains[11:0]==0&&gains[35:24]==0&&gains[23:12]!=0,"USB disconnect urgent gain clear leaves virtual");
 event_send(1,8'h90,60,0);check(gates==0,"zero velocity note off");
  event_send(1,8'h90,84,127);event_send(0,8'hff,0,0);
  check(count(gates)==1&&last_note==84&&last_velocity==127,"virtual only works without USB and survives disconnect");
  event_send(1,8'h80,84,0);check(gates==0,"virtual only release");
 reset();for(i=0;i<7;i=i+1)event_send(0,8'h90,60+i,127);
 check(gates==127,"seven independent slots");event_send(0,8'h90,80,127);check(notes[6:0]==80&&gates==127,"eighth note steals oldest");
 event_send(0,8'h80,60,0);check(gates==127&&notes[6:0]==80,"late stolen off cannot kill replacement");
 event_send(0,8'h80,80,0);check(count(gates)==6,"replacement proper release");
  reset();event_send(0,8'h90,60,127);event_send(0,8'h90,61,127);event_send(0,8'h80,60,0);event_send(0,8'h90,62,127);
  for(i=0;i<12;i=i+1)begin event_send(0,8'h90,63,127);event_send(0,8'h80,63,0);end
  for(i=0;i<5;i=i+1)event_send(0,8'h90,64+i,127);
  event_send(0,8'h90,90,127);check(notes[6:0]==62&&notes[13:7]==90,"oldest order survives repeated free-slot churn");
 reset();event_send(0,8'hb2,64,127);event_send(0,8'h92,0,127);event_send(0,8'h82,0,0);check(count(gates)==1,"sustain and note zero");
 event_send(0,8'hb1,64,0);check(count(gates)==1,"other channel pedal isolated");event_send(0,8'hb2,64,0);check(gates==0,"sustain released");
 event_send(0,8'h92,127,1);check(count(gates)==1&&notes[6:0]==127&&gains[11:0]==32,"MIDI note127 and velocity1");
 event_send(0,8'hb2,123,0);check(gates==0,"CC123 all notes off channel");
 event_send(0,8'hb2,64,127);event_send(0,8'h92,65,127);event_send(0,8'hb2,123,0);check(count(gates)==1,"CC123 respects pedal");
  event_send(0,8'hb2,120,0);check(gates==0&&gains[11:0]==0,"CC120 immediate even sustain");
 event_send(0,8'hc0,0,0);check(knob==0&&ratio==262144,"ProgramChange knob target only");before_ratio=ratio;
 repeat(20)@(negedge clk);check(ratio==before_ratio,"bend only sample ticks");ticks(1);check(ratio<before_ratio&&ratio>174960,"smooth first low step");ticks(700);check(ratio==174960,"low endpoint exact");
 event_send(0,8'hc0,127,0);ticks(800);check(knob==127&&ratio==392772,"high endpoint exact");
  event_send(0,8'hb0,1,127);check(knob==127&&mod_depth==127,"CC1 sets MOD depth independently of knob");
  event_send(0,8'hb0,1,0);check(knob==127&&mod_depth==0,"CC1 zero clears MOD not knob");
 event_send(0,8'hb0,74,64);ticks(800);check(ratio==262144&&knob==64,"CC74 center");
 event_send(0,8'he0,0,0);ticks(800);check(knob==0&&ratio==174960,"pitch bend min");
 event_send(0,8'he0,0,64);ticks(800);check(knob==64&&ratio==262144,"pitch bend center");
 event_send(0,8'he0,127,127);ticks(800);check(knob==127&&ratio==392772,"pitch bend max");
 @(negedge clk);centre=1;@(negedge clk);centre=0;ticks(800);check(ratio==262144&&knob==64,"UI center");
  event_send(0,8'hb0,1,127);event_send(0,8'hff,0,0);check(mod_depth==0,"USB disconnect neutralizes MOD");
  event_send(0,8'hb0,1,127);
  event_send(0,8'h90,63,127);event_send(1,8'h90,64,127);@(negedge clk);panic=1;@(negedge clk);panic=0;check(gates==0&&gains==0&&mod_depth==0,"panic both sources and MOD");
 $display("PASS tb_play_voice_control ownership seven slots sustain PC/CC74/bend smoothing");$finish;
 end
endmodule
