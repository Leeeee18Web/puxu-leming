`timescale 1ns/1ps
// Test-only native clock/USB SoC/IO boundary models. Audio, navigation, RAM,
// snapshot, panel and TMDS encoder remain production modules.
module Gowin_PLL(input clkin,mdclk,output reg clkout0=0,clkout1=0,output reg lock=0);
 always #9.756097561 clkout0=~clkout0;
 always #1.951219512 clkout1=~clkout1;
 initial #1000 lock=1;
endmodule
module CLKDIV #(parameter DIV_MODE="5")(input HCLKIN,RESETN,CALIB,output CLKOUT);
 reg[2:0]phase=0;
 always @(posedge HCLKIN or negedge RESETN)if(!RESETN)phase<=0;else if(phase==4)phase<=0;else phase<=phase+1'b1;
 assign CLKOUT=phase<2;
endmodule
module USB_PLL_MOD(input clkin,reset,mdclk,mdainc,input[1:0]mdopc,input[7:0]mdwdi,
 output reg clkout0=0,output clkout1,output reg lock=0,output[7:0]mdrdo);
 always #10.416666667 clkout0=~clkout0;
 initial #1000 lock=1;
 assign clkout1=0;assign mdrdo=0;
endmodule
module usb_play_soc #(parameter LOCAL_PHY_RESET=0)(input clk,resetn,phy_resetn,uart_rx,output uart_tx,inout usb_dm,usb_dp,
 output reg[31:0]debug_status=0,debug_xy=0,debug_raw=0,debug_vidpid=0,debug_meta=0,
 output reg[31:0]debug_valid_reports=0,output reg debug_toggle=0,
 output reg[31:0]midi_data=0,output reg midi_request=0,input midi_ack,output reg[31:0]play_status=0,
 output reg[255:0]ptest_debug=0,
 output reg[7:0]wifi_rx_data=0,output reg wifi_rx_valid=0,input wifi_rx_ready,
 input[7:0]wifi_tx_data,input wifi_tx_valid,output wifi_tx_ready,output[767:0]link_diagnostics);
 assign link_diagnostics=0;
 // Default nonblocking MMIO consumer. Tests may hold this low to inspect
 // reply backpressure across both independent clock domains.
 reg wifi_reply_ready=1;
 assign wifi_tx_ready=wifi_reply_ready;
 task wifi_byte(input[7:0]b);
 begin
  @(negedge clk);wifi_rx_data=b;wifi_rx_valid=1;
  @(posedge clk);while(!wifi_rx_ready)@(posedge clk);
  @(negedge clk);wifi_rx_valid=0;
 end endtask
 assign uart_tx=1;assign usb_dp=1'bz;assign usb_dm=1'bz;
 // Firmware-boundary publication: no direct note/gate/PCM stimulus.
 task hid_report(input integer x,y,input bit down,valid);
 reg[31:0]shadow_status,shadow_xy;
 begin
  shadow_status=0;shadow_status[12]=valid;shadow_status[13]=valid;shadow_status[14]=valid;shadow_status[24]=down;
  shadow_xy={y[15:0],x[15:0]};
  @(negedge clk);debug_status=shadow_status;debug_xy=shadow_xy;debug_raw=0;
  debug_vidpid=32'h3277009f;debug_meta=32'h00000181;
  @(negedge clk);debug_valid_reports=debug_valid_reports+1;debug_toggle=~debug_toggle;
 end endtask
 task midi_event(input[31:0]word);
 begin
  wait(midi_request==midi_ack);@(negedge clk);midi_data=word;midi_request=~midi_request;
  wait(midi_request==midi_ack);@(negedge clk);
 end endtask

endmodule
module OSER10(input D0,D1,D2,D3,D4,D5,D6,D7,D8,D9,PCLK,FCLK,RESET,output Q);
 assign Q=D0;
endmodule
module ELVDS_OBUF(input I,output O,OB);assign O=I;assign OB=~I;endmodule
