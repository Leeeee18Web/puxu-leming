`timescale 1ns/1ps
module tb_regional170_observer;
 reg clk=0,rstn=0;always #10 clk=~clk;
 reg[2:0]reset_pipe=0;reg[11:0]model_resetn=0;
 always @(posedge clk or negedge rstn)if(!rstn)begin reset_pipe<=0;model_resetn<=0;end
 else begin reset_pipe<={reset_pipe[1:0],1'b1};model_resetn<={12{reset_pipe[1]}};end
 wire rst=!reset_pipe[2];wire recorder_rst=!model_resetn[8];
 reg sample_tick=0,record_toggle=0,replay_toggle=0,clear=0,panic=0;
 reg[6:0]in_gates=0,in_triggers=0;reg[48:0]in_notes=0;reg[83:0]in_gains=0;reg[20:0]in_timbres=0;
 reg[18:0]in_ratio=262144;reg[6:0]in_mod_depth=0;reg[31:0]in_synth_config=0;reg[11:0]export_address=0;
 wire[6:0]og[0:1],ot[0:1];wire[48:0]on[0:1];wire[83:0]gain[0:1],observer_gains;wire[20:0]tone[0:1];wire[18:0]ratio[0:1];wire[6:0]modulation[0:1];wire[31:0]configword[0:1],tm[0:1],duration[0:1],take[0:1];
 wire[1:0]recording,replaying,full,time_limit,ready,export_ready;wire[12:0]count[0:1];wire[95:0]word[0:1];
 final_recorder #(.VOICE_COUNT(7),.EVENT_CAPACITY(64),.MAX_SAMPLES(128))dut(.rst(recorder_rst),.out_gates(og[0]),.out_triggers(ot[0]),.out_notes(on[0]),.out_gains(gain[0]),.out_timbres(tone[0]),.out_ratio(ratio[0]),.out_mod_depth(modulation[0]),.out_synth_config(configword[0]),.recording(recording[0]),.replaying(replaying[0]),.full(full[0]),.time_limit(time_limit[0]),.replay_frame_ready(ready[0]),.count(count[0]),.time_samples(tm[0]),.duration_samples(duration[0]),.export_word(word[0]),.export_ready(export_ready[0]),.take_id(take[0]),.*,.preview_rst(1'b0),.preview_gates('0),.preview_notes('0),.preview_gains('0),.preview_timbres('0),.preview_ratio('0),.preview_mod_depth('0),.preview_synth_config('0));
 recorder_before_observer170 #(.VOICE_COUNT(7),.EVENT_CAPACITY(64),.MAX_SAMPLES(128))old(.rst(recorder_rst),.out_gates(og[1]),.out_triggers(ot[1]),.out_notes(on[1]),.out_gains(gain[1]),.out_timbres(tone[1]),.out_ratio(ratio[1]),.out_mod_depth(modulation[1]),.out_synth_config(configword[1]),.recording(recording[1]),.replaying(replaying[1]),.full(full[1]),.time_limit(time_limit[1]),.replay_frame_ready(ready[1]),.count(count[1]),.time_samples(tm[1]),.duration_samples(duration[1]),.export_word(word[1]),.export_ready(export_ready[1]),.take_id(take[1]),.*);
 reg[6:0]active=0;reg[167:0]steps=0;reg[111:0]envelopes=0;
 wire[6:0]ln[0:1];wire[10:0]lp[0:1];wire[23:0]ls[0:1];wire[15:0]le[0:1];wire[1:0]lv;
 final_leading_voice #(.VOICE_COUNT(7)) ld(.notes(on[0]),.gains(observer_gains),.leading_note(ln[0]),.leading_pitch(lp[0]),.leading_step(ls[0]),.leading_envelope(le[0]),.leading_valid(lv[0]),.*);
 final_leading_voice #(.VOICE_COUNT(7)) lo(.notes(on[1]),.gains(gain[1]),.leading_note(ln[1]),.leading_pitch(lp[1]),.leading_step(ls[1]),.leading_envelope(le[1]),.leading_valid(lv[1]),.*);
 integer i,j,checks=0,recs=0,reps=0,mutes=0,differences=0,valids=0;reg[31:0]rng=32'h8b9a231a;
 always @(posedge clk)begin #1;checks++;
  if(rst!==recorder_rst)$fatal(1,"OBSERVER170_RESET_PHASE");
  if({og[0],ot[0],on[0],gain[0],tone[0],ratio[0],modulation[0],configword[0],recording[0],replaying[0],full[0],time_limit[0],ready[0],count[0],tm[0],duration[0],word[0],export_ready[0],take[0]}!=={og[1],ot[1],on[1],gain[1],tone[1],ratio[1],modulation[1],configword[1],recording[1],replaying[1],full[1],time_limit[1],ready[1],count[1],tm[1],duration[1],word[1],export_ready[1],take[1]})$fatal(1,"OBSERVER170_RECORDER_PUBLIC_CHANGED");
  if({ln[0],lp[0],ls[0],le[0],lv[0],ld.state,ld.address,ld.base,ld.bit_index,ld.q}!=={ln[1],lp[1],ls[1],le[1],lv[1],lo.state,lo.address,lo.base,lo.bit_index,lo.q})$fatal(1,"OBSERVER170_LEADING_CHANGED");
  if(ld.state!=1&&{ld.held_note,ld.held_step,ld.held_env,ld.held_valid}!=={lo.held_note,lo.held_step,lo.held_env,lo.held_valid})$fatal(1,"OBSERVER170_CONSUMED_COHORT_CHANGED");
  if(!rst&&observer_gains!==gain[0])$fatal(1,"OBSERVER170_GAIN_NORMAL_CHANGED");
  if(recording[0])recs++;if(replaying[0])reps++;if(dut.mute_frame)mutes++;if(observer_gains!==gain[0])differences++;if(lv[0])valids++;
 end
 initial begin
  for(i=0;i<200000;i++)begin @(negedge clk);
   rstn=!(i<5||i%8192<3);sample_tick=(i%64==0);record_toggle=(i%4096==64||i%4096==1088);replay_toggle=(i%4096==1280||i%4096==2496);panic=(i%4096==3000);clear=(i%4096==3904);export_address=(i/64)%64;
   rng=rng*1664525+1013904223;active=rng[6:0];
   for(j=0;j<7;j++)begin rng=rng*1664525+1013904223;steps[j*24+:24]=rng[23:0];envelopes[j*16+:16]=rng[15:0];
    if(i%64==2)begin in_notes[j*7+:7]=rng[6:0];in_gains[j*12+:12]=i%512==2?0:rng[11:0];in_gates[j]=rng[15];in_triggers[j]=rng[18];in_timbres[j*3+:3]=rng[2:0];end
   end
  end
  @(negedge clk);if(recs<1000||reps<1000||mutes==0||differences==0||valids==0)$fatal(1,"OBSERVER170_COVERAGE %0d %0d %0d %0d %0d",recs,reps,mutes,differences,valids);
  $display("OBSERVER170_PASS checks%0d rec%0d replay%0d muted%0d resetPrivateDiff%0d leading%0d",checks,recs,reps,mutes,differences,valids);$finish;
 end
endmodule
