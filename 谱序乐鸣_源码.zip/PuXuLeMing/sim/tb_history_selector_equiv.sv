`timescale 1ns/1ps
module tb_history_selector_equiv;
 reg clk=0,pclk=0,rst=1,prstn=0,enable=1;always #10 clk=~clk;always #11 pclk=~pclk;
 reg[9:0]addr=0;wire[10:0]a,b;wire[9:0]ca,cb;wire[16:0]sa,sb;
 tone_history #(.READ_GATED(1)) dut(.clk(clk),.rst(rst),.restart(1'b0),.sample_tick(1'b0),.recording(1'b0),.pitch(11'd960),.pitch_valid(1'b1),.pixel_clk(pclk),.pixel_rstn(prstn),.frame_start(1'b0),.read_addr(addr),.read_enable(enable),.pitch_data(a),.visible_count(ca),.curve_sum(sa));
 tone_history_selector_reference #(.READ_GATED(1)) original(.clk(clk),.rst(rst),.restart(1'b0),.sample_tick(1'b0),.recording(1'b0),.pitch(11'd960),.pitch_valid(1'b1),.pixel_clk(pclk),.pixel_rstn(prstn),.frame_start(1'b0),.read_addr(addr),.read_enable(enable),.pitch_data(b),.visible_count(cb),.curve_sum(sb));
 genvar g;
 generate for(g=0;g<7;g++)begin:init_banks
  integer i;reg[12:0]v;
  initial for(i=0;i<256;i++)begin v=(i%19==0)?8191:((i*157+g*911+13)&8191);dut.banks[g].samples[i]=v;original.banks[g].samples[i]=v;end
 end
 for(g=0;g<4;g++)begin:init_heads
  integer i;reg[12:0]v;
  initial for(i=0;i<8;i++)begin v=(i*743+g*131+33)&8191;dut.head_reads[g].head_samples[i]=v;original.head_reads[g].head_samples[i]=v;end
 end endgenerate
 integer i,bank,n,x,checks=0;
 initial begin
  for(i=0;i<2048;i++)begin dut.history[i]=(i*37)&2047;original.history[i]=(i*37)&2047;end
  for(i=0;i<8;i++)begin dut.first_sample[i]=i*97+319;original.first_sample[i]=i*97+319;end
  for(i=0;i<2;i++)begin dut.first_pitch[i]=960+i*32;original.first_pitch[i]=960+i*32;end
  repeat(8)@(negedge pclk);rst=0;prstn=1;
  for(bank=0;bank<2;bank++)for(n=0;n<1024;n++)begin
   for(x=0;x<1024;x++)begin
    @(negedge pclk);dut.visible_count=n;original.visible_count=n;dut.display_bank=bank;original.display_bank=bank;addr=x;enable=1;
    @(posedge pclk);#1;checks++;
    if({a,ca,sa}!=={b,cb,sb})$fatal(1,"HISTORY_SELECTOR_FAIL bank=%0d count=%0d addr=%0d actual=%h expected=%h",bank,n,x,sa,sb);
    for(i=0;i<7;i++)if(!$onehot(dut.qselect[i]))$fatal(1,"HISTORY_SELECTOR_FAIL invalid onehot");
   end
   for(x=0;x<2;x++)begin
    @(negedge pclk);addr=x?1023:0;enable=0;
    @(posedge pclk);#1;checks++;
    if({a,ca,sa}!=={b,cb,sb})$fatal(1,"HISTORY_SELECTOR_FAIL disabled");
   end
  end
  $display("HISTORY_SELECTOR_EQ_PASS checks=%0d all1024counts all1024addresses bothbanks disabled corners, exact single-edge outputs",checks);$finish;
 end
 initial begin #150000000;$fatal(1,"HISTORY_SELECTOR_FAIL timeout");end
endmodule
