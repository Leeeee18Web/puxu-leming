`timescale 1ns/1ps
module final_ui_nav;
 reg clk=0;always #5 clk=~clk;
 reg rst=1,update=0,valid=1,down=0,ready=1;reg [15:0]x=0,y=0;
 wire [2:0]page;wire [1:0]mode,pattern_mode;wire [6:0]base_note;
 wire record_cmd,replay_cmd,transport_stop,overview,dropdown;wire [2:0]timbre;wire [31:0]cfg;
 wire [5:0]xy;wire ev,ps;wire [31:0]ed;reg [31:0]last_accepted=0;
 integer records=0,replays=0,patterns=0,stops=0,checks=0,c,r,i,expected,k;
`ifdef FINAL_UI_NEW
 final_navigation dut(.record_toggle(record_cmd),.replay_toggle(replay_cmd),.transport_stop(transport_stop),
  .xy_overview(overview),.timbre_open(dropdown),.timbre(timbre),.synth_config(cfg),
`else
 assign record_cmd=0,replay_cmd=0,transport_stop=0,overview=0,dropdown=0,timbre=0,cfg=0;
 p8_navigation dut(
`endif
 .clk(clk),.rst(rst),.touch_update(update),.touch_valid(valid),.touch_down(down),
 .touch_x(x),.touch_y(y),.event_ready(ready),.panic_key(1'b0),.centre_key(1'b0),
 .event_valid(ev),.event_data(ed),.page(page),.mode(mode),.base_note(base_note),
 .xy_config(xy),.pattern_mode(pattern_mode),.pattern_start(ps),.spectrum_zoom(),.restart_lesson(),
 .muted(),.stop_score(),.start_score(),.clear_live(),.panic(),.centre(),.knob_mode());
 always @(posedge clk)begin #1;if(record_cmd)records=records+1;if(replay_cmd)replays=replays+1;if(ps)patterns=patterns+1;if(transport_stop)stops=stops+1;end
 always @(posedge clk)if(ev&&ready)last_accepted=ed;
`ifdef FINAL_UI_NEW
 always @(posedge clk)begin #1;
  if(!rst&&(cfg!==32'd0))$fatal(1,"FINAL_UI_FAIL touchscreen must never customize ADSR");
 end
`endif
 task tick;begin @(negedge clk);end endtask
 task touch(input integer ax,ay,pressed);begin x=ax;y=ay;down=pressed;update=1;tick;update=0;tick;end endtask
 task tap(input integer ax,ay);begin touch(ax,ay,1);touch(ax,ay,0);end endtask
 task check(input bit ok,input string title);begin checks=checks+1;if(!ok)$fatal(1,"FINAL_UI_FAIL %s",title);end endtask
 task keyboard;begin tap(160,32);tap(650,96);end endtask
 initial begin
  repeat(4)tick;rst=0;tick;keyboard;
  check(page==5&&mode==1,"enter keyboard");
  tap(100,195);check(records==1&&base_note==60,"record command replaces octave down");
  tap(280,195);check(replays==1&&base_note==60,"replay command replaces octave up");
`ifdef FINAL_UI_NEW
  for(r=0;r<600;r=r+1)for(c=0;c<1024;c=c+1)begin
   i=dut.final_matrix_hit(c,r);
   expected=-1;
   for(k=0;k<20;k=k+1)if(c>=136+216*(k%4)&&c<328+216*(k%4)&&r>=218+72*(k/4)&&r<282+72*(k/4))expected=k;
   check(i==expected,"complete matrix hit map includes all interiors borders and gaps");
   expected=-1;
   for(k=0;k<4;k=k+1)if(c>=712&&c<1000&&r>=72+44*k&&r<116+44*k)expected=k;
   check(dut.final_timbre_hit(c,r)==expected,"exactly four dropdown hit rows and no fifth/FX hit");
  end
`endif
  touch(100,195,1);repeat(12)tick;check(records==2,"held record exactly one pulse");touch(100,195,0);
  for(i=0;i<3;i=i+1)begin tap(460+144*i,195);check(pattern_mode==i+1,"pattern selection preserved");end
  tap(900,195);check(patterns==1,"trigger preserved");
  // A tab contact stays a button even if it subsequently moves over a piano key.
  touch(160,32,1);touch(640,500,1);check(!ev,"header contact never becomes a note");touch(0,0,0);
  keyboard;
  for(i=0;i<4;i=i+1)begin
   tap(760,32);check(dropdown,"open timbre dropdown");
   tap(850,90+44*i);check(timbre==i&&!dropdown,"four timbre selections");
  end
  tap(760,32);touch(100,500,1);repeat(8)tick;check(!dropdown&&!ev,"outside popup consumes piano contact");touch(100,500,0);
  // Former envelope +/- positions cannot edit preset envelope bits.
  for(i=0;i<8;i=i+1)begin
   if(!dropdown)tap(760,32);
   case(i)0:c=580;1:c=662;2:c=690;3:c=772;4:c=800;5:c=882;6:c=910;default:c=992;endcase
   tap(c,380);check(cfg==32'd0,"former ADSR taps keep envelope fixed and custom disabled");
  end
  // Removed fifth row and effects controls only dismiss modal contact.
  tap(760,32);tap(850,270);check(timbre==3&&!dropdown&&cfg==0,"removed fifth row has no selection");
  tap(760,32);touch(982,380,1);touch(100,500,1);repeat(8)tick;
  check(!dropdown&&!ev&&cfg==0,"removed FX contact cannot become key");touch(100,500,0);
  tap(320,96);check(page==3&&!overview,"Lissajous tab retains big graph");
  check(xy==6'b101000,"initial auto settings");
  tap(900,220);check(overview&&xy==6'b101000,"thumbnail enters without changing settings");
  tap(900,150);check(!overview&&xy==6'b101000,"exit preserves previous auto settings");
  for(r=0;r<5;r=r+1)for(c=0;c<4;c=c+1)begin
   tap(900,220);check(overview,"reopen overview");
   tap(140+216*c,220+72*r);check(!overview&&xy==r*4+c,"all20 cells apply immediately and auto off");
  end
  tap(900,220);tap(330,220);check(overview&&xy==19,"matrix gap ignores contact");tap(900,150);
  tap(900,150);check(xy[5],"normal auto toggle retained");
  tap(900,220);tap(900,150);check(xy==6'b110011,"matrix exit preserves chosen ratio phase and auto");
  tap(300,32);check(mode==2,"song playback mode");
  tap(100,150);tap(280,150);check(records==3&&replays==2,"record/replay during playback");
  tap(650,96);tap(100,195);tap(280,195);check(records==4&&replays==3,"record/replay song keyboard page");
  tap(40,32);tap(100,150);check(page==0&&records==4,"Home has no recorder control");
  keyboard;ready=0;touch(64,500,1);repeat(6)tick;
  check(ev&&ed==32'h01643c90,"raw touch note-on format source and velocity100");
  touch(128,500,1);repeat(4)tick;check(ev&&ed==32'h01643c90,"pending raw event stable under backpressure");
  ready=1;repeat(12)tick;check(last_accepted==32'h01643e90,"drag releases previous note then sounds next");
  touch(128,500,0);repeat(10)tick;check(last_accepted==32'h01003e80,"raw touch note-off preserved");
  check(stops==0,"mode transitions never stop independent recorder");tap(600,32);check(stops==1,"explicit Stop pulses transport_stop");
  $display("FINAL_UI_PASS navigation checks=%0d all20cells=1",checks);$finish;
 end
endmodule
