`timescale 1ns/1ps
module tb_p8_wifi_watchdog;
 reg clk=0,rst=1;always #10 clk=~clk;
 reg[7:0]rx_data=0;reg rx_valid=0;wire rx_ready;wire[7:0]tx_data;wire tx_valid;
 wire[31:0]event_data;wire event_valid,score_playing;wire[9:0]score_position,score_count;
 p8_wifi_control dut(.map_apply_audio(),.map_apply_fx(),.clk(clk),.rst(rst),.sample_tick(1'b0),.playable(1'b1),.clear_notes(1'b0),.live_link_lost(1'b0),.mode(2'd0),.muted(1'b0),
 .rx_data(rx_data),.rx_valid(rx_valid),.rx_ready(rx_ready),.tx_data(tx_data),.tx_valid(tx_valid),.tx_ready(1'b1),
 .event_data(event_data),.event_valid(event_valid),.event_ready(1'b1),.score_playing(score_playing),.score_position(score_position),.score_count(score_count),
 .trace_valid(),.trace_frame(),.trace_expected(),.trace_result(),.trace_size(),.good_frames(),.bad_crc(),.bad_version(),.gap_timeouts(),.watchdog_count());
 function automatic[15:0]crc(input[15:0]c,input[7:0]b);reg[15:0]v;integer k;begin v=c^{b,8'd0};
 for(k=0;k<8;k++)v=v[15]?(v<<1)^16'h1021:v<<1;crc=v;end endfunction
 task send(input[7:0]op,input[15:0]seq,input[31:0]a,b);reg[7:0]p[0:21];reg[15:0]c;integer i;begin
 p[0]="P";p[1]="W";p[2]=1;p[3]=op;p[4]=seq[7:0];p[5]=seq[15:8];p[6]=1;p[7]=0;
 for(i=0;i<4;i++)begin p[8+i]=a>>(8*i);p[12+i]=b>>(8*i);p[16+i]=0;end
 c=16'hffff;for(i=2;i<20;i++)c=crc(c,p[i]);p[20]=c[7:0];p[21]=c[15:8];
 for(i=0;i<22;i++)begin @(negedge clk);rx_data=p[i];rx_valid=1;do @(posedge clk);while(!rx_ready);@(negedge clk);rx_valid=0;end
 end endtask
 integer cycles=0,on_at=-1,ons=0,offs=0;
 always @(posedge clk)begin cycles++;
 if(!rst&&event_valid)begin
  if(event_data==32'h01643c9e)begin ons++;on_at=cycles;end
  else if(event_data==32'h010078be)begin
   offs++;
   if(ons!=1||offs!=1||cycles-on_at<25000000||cycles-on_at>25000100)$fatal(1,"default500ms watchdog boundary");
   $display("P8_WIFI_WATCHDOG_PASS ons=%0d offs=%0d delta_cycles=%0d",ons,offs,cycles-on_at);$finish;
  end else $fatal(1,"unexpected watchdog MIDI event");
 end end
 initial begin repeat(5)@(negedge clk);rst=0;send(0,1,32'h50385731,0);wait(!tx_valid&&rx_ready);send(1,2,1,32'h3c64);end
 initial begin #510000000;$fatal(1,"default500ms watchdog deadline");end
endmodule
