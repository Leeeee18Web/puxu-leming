`timescale 1ns/1ps
module tb_poly_delay_pool;
 reg clk=0;always #10 clk=~clk;reg rst=1,en=0,load=0;reg[2:0]idx=0;
 reg[4:0]ra=0,rb=0,rc=0,wa=0,wb=0,wc=0;reg ea=0,eb=0,ec=0;
 reg[19:0]da=0;reg[17:0]db=0,dc=0;reg[55:0]restore=0;wire[19:0]qa;wire[17:0]qb,qc;wire[55:0]snap;
 poly_delay_pool #(.CONTEXTS(7),.LENGTH(17),.ADDR_WIDTH(5)) dut(clk,rst,en,load,idx,restore,snap,ra,rb,rc,wa,wb,wc,ea,eb,ec,da,db,dc,qa,qb,qc,1'b0,5'd0,20'd0);
 reg[19:0]ga[0:118];reg[17:0]gb[0:118],gc[0:118];integer i,j,n;
 initial begin repeat(3)@(negedge clk);rst=0;en=1;
 for(i=0;i<7;i=i+1)for(j=0;j<17;j=j+1)begin
  @(negedge clk);idx=i;wa=j;wb=j;wc=j;ea=1;eb=1;ec=1;
  da=20'h7f000^(i*655+j*171);db=18'h2f000^(i*157+j*31);dc=18'h1d00^(i*97+j*5);
  ga[i*17+j]=da;gb[i*17+j]=db;gc[i*17+j]=dc;
 end
 @(negedge clk);ea=0;eb=0;ec=0;
 for(n=0;n<2000;n=n+1)begin
  idx=n%7;ra=(n*3)%17;rb=(n*5)%17;rc=(n*7)%17;
  @(negedge clk);if(qa!==ga[idx*17+ra]||qb!==gb[idx*17+rb]||qc!==gc[idx*17+rc])$fatal(1,"POOL_READ_FAIL n%0d row%0d",n,idx);
  en=0;restore=56'h123456789abcde;load=1;@(negedge clk);load=0;
  if(snap!==restore)$fatal(1,"POOL_RESTORE_FAIL");
  idx=(idx+1)%7;@(negedge clk);if(snap!==restore)$fatal(1,"POOL_PAUSE_FAIL");en=1;
 end
 $display("POLY_DELAY_POOL_PASS 7 contexts/3 banks/20bit reed pressure/restore/freeze");$finish;
 end
 initial begin #1000000;$fatal(1,"POOL_TIMEOUT");end
endmodule
