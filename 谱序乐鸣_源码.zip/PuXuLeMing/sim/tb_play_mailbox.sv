`timescale 1ns/1ps
module tb_play_mailbox;
reg sc=0,dc=0,srst=1,drst=1,req=0,ready=0;reg[31:0]source=0;
wire ack,valid;wire[31:0]data;
always #10.416 sc=~sc;always #10 dc=~dc;
play_event_cdc dut(.source_clk(sc),.source_rst(srst),.source_data(source),.source_request(req),.source_ack(ack),.clk(dc),.rst(drst),.valid(valid),.data(data),.ready(ready));
integer got=0,i,stall;reg[31:0]expect_data=0;
always @(posedge dc)if(!drst&&valid&&ready)begin
 if(data!==expect_data)$fatal(1,"FAIL wrong or reordered event got=%h expected=%h",data,expect_data);
 got=got+1;
end
initial begin
 #100;@(negedge sc)srst=0;@(negedge dc)drst=0;
 for(i=0;i<32;i=i+1)begin
  @(negedge sc);source=32'h00503c90+i;expect_data=source;req=~req;ready=0;
  repeat(12)@(negedge dc);
  if(!valid)$fatal(1,"FAIL request not delivered");
  repeat(7)begin @(negedge dc);if(!valid||data!==expect_data)$fatal(1,"FAIL data not stable under stall");end
  ready=1;wait(ack==req);repeat(5)@(negedge dc);
  if(got!=i+1)$fatal(1,"FAIL event duplicated");
 end
 if(got!=32)$fatal(1,"FAIL missing events");
 $display("PASS mailbox32 ordered events, stalled stability, no duplication");$finish;
end
initial begin #200000;$fatal(1,"FAIL mailbox watchdog");end
endmodule
