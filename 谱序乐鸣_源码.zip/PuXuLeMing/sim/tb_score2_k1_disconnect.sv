`timescale 1ns/1ps
module tb_score2_k1_disconnect;
 reg clk=0,rstn=0,key1_n=1;always #10 clk=~clk;
 tri dp,dm;
 hub_play_top dut(.clk(clk),.rstn(rstn),.key1_n(key1_n),.key2_n(1'b1),.uart_rx(1'b1),.usb_dp(dp),.usb_dm(dm),
 .uart_tx(),.hp_bck(),.hp_ws(),.hp_din(),.pa_en(),.i2s_bck(),.i2s_ws(),.i2s_sd(),.led_o(),
 .tmds_clk_p_0(),.tmds_clk_n_0(),.tmds_d_p_0(),.tmds_d_n_0());
 defparam dut.status_bridge.PERIOD=10;
 defparam dut.ui_snapshot.PERIOD=10;
 defparam dut.pedal_button.TICKS=4;
 defparam dut.patterns.HOLD_SAMPLES=8;
 integer checks=0,n,m,x,y,yellow=0,grey=0,on_frames=0,off_frames=0;
 reg[13:0]probe_x=64,probe_y=550;
 always @(dut.pattern_selected)$display("K1_SELECTED_CHANGE time=%t selected=%b chord=%b",$time,dut.pattern_selected,dut.patterns.chord_selection);
 task check(input bit ok,input string why);begin checks++;if(!ok)$fatal(1,"K1_RECORD_UI_FAIL %s",why);end endtask
 task waitclks(input integer n);repeat(n)@(negedge clk);endtask
 task frames(input integer n);repeat(n)begin @(posedge dut.sample_tick);@(negedge clk);end endtask
 task touch(input integer x,y,input bit down);begin dut.soc.hid_report(x,y,down,1);waitclks(40);end endtask
 task tap(input integer x,y);begin touch(x,y,0);touch(x,y,1);touch(x,y,0);end endtask
 task ev(input[31:0]w);begin dut.soc.midi_event(w);waitclks(100);end endtask
 task pedal(input bit down);begin key1_n=!down;waitclks(100);end endtask
 task reset_all;begin rstn=0;key1_n=1;waitclks(20);rstn=1;waitclks(2000);dut.soc.ptest_debug[255:224]=32'h0c;waitclks(100);tap(300,280);tap(650,96);end endtask
 initial begin
  reset_all;tap(600,195);touch(64,500,1);touch(64,500,0);touch(200,500,1);touch(200,500,0);
  check(dut.pattern_count==2,"two selected notes");pedal(1);tap(900,195);frames(20);
  check(dut.perform_gates!=0&&dut.pattern_gates==0,"pedal-only pattern before disconnect");
  ev(32'h000000ff);frames(3);
  check(dut.perform_gates==0&&dut.perform_gains==0,"FF cancels pedal pattern immediately");
  check(dut.pattern_count==2,"disconnect retains selected list");
  tap(900,195);frames(20);check(dut.perform_gates!=0,"relaunch held pattern");
  ev(32'h00ffffff);frames(3);
  check(dut.perform_gates==0&&dut.perform_gains==0&&dut.pattern_count==2,"FF malformed payload still cancels and retains selection");
  $display("SCORE2_K1_DISCONNECT_PASS cancel while held retains selection");$finish;
 end
 initial begin #20000000;$fatal(1,"TIMEOUT");end
endmodule
