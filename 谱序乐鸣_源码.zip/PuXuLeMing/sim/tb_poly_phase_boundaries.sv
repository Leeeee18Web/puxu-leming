`timescale 1ns/1ps
module poly_phase_boundary #(parameter PROBE=0)(output reg done=0);
 reg clk=0;always #10 clk=~clk;reg rst=1,start=0;reg v;reg[15:0]q;
 poly_voice_worker #(.CONTEXTS(1),.LOCAL_MEMORY_RESET(1),.PRECALC_SLOT_GATES(1),.LOCAL_CONTROL(1)) dut(.clk(clk),.rst(rst),.start(start),.gates(1'b1),.triggers(1'b1),.steps(24'd45000),.gains(12'd2400),.timbres(3'd1),.model_reset({3{rst}}),.memory_reset(rst),.samples(),.envelopes(),.active(),.busy(),.deadline_error(),.out_valid(),.out_index(),.out_sample(),.control_resetn_early(1'b1));
 initial begin
  repeat(3)@(negedge clk);rst=0;start=1;@(negedge clk);start=0;
  if(PROBE==0)begin
   wait(dut.phase==2);@(negedge clk);v=dut.strings.body.rst;if(!v)$fatal(1,"CLEAR_BOUNDARY_SETUP");force dut.phase=9;#1;
   if(dut.strings.body.rst!==v)$fatal(1,"LOCAL_CLEAR_REGISTER_BOUNDARY_MISSING");
  end else if(PROBE==1)begin
   wait(dut.phase==1);@(negedge clk);v=dut.strings.body.ctx_load;if(!v)$fatal(1,"RESTORE_BOUNDARY_SETUP");force dut.phase=9;#1;
   if(dut.strings.body.ctx_load!==v)$fatal(1,"LOCAL_RESTORE_REGISTER_BOUNDARY_MISSING");
  end else if(PROBE==2)begin
   wait(dut.phase==5);@(negedge clk);v=dut.render_fire;if(!v)$fatal(1,"RENDER_BOUNDARY_SETUP");force dut.phase=9;#1;
   if(dut.render_fire!==v)$fatal(1,"LOCAL_RENDER_REGISTER_BOUNDARY_MISSING");
  end else begin
   wait(dut.phase==20);@(negedge clk);q=dut.strings.shared_tuning;force dut.strings.step_snapshot=24'h500000;#1;
   if(dut.strings.shared_tuning!==q)$fatal(1,"TUNING_ADDRESS_REGISTER_BOUNDARY_MISSING");
  end
  $display("POLY_PHASE_BOUNDARY_PASS probe%0d",PROBE);done=1;
 end
 initial begin #50000;$fatal(1,"PHASE_BOUNDARY_TIMEOUT");end
endmodule
module tb_poly_clear_boundary;wire d;poly_phase_boundary #(.PROBE(0)) t(d);initial begin wait(d);$finish;end endmodule
module tb_poly_restore_boundary;wire d;poly_phase_boundary #(.PROBE(1)) t(d);initial begin wait(d);$finish;end endmodule
module tb_poly_render_boundary;wire d;poly_phase_boundary #(.PROBE(2)) t(d);initial begin wait(d);$finish;end endmodule
module tb_poly_tuning_address_boundary;wire d;poly_phase_boundary #(.PROBE(3)) t(d);initial begin wait(d);$finish;end endmodule
