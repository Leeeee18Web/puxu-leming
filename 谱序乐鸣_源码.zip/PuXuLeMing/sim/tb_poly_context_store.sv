`timescale 1ns/1ps
module tb_poly_context_store;
 reg clk=0;always #10 clk=~clk;reg rst=1,save=0;reg[2:0]idx=0;reg[16:0]d=0;wire[16:0]q;wire valid;
 poly_context_store #(.WIDTH(17),.COUNT(7),.INDEX_WIDTH(3)) dut(clk,rst,save,idx,d,q,valid);
 reg[16:0]gold[0:6];reg[6:0]seen=0;integer i,j;reg[31:0]rng=32'h46f25713;
 initial begin repeat(3)@(negedge clk);rst=0;
 for(i=0;i<7;i=i+1)begin idx=i;#1;if(valid||q!==0)$fatal(1,"CTX_ZERO_FAIL row%0d",i);end
 for(i=0;i<7;i=i+1)begin @(negedge clk);idx=i;d=17'h11375^(i*131);save=1;gold[i]=d;seen[i]=1;@(negedge clk);save=0;#1;if(!valid||q!==gold[i])$fatal(1,"CTX_WRITE_FAIL row%0d",i);end
 for(j=0;j<5000;j=j+1)begin
 @(negedge clk);rng={rng[30:0],rng[31]^rng[21]^rng[1]^rng[0]};idx=rng%7;save=rng[4];d=rng[16:0];rst=(j%601==600);
 if(rst)seen=0;else if(save)begin gold[idx]=d;seen[idx]=1;end
 @(negedge clk);save=0;rst=0;
 for(i=0;i<7;i=i+1)begin idx=i;#1;if(valid!==seen[i]||q!==(seen[i]?gold[i]:17'd0))$fatal(1,"CTX_RANDOM_FAIL iter%0d row%0d",j,i);end
 end
 $display("POLY_CONTEXT_STORE_PASS checks35056 reset/uninitialized/allrows/write/read");$finish;
 end
 initial begin #1000000;$fatal(1,"CTX_TIMEOUT");end
endmodule
