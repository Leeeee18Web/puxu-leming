`timescale 1ns/1ps
module tb_p8_patterns;
 reg clk=0;always #5 clk=~clk;
 reg rst=1,sample_tick=0,cancel=0,start=0,event_valid=0;
 reg [1:0] pattern_mode=2;
 reg [31:0] event_data=0;
 wire [6:0] selected,gates,triggers;
 wire [48:0] selected_notes,notes;
 wire [83:0] selected_gains,gains;
 wire busy,full;wire [2:0] count;
 integer checks=0,i,j,n,slot,trial,temp_pitch;
 integer pitches[0:6];integer ordered[0:4];
 reg [6:0] seen,expected_mask,last_triggers;
 reg [48:0] saved_notes;reg [83:0] saved_gains;reg [6:0] saved_selected;
 reg d_rst=1,d_sample_tick=0,d_cancel=0,d_start=0,d_event_valid=0;
 reg [1:0] d_mode=2;reg [31:0] d_event_data=0;
 wire [6:0] d_selected,d_gates,d_triggers;wire [48:0] d_selected_notes,d_notes;
 wire [83:0] d_selected_gains,d_gains;wire d_busy,d_full;wire [2:0] d_count;
 p8_patterns #(.SAMPLE_HZ(20),.STRUM_SAMPLES(4),.ARP_SAMPLES(10),.HOLD_SAMPLES(12)) dut(.*);
 p8_patterns defaults(.clk(clk),.rst(d_rst),.sample_tick(d_sample_tick),.cancel(d_cancel),
  .pattern_mode(d_mode),.start(d_start),.event_valid(d_event_valid),.event_data(d_event_data),
  .selected(d_selected),.selected_notes(d_selected_notes),.selected_gains(d_selected_gains),
  .gates(d_gates),.triggers(d_triggers),.notes(d_notes),.gains(d_gains),.busy(d_busy),.count(d_count),.full(d_full));
 task check(input bit okay,input string message);begin
  checks=checks+1;if(!okay)begin $display("P8_PATTERNS_FAIL %s time=%0t",message,$time);$fatal(1,"behavior assertion");end
 end endtask
 task cycles(input integer n);repeat(n)begin @(posedge clk);#1;end endtask
 task ev(input [31:0] word);begin @(negedge clk);event_data=word;event_valid=1;cycles(1);@(negedge clk);event_valid=0;cycles(2);end endtask
 function [31:0] noteon(input integer pitch,input integer velocity,input bit touch);noteon={7'd0,touch,1'b0,velocity[6:0],1'b0,pitch[6:0],8'h90};endfunction
 task tick;begin
  @(negedge clk);sample_tick=1;cycles(1);last_triggers=triggers;
  @(negedge clk);sample_tick=0;cycles(60);
 end endtask
 task pulse_start;begin @(negedge clk);start=1;cycles(1);@(negedge clk);start=0;cycles(60);end endtask
 task launch;begin
  pulse_start();check(gates==0&&gains==0,"start clears prior gates/gains");
  tick();check(gates==0&&gains==0,"first audio sample must observe clear gates");
  tick();check(gates!=0&&busy,"nonempty trigger begins within second sample");
 end endtask
 task reset_main;begin @(negedge clk);rst=1;cycles(2);@(negedge clk);rst=0;pattern_mode=2;cycles(3);end endtask
 task mode(input [1:0] value);begin @(negedge clk);pattern_mode=value;cycles(3);end endtask
 function [6:0] mask_pitch(input integer p);begin
  mask_pitch=0;for(integer z=0;z<7;z=z+1)if(selected[z]&&selected_notes[z*7+:7]==p)mask_pitch[z]=1;
 end endfunction
 task silent(input string why);check(gates==0&&gains==0&&triggers==0&&!busy,why);endtask
 task dtick;begin @(negedge clk);d_sample_tick=1;cycles(1);@(negedge clk);d_sample_tick=0;end endtask
 task dev(input integer p);begin @(negedge clk);d_event_data=noteon(p,100,0);d_event_valid=1;cycles(1);@(negedge clk);d_event_valid=0;cycles(2);end endtask
 task dlaunch;begin
  @(negedge clk);d_start=1;cycles(1);@(negedge clk);d_start=0;cycles(60);
  dtick();check(d_gates==0,"default first sample clear");dtick();check(d_gates!=0,"default second sample launch");
 end endtask
 // Global output invariants catch stale gains, illegal trigger pulses and caps.
 always @(posedge clk)begin
  #2;
  if(!rst)begin
   check((triggers&~gates)==0,"triggers are a subset of sounding gates");
   for(integer z=0;z<7;z=z+1)begin
    check(gains[z*12+:12]<=3200&&selected_gains[z*12+:12]<=3200,"headroom cap velocity100");
    if(!gates[z])check(gains[z*12+:12]==0,"inactive voice gain zero");
   end
  end
 end
 initial begin
  cycles(3);@(negedge clk);rst=0;cycles(2);
  ev(noteon(61,100,0));
  check(gates==0&&gains==0&&triggers==0&&!busy,"selection must remain silent before unified trigger");
  check(count==1&&selected!=0,"NoteOn latches exact selection");
  check(selected_notes[6:0]==61&&selected_gains[11:0]==3200,"exact chromatic pitch and velocity");
  ev(32'h00003d80);ev(noteon(61,0,0));
  check(count==1,"NoteOff and NoteOn0 preserve latched selection");
  ev(32'h00003dC0);ev(32'h006440B0);ev(32'h004000E0);
  ev(noteon(64,100,0)|32'h00008000);ev(noteon(64,100,0)|32'h00800000);
  check(count==1,"PC CC bend and invalid data bytes ignored");silent("nonselection MIDI remains silent");
  ev(noteon(61,65,1));check(count==0,"same pitch toggles across input source");
  launch_empty: begin pulse_start();tick();tick();silent("empty trigger is silent");end
  ev(noteon(0,1,0));check(selected_notes[6:0]==0&&selected_gains[11:0]==32,"MIDI lowest pitch velocity1");
  ev(noteon(0,127,0));ev(noteon(127,1,1));
  check(selected_notes[6:0]==127&&selected_gains[11:0]==3200,"MIDI top pitch and touch velocity100");
  ev(noteon(127,1,0));
  pitches[0]=80;pitches[1]=61;pitches[2]=74;pitches[3]=49;pitches[4]=68;pitches[5]=60;pitches[6]=93;
  for(i=0;i<7;i=i+1)ev(noteon(pitches[i],i==6?127:(i+1)*10,0));
  check(count==7&&selected==127,"seven independent selections");
  saved_notes=selected_notes;saved_gains=selected_gains;saved_selected=selected;
  ev(noteon(95,100,0));check(full&&count==7&&selected_notes==saved_notes&&selected_gains==saved_gains,"eighth note flags full without replacing selection");
  for(i=0;i<19;i=i+1)begin tick();check(full,"full warning retains until exact one second");end
  tick();check(!full,"full warning clears at SAMPLE_HZ samples");
  launch();check(gates==127&&last_triggers==127,"all seven chord notes begin simultaneously");
  check(notes==saved_notes&&gains==saved_gains,"chord uses exact snapshot notes and gain");
  ev(32'h00003d80);ev(32'h006440B0);ev(32'h004000E0);
  check(gates==127&&notes==saved_notes&&gains==saved_gains&&busy,"NoteOff CC bend do not mutate running snapshot");
  for(i=0;i<11;i=i+1)begin tick();check(gates==127&&busy,"chord holds to last sample before boundary");end
  tick();silent("chord ends all gates/gains exactly HOLD samples");
  check(selected==saved_selected&&selected_notes==saved_notes&&selected_gains==saved_gains,"playback retains selection");
  // Remove interior slots: ordered playback must ignore holes and insertion order.
  ev(noteon(74,10,0));ev(noteon(68,10,0));
  check(count==5&&!selected[2]&&!selected[4],"selection removes create sparse slots");
  ordered[0]=49;ordered[1]=60;ordered[2]=61;ordered[3]=80;ordered[4]=93;
  mode(1);launch();seen=mask_pitch(49);
  check(gates==seen&&last_triggers==seen,"strum starts lowest actual pitch");
  for(i=1;i<5;i=i+1)begin
   for(j=1;j<4;j=j+1)begin tick();check(gates==seen&&last_triggers==0,"strum interval remains four samples");end
   tick();expected_mask=mask_pitch(ordered[i]);seen=seen|expected_mask;
   check(gates==seen&&last_triggers==expected_mask,"strum next actual pitch cumulative gates");
  end
  for(i=1;i<12;i=i+1)begin tick();check(gates==seen&&busy,"strum final onset holds full duration");end
  tick();silent("strum releases all after final hold");check(count==5,"strum retains sparse selection");
  mode(3);launch();
  for(i=0;i<5;i=i+1)begin
   expected_mask=mask_pitch(ordered[i]);check(gates==expected_mask&&last_triggers==expected_mask,"arp onset sorted one voice");
   for(j=1;j<10;j=j+1)begin
    tick();
    if(j<8)check(gates==expected_mask,"arp 80 percent gate remains active");
    else check(gates==0&&gains==0&&busy,"arp final 20 percent is silent gap");
    check(last_triggers==0,"arp does not retrigger within interval");
   end
   tick();
  end
  silent("arp single pass ends without repeat or stuck voice");
  // Repeated trigger must leave a complete audio sample of clear gates.
  mode(2);launch();pulse_start();check(gates==0&&gains==0&&busy,"retrigger immediately clears old chord");
  tick();check(gates==0&&gains==0,"retrigger blank sample");tick();check(gates==selected&&last_triggers==selected,"retrigger starts all selected voices again");
  ev(noteon(70,50,0));silent("selection edit while busy cancels old snapshot first");
  check(count==6&&mask_pitch(70)!=0,"edit applies after playback cancel");
  mode(1);launch();ev(32'h00ffffff);silent("disconnect cancels playing pattern even malformed payload");check(count==6,"disconnect retains all selected pitches");
  launch();@(negedge clk);cancel=1;start=1;event_valid=1;event_data=noteon(10,80,0);cycles(1);
  @(negedge clk);cancel=0;start=0;event_valid=0;cycles(2);silent("cancel outranks simultaneous start and event");check(count==6,"cancel preserves selection, discards coincident edit");
  launch();mode(3);silent("mode change cancels playing pattern");check(count==6,"mode change retains selection");
  launch();mode(0);silent("direct mode cancels pattern");ev(noteon(12,100,0));check(count==6,"direct mode cannot alter pattern selection");
  mode(2);pulse_start();@(negedge clk);rst=1;cycles(1);check(selected==0&&selected_notes==0&&selected_gains==0&&count==0&&!full,"reset clears all persistent selection");
  @(negedge clk);rst=0;cycles(2);silent("reset cancels pending sorted snapshot");tick();tick();silent("cancelled prep does not launch later");
  // Full capacity can remove existing notes and reuse the hole, no voice steal.
  for(i=0;i<7;i=i+1)ev(noteon(20+i,100,0));ev(noteon(90,100,0));
  check(full&&count==7,"full flag can reassert");ev(noteon(23,1,0));check(count==6,"full selection existing pitch still toggles off");
  ev(noteon(127,99,0));check(count==7&&selected_notes[3*7+:7]==127,"new note uses exact free hole");
  // Independent reference sort for twelve full seven-note chromatic sets.
  // Exercises every rank, endpoint pitches, selection channels, and repeated runs.
  for(trial=0;trial<12;trial=trial+1)begin
   reset_main();
   for(i=0;i<7;i=i+1)begin
    pitches[i]=(i*17+trial*23)%128;
    ev(noteon(pitches[i],i*19+1,0)|trial);
   end
   check(count==7,"all MIDI channels accept seven notes");
   for(i=0;i<7;i=i+1)for(j=i+1;j<7;j=j+1)if(pitches[i]>pitches[j])begin temp_pitch=pitches[i];pitches[i]=pitches[j];pitches[j]=temp_pitch;end
   mode(3);launch();
   for(i=0;i<7;i=i+1)begin
    check(gates==mask_pitch(pitches[i]),"full seven-note reference ascending arp");
    for(j=0;j<10;j=j+1)tick();
   end
   silent("full seven-note arp completes");
   mode(1);launch();seen=mask_pitch(pitches[0]);
   for(i=1;i<7;i=i+1)begin
    for(j=0;j<4;j=j+1)tick();seen=seen|mask_pitch(pitches[i]);
    check(gates==seen&&last_triggers==mask_pitch(pitches[i]),"full seven-note reference ascending strum");
   end
   for(j=0;j<12;j=j+1)tick();silent("full seven-note strum completes");
  end
  // Defaults are exercised with real sample counts, without changing params.
  @(negedge clk);d_rst=0;cycles(3);dev(72);dev(61);dlaunch();check(d_gates==3,"default chord all notes");
  for(n=1;n<39062;n=n+1)dtick();check(d_gates==3&&d_busy,"default chord holds through sample39061");
  dtick();check(d_gates==0&&d_gains==0&&!d_busy,"default chord ends at39062samples~800ms");
  @(negedge clk);d_mode=1;cycles(3);dlaunch();check(d_gates==2,"default strum lowest actual note");
  for(n=1;n<1953;n=n+1)dtick();check(d_gates==2,"default strum no early second onset");dtick();check(d_gates==3,"default strum second onset at1953samples~40ms");
  for(n=1;n<39062;n=n+1)dtick();check(d_gates==3,"default strum final hold boundary before end");dtick();check(!d_busy&&d_gates==0&&d_gains==0,"default strum ends800ms after last onset");
  @(negedge clk);d_mode=3;cycles(3);dlaunch();check(d_gates==2,"default arp lowest first");
  for(n=1;n<9765;n=n+1)dtick();check(d_gates==2,"default arp gate at9764");dtick();check(d_gates==0&&d_gains==0&&d_busy,"default arp gate closes at floor80percent9765");
  for(n=9766;n<12207;n=n+1)dtick();check(d_gates==0,"default arp gap until12206");dtick();check(d_gates==1,"default arp next note12207~250ms");
  for(n=1;n<12207;n=n+1)dtick();check(d_busy,"default arp final duration before end");dtick();check(!d_busy&&d_gates==0&&d_gains==0,"default arp stops after one pass");
  $display("P8_PATTERNS_PASS checks=%0d",checks);$finish;
 end
 initial begin #1000000000;$fatal(1,"watchdog");end
endmodule
