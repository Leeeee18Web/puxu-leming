`timescale 1ns/1ps
// Catches the old absolute PC behavior: first raw sample must only anchor.
module tb_p8_control_red;
 reg clk=0;always #10 clk=~clk;
 reg rst=1,sample_tick=0,event_valid=0,panic=0,centre=0;
 reg [31:0]event_data=0;
 wire event_ready;wire[6:0]gates,triggers,knob,last_note,last_velocity,mod_depth;
 wire[48:0]notes;wire[83:0]gains;wire[18:0]ratio;
 play_voice_control #(.RELATIVE_KNOB(1)) dut(.knob_mode(2'd1),.raw_knob(),.raw_known(),.pickup_wait(),.clk(clk),.rst(rst),.sample_tick(sample_tick),.event_valid(event_valid),.event_data(event_data),.panic(panic),.centre(centre),.event_ready(event_ready),.gates(gates),.triggers(triggers),.knob(knob),.last_note(last_note),.last_velocity(last_velocity),.mod_depth(mod_depth),.notes(notes),.gains(gains),.ratio(ratio));
 initial begin
 repeat(3)@(negedge clk);rst=0;
 @(negedge clk);event_valid=1;event_data=32'h00006ec0;
 @(negedge clk);event_valid=0;
 if(knob!==64)$fatal(1,"P8 first physical sample must anchor without bend jump: want64 got%0d",knob);
 $display("PASS tb_p8_control_red");$finish;
 end
endmodule
