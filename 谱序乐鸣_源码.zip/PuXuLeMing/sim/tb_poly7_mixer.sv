`timescale 1ns/1ps
module tb_poly7_mixer;
 reg clk=0;always #10 clk=~clk;reg rst=1,tick=0;reg[111:0]samples=0,tails=0;reg[48:0]weights=0;reg[6:0]nonzero=0,active=0;reg[5:0]gain=32;
 wire signed[15:0]pcm;wire positive,clip;wire[111:0]history;
 poly25_mixer #(.VOICE_COUNT(7)) dut(clk,rst,tick,samples,tails,weights,nonzero,active,gain,pcm,positive,clip,history);
 reg signed[15:0]expected[0:6];reg signed[63:0]sum,temp,scaled;reg signed[15:0]out_expected;reg sticky=0;integer n,i,j,count,norm;reg[31:0]rng=32'h837a51e3;
 initial begin repeat(4)@(negedge clk);rst=0;
 for(n=0;n<1500;n=n+1)begin
  @(negedge clk);sum=0;nonzero=0;active=0;count=0;gain=n%33;
  for(i=0;i<7;i=i+1)begin
   rng={rng[30:0],rng[31]^rng[21]^rng[1]^rng[0]};samples[i*16+:16]=n==0?32767:n==1?-32768:rng[15:0];
   rng={rng[30:0],rng[31]^rng[21]^rng[1]^rng[0]};tails[i*16+:16]=rng[15:0];weights[i*7+:7]=rng%65;nonzero[i]=n<2?1:rng[7];active[i]=nonzero[i];
   // Explicit wide arithmetic pins signed extension independently of RTL widths.
   temp=$signed(tails[i*16+:16]);scaled=$signed(samples[i*16+:16]);temp=temp-scaled;
   scaled=weights[i*7+:7];temp=temp*scaled;
   expected[i]=nonzero[i]?$signed(samples[i*16+:16])+(temp>>>6):16'sd0;
   sum=sum+expected[i];if(active[i])count=count+1;
  end
  if(n%31==0)begin active=0;count=0;end
  norm=count<=4?32768:131072/count;scaled=sum;scaled=scaled*$signed({1'b0,gain})*norm;scaled=scaled>>>22;
  out_expected=scaled>32767?32767:scaled< -32768?-32768:scaled;
  repeat(20)@(negedge clk);
  for(i=0;i<7;i=i+1)if(history[i*16+:16]!==expected[i])$fatal(1,"POLY_MIX_FADE_FAIL trial%0d voice%0d",n,i);
  if(pcm!==out_expected||positive!==(out_expected>0))$fatal(1,"POLY_MIX_PCM_FAIL trial%0d got%0d expected%0d sum%0d",n,pcm,out_expected,sum);
  tick=1;@(negedge clk);tick=0;if(scaled>32767||scaled< -32768)sticky=1;
  if(clip!==sticky)$fatal(1,"POLY_MIX_CLIP_FAIL");
 end
 $display("POLY7_MIXER_PASS trials1500 7signed fades/21bit sum/normalization/master gain/clip/sign");$finish;
 end
 initial begin #2000000;$fatal(1,"POLY_MIX_TIMEOUT");end
endmodule
