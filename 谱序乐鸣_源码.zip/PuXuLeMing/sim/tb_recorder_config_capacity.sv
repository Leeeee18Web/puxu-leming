`timescale 1ns/1ps
module recorder_config_capacity_equiv_case #(parameter N=7,CAP=64,CASE_ID=0,FRAME=64)(output reg done=0);
 reg clk=0,rst=1;always #10 clk=~clk;
 reg[$clog2(FRAME)-1:0]phase=0;always @(posedge clk)phase<=phase+1'b1;
 wire sample_tick=phase==FRAME-1;
 reg record_toggle=0,replay_toggle=0,clear=0,panic=0;
 reg[N-1:0]in_gates=0,in_triggers=0;reg[N*7-1:0]in_notes=0;
 reg[N*12-1:0]in_gains=0;reg[N*3-1:0]in_timbres=0;reg[18:0]in_ratio=262144;
 reg[6:0]in_mod_depth=0;reg[31:0]in_synth_config=0;
 wire[N-1:0]g[0:1],t[0:1];wire[N*7-1:0]n[0:1];wire[N*12-1:0]v[0:1];wire[N*3-1:0]tm[0:1];wire[18:0]r[0:1];wire[6:0]m[0:1];wire[31:0]c[0:1];
 wire rec[0:1],play[0:1],full[0:1],limit[0:1],ready[0:1];wire[12:0]count[0:1];wire[31:0]time_samples[0:1],duration[0:1];
 wire[95:0] exported[0:1];wire er[0:1];wire[31:0]take[0:1];
 final_recorder #(.EVENT_CAPACITY(CAP),.MAX_SAMPLES(40),.VOICE_COUNT(N))dut(.observer_gains(),.clk(clk),.rst(rst),.sample_tick(sample_tick),.record_toggle(record_toggle),.replay_toggle(replay_toggle),.clear(clear),.panic(panic),
  .in_gates(in_gates),.in_triggers(in_triggers),.in_notes(in_notes),.in_gains(in_gains),.in_timbres(in_timbres),.in_ratio(in_ratio),.in_mod_depth(in_mod_depth),.in_synth_config(in_synth_config),
  .out_gates(g[0]),.out_triggers(t[0]),.out_notes(n[0]),.out_gains(v[0]),.out_timbres(tm[0]),.out_ratio(r[0]),.out_mod_depth(m[0]),.out_synth_config(c[0]),
  .recording(rec[0]),.replaying(play[0]),.full(full[0]),.time_limit(limit[0]),.replay_frame_ready(ready[0]),.count(count[0]),.time_samples(time_samples[0]),.duration_samples(duration[0]),.export_address(12'd0),.export_word(exported[0]),.export_ready(er[0]),.take_id(take[0]),.preview_rst(1'b0),.preview_gates('0),.preview_notes('0),.preview_gains('0),.preview_timbres('0),.preview_ratio('0),.preview_mod_depth('0),.preview_synth_config('0));
 final_recorder_before_config_capacity #(.EVENT_CAPACITY(CAP),.MAX_SAMPLES(40),.VOICE_COUNT(N))reference(.clk(clk),.rst(rst),.sample_tick(sample_tick),.record_toggle(record_toggle),.replay_toggle(replay_toggle),.clear(clear),.panic(panic),
  .in_gates(in_gates),.in_triggers(in_triggers),.in_notes(in_notes),.in_gains(in_gains),.in_timbres(in_timbres),.in_ratio(in_ratio),.in_mod_depth(in_mod_depth),.in_synth_config(in_synth_config),
  .out_gates(g[1]),.out_triggers(t[1]),.out_notes(n[1]),.out_gains(v[1]),.out_timbres(tm[1]),.out_ratio(r[1]),.out_mod_depth(m[1]),.out_synth_config(c[1]),
  .recording(rec[1]),.replaying(play[1]),.full(full[1]),.time_limit(limit[1]),.replay_frame_ready(ready[1]),.count(count[1]),.time_samples(time_samples[1]),.duration_samples(duration[1]),.export_address(12'd0),.export_word(exported[1]),.export_ready(er[1]),.take_id(take[1]));
 integer voice_index;
 reg prior_export_ready=0;
 reg prior_capture_busy=0;
 integer ram_checks=0,ram_index,prep_cycles=0,max_prep=0,raw_differences=0;
 integer checks=0,frames=0,plays=0,fulls=0,limits=0,seed=32'h31415926,k,j;
 always @(negedge clk)if(!rst)begin
  checks++;
  if({dut.capture_busy,dut.capture_index,dut.write_index}!=={reference.capture_busy,reference.capture_index,reference.write_index})$fatal(1,"RECORDER_WRITER_TIMING");
  if(prior_capture_busy&&!dut.capture_busy)begin
   for(ram_index=0;ram_index<count[0];ram_index=ram_index+1)begin
    if($isunknown(dut.event_ram[ram_index])||dut.event_ram[ram_index]!==reference.event_ram[ram_index])$fatal(1,"RECORDER_RAM_DATA address=%0d",ram_index);
    ram_checks++;
   end
  end
  prior_capture_busy=dut.capture_busy;
  if({dut.replay_state,dut.replay_index,dut.read_address,dut.record_time,dut.replay_time,dut.replay_after_capture,dut.mute_frame} !==
     {reference.replay_state,reference.replay_index,reference.read_address,reference.record_time,reference.replay_time,reference.replay_after_capture,reference.mute_frame})$fatal(1,"CONFIG_CAPACITY_INTERNAL_EVERY_CLOCK");
  // Rejected idle scratch has no writer. Every live/recording snapshot remains exact.
  if((dut.recording||dut.capture_busy||reference.recording||reference.capture_busy)&&
     {dut.capture_mask,dut.captured_time}!=={reference.capture_mask,reference.captured_time})$fatal(1,"CONFIG_CAPACITY_CONSUMED_SCRATCH");
  if(play[0]&&!ready[0])begin prep_cycles++;if(prep_cycles>max_prep)max_prep=prep_cycles;end else prep_cycles=0;
  if({g[0],t[0],n[0],v[0],tm[0],r[0],m[0],c[0],ready[0]}!=={g[1],t[1],n[1],v[1],tm[1],r[1],m[1],c[1],ready[1]})$fatal(1,"CONFIG_CAPACITY_PUBLIC_EVERY_CLOCK");
  // Capacity-only refactor: every output and internal transport state stays same-clock.
  if({er[0],take[0],rec[0],play[0],full[0],limit[0],count[0],time_samples[0],duration[0]}!==
     {er[1],take[1],rec[1],play[1],full[1],limit[1],count[1],time_samples[1],duration[1]})
   $fatal(1,"RECORDER_METADATA clock=%0d phase=%0d",checks,phase);
  if(er[0]&&prior_export_ready&&exported[0]!==exported[1])$fatal(1,"RECORDER_EXPORT_WORD");
  prior_export_ready=er[0];
  if(sample_tick)begin
   if(ready[0]!==ready[1]||(play[0]&&!ready[0]))$fatal(1,"RECORDER_FRAME_NOT_READY");
   if({g[0],t[0],n[0],v[0],tm[0],r[0],m[0],c[0]}!=={g[1],t[1],n[1],v[1],tm[1],r[1],m[1],c[1]})
    $fatal(1,"RECORDER_AUDIO_FRAME clock=%0d",checks);
  end
  if(sample_tick)begin frames++;if(play[0])plays++;if(full[0])fulls++;if(limit[0])limits++;end
 end
 task frame(input bit record_cmd,replay_cmd);begin
  @(posedge clk);while(phase!=10)@(posedge clk);
  @(negedge clk);record_toggle=record_cmd;replay_toggle=replay_cmd;
  @(negedge clk);record_toggle=0;replay_toggle=0;
  @(posedge sample_tick);repeat(3)@(posedge clk);
 end endtask
 initial begin
  repeat(5)@(negedge clk);rst=0;
  // All voices plus a high-bit config event share timestamp0; Record->Replay
  // then waits for a second dense capture. Config must not alias voice1.
  if(CAP>=N+1)begin
   in_gates='1;in_synth_config=32'h80000a55;in_mod_depth=127;
   for(voice_index=0;voice_index<N;voice_index=voice_index+1)begin
    in_notes[voice_index*7+:7]=48+voice_index;in_gains[voice_index*12+:12]=1000+voice_index;in_timbres[voice_index*3+:3]=voice_index%4;
   end
   frame(1,0);repeat(2)frame(0,0);
   in_notes=in_notes+1'b1;in_synth_config=32'h000005aa;in_ratio=300001;frame(0,1);
   repeat(8)frame(0,0);clear=1;frame(0,0);clear=0;
   in_gates=0;in_notes=0;in_gains=0;in_timbres=0;in_synth_config=0;in_mod_depth=0;in_ratio=262144;
  end
  in_gates=1;in_gains=100;in_notes=60;frame(1,0);
  repeat(4)frame(0,0);in_triggers=1;in_notes=62;frame(0,1);in_triggers=0;
  repeat(15)frame(0,0);frame(1,0);repeat(45)frame(0,0);frame(0,1);repeat(45)frame(0,0);
  clear=1;frame(0,0);clear=0;frame(1,0);
  for(k=0;k<15;k++)begin in_notes=k;in_gates=k;in_gains=k*987;in_timbres=k;frame(0,0);end
  frame(0,1);repeat(20)frame(0,0);
  for(k=0;k<700;k++)begin
   j=$unsigned($random(seed))%32;
   if(j<12)begin
    in_gates=$random(seed);in_triggers=$random(seed);
    for(voice_index=0;voice_index<N;voice_index=voice_index+1)begin
     in_notes[voice_index*7+:7]=$random(seed);in_gains[voice_index*12+:12]=$random(seed);in_timbres[voice_index*3+:3]=$random(seed);
    end
   end
   if(j==12)begin in_ratio=$random(seed);in_mod_depth=$random(seed);in_synth_config=$random(seed);end
   clear=j==13;panic=j==14;frame(j==15||j==17,j==16||j==17);in_triggers=0;clear=0;panic=0;
  end
  if(plays==0||fulls==0||limits==0)$fatal(1,"RECORDER_EQ coverage incomplete plays=%0d full=%0d limit=%0d",plays,fulls,limits);
  if(ram_checks==0)$fatal(1,"RECORDER_RAM_COVERAGE");
  $display("RECORDER_EQ_PASS N%0d frame%0d clocks=%0d frames=%0d replayframes=%0d fullframes=%0d limitframes=%0d RAM%0d maxprep%0d rawdelta%0d",N,FRAME,checks,frames,plays,fulls,limits,ram_checks,max_prep,raw_differences);done=1;
 end
 initial begin #30000000;if(!done)$fatal(1,"RECORDER_EQ timeout");end
endmodule

module recorder_config_capacity_binary #(parameter N=7,CAP=4096)(output reg done=0);
 reg[12:0]occupied=0;reg[N:0]mask=0;integer count_value,voices,configuration,checks=0;
 final_recorder #(.VOICE_COUNT(N),.EVENT_CAPACITY(CAP)) dut(.observer_gains(),.clk(1'b0),.rst(1'b1),.sample_tick(1'b0),.record_toggle(1'b0),.replay_toggle(1'b0),.clear(1'b0),.panic(1'b0),
 .in_gates({N{1'b0}}),.in_triggers({N{1'b0}}),.in_notes({N*7{1'b0}}),.in_gains({N*12{1'b0}}),.in_timbres({N*3{1'b0}}),.in_ratio(19'd0),.in_mod_depth(7'd0),.in_synth_config(32'd0),.export_address(12'd0),
 .out_gates(),.out_triggers(),.out_notes(),.out_gains(),.out_timbres(),.out_ratio(),.out_mod_depth(),.out_synth_config(),.recording(),.replaying(),.full(),.time_limit(),.replay_frame_ready(),.count(),.time_samples(),.export_word(),.export_ready(),.take_id(),.duration_samples(),.preview_rst(1'b0),.preview_gates('0),.preview_notes('0),.preview_gains('0),.preview_timbres('0),.preview_ratio('0),.preview_mod_depth('0),.preview_synth_config('0));
 final_recorder_before_config_capacity #(.VOICE_COUNT(N),.EVENT_CAPACITY(CAP)) reference(.clk(1'b0),.rst(1'b1),.sample_tick(1'b0),.record_toggle(1'b0),.replay_toggle(1'b0),.clear(1'b0),.panic(1'b0),
 .in_gates({N{1'b0}}),.in_triggers({N{1'b0}}),.in_notes({N*7{1'b0}}),.in_gains({N*12{1'b0}}),.in_timbres({N*3{1'b0}}),.in_ratio(19'd0),.in_mod_depth(7'd0),.in_synth_config(32'd0),.export_address(12'd0),
 .out_gates(),.out_triggers(),.out_notes(),.out_gains(),.out_timbres(),.out_ratio(),.out_mod_depth(),.out_synth_config(),.recording(),.replaying(),.full(),.time_limit(),.replay_frame_ready(),.count(),.time_samples(),.export_word(),.export_ready(),.take_id(),.duration_samples());
 initial begin
  force dut.count=occupied;force reference.count=occupied;force dut.changed=mask;force reference.changed=mask;
  for(count_value=0;count_value<8192;count_value++)begin
   occupied=count_value;
   for(voices=0;voices<=N;voices++)for(configuration=0;configuration<2;configuration++)begin
    mask=(32'd1<<voices)-1;mask[N]=configuration;#1;
    if(dut.changed_count!==voices+configuration||reference.changed_count!==voices+configuration)$fatal(1,"CONFIG_COUNT_SUM N%0d",N);
    if(dut.changed_voice_count!==voices)$fatal(1,"VOICE_ONLY_COUNT N%0d",N);
    if(dut.record_capacity_exceeded !== (reference.count+reference.changed_count>CAP))$fatal(1,"CONFIG_CAPACITY_BINARY N%0d CAP%0d count%0d voices%0d config%0d",N,CAP,count_value,voices,configuration);
    checks++;
   end
  end
  $display("CONFIG_CAPACITY_BINARY_PASS N%0d CAP%0d checks%0d countAll8192_voiceCountAll_configBoth",N,CAP,checks);done=1;
 end
endmodule

module recorder_config_capacity_defaults(output reg done=0);
 localparam N=7,CAP=4096,MAX=2929688;
 reg clk=0,rst=1,tick=0,record_cmd=0,replay_cmd=0;always #10 clk=~clk;
 reg[18:0]ratio=0;reg[11:0]address=0;
 wire rec[0:1],play[0:1],full[0:1],limit[0:1],ready[0:1],er[0:1];wire[12:0]count[0:1];wire[31:0]time_value[0:1],duration[0:1],take[0:1];wire[95:0]word[0:1];
 final_recorder #(.VOICE_COUNT(N)) dut(.observer_gains(),.clk(clk),.rst(rst),.sample_tick(tick),.record_toggle(record_cmd),.replay_toggle(replay_cmd),.clear(1'b0),.panic(1'b0),
 .in_gates(7'd0),.in_triggers(7'd0),.in_notes(49'd0),.in_gains(84'd0),.in_timbres(21'd0),.in_ratio(ratio),.in_mod_depth(7'd0),.in_synth_config(32'd0),.export_address(address),
 .out_gates(),.out_triggers(),.out_notes(),.out_gains(),.out_timbres(),.out_ratio(),.out_mod_depth(),.out_synth_config(),.recording(rec[0]),.replaying(play[0]),.full(full[0]),.time_limit(limit[0]),.replay_frame_ready(ready[0]),.count(count[0]),.time_samples(time_value[0]),.duration_samples(duration[0]),.export_word(word[0]),.export_ready(er[0]),.take_id(take[0]),.preview_rst(1'b0),.preview_gates('0),.preview_notes('0),.preview_gains('0),.preview_timbres('0),.preview_ratio('0),.preview_mod_depth('0),.preview_synth_config('0));
 final_recorder_before_config_capacity #(.VOICE_COUNT(N)) reference(.clk(clk),.rst(rst),.sample_tick(tick),.record_toggle(record_cmd),.replay_toggle(replay_cmd),.clear(1'b0),.panic(1'b0),
 .in_gates(7'd0),.in_triggers(7'd0),.in_notes(49'd0),.in_gains(84'd0),.in_timbres(21'd0),.in_ratio(ratio),.in_mod_depth(7'd0),.in_synth_config(32'd0),.export_address(address),
 .out_gates(),.out_triggers(),.out_notes(),.out_gains(),.out_timbres(),.out_ratio(),.out_mod_depth(),.out_synth_config(),.recording(rec[1]),.replaying(play[1]),.full(full[1]),.time_limit(limit[1]),.replay_frame_ready(ready[1]),.count(count[1]),.time_samples(time_value[1]),.duration_samples(duration[1]),.export_word(word[1]),.export_ready(er[1]),.take_id(take[1]));
 integer i,checks=0,exported=0;
 always @(negedge clk)if(!rst)begin
  if({rec[0],play[0],full[0],limit[0],ready[0],count[0],time_value[0],duration[0],er[0],take[0],dut.replay_state,dut.replay_index,dut.capture_busy} !==
     {rec[1],play[1],full[1],limit[1],ready[1],count[1],time_value[1],duration[1],er[1],take[1],reference.replay_state,reference.replay_index,reference.capture_busy})$fatal(1,"DEFAULT4096_60S_EVERY_CLOCK");
  checks++;
 end
 task frame(input bit record_value,replay_value);begin
  @(negedge clk);tick=1;record_cmd=record_value;replay_cmd=replay_value;
  @(negedge clk);tick=0;record_cmd=0;replay_cmd=0;repeat(12)@(negedge clk);
 end endtask
 initial begin
  repeat(4)@(negedge clk);rst=0;frame(1,0);
  for(i=1;i<CAP;i++)begin ratio=i;frame(0,0);end
  if(count[0]!=4096||!rec[0]||full[0]||dut.capture_busy)$fatal(1,"DEFAULT4096_LAST_ENTRY");
  frame(0,0);if(count[0]!=4096||!rec[0]||full[0])$fatal(1,"DEFAULT4096_ZERO_INCREMENT_ALLOWED");
  ratio=4096;frame(0,0);if(count[0]!=4096||rec[0]||!full[0]||!er[0])$fatal(1,"DEFAULT4096_NEXT_CONFIG_REJECTED");
  for(i=0;i<4096;i++)begin
   @(negedge clk);address=i;@(negedge clk);
   if($isunknown(word[0])||word[0]!==word[1]||dut.event_ram[i]!==reference.event_ram[i])$fatal(1,"DEFAULT4096_EXPORTED_WORD address%0d",i);exported++;
  end
  // Counter fixture reaches the real60s edge without simulating billions of clocks.
  rst=1;repeat(4)@(negedge clk);rst=0;ratio=0;frame(1,0);
  @(negedge clk);dut.record_time=MAX-2;reference.record_time=MAX-2;dut.duration_samples=MAX-2;reference.duration_samples=MAX-2;
  frame(0,0);if(!rec[0]||duration[0]!=MAX-1||limit[0])$fatal(1,"REAL60S_LAST_SAMPLE_ADMITTED");
  frame(0,1);if(rec[0]||!limit[0]||full[0]||!play[0]||!ready[0]||duration[0]!=MAX-1||count[0]!=1)$fatal(1,"REAL60S_NEXT_SAMPLE_STOP_REPLAY_SAME_EDGE");
  $display("CONFIG_CAPACITY_DEFAULTS_PASS checks%0d exported%0d realCapacity4096_zeroDeltaAtFull_nextConfigRejected realMAX2929688_prevSampleAdmitted_exactStopAndReplayReady",checks,exported);done=1;
 end
endmodule

module tb_recorder_config_capacity_equiv;
 wire[8:0]done;
 recorder_config_capacity_equiv_case #(.N(4),.CAP(32),.CASE_ID(0)) e4(done[0]);
 recorder_config_capacity_equiv_case #(.N(7),.CAP(64),.CASE_ID(1)) e7(done[1]);
 recorder_config_capacity_equiv_case #(.N(25),.CAP(128),.CASE_ID(2),.FRAME(256)) e25(done[2]);
 recorder_config_capacity_equiv_case #(.N(7),.CAP(3),.CASE_ID(3)) e_small(done[3]);
 recorder_config_capacity_equiv_case #(.N(7),.CAP(64),.CASE_ID(4),.FRAME(1024)) e_real(done[4]);
 recorder_config_capacity_binary #(.N(4),.CAP(32)) b4(done[5]);
 recorder_config_capacity_binary #(.N(7),.CAP(4096)) b7(done[6]);
 recorder_config_capacity_binary #(.N(25),.CAP(3)) b25(done[7]);
 recorder_config_capacity_defaults defaults(done[8]);
 initial begin wait(&done);$display("RECORDER_CONFIG_CAPACITY_EQ_PASS completeOldRTL_sameClock_allOutputsReadyWriterSnapshotRAM");$finish;end
 initial begin #31000000;$fatal(1,"RECORDER_CONFIG_CAPACITY_TIMEOUT");end
endmodule

module tb_recorder_config_capacity_boundary;
 reg clk=0,rst=1,tick=0,record_cmd=0;always #10 clk=~clk;reg[18:0]ratio=0;wire recording,full;wire[12:0]count;
 final_recorder #(.VOICE_COUNT(7),.EVENT_CAPACITY(3)) dut(
 .observer_gains(),.clk(clk),.rst(rst),.sample_tick(tick),.record_toggle(record_cmd),.replay_toggle(1'b0),.clear(1'b0),.panic(1'b0),
 .in_gates(7'd0),.in_triggers(7'd0),.in_notes(49'd0),.in_gains(84'd0),.in_timbres(21'd0),.in_ratio(ratio),.in_mod_depth(7'd0),.in_synth_config(32'd0),.export_address(12'd0),
 .out_gates(),.out_triggers(),.out_notes(),.out_gains(),.out_timbres(),.out_ratio(),.out_mod_depth(),.out_synth_config(),.recording(recording),.replaying(),.full(full),.time_limit(),.replay_frame_ready(),.count(count),.time_samples(),.export_word(),.export_ready(),.take_id(),.duration_samples(),.preview_rst(1'b0),.preview_gates('0),.preview_notes('0),.preview_gains('0),.preview_timbres('0),.preview_ratio('0),.preview_mod_depth('0),.preview_synth_config('0));
 task frame(input bit command_value);begin
  @(negedge clk);tick=1;record_cmd=command_value;
  @(negedge clk);tick=0;record_cmd=0;repeat(12)@(negedge clk);
 end endtask
 initial begin
  repeat(4)@(negedge clk);rst=0;frame(1);ratio=1;frame(0);ratio=2;frame(0);
  if(count!=3||!recording||full||dut.capture_busy||dut.changed_count!=0)$fatal(1,"CONFIG_CAPACITY_BOUNDARY_SETUP");
  // Deliberately perturb only the old total-count net. Ordinary RTL equivalence
  // above never forces this inconsistency; this probe isolates the state cone.
  force dut.changed_count=7'd1;
  @(negedge clk);tick=1;@(posedge clk);#1;
  if(!recording||full)$fatal(1,"CONFIG_CAPACITY_STATE_STILL_USES_TOTAL_COUNT");
  release dut.changed_count;
  $display("CONFIG_CAPACITY_BOUNDARY_PASS finalConfigurationBitSelectsParallelVoiceCapacity_withoutTotalPopcountInStateCone");$finish;
 end
 initial begin #5000;$fatal(1,"CONFIG_CAPACITY_BOUNDARY_TIMEOUT");end
endmodule
