`timescale 1ns/1ps
module tb_poly_filter_operand_equiv;
 `include "src/poly/poly_model_layout.vh"
 reg clk=0;always #10 clk=~clk;
 reg rst=1,tick=0,trig=0,en=1,load=0,gate=1;reg[2:0]kind=1;
 reg[11:0]velocity=2400;reg[23:0]step=1000000;
 reg signed[17:0]bridge=0,mem_q=0;reg[`POLY_MODEL_LINE_W-1:0]saved=0;
 wire signed[17:0]samplea,sampleb,incidenta,incidentb,nexta,nextb;
 wire[15:0]enva,envb,impacta,impactb;wire busya,busyb,erra,errb,wea,web;
 wire[12:0]raa,rab,waa,wab;wire[17:0]wda,wdb;wire[`POLY_MODEL_LINE_W-1:0]snapshota,snapshotb;
 poly_model_line #(.LENGTH(64),.INDEX(0),.PREDECODE_PIANO(1)) dut(.clk(clk),.rst(rst),.tick(tick),.trigger(trig),.gate(gate),.kind(kind),.velocity(velocity),.step(step),.rate_shift(2'd0),.period_q10(24'd20000),.sample(samplea),.envelope(enva),.busy(busya),.deadline_error(erra),.bridge_return(bridge),.bridge_incident(incidenta),.piano_mode(kind==1),.bridge_incident_next(nexta),.ctx_enable(en),.ctx_load(load),.ctx_data(saved),.ctx_state(snapshota),.mem_q(mem_q),.mem_raddr(raa),.mem_waddr(waa),.mem_we(wea),.mem_data(wda),.shared_tuning(16'd0),.shared_impact(18'sd0),.impact_phase(impacta));
 poly_line_before_control #(.LENGTH(64),.INDEX(0),.PREDECODE_PIANO(1)) reference(.clk(clk),.rst(rst),.tick(tick),.trigger(trig),.gate(gate),.kind(kind),.velocity(velocity),.step(step),.rate_shift(2'd0),.period_q10(24'd20000),.sample(sampleb),.envelope(envb),.busy(busyb),.deadline_error(errb),.bridge_return(bridge),.bridge_incident(incidentb),.piano_mode(kind==1),.bridge_incident_next(nextb),.ctx_enable(en),.ctx_load(load),.ctx_data(saved),.ctx_state(snapshotb),.mem_q(mem_q),.mem_raddr(rab),.mem_waddr(wab),.mem_we(web),.mem_data(wdb),.shared_tuning(16'd0),.shared_impact(18'sd0),.impact_phase(impactb));
 reg signed[17:0]ram[0:63];reg[31:0]rng=32'h73ac81e2;integer i,captures[0:3],checks=0,loads=0,pauses=0;
 initial begin
  for(i=0;i<64;i=i+1)ram[i]=0;for(i=0;i<4;i=i+1)captures[i]=0;
  repeat(3)@(negedge clk);rst=0;
  for(i=0;i<24000;i=i+1)begin
   rng={rng[30:0],rng[31]^rng[21]^rng[1]^rng[0]};
   en=(rng[3:0]!=0);rst=(i==8000||i==16000);trig=(i%2000==1);tick=!busyb&&(i%3==0);gate=i<22000;
   load=(i%701==0)&&(reference.state<=3);if(load)loads=loads+1;if(!en)pauses=pauses+1;
   if(trig)begin kind=(i/2000)%2?1:2;velocity=(i/2000)%3?2400:1000;end
   bridge=rng[17:0];mem_q=ram[rab%64];
   if(reference.state<=3&&!load)saved=snapshotb;
   #1;
   if(en&&!load&&!rst&&!trig)case(reference.state)
    10:captures[0]++;11:captures[1]++;13:captures[2]++;14:captures[3]++;
   endcase
   if(en&&!load&&!rst&&!trig&&(reference.state==10||reference.state==11||reference.state==13||reference.state==14)&&
      {dut.filter_a,dut.filter_b}!=={reference.filter_a,reference.filter_b})$fatal(1,"FILTER_OPERAND_EQ state%0d cycle%0d",reference.state,i);
   @(posedge clk);#1;
   if({samplea,enva,busya,erra,incidenta,nexta,wea,waa,raa,wda,impacta,snapshota}!==
      {sampleb,envb,busyb,errb,incidentb,nextb,web,wab,rab,wdb,impactb,snapshotb})$fatal(1,"FILTER_LINE_EQ cycle%0d state%0d/%0d",i,dut.state,reference.state);
   if({dut.product,dut.product_floor,dut.product_carry,dut.filter_wide,dut.allpass,dut.work}!==
      {reference.product,reference.product_floor,reference.product_carry,reference.filter_wide,reference.allpass,reference.work})$fatal(1,"FILTER_CAPTURE_EQ cycle%0d state%0d",i,dut.state);
   if(en&&wea)ram[waa%64]=wda;
   checks++;@(negedge clk);
  end
  if(loads==0||pauses==0||captures[0]<20||captures[1]<20||captures[2]<20||captures[3]<20)$fatal(1,"FILTER_OPERAND_COVERAGE");
  $display("POLY_FILTER_OPERAND_EQ_PASS checks%0d capture%0d/%0d/%0d/%0d loads%0d pauses%0d original private line exact state/outputs/memory/product",checks,captures[0],captures[1],captures[2],captures[3],loads,pauses);$finish;
 end
endmodule
