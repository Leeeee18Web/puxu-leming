`timescale 1ns/1ps
module tb_p8_history_cycle;
 reg clk=0,pclk=0,rst=1,prstn=0,tick=0,frame=0,restart=0,frames_on=1;
 always #10 clk=~clk;always #13 pclk=~pclk;
 reg[10:0] pitch=960;reg valid=1;
 wire[10:0] data;wire[16:0] curve;wire[9:0] count;
 tone_history #(.TOTAL_SAMPLES(112),.COLUMNS(28),.READ_GATED(1)) dut(.clk(clk),.rst(rst),.restart(restart),.sample_tick(tick),.recording(1'b1),.pitch(pitch),.pitch_valid(valid),.pixel_clk(pclk),.pixel_rstn(prstn),.frame_start(frame),.read_addr(10'd0),.read_enable(1'b1),.pitch_data(data),.visible_count(count),.curve_sum(curve));
 integer cycles=0,pc=0,wraps=0;reg[9:0] previous_count=0;reg previous_bank=0;
 always @(negedge clk)begin cycles=cycles+1;tick=cycles%4==0;end
 always @(negedge pclk)begin pc=pc+1;frame=frames_on&&pc%19==0;end
 always @(posedge clk)if(!rst&&dut.store_sample&&dut.writer==dut.display_bank&&dut.column<count)$fatal(1,"history overwrites frame-visible column");
 always @(posedge pclk)begin #1;if(prstn&&previous_count!=0&&count==0)wraps=wraps+1;previous_count=count;end
 reg frozenbank;reg[9:0] frozencount;reg[10:0] frozenpitch;
 initial begin
  repeat(5)@(negedge clk);rst=0;prstn=1;wait(count>=12);
  @(negedge pclk);frames_on=0;frame=0;repeat(5)@(negedge pclk);
  frozenbank=dut.display_bank;frozencount=count;frozenpitch=data;
  wait(dut.column==28);repeat(100)@(negedge clk);
  if(dut.display_bank!==frozenbank||count!==frozencount||data!==frozenpitch)$fatal(1,"stalled frame not held through history full");
  @(negedge clk);restart=1;pitch=1152;@(negedge clk);restart=0;
  repeat(80)@(negedge clk);
  if(dut.writer!==frozenbank||dut.display_bank!==frozenbank||count!==frozencount||data!==frozenpitch)$fatal(1,"restart recycled pixel-owned bank before ACK");
  frames_on=1;wait(count==0);wait(count>=8);repeat(3)@(negedge pclk);if(data!==1152)$fatal(1,"restart did not publish new pitch");
  wait(wraps>=3);valid=0;wait(count>=8);wait(count==0);wait(count>=8);repeat(3)@(negedge pclk);if(data!==2047)$fatal(1,"cyclic rests retain old note");
  $display("P8_HISTORY_CYCLE_PASS full stalls restart pending three cyclic passes no visible overwrites rests");$finish;
 end
 initial begin #500000;$fatal(1,"cycle deadline");end
endmodule

