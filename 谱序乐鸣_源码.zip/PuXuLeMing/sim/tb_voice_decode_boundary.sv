`timescale 1ns/1ps
module tb_voice_decode_boundary;
 reg clk=0;always #10 clk=~clk;
 reg rst=1,event_valid=0,panic=0,map_apply=0;reg[31:0]event_data=0;reg[1:0]event_source=3;
 reg[174:0]map_notes=0;wire ready;wire[6:0]gates,triggers;wire[48:0]notes;wire[83:0]gains;
 final_voice_control #(.VOICE_COUNT(7),.ENABLE_PEDAL(1)) dut(.clk(clk),.rst(rst),.sample_tick(1'b0),.event_valid(event_valid),.event_data(event_data),.event_ready(ready),.panic(panic),.centre(1'b0),.pedal_down(1'b0),.timbre_select(3'd2),.voice_active(7'd0),.timbres(),.gates(gates),.notes(notes),.gains(gains),.triggers(triggers),.ratio(),.knob(),.last_note(),.last_velocity(),.mod_depth(),.knob_mode(2'd1),.raw_knob(),.raw_known(),.pickup_wait(),.event_source(event_source),.map_notes(map_notes),.map_input_base(7'd60),.map_enabled(1'b1),.map_apply(map_apply),.key_seen_valid(),.key_seen_index(),.ready_raw());
 initial begin
  map_notes[24*7+:7]=127;repeat(3)@(negedge clk);rst=0;
  event_data={7'd24,1'b1,1'b0,7'd100,1'b0,7'd72,8'h9e};event_valid=1;#1;
  if(ready!==0)$fatal(1,"VOICE_DECODE_PREFETCH_MISSING");
  @(posedge clk);#1;if(ready!==1||gates!=0)$fatal(1,"prefetch must not commit");
  @(posedge clk);#1;if(ready!==0||gates!=1||notes[6:0]!=127||dut.original_keys[0]!=24||dut.owners[0]!=3||dut.channels[0]!=14)$fatal(1,"indexed event fields lost");
  @(negedge clk);event_valid=0;
  @(negedge clk);event_data={7'd24,1'b0,1'b0,7'd0,1'b0,7'd12,8'h8e};event_valid=1;
  @(posedge clk);#1;@(posedge clk);#1;if(gates!=0)$fatal(1,"indexed off original key lost");
  @(negedge clk);event_valid=0;
  @(negedge clk);event_data={7'd0,1'b0,1'b0,7'd100,1'b0,7'd60,8'h90};event_source=1;event_valid=1;
  @(posedge clk);#1;@(negedge clk);panic=1;
  @(posedge clk);#1;if(gates!=0||triggers!=0)$fatal(1,"panic failed to flush prefetched event");
  @(negedge clk);panic=0;event_valid=0;repeat(3)@(negedge clk);if(gates!=0)$fatal(1,"flushed event committed later");
  event_valid=1;@(posedge clk);#1;@(negedge clk);map_apply=1;#1;
  if(ready!==0)$fatal(1,"map apply must suppress acceptance");
  @(posedge clk);#1;if(gates!=0||triggers!=0)$fatal(1,"map apply failed to flush token");
  @(negedge clk);event_valid=0;map_apply=0;repeat(3)@(negedge clk);
  if(gates!=0||ready!=0)$fatal(1,"map-flushed event committed later");
  $display("VOICE_DECODE_BOUNDARY_PASS prefetch/commit/indexed upper7/source/panic/mapapply flush");$finish;
 end
endmodule
