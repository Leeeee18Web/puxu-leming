// P8 graph producer bridge. All audio-domain inputs are actual synthesis state.
// PCM waveform/FFT is the mixed output. Pitch/XY follow the selected voice.
// The parent resets the producer whenever synchronized video_up is low.
module p8_visuals_before_pixel_pipeline #(
 parameter REGISTERED_PCM_POSITIVE=0,
 parameter HISTORY_SAMPLES=1464844,
 parameter XY_POINTS=64
)(
 input wire clk,rst,sample_tick,
 input wire signed [15:0] pcm,input wire pcm_positive,
 input wire [6:0] leading_note,
 input wire [10:0] leading_pitch,
 input wire [23:0] leading_step,
 input wire [15:0] leading_envelope,
 input wire leading_valid,restart,
 input wire [5:0] requested_config,
 input wire pixel_clk,pixel_rstn,frame_start,
 input wire [2:0] page,
 input wire [13:0] x,
 input wire [9:0] wave_addr,
 input wire [6:0] spectrum_addr,
 input wire [9:0] tone_addr,
 input wire [15:0] xy_addr,
 output wire [47:0] wave_data,
 output wire [7:0] spectrum_data,spectrum_peak,
 output wire visual_valid,
 output wire [10:0] tone_data,
 output wire [16:0] tone_curve,
 output wire [9:0] tone_count,
 output wire xy_data,xy_valid,
 output wire [5:0] xy_settings
);
 // Register only the FFT observation tuple. Audio, history and XY keep their
 // original paths; the FFT producer observes the same samples one clock later.
 (* syn_preserve=1 *) reg fft_rst_q=1,fft_sample_tick_q=0,fft_positive_q=0;
 (* syn_preserve=1 *) reg signed [15:0] fft_pcm_q=0;
 (* syn_preserve=1 *) reg [5:0] fft_note_q=0;
 (* syn_preserve=1 *) reg fft_playing_q=0;
 always @(posedge clk)begin
  fft_rst_q<=rst;fft_sample_tick_q<=sample_tick;
  fft_pcm_q<=pcm;fft_positive_q<=pcm_positive;
  fft_note_q<=leading_note[5:0];fft_playing_q<=leading_valid;
 end
 audio_visualizer #(.REGISTERED_PCM_POSITIVE(REGISTERED_PCM_POSITIVE)) fft(
  .clk(clk),.rst(fft_rst_q),.sample_tick(fft_sample_tick_q),.pcm(fft_pcm_q),.pcm_positive(fft_positive_q),
  .component_a(16'sd0),.component_b(16'sd0),
  .note_index(fft_note_q),.current_note(3'd0),.next_note(3'd0),.playing(fft_playing_q),
  .pixel_clk(pixel_clk),.pixel_rstn(pixel_rstn),.frame_start(frame_start),
  .wave_addr(wave_addr),.spectrum_addr(spectrum_addr),.xy_addr(16'd0),
  .wave_data(wave_data),.spectrum_data(spectrum_data),.xy_data(),
  .valid(visual_valid),.meta(),.spectrum_peak(spectrum_peak));
 tone_history_before_pixel_pipeline #(.TOTAL_SAMPLES(HISTORY_SAMPLES),.READ_GATED(1)) history(
  .clk(clk),.rst(rst),.restart(restart),.sample_tick(sample_tick),
  .recording(1'b1),.pitch(leading_pitch),.pitch_valid(leading_valid),
  .pixel_clk(pixel_clk),.pixel_rstn(pixel_rstn),.frame_start(frame_start),
  .read_addr(tone_addr),.read_enable(page==3'd1&&x>=14'd128&&x<14'd896),
  .pitch_data(tone_data),.visible_count(tone_count),.curve_sum(tone_curve));
 dynamic_xy #(.POINTS(XY_POINTS)) xy(
  .clk(clk),.rst(rst),.sample_tick(sample_tick),.active(leading_valid),
  .note_step(leading_step),.envelope(leading_envelope),.requested_config(requested_config),
  .pixel_clk(pixel_clk),.pixel_rstn(pixel_rstn),.frame_start(frame_start),
  .read_addr(xy_addr),.data(xy_data),.valid(xy_valid),.shown_config(xy_settings));
endmodule

