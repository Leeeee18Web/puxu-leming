// P3 plotting geometry, colours, normalization and sample semantics retained.
// This module is only the graph; navigation and keyboard are in p8_panel.
module p8_graph_history_reference(input pixel_clk,input [13:0] x,y,input [2:0] page,
 input [47:0] wave_data,input [7:0] spectrum_data,spectrum_peak,
 input visual_valid,input [10:0] tone_data,input [16:0] tone_curve,
 input [9:0] tone_count,input xy_data,xy_valid,input [5:0] xy_settings,
 output reg [23:0] color);
 reg [23:0] color_comb;
 reg [15:0] gain[0:255] /* synthesis syn_romstyle="block_rom" */;
 initial $readmemh("src/ui/spectrum_gain.hex",gain);
 reg [15:0] display_gain=0;
 reg [16:0] previous_curve=0;reg [10:0] previous_tone=2047;
 reg signed [15:0] previous_wave=0;
 always @(posedge pixel_clk)begin
  display_gain<=gain[spectrum_peak];previous_curve<=tone_curve;
  previous_tone<=tone_data;previous_wave<=wave_data[15:0];
 end

 // Cut 1: exact RAM outputs and original previous-sample state.
 reg [13:0] s_x=0;
 reg [13:0] s_y=0;
 reg [2:0] s_page=0;
 reg [47:0] s_wave_data=0;
 reg [7:0] s_spectrum_data=0;
 reg s_visual_valid=0;
 reg [10:0] s_tone_data=0;
 reg [16:0] s_tone_curve=0;
 reg [9:0] s_tone_count=0;
 reg s_xy_data=0;
 reg s_xy_valid=0;
 reg [16:0] s_previous_curve=0;
 reg [10:0] s_previous_tone=0;
 reg signed [15:0] s_previous_wave=0;
 reg [15:0] s_display_gain=0;
 always @(posedge pixel_clk)begin
  s_x<=x;
  s_y<=y;
  s_page<=page;
  s_wave_data<=wave_data;
  s_spectrum_data<=spectrum_data;
  s_visual_valid<=visual_valid;
  s_tone_data<=tone_data;
  s_tone_curve<=tone_curve;
  s_tone_count<=tone_count;
  s_xy_data<=xy_data;
  s_xy_valid<=xy_valid;
  s_previous_curve<=previous_curve;
  s_previous_tone<=previous_tone;
  s_previous_wave<=previous_wave;
  s_display_gain<=display_gain;
 end
 wire [23:0] product=s_spectrum_data*s_display_gain;
 wire [8:0] height=product[23:8]>240?9'd240:product[16:8];
 integer wy,old_y,lo,hi;
 always @*begin
  color_comb=24'h10151b;wy=0;old_y=0;lo=0;hi=0;
  if(s_page==1||s_page==2)begin
   if(s_x>=128&&s_x<896&&s_y>=208&&s_y<496)begin
    color_comb=24'h0d1821;
    if(s_x[6:0]==0||s_y==228||s_y==263||s_y==312||s_y==347||s_y==396||s_y==431||s_y==480)color_comb=24'h263c4a;
    if(s_x<130||s_x>=894||s_y<210||s_y>=494)color_comb=24'h426574;
    if(s_page==1&&s_x-128<s_tone_count&&s_tone_data!=2047&&s_previous_tone!=2047)begin
     wy=s_tone_curve>>8;old_y=s_previous_curve>>8;
     if(wy<212)wy=212;if(wy>492)wy=492;
     if(old_y<212)old_y=212;if(old_y>492)old_y=492;
     lo=wy<old_y?wy:old_y;hi=wy>old_y?wy:old_y;
     if(s_y>=lo-1&&s_y<=hi+1)color_comb=24'hf5c767;
     else if(s_y>=lo-3&&s_y<=hi+3)color_comb=24'h6b5934;
    end
    if(s_page==2&&s_visual_valid&&s_y>=492-height)color_comb=24'h60d9ed;
   end
  end else if(s_page==3)begin
   if(s_x>=304&&s_x<720&&s_y>=180&&s_y<488)begin
    color_comb=24'h0c151f;
    if(s_x==512||s_y==344||s_x==416||s_x==608||s_y==260||s_y==412)color_comb=24'h273b4a;
    if(s_x<306||s_x>=718||s_y<182||s_y>=486)color_comb=24'h465c70;
    if(s_x>=384&&s_x<640&&s_y>=216&&s_y<472&&s_xy_valid&&s_xy_data)color_comb=24'hf5c767;
   end
  end else if(s_page==4)begin
   if(s_x>=32&&s_x<992&&s_y>=208&&s_y<544)begin
    color_comb=24'h0d1821;
    if(s_x[6:0]==0||s_y==248||s_y==312||s_y==376||s_y==440||s_y==504)color_comb=24'h263c4a;
    if(s_x<34||s_x>=990||s_y<210||s_y>=542)color_comb=24'h426574;
    if(s_y==376)color_comb=24'h465c70;
    wy=376-($signed(s_wave_data[15:0])>>>8);
    old_y=s_x==32?wy:376-($signed(s_previous_wave)>>>8);
    lo=wy<old_y?wy:old_y;hi=wy>old_y?wy:old_y;
    if(s_visual_valid&&s_y>=lo&&s_y<=hi)color_comb=24'hf5c767;
   end
  end
 end
 // Cut 2: graph clamp/colour is separate from panel overlays.
 always @(posedge pixel_clk) color<=color_comb;
endmodule
