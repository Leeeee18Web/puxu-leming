`timescale 1ns/1ps
// Volatile, post-expansion control-event recorder. One synchronous 96-bit
// timestamp/payload RAM; no PCM or backpressure in the live datapath.
module final_recorder_before_admit_ce #(
 parameter integer EVENT_CAPACITY=4096,
 parameter integer MAX_SAMPLES=2929688,
 parameter integer VOICE_COUNT=4
)(
 input wire clk,rst,sample_tick,record_toggle,replay_toggle,clear,panic,
 input wire [VOICE_COUNT-1:0] in_gates,in_triggers,
 input wire [VOICE_COUNT*7-1:0] in_notes,
 input wire [VOICE_COUNT*12-1:0] in_gains,
 input wire [VOICE_COUNT*3-1:0] in_timbres,
 input wire [18:0] in_ratio,
 input wire [6:0] in_mod_depth,
 input wire [31:0] in_synth_config,
 output wire [VOICE_COUNT-1:0] out_gates,out_triggers,
 output wire [VOICE_COUNT*7-1:0] out_notes,
 output wire [VOICE_COUNT*12-1:0] out_gains,
 output wire [VOICE_COUNT*3-1:0] out_timbres,
 output wire [18:0] out_ratio,
 output wire [6:0] out_mod_depth,
 output wire [31:0] out_synth_config,
 output reg recording=0,replaying=0,full=0,time_limit=0,
 output wire replay_frame_ready,
 output reg [12:0] count=0,
 output wire [31:0] time_samples,
 input wire [11:0] export_address,
 output wire [95:0] export_word,output wire export_ready,output reg [31:0] take_id=0,
 output reg [31:0] duration_samples=0
);
 reg [95:0] event_ram[0:EVENT_CAPACITY-1];
 // RAM read deliberately synchronous for embedded block RAM inference.
 reg [11:0] read_address=0;
 reg [95:0] read_word=0;
 

 reg pending_record=0,pending_replay=0,pending_clear=0,pending_panic=0;
 reg [VOICE_COUNT-1:0] pending_triggers=0;
 wire cmd_record=pending_record|record_toggle;
 wire cmd_replay=pending_replay|replay_toggle;
 wire cmd_clear=pending_clear|clear;
 wire cmd_panic=pending_panic|panic;
 reg have_take=0,mute_frame=0;
 reg [31:0] record_time=0,replay_time=0;
 assign time_samples=recording?record_time:replaying?replay_time:duration_samples;

 reg [VOICE_COUNT-1:0] previous_gates=0;
 reg [VOICE_COUNT*7-1:0] previous_notes=0;
 reg [VOICE_COUNT*12-1:0] previous_gains=0;
 reg [VOICE_COUNT*3-1:0] previous_timbres=0;
 reg [18:0] previous_ratio=0;
 reg [6:0] previous_mod=0;
 reg [31:0] previous_config=0;
 reg [VOICE_COUNT-1:0] captured_gates=0,captured_triggers=0;
 reg [VOICE_COUNT*7-1:0] captured_notes=0;
 reg [VOICE_COUNT*12-1:0] captured_gains=0;
 reg [VOICE_COUNT*3-1:0] captured_timbres=0;
 reg [18:0] captured_ratio=0;
 reg [6:0] captured_mod=0;
 reg [31:0] captured_config=0,captured_time=0;
 reg [VOICE_COUNT:0] capture_mask=0;
 reg [5:0] capture_index=0;
 reg [12:0] write_index=0;
 reg capture_busy=0,replay_after_capture=0;
 assign export_ready=have_take&&!recording&&!replaying&&!capture_busy;
 assign export_word=read_word;
 always @(posedge clk) read_word<=event_ram[export_ready?export_address:read_address];

 // A frame is admitted in its entirety. This popcount/reservation prevents
 // capacity exhaustion from leaving half of a VOICE_COUNT-note chord in a take.
 reg [VOICE_COUNT:0] changed,initial_changed;
 // Balanced population counts keep the25-voice reservation off a linear adder chain.
 localparam integer COUNT_LEAVES=1<<$clog2(VOICE_COUNT+1);
 wire [6:0] changed_tree[1:2*COUNT_LEAVES-1],initial_tree[1:2*COUNT_LEAVES-1],voice_tree[1:2*COUNT_LEAVES-1];
 wire [6:0] changed_count=changed_tree[1],initial_count=initial_tree[1];
 wire [6:0] changed_voice_count=voice_tree[1];
 // Compare each constant reservation threshold in parallel with the change
 // popcount. Its result selects one bit, without a count+popcount carry chain
 // feeding the playback/control enables on the same frame boundary.
 wire [VOICE_COUNT+1:0] capacity_exceeded;
 genvar reservation_increment;
 generate for(reservation_increment=0;reservation_increment<=VOICE_COUNT+1;reservation_increment=reservation_increment+1)begin:reservation_limits
  if(reservation_increment>EVENT_CAPACITY)begin:too_large
   assign capacity_exceeded[reservation_increment]=1'b1;
  end else begin:fits
   assign capacity_exceeded[reservation_increment]=count>EVENT_CAPACITY-reservation_increment;
  end
 end endgenerate
 genvar count_leaf,count_node;
 generate for(count_leaf=0;count_leaf<COUNT_LEAVES;count_leaf=count_leaf+1)begin:count_leaves
  assign voice_tree[COUNT_LEAVES+count_leaf]=count_leaf<VOICE_COUNT?changed_tree[COUNT_LEAVES+count_leaf]:7'd0;
  if(count_leaf<=VOICE_COUNT)begin:present
   assign changed_tree[COUNT_LEAVES+count_leaf]={6'd0,changed[count_leaf]};
   assign initial_tree[COUNT_LEAVES+count_leaf]={6'd0,initial_changed[count_leaf]};
  end else begin:padding
   assign changed_tree[COUNT_LEAVES+count_leaf]=0;assign initial_tree[COUNT_LEAVES+count_leaf]=0;
  end
 end
 for(count_node=1;count_node<COUNT_LEAVES;count_node=count_node+1)begin:count_branches
  assign changed_tree[count_node]=changed_tree[count_node*2]+changed_tree[count_node*2+1];
  assign voice_tree[count_node]=voice_tree[count_node*2]+voice_tree[count_node*2+1];
  assign initial_tree[count_node]=initial_tree[count_node*2]+initial_tree[count_node*2+1];
 end endgenerate
 // Count voice changes in parallel with configuration comparison. Only the
 // final one-bit selection depends on configuration; the original full count
 // remains unchanged for RAM reservation, count updates and event timestamps.
 wire [VOICE_COUNT:0] limits_without_configuration=capacity_exceeded[VOICE_COUNT:0];
 wire [VOICE_COUNT:0] limits_with_configuration=capacity_exceeded[VOICE_COUNT+1:1];
 (* syn_keep=1 *) wire exceeded_without_configuration=limits_without_configuration[changed_voice_count];
 (* syn_keep=1 *) wire exceeded_with_configuration=limits_with_configuration[changed_voice_count];
 wire record_capacity_exceeded=changed[VOICE_COUNT]?exceeded_with_configuration:exceeded_without_configuration;
 integer k;
 wire start_take=cmd_record&&!recording;
 wire [57:0] current_configuration={in_ratio,in_mod_depth,in_synth_config};
 wire [57:0] previous_configuration={previous_ratio,previous_mod,previous_config};
 // Keep the independent mismatch groups before their final OR; a single
 // wide equality otherwise maps the configuration event to a long carry chain.
 (* syn_keep=1 *) wire [7:0] configuration_changed;
 genvar configuration_piece;
 generate for(configuration_piece=0;configuration_piece<7;configuration_piece=configuration_piece+1)begin:configuration_pieces
  assign configuration_changed[configuration_piece]=|(current_configuration[configuration_piece*8+:8]^previous_configuration[configuration_piece*8+:8]);
 end endgenerate
 assign configuration_changed[7]=|(current_configuration[57:56]^previous_configuration[57:56]);
 // Keep the three local voice mismatch groups off the gain-to-reservation carry chain.
 wire [VOICE_COUNT-1:0] voice_changed;
 genvar changed_voice;
 generate for(changed_voice=0;changed_voice<VOICE_COUNT;changed_voice=changed_voice+1)begin:voice_comparisons
  wire [22:0] current_voice={in_gates[changed_voice],in_notes[changed_voice*7+:7],in_gains[changed_voice*12+:12],in_timbres[changed_voice*3+:3]};
  wire [22:0] previous_voice={previous_gates[changed_voice],previous_notes[changed_voice*7+:7],previous_gains[changed_voice*12+:12],previous_timbres[changed_voice*3+:3]};
  (* syn_keep=1 *) wire [2:0] mismatch;
  assign mismatch[0]=|(current_voice[7:0]^previous_voice[7:0]);
  assign mismatch[1]=|(current_voice[15:8]^previous_voice[15:8]);
  assign mismatch[2]=|(current_voice[22:16]^previous_voice[22:16]);
  assign voice_changed[changed_voice]=|mismatch;
 end endgenerate
 // Compute the new-take and incremental masks independently. The command
 // selects a branch only after comparison/popcount; it must not reset every
 // previous value through a wide, high-fanout mux before the capacity sum.
 always @* begin
  changed=0;initial_changed=({{VOICE_COUNT{1'b0}},1'b1}<<VOICE_COUNT);
  for(integer j=0;j<VOICE_COUNT;j=j+1)begin
   changed[j]=voice_changed[j]||pending_triggers[j]||in_triggers[j];
   initial_changed[j]=in_gates[j]||pending_triggers[j]||in_triggers[j]||
     (|in_notes[j*7+:7])||(|in_gains[j*12+:12])||(|in_timbres[j*3+:3]);
  end
  changed[VOICE_COUNT]=|configuration_changed;
 end

 reg [VOICE_COUNT-1:0] stage_gates=0,stage_triggers=0,replay_gates=0,replay_triggers=0;
 reg [VOICE_COUNT*7-1:0] stage_notes=0,replay_notes=0;
 reg [VOICE_COUNT*12-1:0] stage_gains=0,replay_gains=0;
 reg [VOICE_COUNT*3-1:0] stage_timbres=0,replay_timbres=0;
 reg [18:0] stage_ratio=0,replay_ratio=0;
 reg [6:0] stage_mod=0,replay_mod=0;
 reg [31:0] stage_config=0,replay_config=0;
 localparam RP_IDLE=0,RP_READ=1,RP_WAIT=2,RP_APPLY=3,RP_PUBLISH=4,RP_READY=5,RP_DECODE=6;
 reg [2:0] replay_state=RP_IDLE;
 reg [12:0] replay_index=0;
 (* syn_preserve=1 *) reg replay_due=0,replay_config_word=0;
 (* syn_preserve=1 *) reg [VOICE_COUNT-1:0] replay_voice=0;
 assign replay_frame_ready=replaying&&replay_state==RP_READY;
 wire silent=mute_frame||rst;
 assign out_gates=silent?'0:replaying?replay_gates:in_gates;
 assign out_triggers=silent?'0:replaying?(sample_tick?replay_triggers:'0):in_triggers;
 assign out_notes=replaying?replay_notes:in_notes;
 assign out_gains=silent?'0:replaying?replay_gains:in_gains;
 assign out_timbres=replaying?replay_timbres:in_timbres;
 assign out_ratio=replaying?replay_ratio:in_ratio;
 assign out_mod_depth=replaying?replay_mod:in_mod_depth;
 assign out_synth_config=replaying?replay_config:in_synth_config;

 // Start playback only after the writer has completed the final accepted
 // frame; this also handles a Record->Replay command with a last note change.
 task begin_replay;
 begin
  replaying<=1;recording<=0;replay_after_capture<=0;
  replay_time<=0;replay_index<=0;replay_state<=RP_READ;
 end endtask

 always @(posedge clk)begin
  if(rst)begin
   pending_record<=0;pending_replay<=0;pending_clear<=0;pending_panic<=0;pending_triggers<=0;
   recording<=0;replaying<=0;full<=0;time_limit<=0;count<=0;duration_samples<=0;take_id<=0;
   have_take<=0;mute_frame<=0;record_time<=0;replay_time<=0;
   previous_gates<=0;previous_notes<=0;previous_gains<=0;previous_timbres<=0;
   previous_ratio<=0;previous_mod<=0;previous_config<=0;
   captured_gates<=0;captured_triggers<=0;captured_notes<=0;captured_gains<=0;captured_timbres<=0;
   captured_ratio<=0;captured_mod<=0;captured_config<=0;captured_time<=0;
   capture_mask<=0;capture_index<=0;write_index<=0;capture_busy<=0;replay_after_capture<=0;
   stage_gates<=0;stage_triggers<=0;stage_notes<=0;stage_gains<=0;stage_timbres<=0;
   stage_ratio<=0;stage_mod<=0;stage_config<=0;
   replay_gates<=0;replay_triggers<=0;replay_notes<=0;replay_gains<=0;replay_timbres<=0;
   replay_ratio<=0;replay_mod<=0;replay_config<=0;replay_state<=RP_IDLE;replay_index<=0;read_address<=0;
   replay_due<=0;replay_config_word<=0;replay_voice<=0;
  end else begin
   pending_record<=pending_record|record_toggle;pending_replay<=pending_replay|replay_toggle;
   pending_clear<=pending_clear|clear;pending_panic<=pending_panic|panic;
   pending_triggers<=pending_triggers|in_triggers;

   // Idle banks are invisible while outputs select live controls. Preclear
   // them before playback, removing record/popcount/capacity from wide CEs.
   // Keep this before RP_APPLY/PUBLISH and sample-boundary overrides.
   if(!replaying)begin
    stage_gates<=0;stage_triggers<=0;stage_notes<=0;stage_gains<=0;stage_timbres<=0;
    stage_ratio<=0;stage_mod<=0;stage_config<=0;
    replay_gates<=0;replay_triggers<=0;replay_notes<=0;replay_gains<=0;replay_timbres<=0;
    replay_ratio<=0;replay_mod<=0;replay_config<=0;
   end

   if(capture_busy)begin
    if(capture_mask[capture_index])begin
     if(capture_index==VOICE_COUNT)
      event_ram[write_index[11:0]]<={captured_time,1'b1,5'd0,captured_config,captured_ratio,captured_mod};
     else
      event_ram[write_index[11:0]]<={captured_time,1'b0,capture_index,captured_gates[capture_index],captured_triggers[capture_index],captured_notes[capture_index*7+:7],captured_gains[capture_index*12+:12],captured_timbres[capture_index*3+:3],33'd0};
     write_index<=write_index+1'b1;
    end
    if(capture_index==VOICE_COUNT)begin
     capture_busy<=0;
     if(replay_after_capture)begin_replay;
    end else capture_index<=capture_index+1'b1;
   end

   case(replay_state)
    RP_READ:begin
     if(replay_index>=count)replay_state<=RP_PUBLISH;
     else begin read_address<=replay_index[11:0];replay_state<=RP_WAIT;end
    end
    RP_WAIT:replay_state<=RP_DECODE;
    RP_DECODE:begin
     replay_due<=read_word[95:64]<=replay_time;
     replay_config_word<=read_word[63];
     for(integer voice=0;voice<VOICE_COUNT;voice=voice+1)
      replay_voice[voice]<=!read_word[63]&&(read_word[62:57]==voice);
     replay_state<=RP_APPLY;
    end
    RP_APPLY:begin
     if(!replay_due)replay_state<=RP_PUBLISH;
     else begin
      if(replay_config_word)begin
       stage_config<=read_word[57:26];stage_ratio<=read_word[25:7];stage_mod<=read_word[6:0];
      end else begin
       for(integer voice=0;voice<VOICE_COUNT;voice=voice+1)if(replay_voice[voice])begin
        stage_gates[voice]<=read_word[56];stage_triggers[voice]<=read_word[55];
        stage_notes[voice*7+:7]<=read_word[54:48];
        stage_gains[voice*12+:12]<=read_word[47:36];
        stage_timbres[voice*3+:3]<=read_word[35:33];
       end
      end
      replay_index<=replay_index+1'b1;replay_state<=RP_READ;
     end
    end
    RP_PUBLISH:begin
     replay_gates<=stage_gates;
     // A take can begin with keys already held. Its first rendered frame must
     // initialize those envelopes, even if live gates stayed high into Replay.
     replay_triggers<=stage_triggers|((replay_time==0)?stage_gates:'0);
     replay_notes<=stage_notes;
     replay_gains<=stage_gains;replay_timbres<=stage_timbres;replay_ratio<=stage_ratio;
     replay_mod<=stage_mod;replay_config<=stage_config;replay_state<=RP_READY;
    end
    default:begin end
   endcase

   if(sample_tick)begin
    pending_record<=0;pending_replay<=0;pending_clear<=0;pending_panic<=0;pending_triggers<=0;
    mute_frame<=0;
    if(cmd_clear||cmd_panic)begin
     recording<=0;replaying<=0;capture_busy<=0;replay_after_capture<=0;replay_state<=RP_IDLE;
     replay_gates<=0;replay_triggers<=0;mute_frame<=1;
     if(cmd_clear)begin take_id<=take_id+1'b1;count<=0;have_take<=0;duration_samples<=0;full<=0;time_limit<=0;end
    end else if(start_take)begin
     // New take is independent of the selected performance source/mode.
     take_id<=take_id+1'b1;
     replaying<=0;replay_state<=RP_IDLE;replay_after_capture<=0;
     full<=0;time_limit<=0;record_time<=0;duration_samples<=0;have_take<=1;
     if(initial_count>EVENT_CAPACITY)begin recording<=0;full<=1;count<=0;end
     else begin
      recording<=1;count<=initial_count;write_index<=0;capture_index<=0;capture_busy<=1;
      capture_mask<=initial_changed;captured_time<=0;
      captured_gates<=in_gates;captured_triggers<=pending_triggers|in_triggers;
      captured_notes<=in_notes;captured_gains<=in_gains;captured_timbres<=in_timbres;
      captured_ratio<=in_ratio;captured_mod<=in_mod_depth;captured_config<=in_synth_config;
      previous_gates<=in_gates;previous_notes<=in_notes;previous_gains<=in_gains;previous_timbres<=in_timbres;
      previous_ratio<=in_ratio;previous_mod<=in_mod_depth;previous_config<=in_synth_config;
     end
    end else if(recording)begin
     if(record_time+1>=MAX_SAMPLES||record_capacity_exceeded||capture_busy)begin
      recording<=0;
      if(record_time+1>=MAX_SAMPLES)time_limit<=1;else full<=1;
      if(cmd_replay&&!cmd_record&&have_take)begin_replay;
     end else begin
      record_time<=record_time+1;duration_samples<=record_time+1;
      count<=count+changed_count;write_index<=count;capture_index<=0;capture_busy<=1;
      capture_mask<=changed;captured_time<=record_time+1;
      captured_gates<=in_gates;captured_triggers<=pending_triggers|in_triggers;
      captured_notes<=in_notes;captured_gains<=in_gains;captured_timbres<=in_timbres;
      captured_ratio<=in_ratio;captured_mod<=in_mod_depth;captured_config<=in_synth_config;
      previous_gates<=in_gates;previous_notes<=in_notes;previous_gains<=in_gains;previous_timbres<=in_timbres;
      previous_ratio<=in_ratio;previous_mod<=in_mod_depth;previous_config<=in_synth_config;
      if(cmd_record||cmd_replay)begin recording<=0;replay_after_capture<=!cmd_record&&cmd_replay;end
     end
    end else if(replaying)begin
     if(cmd_replay)begin
      replaying<=0;replay_state<=RP_IDLE;replay_gates<=0;replay_triggers<=0;mute_frame<=1;
     end else if(replay_state==RP_READY)begin
      if(replay_time>=duration_samples)begin
       replaying<=0;replay_state<=RP_IDLE;replay_gates<=0;replay_triggers<=0;mute_frame<=1;
      end else begin
       replay_time<=replay_time+1;stage_triggers<=0;replay_state<=RP_READ;
      end
     end
    end else if(cmd_replay&&have_take&&!capture_busy)begin_replay;
   end
  end
 end
endmodule
