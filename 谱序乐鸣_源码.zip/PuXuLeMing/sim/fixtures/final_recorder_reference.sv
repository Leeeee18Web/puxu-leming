// Frozen 20261026_224812 pre-timing-refactor recorder; behavioral comparison only.
`timescale 1ns/1ps
// Volatile, post-expansion control-event recorder. One synchronous 96-bit
// timestamp/payload RAM; no PCM or backpressure in the live datapath.
module final_recorder_reference #(
 parameter integer EVENT_CAPACITY=4096,
 parameter integer MAX_SAMPLES=2929688
)(
 input wire clk,rst,sample_tick,record_toggle,replay_toggle,clear,panic,
 input wire [3:0] in_gates,in_triggers,
 input wire [27:0] in_notes,
 input wire [47:0] in_gains,
 input wire [11:0] in_timbres,
 input wire [18:0] in_ratio,
 input wire [6:0] in_mod_depth,
 input wire [31:0] in_synth_config,
 output wire [3:0] out_gates,out_triggers,
 output wire [27:0] out_notes,
 output wire [47:0] out_gains,
 output wire [11:0] out_timbres,
 output wire [18:0] out_ratio,
 output wire [6:0] out_mod_depth,
 output wire [31:0] out_synth_config,
 output reg recording=0,replaying=0,full=0,time_limit=0,
 output wire replay_frame_ready,
 output reg [12:0] count=0,
 output wire [31:0] time_samples,
 input wire [11:0] export_address,
 output wire [95:0] export_word,output wire export_ready,output reg [31:0] take_id=0,
 output reg [31:0] duration_samples=0
);
 reg [95:0] event_ram[0:EVENT_CAPACITY-1];
 // RAM read deliberately synchronous for embedded block RAM inference.
 reg [11:0] read_address=0;
 reg [95:0] read_word=0;
 

 reg pending_record=0,pending_replay=0,pending_clear=0,pending_panic=0;
 reg [3:0] pending_triggers=0;
 wire cmd_record=pending_record|record_toggle;
 wire cmd_replay=pending_replay|replay_toggle;
 wire cmd_clear=pending_clear|clear;
 wire cmd_panic=pending_panic|panic;
 reg have_take=0,mute_frame=0;
 reg [31:0] record_time=0,replay_time=0;
 assign time_samples=recording?record_time:replaying?replay_time:duration_samples;

 reg [3:0] previous_gates=0;
 reg [27:0] previous_notes=0;
 reg [47:0] previous_gains=0;
 reg [11:0] previous_timbres=0;
 reg [18:0] previous_ratio=0;
 reg [6:0] previous_mod=0;
 reg [31:0] previous_config=0;
 reg [3:0] captured_gates=0,captured_triggers=0;
 reg [27:0] captured_notes=0;
 reg [47:0] captured_gains=0;
 reg [11:0] captured_timbres=0;
 reg [18:0] captured_ratio=0;
 reg [6:0] captured_mod=0;
 reg [31:0] captured_config=0,captured_time=0;
 reg [4:0] capture_mask=0;
 reg [5:0] capture_index=0;
 reg [12:0] write_index=0;
 reg capture_busy=0,replay_after_capture=0;
 assign export_ready=have_take&&!recording&&!replaying&&!capture_busy;
 assign export_word=read_word;
 always @(posedge clk) read_word<=event_ram[export_ready?export_address:read_address];

 // A frame is admitted in its entirety. This popcount/reservation prevents
 // capacity exhaustion from leaving half of a four-note chord in a take.
 reg [4:0] changed;
 reg [6:0] changed_count;
 integer k;
 wire start_take=cmd_record&&!recording;
 always @* begin
  changed=0;changed_count=0;
  for(integer j=0;j<4;j=j+1)begin
   changed[j]=(in_gates[j]!=(start_take?1'b0:previous_gates[j]))||
     (|(pending_triggers[j]|in_triggers[j]))||
     in_notes[j*7+:7]!=(start_take?7'd0:previous_notes[j*7+:7])||
     in_gains[j*12+:12]!=(start_take?12'd0:previous_gains[j*12+:12])||
     in_timbres[j*3+:3]!=(start_take?3'd0:previous_timbres[j*3+:3]);
   changed_count=changed_count+changed[j];
  end
  changed[4]=start_take||in_ratio!=previous_ratio||in_mod_depth!=previous_mod||in_synth_config!=previous_config;
  changed_count=changed_count+changed[4];
 end

 reg [3:0] stage_gates=0,stage_triggers=0,replay_gates=0,replay_triggers=0;
 reg [27:0] stage_notes=0,replay_notes=0;
 reg [47:0] stage_gains=0,replay_gains=0;
 reg [11:0] stage_timbres=0,replay_timbres=0;
 reg [18:0] stage_ratio=0,replay_ratio=0;
 reg [6:0] stage_mod=0,replay_mod=0;
 reg [31:0] stage_config=0,replay_config=0;
 localparam RP_IDLE=0,RP_READ=1,RP_WAIT=2,RP_APPLY=3,RP_PUBLISH=4,RP_READY=5;
 reg [2:0] replay_state=RP_IDLE;
 reg [12:0] replay_index=0;
 assign replay_frame_ready=replaying&&replay_state==RP_READY;
 wire silent=mute_frame||rst;
 assign out_gates=silent?4'd0:replaying?replay_gates:in_gates;
 assign out_triggers=silent?4'd0:replaying?(sample_tick?replay_triggers:4'd0):in_triggers;
 assign out_notes=replaying?replay_notes:in_notes;
 assign out_gains=silent?48'd0:replaying?replay_gains:in_gains;
 assign out_timbres=replaying?replay_timbres:in_timbres;
 assign out_ratio=replaying?replay_ratio:in_ratio;
 assign out_mod_depth=replaying?replay_mod:in_mod_depth;
 assign out_synth_config=replaying?replay_config:in_synth_config;

 // Start playback only after the writer has completed the final accepted
 // frame; this also handles a Record->Replay command with a last note change.
 task begin_replay;
 begin
  replaying<=1;recording<=0;replay_after_capture<=0;
  replay_time<=0;replay_index<=0;replay_state<=RP_READ;
 end endtask

 always @(posedge clk)begin
  if(rst)begin
   pending_record<=0;pending_replay<=0;pending_clear<=0;pending_panic<=0;pending_triggers<=0;
   recording<=0;replaying<=0;full<=0;time_limit<=0;count<=0;duration_samples<=0;take_id<=0;
   have_take<=0;mute_frame<=0;record_time<=0;replay_time<=0;
   previous_gates<=0;previous_notes<=0;previous_gains<=0;previous_timbres<=0;
   previous_ratio<=0;previous_mod<=0;previous_config<=0;
   captured_gates<=0;captured_triggers<=0;captured_notes<=0;captured_gains<=0;captured_timbres<=0;
   captured_ratio<=0;captured_mod<=0;captured_config<=0;captured_time<=0;
   capture_mask<=0;capture_index<=0;write_index<=0;capture_busy<=0;replay_after_capture<=0;
   stage_gates<=0;stage_triggers<=0;stage_notes<=0;stage_gains<=0;stage_timbres<=0;
   stage_ratio<=0;stage_mod<=0;stage_config<=0;
   replay_gates<=0;replay_triggers<=0;replay_notes<=0;replay_gains<=0;replay_timbres<=0;
   replay_ratio<=0;replay_mod<=0;replay_config<=0;replay_state<=RP_IDLE;replay_index<=0;read_address<=0;
  end else begin
   pending_record<=pending_record|record_toggle;pending_replay<=pending_replay|replay_toggle;
   pending_clear<=pending_clear|clear;pending_panic<=pending_panic|panic;
   pending_triggers<=pending_triggers|in_triggers;

   // Idle banks are invisible while outputs select live controls. Preclear
   // them before playback, removing record/popcount/capacity from wide CEs.
   // Keep this before RP_APPLY/PUBLISH and sample-boundary overrides.
   if(!replaying)begin
    stage_gates<=0;stage_triggers<=0;stage_notes<=0;stage_gains<=0;stage_timbres<=0;
    stage_ratio<=0;stage_mod<=0;stage_config<=0;
    replay_gates<=0;replay_triggers<=0;replay_notes<=0;replay_gains<=0;replay_timbres<=0;
    replay_ratio<=0;replay_mod<=0;replay_config<=0;
   end

   if(capture_busy)begin
    if(capture_mask[capture_index])begin
     if(capture_index==4)
      event_ram[write_index[11:0]]<={captured_time,1'b1,5'd0,captured_config,captured_ratio,captured_mod};
     else
      event_ram[write_index[11:0]]<={captured_time,1'b0,capture_index,captured_gates[capture_index],captured_triggers[capture_index],captured_notes[capture_index*7+:7],captured_gains[capture_index*12+:12],captured_timbres[capture_index*3+:3],33'd0};
     write_index<=write_index+1'b1;
    end
    if(capture_index==4)begin
     capture_busy<=0;
     if(replay_after_capture)begin_replay;
    end else capture_index<=capture_index+1'b1;
   end

   case(replay_state)
    RP_READ:begin
     if(replay_index>=count)replay_state<=RP_PUBLISH;
     else begin read_address<=replay_index[11:0];replay_state<=RP_WAIT;end
    end
    RP_WAIT:replay_state<=RP_APPLY;
    RP_APPLY:begin
     if(read_word[95:64]>replay_time)replay_state<=RP_PUBLISH;
     else begin
      if(read_word[63])begin
       stage_config<=read_word[57:26];stage_ratio<=read_word[25:7];stage_mod<=read_word[6:0];
      end else begin
       stage_gates[read_word[62:57]]<=read_word[56];stage_triggers[read_word[62:57]]<=read_word[55];
       stage_notes[read_word[62:57]*7+:7]<=read_word[54:48];
       stage_gains[read_word[62:57]*12+:12]<=read_word[47:36];
       stage_timbres[read_word[62:57]*3+:3]<=read_word[35:33];
      end
      replay_index<=replay_index+1'b1;replay_state<=RP_READ;
     end
    end
    RP_PUBLISH:begin
     replay_gates<=stage_gates;
     // A take can begin with keys already held. Its first rendered frame must
     // initialize those envelopes, even if live gates stayed high into Replay.
     replay_triggers<=stage_triggers|((replay_time==0)?stage_gates:4'd0);
     replay_notes<=stage_notes;
     replay_gains<=stage_gains;replay_timbres<=stage_timbres;replay_ratio<=stage_ratio;
     replay_mod<=stage_mod;replay_config<=stage_config;replay_state<=RP_READY;
    end
    default:begin end
   endcase

   if(sample_tick)begin
    pending_record<=0;pending_replay<=0;pending_clear<=0;pending_panic<=0;pending_triggers<=0;
    mute_frame<=0;
    if(cmd_clear||cmd_panic)begin
     recording<=0;replaying<=0;capture_busy<=0;replay_after_capture<=0;replay_state<=RP_IDLE;
     replay_gates<=0;replay_triggers<=0;mute_frame<=1;
     if(cmd_clear)begin take_id<=take_id+1'b1;count<=0;have_take<=0;duration_samples<=0;full<=0;time_limit<=0;end
    end else if(start_take)begin
     // New take is independent of the selected performance source/mode.
     take_id<=take_id+1'b1;
     replaying<=0;replay_state<=RP_IDLE;replay_after_capture<=0;
     full<=0;time_limit<=0;record_time<=0;duration_samples<=0;have_take<=1;
     if(changed_count>EVENT_CAPACITY)begin recording<=0;full<=1;count<=0;end
     else begin
      recording<=1;count<=changed_count;write_index<=0;capture_index<=0;capture_busy<=1;
      capture_mask<=changed;captured_time<=0;
      captured_gates<=in_gates;captured_triggers<=pending_triggers|in_triggers;
      captured_notes<=in_notes;captured_gains<=in_gains;captured_timbres<=in_timbres;
      captured_ratio<=in_ratio;captured_mod<=in_mod_depth;captured_config<=in_synth_config;
      previous_gates<=in_gates;previous_notes<=in_notes;previous_gains<=in_gains;previous_timbres<=in_timbres;
      previous_ratio<=in_ratio;previous_mod<=in_mod_depth;previous_config<=in_synth_config;
     end
    end else if(recording)begin
     if(record_time+1>=MAX_SAMPLES||count+changed_count>EVENT_CAPACITY||capture_busy)begin
      recording<=0;
      if(record_time+1>=MAX_SAMPLES)time_limit<=1;else full<=1;
      if(cmd_replay&&!cmd_record&&have_take)begin_replay;
     end else begin
      record_time<=record_time+1;duration_samples<=record_time+1;
      count<=count+changed_count;write_index<=count;capture_index<=0;capture_busy<=1;
      capture_mask<=changed;captured_time<=record_time+1;
      captured_gates<=in_gates;captured_triggers<=pending_triggers|in_triggers;
      captured_notes<=in_notes;captured_gains<=in_gains;captured_timbres<=in_timbres;
      captured_ratio<=in_ratio;captured_mod<=in_mod_depth;captured_config<=in_synth_config;
      previous_gates<=in_gates;previous_notes<=in_notes;previous_gains<=in_gains;previous_timbres<=in_timbres;
      previous_ratio<=in_ratio;previous_mod<=in_mod_depth;previous_config<=in_synth_config;
      if(cmd_record||cmd_replay)begin recording<=0;replay_after_capture<=!cmd_record&&cmd_replay;end
     end
    end else if(replaying)begin
     if(cmd_replay)begin
      replaying<=0;replay_state<=RP_IDLE;replay_gates<=0;replay_triggers<=0;mute_frame<=1;
     end else if(replay_state==RP_READY)begin
      if(replay_time>=duration_samples)begin
       replaying<=0;replay_state<=RP_IDLE;replay_gates<=0;replay_triggers<=0;mute_frame<=1;
      end else begin
       replay_time<=replay_time+1;stage_triggers<=0;replay_state<=RP_READ;
      end
     end
    end else if(cmd_replay&&have_take&&!capture_busy)begin_replay;
   end
  end
 end
endmodule
