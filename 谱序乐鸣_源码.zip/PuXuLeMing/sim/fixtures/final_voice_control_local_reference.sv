`timescale 1ns/1ps
// Source/channel/original-key ownership; parameter4 preserves the legacy API behavior.
module final_voice_control_local_reference #(parameter RELATIVE_KNOB=0,ENABLE_PEDAL=0,VOICE_COUNT=4)(
 input wire [2:0] timbre_select,input wire [VOICE_COUNT-1:0] voice_active,
 output reg [VOICE_COUNT*3-1:0] timbres=0,
 input wire clk,rst,sample_tick,event_valid,input wire [31:0] event_data,
 output wire event_ready,input wire panic,centre,input wire pedal_down,
 output reg [VOICE_COUNT-1:0] gates=0,output reg [VOICE_COUNT*7-1:0] notes=0,
 output reg [VOICE_COUNT*12-1:0] gains=0,output reg [VOICE_COUNT-1:0] triggers=0,
 output reg [18:0] ratio=19'd262144,output reg [6:0] knob=64,
 output reg [6:0] last_note=0,last_velocity=0,output reg [6:0] mod_depth=0,
 input wire [1:0] knob_mode,
 output reg [6:0] raw_knob=0,output reg raw_known=0,output wire pickup_wait,
 input wire [1:0] event_source,input wire [174:0] map_notes,
 input wire [6:0] map_input_base,input wire map_enabled,map_apply,
 output reg key_seen_valid=0,output reg [4:0] key_seen_index=0
);
 wire physical_pedal=ENABLE_PEDAL?pedal_down:1'b0;
 assign event_ready=1'b1;
 reg [1:0] owners[0:VOICE_COUNT-1];reg [VOICE_COUNT-1:0] held=0;
 reg [6:0] original_keys[0:VOICE_COUNT-1];
 reg [3:0] channels[0:VOICE_COUNT-1];reg [VOICE_COUNT-1:0] newer[0:VOICE_COUNT-1];reg [63:0] sustain=0;
 reg pedal_previous=0;
 reg [18:0] target=262144;
 wire [1:0] src=(VOICE_COUNT>4)?event_source:{1'b0,event_data[24]};wire [7:0] status=event_data[7:0];
 wire [6:0] d1=event_data[14:8],d2=event_data[22:16];
 wire [5:0] pedal_index={src,status[3:0]};
 wire indexed_live=(VOICE_COUNT>4)&&src==3&&status[3:0]==14;
 wire [6:0] original_key=indexed_live?event_data[31:25]:d1;
 wire [7:0] map_delta={1'b0,d1}-{1'b0,map_input_base};
 wire input_mappable=(src==0||src==1)&&d1>=map_input_base&&map_delta<25;
 wire [6:0] map_index=indexed_live?original_key:map_delta[6:0];
 wire mapped=(VOICE_COUNT>4)&&map_enabled&&(indexed_live?original_key<25:input_mappable);
 wire [6:0] resolved_note=mapped?map_notes[map_index*7+:7]:d1;
 wire legal_data=!event_data[15]&&!event_data[23];
 // Parameter zero preserves the existing absolute PC/CC74 mapping.
 // P8 opts in; mode3 safely aliases the bounded relative mode.
 wire [1:0] active_mode=(knob_mode==0)?2'd0:(knob_mode==2)?2'd2:2'd1;
 reg [1:0] previous_mode=1;
 reg anchor_valid=0,pickup_owned=0;
 wire mode_changed=active_mode!=previous_mode;
 assign pickup_wait=RELATIVE_KNOB&&(active_mode==0)&&!pickup_owned;
 wire [6:0] physical_raw=(status[7:4]==12)?d1:d2;
 wire signed [8:0] raw_delta=$signed({2'b00,physical_raw})-$signed({2'b00,raw_knob});
 // Sign extending the low seven bits is modulo128 in [-64,63].
 wire signed [8:0] knob_delta=(active_mode==2)?{{2{raw_delta[6]}},raw_delta[6:0]}:raw_delta;
 wire signed [8:0] knob_sum=$signed({2'b00,knob})+knob_delta;
 wire [6:0] relative_value=(knob_sum<0)?7'd0:(knob_sum>127)?7'd127:knob_sum[6:0];
 wire pickup_crossed=(physical_raw==knob)||(anchor_valid&&!mode_changed&&
                      ((raw_knob<knob&&physical_raw>knob)||(raw_knob>knob&&physical_raw<knob)));
 `include "play_bend_lut.vh"
 wire [VOICE_COUNT-1:0] match_slots,free_slots,pedal_slots,oldest_pedals,candidate_slots,selected_slots,tail_slots,oldest_tails;
 wire [VOICE_COUNT-1:0] occupied=gates|voice_active;
 genvar v;
 generate for(v=0;v<VOICE_COUNT;v=v+1)begin:slot_choice
  assign match_slots[v]=occupied[v]&&owners[v]==src&&channels[v]==status[3:0]&&original_keys[v]==original_key;
  assign free_slots[v]=!occupied[v]||(ENABLE_PEDAL&&gates[v]&&!held[v]&&!voice_active[v]);
  assign tail_slots[v]=!gates[v]&&voice_active[v];
  assign oldest_tails[v]=tail_slots[v]&&!(|(newer[v]&tail_slots));
  // Finger-held notes are protected; pedal-only notes can yield to new onsets.
  assign pedal_slots[v]=gates[v]&&!held[v];
  assign oldest_pedals[v]=pedal_slots[v]&&!(|(newer[v]&pedal_slots));
  if(v==0)assign selected_slots[v]=candidate_slots[v];
  else assign selected_slots[v]=candidate_slots[v]&&!(|candidate_slots[v-1:0]);
 end endgenerate
 assign candidate_slots=(|match_slots)?match_slots:(|free_slots)?free_slots:(|oldest_tails)?oldest_tails:ENABLE_PEDAL?oldest_pedals:{VOICE_COUNT{1'b0}};
 wire cc64_on=event_valid&&legal_data&&status[7:4]==11&&d1==64&&d2>=64;
 integer i; reg [6:0] bend_value;
 always @(posedge clk)begin
  triggers<=0;key_seen_valid<=0;
  if(rst)begin
   gates<=0;notes<=0;gains<=0;timbres<=0;held<=0;sustain<=0;pedal_previous<=0;
   ratio<=262144;target<=262144;knob<=64;last_note<=0;last_velocity<=0;mod_depth<=0;
   key_seen_index<=0;raw_knob<=0;raw_known<=0;anchor_valid<=0;pickup_owned<=0;previous_mode<=1;
   for(i=0;i<VOICE_COUNT;i=i+1)begin channels[i]<=0;newer[i]<=0;owners[i]<=0;original_keys[i]<=0;end
  end else begin
   pedal_previous<=physical_pedal;
   if(pedal_previous&&!physical_pedal)for(i=0;i<VOICE_COUNT;i=i+1)
    if(!held[i]&&!sustain[{owners[i],channels[i]}]&&
       !(cc64_on&&owners[i]==src&&channels[i]==status[3:0]))gates[i]<=0;
   if(RELATIVE_KNOB&&mode_changed)begin
    previous_mode<=active_mode;anchor_valid<=0;pickup_owned<=0;
   end
   if(sample_tick)begin
    if(target>ratio)ratio<=ratio+((target-ratio<64)?target-ratio:(target-ratio)>>6);
    else if(target<ratio)ratio<=ratio-((ratio-target<64)?ratio-target:(ratio-target)>>6);
   end
   if(panic||((VOICE_COUNT>4)&&map_apply))begin gates<=0;held<=0;sustain<=0;gains<=0;mod_depth<=0;end
   else if(event_valid)begin
    if(status==8'hff)begin
     //25-mode disconnect clears only the tagged source; default4 retains USB-only legacy cleanup.
     for(i=0;i<VOICE_COUNT;i=i+1)if((VOICE_COUNT>4)?owners[i]==src:owners[i]==0)begin gates[i]<=0;held[i]<=0;gains[i*12+:12]<=0;end
     if(VOICE_COUNT>4)begin
      for(i=0;i<16;i=i+1)sustain[{src,4'b0}+i]<=0;
     end else sustain[15:0]<=0;mod_depth<=0;raw_known<=0;anchor_valid<=0;pickup_owned<=0;
    end else if(legal_data)begin
     if(status[7:4]==12||(status[7:4]==11&&d1==74))begin
      raw_knob<=physical_raw;raw_known<=1;anchor_valid<=1;
      if(!RELATIVE_KNOB)begin knob<=physical_raw;target<=bend_ratio(physical_raw);end
      else if(active_mode==0)begin
       if((pickup_owned&&!mode_changed)||pickup_crossed)begin
        knob<=physical_raw;target<=bend_ratio(physical_raw);pickup_owned<=1;
       end
      end else if(anchor_valid&&!mode_changed)begin
       knob<=relative_value;target<=bend_ratio(relative_value);
      end
     end else if(status[7:4]==9&&d2!=0)begin
      if(VOICE_COUNT>4&&input_mappable)begin key_seen_valid<=1;key_seen_index<=map_delta[4:0];end
      // Static onehot writes avoid an age-comparator chain and dynamic slot
      // decode at the gain/ownership register enables. New slot is newest;
      // relative order of every other pair remains untouched across releases.
      for(i=0;i<VOICE_COUNT;i=i+1)begin
       if(selected_slots[i])begin
        newer[i]<={VOICE_COUNT{1'b1}}^({{(VOICE_COUNT-1){1'b0}},1'b1}<<i);
        gates[i]<=1;held[i]<=1;owners[i]<=src;channels[i]<=status[3:0];
        timbres[i*3+:3]<=timbre_select<=4?timbre_select:3'd0;
        original_keys[i]<=original_key;notes[i*7+:7]<=resolved_note;gains[i*12+:12]<={d2,5'd0};triggers[i]<=1;
       end else newer[i]<=newer[i]&~selected_slots;
      end
      if(|selected_slots)begin last_note<=resolved_note;last_velocity<=d2;end
     end else if(status[7:4]==8||(status[7:4]==9&&d2==0))begin
      for(i=0;i<VOICE_COUNT;i=i+1)if(gates[i]&&owners[i]==src&&channels[i]==status[3:0]&&original_keys[i]==original_key)begin
       held[i]<=0;if(!physical_pedal&&!sustain[pedal_index])gates[i]<=0;
      end
     end else if(status[7:4]==11)begin
      if(d1==64)begin
       sustain[pedal_index]<=d2>=64;
       if(d2<64&&!physical_pedal)for(i=0;i<VOICE_COUNT;i=i+1)if(owners[i]==src&&channels[i]==status[3:0]&&!held[i])gates[i]<=0;
      end else if(d1==120||d1==123)begin
       for(i=0;i<VOICE_COUNT;i=i+1)if(owners[i]==src&&channels[i]==status[3:0])begin
        held[i]<=0;if(d1==120||(!physical_pedal&&!sustain[pedal_index]))gates[i]<=0;
        if(d1==120)gains[i*12+:12]<=0;
       end
       if(d1==120)sustain[pedal_index]<=0;
      end else if(d1==1)mod_depth<=d2;
     end else if(status[7:4]==14)begin
      // MSB bins preserve exact MIDI 14-bit endpoints and center.
      bend_value=d2;knob<=bend_value;target<=bend_ratio(bend_value);pickup_owned<=0;
     end
    end
   end
   if(centre)begin knob<=64;target<=262144;pickup_owned<=0;end
  end
 end
endmodule
