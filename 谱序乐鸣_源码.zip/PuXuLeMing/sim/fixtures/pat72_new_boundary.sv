`timescale 1ns/1ps
module pat72_new_boundary(input clk,rst,sample_tick,
 input [31:0]touch_event_data,usb_event_data,gesture_event_data,wifi_event_data,
 input touch_event_valid,usb_event_valid,gesture_event_valid,wifi_event_valid,
 input clear_live,panic_touch,gesture_stop,map_apply,stop_score,mute_enter,touch_lost,
 input [3:0]usb_region_up,input pattern_usb_up,status_pattern_raw,wifi_pattern_override,
 input [1:0]wifi_pattern_mode,touch_pattern_mode,mode,input pattern_start,
 input [174:0]map_notes,input [6:0]map_input_base,input map_enabled,pedal_down,
 input [2:0]timbre_select,input [6:0]active,input [1:0]knob_mode);
 localparam VOICE_COUNT=7;
 wire panic_key=0,centre_touch=0,centre_key=0;
 wire esp_ready_patterns=usb_region_up[0]&&status_pattern_raw;
 wire panic_all=panic_touch||panic_key||gesture_stop||!usb_region_up[1];
 wire pattern_owner=esp_ready_patterns&&wifi_pattern_override;
 wire wifi_pattern_active=pattern_owner&&wifi_pattern_mode!=0;
 wire pattern_enabled=(mode==1)||wifi_pattern_active;
 wire pattern_select=pattern_owner?(wifi_pattern_mode!=0):((mode==1)&&touch_pattern_mode!=0);
 wire [1:0]pattern_mode=pattern_owner?wifi_pattern_mode:touch_pattern_mode;
 wire touch_event_ready,usb_event_ready,gesture_event_ready,wifi_event_ready;
 wire selected_valid,selected_ready,controller_ready,selected_raw_valid,controller_ready_raw;
 wire[31:0]selected_data;wire[1:0]selected_source;
 wire [6:0]live_gates,live_triggers,knob,last_note,last_velocity,mod_depth,raw_knob;
 wire [20:0]live_timbres;wire [48:0]live_notes;wire[83:0]live_gains;
 wire [18:0]ratio;wire raw_known,pickup_wait,map_key_seen_valid;wire[4:0]map_key_seen_index;
 wire live_pedal=pedal_down;
 p8_wifi_arbiter event_arbiter(.clk(clk),.rst(rst), .flush(clear_live||panic_all||map_apply),
  .touch_data(touch_event_data),.touch_valid(touch_event_valid),.touch_ready(touch_event_ready),
  .usb_data(usb_event_data),.usb_valid(usb_event_valid),.usb_ready(usb_event_ready),
  .gesture_data(gesture_event_data),.gesture_valid(gesture_event_valid),.gesture_ready(gesture_event_ready),
  .wifi_data(wifi_event_data),.wifi_valid(wifi_event_valid),.wifi_ready(wifi_event_ready),
  .data(selected_data),.valid(selected_valid),.raw_valid(selected_raw_valid),.ready(selected_ready),.source_tag(selected_source));
 // Semantic sideband is captured on the original arbiter payload edge.
 // It holds through stalls/consume and clears on the same reset/flush.
 // Decode the original four-state priority mux before the register.
 wire[31:0]pattern_capture_data=touch_event_valid?touch_event_data:usb_event_valid?usb_event_data:
                                  gesture_event_valid?gesture_event_data:wifi_event_data;
 (* syn_preserve=1 *)reg[3:0]pattern_event_decode=0;
 always @(posedge clk)begin
  if(rst||clear_live||panic_all||map_apply)pattern_event_decode<=0;
  else if(!selected_raw_valid)begin
   if(touch_event_valid||usb_event_valid||gesture_event_valid||wifi_event_valid)begin
    pattern_event_decode[3]<=pattern_capture_data[7:4]==8||pattern_capture_data[7:4]==9;
    pattern_event_decode[2]<=!pattern_capture_data[15]&&!pattern_capture_data[23]&&
                             pattern_capture_data[7:4]==9&&pattern_capture_data[22:16]!=0;
    pattern_event_decode[1]<=!(pattern_capture_data[24]&&(pattern_capture_data[3:0]==13||pattern_capture_data[3:0]==14))&&
                             pattern_capture_data[7:4]==11&&!pattern_capture_data[15]&&!pattern_capture_data[23]&&
                             (pattern_capture_data[14:8]==120||pattern_capture_data[14:8]==123);
    pattern_event_decode[0]<=pattern_capture_data[7:0]==8'hff;
   end
  end
 end
 wire selected_note_event=selected_data[7:4]==8||selected_data[7:4]==9;
 assign selected_ready=(pattern_select&&selected_note_event?1'b1:controller_ready)&&!clear_live&&!panic_all&&!map_apply;
 final_voice_control #(.VOICE_COUNT(VOICE_COUNT),.RELATIVE_KNOB(1),.ENABLE_PEDAL(1)) voices(.clk(clk),.rst(rst),.sample_tick(sample_tick),.event_valid(selected_valid&&!clear_live&&!panic_all&&!map_apply&&!(pattern_select&&selected_note_event)),.event_data(selected_data),.event_ready(controller_ready),.ready_raw(controller_ready_raw),
  .panic(panic_all||clear_live),.centre(centre_touch||centre_key),.pedal_down(live_pedal),.gates(live_gates),.notes(live_notes),.gains(live_gains),.triggers(live_triggers),
  .ratio(ratio),.knob(knob),.last_note(last_note),.last_velocity(last_velocity),.mod_depth(mod_depth),
  .knob_mode(knob_mode),.raw_knob(raw_knob),.raw_known(raw_known),.pickup_wait(pickup_wait),
  .timbre_select(timbre_select),.voice_active(active),.timbres(live_timbres),
  .event_source(selected_source),.map_notes(map_notes),.map_input_base(map_input_base),.map_enabled(map_enabled),.map_apply(map_apply),.key_seen_valid(map_key_seen_valid),.key_seen_index(map_key_seen_index));
 wire mobile_scoped_event=selected_data[24]&&(selected_data[3:0]==13||selected_data[3:0]==14);
 wire pattern_all_off=selected_valid&&selected_ready&&!mobile_scoped_event&&selected_data[7:4]==11&&
  !selected_data[15]&&!selected_data[23]&&(selected_data[14:8]==120||selected_data[14:8]==123);
 wire[6:0]pattern_selected;wire[3:0]pattern_gates,pattern_triggers;
 wire[48:0]pattern_notes;wire[27:0]pattern_sound_notes;wire[83:0]pattern_selected_gains;wire[47:0]pattern_gains;
 wire pattern_busy,pattern_full;wire[2:0]pattern_count;
 wire pattern_disconnect=selected_valid&&selected_ready&&pattern_select&&selected_data[7:0]==8'hff;
 wire pattern_cancel=map_apply||panic_all||clear_live||stop_score||mute_enter||pattern_all_off||!pattern_enabled||touch_lost||pattern_disconnect;
 // Rebuild the same control waveform from private observers and one local final-stage copy.
 wire pattern_local_owner=pattern_usb_up&&status_pattern_raw&&wifi_pattern_override;
 wire[1:0]pattern_local_mode=pattern_local_owner?wifi_pattern_mode:touch_pattern_mode;
 wire pattern_local_enabled=(mode==1)||(pattern_local_owner&&wifi_pattern_mode!=0);
 wire pattern_local_select=pattern_local_owner?(wifi_pattern_mode!=0):((mode==1)&&touch_pattern_mode!=0);
 wire pattern_local_panic=panic_touch||panic_key||gesture_stop||!pattern_usb_up;
 wire pattern_local_ready=!clear_live&&!pattern_local_panic&&!map_apply&&
  ((pattern_local_select&&pattern_event_decode[3])||(controller_ready_raw&&!rst));
 wire pattern_local_valid=selected_raw_valid&&!rst&&!clear_live&&!pattern_local_panic&&!map_apply;
 wire pattern_local_all_off=pattern_local_valid&&pattern_local_ready&&pattern_event_decode[1];
 wire pattern_local_disconnect=pattern_local_valid&&pattern_local_ready&&pattern_local_select&&pattern_event_decode[0];
 wire pattern_local_base_cancel=map_apply||pattern_local_panic||clear_live||stop_score||mute_enter||pattern_local_all_off||touch_lost;
 wire pattern_local_cancel=pattern_local_base_cancel||!pattern_local_enabled||pattern_local_disconnect;
 final_patterns #(.BRANCH_FULL_RELOAD(1)) patterns(.clk(clk),.rst(rst),.sample_tick(sample_tick),
  .cancel(pattern_local_cancel),
  .pattern_mode(pattern_local_mode),.start(pattern_start),
  .event_valid(pattern_local_valid&&pattern_local_ready&&pattern_local_select),.event_data(selected_data),
  .selected(pattern_selected),.selected_notes(pattern_notes),.selected_gains(pattern_selected_gains),
  .gates(pattern_gates),.triggers(pattern_triggers),.notes(pattern_sound_notes),.gains(pattern_gains),
  .busy(pattern_busy),.count(pattern_count),.full(pattern_full),
  .full_touch_mode(touch_pattern_mode),.full_wifi_mode(wifi_pattern_mode),.full_owner(pattern_local_owner),.full_touch_enabled(mode==1),
  .full_note_request(pattern_local_valid&&pattern_event_decode[2]),
  .full_base_cancel(pattern_local_base_cancel));

endmodule
