// Passive common bridge. All incident waves belong to the same sample.
// M=I-alpha*11^T: eigenvalues 1,1,1-3alpha (piano) or 1,1-2alpha
// (two guitar polarizations). No arbitrary delay is inserted in the junction.
module ref_r2_phys_string_bridge(input wire[2:0]kind,
 input wire signed[17:0]a,b,c,output wire signed[17:0]ra,rb,rc);
 wire signed[19:0]total=$signed({{2{a[17]}},a})+$signed({{2{b[17]}},b})+
    (kind==1?$signed({{2{c[17]}},c}):20'sd0);
 wire signed[19:0]delta=total<0?-((-total)>>>(kind==1?10:9)):(total>>>(kind==1?10:9));
 function automatic signed[17:0]sat(input signed[19:0]v);
 begin if(v>131071)sat=131071;else if(v< -131072)sat=-131072;else sat=v[17:0];end endfunction
 assign ra=sat($signed({{2{a[17]}},a})-delta);
 assign rb=sat($signed({{2{b[17]}},b})-delta);
 assign rc=kind==1?sat($signed({{2{c[17]}},c})-delta):c;
endmodule
