`timescale 1ns/1ps
// One physical propagation loop. 8192 x 18-bit synchronous RAM; a sequential
// 18 x 18 multiplier does all fractional-delay, dispersion and loss products.
module ref_r2_phys_strings_line #(parameter INDEX=0)(
 input wire clk,rst,tick,trigger,gate,input wire[2:0]kind,input wire[11:0]velocity,
 input wire[23:0]step,input wire half_rate,input wire[23:0]period_q10,
 output reg signed[17:0]sample=0,output reg[15:0]envelope=0,
 output wire busy,output reg deadline_error=0,
 input wire signed[17:0]bridge_return,output wire signed[17:0]bridge_incident
);
 localparam integer DISPERSION_Q15 = -19661;
 reg signed[17:0]ram[0:8191];
 // Frequency-correct all-pass coefficient, using the Bhaskara sine rational
 // approximation. a=sin((1-f)*omega/2)/sin((1+f)*omega/2). Unlike (1-f)/(1+f)
 // this follows continuously through the highest MIDI notes near Nyquist.
 reg[45:0]frac_num=0,frac_quot=0;reg[31:0]frac_rem=0,frac_div=1;
 reg[5:0]frac_count=0;wire[31:0]frac_trial={frac_rem[30:0],frac_num[45]};
 reg[34:0]angle_product=0;reg[12:0]angle0=0,angle1=0;
 reg[24:0]z0=0,z1=0;reg[49:0]ratio_product=0;
 wire[23:0]effective_step=half_rate?(step<<1):step;
 reg[5:0]state=0;reg[12:0]wr=0,fill=0,rd=0;
 reg[31:0]fill_phase=0,phase_increment=0;
 // Two-stage initial displacement pipeline, retaining one RAM write/clock.
 // Positive constant division is exact over the 18-bit displacement domain.
 reg[17:0]fill_numerator=0;
 reg signed[17:0]fill_linear=0,fill_linear_q=0;
 reg fill_divide=0,fill_soft=0,fill_divide_q=0,fill_soft_q=0;
 reg[12:0]fill_addr=0,fill_addr_q=0;
 reg fill_valid=0,fill_valid_q=0;
 reg[36:0]fill_product=0;
 wire[17:0]fill_quotient=fill_soft_q?fill_product[36:19]:{2'b0,fill_product[36:21]};
 wire signed[17:0]fill_result=fill_divide_q?18'sd16384-$signed(fill_quotient):fill_linear_q;
 reg signed[17:0]raw=0,lp=0,disp_x=0,disp_y=0,frac_x=0,frac_y=0;
 reg signed[17:0]work=0,allpass=0,loss=32745,frac=0;
 assign bridge_incident=work;
 `include "ref_r2_phys_hammer_contact.vh"
 reg signed[35:0]product=0;reg signed[37:0]wide=0;
 // Explicit operand mux enforces one signed 26x26 physical multiplier per
 // string, rather than relying on synthesis resource-sharing heuristics.
 reg signed[25:0]mul_a,mul_b;
 wire signed[51:0]mul_y=mul_a*mul_b;
 reg signed[17:0]hammer=0,hammer_previous=0,noise_lp=0;
 reg[9:0]age=0;reg[31:0]noise=32'hc184a923;reg[23:0]env_q8=0;
 reg signed[31:0]pickup_dc=0;
 wire[4:0]dc_shift=step>2097152?5'd3:step>1048576?5'd4:step>524288?5'd5:
     step>262144?5'd6:step>131072?5'd7:step>65536?5'd8:step>32768?5'd9:5'd10;
 wire[6:0]hammer_rise=step>1048576?7'd2:step>524288?7'd6:7'd24;
 wire[15:0]phase_compensation;
 ref_r2_phys_strings_tuning tuning(effective_step[22:15],kind==1,velocity<2048,phase_compensation);
 wire[23:0]corrected=period_q10-{8'b0,phase_compensation};
 wire[12:0]tap=corrected[22:10]<2?13'd2:corrected[22:10];
 wire[31:0]new_increment=half_rate?({8'b0,step}<<9):({8'b0,step}<<8);
 always @* begin
  mul_a=0;mul_b=0;
  case(state)
   1,2:begin mul_a=$signed({8'd0,fill_numerator});mul_b=fill_soft?26'sd174763:26'sd299594;end
   0:begin mul_a=$signed({2'b0,effective_step});mul_b=$signed({15'b0,(11'd1024-{1'b0,corrected[9:0]})});end
   10:begin mul_a=work;mul_b=DISPERSION_Q15;end
   11:begin mul_a=disp_y;mul_b=DISPERSION_Q15;end
   13:begin mul_a=allpass;mul_b=frac;end
   14:begin mul_a=frac_y;mul_b=frac;end
   16:begin mul_a=bridge_return;mul_b=loss;end
   22:begin mul_a=$signed({2'b0,effective_step});mul_b=$signed({15'b0,(11'd1024+{1'b0,corrected[9:0]})});end
   23:begin mul_a=$signed({13'b0,angle0});mul_b=$signed({13'b0,(13'd4096-angle0)});end
   24:begin mul_a=$signed({13'b0,angle1});mul_b=$signed({13'b0,(13'd4096-angle1)});end
   25:begin mul_a=$signed({1'b0,z0});mul_b=$signed({1'b0,(25'd20971520-z1)});end
   26:begin mul_a=$signed({1'b0,z1});mul_b=$signed({1'b0,(25'd20971520-z0)});end
   default:begin mul_a=0;mul_b=0;end
  endcase
 end
 assign busy=state!=0;
 function automatic signed[17:0]clamp(input signed[37:0]x);
 begin if(x>131071)clamp=131071;else if(x< -131072)clamp=-131072;else clamp=x[17:0];end endfunction
 // Truncation toward zero avoids circulating sign-biased DC limit cycles.
 function automatic signed[17:0]q15(input signed[35:0]x);
 begin if(x<0)q15=-((-x)>>>15);else q15=x>>>15;end endfunction
 // Initial impact traveling waves: hammer at L/8, bridge at L.
 // Direct path is 7/16 of one round trip; the nut-reflected, inverted
 // path is 9/16. Periodic spatial initialization also supplies valid wave
 // history when the player immediately bends pitch. This is a finite-contact
 // excitation approximation, not a solved hysteretic hammer collision.
 function automatic signed[17:0]piano_impact(input[15:0]p);
 reg[15:0]u;reg signed[17:0]contact_wave;
 begin
  contact_wave=0;u=0;
  if(velocity<2048)begin
   if(p>=28672&&p<36864)begin u=p-28672;contact_wave=hammer_contact(u[12:7]);end
   else if(p>=36864&&p<45056)begin u=p-36864;contact_wave=-hammer_contact(u[12:7]);end
  end else begin
   if(p>=28672&&p<32768)begin u=p-28672;contact_wave=hammer_contact(u[11:6]);end
   else if(p>=36864&&p<40960)begin u=p-36864;contact_wave=-hammer_contact(u[11:6]);end
  end
  piano_impact=contact_wave;
 end endfunction
 // Initial off-centre triangular displacement; pluck at 1/8 string length.
 function automatic signed[17:0]pluck(input[15:0]p,input soft_attack);
 reg signed[18:0]v;
 begin if(soft_attack)begin
  if(p<16384)v=($signed({1'b0,p})<<<1)-19'sd16384;
  else v=19'sd16384-(($signed({1'b0,p})-19'sd16384)*19'sd2)/19'sd3;
 end else begin
  if(p<8192)v=($signed({1'b0,p})<<<2)-19'sd16384;
  else v=19'sd16384-(($signed({1'b0,p})-19'sd8192)*19'sd4)/19'sd7;
 end
 pluck=v[17:0];end endfunction
 always @(posedge clk)begin
  if(rst)begin
   state<=0;wr<=0;sample<=0;envelope<=0;env_q8<=0;deadline_error<=0;
   fill_valid<=0;fill_valid_q<=0;
   lp<=0;disp_x<=0;disp_y<=0;frac_x<=0;frac_y<=0;age<=0;pickup_dc<=0;
  end else if(trigger)begin
   state<=1;wr<=0;fill<=0;fill_phase<=kind==1?-(new_increment<<13):32'd0;phase_increment<=new_increment;
   fill_valid<=0;fill_valid_q<=0;
   sample<=0;env_q8<=24'hd00000;envelope<=16'hd000;
   lp<=0;disp_x<=0;disp_y<=0;frac_x<=0;frac_y<=0;age<=0;pickup_dc<=0;
   hammer<=0;hammer_previous<=0;noise_lp<=0;noise<=32'hc184a923+INDEX*32'h1937;
  end else case(state)
   0:if(tick)begin
    rd<=wr-tap;
    angle_product<=mul_y[34:0];
    loss<=!gate?18'sd29500:(kind==1?18'sd32726:(INDEX==0?18'sd32710:18'sd32736));state<=22;
   end
   1,2,3:begin
    // Every RAM location rebuilt; a later glide cannot expose stale notes.
    // Soft contact at 1/4 and hard contact at 1/8 string length.
    if(fill_valid_q)ram[fill_addr_q]<=fill_result;
    fill_valid_q<=fill_valid;
    if(fill_valid)begin
     fill_product<=mul_y[36:0];fill_linear_q<=fill_linear;
     fill_divide_q<=fill_divide;fill_soft_q<=fill_soft;fill_addr_q<=fill_addr;
    end
    if(state==1)begin
     fill_addr<=fill;fill_valid<=1;fill_soft<=velocity<2048;
     fill_numerator<=0;fill_linear<=0;fill_divide<=0;
     if(kind==1)fill_linear<=piano_impact(fill_phase[31:16]);
     else if(kind==2&&INDEX<2)begin
      if(velocity<2048)begin
       if(fill_phase[31:16]<16384)fill_linear<=($signed({1'b0,fill_phase[31:16]})<<<1)-18'sd16384;
       else begin fill_divide<=1;fill_numerator<=(fill_phase[31:16]-18'd16384)<<1;end
      end else begin
       if(fill_phase[31:16]<8192)fill_linear<=($signed({1'b0,fill_phase[31:16]})<<<2)-18'sd16384;
       else begin fill_divide<=1;fill_numerator<=(fill_phase[31:16]-18'd8192)<<2;end
      end
     end
     fill_phase<=fill_phase+phase_increment;fill<=fill+1'b1;if(fill==8191)state<=2;
    end else begin fill_valid<=0;state<=state==2?3:0;end
   end
   8:begin raw<=ram[rd];state<=9;end
   9:begin
    work<=kind==1?($signed(raw)-(($signed({raw[17],raw})-$signed({lp[17],lp}))>>>(velocity<2048?2:3))):
                       ($signed(raw)-(($signed({raw[17],raw})-$signed({lp[17],lp}))>>>(velocity<2048?1:2)));lp<=raw;state<=10;
   end
   10:begin product<=mul_y[35:0];state<=11;end
   11:begin wide<=kind==1?$signed(q15(product))+$signed(disp_x):$signed(work);
    disp_x<=work;product<=mul_y[35:0];state<=12;end
   12:begin
    allpass<=kind==1?clamp(wide-$signed(q15(product))):clamp(wide);
    disp_y<=kind==1?clamp(wide-$signed(q15(product))):clamp(wide);state<=13;
   end
   13:begin product<=mul_y[35:0];state<=14;end
   14:begin wide<=$signed(q15(product))+$signed(frac_x);frac_x<=allpass;product<=mul_y[35:0];state<=15;end
   15:begin work<=clamp(wide-$signed(q15(product)));frac_y<=clamp(wide-$signed(q15(product)));state<=16;end
   16:begin product<=mul_y[35:0];state<=17;end
   17:begin
    noise<={noise[30:0],noise[31]^noise[21]^noise[1]^noise[0]};
    noise_lp<=noise_lp+(($signed({noise[17],noise[17:0]})-$signed({noise_lp[17],noise_lp}))>>>2);
    if(age<hammer_rise)hammer<=hammer+(velocity<2048?18'sd750:18'sd1250);
    else if(age<(hammer_rise+{hammer_rise,1'b0}))hammer<=hammer-(velocity<2048?18'sd375:18'sd625);else hammer<=0;
    hammer_previous<=hammer;
    wide<=$signed(q15(product));state<=18;
   end
   18:begin
    ram[wr]<=clamp(wide);
    // Mechanical pickup rejects net displacement/DC independently of loop
    // pitch. Q8 pole follows pitch without changing propagation tuning.
    pickup_dc<=pickup_dc+((($signed(raw)<<<8)-pickup_dc)>>>dc_shift);
    sample<=clamp($signed(raw)-(pickup_dc>>>8));wr<=wr+1'b1;if(age!=1023)age<=age+1'b1;
    if(env_q8<24'd256)begin env_q8<=0;envelope<=0;end
    else begin env_q8<=env_q8-(gate?((env_q8>>16)+1):((env_q8>>9)+1));envelope<=env_q8[23:8];end
    state<=0;
   end
   20:begin
    frac_num<={frac_num[44:0],1'b0};frac_count<=frac_count-1'b1;
    if(frac_trial>=frac_div)begin frac_rem<=frac_trial-frac_div;frac_quot<={frac_quot[44:0],1'b1};end
    else begin frac_rem<=frac_trial;frac_quot<={frac_quot[44:0],1'b0};end
    if(frac_count==1)state<=21;
   end
   21:begin frac<=frac_quot>32767?18'sd32767:$signed({2'b0,frac_quot[15:0]});state<=8;end
   22:begin angle0<=angle_product[34:22];angle_product<=mul_y[34:0];state<=23;end
   23:begin angle1<=angle_product[34:22];z0<=mul_y[24:0];state<=24;end
   24:begin z1<=mul_y[24:0];state<=25;end
   25:begin ratio_product<=mul_y[49:0];state<=26;end
   26:begin frac_num<={ratio_product[48:18],15'd0};ratio_product<=mul_y[49:0];state<=27;end
   27:begin
    frac_div<=ratio_product[49:18]==0?32'd1:ratio_product[49:18];frac_rem<=0;frac_quot<=0;frac_count<=46;
    // At very small angles, Q12 sine arguments quantize too coarsely. The
    // ordinary low-frequency rational is accurate to <<1 cent here.
    if(effective_step<24'd524288)begin
     frac_num<=(46'd1024-{36'd0,corrected[9:0]})<<15;
     frac_div<=32'd1024+{22'd0,corrected[9:0]};
    end
    state<=20;
   end
   default:state<=0;
  endcase
  if(!rst&&tick&&state>=8)deadline_error<=1;
 end
endmodule
