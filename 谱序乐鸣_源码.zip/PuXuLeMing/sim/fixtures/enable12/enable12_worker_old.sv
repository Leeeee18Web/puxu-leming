// Four timbre families use a tagged union of voice state and local delay banks.
module enable12_worker_old #(parameter CONTEXTS=7,LENGTH=2048,SLOT_CYCLES=136,LOCAL_MEMORY_RESET=0,PRECALC_SLOT_GATES=0,LOCAL_CONTROL=0,REGIONAL_MODEL_CONTROLS=0)(
 input wire clk,rst,start,input wire[CONTEXTS-1:0]gates,triggers,
 input wire[CONTEXTS*24-1:0]steps,input wire[CONTEXTS*12-1:0]gains,
 input wire[CONTEXTS*3-1:0]timbres,
 output reg[CONTEXTS*16-1:0]samples=0,envelopes=0,
 output reg[CONTEXTS-1:0]active=0,output wire busy,
 output reg deadline_error=0,out_valid=0,output reg[2:0]out_index=0,
 output reg signed[15:0]out_sample=0,input wire[2:0]model_reset,input wire memory_reset,input wire control_resetn_early);
 `include "src/poly/poly_model_layout.vh"
 localparam EP_W=`POLY_MODEL_EP_W,REED_W=`POLY_MODEL_REED_W,STR_W=`POLY_MODEL_STRINGS_W,STATE_W=STR_W+60;
 localparam REED_LENGTH=LENGTH==2048?2050:LENGTH;
 reg running=0;reg[7:0]phase=0;reg[2:0]context_index=0;
 // Frame parameters settle before start; phase0 isolates the selected slot before restore.
 reg[23:0]step=0;reg[11:0]gain=0;reg[2:0]tone=0;
 // Keep the existing slot-entry decode as a real local register boundary.
 (* syn_preserve=1,syn_keep=1 *)reg is_ep=1,is_strings=0,is_reed=0;
 reg gate_q=0,pending_q=0;
 wire gate=PRECALC_SLOT_GATES?gate_q:gates[context_index];
 wire pending=PRECALC_SLOT_GATES?pending_q:triggers[context_index];
 wire memory_rst=LOCAL_MEMORY_RESET?memory_reset:rst;
 (* syn_preserve=1,syn_keep=1 *)reg load_memory_q=0;
 always @(posedge clk)if(rst)load_memory_q<=0;else load_memory_q<=running&&phase==0;
 wire memory_load=!memory_rst&&load_memory_q;
 wire[STATE_W-1:0]context_data,context_state;wire known;
 // The ring rotates on phase135. This unconditional local pipeline captures
 // its settled head on phase0, before phase1 restores every consumer.
 // No wide reset or high-fanout capture enable is introduced.
 (* syn_preserve=1,syn_keep=1 *)reg[STATE_W-1:0]context_snapshot=0;
 (* syn_preserve=1,syn_keep=1 *)reg snapshot_known=0;
 always @(posedge clk)begin context_snapshot<=context_data;snapshot_known<=known;end
 wire saved_gate=context_snapshot[3];wire[2:0]saved_tone=context_snapshot[2:0];
 reg fresh_context=1;
 reg warm_busy=0;
 (* syn_preserve=1,syn_keep=1 *)reg[2:0]clear_family_q=REGIONAL_MODEL_CONTROLS?3'b111:0;
 (* syn_preserve=1,syn_keep=1 *)reg[6:0]clear_body_q=REGIONAL_MODEL_CONTROLS?7'b1111111:0,load_domain_q=0;
 (* syn_preserve=1,syn_keep=1 *)reg clear_context_q=0;
 (* syn_preserve=1,syn_keep=1 *)reg[2:0]render_domain_q=0,trigger_domain_q=0;
 (* syn_preserve=1 *)reg render_q=0;
 wire ctx_load=(LOCAL_CONTROL?load_domain_q[2]:(running&&phase==1))&&!rst;
 wire ctx_save=running&&phase==134&&!rst;
 wire render_fire=(LOCAL_CONTROL?render_q:(running&&phase==5))&&!rst;
 wire attack_needed=pending||(gate&&(!saved_gate||saved_tone!=tone));
 // Captured slot controls and the restored head are stable before render.
 // Prepare this comparison in the existing wait clocks; retain the render edge.
 (* syn_preserve=1,syn_keep=1 *)reg attack_needed_q=0;
 always @(posedge clk)if(rst)attack_needed_q<=0;else attack_needed_q<=attack_needed;
 wire trigger_fire=render_fire&&((LOCAL_CONTROL&&PRECALC_SLOT_GATES)?attack_needed_q:attack_needed);
 wire raw_context_clear=running&&phase>=2&&phase<=4&&fresh_context;
 wire context_clear=LOCAL_CONTROL?(REGIONAL_MODEL_CONTROLS?clear_context_q:clear_family_q[2]):raw_context_clear;
 wire[STR_W-1:0]physical_restore=context_snapshot[STATE_W-1:60];
 wire[STR_W-1:0]string_state;wire[EP_W-1:0]ep_state;wire[REED_W-1:0]reed_state;
 wire[55:0]memory_state;
 wire signed[15:0]ep_sample,string_sample,reed_sample;
 wire[15:0]ep_env,string_env,reed_env;
 wire ep_active,string_active,reed_active,ep_busy,string_busy,reed_busy;
 wire ep_error,string_error,reed_error;
 wire string_initializing,string_body_busy,string_defer_next;wire[5:0]string_phase;
 wire selected_busy=is_ep ? ep_busy:is_strings ? string_busy:is_reed ? reed_busy:1'b0;
 wire selected_error=is_ep ? ep_error:is_strings ? string_error:is_reed ? reed_error:1'b0;
 wire defer_initial_body=phase>=113&&string_initializing&&string_phase==10;
 wire warm_enable=phase>=2&&phase<=4&&(fresh_context||!warm_busy);
 // Predict the original enable for the next scheduler edge. On phase1,
 // use exactly the values being restored by that edge, rather than old flags.
 wire restore_warm=(!snapshot_known||saved_tone!=tone)||
                   !(is_strings&&`POLY_MODEL_STRINGS_RESTORE_BUSY(physical_restore));
 // These small windows describe the scheduler phase after this edge.
 (* syn_preserve=1,syn_keep=1 *)reg phase_restore_q=0,phase_warm_q=0,phase_main_q=0,phase_defer_q=0;
 always @(posedge clk)begin
  if(rst){phase_restore_q,phase_warm_q,phase_main_q,phase_defer_q}<=0;
  else begin
   phase_restore_q<=running&&phase==0;
   phase_warm_q<=running&&(phase==1||phase==2);
   phase_main_q<=running&&phase>=3&&phase<=130;
   phase_defer_q<=running&&phase>=111&&phase<=130;
  end
 end
 // Restore and fresh-clear are predicted at the previous scheduler edge.
 // Each field region has one local driver; no new state crosses a context.
 wire next_clear=(phase_restore_q&&(!snapshot_known||saved_tone!=tone))||
                 (phase_warm_q&&fresh_context);
 // Keep the diagnostic fresh-clear separate from complete consumer resets.
 always @(posedge clk)begin
  if(rst)begin clear_context_q<=0;render_q<=0;end
  else begin clear_context_q<=next_clear;render_q<=running&&phase==4;end
 end
 wire[2:0]slot_tone=timbres[context_index*3+:3];
 wire[2:0]family_after_edge=running&&phase==0 ?
   {((slot_tone==1)||(slot_tone==2)),(slot_tone==3),(slot_tone==0)}:
   {is_strings,is_reed,is_ep};
 // gain is the pre-edge value, exactly matching gain_zero_q in strings.
 wire body_clear_next=next_clear||!family_after_edge[2]||(gain==0)||
   (running&&phase==4&&attack_needed&&is_strings);
 generate if(REGIONAL_MODEL_CONTROLS)begin:regional_controls
  // The penultimate synchronizer releases at C2; these FFs capture normal
  // controls at C3, exactly when the final scheduler reset falls. No final
  // reset test is allowed here, or the original CE would gain an extra edge.
  always @(posedge clk or negedge control_resetn_early)begin
   if(!control_resetn_early)begin
    clear_family_q<=3'b111;clear_body_q<=7'b1111111;load_domain_q<=0;
    render_domain_q<=0;trigger_domain_q<=0;
   end else begin
    clear_family_q<={3{next_clear}}|~family_after_edge;
    clear_body_q<={7{body_clear_next}};
    load_domain_q<={7{running&&phase==0}};
    render_domain_q<={3{running&&phase==4}};
    trigger_domain_q<={3{running&&phase==4&&attack_needed}}&{is_strings,is_reed,is_ep};
   end
  end
 end else begin:generic_controls
  always @(posedge clk)begin
   if(rst)begin clear_family_q<=0;clear_body_q<=0;load_domain_q<=0;end
   else begin
    clear_family_q<={3{next_clear}};clear_body_q<={7{next_clear}};
    load_domain_q<={7{running&&phase==0}};
   end
  end
 end endgenerate
 wire next_enable=(phase_restore_q&&restore_warm)||
  (phase_warm_q&&(fresh_context||!warm_busy))||
  (phase_main_q&&!(phase_defer_q&&string_initializing&&string_defer_next));
 (* syn_preserve=1,syn_keep=1 *)reg enable_memory_q=0,enable_ep_q=REGIONAL_MODEL_CONTROLS,enable_reed_q=REGIONAL_MODEL_CONTROLS,enable_strings_q=REGIONAL_MODEL_CONTROLS;
 (* syn_preserve=1,syn_keep=1 *)reg enable_line_a_q=REGIONAL_MODEL_CONTROLS,enable_line_b_q=REGIONAL_MODEL_CONTROLS,enable_line_c_q=REGIONAL_MODEL_CONTROLS,enable_body_q=REGIONAL_MODEL_CONTROLS;
 always @(posedge clk)if(rst)enable_memory_q<=0;else enable_memory_q<=next_enable;
 generate if(REGIONAL_MODEL_CONTROLS)begin:regional_enables
  always @(posedge clk or negedge control_resetn_early)
   if(!control_resetn_early){enable_ep_q,enable_reed_q,enable_strings_q,enable_line_a_q,enable_line_b_q,enable_line_c_q,enable_body_q}<=7'b1111111;
   else {enable_ep_q,enable_reed_q,enable_strings_q,enable_line_a_q,enable_line_b_q,enable_line_c_q,enable_body_q}<={7{next_enable}};
 end else begin:generic_enables
  always @(posedge clk)
   if(rst){enable_ep_q,enable_reed_q,enable_strings_q,enable_line_a_q,enable_line_b_q,enable_line_c_q,enable_body_q}<=0;
   else {enable_ep_q,enable_reed_q,enable_strings_q,enable_line_a_q,enable_line_b_q,enable_line_c_q,enable_body_q}<={7{next_enable}};
 end endgenerate
 wire core_enable=rst||enable_memory_q;
 wire signed[15:0]raw_sample=is_ep ? ep_sample:is_strings ? string_sample:is_reed ? reed_sample:16'sd0;
 wire[15:0]raw_env=is_ep ? ep_env:is_strings ? string_env:is_reed ? reed_env:16'd0;
 wire raw_active=is_ep ? ep_active:is_strings ? string_active:is_reed ? reed_active:1'b0;
 wire[STR_W-1:0]physical_save=is_ep ? {{(STR_W-EP_W){1'b0}},ep_state}:
  is_reed ? {{(STR_W-REED_W){1'b0}},reed_state}:is_strings ? string_state:{STR_W{1'b0}};
 assign context_state={physical_save,memory_state,(gate&&(gain!=0)),(gain!=0 ? tone:3'd0)};
 poly_context_store #(.WIDTH(STATE_W),.COUNT(CONTEXTS),.INDEX_WIDTH(3),.ROTATING(1)) contexts(
  clk,rst,ctx_save,context_index,context_state,context_data,known);
 wire[12:0]sra,srb,src,swa,swb,swc,rra,rwa;
 wire[2:0]swe;wire rwe;wire[17:0]sda,sdb,sdc;wire[19:0]rdata,qa;wire[17:0]qb,qc;
 poly_delay_pool #(.CONTEXTS(CONTEXTS),.LENGTH(LENGTH),.A_EXTRA(REED_LENGTH-LENGTH),.SEPARATE_SPILL(1)) memory(
  .clk(clk),.rst(memory_rst),.enable(memory_rst||enable_memory_q),.ctx_load(memory_load),.ctx_index(context_index),
  .ctx_data(context_snapshot[59:4]),.ctx_state(memory_state),
  .ra(is_reed ? rra:sra),.rb(srb),.rc(src),.wa(is_reed ? rwa:swa),.wb(swb),.wc(swc),
  .we_a(is_reed ? rwe:is_strings ? swe[0]:1'b0),.we_b(is_strings&&swe[1]),.we_c(is_strings&&swe[2]),
  .da(is_reed ? rdata:{2'd0,sda}),.db(sdb),.dc(sdc),.qa(qa),.qb(qb),.qc(qc),
  .spill_we(is_reed&&rwe),.spill_wa(rwa),.spill_data(rdata));
 poly_model_ep ep(.clk(clk),.rst(REGIONAL_MODEL_CONTROLS?clear_family_q[0]:(model_reset[0]||(LOCAL_CONTROL?clear_family_q[0]:raw_context_clear)||!is_ep)),.render_tick(REGIONAL_MODEL_CONTROLS?render_domain_q[0]:render_fire),
  .gate(gate),.trigger(REGIONAL_MODEL_CONTROLS?trigger_domain_q[0]:(trigger_fire&&is_ep)),.step(step),.gain(gain),
  .sample(ep_sample),.envelope(ep_env),.active(ep_active),.busy(ep_busy),.deadline_error(ep_error),
  .ctx_enable(REGIONAL_MODEL_CONTROLS?enable_ep_q:(rst||enable_ep_q)),.ctx_load(REGIONAL_MODEL_CONTROLS?load_domain_q[0]:(LOCAL_CONTROL?(load_domain_q[0]&&!model_reset[0]):ctx_load)),.ctx_data(physical_restore[EP_W-1:0]),.ctx_state(ep_state));
 poly_model_reed #(.LENGTH(REED_LENGTH),.PRECALC_STEP(1)) reed(.clk(clk),.rst(REGIONAL_MODEL_CONTROLS?clear_family_q[1]:(model_reset[2]||(LOCAL_CONTROL?clear_family_q[1]:raw_context_clear)||!is_reed)),.render_tick(REGIONAL_MODEL_CONTROLS?render_domain_q[1]:render_fire),
  .gate(gate),.trigger(REGIONAL_MODEL_CONTROLS?trigger_domain_q[1]:(trigger_fire&&is_reed)),.step(step),.gain(gain),
  .sample(reed_sample),.envelope(reed_env),.active(reed_active),.busy(reed_busy),.deadline_error(reed_error),
  .ctx_enable(REGIONAL_MODEL_CONTROLS?enable_reed_q:(rst||enable_reed_q)),.ctx_load(REGIONAL_MODEL_CONTROLS?load_domain_q[1]:(LOCAL_CONTROL?(load_domain_q[1]&&!model_reset[2]):ctx_load)),.ctx_data(physical_restore[REED_W-1:0]),.ctx_state(reed_state),
  .mem_q(qa),.mem_raddr(rra),.mem_waddr(rwa),.mem_we(rwe),.mem_data(rdata));
 enable12_strings_old #(.LENGTH(LENGTH),.LOCAL_ENABLES(1),.PRECALC_ZERO_GAIN(1),.LOCAL_CONTROLS(LOCAL_CONTROL),.BODY_RESETS_COMPLETE(REGIONAL_MODEL_CONTROLS)) strings(.clk(clk),.rst(REGIONAL_MODEL_CONTROLS?clear_family_q[2]:(model_reset[1]||context_clear||!is_strings)),.render_tick(REGIONAL_MODEL_CONTROLS?render_domain_q[2]:render_fire),
  .gate(gate),.trigger(REGIONAL_MODEL_CONTROLS?trigger_domain_q[2]:(trigger_fire&&is_strings)),.step(step),.gain(gain),.timbre(tone),
  .sample(string_sample),.envelope(string_env),.active(string_active),.busy(string_busy),.deadline_error(string_error),
  .ctx_enable(REGIONAL_MODEL_CONTROLS?enable_strings_q:(rst||enable_strings_q)),.ctx_load(REGIONAL_MODEL_CONTROLS?load_domain_q[2]:(LOCAL_CONTROL?(load_domain_q[2]&&!model_reset[1]):ctx_load)),.ctx_data(physical_restore),.ctx_state(string_state),
  .ctx_local_enable(REGIONAL_MODEL_CONTROLS?{enable_body_q,enable_line_c_q,enable_line_b_q,enable_line_a_q}:{(rst||enable_body_q),(rst||enable_line_c_q),(rst||enable_line_b_q),(rst||enable_line_a_q)}),.defer_next_out(string_defer_next),
  .ctx_local_load(REGIONAL_MODEL_CONTROLS?load_domain_q[6:3]:(load_domain_q[6:3]&{4{!model_reset[1]}})),
  .ctx_body_reset(REGIONAL_MODEL_CONTROLS?clear_body_q:(clear_body_q|{7{model_reset[1]||!is_strings}})),
  .mem_qa(qa[17:0]),.mem_qb(qb),.mem_qc(qc),.mem_ra(sra),.mem_rb(srb),.mem_rc(src),
  .mem_wa(swa),.mem_wb(swb),.mem_wc(swc),.mem_we(swe),.mem_da(sda),.mem_db(sdb),.mem_dc(sdc),
  .initializing_out(string_initializing),.body_busy_out(string_body_busy),.state_out(string_phase));
 function automatic signed[15:0]grand_knee(input signed[19:0]x);
  reg signed[20:0]magnitude,soft_magnitude;
  begin magnitude=x<0 ? -$signed({x[19],x}):$signed({x[19],x});
   if(magnitude<=6000)soft_magnitude=magnitude;
   else if(magnitude<12000)soft_magnitude=6000+((magnitude-6000)>>>2);
   else soft_magnitude=7500;
   grand_knee=x<0 ? -$signed(soft_magnitude):$signed(soft_magnitude);
  end
 endfunction
 wire[10:0]balance=step<=24'd45056 ? 11'd1024:step>=24'd176128 ? 11'd768:11'd1024-((step-24'd45056)>>9);
 reg v0=0,v1=0;reg signed[15:0]raw0=0,raw1=0;reg signed[27:0]product1=0;
 reg[10:0]balance0=0;reg grand0=0,grand1=0,active0=0,active1=0;
 reg[15:0]env0=0,env1=0;reg[2:0]tag0=0,tag1=0;
 wire signed[19:0]scaled1=product1>>>8;
 wire signed[15:0]voiced=grand1 ? grand_knee(scaled1):raw1;
 always @(posedge clk)begin
  out_valid<=0;
  if(rst)begin
   running<=0;phase<=0;context_index<=0;deadline_error<=0;
   step<=0;gain<=0;tone<=0;gate_q<=0;pending_q<=0;is_ep<=1;is_strings<=0;is_reed<=0;fresh_context<=1;warm_busy<=0;
   samples<=0;envelopes<=0;active<=0;out_index<=0;out_sample<=0;
   v0<=0;v1<=0;raw0<=0;raw1<=0;product1<=0;balance0<=0;
   grand0<=0;grand1<=0;active0<=0;active1<=0;env0<=0;env1<=0;tag0<=0;tag1<=0;
  end else begin
   if(ctx_load)begin
    fresh_context<=!snapshot_known||saved_tone!=tone;
    // Capture the FSM busy value installed by this same restore edge.
    // It remains unchanged over warm phases2..4 (no render/trigger there).
    warm_busy<=is_strings&&`POLY_MODEL_STRINGS_RESTORE_BUSY(physical_restore);
   end
   if(start)begin
    if(running)deadline_error<=1;
    else begin running<=1;phase<=0;context_index<=0;end
   end
   if(running)begin
    if(phase==0)begin
     gate_q<=gates[context_index];pending_q<=triggers[context_index];
     step<=steps[context_index*24+:24];gain<=gains[context_index*12+:12];tone<=timbres[context_index*3+:3];
     is_ep<=timbres[context_index*3+:3]==0;
     is_strings<=timbres[context_index*3+:3]==1||timbres[context_index*3+:3]==2;
     is_reed<=timbres[context_index*3+:3]==3;
    end
    if(phase==SLOT_CYCLES-1)begin
     phase<=0;if(context_index==CONTEXTS-1)begin running<=0;context_index<=0;end
     else context_index<=context_index+1'b1;
    end else phase<=phase+1'b1;
   end
   if(ctx_save&&(selected_error||(is_ep&&ep_busy)||(is_reed&&reed_busy)||
      (is_strings&&(string_body_busy||(!string_initializing&&string_busy)))))deadline_error<=1;
   v0<=running&&phase==133;v1<=v0;
   if(running&&phase==133)begin
    raw0<=gain==0 ? 16'sd0:raw_sample;balance0<=balance;grand0<=tone==1;
    active0<=(gain!=0)&&raw_active;env0<=gain==0 ? 16'd0:raw_env;tag0<=context_index;
   end
   product1<=raw0*$signed({1'b0,balance0});raw1<=raw0;
   grand1<=grand0;active1<=active0;env1<=env0;tag1<=tag0;
   if(v1)begin
    samples[tag1*16+:16]<=voiced;envelopes[tag1*16+:16]<=env1;active[tag1]<=active1;
    out_valid<=1;out_index<=tag1;out_sample<=voiced;
   end
  end
 end
 assign busy=running||v0||v1;
 // synthesis translate_off
 always @(posedge clk)if(!rst&&core_enable&&running&&phase>=5)begin
  if(is_strings&&((swe[0]&&swa>=LENGTH)||(swe[1]&&swb>=LENGTH)||(swe[2]&&swc>=LENGTH)))$fatal(1,"POLY_STRING_RAM_BOUNDS");
  if(is_reed&&rwe&&rwa>=REED_LENGTH)$fatal(1,"POLY_REED_RAM_BOUNDS");
  if(is_reed&&rra>=REED_LENGTH)$fatal(1,"POLY_REED_READ_BOUNDS");
  if(is_strings&&(sra>=LENGTH||srb>=LENGTH||src>=LENGTH))$fatal(1,"POLY_STRING_READ_BOUNDS");
 end
 // synthesis translate_on
endmodule
