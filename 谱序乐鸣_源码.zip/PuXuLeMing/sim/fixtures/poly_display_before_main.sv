// Four representative panel slots cover every configured voice. The home7 and leading
// monitors independently aggregate all voices; panel selection is a slow scan.
module poly_display_before_main #(parameter VOICE_COUNT=25)(input wire clk,rst,input wire[VOICE_COUNT-1:0]gates,input wire[VOICE_COUNT*7-1:0]notes,input wire[VOICE_COUNT*12-1:0]gains,output reg[3:0]panel_gates=0,output reg[27:0]panel_notes=0,output reg[47:0]panel_gains=0);
 reg[4:0]index=0;reg[3:0]found=0;reg[27:0]working_notes=0;reg[47:0]working_gains=0;
 localparam B1=(VOICE_COUNT+3)/4,B2=B1+(VOICE_COUNT+2)/4,B3=B2+(VOICE_COUNT+1)/4;
 wire[1:0]group_id=index<B1?2'd0:index<B2?2'd1:index<B3?2'd2:2'd3;
 always @(posedge clk)begin
  if(rst)begin index<=0;found<=0;working_notes<=0;working_gains<=0;panel_gates<=0;panel_notes<=0;panel_gains<=0;end
  else if(index==VOICE_COUNT)begin
   panel_gates<=found;panel_notes<=working_notes;panel_gains<=working_gains;
   found<=0;working_notes<=0;working_gains<=0;index<=0;
  end else begin
   if(gates[index]&&gains[index*12+:12]!=0&&!found[group_id])begin
    found[group_id]<=1;working_notes[group_id*7+:7]<=notes[index*7+:7];working_gains[group_id*12+:12]<=gains[index*12+:12];
   end
   index<=index+1'b1;
  end
 end
endmodule
