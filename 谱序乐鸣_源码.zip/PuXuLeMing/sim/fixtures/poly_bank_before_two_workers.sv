// Fixed ownership partition keeps each context and RAM near one datapath.
module poly_bank_before_two_workers #(parameter VOICE_COUNT=25)(input wire clk,rst,start,input wire[VOICE_COUNT-1:0]gates,triggers,input wire[VOICE_COUNT*24-1:0]steps,input wire[VOICE_COUNT*12-1:0]gains,input wire[VOICE_COUNT*3-1:0]timbres,output wire[VOICE_COUNT*16-1:0]samples,envelopes,output wire[VOICE_COUNT-1:0]active,output wire busy,deadline_error,input wire[11:0]model_reset);
 wire[3:0]worker_busy,worker_error;
 genvar g;generate for(g=0;g<4;g=g+1)begin:group
  localparam N=VOICE_COUNT/4+(g<VOICE_COUNT%4);
  localparam BASE=g*(VOICE_COUNT/4)+(g<VOICE_COUNT%4?g:VOICE_COUNT%4);
  poly_voice_worker #(.CONTEXTS(N)) worker(.clk(clk),.rst(rst),.start(start),.model_reset(model_reset[g*3+:3]),
   .gates(gates[BASE+:N]),.triggers(triggers[BASE+:N]),.steps(steps[BASE*24+:N*24]),
   .gains(gains[BASE*12+:N*12]),.timbres(timbres[BASE*3+:N*3]),
   .samples(samples[BASE*16+:N*16]),.envelopes(envelopes[BASE*16+:N*16]),.active(active[BASE+:N]),
   .busy(worker_busy[g]),.deadline_error(worker_error[g]),.out_valid(),.out_index(),.out_sample(),.control_resetn_early(1'b1));
 end endgenerate
 assign busy=|worker_busy;assign deadline_error=|worker_error;
endmodule
