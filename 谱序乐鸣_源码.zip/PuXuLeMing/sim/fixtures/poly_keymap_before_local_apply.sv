`timescale 1ns/1ps
// Complete-table transaction. Draft writes never change the audible mapping.
// CRC-CCITT/FFFF covers base, enabled, then all 25 seven-bit notes as bytes.
module poly_keymap_before_local_apply(
 input wire clk,rst,abort_transaction,
 input wire command_valid,input wire[7:0]command_op,
 input wire[31:0]command_a,command_b,command_c,
 input wire key_seen_valid,input wire[4:0]key_seen_index,
 output reg command_done=0,output reg[7:0]command_result=0,
 output reg[174:0]map_notes=0,output reg[6:0]map_input_base=60,
 output reg map_enabled=1,map_apply=0,
 output wire[31:0]reply_a,reply_b
);
 function automatic[15:0]crc_byte(input[15:0]c,input[7:0]b);
  reg[15:0]v;integer k;begin v=c^{b,8'd0};for(k=0;k<8;k=k+1)v=v[15]?(v<<1)^16'h1021:v<<1;crc_byte=v;end
 endfunction
 function automatic[15:0]default_crc();
  reg[15:0]v;integer n;begin v=crc_byte(crc_byte(16'hffff,60),1);for(n=0;n<25;n=n+1)v=crc_byte(v,60+n);default_crc=v;end
 endfunction
 reg[174:0]draft=0;reg[24:0]written=0;reg[6:0]draft_base=60;reg draft_enabled=1,uploading=0;
 reg[1:0]phase=0;reg[5:0]crc_index=0;reg[15:0]crc=16'hffff,expected_crc=0,active_crc=default_crc();
 reg[6:0]read_note=60;reg[4:0]learned_index=0;reg learned_valid=0;
 wire[7:0]crc_data=crc_index==0?{1'b0,draft_base}:crc_index==1?{7'd0,draft_enabled}:{1'b0,draft[(crc_index-2)*7+:7]};
 wire[15:0]next_crc=crc_byte(crc,crc_data);
 assign reply_a={7'd0,map_enabled,1'b0,map_input_base,1'b0,read_note,command_result};
 assign reply_b={10'd0,learned_valid,learned_index,active_crc};
 integer i;
 always @(posedge clk)begin
  command_done<=0;map_apply<=0;
  if(rst)begin
   for(i=0;i<25;i=i+1)map_notes[i*7+:7]<=60+i;
   map_input_base<=60;map_enabled<=1;active_crc<=default_crc();phase<=0;uploading<=0;written<=0;
   draft<=0;draft_base<=60;draft_enabled<=1;crc_index<=0;crc<=16'hffff;expected_crc<=0;
   command_result<=0;read_note<=60;learned_index<=0;learned_valid<=0;
  end else begin
   if(key_seen_valid&&key_seen_index<25)begin learned_index<=key_seen_index;learned_valid<=1;end
   if(abort_transaction)begin
    // Cancellation wins over command acceptance, CRC completion and bank swap.
    // A result4 must never describe a transaction that changed the active map.
    uploading<=0;written<=0;phase<=0;
    if(phase!=0||command_valid)begin command_result<=4;command_done<=1;end
   end else begin
   if(phase==1)begin
    crc<=next_crc;
    if(crc_index==26)phase<=3;
    else crc_index<=crc_index+1'b1;
   end
   // Compare the completed CRC after its existing register, before clear/swap.
   if(phase==3)begin
    if(crc!=expected_crc)begin command_result<=5;command_done<=1;phase<=0;end
    else begin map_apply<=1;phase<=2;end
   end
   // The clear pulse is observed by the controller before the new bank is visible.
   if(phase==2)begin
    map_notes<=draft;map_input_base<=draft_base;map_enabled<=draft_enabled;active_crc<=expected_crc;
    uploading<=0;phase<=0;command_result<=0;command_done<=1;
   end
   if(command_valid&&phase==0)begin
    command_result<=0;command_done<=1;
    case(command_op)
     20:if(command_a>103||command_b>1||command_c!=0)command_result<=1;
        else begin draft_base<=command_a[6:0];draft_enabled<=command_b[0];written<=0;uploading<=1;end
     21:if(!uploading||command_a>24||command_b>127||command_c!=0)command_result<=1;
        else begin draft[command_a*7+:7]<=command_b[6:0];written[command_a]<=1;end
     22:if(command_a>65535||command_b>1||command_c!=0)command_result<=1;
        else if(!uploading||written!=25'h1ffffff)command_result<=5;
        else begin command_done<=0;expected_crc<=command_a[15:0];crc<=16'hffff;crc_index<=0;phase<=1;end
     23:if(command_a>24||command_b!=0||command_c!=0)command_result<=1;
        else read_note<=map_notes[command_a*7+:7];
     24:if(command_a>1||command_b!=0||command_c!=0)command_result<=1;
        else if(command_a==1)learned_valid<=0;
     default:command_result<=1;
    endcase
   end
   end
  end
 end
endmodule
