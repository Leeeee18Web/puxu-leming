module ref_status_snapshot # (parameter PERIOD=1000000, WIDTH=164)(
 input clk,rstn,input [WIDTH-1:0] source_data,
 input pixel_clk,pixel_rstn,frame_start,output wire [WIDTH-1:0] data);
 // Keep the frame-ACK destination as a real register boundary. Inferred DSP
 // input registers must not absorb this held-payload CDC latch.
 (* syn_preserve=1 *) reg [WIDTH-1:0] frame_data=0;
 assign data=frame_data;
 reg [19:0] count=0;reg publish=0,seen=0;
 reg [WIDTH-1:0] held=0;
 (* syn_preserve=1 *) reg [1:0] publish_sync=0,ack_sync=0;
 reg ack=0;
 always @(posedge clk)begin
  ack_sync<={ack_sync[0],ack};
  if(!rstn)begin count<=0;publish<=0;held<=0;ack_sync<=0;end
  else if(count==PERIOD-1)begin
   if(ack_sync[1]==publish)begin held<=source_data;publish<=~publish;count<=0;end
  end else count<=count+1'b1;
 end
 always @(posedge pixel_clk)begin
  publish_sync<={publish_sync[0],publish};
  if(!pixel_rstn)begin publish_sync<=0;seen<=0;ack<=0;frame_data<=0;end
  else if(frame_start&&publish_sync[1]!=seen)begin frame_data<=held;seen<=publish_sync[1];ack<=publish_sync[1];end
 end
endmodule
