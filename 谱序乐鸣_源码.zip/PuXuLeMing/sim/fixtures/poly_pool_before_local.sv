// Three local synchronous delay banks, partitioned by context. Strings use
// 18-bit lanes; reed uses the 20-bit A lane. No reset of the storage arrays.
module poly_pool_before_local #(parameter CONTEXTS=7,LENGTH=2112,ADDR_WIDTH=13,A_EXTRA=0)(input wire clk,rst,enable,ctx_load,input wire[2:0]ctx_index,input wire[55:0]ctx_data,output wire[55:0]ctx_state,input wire[ADDR_WIDTH-1:0]ra,rb,rc,wa,wb,wc,input wire we_a,we_b,we_c,input wire[19:0]da,input wire[17:0]db,dc,output wire[19:0]qa,output wire[17:0]qb,qc);
 localparam DEPTH=CONTEXTS*LENGTH;
 wire[31:0]base=ctx_index*LENGTH;
 wire[14:0]ar=base+((A_EXTRA!=0&&ra>=LENGTH)?0:ra),br=base+rb,cr=base+rc;
 wire[14:0]aw=base+((A_EXTRA!=0&&wa>=LENGTH)?0:wa),bw=base+wb,cw=base+wc;
 wire main_write=we_a&&(A_EXTRA==0||wa<LENGTH);wire[19:0]main_qa;
 poly_lane_before_local #(.WIDTH(18),.DEPTH(DEPTH),.CHUNK_BITS(10)) a_low(clk,rst,enable,ctx_load,ctx_data[53:36],ar,aw,main_write,da[17:0],main_qa[17:0]);
 poly_lane_before_local #(.WIDTH(2),.DEPTH(DEPTH),.CHUNK_BITS(13)) a_high(clk,rst,enable,ctx_load,ctx_data[55:54],ar,aw,main_write,da[19:18],main_qa[19:18]);
 poly_lane_before_local #(.WIDTH(18),.DEPTH(DEPTH),.CHUNK_BITS(10)) b_lane(clk,rst,enable,ctx_load,ctx_data[35:18],br,bw,we_b,db,qb);
 poly_lane_before_local #(.WIDTH(18),.DEPTH(DEPTH),.CHUNK_BITS(10)) c_lane(clk,rst,enable,ctx_load,ctx_data[17:0],cr,cw,we_c,dc,qc);
 // The reed's full-period interpolator needs two samples beyond the native
 // 2048-word string ring. Keep only those spill samples in private FF rows.
 // Payloads do not reset; the model's fill counter guards unwritten history.
 generate if(A_EXTRA==0)begin:no_spill
  assign qa=main_qa;
 end else begin:spill
  wire[19:0]words[0:CONTEXTS*A_EXTRA-1];
  genvar c,o;for(c=0;c<CONTEXTS;c=c+1)begin:voice
   for(o=0;o<A_EXTRA;o=o+1)begin:point
    reg[19:0]value;
    always @(posedge clk)if(enable&&!ctx_load&&!rst&&we_a&&ctx_index==c&&wa==LENGTH+o)value<=da;
    assign words[c*A_EXTRA+o]=value;
   end
  end
  reg[19:0]read_q,saved_q=0;reg selected=0,restored=1;
  always @(posedge clk)begin
   if(rst)begin selected<=0;restored<=1;saved_q<=0;end
   else if(ctx_load)begin restored<=1;saved_q<=ctx_data[55:36];end
   else if(enable)begin
    restored<=0;selected<=ra>=LENGTH;
    if(ra>=LENGTH&&ra<LENGTH+A_EXTRA)read_q<=words[ctx_index*A_EXTRA+(ra-LENGTH)];
   end
  end
  assign qa=restored?saved_q:selected?read_q:main_qa;
 end endgenerate
 assign ctx_state={qa,qb,qc};
endmodule

// Explicit native-sized banks avoid rounding every context pool to a 16K
// power-of-two depth. A separate two-bit lane retains reed pressure precision.
// Each bank is read-first synchronous RAM; the registered bank selector and
// restored output keep the original one-clock read contract across ctx_load.
module poly_lane_before_local #(parameter WIDTH=18,DEPTH=14784,CHUNK_BITS=10)(
 input wire clk,rst,enable,ctx_load,input wire[WIDTH-1:0]ctx_data,
 input wire[14:0]ra,wa,input wire we,input wire[WIDTH-1:0]data,
 output wire[WIDTH-1:0]q);
 localparam CHUNKS=(DEPTH+(1<<CHUNK_BITS)-1)>>CHUNK_BITS;
 reg[14-CHUNK_BITS:0]read_bank=0;
 reg restored=1;reg[WIDTH-1:0]saved_q=0;
 wire[WIDTH-1:0]bank_q[0:CHUNKS-1];
 genvar g;
 generate for(g=0;g<CHUNKS;g=g+1)begin:chunk
  reg[WIDTH-1:0]storage[0:(1<<CHUNK_BITS)-1] /* synthesis syn_ramstyle="block_ram" */;
  reg[WIDTH-1:0]read_q;
  always @(posedge clk)begin
   if(enable&&!ctx_load&&!rst)begin
    if(ra[14:CHUNK_BITS]==g)read_q<=storage[ra[CHUNK_BITS-1:0]];
    if(we&&wa[14:CHUNK_BITS]==g)storage[wa[CHUNK_BITS-1:0]]<=data;
   end
  end
  assign bank_q[g]=read_q;
 end endgenerate
 always @(posedge clk)begin
  if(rst)begin restored<=1;saved_q<=0;read_bank<=0;end
  else if(ctx_load)begin restored<=1;saved_q<=ctx_data;end
  else if(enable)begin restored<=0;read_bank<=ra[14:CHUNK_BITS];end
 end
 assign q=restored?saved_q:bank_q[read_bank];
endmodule
