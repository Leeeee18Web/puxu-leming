`timescale 1ns/1ps
// One registered event slot separates source selection from consumer decoding.
// No fall-through/refill: fixed priority, held payload, one event / two clocks.
module pat72_old_arbiter(
 input wire clk,rst,flush,
 input wire[31:0]touch_data,usb_data,gesture_data,wifi_data,
 input wire touch_valid,usb_valid,gesture_valid,wifi_valid,
 output wire touch_ready,usb_ready,gesture_ready,wifi_ready,
 output wire[1:0]source_tag,output wire[31:0]data,output wire valid,input wire ready,output wire raw_valid
);
 (* syn_preserve=1 *)reg[31:0]pending_data=0;
 (* syn_preserve=1 *)reg pending_valid=0;reg[1:0]pending_source=0;
 wire empty=!pending_valid&&!flush&&!rst;
 assign raw_valid=pending_valid;
 assign source_tag=pending_source;assign data=pending_data;assign valid=pending_valid&&!flush&&!rst;
 assign touch_ready=empty;
 assign usb_ready=empty&&!touch_valid;
 assign gesture_ready=empty&&!touch_valid&&!usb_valid;
 assign wifi_ready=empty&&!touch_valid&&!usb_valid&&!gesture_valid;
 always @(posedge clk)begin
  if(rst||flush)begin pending_data<=0;pending_valid<=0;pending_source<=0;end
  else if(pending_valid)begin if(ready)pending_valid<=0;end
  else if(touch_valid||usb_valid||gesture_valid||wifi_valid)begin
   pending_data<=touch_valid?touch_data:usb_valid?usb_data:gesture_valid?gesture_data:wifi_data;
   pending_source<=touch_valid?2'd0:usb_valid?2'd1:gesture_valid?2'd2:2'd3;
   pending_valid<=1;
  end
 end
endmodule
