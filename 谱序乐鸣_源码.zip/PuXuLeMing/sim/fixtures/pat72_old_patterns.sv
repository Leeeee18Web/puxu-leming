`timescale 1ns/1ps
// Silent latched selection. Snapshot sorting uses the actual MIDI pitches.
module pat72_old_patterns #(
 parameter SAMPLE_HZ=48828, STRUM_SAMPLES=1953,
 parameter ARP_SAMPLES=12207, HOLD_SAMPLES=39062,
 parameter BRANCH_FULL_RELOAD=0
)(
 input wire clk,rst,sample_tick,cancel,input wire [1:0] pattern_mode,
 input wire start,event_valid,input wire [31:0] event_data,
 output reg [6:0] selected=0,output reg [48:0] selected_notes=0,
 output reg [83:0] selected_gains=0,output reg [3:0] gates=0,triggers=0,
 output reg [27:0] notes=0,output reg [47:0] gains=0,
 output reg busy=0,output wire [2:0] count,output reg full=0,
 input wire [1:0] full_touch_mode,full_wifi_mode,
 input wire full_owner,full_touch_enabled,full_note_request,full_base_cancel
);
 localparam ARP_GATE=(ARP_SAMPLES*4/5<1)?1:ARP_SAMPLES*4/5;
 localparam IDLE=0,PREPARE=1,STRUM=2,CHORD=3,ARP=4;
 reg [2:0] state=IDLE;
 reg [1:0] previous_mode=0,run_mode=0;
 reg [6:0] snapshot_selected=0,remaining=0;
 reg [48:0] snapshot_notes=0;
 reg [83:0] snapshot_gains=0;
 reg [6:0] order[0:6];
 reg [2:0] scan=0,rank=0,run_index=0;
 reg [6:0] best_note=127,best_mask=0;
 reg sorted=0,clear_sample=0;
 reg [31:0] interval_left=0,hold_left=0,arp_age=0,full_left=0;
 wire [7:0] status=event_data[7:0];
 wire [6:0] pitch=event_data[14:8],velocity=event_data[22:16];
 wire legal_data=!event_data[15]&&!event_data[23];
 wire selection_event=event_valid&&legal_data&&status[7:4]==9&&velocity!=0&&pattern_mode!=0;
 wire disconnect=event_valid&&status==8'hff;
 wire [6:0] match_mask,free_mask,choice_mask;
 wire [6:0] candidates=(|match_mask)?match_mask:free_mask;
 wire [6:0] bounded_velocity=event_data[24]?7'd100:((velocity>100)?7'd100:velocity);
 assign count={2'd0,selected[0]}+{2'd0,selected[1]}+{2'd0,selected[2]}+
              {2'd0,selected[3]}+{2'd0,selected[4]}+{2'd0,selected[5]}+{2'd0,selected[6]};
 genvar v;
 generate for(v=0;v<7;v=v+1)begin:selection_slot
  assign match_mask[v]=selected[v]&&selected_notes[v*7+:7]==pitch;
  assign free_mask[v]=!selected[v];
  if(v==0)assign choice_mask[v]=candidates[v];
  else assign choice_mask[v]=candidates[v]&&!(|candidates[v-1:0]);
 end endgenerate
 // One static slot per clock, seven clocks per rank: <=49 clock preparation.
 // Preserve seven UI selection slots; compact each sorted onset into one of
 // four sound slots. Sequential strum wraps at slot four, reclaiming oldest.
 // Keep selection identity independent of live cancel/ready controls. The
 // incoming event decides only the final write enable of each gain slot.
 wire legacy_eligible=!(cancel||pattern_mode!=previous_mode||pattern_mode==0||disconnect);
 wire touch_eligible=full_touch_enabled&&full_touch_mode!=0&&full_touch_mode==previous_mode;
 wire wifi_eligible=full_wifi_mode!=0&&full_wifi_mode==previous_mode;
 wire legacy_accept=(|match_mask)||((|free_mask)&&(pattern_mode!=2||count<4));
 wire touch_accept=(|match_mask)||((|free_mask)&&(full_touch_mode!=2||count<4));
 wire wifi_accept=(|match_mask)||((|free_mask)&&(full_wifi_mode!=2||count<4));
 // Owner selects a completed one-bit decision, never the two-bit mode
 // ahead of admission/count. Slot identity comparisons remain shared.
 wire branch_admit=full_note_request&&!full_base_cancel&&
                   (full_owner?(wifi_eligible&&wifi_accept):(touch_eligible&&touch_accept));
 wire branch_reload=full_note_request&&!full_base_cancel&&
                    (full_owner?(wifi_eligible&&!wifi_accept):(touch_eligible&&!touch_accept));
 wire selection_admit=BRANCH_FULL_RELOAD?branch_admit:(legacy_eligible&&selection_event&&legacy_accept);
 wire chord_entry=BRANCH_FULL_RELOAD?
                  (full_owner?(full_wifi_mode==2&&previous_mode!=2):(full_touch_mode==2&&previous_mode!=2)):
                  (pattern_mode==2&&pattern_mode!=previous_mode);
 wire full_reload=BRANCH_FULL_RELOAD?branch_reload:(legacy_eligible&&selection_event&&!legacy_accept);
 // Complete owner decisions feed the run controller as well as selection.
 // Root supplies the same-cycle local link/flush qualification on every input.
 wire branch_run_eligible=!full_base_cancel&&!disconnect&&
                          (full_owner?wifi_eligible:touch_eligible);
 wire run_blocked=BRANCH_FULL_RELOAD?!branch_run_eligible:!legacy_eligible;
 wire run_selection=BRANCH_FULL_RELOAD?full_note_request:selection_event;
 wire prepare_enable=branch_run_eligible&&!full_note_request&&!start&&state==PREPARE;
 wire interval_begin=prepare_enable&&sorted&&clear_sample&&sample_tick&&run_mode==1;
 wire interval_step=branch_run_eligible&&!full_note_request&&!start&&
                    state==STRUM&&sample_tick&&run_index!=rank;
 integer k, selected_rank;
 reg [6:0] chord_selection;
 always_comb begin
  selected_rank=0;chord_selection=0;
  for(integer j=0;j<7;j=j+1) if(selected[j]&&selected_rank<4)begin
   chord_selection[j]=1;selected_rank=selected_rank+1;
  end
 end

 reg [6:0] scan_note,scan_mask,next_best_note,next_best_mask;
 reg [6:0] next_onset;
 always @* begin
  scan_note=127;scan_mask=0;next_onset=0;
  for(integer j=0;j<7;j=j+1)begin
   if(scan==j&&remaining[j])begin scan_note=snapshot_notes[j*7+:7];scan_mask[j]=1;end
   if(run_index+1==j)next_onset=order[j];
  end
  next_best_note=best_note;next_best_mask=best_mask;
  if((|scan_mask)&&(!( |best_mask)||scan_note<best_note))begin
   next_best_note=scan_note;next_best_mask=scan_mask;
  end
 end
 always @(posedge clk)begin
  triggers<=0;
  if(rst)begin
   gates<=0;triggers<=0;notes<=0;gains<=0;
   busy<=0;state<=IDLE;previous_mode<=pattern_mode;run_mode<=0;
   snapshot_selected<=0;snapshot_notes<=0;snapshot_gains<=0;remaining<=0;
   scan<=0;rank<=0;run_index<=0;best_note<=127;best_mask<=0;sorted<=0;clear_sample<=0;
   if(!BRANCH_FULL_RELOAD)begin
    interval_left<=0;for(k=0;k<7;k=k+1)order[k]<=0;
   end
   hold_left<=0;arp_age<=0;
  end else begin
   previous_mode<=pattern_mode;
   // Cancel wins over a coincident event/start, retaining the selected notes.
   if(run_blocked)begin
    gates<=0;gains<=0;busy<=0;state<=IDLE;clear_sample<=0;
   end else if(run_selection)begin
    gates<=0;gains<=0;busy<=0;state<=IDLE;
   end else if(start)begin
    gates<=0;gains<=0;clear_sample<=0;sorted<=0;scan<=0;rank<=0;run_index<=0;
    best_note<=127;best_mask<=0;run_mode<=pattern_mode;
    snapshot_selected<=selected;snapshot_notes<=selected_notes;snapshot_gains<=selected_gains;remaining<=selected;
    busy<=|selected;state<=(|selected)?PREPARE:IDLE;
   end else if(state==PREPARE)begin
    if(sample_tick)clear_sample<=1;
    if(!sorted)begin
     if(scan==6)begin
      if(!BRANCH_FULL_RELOAD)for(k=0;k<7;k=k+1)if(rank==k)order[k]<=next_best_mask;
      remaining<=remaining&~next_best_mask;
      if((remaining&~next_best_mask)==0)sorted<=1;
      else begin rank<=rank+1;scan<=0;best_note<=127;best_mask<=0;end
     end else begin scan<=scan+1;best_note<=next_best_note;best_mask<=next_best_mask;end
    end
    // A complete audio sample sees gates==0 before any new trigger pulse.
    if(sorted&&clear_sample&&sample_tick)begin
     run_index<=0;arp_age<=0;
     if(run_mode==2)begin
      gates<=0;triggers<=0;gains<=0;
      for(k=0;k<4;k=k+1)if(k<=rank)begin
       gates[k]<=1;triggers[k]<=1;
       for(integer j=0;j<7;j=j+1)if(order[k][j])begin
        notes[k*7+:7]<=snapshot_notes[j*7+:7];
        gains[k*12+:12]<=snapshot_gains[j*12+:12];
       end
      end
      state<=CHORD;hold_left<=HOLD_SAMPLES;
     end else begin
      gates<=1;triggers<=1;gains<=0;
      for(k=0;k<7;k=k+1)if(order[0][k])begin
       notes[6:0]<=snapshot_notes[k*7+:7];gains[11:0]<=snapshot_gains[k*12+:12];
      end
      if(run_mode==1)begin
       state<=STRUM;if(!BRANCH_FULL_RELOAD)interval_left<=STRUM_SAMPLES;hold_left<=(rank==0)?HOLD_SAMPLES:0;
      end else state<=ARP;
     end
    end
   end else if(sample_tick)begin
    if(state==CHORD||(state==STRUM&&run_index==rank))begin
     if(hold_left<=1)begin gates<=0;gains<=0;busy<=0;state<=IDLE;end
     else hold_left<=hold_left-1;
    end else if(state==STRUM)begin
     if(interval_left<=1)begin
      run_index<=run_index+1;gates<=gates|(4'b0001<<(run_index[1:0]+2'd1));
      triggers<=4'b0001<<(run_index[1:0]+2'd1);
      for(k=0;k<7;k=k+1)if(next_onset[k])begin
       notes[((run_index[1:0]+2'd1)&2'b11)*7+:7]<=snapshot_notes[k*7+:7];
       gains[((run_index[1:0]+2'd1)&2'b11)*12+:12]<=snapshot_gains[k*12+:12];
      end if(!BRANCH_FULL_RELOAD)interval_left<=STRUM_SAMPLES;
      if(run_index+1==rank)hold_left<=HOLD_SAMPLES;
     end else if(!BRANCH_FULL_RELOAD)interval_left<=interval_left-1;
    end else if(state==ARP)begin
     if(arp_age+1>=ARP_SAMPLES)begin
      arp_age<=0;
      if(run_index==rank)begin gates<=0;gains<=0;busy<=0;state<=IDLE;end
      else begin
       run_index<=run_index+1;gates<=4'b0001<<(run_index[1:0]+2'd1);triggers<=4'b0001<<(run_index[1:0]+2'd1);gains<=0;
       for(k=0;k<7;k=k+1)if(next_onset[k])begin
        notes[((run_index[1:0]+2'd1)&2'b11)*7+:7]<=snapshot_notes[k*7+:7];
        gains[((run_index[1:0]+2'd1)&2'b11)*12+:12]<=snapshot_gains[k*12+:12];
       end
      end
     end else begin
      arp_age<=arp_age+1;
      if(arp_age+1>=ARP_GATE)begin gates<=0;gains<=0;end
     end
    end
   end
  end
 end
 // Order RAM and interval counter use complete parallel write enables.
 // Cancellation, selection and start retain priority without passing through
 // the remaining/sorted/next-state mux before these destinations.
 generate if(BRANCH_FULL_RELOAD)begin:run_writes
  always @(posedge clk)begin
   if(rst)begin
    for(integer q=0;q<7;q=q+1)order[q]<=0;
   end else if(prepare_enable&&!sorted&&scan==6)begin
    for(integer q=0;q<7;q=q+1)if(rank==q)order[q]<=next_best_mask;
   end
  end
  always @(posedge clk)begin
   if(rst)interval_left<=0;
   else if(interval_begin)interval_left<=STRUM_SAMPLES;
   else if(interval_step)interval_left<=(interval_left<=1)?STRUM_SAMPLES:interval_left-1;
  end
 end endgenerate
 // The full indication keeps running through cancel/mode changes. Reload
 // follows decrement so overflow coincident with full_left==1 wins exactly.
 always @(posedge clk)begin
  if(rst)begin full<=0;full_left<=0;end
  else begin
   if(sample_tick&&full_left!=0)begin
    full_left<=full_left-1;
    if(full_left==1)full<=0;
   end
   if(BRANCH_FULL_RELOAD)begin
    if(branch_reload)begin full<=1;full_left<=SAMPLE_HZ;end
   end else if(cancel||pattern_mode!=previous_mode||pattern_mode==0||disconnect)begin
   end else if(selection_event)begin
    if(legacy_accept)begin end
    else begin full<=1;full_left<=SAMPLE_HZ;end
   end
  end
 end
 // Preserve mode-entry trimming above admission, independently of cancel.
 // All normal writes share the completed branch decision and original slot.
 always @(posedge clk)begin
  if(rst)begin selected<=0;selected_notes<=0;selected_gains<=0;end
  else if(BRANCH_FULL_RELOAD?chord_entry:
          (cancel||pattern_mode!=previous_mode||pattern_mode==0||disconnect))begin
   if(chord_entry)begin
    selected<=chord_selection;
    for(integer g=0;g<7;g=g+1)if(!chord_selection[g])selected_gains[g*12+:12]<=0;
   end
  end else if(BRANCH_FULL_RELOAD?branch_admit:selection_event)begin
   for(integer g=0;g<7;g=g+1)if(choice_mask[g]&&(BRANCH_FULL_RELOAD||legacy_accept))begin
    selected[g]<=!(|match_mask);
    if(!(|match_mask))selected_notes[g*7+:7]<=pitch;
    selected_gains[g*12+:12]<=(|match_mask)?12'd0:{bounded_velocity,5'd0};
   end
  end
 end
endmodule
