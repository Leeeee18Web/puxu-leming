module leading_before_pair48 #(parameter integer VOICE_COUNT=4)(
 input wire clk,rst,input wire[VOICE_COUNT-1:0]active,input wire[VOICE_COUNT*7-1:0]notes,
 input wire[VOICE_COUNT*12-1:0]gains,input wire[VOICE_COUNT*24-1:0]steps,input wire[VOICE_COUNT*16-1:0]envelopes,
 output reg[6:0]leading_note=0,output reg[10:0]leading_pitch=0,
 output reg[23:0]leading_step=0,output reg[15:0]leading_envelope=0,
 output reg leading_valid=0
);
 localparam integer LEAVES=1<<$clog2(VOICE_COUNT);
 // Lowest valid slot wins through ceil(log2(VOICE_COUNT)) mux levels.
 wire[46:0]tree[1:2*LEAVES-1];wire valid_tree[1:2*LEAVES-1];
 genvar leaf,node;
 generate for(leaf=0;leaf<LEAVES;leaf=leaf+1)begin:leaves
  if(leaf<VOICE_COUNT)begin:voice
   assign valid_tree[LEAVES+leaf]=active[leaf]&&gains[leaf*12+:12]!=0;
   assign tree[LEAVES+leaf]={notes[leaf*7+:7],steps[leaf*24+:24],envelopes[leaf*16+:16]};
  end else begin:padding
   assign valid_tree[LEAVES+leaf]=0;assign tree[LEAVES+leaf]=0;
  end
 end
 for(node=1;node<LEAVES;node=node+1)begin:branches
  assign valid_tree[node]=valid_tree[node*2]||valid_tree[node*2+1];
  assign tree[node]=valid_tree[node*2]?tree[node*2]:tree[node*2+1];
 end endgenerate
 reg[23:0]pitch_steps[0:2047] /* synthesis syn_romstyle="block_rom" */;
 initial $readmemh("src/play/p8_pitch_steps.hex",pitch_steps);
 reg[10:0]address=1024,base=0;reg[23:0]q=0,held_step=0;
 reg[6:0]held_note=0;reg[15:0]held_env=0;reg held_valid=0;
 reg[3:0]bit_index=10;reg[1:0]state=0;
 wire[10:0]accepted=q<=held_step?address:base;
 always @(posedge clk)q<=pitch_steps[address];
 always @(posedge clk)begin
  if(rst)begin state<=0;address<=1024;base<=0;bit_index<=10;
   leading_note<=0;leading_pitch<=0;leading_step<=0;leading_envelope<=0;leading_valid<=0;
   held_step<=0;held_note<=0;held_env<=0;held_valid<=0;
  end else case(state)
   0:begin held_note<=tree[1][46:40];held_step<=tree[1][39:16];held_env<=tree[1][15:0];held_valid<=valid_tree[1];
    address<=1024;base<=0;bit_index<=10;state<=1;end
   1:state<=2;
   2:begin
    base<=accepted;
    if(bit_index==0)begin
     leading_note<=held_note;leading_pitch<=accepted;leading_step<=held_step;
     leading_envelope<=held_env;leading_valid<=held_valid;state<=0;
    end else begin address<=accepted|(11'd1<<(bit_index-1'b1));bit_index<=bit_index-1'b1;state<=1;end
   end
   default:state<=0;
  endcase
 end
endmodule
