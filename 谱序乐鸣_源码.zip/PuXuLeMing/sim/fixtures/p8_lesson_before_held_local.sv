`timescale 1ns/1ps
// Follow-along grades the same accepted event stream as the live instrument.
// It never supplies notes to the audio engine. One source/channel/key press
// can grade only once until an actual release, channel clear, or disconnect.
module p8_lesson_before_held_local(
 input wire clk,rst,sample_tick,enabled,restart,
 input wire [6:0] base_note,
 input wire event_valid,input wire [31:0] event_data,input wire panic,
 output wire [6:0] target_note,
 output reg [6:0] feedback_note=127,
 output reg [1:0] feedback=0,
 output reg [5:0] position=0,
 output wire done,
 output reg [6:0] correct_count=0,
 output reg [15:0] wrong_count=0
);
 // All accepted transactions and their mode context advance together. This
 // fixed one-clock latency retains one event per clock; synchronous reset
 // flushes the input stage immediately so no pre-reset transaction reappears.
 reg sample_tick_q=0,enabled_q=0,restart_q=0,event_valid_q=0,panic_q=0;
 reg [6:0] base_note_q=60;
 reg [31:0] event_data_q=0;
 (* syn_preserve=1 *) reg [127:0] note_select_q=0;
 (* syn_preserve=1 *) reg note_on_q=0;
 wire raw_legal=!event_data[15]&&!event_data[23];
 wire raw_on=event_data[7:4]==9 && event_data[22:16]!=0;
 wire raw_off=event_data[7:4]==8 || (event_data[7:4]==9 && event_data[22:16]==0);
 wire raw_channel_clear=event_data[7:4]==11 && (event_data[14:8]==120 || event_data[14:8]==123);
 always @(posedge clk)begin
  if(rst)begin
   sample_tick_q<=0;enabled_q<=0;restart_q<=0;event_valid_q<=0;panic_q<=0;
   base_note_q<=base_note;event_data_q<=0;note_on_q<=0;
  end else begin
   sample_tick_q<=sample_tick;enabled_q<=enabled;restart_q<=restart;
   event_valid_q<=event_valid;event_data_q<=event_data;panic_q<=panic;
   base_note_q<=base_note;note_on_q<=raw_on;
  end
 end

 // A 32-row by 128-key synchronous RAM replaces the full FF bitmap.
 // Per-row validity provides exact constant-time channel/session clear without
 // resetting RAM. Forward the immediately preceding row write for a sustained
 // one-event-per-clock stream, including consecutive writes to the same channel.
 reg [127:0] key_rows[0:31] /* synthesis syn_ramstyle="block_ram" */;
 reg [127:0] row_read,forward_row;
 reg [4:0] forward_channel;
 reg forward_valid=0;
 reg [31:0] row_valid=0;
 always @(posedge clk)row_read<=key_rows[{event_data[24],event_data[3:0]}];
 // Synthesis drops this full-state inspection view; the datapath uses only the
 // synchronous row read below. Keeping the view lets simulation compare all keys.
 // synthesis translate_off
 wire [4095:0] held;
 genvar debug_channel;
 generate for(debug_channel=0;debug_channel<32;debug_channel=debug_channel+1)begin:debug_rows
  assign held[debug_channel*128+:128]=row_valid[debug_channel]?key_rows[debug_channel]:128'd0;
 end endgenerate
 // synthesis translate_on
 reg [6:0] previous_base=60;
 reg previous_enabled=0;
 reg [13:0] feedback_ticks=0;
 wire src=event_data_q[24];
 wire [7:0] status=event_data_q[7:0];
 wire [6:0] note=event_data_q[14:8],velocity=event_data_q[22:16];
 wire legal_data=!event_data_q[15]&&!event_data_q[23];
 wire [11:0] key_index={src,status[3:0],note};
 wire [4:0] channel_index={src,status[3:0]};
 wire new_session=restart_q || !previous_enabled || base_note_q!=previous_base;
 wire [5:0] current_position=new_session?6'd0:position;
 wire note_on=note_on_q;
 wire note_off=status[7:4]==8 || (status[7:4]==9 && velocity==0);
 wire channel_clear=status[7:4]==11 && (note==120 || note==123);
 wire [127:0] note_select;
 genvar n;
 generate for(n=0;n<128;n=n+1)begin:pitch_decode
  always @(posedge clk)begin
   if(rst)note_select_q[n]<=0;
   else note_select_q[n]<=event_data[14:8]==n;
  end
  assign note_select[n]=note_select_q[n];
 end endgenerate
 wire [127:0] latest_row=forward_valid&&forward_channel==channel_index?forward_row:row_read;
 wire [127:0] current_row=row_valid[channel_index]?latest_row:128'd0;
 wire held_note=current_row[note];
 wire write_note=event_valid_q&&legal_data&&status!=8'hff&&(note_on||note_off);
 wire write_row=write_note&&enabled_q&&!panic_q&&!rst;
 wire [127:0] row_base=new_session?128'd0:current_row;
 wire [127:0] next_row=(row_base&~note_select)|({128{note_on}}&note_select);
 always @(posedge clk)begin
  forward_valid<=write_row;
  if(write_row)begin
   key_rows[channel_index]<=next_row;
   forward_row<=next_row;forward_channel<=channel_index;
  end
  if(rst||!enabled_q||panic_q)row_valid<=0;
  else begin
   if(new_session)row_valid<=0;
   if(event_valid_q)begin
    if(status==8'hff)row_valid[15:0]<=0;
    else if(legal_data&&channel_clear)row_valid[channel_index]<=0;
   end
   if(write_row)row_valid[channel_index]<=1;
  end
 end
 function automatic [3:0] song_offset(input [5:0] p);
  begin
   case(p)
    0,1,13,28,29,41:song_offset=0;
    2,3,6,14,15,21,22,30,31,34:song_offset=7;
    4,5,32,33:song_offset=9;
    7,8,16,17,23,24,35,36:song_offset=5;
    9,10,18,19,25,26,37,38:song_offset=4;
    11,12,20,27,39,40:song_offset=2;
    default:song_offset=0;
   endcase
  end
 endfunction
 wire [7:0] target_sum={1'b0,base_note_q}+{4'd0,song_offset(position)};
 wire [7:0] current_target={1'b0,base_note_q}+{4'd0,song_offset(current_position)};
 assign done=position==42;
 assign target_note=done||target_sum>127?7'd127:target_sum[6:0];
 always @(posedge clk)begin
  previous_base<=base_note_q;
  previous_enabled<=enabled_q;
  if(rst || !enabled_q)begin
   position<=0;feedback<=0;feedback_note<=127;
   correct_count<=0;wrong_count<=0;feedback_ticks<=0;
  end else begin
   if(new_session)begin
    position<=0;feedback<=0;feedback_note<=127;
    correct_count<=0;wrong_count<=0;feedback_ticks<=0;
   end else if(sample_tick_q && feedback_ticks!=0)begin
    feedback_ticks<=feedback_ticks-1'b1;
    if(feedback_ticks==1)begin feedback<=0;feedback_note<=127;end
   end
   if(panic_q)begin
    feedback<=0;feedback_note<=127;feedback_ticks<=0;
   end else if(event_valid_q)begin
    if(status!=8'hff && legal_data)begin
     if(note_on)begin
      if((new_session || !held_note) && current_position<42)begin
       feedback_note<=note;feedback_ticks<=14'd14648;
       if(current_target<=127 && note==current_target[6:0])begin
        feedback<=1;position<=current_position+1'b1;
        correct_count<=new_session?7'd1:correct_count+1'b1;
       end else begin
        feedback<=2;
        if(new_session)wrong_count<=1;
        else if(wrong_count!=16'hffff)wrong_count<=wrong_count+1'b1;
       end
      end
     end
    end
   end
  end
 end
endmodule
