// Single-reed nonlinear pressure/reflection model, Q18 pressure. A half-period
// air column plus weak full-period tapered-bore branch and radiation filtering.
// Generic design coefficients; no measured saxophone claim. Shared 24x18 multiply.
module ref_r1_phys_reed_voice(input wire clk,rst,render_tick,gate,trigger,
 input wire [23:0] step,input wire [11:0] gain,
 output reg signed [15:0] sample,output reg [15:0] envelope,
 output reg active,busy,deadline_error);
 reg signed [19:0] bore[0:4095]; // pressure Q18, no reset port; valid-count masks stale data
 reg [11:0] ram_address;
 reg signed [19:0] ram_value;
 reg [11:0] wp,delay_i,full_i;
 reg [12:0] fill;
 reg [11:0] fraction,full_fraction;
 reg signed [19:0] a,b,c,d;
 reg signed [23:0] half_return,full_return,previous_half,pressure_diff,flow;
 reg signed [23:0] ma;
 reg signed [17:0] mb,response;
 wire signed [41:0] mp=ma*mb;
 reg signed [31:0] radiation_dc;
 reg signed [23:0] radiation_lp;
 reg [23:0] mouth;
 reg held;
 reg [11:0] velocity;
 reg [1:0] divider_phase,rate;
 reg [23:0] divisor;
 reg [35:0] dividend,quotient;
 reg [24:0] remainder;
 reg [5:0] bits_left;
 reg [25:0] delay_q,full_q;
 reg [6:0] state;
 reg [22:0] noise;
 wire [24:0] trial={remainder[23:0],dividend[35]};
 wire [23:0] mouth_target=24'd204472+({12'd0,velocity}<<2)+{12'd0,velocity};
 function automatic signed [19:0] pressure_limit(input signed [42:0] v);
 begin if(v>43'sd250000)pressure_limit=20'sd250000;
 else if(v< -43'sd250000)pressure_limit=-20'sd250000;
 else pressure_limit=v[19:0];end endfunction
 function automatic signed [15:0] audio_limit(input signed [41:0] v);
 begin if(v>42'sd7000)audio_limit=7000;
 else if(v< -42'sd7000)audio_limit=-7000;else audio_limit=v[15:0];end endfunction
 // Exactly one synchronous RAM read port, time-multiplexed over the four taps.
 always @(*) begin
  case(state)
   4: ram_address=wp-delay_i;
   5: ram_address=wp-delay_i-12'd1;
   6: ram_address=wp-full_i;
   7: ram_address=wp-full_i-12'd1;
   default: ram_address=wp;
  endcase
 end
 always @(posedge clk) ram_value<=bore[ram_address];
 always @(posedge clk)begin
  if(rst || gain==0)begin
   state<=0;sample<=0;envelope<=0;active<=0;busy<=0;deadline_error<=0;
   wp<=0;fill<=0;delay_i<=2;full_i<=5;fraction<=0;full_fraction<=0;
   a<=0;b<=0;c<=0;d<=0;half_return<=0;full_return<=0;previous_half<=0;
   pressure_diff<=0;flow<=0;ma<=0;mb<=0;response<=0;
   radiation_dc<=0;radiation_lp<=0;mouth<=0;held<=0;velocity<=0;
   divisor<=1;dividend<=0;quotient<=0;remainder<=0;bits_left<=0;
   delay_q<=0;full_q<=0;noise<=23'h524a67;divider_phase<=0;rate<=0;
  end else begin
   if(render_tick && busy)deadline_error<=1;
   case(state)
   0 : if(render_tick)begin
    divider_phase<=divider_phase+1'b1;
    if(trigger || (active && ((step>=24'd32768) ||
      ((step>=24'd8192) && !divider_phase[0]) || divider_phase==0)))begin
     busy<=1;active<=1;held<=gate;velocity<=gain;
     rate<=step<24'd8192 ? 2 : (step<24'd32768 ? 1 : 0);
     divisor<=step<24'd32 ? 24'd32 : step;
     // 2^35/step is half-period Q12; half/quarter rate divide numerator again.
     if(step<24'd8192)dividend<=36'h200000000;
     else if(step<24'd32768)dividend<=36'h400000000;
     else dividend<=36'h800000000;
     quotient<=0;remainder<=0;bits_left<=36;state<=1;
     if(trigger)begin
      wp<=0;fill<=0;mouth<=0;previous_half<=0;radiation_dc<=0;
      radiation_lp<=0;sample<=0;noise<=23'h524a67;divider_phase<=0;
     end
    end else if(!active)begin sample<=0;envelope<=0;end
   end
   1 : begin
    dividend<={dividend[34:0],1'b0};
    if(trial>={1'b0,divisor})begin remainder<=trial-{1'b0,divisor};quotient<={quotient[34:0],1'b1};end
    else begin remainder<=trial;quotient<={quotient[34:0],1'b0};end
    bits_left<=bits_left-1'b1;
    if(bits_left==1)state<=2;
   end
   2 : begin
    if(quotient<36'd10240)delay_q<=26'd8192;
    else if(quotient>36'd8386560)delay_q<=26'd8384512;
    else delay_q<=quotient[25:0]-26'd2048;
    state<=3;
   end
   3 : begin
    delay_i<=delay_q[23:12];fraction<=delay_q[11:0];
    full_q<=(delay_q<<1)+26'd4096;
    if(held)begin
     if(mouth<mouth_target)mouth<=mouth+((mouth_target-mouth)>>(8-rate))+1'b1;
     else mouth<=mouth-((mouth-mouth_target)>>(8-rate));
    end else if(mouth>32)mouth<=mouth-(mouth>>(11-rate))-1'b1;
    else begin mouth<=0;active<=0;end
    noise<={noise[21:0],noise[22]^noise[17]};state<=4;
   end
   4 : begin
    full_i<=full_q[23:12];full_fraction<=full_q[11:0];
    state<=5;
   end
   5:begin a<=fill>={1'b0,delay_i} ? ram_value : 20'sd0;state<=6;end
   6:begin b<=fill>{1'b0,delay_i} ? ram_value : 20'sd0;state<=7;end
   7:begin c<=fill>={1'b0,full_i} ? ram_value : 20'sd0;state<=8;end
   8:begin d<=fill>{1'b0,full_i} ? ram_value : 20'sd0;ma<=$signed(b)-$signed(a);mb<=$signed({6'd0,fraction});state<=9;end
   9 : begin half_return<=$signed(a)+(mp>>>12);state<=10;end
   10 : begin ma<=$signed(d)-$signed(c);mb<=$signed({6'd0,full_fraction});state<=11;end
   11 : begin full_return<=$signed(c)+(mp>>>12);state<=12;end
   12 : begin
    // Negative open-end reflection; full-period branch is a small tapered-bore correction.
    pressure_diff<=-(($signed(half_return)+$signed(previous_half))>>>1)
     +(($signed(half_return)+$signed(previous_half))>>>5)
     +(($signed(half_return)+$signed(previous_half))>>>6)
     +($signed(full_return)>>>4)-$signed({1'b0,mouth})
     +($signed(noise[15:0])>>>7);
    previous_half<=half_return;state<=13;
   end
   13 : begin ma<=pressure_diff;mb<=18'sd19661;state<=14;end
   14 : begin
    // Memoryless quasi-static reed opening vs pressure, limited by reed closure.
    if((42'sd45875-(mp>>>18))>65536)response<=18'sd65536;
    else if((42'sd45875-(mp>>>18))< -65536)response<=-18'sd65536;
    else response<=42'sd45875-(mp>>>18);
    state<=15;
   end
   15 : begin ma<=pressure_diff;mb<=response;state<=16;end
   16 : begin
    flow<=$signed({1'b0,mouth})+(mp>>>16);state<=17;
   end
   17 : begin
    bore[wp]<=pressure_limit(flow);wp<=wp+1'b1;
    if(fill<4096)fill<=fill+1'b1;
    // Bell radiation DC removal followed by a mild mouth/bell low-pass.
    radiation_dc<=radiation_dc+((($signed(flow)<<<6)-radiation_dc)>>>10);
    radiation_lp<=radiation_lp+(($signed(flow)-(radiation_dc>>>6)-radiation_lp)>>>1);
    envelope<=mouth[17:2];state<=18;
   end
   18 : begin ma<=radiation_lp;mb<=$signed({6'd0,velocity});state<=19;end
   19 : begin sample<=active ? audio_limit(mp>>>18) : 16'sd0;busy<=0;state<=0;end
   default : begin state<=0;busy<=0;deadline_error<=1;end
   endcase
  end
 end
endmodule

