// Generic tine / tonebar electric piano. All coefficients are mathematical design
// choices, not measurements of an instrument. One time-multiplexed 24x18 multiplier.
module ref_r1_phys_ep_voice(input wire clk,rst,render_tick,gate,trigger,
 input wire [23:0] step,input wire [11:0] gain,
 output reg signed [15:0] sample,output reg [15:0] envelope,
 output reg active,busy,deadline_error);
`include "phys_er_ep_coeff.vh"
 reg [6:0] state;
 reg [1:0] mode;
 reg [23:0] pitch,phase_mode;
 reg [11:0] velocity;
 reg struck,held;
 reg signed [23:0] x[0:2],v[0:2]; // displacement and velocity Q8
 reg signed [17:0] k[0:2],base_k;
 reg signed [23:0] ma;
 reg signed [17:0] mb;
 wire signed [41:0] mp=ma*mb;
 reg signed [23:0] vn,pickup;
 reg signed [31:0] dc;
 reg signed [24:0] shaped;
 reg [23:0] env;
 reg signed [23:0] hammer; // finite contact-force tail, approximately 1 ms
 wire [4:0] loss = held  ?  ((mode==0) ? 5'd17 : (mode==1) ? 5'd15 : 5'd12) : 5'd11;
 integer j;
 function automatic signed [23:0] sat24(input signed [42:0] a);
 begin if(a>43'sd8388607) sat24=24'sd8388607;
 else if(a< -43'sd8388607) sat24=-24'sd8388607; else sat24=a[23:0]; end endfunction
 function automatic signed [15:0] sat16(input signed [31:0] a);
 begin if(a>7000) sat16=16'sd7000; else if(a< -7000) sat16=-16'sd7000; else sat16=a[15:0]; end endfunction
 always @(posedge clk) begin
  if(rst || gain==0) begin
   state<=0; mode<=0; pitch<=0; phase_mode<=0; velocity<=0;
   struck<=0; held<=0; sample<=0; envelope<=0; active<=0;
   busy<=0; deadline_error<=0; ma<=0; mb<=0; vn<=0; pickup<=0;
   shaped<=0; dc<=0; env<=0; hammer<=0; base_k<=0;
   for(j=0;j<3;j=j+1) begin x[j]<=0;v[j]<=0;k[j]<=0;end
  end else begin
   if(render_tick && busy) deadline_error<=1;
   case(state)
   0 :  if(render_tick) begin
    if(trigger || active) begin
     busy<=1; mode<=0; pitch<=step<24'd32 ? 24'd32 : (step>24'h700000 ? 24'h700000 : step);
     struck<=trigger; held<=gate; velocity<=gain; state<=1;
     if(trigger) begin
      env<=24'hffff00; active<=1; dc<=0; sample<=0;
      hammer<=$signed({1'b0,gain,5'b0});
      for(j=0;j<3;j=j+1)begin x[j]<=0;v[j]<=0;end
     end else begin
      env<=env-(env>>(gate ? 17 : 10))-1'b1;
      if(env<24'd2048) begin active<=0;env<=0;sample<=0;end
     end
    end else begin sample<=0;envelope<=0;end
   end
   1 :  begin
    if(mode==0)phase_mode<=pitch;
    else if(mode==1)phase_mode<=pitch+(pitch>>9);
    else phase_mode<=(pitch>24'h180000) ? 24'h600000 : ((pitch<<2)+(pitch>>6));
    state<=2;
   end
   2 :  begin
    base_k<=er_ep_k(phase_mode[23:15]);
    ma<=$signed({1'b0,er_ep_k(phase_mode[23:15]+1'b1)})-$signed({1'b0,er_ep_k(phase_mode[23:15])});
    mb<=$signed({3'b000,phase_mode[14:0]});state<=3;
   end
   3 :  begin k[mode]<=base_k+(mp>>>15);state<=4;end
   4 :  begin
    if(struck)begin ma<=$signed({1'b0,velocity,9'b0}) >>> ((mode==0) ? 0 : (mode==1) ? 2 : 4);mb<=18'sd65536;state<=5;end
    else begin ma<=x[mode];mb<=k[mode];state<=6;end
   end
   5 :  begin vn<=sat24(mp>>>16);state<=7;
    // Hammer impulse initializes all three normalized modal velocities.
   end
   6 :  begin
    vn<=sat24($signed(v[mode])-(mp>>>16)-($signed(v[mode])>>>loss)
       +((mode==0) ? (($signed(x[1])-$signed(x[0]))>>>22) : 
         (mode==1) ? (($signed(x[0])-$signed(x[1]))>>>22) : 24'sd0)
       +((mode==0) ? (hammer>>>12) : 24'sd0));state<=7;
   end
   7 : begin ma<=vn;mb<=k[mode];state<=8;end
   8 : begin
    x[mode]<=sat24($signed(x[mode])+(mp>>>16)-($signed(x[mode])>>>loss));
    v[mode]<=vn;
    if(mode==2)state<=10;else begin mode<=mode+1'b1;state<=1;end
   end
   10 : begin
    pickup<=($signed(x[0])>>>9)+($signed(x[1])>>>10)+($signed(x[2])>>>10);
    hammer<=hammer-(hammer>>>5)-1'b1;
    if(hammer<24'd64)hammer<=0;
    envelope<=env[23:8];state<=11;
   end
   11 : begin ma<=pickup;mb<=pickup[17:0];state<=12;end
   12 : begin shaped<=pickup+(mp>>>15);state<=13;end
   13 : begin
    dc<=dc+((($signed(shaped)<<<8)-dc)>>>9);
    sample<=active ? sat16($signed(shaped)-(dc>>>8)) : 16'sd0;
    state<=0;busy<=0;
   end
   default : begin state<=0;busy<=0;deadline_error<=1;end
   endcase
  end
 end
endmodule



