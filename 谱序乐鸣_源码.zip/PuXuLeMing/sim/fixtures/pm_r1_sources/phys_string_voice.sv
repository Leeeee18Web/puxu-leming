`timescale 1ns/1ps
// Generic physical strings; engineering coefficients, not measured instruments.
module ref_r1_phys_string_voice(
 input wire clk,rst,render_tick,gate,trigger,input wire[23:0]step,
 input wire[11:0]gain,input wire[2:0]timbre,
 output reg signed[15:0]sample=0,output reg[15:0]envelope=0,
 output reg active=0,output wire busy,output reg deadline_error=0
);
 reg[5:0]state=0,bit_count=0;
 reg[34:0]dividend=0,quotient=0;reg[24:0]remainder=0;
 reg[23:0]divisor=1,step_snapshot=1;reg half_rate=0,half_phase=0;
 reg[23:0]period_q10=102400;reg launch=0,rebuild=0,init_pending=0,initializing=0;reg[2:0]kind=1;
 wire signed[17:0]s0,s1,s2;wire b0,b1,b2,e0,e1,e2;
 wire[15:0]env0,env1,env2;
 wire local_reset=rst||(gain==0);
 // Dedicated regional reset drivers spend FFs to keep three large RAM/control
 // cones off the same high-fanout net. Keep both FFs and their distinct nets.
 // The voice itself still clears immediately; rebuild arrives >35 clocks
 // after a trigger, allowing the one-clock line reset distribution to settle.
 (* syn_preserve=1 *) reg reset_a=1;
 (* syn_preserve=1 *) reg reset_b=1;
 (* syn_preserve=1 *) reg reset_c=1;
 wire line_reset_a /* synthesis syn_keep=1 */;
 wire line_reset_b /* synthesis syn_keep=1 */;
 wire line_reset_c /* synthesis syn_keep=1 */;
 assign line_reset_a=reset_a;assign line_reset_b=reset_b;assign line_reset_c=reset_c;
 always @(posedge clk)begin reset_a<=local_reset;reset_b<=local_reset;reset_c<=local_reset;end
 // Local mode drivers trade a few FFs for lower fanout at each string.
 (* syn_preserve=1 *) reg half_rate_a=0;
 (* syn_preserve=1 *) reg half_rate_b=0;
 (* syn_preserve=1 *) reg half_rate_c=0;
 (* syn_preserve=1 *) reg [2:0] kind_a=1;
 (* syn_preserve=1 *) reg [2:0] kind_b=1;
 (* syn_preserve=1 *) reg [2:0] kind_c=1;
 wire mode_rate_a /* synthesis syn_keep=1 */;
 wire mode_rate_b /* synthesis syn_keep=1 */;
 wire mode_rate_c /* synthesis syn_keep=1 */;
 wire [2:0] mode_kind_a /* synthesis syn_keep=1 */;
 wire [2:0] mode_kind_b /* synthesis syn_keep=1 */;
 wire [2:0] mode_kind_c /* synthesis syn_keep=1 */;
 assign mode_rate_a=half_rate_a;assign mode_rate_b=half_rate_b;assign mode_rate_c=half_rate_c;
 assign mode_kind_a=kind_a;assign mode_kind_b=kind_b;assign mode_kind_c=kind_c;
 wire[24:0]trial={remainder[23:0],dividend[34]};
 wire[23:0]safe_step=step==0?24'd1:step;
 wire[23:0]detune=period_q10>>11;
 always @(posedge clk)if(!local_reset&&trigger)begin
  half_rate_a<=safe_step<4608;half_rate_b<=safe_step<4608;half_rate_c<=safe_step<4608;
  kind_a<=timbre;kind_b<=timbre;kind_c<=timbre;
 end
 ref_r1_phys_strings_line #(.INDEX(0)) a(clk,line_reset_a,launch,rebuild,gate,mode_kind_a,gain,step_snapshot,mode_rate_a,period_q10,s0,env0,b0,e0);
 ref_r1_phys_strings_line #(.INDEX(1)) b(clk,line_reset_b,launch,rebuild,gate,mode_kind_b,gain,step_snapshot,mode_rate_b,period_q10+detune,s1,env1,b1,e1);
 ref_r1_phys_strings_line #(.INDEX(2)) c(clk,line_reset_c,launch,rebuild,gate,mode_kind_c,gain,step_snapshot,mode_rate_c,period_q10-detune,s2,env2,b2,e2);
 assign busy=(state!=0)||b0||b1||b2||init_pending;
 reg signed[20:0]mixed=0,previous_mix=0;
 reg signed[33:0]scaled=0;
 // Stable coupled-integrator body modes. Q8 keeps sub-PCM motion.
 reg signed[31:0]body_v0=0,body_x0=0,body_v1=0,body_x1=0,dc=0;
 reg signed[24:0]out_q8=0;
 function automatic signed[15:0]sat16(input signed[33:0]x);
 begin if(x>32767)sat16=32767;else if(x< -32768)sat16=-32768;else sat16=x[15:0];end endfunction
 always @(posedge clk)begin
  launch<=0;rebuild<=0;
  if(local_reset)begin
   state<=0;sample<=0;envelope<=0;active<=0;init_pending<=0;initializing<=0;half_phase<=0;
   body_v0<=0;body_x0<=0;body_v1<=0;body_x1<=0;dc<=0;previous_mix<=0;deadline_error<=0;
  end else if(trigger)begin
   // Half rate only for subaudible trigger pitches (<13.42 Hz), with margin
   // for the entire 0.667..1.498 knob excursion during this same note.
   kind<=timbre;step_snapshot<=safe_step;half_rate<=safe_step<4608;
   divisor<=safe_step<4608?(safe_step<<1):safe_step;
   dividend<=35'h400000000;quotient<=0;remainder<=0;bit_count<=35;
   state<=1;init_pending<=1;initializing<=1;sample<=0;envelope<=0;active<=1;half_phase<=0;
   body_v0<=0;body_x0<=0;body_v1<=0;body_x1<=0;dc<=0;previous_mix<=0;
  end else case(state)
   0:if(render_tick&&active&&!b0&&!b1&&!b2)begin
    step_snapshot<=safe_step;divisor<=half_rate?(safe_step<<1):safe_step;
    dividend<=35'h400000000;quotient<=0;remainder<=0;bit_count<=35;state<=1;
   end
   1:begin
    dividend<={dividend[33:0],1'b0};
    if(trial>={1'b0,divisor})begin remainder<=trial-{1'b0,divisor};quotient<={quotient[33:0],1'b1};end
    else begin remainder<=trial;quotient<={quotient[33:0],1'b0};end
    bit_count<=bit_count-1'b1;if(bit_count==1)state<=2;
   end
   2:begin
    if(quotient>35'd8385536)period_q10<=24'd8385536;
    else if(quotient<35'd2304)period_q10<=24'd2304;
    else period_q10<=quotient[23:0];state<=3;
   end
   3:begin
    half_phase<=~half_phase;
    if(init_pending)begin rebuild<=1;init_pending<=0;state<=4;end
    else if(!half_rate||half_phase)begin launch<=1;state<=4;end
    else state<=10;
   end
   4:state<=5;
   5:if(!b0&&!b1&&!b2)state<=10;
   10:begin
    mixed<=kind==2?($signed(s0)+($signed(s1)>>>1)):($signed(s0)+$signed(s1)+$signed(s2));state<=11;
   end
   11:begin
    // Bridge velocity excites body; no permanent DC driving force.
    body_v0<=body_v0-(body_v0>>>7)-(kind==2?(body_x0>>>12):(body_x0>>>10))+
                 (($signed(mixed)-$signed(previous_mix))<<<4);
    body_v1<=body_v1-(body_v1>>>6)-(kind==2?(body_x1>>>9):(body_x1>>>8))+
                 (($signed(mixed)-$signed(previous_mix))<<<3);
    body_x0<=body_x0+body_v0;body_x1<=body_x1+body_v1;previous_mix<=mixed;state<=12;
   end
   12:begin out_q8<=($signed(mixed)<<<5)+(body_x0>>>6)+(body_x1>>>6);state<=13;end
   13:begin dc<=dc+(($signed(out_q8)-dc)>>>10);state<=14;end
   14:begin scaled<=(($signed(out_q8)-dc)>>>8)*$signed({1'b0,gain});state<=15;end
   15:begin sample<=env0==0?16'sd0:sat16(scaled>>>12);envelope<=env0;active<=env0!=0;initializing<=0;state<=0;end
   default:state<=0;
  endcase
  if(!local_reset&&render_tick&&state!=0&&!initializing)deadline_error<=1;
  if(!local_reset&&!line_reset_a&&!line_reset_b&&!line_reset_c&&(e0||e1||e2))deadline_error<=1;
 end
endmodule
