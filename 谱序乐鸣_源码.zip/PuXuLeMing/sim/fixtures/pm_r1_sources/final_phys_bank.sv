`timescale 1ns/1ps
// Four existing ownership slots, each with its independently captured timbre.
// Disabled physical services are locally reset, never selected into the mix.
module ref_r1_final_phys_bank(
 input wire clk,rst,render_tick,input wire[3:0]gates,triggers,
 input wire[95:0]steps,input wire[47:0]gains,input wire[11:0]timbres,
 output wire[63:0]samples,envelopes,output wire[3:0]active,
 output wire busy,deadline_error
);
 wire[3:0]busy_slots,error_slots;
 // Fixed acoustic-piano voicing: modest bass lift, continuously tapering
 // from 4x at <=131Hz to 3x at >=513Hz. No automatic gain/tail normalization.
 // A symmetric soft_magnitude knee keeps four coherent grand voices below full scale.
 function automatic signed[15:0]grand_knee(input signed[19:0]x);
  reg signed[20:0]magnitude,soft_magnitude;
  begin
   magnitude=x<0?-$signed({x[19],x}):$signed({x[19],x});
   if(magnitude<=6000)soft_magnitude=magnitude;
   else if(magnitude<12000)soft_magnitude=6000+((magnitude-6000)>>>2);
   else soft_magnitude=7500;
   grand_knee=x<0?-$signed(soft_magnitude):$signed(soft_magnitude);
  end
 endfunction
 genvar i;
 generate for(i=0;i<4;i=i+1)begin:slot
  wire[2:0]tone=timbres[i*3+:3];wire[11:0]gain=gains[i*12+:12];
  wire hard_mute=gain==0;wire[23:0]step=steps[i*24+:24];
  wire is_ep=tone==0,is_string=tone==1||tone==2,is_reed=tone==3;
  reg previous_gate=0;reg[2:0]previous_tone=0;
  always @(posedge clk)begin
   if(rst||hard_mute)begin previous_gate<=0;previous_tone<=0;end
   else if(render_tick)begin previous_gate<=gates[i];previous_tone<=tone;end
  end
  wire effective_trigger=render_tick&&(triggers[i]||(gates[i]&&(!previous_gate||previous_tone!=tone)));
  wire signed[15:0]ep_sample,string_sample,reed_sample;
  wire[10:0]grand_balance=step<=24'd45056 ? 11'd1024 : step>=24'd176128 ? 11'd768 :
      11'd1024-((step-24'd45056)>>9);
  // All voicing stages settle long before the next 1024-clock DAC frame.
  // Register coefficient, product, nonlinear output and final selection so
  // the acoustic voicing never chains into the existing crossfade/mixer.
  reg[10:0]grand_balance_q=0;
  reg signed[27:0]grand_product=0;
  wire signed[19:0]grand_scaled=grand_product>>>8;
  reg signed[15:0]grand_voiced=0,sample_q=0;
  wire signed[15:0]voiced_strings=tone==1?grand_voiced:string_sample;
  wire[15:0]ep_env,string_env,reed_env;
  wire ep_active,string_active,reed_active,ep_busy,string_busy,reed_busy,ep_error,string_error,reed_error;
  ref_r1_phys_ep_voice ep(.clk(clk),.rst(rst||hard_mute||!is_ep),.render_tick(render_tick),
   .gate(gates[i]),.trigger(effective_trigger&&is_ep),.step(step),.gain(gain),
   .sample(ep_sample),.envelope(ep_env),.active(ep_active),.busy(ep_busy),.deadline_error(ep_error));
  ref_r1_phys_string_voice strings(.clk(clk),.rst(rst||hard_mute||!is_string),.render_tick(render_tick),
   .gate(gates[i]),.trigger(effective_trigger&&is_string),.step(step),.gain(gain),.timbre(tone),
   .sample(string_sample),.envelope(string_env),.active(string_active),.busy(string_busy),.deadline_error(string_error));
  ref_r1_phys_reed_voice reed(.clk(clk),.rst(rst||hard_mute||!is_reed),.render_tick(render_tick),
   .gate(gates[i]),.trigger(effective_trigger&&is_reed),.step(step),.gain(gain),
   .sample(reed_sample),.envelope(reed_env),.active(reed_active),.busy(reed_busy),.deadline_error(reed_error));
  always @(posedge clk)begin
   if(rst||hard_mute)begin grand_balance_q<=0;grand_product<=0;grand_voiced<=0;sample_q<=0;end
   else begin
    grand_balance_q<=grand_balance;
    grand_product<=$signed(string_sample)*$signed({1'b0,grand_balance_q});
    grand_voiced<=grand_knee(grand_scaled);
    sample_q<=is_ep?ep_sample:is_string?voiced_strings:is_reed?reed_sample:16'd0;
   end
  end
  assign samples[i*16+:16]=hard_mute?16'd0:sample_q;
  assign envelopes[i*16+:16]=hard_mute?16'd0:is_ep?ep_env:is_string?string_env:is_reed?reed_env:16'd0;
  assign active[i]=!hard_mute&&((is_ep&&ep_active)||(is_string&&string_active)||(is_reed&&reed_active));
  assign busy_slots[i]=(is_ep&&ep_busy)||(is_string&&string_busy)||(is_reed&&reed_busy);
  assign error_slots[i]=(is_ep&&ep_error)||(is_string&&string_error)||(is_reed&&reed_error);
 end endgenerate
 assign busy=|busy_slots;assign deadline_error=|error_slots;
endmodule
