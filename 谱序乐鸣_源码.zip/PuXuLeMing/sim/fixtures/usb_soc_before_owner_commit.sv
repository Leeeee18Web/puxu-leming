// Dedicated live player SoC: copied verified CPU/USB bus path, no SD/file services.
module usb_soc_before_owner_commit #(parameter TIMER_TICKS=48000,LOCAL_PHY_RESET=0)(input clk,resetn,input phy_resetn,input uart_rx,output uart_tx,inout usb_dm,usb_dp,
 output reg[31:0]debug_status,debug_xy,debug_raw,debug_vidpid,debug_meta,
 output reg[31:0]debug_valid_reports=0,output reg debug_toggle,
 output reg[31:0]midi_data=0,output reg midi_request=0,input midi_ack,
 output reg[31:0]play_status=0,
 // USB48-domain application transport. Names describe direction at SoC:
 // rx is firmware->application, tx is application->firmware.
 output [7:0]wifi_rx_data,output wifi_rx_valid,input wifi_rx_ready,
 input [7:0]wifi_tx_data,input wifi_tx_valid,output wifi_tx_ready,
 output [767:0]link_diagnostics,output reg[255:0]ptest_debug=0);
wire        ibus_cmd_valid;
reg         ibus_cmd_ready;
wire [31:0] ibus_cmd_pc;
reg         ibus_rsp_ready;

// A single registered command slot cuts BOTH payload and backpressure paths.
// No fall-through and no same-cycle refill: CPU acceptance depends only on
// slot occupancy, never on the ALU address or UART/USB combinational ready.
// This is the DBusSimple half-pipe handshake: one extra cycle, <=1 cmd/2 cycles.
wire        cpu_dbus_valid,cpu_dbus_ready,cpu_dbus_wr;
wire [31:0] cpu_dbus_a,cpu_dbus_data;
wire [1:0]  cpu_dbus_size;
reg         dbus_pending=0;
wire        dbus_cmd_valid = dbus_pending && resetn;
reg         dbus_cmd_ready;
reg         dbus_cmd_wr=0;
reg [31:0]  dbus_cmd_a=0;
reg [31:0]  dbus_cmd_data=0;
reg [1:0]   dbus_cmd_size=0;
reg         dbus_rsp_ready;
assign cpu_dbus_ready = resetn && !dbus_pending;
always @(posedge clk)begin
    if(!resetn)dbus_pending<=0;
    else if(!dbus_pending)begin
        if(cpu_dbus_valid)begin
            dbus_pending<=1;
            dbus_cmd_wr<=cpu_dbus_wr;dbus_cmd_a<=cpu_dbus_a;
            dbus_cmd_data<=cpu_dbus_data;dbus_cmd_size<=cpu_dbus_size;
        end
    end else if(dbus_cmd_ready)dbus_pending<=0;
end

reg [223:0] ptest_shadow=0;
always @(posedge clk)begin
 if(!resetn)begin ptest_shadow<=0;ptest_debug<=0;end
 else if(dbus_cmd_valid&&dbus_cmd_ready&&dbus_cmd_wr)begin
  case(dbus_cmd_a)
   32'h02000230:ptest_shadow[223:192]<=dbus_cmd_data;
   32'h02000234:ptest_shadow[191:160]<=dbus_cmd_data;
   32'h02000238:ptest_shadow[159:128]<=dbus_cmd_data;
   32'h0200023c:ptest_shadow[127:96]<=dbus_cmd_data;
   32'h02000240:ptest_shadow[95:64]<=dbus_cmd_data;
   32'h02000244:ptest_shadow[63:32]<=dbus_cmd_data;
   32'h02000248:ptest_shadow[31:0]<=dbus_cmd_data;
   32'h0200024c:ptest_debug<={ptest_shadow,dbus_cmd_data};
   default:;
  endcase
 end
end

reg [31:0] time_reg=0, cycle_reg=0;
reg[5:0]usb_restart_cycles=0;reg[31:0]usb_restarts=0;reg usb_software_reset=0;
wire usb_restart_commit=dbus_cmd_valid&&dbus_cmd_ready&&dbus_cmd_wr&&dbus_cmd_a==32'h0200022c&&dbus_cmd_data[0];
wire usb_host_resetn=resetn&&!usb_software_reset;
 // Identical last-stage reset timing; the PHY has its own low-fanout cone.
 (* syn_keep=1 *)wire usb_phy_local_resetn=(LOCAL_PHY_RESET?phy_resetn:resetn)&&!usb_software_reset;
always @(posedge clk)begin
 if(!resetn)begin usb_restart_cycles<=0;usb_restarts<=0;usb_software_reset<=0;end
 else if(usb_restart_commit)begin usb_restart_cycles<=32;usb_restarts<=usb_restarts+1'b1;usb_software_reset<=1;end
 else if(usb_restart_cycles!=0)begin
  usb_restart_cycles<=usb_restart_cycles-1'b1;
  if(usb_restart_cycles==1)usb_software_reset<=0;
 end
end

initial begin debug_status=0;debug_xy=0;debug_raw=0;debug_vidpid=0;debug_meta=0;debug_toggle=0;end
// 32KB RAM -------------------------------------------------------------------------------
localparam ROM_FILE = "src/usb_host/firmware_low.hex";
reg [31:0] ram [0:8191];reg[31:0]ram_extra[0:2047];
initial begin
    $readmemh(ROM_FILE,ram);
    $readmemh("src/usb_host/firmware_high.hex",ram_extra);
end

wire [3:0] mem_wstrb = !dbus_cmd_wr ? 4'b0 :
                       dbus_cmd_size == 2'b0 ? (4'b1 << dbus_cmd_a[1:0]) :
                       dbus_cmd_size == 2'b1 ? (4'b11 << dbus_cmd_a[1:0]) : 4'b1111;
reg[31:0]ram_low_q=0,ram_high_q=0;wire[31:0]ram_tail_q;reg[1:0]bank_q=0;
wire[31:0]mem_rdata=bank_q[1]?ram_tail_q:bank_q[0]?ram_high_q:ram_low_q;
// Decode the entire address before indexing. Removed address bits must never
// wrap high RAM or unrelated MMIO into the low 32KB code/data/stack array.
// VexRiscv resets at 0x80000000. The linked image uses origin0; startup
// AUIPC-relative BSS addresses use this deliberately bounded boot mirror.
// Both legal windows end after32KB; all other high-address aliases are blocked.
wire dbus_ram_sel = (dbus_cmd_a[31:16]==0||dbus_cmd_a[31:16]==16'h8000)&&dbus_cmd_a[15:0]<45056;
wire ibus_ram_sel = (ibus_cmd_pc[31:16]==0||ibus_cmd_pc[31:16]==16'h8000)&&ibus_cmd_pc[15:0]<45056;
reg dbus_rsp_error, ibus_rsp_error;

wire[31:0]ram_address=dbus_cmd_valid?dbus_cmd_a:ibus_cmd_pc;
project4_ram4k_sp tail_bank(.clk(clk),
 .write_enable(dbus_cmd_valid&&dbus_cmd_wr&&dbus_ram_sel&&dbus_cmd_a[15:12]==4'ha),
 .read_enable((dbus_cmd_valid?dbus_ram_sel:ibus_ram_sel)&&ram_address[15:12]==4'ha),
 .address(ram_address[11:2]),.data(dbus_cmd_data),.strobe(mem_wstrb),.q(ram_tail_q));
always @(posedge clk)begin
 if(dbus_cmd_valid&&dbus_cmd_wr&&dbus_ram_sel)begin
  if(!dbus_cmd_a[15])begin
   if(mem_wstrb[0])ram[dbus_cmd_a[14:2]][7:0]<=dbus_cmd_data[7:0];
   if(mem_wstrb[1])ram[dbus_cmd_a[14:2]][15:8]<=dbus_cmd_data[15:8];
   if(mem_wstrb[2])ram[dbus_cmd_a[14:2]][23:16]<=dbus_cmd_data[23:16];
   if(mem_wstrb[3])ram[dbus_cmd_a[14:2]][31:24]<=dbus_cmd_data[31:24];
  end else if(!dbus_cmd_a[13])begin
   if(mem_wstrb[0])ram_extra[dbus_cmd_a[12:2]][7:0]<=dbus_cmd_data[7:0];
   if(mem_wstrb[1])ram_extra[dbus_cmd_a[12:2]][15:8]<=dbus_cmd_data[15:8];
   if(mem_wstrb[2])ram_extra[dbus_cmd_a[12:2]][23:16]<=dbus_cmd_data[23:16];
   if(mem_wstrb[3])ram_extra[dbus_cmd_a[12:2]][31:24]<=dbus_cmd_data[31:24];
  end
 end
 if(dbus_cmd_valid?dbus_ram_sel:ibus_ram_sel)begin
  ram_low_q<=ram[ram_address[14:2]];ram_high_q<=ram_extra[ram_address[12:2]];
  bank_q<={ram_address[15]&&ram_address[13],ram_address[15]&&!ram_address[13]};
 end else begin ram_low_q<=0;ram_high_q<=0;bank_q<=0;end
end

// The peripheral-side command remains stable until dbus_cmd_ready.
// Its read result is returned one cycle after peripheral acceptance; CPU
// command acceptance into the slot happened at least one cycle earlier.
// DBus supports both memory accesses and MMIO accesses.
// IBus is executed in the same manner with lower priority, i.e. when DBus is idle.
// Firmware updates a shadow bank, then EVENT atomically publishes a snapshot.
reg [31:0] shadow_status=0,shadow_xy=0,shadow_raw=0,shadow_vidpid=0,shadow_meta=0;
reg valid_report_pending=0;
// Keep the published five-field bundle stable across the pixel-domain token.
// Shadow writes remain independent; only a subsequent EVENT may be stalled.
reg [6:0] touch_publish_guard=0;
wire touch_event_wait=dbus_cmd_wr&&dbus_cmd_a==32'h02000214&&touch_publish_guard!=0;
// EVENT cannot select UART or USB; only its local publish guard can stall it.
wire touch_event_commit=dbus_cmd_valid&&dbus_cmd_wr&&dbus_cmd_a==32'h02000214&&touch_publish_guard==0;
always @(posedge clk)begin
    if(!resetn)debug_valid_reports<=0;
    else if(touch_event_commit&&valid_report_pending)
        debug_valid_reports<=debug_valid_reports+1'b1;
end
always @(posedge clk)begin
    if(!resetn)touch_publish_guard<=0;
    else if(dbus_cmd_valid&&dbus_cmd_ready&&dbus_cmd_wr&&dbus_cmd_a==32'h02000214)
        touch_publish_guard<=7'd64;
    else if(touch_publish_guard!=0)touch_publish_guard<=touch_publish_guard-1'b1;
end
always @(posedge clk) begin
    if(!resetn) begin
        debug_status<=0;debug_xy<=0;debug_raw<=0;debug_vidpid<=0;
        debug_meta<=0;debug_toggle<=0;
        shadow_status<=0;shadow_xy<=0;shadow_raw<=0;shadow_vidpid<=0;shadow_meta<=0;
        valid_report_pending<=0;
    end else if(dbus_cmd_valid && dbus_cmd_ready && dbus_cmd_wr && dbus_cmd_a[31:8]==24'h020002) begin
        case(dbus_cmd_a[7:0])
        8'h00: begin
            shadow_status<=dbus_cmd_data;
            // Count only a fresh valid decoded touch STATUS followed by EVENT.
            // READY before first input, failures, NAKs and repeated EVENT do not count.
            valid_report_pending<=dbus_cmd_data[7:0]==8'd5 && dbus_cmd_data[23:16]==0 &&
                                  dbus_cmd_data[12] && dbus_cmd_data[13] && dbus_cmd_data[14];
        end
        8'h04: shadow_xy<=dbus_cmd_data;
        8'h08: shadow_raw<=dbus_cmd_data;
        8'h0c: shadow_vidpid<=dbus_cmd_data;
        8'h10: shadow_meta<=dbus_cmd_data;
        8'h14: begin
            debug_status<=shadow_status;debug_xy<=shadow_xy;debug_raw<=shadow_raw;
            debug_vidpid<=shadow_vidpid;debug_meta<=shadow_meta;debug_toggle<=~debug_toggle;
            valid_report_pending<=0;
        end
        endcase
    end
end
// MMIO registers
wire        simpleuart_reg_div_sel = dbus_cmd_valid && (dbus_cmd_a == 32'h 0200_0010);
wire [31:0] simpleuart_reg_div_do;

wire        simpleuart_reg_dat_sel = dbus_cmd_valid && (dbus_cmd_a == 32'h 0200_0014);
wire [31:0] simpleuart_reg_dat_do;
wire        simpleuart_reg_dat_wait;
reg         simpleuart_reg_dat_sel_r;
reg [31:0]  simpleuart_reg_dat_do_r;

wire        time_reg_sel = dbus_cmd_valid && (dbus_cmd_a == 32'h0200_0050);        // milli-seconds since start-up (overflows in 49 days)
wire        cycle_reg_sel = dbus_cmd_valid && (dbus_cmd_a == 32'h0200_0054);       // cycles counter (overflows every 200 seconds)
reg         time_reg_sel_r, cycle_reg_sel_r;

always @(posedge clk) begin
    simpleuart_reg_dat_sel_r <= simpleuart_reg_dat_sel;
    simpleuart_reg_dat_do_r <= simpleuart_reg_dat_do;
    time_reg_sel_r <= time_reg_sel;
    cycle_reg_sel_r <= cycle_reg_sel;
end

// Interface to USB host controller
wire [31:0] usb_rdata;
wire        usb_sel = dbus_cmd_valid && (dbus_cmd_a[31:8] == 24'h0200_01);
wire        usb_ack;
wire midi_select=dbus_cmd_valid&&dbus_cmd_a==32'h02000220;
wire midi_event_wait=midi_select&&dbus_cmd_wr&&(midi_request!=midi_ack);
wire wifi_write_select=dbus_cmd_valid&&dbus_cmd_wr&&dbus_cmd_a==32'h02000218;
wire wifi_read_select=dbus_cmd_valid&&!dbus_cmd_wr&&dbus_cmd_a==32'h0200021c;
wire wifi_ready_select=dbus_cmd_valid&&!dbus_cmd_wr&&dbus_cmd_a==32'h02000218;
assign wifi_rx_data=dbus_cmd_data[7:0];
assign wifi_rx_valid=wifi_write_select;
wire wifi_event_wait=wifi_write_select&&!wifi_rx_ready;
assign wifi_tx_ready=wifi_read_select&&dbus_cmd_ready;
reg wifi_read=0;
reg [31:0]wifi_read_data=0;
always @(posedge clk)begin
 if(!resetn)begin wifi_read<=0;wifi_read_data<=0;end
 else begin
  wifi_read<=(wifi_read_select||wifi_ready_select)&&dbus_cmd_ready;
  if(wifi_read_select&&dbus_cmd_ready)
   wifi_read_data<=wifi_tx_valid?{1'b1,23'b0,wifi_tx_data}:32'b0;
  else if(wifi_ready_select&&dbus_cmd_ready)wifi_read_data<={wifi_rx_ready,31'b0};
 end
end
wire stats_select=dbus_cmd_valid&&dbus_cmd_a==32'h02000228;
reg stats_read=0;
always @(posedge clk)begin
 if(!resetn)begin midi_request<=0;midi_data<=0;play_status<=0;stats_read<=0;end
 else begin
  stats_read<=stats_select&&!dbus_cmd_wr&&dbus_cmd_ready;
  if(midi_select&&dbus_cmd_wr&&dbus_cmd_ready)begin
   midi_data<=dbus_cmd_data;midi_request<=~midi_request;
  end
  if(stats_select&&dbus_cmd_wr&&dbus_cmd_ready)play_status<=dbus_cmd_data;
 end
end

// UART and USB address selects are mutually exclusive. Parallel stall terms
// avoid a cascaded address-to-ready mux on the CPU backpressure path.
assign      dbus_cmd_ready = dbus_cmd_valid &&
                            !((simpleuart_reg_dat_sel && simpleuart_reg_dat_wait) ||
                              (usb_sel && !usb_ack) || touch_event_wait || midi_event_wait || wifi_event_wait);
assign      ibus_cmd_ready = ~dbus_cmd_valid & ibus_cmd_valid;

reg         dbus_mem_ready, dbus_usb_ready;
wire [31:0] dbus_rdata = dbus_mem_ready ? mem_rdata :
                         dbus_usb_ready ? usb_rdata :
                         wifi_read ? wifi_read_data :
                         stats_read ? play_status :
                         simpleuart_reg_dat_sel_r ? simpleuart_reg_dat_do_r : 
                         time_reg_sel_r ? time_reg :
                         cycle_reg_sel_r ? cycle_reg :
                         32'h0;

always @(posedge clk) begin
    dbus_rsp_ready <= 0;
    dbus_rsp_error <= 0;
    ibus_rsp_error <= 0;
    ibus_rsp_ready <= 0;
    dbus_mem_ready <= 0;
    dbus_usb_ready <= 0;

    if (dbus_cmd_valid) begin
        if (dbus_cmd_ready && !dbus_cmd_wr) begin       // dbus read, send response next cycle
            dbus_rsp_ready <= 1;
            dbus_mem_ready <= dbus_ram_sel;
            // Preserve the existing peripheral pages and default-zero reads.
            dbus_rsp_error <= !dbus_ram_sel && dbus_cmd_a[31:8] != 24'h020000 &&
                              dbus_cmd_a[31:8] != 24'h020001 && dbus_cmd_a[31:8] != 24'h020002;
            dbus_usb_ready <= usb_sel;

        end
    end else if (ibus_cmd_valid)                        // instruction fetch takes one cycle
        begin
        ibus_rsp_ready <= 1;
        ibus_rsp_error <= !ibus_ram_sel;
    end
end

// VexRiscv cpu ---------------------------------------------------------------------------
VexRiscv rv (
    .clk(clk), .reset(~resetn), .timerInterrupt(1'b0), .externalInterrupt(1'b0), .softwareInterrupt(1'b0),
    // iBus cmd stream
    .iBus_cmd_valid(ibus_cmd_valid), .iBus_cmd_ready(ibus_cmd_ready), .iBus_cmd_payload_pc(ibus_cmd_pc), 
    // iBus rsp stream
    .iBus_rsp_valid(ibus_rsp_ready), .iBus_rsp_payload_error(ibus_rsp_error), .iBus_rsp_payload_inst(mem_rdata),
    // dBus cmd stream
    .dBus_cmd_valid(cpu_dbus_valid), .dBus_cmd_ready(cpu_dbus_ready), .dBus_cmd_payload_wr(cpu_dbus_wr),
    .dBus_cmd_payload_address(cpu_dbus_a), .dBus_cmd_payload_data(cpu_dbus_data), .dBus_cmd_payload_size(cpu_dbus_size),
    // dBus rsp stream
    .dBus_cmd_payload_mask(),
    .dBus_rsp_ready(dbus_rsp_ready), .dBus_rsp_error(dbus_rsp_error), .dBus_rsp_data(dbus_rdata)
);

// uart @ 0x0200_0010
simpleuart simpleuart (
    .clk(clk), .resetn(resetn),
    .ser_tx(uart_tx), .ser_rx(uart_rx),

    .reg_div_we  (simpleuart_reg_div_sel ? mem_wstrb : 4'b0),
    .reg_div_di  (dbus_cmd_data),
    .reg_div_do  (simpleuart_reg_div_do),

    .reg_dat_we  (simpleuart_reg_dat_sel ? mem_wstrb[0] : 1'b0),
    .reg_dat_re  (simpleuart_reg_dat_sel && mem_wstrb == 4'b0),
    .reg_dat_di  (dbus_cmd_data),
    .reg_dat_do  (simpleuart_reg_dat_do),
    .reg_dat_wait(simpleuart_reg_dat_wait)
);

// Time counter register
reg [$clog2(TIMER_TICKS)-1:0] time_cnt;
always @(posedge clk) begin
    if (~resetn) begin
        time_reg <= 0;
        time_cnt <= 0;
    end else begin
        cycle_reg <= cycle_reg + 1;
        time_cnt <= time_cnt + 1;
`ifndef VERILATOR
        if (time_cnt == TIMER_TICKS-1)
`else
        if (time_cnt == 15)          // 16 cycles per "ms" for verilator
`endif
         begin
            time_cnt <= 0;
            time_reg <= time_reg + 1;
        end
    end
end

logic  [7:0]           utmi_data_in_i;
logic                  utmi_txready_i;
logic                  utmi_rxvalid_i;
logic                  utmi_rxactive_i;
logic                  utmi_rxerror_i;
logic  [1:0]           utmi_linestate_i;
usb_link_diag link_observer(.clk(clk),.resetn(resetn),
 .bus_valid(dbus_cmd_valid&&dbus_cmd_ready),.bus_write(dbus_cmd_wr),
 .address(dbus_cmd_a),.write_data(dbus_cmd_data),.read_data(usb_rdata),
 .pc(ibus_cmd_pc),.time_ms(time_reg),.usb_state(play_status),.line_state(utmi_linestate_i),
 .reply_taken(wifi_tx_valid&&wifi_tx_ready),.reply_byte(wifi_tx_data),.host_restarts(usb_restarts),.snapshot(link_diagnostics));

logic [7:0]            utmi_data_out_o;
logic                  utmi_txvalid_o;
logic [1:0]            utmi_op_mode_o;
logic [1:0]            utmi_xcvrselect_o;
logic                  utmi_termselect_o;
logic                  utmi_dppulldown_o;
logic                  utmi_dmpulldown_o;
logic                  usb_pads_tx_dp_w;
logic                  usb_pads_tx_oen_w;
logic                  usb_pads_rx_dn_w;
logic                  usb_pads_tx_dn_w;
logic                  usb_pads_rx_rcv_w;
logic                  usb_pads_rx_dp_w;
logic                  usb_xcvr_mode_w = 1'h1;

usbh_core u_usb (
    .clk_i(clk) ,.rstn_i(usb_host_resetn),
    .reg_cs(usb_sel), .reg_wr(usb_sel & dbus_cmd_wr), .reg_addr(dbus_cmd_a[5:0]), 
    .reg_wdata(dbus_cmd_data), .reg_be(mem_wstrb), 
    .reg_rdata(usb_rdata), .reg_ack(usb_ack),

    .intr_o              (),

    .utmi_data_in_i      (utmi_data_in_i      ),
    .utmi_rxvalid_i      (utmi_rxvalid_i      ),
    .utmi_rxactive_i     (utmi_rxactive_i     ),
    .utmi_rxerror_i      (utmi_rxerror_i      ),
    .utmi_linestate_i    (utmi_linestate_i    ),

    .utmi_txready_i      (utmi_txready_i      ),
    .utmi_data_out_o     (utmi_data_out_o     ),
    .utmi_txvalid_o      (utmi_txvalid_o      ),

    .utmi_op_mode_o      (utmi_op_mode_o      ),
    .utmi_xcvrselect_o   (utmi_xcvrselect_o   ),
    .utmi_termselect_o   (utmi_termselect_o   ),
    .utmi_dppulldown_o   (utmi_dppulldown_o   ),
    .utmi_dmpulldown_o   (utmi_dmpulldown_o   )
);

usb_fs_phy  u_phy(
    // Inputs
    .clk_i               (clk           ),
    .rstn_i              (usb_phy_local_resetn ),
    .utmi_data_out_i     (utmi_data_out_o     ),
    .utmi_txvalid_i      (utmi_txvalid_o      ),
    .utmi_op_mode_i      (utmi_op_mode_o      ),
    .utmi_xcvrselect_i   (utmi_xcvrselect_o   ),
    .utmi_termselect_i   (utmi_termselect_o   ),
    .utmi_dppulldown_i   (utmi_dppulldown_o   ),
    .utmi_dmpulldown_i   (utmi_dmpulldown_o   ),
    .usb_rx_rcv_i        (usb_pads_rx_rcv_w   ),
    .usb_rx_dp_i         (usb_pads_rx_dp_w    ),
    .usb_rx_dn_i         (usb_pads_rx_dn_w    ),
    .usb_reset_assert_i  ( 1'b0               ),

    // Outputs
    .utmi_data_in_o     (utmi_data_in_i      ),
    .utmi_txready_o     (utmi_txready_i      ),
    .utmi_rxvalid_o     (utmi_rxvalid_i      ),
    .utmi_rxactive_o    (utmi_rxactive_i     ),
    .utmi_rxerror_o     (utmi_rxerror_i      ),
    .utmi_linestate_o   (utmi_linestate_i    ),
    .usb_tx_dp_o        (usb_pads_tx_dp_w    ),
    .usb_tx_dn_o        (usb_pads_tx_dn_w    ),
    .usb_tx_oen_o       (usb_pads_tx_oen_w   ),
    .usb_reset_detect_o (                    ),
    .usb_en_o           (                    )
);

wire out_dp, out_dn, out_tx_oen;

usb_transceiver u_usb_xcvr (
    // Inputs
    .usb_phy_tx_dp_i    (usb_pads_tx_dp_w   ),
    .usb_phy_tx_dn_i    (usb_pads_tx_dn_w   ),
    .usb_phy_tx_oen_i   (usb_pads_tx_oen_w  ),
    .mode_i             (usb_xcvr_mode_w    ),

    .out_dp             (out_dp             ),
    .out_dn             (out_dn             ),
    .out_tx_oen         (out_tx_oen         ),

`ifdef VERILATOR
    .in_dp              (1'b1             ),    // J for simulation
    .in_dn              (1'b0             ),
`else
    .in_dp              (usb_dp             ),
    .in_dn              (usb_dm             ),
`endif

    // Outputs
    .usb_phy_rx_rcv_o  (usb_pads_rx_rcv_w   ),
    .usb_phy_rx_dp_o   (usb_pads_rx_dp_w    ),
    .usb_phy_rx_dn_o   (usb_pads_rx_dn_w    )
);

assign usb_dp = out_tx_oen ? 1'bZ : out_dp;
assign usb_dm = out_tx_oen ? 1'bZ : out_dn;

endmodule
