// Display/guide observers only: none of these paths can stall USB or audio.
module ref_status_bridge #(parameter PERIOD=48000)(
 input wire clk,rst,usb_clk,usb_rstn,usb_running,
 input wire[31:0]diagnostic,
 output wire piano_ready,touch_ready,esp_ready
);
 wire[5:0]status;
 ref_status_snapshot #(.WIDTH(6),.PERIOD(PERIOD)) ready_snapshot(
  .clk(usb_clk),.rstn(usb_rstn),.source_data(diagnostic[5:0]),
  .pixel_clk(clk),.pixel_rstn(!rst),.frame_start(1'b1),.data(status));
 // Diagnostic error is historical; it must not hide a currently ready sibling.
 assign piano_ready=usb_running&&status[3];
 assign touch_ready=usb_running&&status[2];
 assign esp_ready=usb_running&&status[5];
endmodule