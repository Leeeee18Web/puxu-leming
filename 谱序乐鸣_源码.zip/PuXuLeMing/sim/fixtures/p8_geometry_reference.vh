// Pixel rectangles are half-open and shared by touch and display.
`include "play_geometry.vh"
function automatic integer p8_header_hit(input integer px,input integer py);
 begin
 p8_header_hit=0;
 if(py>=8&&py<56)begin
  if(px>=8&&px<104)p8_header_hit=1;
  else if(px>=116&&px<244)p8_header_hit=2;
  else if(px>=260&&px<388)p8_header_hit=3;
  else if(px>=416&&px<544)p8_header_hit=4;
  else if(px>=560&&px<688)p8_header_hit=7;
 end
 end
endfunction
function automatic integer p8_tab_hit(input integer px,input integer py);
 integer i;
 begin p8_tab_hit=0;
 if(py>=72&&py<120)for(i=0;i<7;i=i+1)
  if(px>=8+i*144&&px<144+i*144)p8_tab_hit=i+1;
 end
endfunction
function automatic integer p8_home_hit(input integer px,input integer py);
 begin p8_home_hit=0;
 if(py>=144&&py<344)begin
  if(px>=244&&px<412)p8_home_hit=2;
  else if(px>=428&&px<596)p8_home_hit=3;
  else if(px>=612&&px<780)p8_home_hit=8;
 end
 end
endfunction
function automatic integer p8_octave_hit(input integer px,input integer py);
 begin p8_octave_hit=0;
 if(py>=176&&py<224)begin
  if(px>=32&&px<200)p8_octave_hit=-1;
  else if(px>=216&&px<384)p8_octave_hit=1;
 end
 end
endfunction
function automatic integer p8_knob_mode_hit(input integer px,input integer py);
 begin p8_knob_mode_hit=-1;
 if(py>=420&&py<472)begin
  if(px>=160&&px<368)p8_knob_mode_hit=0;
  else if(px>=408&&px<616)p8_knob_mode_hit=1;
  else if(px>=656&&px<864)p8_knob_mode_hit=2;
 end
 end
endfunction
function automatic integer p8_slider_hit(input integer px,input integer py);
 begin p8_slider_hit=px>=176&&px<848&&py>=260&&py<330;end
endfunction
function automatic [6:0] p8_slider_value(input integer px);
 begin
 if(px<=192)p8_slider_value=0;
 else if(px>=832)p8_slider_value=127;
 else p8_slider_value=((px-192)*127+320)/640;
 end
endfunction
