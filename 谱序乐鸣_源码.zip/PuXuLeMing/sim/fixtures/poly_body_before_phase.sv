// Generated body state context; six original modes, scratch reused at idle.
// Six radiating body modes, parallel dedicated products, normalized Q8
// displacement/velocity. Semi-implicit update has determinant r<1 and
// k^2<2(1+r); coefficients are generic voicing targets, not measurements.
module poly_body_before_phase(input wire clk,rst,tick,piano,input wire signed[21:0]drive,
 output reg signed[31:0]radiation=0,output reg busy=0,
 input wire ctx_enable,ctx_load,input wire[319:0]ctx_data,output wire[319:0]ctx_state
);
 reg[2:0]state=0;reg piano_q=0;reg signed[23:0]input_q=0;
 wire signed[23:0]position[0:5];
 function automatic signed[23:0]sat(input signed[47:0]v);
 begin if(v>8388607)sat=8388607;else if(v< -8388608)sat=-8388608;else sat=v[23:0];end endfunction
 genvar i;generate for(i=0;i<6;i=i+1)begin:m
  localparam integer KG=i==0?877:i==1?1619:i==2?3289:i==3?4806:i==4?6828:10194,KP=i==0?801:i==1?1560:i==2?2994:i==3?5227:i==4?8848:13889,RG=i==0?65463:i==1?65435:i==2?65372:i==3?65318:i==4?65263:65173,RP=i==0?65469:i==1?65432:i==2?65370:i==3?65275:i==4?65152:65003;
  reg signed[23:0]x=0,v=0,vn=0;
  reg signed[41:0]spring=0,damping=0,motion=0;
  (* syn_preserve=1,syn_keep=1 *)reg signed[17:0]k=KG;
  (* syn_preserve=1,syn_keep=1 *)reg signed[17:0]r=RG;
  assign position[i]=x;
  always @(posedge clk)begin
   // Capture raw piano at the original tick edge, not the old piano_q NBA value.
   if(ctx_enable&&!ctx_load&&!rst&&state==0&&tick)begin k<=piano?KP:KG;r<=piano?RP:RG;end
   spring<=x*k;damping<=v*r;motion<=vn*k;
  end
  always @(posedge clk)begin
 if(ctx_load)begin x<=ctx_data[i*48+24+:24];v<=ctx_data[i*48+:24];vn<=0;end
 else if(ctx_enable)begin

   if(rst)begin x<=0;v<=0;vn<=0;end
   else case(state)
    1:begin end
    2:vn<=sat((($signed(damping)-$signed(spring))>>>16)+($signed(input_q)>>>i));
    3:begin end
    4:begin x<=sat($signed(x)+(motion>>>16));v<=vn;end
   endcase
  
 end
end
 end endgenerate
 reg signed[27:0]pair0=0,pair1=0,pair2=0;
 always @(posedge clk)begin
 if(ctx_load)begin state<=0;piano_q<=0;input_q<=0;pair0<=0;pair1<=0;pair2<=0;radiation<=ctx_data[288+:32];busy<=0;end
 else if(ctx_enable)begin

  if(rst)begin state<=0;busy<=0;radiation<=0;piano_q<=0;input_q<=0;pair0<=0;pair1<=0;pair2<=0;end
  else case(state)
   0:if(tick)begin input_q<=sat($signed(drive)<<<3);piano_q<=piano;busy<=1;state<=1;end
   1:state<=2;2:state<=3;3:state<=4;4:state<=5;
   5:begin pair0<=$signed(position[0])+$signed(position[1]);pair1<=$signed(position[2])+$signed(position[3]);pair2<=$signed(position[4])+$signed(position[5]);state<=6;end
   6:begin radiation<=$signed(pair0)+$signed(pair1)+$signed(pair2);busy<=0;state<=0;end
   default:begin state<=0;busy<=0;end
  endcase
 
 end
end
assign ctx_state[288+:32]=radiation;
 genvar q;generate for(q=0;q<6;q=q+1)begin:context_modes
 assign ctx_state[q*48+:48]={m[q].x,m[q].v};end endgenerate
endmodule
