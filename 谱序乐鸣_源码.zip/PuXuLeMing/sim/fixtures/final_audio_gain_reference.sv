`timescale 1ns/1ps
module final_audio_gain_reference(
 input wire clk,rst,input wire [3:0] gates,triggers,input wire [27:0] notes,
 input wire [47:0] gains,input wire [11:0] timbres,
 input wire [18:0] ratio,input wire [6:0] mod_depth,input wire [31:0] synth_config,
 output wire sample_tick,output wire signed [15:0] pcm,
 output wire hp_bck,hp_ws,hp_din,i2s_bck,i2s_ws,i2s_sd,
 output wire [3:0] active,output wire [95:0] monitor_steps,
 output wire [63:0] monitor_envelopes,output wire deadline_error,output reg clip_active=0
);
 `include "play_note_steps.vh"
 reg [3:0] frame_gates=0,frame_triggers=0,pending_triggers=0;
 reg [27:0] frame_notes=0;reg [47:0] frame_gains=0;reg [11:0] frame_timbres=0;
 reg [18:0] frame_ratio=262144;
 reg [95:0] event_steps=0;reg [6:0] index=0;reg [42:0] product=0;
 reg [31:0] mod_phase=0;wire [14:0] mod_magnitude=mod_phase[30]?~mod_phase[29:15]:mod_phase[29:15];
 wire signed [15:0] mod_triangle=mod_phase[31]?-$signed({1'b0,mod_magnitude}):$signed({1'b0,mod_magnitude});
 reg signed [22:0] mod_depth_product=0;reg signed [13:0] mod_offset=0;
 reg signed [33:0] mod_bend_product=0;reg [18:0] modulated_ratio=262144;
 reg [6:0] render_wait=0;
 wire render_tick=render_wait==1;
 // Preset envelopes are fixed; synth_config is an unused recording compatibility input.
 always @(posedge clk)begin
  if(rst)begin mod_phase<=0;mod_depth_product<=0;mod_offset<=0;mod_bend_product<=0;modulated_ratio<=262144;end
  else begin
   if(sample_tick)mod_phase<=mod_phase+32'd439805;
   mod_depth_product<=mod_triangle*$signed({1'b0,mod_depth});
   mod_offset<=($signed(mod_depth_product)*28'sd30)>>>15;
   mod_bend_product<=$signed({1'b0,ratio})*mod_offset;
   modulated_ratio<=$signed({1'b0,ratio})+(mod_bend_product>>>18);
  end
 end
 always @(posedge clk)begin
  frame_triggers<=0;
  if(rst)begin
   frame_gates<=0;frame_triggers<=0;pending_triggers<=0;frame_notes<=0;frame_gains<=0;frame_timbres<=0;
   frame_ratio<=262144;event_steps<=0;index<=0;product<=0;render_wait<=0;
  end else begin
   if(sample_tick)begin
    frame_gates<=gates;frame_notes<=notes;frame_gains<=gains;frame_timbres<=timbres;
    frame_ratio<=mod_depth==0?ratio:modulated_ratio;
    frame_triggers<=pending_triggers|triggers;pending_triggers<=0;index<=1;render_wait<=64;
   end else begin
    pending_triggers<=pending_triggers|triggers;
    if(render_wait!=0)render_wait<=render_wait-1'b1;
    if(index!=0)begin
     if(index<=4)product<=midi_step(frame_notes[(index-1)*7+:7])*frame_ratio;
     if(index>=2)event_steps[(index-2)*24+:24]<=product[41:18];
     index<=index==5?0:index+1'b1;
    end
   end
  end
 end
 assign monitor_steps=event_steps;
 // Preserve same-frame trigger capture through the physical render launch.
 reg [3:0] phys_triggers=0;
 always @(posedge clk)if(rst)phys_triggers<=0;else if(render_tick)phys_triggers<=0;else phys_triggers<=phys_triggers|frame_triggers;
 wire[63:0]phys_samples,phys_envelopes;wire[3:0]phys_active;wire phys_busy;
 ref_mixed_final_phys_bank physical(.clk(clk),.rst(rst),.render_tick(render_tick),.gates(frame_gates),.triggers(phys_triggers),
  .steps(event_steps),.gains(frame_gains),.timbres(frame_timbres),.samples(phys_samples),.envelopes(phys_envelopes),
  .active(phys_active),.busy(phys_busy),.deadline_error(deadline_error));
 wire signed [15:0] selected[0:3];wire signed [15:0] smooth_sample[0:3];
 genvar v;
 reg signed [15:0] stolen_tail[0:3];reg [6:0] crossfade[0:3];
 generate for(v=0;v<4;v=v+1)begin:outputs
  assign active[v]=frame_gains[v*12+:12]!=0&&(phys_active[v]||crossfade[v]!=0);
  assign monitor_envelopes[v*16+:16]=phys_envelopes[v*16+:16];
  assign selected[v]=frame_gains[v*12+:12]==0?16'sd0:$signed(phys_samples[v*16+:16]);
  // Exact old*w + new*(64-w), rewritten as new + (old-new)*w/64.
  // One signed DSP product per slot avoids the former LUT-heavy shift/add.
  wire signed [16:0] difference={stolen_tail[v][15],stolen_tail[v]}-{selected[v][15],selected[v]};
  wire signed [24:0] fade_product=difference*$signed({1'b0,crossfade[v]});
  wire signed [23:0] crossfaded=$signed(selected[v])+(fade_product>>>6);
  assign smooth_sample[v]=frame_gains[v*12+:12]==0?16'sd0:crossfade[v]==0?selected[v]:crossfaded[15:0];
  always @(posedge clk)begin
   if(rst)begin stolen_tail[v]<=0;crossfade[v]<=0;end
   else if(sample_tick)begin
    if((pending_triggers[v]||triggers[v])&&active[v])begin stolen_tail[v]<=smooth_sample[v];crossfade[v]<=64;end
    else if(crossfade[v]!=0)crossfade[v]<=crossfade[v]-1'b1;
   end
  end
 end endgenerate
 // Four signed leaves, balanced two-level summation.
 wire signed [21:0] sum01=$signed(smooth_sample[0])+$signed({{6{smooth_sample[1][15]}},smooth_sample[1]});
 wire signed [21:0] sum23=$signed(smooth_sample[2])+$signed({{6{smooth_sample[3][15]}},smooth_sample[3]});
 wire signed [21:0] sum_all=sum01+sum23;
 reg [5:0] master_gain=0;reg signed [21:0] mixed=0;
 reg signed [28:0] scaled=0;reg signed [15:0] source_pcm=0;
 wire signed [28:0] limited=scaled>>>5;
 always @(posedge clk)begin
  if(rst)begin master_gain<=0;mixed<=0;scaled<=0;source_pcm<=0;clip_active<=0;end
  else begin
   if(sample_tick&&master_gain<32)master_gain<=master_gain+1'b1;
   mixed<=sum_all;scaled<=mixed*$signed({1'b0,master_gain});
   if(limited>32767)begin source_pcm<=32767;clip_active<=1;end
   else if(limited< -32768)begin source_pcm<=-32768;clip_active<=1;end
   else source_pcm<=limited[15:0];
  end
 end
 assign pcm=source_pcm;
 i2s_tx16 tx(.clk(clk),.rst(rst),.pcm_l(pcm),.pcm_r(pcm),.bck(i2s_bck),.ws(i2s_ws),.sd(i2s_sd),.sample_tick(sample_tick));
 pt8211_tx16 adapter(.clk(clk),.rst(rst),.pcm_l(pcm),.pcm_r(pcm),.bck(hp_bck),.ws(hp_ws),.sd(hp_din));
endmodule
