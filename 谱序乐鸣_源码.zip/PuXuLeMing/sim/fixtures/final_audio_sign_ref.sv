`timescale 1ns/1ps
module final_audio_sign_ref #(parameter ENABLE_FX=0)(
 input wire clk,rst,input wire [3:0] gates,triggers,input wire [27:0] notes,
 input wire [47:0] gains,input wire [11:0] timbres,
 input wire [18:0] ratio,input wire [6:0] mod_depth,input wire [31:0] synth_config,
 output wire sample_tick,output wire signed [15:0] pcm,output wire pcm_positive,
 output wire hp_bck,hp_ws,hp_din,i2s_bck,i2s_ws,i2s_sd,
 output wire [3:0] active,output wire [95:0] monitor_steps,
 output wire [63:0] monitor_envelopes,output wire deadline_error,output wire clip_active
);

 wire signed [15:0] dry_pcm;wire dry_deadline,fx_deadline;
 wire [6:0] target=!ENABLE_FX?7'd0:synth_config[5:4]==1?7'd24:synth_config[5:4]==2?7'd56:synth_config[5:4]==3?7'd96:7'd0;
 reg [6:0] depth=0;
 always @(posedge clk)if(rst)depth<=0;else if(sample_tick)begin
  if(depth<target)depth<=depth+1'b1;else if(depth>target)depth<=depth-1'b1;
 end
 wire [6:0] effective=depth>mod_depth?depth:mod_depth;
 final_audio_pm_reference original(.clk(clk),.rst(rst),.gates(gates),.triggers(triggers),.notes(notes),.gains(gains),.timbres(timbres),
  .ratio(ratio),.mod_depth(effective),.synth_config(synth_config),.sample_tick(sample_tick),.pcm(dry_pcm),
  .active(active),.monitor_steps(monitor_steps),.monitor_envelopes(monitor_envelopes),.deadline_error(dry_deadline),.clip_active(clip_active));
 generate if(ENABLE_FX)begin:fx
  final_fx_sign_ref effects(.clk(clk),.rst(rst),.sample_tick(sample_tick),.clear(synth_config[31]),.dry(dry_pcm),
   .chorus_level(synth_config[1:0]),.reverb_level(synth_config[3:2]),.pcm(pcm),.deadline_error(fx_deadline),.ready(),.tap_delays());
 end else begin assign pcm=dry_pcm;assign fx_deadline=0;end endgenerate
 assign pcm_positive=$signed(pcm)>0;
 assign deadline_error=dry_deadline|fx_deadline;
 i2s_tx16 tx(.clk(clk),.rst(rst),.pcm_l(pcm),.pcm_r(pcm),.bck(i2s_bck),.ws(i2s_ws),.sd(i2s_sd),.sample_tick());
 pt8211_tx16 adapter(.clk(clk),.rst(rst),.pcm_l(pcm),.pcm_r(pcm),.bck(hp_bck),.ws(hp_ws),.sd(hp_din));
endmodule
