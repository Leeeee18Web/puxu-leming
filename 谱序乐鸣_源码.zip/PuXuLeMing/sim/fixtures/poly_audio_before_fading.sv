`timescale 1ns/1ps
module poly_audio_before_fading #(parameter VOICE_COUNT=25,ENABLE_FX=0,DISTRIBUTED_RESET=0)(
 input wire clk,rst,input wire [VOICE_COUNT-1:0] gates,triggers,input wire [VOICE_COUNT*7-1:0] notes,
 input wire [VOICE_COUNT*12-1:0] gains,input wire [VOICE_COUNT*3-1:0] timbres,
 input wire [18:0] ratio,input wire [6:0] mod_depth,input wire [31:0] synth_config,
 output wire sample_tick,output wire signed [15:0] pcm,output wire pcm_positive,
 output wire hp_bck,hp_ws,hp_din,i2s_bck,i2s_ws,i2s_sd,
 output wire [VOICE_COUNT-1:0] active,output wire [VOICE_COUNT*24-1:0] monitor_steps,
 output wire [VOICE_COUNT*16-1:0] monitor_envelopes,output wire deadline_error,output wire clip_active,
 input wire map_apply,input wire[11:0]model_reset
);
 `include "play_note_steps.vh"
 reg [VOICE_COUNT-1:0] frame_gates=0,frame_triggers=0,pending_triggers=0;
 reg [VOICE_COUNT*7-1:0] frame_notes=0;reg [VOICE_COUNT*12-1:0] frame_gains=0;reg [VOICE_COUNT*3-1:0] frame_timbres=0;
 (* syn_preserve=1 *)reg[VOICE_COUNT-1:0]frame_gain_zero={VOICE_COUNT{1'b1}};
 reg [18:0] frame_ratio=262144;
 reg [VOICE_COUNT*24-1:0] event_steps=0;reg [6:0] index=0;reg [42:0] product=0;
 reg [31:0] mod_phase=0;wire [14:0] mod_magnitude=mod_phase[30]?~mod_phase[29:15]:mod_phase[29:15];
 wire signed [15:0] mod_triangle=mod_phase[31]?-$signed({1'b0,mod_magnitude}):$signed({1'b0,mod_magnitude});
 reg signed [22:0] mod_depth_product=0;reg signed [13:0] mod_offset=0;
 reg signed [33:0] mod_bend_product=0;reg [18:0] modulated_ratio=262144;
 reg [6:0] render_wait=0;
 wire render_tick=render_wait==1;
 // Three UI levels travel through the existing 32-bit recorded configuration.
 wire fx_deadline;
 wire[6:0]ui_depth_target=!ENABLE_FX?7'd0:synth_config[5:4]==1?7'd24:synth_config[5:4]==2?7'd56:synth_config[5:4]==3?7'd96:7'd0;
 reg[6:0]ui_depth=0;
 always @(posedge clk)begin
  if(rst)ui_depth<=0;
  else if(sample_tick)begin
   if(ui_depth<ui_depth_target)ui_depth<=ui_depth+1'b1;
   else if(ui_depth>ui_depth_target)ui_depth<=ui_depth-1'b1;
  end
 end
 wire[6:0]effective_depth=ui_depth>mod_depth?ui_depth:mod_depth;
 always @(posedge clk)begin
  if(rst)begin mod_phase<=0;mod_depth_product<=0;mod_offset<=0;mod_bend_product<=0;modulated_ratio<=262144;end
  else begin
   if(sample_tick)mod_phase<=mod_phase+32'd439805;
   mod_depth_product<=mod_triangle*$signed({1'b0,effective_depth});
   mod_offset<=($signed(mod_depth_product)*28'sd30)>>>15;
   mod_bend_product<=$signed({1'b0,ratio})*mod_offset;
   modulated_ratio<=$signed({1'b0,ratio})+(mod_bend_product>>>18);
  end
 end
 always @(posedge clk)begin
  frame_triggers<=0;
  if(rst)begin
   frame_gates<=0;frame_triggers<=0;pending_triggers<=0;frame_notes<=0;frame_gains<=0;frame_timbres<=0;
   frame_gain_zero<={VOICE_COUNT{1'b1}};frame_ratio<=262144;event_steps<=0;index<=0;product<=0;render_wait<=0;
  end else begin
   if(sample_tick)begin
    frame_gates<=gates;frame_notes<=notes;frame_gains<=gains;frame_timbres<=timbres;
    for(integer g=0;g<VOICE_COUNT;g=g+1)frame_gain_zero[g]<=gains[g*12+:12]==0;
    frame_ratio<=effective_depth==0?ratio:modulated_ratio;
    frame_triggers<=pending_triggers|triggers;pending_triggers<=0;index<=1;render_wait<=32;
   end else begin
    pending_triggers<=pending_triggers|triggers;
    if(render_wait!=0)render_wait<=render_wait-1'b1;
    if(index!=0)begin
     if(index<=VOICE_COUNT)product<=midi_step(frame_notes[(index-1)*7+:7])*frame_ratio;
     // Static destination slices avoid index arithmetic and a wide dynamic write mux.
     for(integer s=0;s<VOICE_COUNT;s=s+1)if(index==s+2)event_steps[s*24+:24]<=product[41:18];
     index<=index==VOICE_COUNT+1?0:index+1'b1;
    end
   end
  end
 end
 assign monitor_steps=event_steps;
 // Fixed 32-clock lead-in; worker lengths follow the compile-time voice count.
 reg[VOICE_COUNT-1:0]phys_triggers=0;
 always @(posedge clk)if(rst)phys_triggers<=0;else if(render_tick)phys_triggers<=0;else phys_triggers<=phys_triggers|frame_triggers;
 wire[VOICE_COUNT*16-1:0]phys_samples,phys_envelopes;wire[VOICE_COUNT-1:0]phys_active;wire phys_busy,phys_deadline;
 wire[11:0]physical_reset=DISTRIBUTED_RESET ? model_reset:{12{rst}};
 poly25_bank #(.VOICE_COUNT(VOICE_COUNT)) physical(clk,rst,render_tick,frame_gates,phys_triggers,event_steps,frame_gains,frame_timbres,phys_samples,phys_envelopes,phys_active,phys_busy,phys_deadline,physical_reset,1'b1);
 assign deadline_error=phys_deadline|fx_deadline;
 wire signed[15:0]smooth_sample[0:VOICE_COUNT-1];
 wire[VOICE_COUNT*16-1:0]fade_samples,fade_tails,fade_history;wire[VOICE_COUNT*7-1:0]fade_weights;
 genvar v;generate for(v=0;v<VOICE_COUNT;v=v+1)begin:outputs
  reg signed[15:0]stolen_tail=0;reg[6:0]crossfade=0;
  assign active[v]=!frame_gain_zero[v]&&(phys_active[v]||crossfade!=0);
  assign monitor_envelopes[v*16+:16]=phys_envelopes[v*16+:16];
  assign smooth_sample[v]=fade_history[v*16+:16];
  assign fade_samples[v*16+:16]=frame_gain_zero[v]?16'd0:phys_samples[v*16+:16];
  assign fade_tails[v*16+:16]=stolen_tail;assign fade_weights[v*7+:7]=crossfade;
  always @(posedge clk)begin
   if(rst)begin stolen_tail<=0;crossfade<=0;end
   else if(sample_tick)begin
    if((pending_triggers[v]||triggers[v])&&active[v])begin stolen_tail<=fade_history[v*16+:16];crossfade<=64;end
    else if(crossfade!=0)crossfade<=crossfade-1'b1;
   end
  end
 end endgenerate
 reg[5:0]master_gain=0;
 always @(posedge clk)if(rst)master_gain<=0;else if(sample_tick&&master_gain<32)master_gain<=master_gain+1'b1;
 wire signed[15:0]source_pcm,raw_pcm;wire source_positive,raw_positive;
 poly25_mixer #(.VOICE_COUNT(VOICE_COUNT)) mixer(clk,rst,sample_tick,fade_samples,fade_tails,fade_weights,~frame_gain_zero,active,master_gain,source_pcm,source_positive,clip_active,fade_history);
 generate if(ENABLE_FX)begin:effects
  final_fx processor(.clk(clk),.rst(rst),.sample_tick(sample_tick),.clear(synth_config[31]),.dry(source_pcm),.dry_positive(source_positive),
   .chorus_level(synth_config[1:0]),.reverb_level(synth_config[3:2]),.pcm(raw_pcm),.pcm_positive(raw_positive),.ready(),.deadline_error(fx_deadline),.tap_delays());
 end else begin:original_dry
  assign raw_pcm=source_pcm;assign raw_positive=source_positive;assign fx_deadline=0;
 end endgenerate
 poly25_map_fade map_release(clk,rst,sample_tick,map_apply,raw_pcm,raw_positive,pcm,pcm_positive);
 i2s_tx16 tx(.clk(clk),.rst(rst),.pcm_l(pcm),.pcm_r(pcm),.bck(i2s_bck),.ws(i2s_ws),.sd(i2s_sd),.sample_tick(sample_tick));
 pt8211_tx16 adapter(.clk(clk),.rst(rst),.pcm_l(pcm),.pcm_r(pcm),.bck(hp_bck),.ws(hp_ws),.sd(hp_din));
endmodule
