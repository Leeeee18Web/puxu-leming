`timescale 1ns/1ps
// Real-time hardware effects. The original dry path is exact when settled off.
// The shared MAC/RAM engine runs Chorus -> (disabled Delay) -> Schroeder Reverb.
module final_fx_sign_ref(
 input wire clk,rst,sample_tick,clear,input wire signed[15:0]dry,
 input wire[1:0]chorus_level,reverb_level,
 output wire signed[15:0]pcm,output wire ready,deadline_error,output wire[63:0]tap_delays
);
 wire wanted=(chorus_level!=0)||(reverb_level!=0);
 wire[15:0]c_wet=chorus_level==1?16'd4096:chorus_level==2?16'd8192:chorus_level==3?16'd12288:16'd0;
 wire[15:0]r_wet=reverb_level==1?16'd4096:reverb_level==2?16'd6554:reverb_level==3?16'd9830:16'd0;
 wire signed[15:0]wet_pcm;
 project4_fx_chain engine(.clk(clk),.rst(rst||clear),.sample_tick(sample_tick),.panic(1'b0),.dry(dry),
  .enabled({reverb_level!=0,1'b0,chorus_level!=0}),.chorus_wet(c_wet),.chorus_rate(32'd70369),.chorus_depth(17'd25000),
  .delay_wet(16'd0),.delay_time(14'd3638),.delay_feedback(16'd0),.reverb_wet(r_wet),.reverb_damping(16'd15564),
  .reverb_gains({16'd26174,16'd26672,16'd27129,16'd27476}),.pcm(wet_pcm),.nodes(),.tap_delays(tap_delays),.deadline_error(deadline_error),.ready(ready));
 // Smooth outer bypass as well as the engine's internal parameter ramps.
 reg[8:0]blend=0;reg signed[15:0]dry_q=0,mixed_q=0;
 wire signed[16:0]difference=$signed({wet_pcm[15],wet_pcm})-$signed({dry[15],dry});
 reg signed[26:0]product=0;
 wire signed[27:0]sum=$signed(dry_q)+(product>>>8);
 always @(posedge clk)begin
  if(rst||clear)begin blend<=0;dry_q<=0;product<=0;mixed_q<=0;end
  else begin
   dry_q<=dry;product<=difference*$signed({1'b0,blend});
   mixed_q<=sum>32767?16'sd32767:sum< -32768?-16'sd32768:sum[15:0];
   if(sample_tick)begin
    if(wanted&&ready)begin if(blend<256)blend<=blend+9'd4;end
    else if(blend!=0)blend<=blend-9'd4;
   end
  end
 end
 assign pcm=(rst||clear)?16'sd0:blend==0?dry:mixed_q;
endmodule
