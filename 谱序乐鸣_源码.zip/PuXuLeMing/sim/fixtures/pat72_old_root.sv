module pat72_old_root(input clk,rstn,key1_n,key2_n,uart_rx,inout usb_dp,usb_dm,
 output uart_tx,hp_bck,hp_ws,hp_din,pa_en,i2s_bck,i2s_ws,i2s_sd,output[7:0]led_o,
 output tmds_clk_p_0,tmds_clk_n_0,output[2:0]tmds_d_p_0,tmds_d_n_0);
 localparam integer VOICE_COUNT=12;

 reg[2:0]audio_reset=0;
 always @(posedge clk or negedge rstn)if(!rstn)audio_reset<=0;else audio_reset<={audio_reset[1:0],1'b1};
 wire rst=!audio_reset[2];
 // Same final synchronizer stage, physically separate model reset drivers.
 // No additional reset latency: every bit equals audio_reset[2] each cycle.
 // Production uses0..5 for models,6/7 for memory,8 recorder,9 audio boundary.
 (* syn_preserve=1,syn_keep=1 *)reg[11:0]model_resetn=0;
 always @(posedge clk or negedge rstn)
  if(!rstn)model_resetn<=0;else model_resetn<={12{audio_reset[1]}};
 (* syn_keep=1 *)wire pixel_monitor;wire fast_clk,pixel_clk,video_lock;
 (* syn_preserve=1 *)reg[15:0]monitor_count=0;always @(posedge pixel_monitor)monitor_count<=monitor_count+1'b1;
 Gowin_PLL hdmi_pll(.clkin(clk),.mdclk(clk),.lock(video_lock),.clkout0(pixel_monitor),.clkout1(fast_clk));
 CLKDIV #(.DIV_MODE("5")) pixel_clock_divider(.HCLKIN(fast_clk),.RESETN(video_lock),.CALIB(1'b0),.CLKOUT(pixel_clk));
 reg[2:0]pixel_reset=0;
 always @(negedge pixel_clk or negedge rstn or negedge video_lock)
  if(!rstn||!video_lock)pixel_reset<=0;else pixel_reset<={pixel_reset[1:0],1'b1};
 wire video_rstn=pixel_reset[2];
 (* syn_preserve=1,syn_keep=1 *)reg pixel_reset_timing=0;
 always @(negedge pixel_clk or negedge rstn or negedge video_lock)
  if(!rstn||!video_lock)pixel_reset_timing<=0;else pixel_reset_timing<=pixel_reset[1];
 wire usb_clk,usb_lock;
 (* async_reg="true",syn_preserve=1 *)reg[1:0]usb_up_sync=0;
 // Regional copies of the existing final synchronizer stage. Every copy
 // samples stage0 on the same edge as stage1, so link-loss timing is exact.
 (* syn_preserve=1,syn_keep=1 *)reg[3:0]usb_region_up=0;
 always @(posedge clk)if(rst)usb_region_up<=0;else usb_region_up<={4{usb_up_sync[0]}};
 // Dedicated copy of the same final USB synchronizer stage for pattern controls.
 (* syn_preserve=1,syn_keep=1 *)reg pattern_usb_up=0;
 always @(posedge clk)if(rst)pattern_usb_up<=0;else pattern_usb_up<=usb_up_sync[0];
 USB_PLL_MOD usb_pll(.clkin(clk),.clkout0(usb_clk),.clkout1(),.lock(usb_lock),.reset(1'b0),
  .mdclk(clk),.mdopc(2'b0),.mdainc(1'b0),.mdwdi(8'b0),.mdrdo());
 reg[2:0]usb_reset=0;
 always @(posedge usb_clk or negedge rstn or negedge usb_lock)
  if(!rstn||!usb_lock)usb_reset<=0;else usb_reset<={usb_reset[1:0],1'b1};
 (* syn_preserve=1,syn_keep=1 *)reg usb_reset_phy=0;
 always @(posedge usb_clk or negedge rstn or negedge usb_lock)
  if(!rstn||!usb_lock)usb_reset_phy<=0;else usb_reset_phy<=usb_reset[1];
 wire[31:0]touch_status_source,touch_xy_source,touch_raw_source,touch_vidpid_source,touch_meta_source;
 wire[7:0]wifi_cpu_rx_data,wifi_cpu_tx_data,wifi_rx_data,wifi_tx_data;
 wire wifi_cpu_rx_valid,wifi_cpu_rx_ready,wifi_cpu_tx_valid,wifi_cpu_tx_ready;
 wire wifi_rx_valid,wifi_rx_ready,wifi_tx_valid,wifi_tx_ready;
 wire touch_toggle,midi_request,midi_ack;wire[31:0]midi_data_source,play_status;
 wire[255:0]ptest_debug_source;
 usb_play_soc #(.LOCAL_PHY_RESET(1)) soc(.clk(usb_clk),.resetn(usb_reset[2]),.phy_resetn(usb_reset_phy),.uart_rx(1'b1),.uart_tx(),.usb_dp(usb_dp),.usb_dm(usb_dm),
  .debug_status(touch_status_source),.debug_xy(touch_xy_source),.debug_raw(touch_raw_source),.debug_vidpid(touch_vidpid_source),
  .debug_meta(touch_meta_source),.debug_valid_reports(),.debug_toggle(touch_toggle),
  .midi_data(midi_data_source),.midi_request(midi_request),.midi_ack(midi_ack),.play_status(play_status),.ptest_debug(ptest_debug_source),.link_diagnostics(),
  .wifi_rx_data(wifi_cpu_rx_data),.wifi_rx_valid(wifi_cpu_rx_valid),.wifi_rx_ready(wifi_cpu_rx_ready),
  .wifi_tx_data(wifi_cpu_tx_data),.wifi_tx_valid(wifi_cpu_tx_valid),.wifi_tx_ready(wifi_cpu_tx_ready));
 // Reused bundled-data mailbox in both directions. Common startup gating
 // resets the reverse source if USB PLL drops; no unbuffered multibit CDC.
 wifi_byte_cdc wifi_to_app(.source_clk(usb_clk),.source_resetn(usb_reset[2]),
  .source_data(wifi_cpu_rx_data),.source_valid(wifi_cpu_rx_valid),.source_ready(wifi_cpu_rx_ready),
  .clk(clk),.resetn(audio_reset[2]),.data(wifi_rx_data),.valid(wifi_rx_valid),.ready(wifi_rx_ready));
 wifi_byte_cdc wifi_from_app(.source_clk(clk),.source_resetn(audio_reset[2]&&usb_region_up[3]),
  .source_data(wifi_tx_data),.source_valid(wifi_tx_valid),.source_ready(wifi_tx_ready),
  .clk(usb_clk),.resetn(usb_reset[2]),.data(wifi_cpu_tx_data),.valid(wifi_cpu_tx_valid),.ready(wifi_cpu_tx_ready));
 wire usb_event_valid,usb_event_ready;wire[31:0]usb_event_data;
 play_event_cdc midi_mailbox(.source_clk(usb_clk),.source_rst(!usb_reset[2]),.source_data(midi_data_source),.source_request(midi_request),.source_ack(midi_ack),
  .clk(clk),.rst(rst),.valid(usb_event_valid),.data(usb_event_data),.ready(usb_event_ready));
 wire[31:0]touch_status,touch_xy;wire touch_report;
 usb_touch_bridge touch_bridge(.pixel_clk(clk),.rstn(audio_reset[2]),.source_toggle(touch_toggle),.source_status(touch_status_source),
  .source_xy(touch_xy_source),.source_raw(touch_raw_source),.source_vidpid(touch_vidpid_source),.source_meta(touch_meta_source),
  .status_q(touch_status),.xy_q(touch_xy),.raw_q(),.vidpid_q(),.meta_q(),.report_valid(touch_report));
 wire touch_good=touch_status[14]&&touch_status[12]&&usb_region_up[2];reg previous_touch_good=0;
 always @(posedge clk)if(rst)previous_touch_good<=0;else previous_touch_good<=touch_good;
 wire touch_update=touch_report||(previous_touch_good&&!touch_good);
 // HID configured/layout-ready remains connected before the first valid touch.
 wire [1:0] touch_state={touch_status[12]&&usb_region_up[2],touch_good&&touch_status[24]};

 wire [2:0]page;wire [1:0]mode,knob_mode,spectrum_zoom;wire [5:0]xy_config;
 wire centre_touch,panic_touch,clear_live,start_score,stop_score,touch_event_valid,touch_event_ready,muted,restart_lesson;
 wire [6:0]base_note;wire[31:0]touch_event_data;
 wire[1:0]touch_pattern_mode;wire touch_pattern_start;
 wire record_toggle,replay_toggle,timbre_open,xy_overview,transport_stop;
 wire[7:0]envelope_choices;wire preview_toggle,preview_busy,timbre_commit;
 wire[2:0]touch_timbre_select;wire[31:0]synth_config;
 wire recording,replaying,record_full,record_time_limit,replay_frame_ready;
 wire[12:0]record_count;wire[31:0]record_samples,record_duration;
 // Bounded integer time approximation (<1ms at 60s), display only.
 wire[47:0]record_ms_product=record_samples*16'd21475;
 wire[15:0]record_milliseconds=record_ms_product[35:20];
 wire piano_ready,touch_ready,esp_ready,esp_ready_patterns,status_pattern_raw;
 final_status_bridge status_bridge(.clk(clk),.rst(rst),.usb_clk(usb_clk),.usb_rstn(usb_reset[2]),
  .usb_running(usb_region_up[0]),.diagnostic(ptest_debug_source[255:224]),
  .piano_ready(piano_ready),.touch_ready(touch_ready),.esp_ready(esp_ready),.esp_ready_patterns(esp_ready_patterns),.status_pattern_raw(status_pattern_raw));
 wire panic_key=1'b0;wire centre_key;
 project_button centre_button(.clk(clk),.rst(rst),.key_n(key2_n),.press(centre_key));
 wire pedal_down;
 project_pedal pedal_button(.clk(clk),.rst(rst),.key_n(key1_n),.down(pedal_down));
 final_navigation touch_controls(.clk(clk),.rst(rst),.touch_update(touch_update),.touch_valid(touch_good),
  .touch_down(touch_status[24]&&touch_status[12]),.touch_x(touch_xy[15:0]),.touch_y(touch_xy[31:16]),
  .event_ready(touch_event_ready),.event_valid(touch_event_valid),.event_data(touch_event_data),.panic_key(panic_key),.centre_key(centre_key),
  .page(page),.mode(mode),.knob_mode(knob_mode),.base_note(base_note),.centre(centre_touch),.panic(panic_touch),
  .clear_live(clear_live),.start_score(start_score),.stop_score(stop_score),.muted(muted),.restart_lesson(restart_lesson),.xy_config(xy_config),.spectrum_zoom(spectrum_zoom),.pattern_mode(touch_pattern_mode),.pattern_start(touch_pattern_start),.record_toggle(record_toggle),.replay_toggle(replay_toggle),.transport_stop(transport_stop),
  .envelope_choices(envelope_choices),.preview_toggle(preview_toggle),.preview_busy(preview_busy),.timbre_commit(timbre_commit),
  .timbre(touch_timbre_select),.timbre_open(timbre_open),.xy_overview(xy_overview),.synth_config(synth_config));
 wire[VOICE_COUNT-1:0]live_gates,live_triggers;wire[6:0]knob,last_note,last_velocity,mod_depth,raw_knob;
 wire[VOICE_COUNT*3-1:0]live_timbres;wire[VOICE_COUNT-1:0]active;wire[VOICE_COUNT*7-1:0]live_notes;wire[VOICE_COUNT*12-1:0]live_gains;
 wire[6:0]host_gates;wire[83:0]host_gains;
 final_voice_display #(.VOICE_COUNT(VOICE_COUNT)) host_activity(.clk(clk),.rst(rst),.gates(live_gates),.gains(live_gains),
  .home_gates(host_gates),.home_gains(host_gains));
 wire raw_known,pickup_wait;wire[18:0]ratio;
 wire sample_tick;wire signed[15:0]pcm;wire pcm_positive;
 wire gesture_event_valid,gesture_event_ready,gesture_stop;wire[31:0]gesture_event_data;
 wire wifi_event_valid,wifi_event_ready;wire[31:0]wifi_event_data;
 wire wifi_record_toggle,record_export_ready;wire[11:0]record_export_address;
 wire[95:0]record_export_word;wire[31:0]record_take_id;
 wire wifi_score_playing;wire[9:0]wifi_score_position,wifi_score_count;
 wire selected_valid,selected_ready,controller_ready,selected_raw_valid,controller_ready_raw;wire[31:0]selected_data;wire[1:0]selected_source;
 wire[174:0]map_notes;wire[6:0]map_input_base;wire map_enabled,map_apply,map_apply_audio,map_apply_fx,map_key_seen_valid;wire[4:0]map_key_seen_index;
 always @(posedge clk)if(rst)usb_up_sync<=0;else usb_up_sync<={usb_up_sync[0],usb_reset[2]};
 wire panic_all=panic_touch||panic_key||gesture_stop||!usb_region_up[1];
 p8_wifi_arbiter event_arbiter(.clk(clk),.rst(rst), .flush(clear_live||panic_all||map_apply),
  .touch_data(touch_event_data),.touch_valid(touch_event_valid),.touch_ready(touch_event_ready),
  .usb_data(usb_event_data),.usb_valid(usb_event_valid),.usb_ready(usb_event_ready),
  .gesture_data(gesture_event_data),.gesture_valid(gesture_event_valid),.gesture_ready(gesture_event_ready),
  .wifi_data(wifi_event_data),.wifi_valid(wifi_event_valid),.wifi_ready(wifi_event_ready),
  .data(selected_data),.valid(selected_valid),.raw_valid(selected_raw_valid),.ready(selected_ready),.source_tag(selected_source));
 wire[2:0]wifi_timbre;wire wifi_timbre_override;wire[1:0]wifi_pattern_mode;wire wifi_pattern_override,wifi_pattern_start;
 wire[2:0]timbre_select=(esp_ready&&wifi_timbre_override)?wifi_timbre:touch_timbre_select;
 wire[1:0]pattern_mode=(esp_ready_patterns&&wifi_pattern_override)?wifi_pattern_mode:touch_pattern_mode;
 wire pattern_start=touch_pattern_start||wifi_pattern_start;
 // A web-selected pattern can start while the touch UI is still on its home page.
 // Touch patterns retain their existing free-performance mode requirement.
 wire pattern_owner=esp_ready_patterns&&wifi_pattern_override;
 wire wifi_pattern_active=pattern_owner&&wifi_pattern_mode!=0;
 wire pattern_enabled=(mode==1)||wifi_pattern_active;
 wire pattern_select=pattern_owner?(wifi_pattern_mode!=0):((mode==1)&&touch_pattern_mode!=0);
 p8_gesture_link host_link(.clk(clk),.rst(rst),.rx(uart_rx),.tx(uart_tx),.stop_request(gesture_stop),
  .event_valid(gesture_event_valid),.event_data(gesture_event_data),.event_ready(gesture_event_ready),
  .clear_notes(panic_all||clear_live),.playable(mode!=2&&!pattern_select&&!muted&&!replaying),
  .muted(muted),.mode(mode),.pattern_mode(pattern_mode),.page(page),.gates(host_gates),.last_note(last_note));
 // The existing held-data status CDC reports only ESP owner loss; no global panic.
 reg wifi_link_was_up=0;
 wire wifi_link_lost=wifi_link_was_up&&!esp_ready;
 always @(posedge clk)if(rst)wifi_link_was_up<=0;else wifi_link_was_up<=esp_ready;
 wire wifi_playable=!muted&&!replaying&&mode!=2;
 p8_wifi_control #(.ENABLE_SCORE(1),.MAX_VOICES(VOICE_COUNT),.TIMBRE_COUNT(5)) wifi_control(.clk(clk),.rst(rst),.sample_tick(sample_tick),
  .local_timbre_commit(timbre_commit),.playable(wifi_playable),.live_link_lost(wifi_link_lost),.clear_notes(clear_live||panic_all||!wifi_playable),.mode(mode),.muted(muted),
  .rx_data(wifi_rx_data),.rx_valid(wifi_rx_valid),.rx_ready(wifi_rx_ready),
  .tx_data(wifi_tx_data),.tx_valid(wifi_tx_valid),.tx_ready(wifi_tx_ready),
  .event_data(wifi_event_data),.event_valid(wifi_event_valid),.event_ready(wifi_event_ready),
  .wifi_timbre(wifi_timbre),.wifi_timbre_override(wifi_timbre_override),.wifi_pattern_mode(wifi_pattern_mode),.wifi_pattern_override(wifi_pattern_override),.wifi_pattern_start(wifi_pattern_start),
  .recording(recording),.record_replaying(replaying),.record_full(record_full),.record_time_limit(record_time_limit),
  .record_export_ready(record_export_ready),.record_count(record_count),.record_duration(record_duration),.record_take_id(record_take_id),
  .record_read_word(record_export_word),.record_read_address(record_export_address),.record_toggle_request(wifi_record_toggle),
  .score_playing(wifi_score_playing),.score_position(wifi_score_position),.score_count(wifi_score_count),
  .trace_valid(),.trace_frame(),.trace_expected(),.trace_result(),.trace_size(),
  .good_frames(),.bad_crc(),.bad_version(),.gap_timeouts(),.watchdog_count(),
  .map_notes(map_notes),.map_input_base(map_input_base),.map_enabled(map_enabled),.map_apply(map_apply),.map_apply_audio(map_apply_audio),.map_apply_fx(map_apply_fx),.map_key_seen_valid(map_key_seen_valid),.map_key_seen_index(map_key_seen_index));
 wire selected_note_event=selected_data[7:4]==8||selected_data[7:4]==9;
 assign selected_ready=(pattern_select&&selected_note_event?1'b1:controller_ready)&&!clear_live&&!panic_all&&!map_apply;
 wire live_pedal=pedal_down&&!muted&&!replaying;
 final_voice_control #(.VOICE_COUNT(VOICE_COUNT),.RELATIVE_KNOB(1),.ENABLE_PEDAL(1)) voices(.clk(clk),.rst(rst),.sample_tick(sample_tick),.event_valid(selected_valid&&!clear_live&&!panic_all&&!map_apply&&!(pattern_select&&selected_note_event)),.event_data(selected_data),.event_ready(controller_ready),.ready_raw(controller_ready_raw),
  .panic(panic_all||clear_live),.centre(centre_touch||centre_key),.pedal_down(live_pedal),.gates(live_gates),.notes(live_notes),.gains(live_gains),.triggers(live_triggers),
  .ratio(ratio),.knob(knob),.last_note(last_note),.last_velocity(last_velocity),.mod_depth(mod_depth),
  .knob_mode(knob_mode),.raw_knob(raw_knob),.raw_known(raw_known),.pickup_wait(pickup_wait),
  .timbre_select(timbre_select),.voice_active(active),.timbres(live_timbres),
  .event_source(selected_source),.map_notes(map_notes),.map_input_base(map_input_base),.map_enabled(map_enabled),.map_apply(map_apply),.key_seen_valid(map_key_seen_valid),.key_seen_index(map_key_seen_index));
 reg touch_connected_q=0,muted_q=0;
 always @(posedge clk)if(rst)begin touch_connected_q<=0;muted_q<=0;end
 else begin touch_connected_q<=touch_state[1];muted_q<=muted;end
 wire touch_lost=touch_connected_q&&!touch_state[1];
 wire mute_enter=muted&&!muted_q;
 // Mobile release addresses its own live/score channels, never the physical
 // pattern engine. Keep physical USB/touch CC120/123 cancellation unchanged.
 wire mobile_scoped_event=selected_data[24]&&(selected_data[3:0]==13||selected_data[3:0]==14);
 wire pattern_all_off=selected_valid&&selected_ready&&!mobile_scoped_event&&selected_data[7:4]==11&&
  !selected_data[15]&&!selected_data[23]&&(selected_data[14:8]==120||selected_data[14:8]==123);
 wire[6:0]pattern_selected;wire[3:0]pattern_gates,pattern_triggers;
 wire[48:0]pattern_notes;wire[27:0]pattern_sound_notes;wire[83:0]pattern_selected_gains;wire[47:0]pattern_gains;
 wire pattern_busy,pattern_full;wire[2:0]pattern_count;
 wire pattern_disconnect=selected_valid&&selected_ready&&pattern_select&&selected_data[7:0]==8'hff;
 wire pattern_cancel=map_apply||panic_all||clear_live||stop_score||mute_enter||pattern_all_off||!pattern_enabled||touch_lost||pattern_disconnect;
 // Rebuild the same control waveform from private observers and one local final-stage copy.
 wire pattern_local_owner=pattern_usb_up&&status_pattern_raw&&wifi_pattern_override;
 wire[1:0]pattern_local_mode=pattern_local_owner?wifi_pattern_mode:touch_pattern_mode;
 wire pattern_local_enabled=(mode==1)||(pattern_local_owner&&wifi_pattern_mode!=0);
 wire pattern_local_select=pattern_local_owner?(wifi_pattern_mode!=0):((mode==1)&&touch_pattern_mode!=0);
 wire pattern_local_panic=panic_touch||panic_key||gesture_stop||!pattern_usb_up;
 wire pattern_local_ready=!clear_live&&!pattern_local_panic&&!map_apply&&
  ((pattern_local_select&&selected_note_event)||(controller_ready_raw&&!rst));
 wire pattern_local_valid=selected_raw_valid&&!rst&&!clear_live&&!pattern_local_panic&&!map_apply;
 wire pattern_local_all_off=pattern_local_valid&&pattern_local_ready&&!mobile_scoped_event&&selected_data[7:4]==11&&
  !selected_data[15]&&!selected_data[23]&&(selected_data[14:8]==120||selected_data[14:8]==123);
 wire pattern_local_disconnect=pattern_local_valid&&pattern_local_ready&&pattern_local_select&&selected_data[7:0]==8'hff;
 wire pattern_local_base_cancel=map_apply||pattern_local_panic||clear_live||stop_score||mute_enter||pattern_local_all_off||touch_lost;
 wire pattern_local_cancel=pattern_local_base_cancel||!pattern_local_enabled||pattern_local_disconnect;
 final_patterns #(.BRANCH_FULL_RELOAD(1)) patterns(.clk(clk),.rst(rst),.sample_tick(sample_tick),
  .cancel(pattern_local_cancel),
  .pattern_mode(pattern_local_mode),.start(pattern_start),
  .event_valid(pattern_local_valid&&pattern_local_ready&&pattern_local_select),.event_data(selected_data),
  .selected(pattern_selected),.selected_notes(pattern_notes),.selected_gains(pattern_selected_gains),
  .gates(pattern_gates),.triggers(pattern_triggers),.notes(pattern_sound_notes),.gains(pattern_gains),
  .busy(pattern_busy),.count(pattern_count),.full(pattern_full),
  .full_touch_mode(touch_pattern_mode),.full_wifi_mode(wifi_pattern_mode),.full_owner(pattern_local_owner),.full_touch_enabled(mode==1),
  .full_note_request(pattern_local_valid&&!selected_data[15]&&!selected_data[23]&&selected_data[7:4]==9&&selected_data[22:16]!=0),
  .full_base_cancel(pattern_local_base_cancel));
 // Original four-slot patterns are padded into the configured twelve-voice audio path.
 wire[11:0]pattern_timbres;
 wire[3:0]pedal_pattern_gates,pedal_pattern_triggers;
 wire[27:0]pedal_pattern_notes;wire[47:0]pedal_pattern_gains;
 wire new_pattern_selection=selected_valid&&selected_ready&&pattern_select&&
  selected_data[7:4]==9&&selected_data[22:16]!=0&&!selected_data[15]&&!selected_data[23];
 final_pattern_pedal pattern_pedal(.clk(clk),.rst(rst),.pedal_down(live_pedal),.pattern_mode(pattern_mode),
  .cancel(pattern_cancel||pattern_start||new_pattern_selection||replaying),
  .in_gates(pattern_gates),.in_triggers(pattern_triggers),.in_notes(pattern_sound_notes),.in_gains(pattern_gains),
  .timbre_select(timbre_select),.gates(pedal_pattern_gates),.triggers(pedal_pattern_triggers),
  .notes(pedal_pattern_notes),.gains(pedal_pattern_gains),.timbres(pattern_timbres));
 wire[VOICE_COUNT-1:0]perform_gates=pattern_select?{{(VOICE_COUNT-4){1'b0}},pedal_pattern_gates}:live_gates;
 wire[VOICE_COUNT-1:0]perform_triggers=pattern_select?{{(VOICE_COUNT-4){1'b0}},pedal_pattern_triggers}:live_triggers;
 wire[VOICE_COUNT*7-1:0]perform_notes=pattern_select?{{((VOICE_COUNT-4)*7){1'b0}},pedal_pattern_notes}:live_notes;
 wire[VOICE_COUNT*12-1:0]perform_gains=pattern_select?{{((VOICE_COUNT-4)*12){1'b0}},pedal_pattern_gains}:live_gains;
 wire[VOICE_COUNT*3-1:0]perform_timbres=pattern_select?{{((VOICE_COUNT-4)*3){1'b0}},pattern_timbres}:live_timbres;
 wire[VOICE_COUNT-1:0]source_gates,source_triggers,gates,triggers;
 wire[VOICE_COUNT*7-1:0]source_notes,notes;wire[VOICE_COUNT*12-1:0]source_gains,gains,observer_gains;
 wire[VOICE_COUNT*3-1:0]source_timbres,timbres;wire[18:0]sound_ratio;wire[6:0]sound_mod;
 wire[31:0]sound_config;wire playing,score_done;wire[6:0]next_note;
 final_audio_source #(.VOICE_COUNT(VOICE_COUNT)) sources(.clk(clk),.rst(rst),.sample_tick(sample_tick),.mode(mode),.start_score(start_score),.stop_score(stop_score),.panic(panic_all||map_apply),.transition_mute(clear_live),.muted(muted),
  .live_gates(perform_gates),.live_triggers(perform_triggers),.live_notes(perform_notes),.live_gains(perform_gains),
  .live_timbres(perform_timbres),.timbre_select(timbre_select),
  .gates(source_gates),.triggers(source_triggers),.notes(source_notes),.gains(source_gains),.timbres(source_timbres),.playing(playing),.done(score_done),.next_note(next_note));
 wire[VOICE_COUNT-1:0]admitted_gates,admitted_triggers;wire[VOICE_COUNT*7-1:0]admitted_notes;wire[VOICE_COUNT*12-1:0]admitted_gains;
 wire[VOICE_COUNT*3-1:0]admitted_timbres;wire[18:0]admitted_ratio;wire[6:0]admitted_mod;wire[31:0]admitted_config;
 final_sound_pipe #(.VOICE_COUNT(VOICE_COUNT)) sound_ingress(.clk(clk),.rst(rst),.in_gates(source_gates),.in_triggers(source_triggers),
  .in_notes(source_notes),.in_gains(source_gains),.in_timbres(source_timbres),.in_ratio(ratio),.in_mod(mod_depth),.in_config(synth_config),
  .gates(admitted_gates),.triggers(admitted_triggers),.notes(admitted_notes),.gains(admitted_gains),.timbres(admitted_timbres),
  .ratio(admitted_ratio),.mod_depth(admitted_mod),.config_word(admitted_config));
 // Recorder observes the selected sounding controls; replay never re-enters input expansion.
 final_recorder #(.VOICE_COUNT(VOICE_COUNT),.PREVIEW_INPUT(1)) recorder(.clk(clk),.rst(!model_resetn[8]),.sample_tick(sample_tick),.record_toggle(record_toggle||wifi_record_toggle),.replay_toggle(replay_toggle),
  .clear(1'b0),.panic(panic_all||mute_enter||transport_stop||map_apply),
  .preview_rst(rst),.preview_gates(source_gates),.preview_notes(source_notes),.preview_gains(source_gains),.preview_timbres(source_timbres),
  .preview_ratio(ratio),.preview_mod_depth(mod_depth),.preview_synth_config(synth_config),
  .in_gates(admitted_gates),.in_triggers(admitted_triggers),.in_notes(admitted_notes),.in_gains(admitted_gains),.in_timbres(admitted_timbres),
  .in_ratio(admitted_ratio),.in_mod_depth(admitted_mod),.in_synth_config(admitted_config),
  .out_gates(gates),.out_triggers(triggers),.out_notes(notes),.out_gains(gains),.observer_gains(observer_gains),.out_timbres(timbres),
  .out_ratio(sound_ratio),.out_mod_depth(sound_mod),.out_synth_config(sound_config),
  .recording(recording),.replaying(replaying),.full(record_full),.time_limit(record_time_limit),
  .export_address(record_export_address),.export_word(record_export_word),.export_ready(record_export_ready),.take_id(record_take_id),
  .replay_frame_ready(replay_frame_ready),.count(record_count),.time_samples(record_samples),.duration_samples(record_duration));
 // Audition stays downstream of the event recorder; its original four-note
 // phrase is zero-padded, so comparing a draft never modifies a saved take.
 wire[3:0]preview_gates,preview_triggers;wire[27:0]preview_notes;wire[47:0]preview_gains;
 wire[11:0]preview_timbres;wire[7:0]preview_choices;
 envelope_preview audition(.clk(clk),.rst(rst),.sample_tick(sample_tick),.toggle(preview_toggle),
  .stop(page!=6||panic_all||muted||clear_live||transport_stop||map_apply),.choices(envelope_choices),
  .busy(preview_busy),.gates(preview_gates),.triggers(preview_triggers),.notes(preview_notes),
  .gains(preview_gains),.timbres(preview_timbres),.captured_choices(preview_choices));
 wire[VOICE_COUNT-1:0]audio_gates=preview_busy?{{(VOICE_COUNT-4){1'b0}},preview_gates}:gates;
 wire[VOICE_COUNT-1:0]audio_triggers=preview_busy?{{(VOICE_COUNT-4){1'b0}},preview_triggers}:triggers;
 wire[VOICE_COUNT*7-1:0]audio_notes=preview_busy?{{((VOICE_COUNT-4)*7){1'b0}},preview_notes}:notes;
 wire[VOICE_COUNT*12-1:0]audio_gains=preview_busy?{{((VOICE_COUNT-4)*12){1'b0}},preview_gains}:gains;
 wire[VOICE_COUNT*3-1:0]audio_timbres=preview_busy?{{((VOICE_COUNT-4)*3){1'b0}},preview_timbres}:timbres;
 wire[VOICE_COUNT*24-1:0]monitor_steps;wire[VOICE_COUNT*16-1:0]monitor_envelopes;wire audio_deadline_error,audio_clip;
 poly25_audio #(.VOICE_COUNT(VOICE_COUNT),.ENABLE_FX(1),.DISTRIBUTED_RESET(1),.REGIONAL_MODEL_CONTROLS(1)) audio(.clk(clk),.rst(!model_resetn[9]),.map_apply(map_apply_audio),.control_resetn_early(audio_reset[1]),.model_reset(~model_resetn),.gates(audio_gates),.notes(audio_notes),.gains(audio_gains),.triggers(audio_triggers),.timbres(audio_timbres),
  .ratio(preview_busy?19'd262144:sound_ratio),.mod_depth(preview_busy?7'd0:sound_mod),.synth_config((preview_busy?{16'd0,preview_choices,8'd0}:sound_config)|{(muted||panic_all||clear_live||map_apply_fx),31'd0}),
  .sample_tick(sample_tick),.pcm(pcm),.pcm_positive(pcm_positive),.hp_bck(hp_bck),.hp_ws(hp_ws),.hp_din(hp_din),
  .i2s_bck(i2s_bck),.i2s_ws(i2s_ws),.i2s_sd(i2s_sd),.active(active),.monitor_steps(monitor_steps),.monitor_envelopes(monitor_envelopes),
  .deadline_error(audio_deadline_error),.clip_active(audio_clip));
 wire[6:0]home_gates;wire[83:0]home_gains;
 final_voice_display #(.VOICE_COUNT(VOICE_COUNT)) home_activity(.clk(clk),.rst(rst),.gates(gates),.gains(gains),.home_gates(home_gates),.home_gains(home_gains));
 assign pa_en=1'b0;
 wire[13:0]x,y;wire[9:0]history_addr;wire den,hs,vs;
 final_video_timing_ctrl #(.video_hlength(1344),.video_vlength(635),.video_hsync_len(20),.video_hbp_len(140),.video_h_visible(1024),
  .video_vsync_len(3),.video_vbp_len(20),.video_v_visible(600)) timing(.pixel_clock(pixel_clk),.rstn(pixel_reset_timing),.ext_sync(1'b0),
  .timing_h_pos(),.timing_v_pos(),.pixel_x(x),.pixel_y(y),.history_addr(history_addr),.video_vsync(vs),.video_hsync(hs),.video_den(den),.video_line_start());
 wire frame_start=den&&x==0&&y==0;
 // All display consumers release reset on a pixel rising edge.
 reg[1:0]panel_reset=0;
 always @(posedge pixel_clk or negedge video_rstn)if(!video_rstn)panel_reset<=0;else panel_reset<={panel_reset[0],1'b1};
 wire panel_rstn=panel_reset[1];
 (* async_reg="true",syn_preserve=1 *)reg[1:0]video_up_sync=0;
 always @(posedge clk)if(rst)video_up_sync<=0;else video_up_sync<={video_up_sync[0],panel_rstn};
 wire[6:0]lesson_target,lesson_feedback_note,lesson_correct;wire[1:0]lesson_feedback;wire[5:0]lesson_position;wire lesson_done;wire[15:0]lesson_wrong;
 p8_lesson lesson(.clk(clk),.rst(rst),.sample_tick(sample_tick),.enabled(mode==3),.restart(restart_lesson),.base_note(base_note),
  .event_valid(selected_valid&&selected_ready),.event_data(selected_data),.panic(panic_all),
  .target_note(lesson_target),.feedback_note(lesson_feedback_note),.feedback(lesson_feedback),.position(lesson_position),.done(lesson_done),.correct_count(lesson_correct),.wrong_count(lesson_wrong));
 wire[6:0]ui_next_note=mode==3?lesson_target:mode==2?next_note:7'd127;
 final_guide_led guide_led(.mode(mode),.target_note(ui_next_note),.done(mode==3?lesson_done:score_done),
  .activity(home_gates),.usb_ready(usb_up_sync[1]),.led_o(led_o));
 wire[6:0]leading_note;wire[10:0]leading_pitch;wire[23:0]leading_step;wire[15:0]leading_envelope;wire leading_valid;
 wire[3:0]panel_gates;wire[27:0]panel_notes;wire[47:0]panel_gains;
 poly25_display_slots #(.VOICE_COUNT(VOICE_COUNT)) panel_slots(clk,rst,gates,notes,gains,panel_gates,panel_notes,panel_gains);
 localparam integer VIEW_WIDTH=403;
 wire[VIEW_WIDTH-1:0]view;
 final_snapshot #(.WIDTH(VIEW_WIDTH),.PERIOD(100000)) ui_snapshot(.clk(clk),.rstn(audio_reset[2]),
  .source_data({envelope_choices,preview_busy,pedal_down,page,mode,playing,base_note,panel_gates,panel_notes,panel_gains,knob,raw_knob,raw_known,pickup_wait,knob_mode,leading_note,last_velocity,mod_depth,spectrum_zoom,muted,leading_valid,ui_next_note,lesson_target,lesson_feedback_note,lesson_feedback,lesson_position,lesson_done,touch_state,pattern_mode,pattern_selected,pattern_notes,pattern_busy,pattern_count,pattern_full,home_gates,home_gains,piano_ready,touch_ready,recording,replaying,record_full,record_count,record_milliseconds,timbre_select,timbre_open,xy_overview,synth_config}),
  .pixel_clk(pixel_clk),.pixel_rstn(panel_rstn),.frame_start(frame_start),.data(view));
 wire vpedal_down;wire[7:0]venvelope_choices;wire vpreview_busy;
 wire[2:0]vpage;wire[1:0]vmode,vknob_mode,vzoom;wire vplaying,vraw_known,vpickup,vmuted,vnote_valid,vlesson_done;
 wire[6:0]vnext,vlesson_target,vlesson_note;wire[1:0]vlesson_feedback;wire[5:0]vlesson_position;
 wire[1:0]vtouch_state,vpattern_mode;wire[6:0]vpattern_selected;wire[48:0]vpattern_notes;wire vpattern_busy,vpattern_full;wire[2:0]vpattern_count;
 wire[6:0]vbase,vknob,vraw,vnote,vvelocity,vmod;wire[3:0]vgates;wire[27:0]vnotes;wire[47:0]vgains;
 wire[6:0]vhome_gates;wire[83:0]vhome_gains;wire vpiano_ready,vtouch_ready,vrecording,vreplaying,vrecord_full;
 wire[12:0]vrecord_count;wire[15:0]vrecord_ms;wire[2:0]vtimbre;wire vtimbre_open,vxy_overview;wire[31:0]vsynth_config;
 assign {venvelope_choices,vpreview_busy,vpedal_down,vpage,vmode,vplaying,vbase,vgates,vnotes,vgains,vknob,vraw,vraw_known,vpickup,vknob_mode,vnote,vvelocity,vmod,vzoom,vmuted,vnote_valid,vnext,vlesson_target,vlesson_note,vlesson_feedback,vlesson_position,vlesson_done,vtouch_state,vpattern_mode,vpattern_selected,vpattern_notes,vpattern_busy,vpattern_count,vpattern_full,vhome_gates,vhome_gains,vpiano_ready,vtouch_ready,vrecording,vreplaying,vrecord_full,vrecord_count,vrecord_ms,vtimbre,vtimbre_open,vxy_overview,vsynth_config}=view;
 final_leading_voice #(.VOICE_COUNT(VOICE_COUNT)) leading(.clk(clk),.rst(rst),.active(active),.notes(notes),.gains(observer_gains),.steps(monitor_steps),.envelopes(monitor_envelopes),
  .leading_note(leading_note),.leading_pitch(leading_pitch),.leading_step(leading_step),.leading_envelope(leading_envelope),.leading_valid(leading_valid));
 wire[9:0]wave_addr,tone_addr;wire[6:0]spectrum_addr;wire[15:0]xy_addr;
 wire[47:0]wave_data;wire[7:0]spectrum_data,spectrum_peak;wire visual_valid,xy_data,xy_valid;
 wire[10:0]tone_data;wire[16:0]tone_curve;wire[9:0]tone_count;wire[5:0]xy_settings;
 p8_visuals #(.REGISTERED_PCM_POSITIVE(1),.HISTORY_READ_PIPELINE(1),.HISTORY_PREDICT_WRITE(1)) visual(.clk(clk),.rst(rst||!video_up_sync[1]),.sample_tick(sample_tick),.pcm(pcm),.pcm_positive(pcm_positive),
  .leading_note(leading_note),.leading_pitch(leading_pitch),.leading_step(leading_step),.leading_envelope(leading_envelope),.leading_valid(leading_valid),
  .restart(clear_live||start_score),.requested_config(xy_config),.pixel_clk(pixel_clk),.pixel_rstn(panel_rstn),.frame_start(frame_start),
  .page(vpage),.x(x),.wave_addr(wave_addr),.spectrum_addr(spectrum_addr),.tone_addr(history_addr),.xy_addr(xy_addr),
  .wave_data(wave_data),.spectrum_data(spectrum_data),.spectrum_peak(spectrum_peak),.visual_valid(visual_valid),
  .tone_data(tone_data),.tone_curve(tone_curve),.tone_count(tone_count),.xy_data(xy_data),.xy_valid(xy_valid),.xy_settings(xy_settings));
 wire[23:0]rgb;wire de,ohs,ovs;
 final_panel #(.SHOW_PEDAL(1),.HISTORY_PREFETCH(1)) panel(.pixel_clk(pixel_clk),.rstn(panel_rstn),.den(den),.hsync(hs),.vsync(vs),.x(x),.y(y),.pedal_down(vpedal_down),
  .home_gates(vhome_gates),.home_gains(vhome_gains),.piano_ready(vpiano_ready),.touch_ready(vtouch_ready),
  .recording(vrecording),.replaying(vreplaying),.record_full(vrecord_full),.record_count(vrecord_count),.record_milliseconds(vrecord_ms),
  .envelope_choices(venvelope_choices),.preview_busy(vpreview_busy),
  .timbre(vtimbre),.timbre_open(vtimbre_open),.xy_overview(vxy_overview),.synth_config(vsynth_config),
  .pattern_mode(vpattern_mode),.pattern_selected(vpattern_selected),.pattern_notes(vpattern_notes),.pattern_busy(vpattern_busy),.pattern_count(vpattern_count),.pattern_full(vpattern_full),
  .touch_state(vtouch_state),.page(vpage),.mode(vmode),.playing(vplaying),.muted(vmuted),.note_valid(vnote_valid),.next_note(vnext),
  .lesson_target(vlesson_target),.lesson_feedback_note(vlesson_note),.lesson_feedback(vlesson_feedback),.lesson_position(vlesson_position),.lesson_done(vlesson_done),.base_note(vbase),.gates(vgates),.notes(vnotes),.gains(vgains),
  .knob(vknob),.raw_knob(vraw),.raw_known(vraw_known),.pickup_wait(vpickup),.knob_mode(vknob_mode),.last_note(vnote),.last_velocity(vvelocity),.mod_depth(vmod),.spectrum_zoom(vzoom),
  .wave_data(wave_data),.spectrum_data(spectrum_data),.spectrum_peak(spectrum_peak),.visual_valid(visual_valid),
  .tone_data(tone_data),.tone_curve(tone_curve),.tone_count(tone_count),.xy_data(xy_data),.xy_valid(xy_valid),.xy_settings(xy_settings),
  .rgb(rgb),.den_out(de),.hsync_out(ohs),.vsync_out(ovs),.wave_addr(wave_addr),.spectrum_addr(spectrum_addr),.tone_addr(tone_addr),.xy_addr(xy_addr));
 dvi_tx_top dvi(.pixel_clock(pixel_clk),.ddr_bit_clock(fast_clk),.rstn(video_rstn),.den(de),.hsync(ohs),.vsync(ovs),.pixel_data(rgb),
  .tmds_clk({tmds_clk_p_0,tmds_clk_n_0}),.tmds_d0({tmds_d_p_0[0],tmds_d_n_0[0]}),
  .tmds_d1({tmds_d_p_0[1],tmds_d_n_0[1]}),.tmds_d2({tmds_d_p_0[2],tmds_d_n_0[2]}));
endmodule
