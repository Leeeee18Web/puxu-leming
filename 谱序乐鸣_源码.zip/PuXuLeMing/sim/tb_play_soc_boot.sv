`timescale 1ns/1ps
module tb_play_soc_boot;
 GSR GSR(.GSRI(1'b1));
 reg clk=0,resetn=0;always #10.416667 clk=~clk;
 tri usb_dp,usb_dm;pulldown(usb_dp);pulldown(usb_dm);
 wire uart_tx,toggle,req;wire[31:0]status,xy,raw,vidpid,meta,count,midi,state;
 wire[255:0]ptest_debug;
 usb_play_soc dut(.clk(clk),.resetn(resetn),.uart_rx(1'b1),.uart_tx(uart_tx),.usb_dm(usb_dm),.usb_dp(usb_dp),
 .debug_status(status),.debug_xy(xy),.debug_raw(raw),.debug_vidpid(vidpid),.debug_meta(meta),.debug_valid_reports(count),.debug_toggle(toggle),
 .midi_data(midi),.midi_request(req),.midi_ack(1'b0),.play_status(state),.ptest_debug(ptest_debug),
 .wifi_rx_data(),.wifi_rx_valid(),.wifi_rx_ready(1'b1),.wifi_tx_data(8'd0),.wifi_tx_valid(1'b0),.wifi_tx_ready());
 integer reads=0,timers=0,writes=0;reg uart_init=0,usb_init=0,published=0;
 always @(posedge clk)if(resetn)begin
  if(dut.dbus_cmd_valid&&dut.dbus_cmd_ready)begin
   if(dut.dbus_cmd_wr)begin
    writes=writes+1;
    if(dut.dbus_cmd_a==32'h02000010&&dut.dbus_cmd_data==417)uart_init=1;
    if(dut.dbus_cmd_a==32'h02000100&&dut.dbus_cmd_data==32'h68)usb_init=1;
    if(dut.dbus_cmd_a==32'h02000214)published=1;
   end else begin
    if(dut.dbus_cmd_a==32'h02000104)reads=reads+1;
    if(dut.dbus_cmd_a==32'h02000050)timers=timers+1;
   end
  end
  if(dut.ibus_rsp_ready&&dut.ibus_rsp_error)$fatal(1,"FAIL actual CPU instruction bus error");
  if(dut.dbus_rsp_ready&&dut.dbus_rsp_error)$fatal(1,"FAIL actual CPU data bus error");
 end
 initial begin
  repeat(10)@(negedge clk);resetn=1;
  repeat(200000)@(negedge clk);
  if(!uart_init||!usb_init||!published||!toggle)$fatal(1,"FAIL actual firmware init missing uart=%b usb=%b publish=%b toggle=%b",uart_init,usb_init,published,toggle);
  if(status!==0||xy!==0||state!==0||count!==0||req!==0)$fatal(1,"FAIL idle/no-device state contaminated");
  if(ptest_debug[31:0]!==1||ptest_debug[255:32]!==0)$fatal(1,"FAIL real CPU diagnostic commit missing/corrupt");
  if(reads<100||timers<100||dut.time_reg<4)$fatal(1,"FAIL real polling loop/timer stalled reads=%d timers=%d time=%d",reads,timers,dut.time_reg);
  $display("PASS real VexRiscv RV32I firmware boot, RAM stack, USB/UART init, NO_DEVICE atomic touch snapshot, idle poll reads=%0d timer_reads=%0d ms=%0d writes=%0d",reads,timers,dut.time_reg,writes);
  $finish;
 end
endmodule
