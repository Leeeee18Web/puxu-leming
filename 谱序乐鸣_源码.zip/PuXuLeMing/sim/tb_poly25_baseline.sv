`timescale 1ns/1ps
module tb_poly25_baseline;
 reg clk=0;always #10 clk=~clk;reg rst=1,valid=0;reg[31:0]ev=0;
 wire[3:0]g,t;wire[27:0]n;wire[47:0]gain;wire[11:0]tones;
 final_voice_control #(.ENABLE_PEDAL(1)) dut(.clk(clk),.rst(rst),.sample_tick(1'b0),.event_valid(valid),.event_data(ev),.event_ready(),.panic(1'b0),.centre(1'b0),.pedal_down(1'b0),.timbre_select(3'd1),.voice_active(g),.timbres(tones),.gates(g),.notes(n),.gains(gain),.triggers(t),.ratio(),.knob(),.last_note(),.last_velocity(),.mod_depth(),.knob_mode(2'd1),.raw_knob(),.raw_known(),.pickup_wait(),.ready_raw());
 integer i;initial begin
 repeat(5)@(negedge clk);rst=0;
 for(i=0;i<25;i=i+1)begin @(negedge clk);valid=1;ev={8'd0,8'd96,8'(48+i),8'h90};@(negedge clk);valid=0;repeat(3)@(negedge clk);end
 repeat(8)@(negedge clk);
 if($countones(g)!=25)$fatal(1,"POLY25_REQUIREMENT_RED expected25 held voices actual=%0d",$countones(g));
 $display("POLY25_REQUIREMENT_PASS");$finish;
 end
endmodule
