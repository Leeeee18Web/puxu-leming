`timescale 1ns/1ps
module tb_p8_source;
 reg clk=0;always #10 clk=~clk;
 reg rst=1,tick=0,start=0,stop=0,panic=0;reg[1:0]mode=0;
 reg[6:0]lg=7'b1,lt=0;reg[48:0]ln=49'd60;reg[83:0]lv=84'd3200;
 wire[6:0]g,t,nextnote;wire[48:0]n;wire[83:0]v;wire playing,done;
 p8_audio_source dut(.clk(clk),.rst(rst),.sample_tick(tick),.mode(mode),.start_score(start),.stop_score(stop),.panic(panic),.transition_mute(1'b0),.muted(1'b0),
  .live_gates(lg),.live_triggers(lt),.live_notes(ln),.live_gains(lv),.gates(g),.triggers(t),.notes(n),.gains(v),.playing(playing),.done(done),.next_note(nextnote));
 integer checks=0,j;task ck(input bit b,input string s);begin checks=checks+1;if(!b)$fatal(1,"%s",s);end endtask
 initial begin
  repeat(5)@(negedge clk);rst=0;repeat(2)@(negedge clk);
  ck(g==lg&&n==ln&&v==lv,"home receives live physical voice");
  mode=2;start=1;@(negedge clk);start=0;repeat(12)@(negedge clk);
  ck(playing&&|g,"P3 note score starts HDL voices");ck(g[6:4]==0&&v[83:48]==0,"score pads upper voices");
  stop=1;@(negedge clk);stop=0;repeat(3)@(negedge clk);ck(!playing&&g==0&&v==0,"stop clears score");
  start=1;@(negedge clk);start=0;repeat(10)@(negedge clk);ck(playing&&|g,"restart score");
  panic=1;#1;ck(g==0&&v==0&&t==0,"urgent mute combinational source guard");@(negedge clk);panic=0;repeat(3)@(negedge clk);ck(!playing&&g==0,"panic stops score");
  mode=1;#1;ck(g==lg&&n==ln,"live source restored");
  mode=2;start=1;@(negedge clk);start=0;
  for(j=0;j<1464900;j=j+1)begin tick=1;@(negedge clk);end
  tick=0;ck(done&&!playing&&g==0,"full original event score completes");
  $display("PASS tb_p8_source checks=%0d full_samples=%0d",checks,j);$finish;
 end
endmodule
