`timescale 1ns/1ps
// Native PLL/physical pads and firmware publication boundary are modeled.
// Every production navigation, CDC, arbiter, allocator, source, recorder,
// voice engine, serial output and display module is instantiated by real top.
module tb_score2_k1_top;
 reg clk=0,rstn=0,key1_n=1;always #10 clk=~clk;
 tri dp,dm;wire[7:0]led;wire bck,ws,sd,ib,iw,idata;
 hub_play_top dut(.clk(clk),.rstn(rstn),.key1_n(key1_n),.key2_n(1'b1),.uart_rx(1'b1),.uart_tx(),
  .usb_dp(dp),.usb_dm(dm),.hp_bck(bck),.hp_ws(ws),.hp_din(sd),.i2s_bck(ib),.i2s_ws(iw),.i2s_sd(idata),
  .pa_en(),.led_o(led),.tmds_clk_p_0(),.tmds_clk_n_0(),.tmds_d_p_0(),.tmds_d_n_0());
 defparam dut.status_bridge.PERIOD=10;
 integer checks=0,nz=0,cycles=0,i,j,dual_left=0,dual_right=0,dual_mixed=0;
 reg dual_phase=0;
 reg[23:0]physical_step;
 reg[11:0]physical_gain;
 reg[6:0]physical_slot,touch_slot;
 always @(posedge clk)if(!dut.rst)begin
  cycles++;
  if(dut.sample_tick)begin
   check(!dut.audio_deadline_error,"all audio engines meet sample deadline");
   if(dut.pcm!=0)nz++;
   if(dual_phase)begin
    if(dut.audio.smooth_sample[0]!=0)dual_left++;
    if(dut.audio.smooth_sample[1]!=0)dual_right++;
    if(dut.pcm!=0)dual_mixed++;
   end
   if(dut.replaying)check(dut.replay_frame_ready,"coherent replay staged before render");
  end
 end
 task check(input bit ok,input string label_text);begin checks++;if(!ok)$fatal(1,"FINAL_TOP_FAIL %s",label_text);end endtask
 task waitclks(input integer count);begin repeat(count)@(negedge clk);end endtask
 task frames(input integer count);integer k;begin for(k=0;k<count;k++)begin @(posedge dut.sample_tick);@(negedge clk);end end endtask
 task touch(input integer x,y,input bit down);begin dut.soc.hid_report(x,y,down,1);waitclks(40);end endtask
 task tap(input integer x,y);begin touch(x,y,0);touch(x,y,1);touch(x,y,0);end endtask
 task eventword(input[31:0]word);begin dut.soc.midi_event(word);waitclks(50);end endtask
 task reset_all;begin rstn=0;waitclks(10);rstn=1;waitclks(1000);end endtask
 initial begin
  reset_all;dut.soc.ptest_debug[255:224]=32'h0c;waitclks(80);tap(300,280);tap(650,96);
  key1_n=0;waitclks(51000);eventword(32'h00643c90);frames(4);eventword(32'h00003c80);frames(3);
  check(dut.live_gates!=0,"K1 must hold released physical note");
  key1_n=1;waitclks(51000);check(dut.live_gates==0,"K1 release ends pedal-only note");
  $display("SCORE2_K1_TOP_PASS real key debounce and MIDI mailbox");$finish;
 end
 initial begin #20000000;$fatal(1,"TIMEOUT");end
endmodule
