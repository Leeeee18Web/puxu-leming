`timescale 1ns/1ps
module tb_poly_reed_context;
 localparam MW=678,W=MW+56;reg clk=0;always #10 clk=~clk;
 reg rst=1,first_reset=0,en=0,load=0,save=0,tick=0,trig=0,gate=1;reg[2:0]idx=0;
 reg[23:0]step=24'd31700;reg[11:0]gain=12'd2400;
 wire[MW-1:0]snapshot;wire[W-1:0]restore;wire known;wire signed[15:0]s;wire[15:0]e;wire active,busy,err;
 wire[12:0]ra,wa;wire we;wire[19:0]wd,qa;wire[17:0]qb,qc;wire[55:0]ms;
 poly_context_store #(.WIDTH(W),.COUNT(7),.INDEX_WIDTH(3)) bank(clk,rst,save,idx,{snapshot,ms},restore,known);
 poly_delay_pool #(.CONTEXTS(7),.LENGTH(2112)) mem(clk,rst,en,load,idx,restore[55:0],ms,ra,13'd0,13'd0,wa,13'd0,13'd0,we,1'b0,1'b0,wd,18'd0,18'd0,qa,qb,qc);
 poly_model_reed_full dut(.clk(clk),.rst(rst||first_reset),.render_tick(tick),.gate(gate),.trigger(trig),.step(step),.gain(gain),.sample(s),.envelope(e),.active(active),.busy(busy),.deadline_error(err),.ctx_enable(en),.ctx_load(load),.ctx_data(restore[W-1:56]),.ctx_state(snapshot),.mem_q(qa),.mem_raddr(ra),.mem_waddr(wa),.mem_we(we),.mem_data(wd));
 wire signed[15:0]gs[0:6];wire[15:0]ge[0:6];wire[6:0]ga,gb,gerr;
 genvar k;generate for(k=0;k<7;k=k+1)begin:refvoice
  wire gc=clk&&(rst||(en&&idx==k));
  phys_reed_voice refm(.clk(gc),.rst(rst||first_reset),.render_tick(tick),.gate(gate),.trigger(trig),.step(step),.gain(gain),.sample(gs[k]),.envelope(ge[k]),.active(ga[k]),.busy(gb[k]),.deadline_error(gerr[k]));
 end endgenerate
 integer round,c,checks=0,wraps=0;
 always @(posedge clk)if(en&&!load&&dut.state==17&&dut.wp==2111)wraps=wraps+1;
 initial begin repeat(4)@(negedge clk);rst=0;
 for(round=0;round<150000;round=round+1)begin
  @(negedge clk);idx=round%7;load=1;en=0;save=0;step=24'd31700+idx*24'd12000;gain=12'd1000+idx*12'd330;gate=round<140000;
  #1;first_reset=!known;
  @(negedge clk);load=0;en=1;
  if(first_reset)begin @(negedge clk);first_reset=0;end
  tick=!gb[idx];trig=round<7||(round>125000&&round%173==0);
  for(c=0;c<1+(round%13);c=c+1)begin
   @(negedge clk);
   if(s!==gs[idx]||e!==ge[idx]||active!==ga[idx]||busy!==gb[idx]||err!==gerr[idx])$fatal(1,"REED_CONTEXT_FAIL visit%0d row%0d cycle%0d s=%0d/%0d e=%0d/%0d busy=%b/%b",round,idx,c,s,gs[idx],e,ge[idx],busy,gb[idx]);
   checks=checks+1;tick=0;trig=0;
  end
  en=0;save=1;@(negedge clk);save=0;
 end
 if(wraps==0)$fatal(1,"REED_RING_WRAP_NOT_EXERCISED");
 $display("POLY_REED_CONTEXT_PASS checks=%0d wraps=%0d seven paused voices pressure20bit/isolated RAM",checks,wraps);$finish;
 end
 initial begin #40000000;$fatal(1,"REED_CONTEXT_TIMEOUT");end
endmodule
