`timescale 1ns/1ps
module tb_lesson_held_local_boundary;
 reg clk=0;always #5 clk=~clk;
 reg rst=1,sample_tick=0,enabled=1,restart=0,event_valid=0,panic=0;
 reg[6:0]base_note=60;reg[31:0]event_data=32'h00643c90;
 wire[6:0]target_note,feedback_note,correct_count;wire[1:0]feedback;wire[5:0]position;wire done;wire[15:0]wrong_count;
 p8_lesson dut(.*);
 initial begin
  repeat(3)@(negedge clk);rst=0;
  @(negedge clk);event_valid=1;
  @(negedge clk);event_valid=0;
  repeat(4)@(negedge clk);
  if(dut.held_note!==1'b1||dut.forward_valid)$fatal(1,"LESSON_LOCAL_SETUP");
  // Only this structural probe perturbs an already captured channel during idle.
  // No event is valid, and the force is released before any following input capture.
  @(posedge clk);#1;force dut.event_data_q[0]=1'b1;#1;
  if(dut.held_note!==1'b1)$fatal(1,"LESSON_LOCAL_CHANNEL_BOUNDARY_MISSING");
  release dut.event_data_q[0];repeat(3)@(negedge clk);
  $display("LESSON_HELD_LOCAL_BOUNDARY_PASS capturedAddressIndependentOfSharedChannelQ noAddedLatency");$finish;
 end
 initial begin #1000;$fatal(1,"LESSON_HELD_LOCAL_BOUNDARY_TIMEOUT");end
endmodule
