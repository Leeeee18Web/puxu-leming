`timescale 1ns/1ps
module tb_poly12_top_wifi;
 wire trace_valid;wire[175:0]trace_frame;wire[15:0]trace_expected;wire[7:0]trace_result,trace_size;
 wire[31:0]good_frames,bad_crc,bad_version,gap_timeouts,watchdog_count;
 wire live_link_lost=1'b0;wire[2:0]wifi_timbre;wire wifi_timbre_override;wire[1:0]wifi_pattern_mode;wire wifi_pattern_override,wifi_pattern_start;
 wire recording=0,record_replaying=0,record_full=0,record_time_limit=0,record_export_ready=0;
 wire[12:0]record_count=0;wire[31:0]record_duration=0,record_take_id=0;wire[95:0]record_read_word=0;wire[11:0]record_read_address;wire record_toggle_request;
 reg clk=0,rst=1;always #10 clk=~clk;
 reg[7:0]rx_data=0;reg rx_valid=0,tx_ready=1,event_ready=1;
 wire rx_ready,tx_valid,event_valid;wire[7:0]tx_data;wire[31:0]event_data;
 reg playable=1,clear_notes=0;reg[1:0]mode=0;reg muted=0;
 reg[3:0]sample_phase=0;wire sample_tick=sample_phase==15;
 always @(posedge clk)sample_phase<=sample_phase+1'b1;
 wire score_playing;wire[9:0]score_position,score_count;
 p8_wifi_control #(.CLOCK_HZ(1000000),.WATCHDOG_MS(100),.MAX_VOICES(12),.TIMBRE_COUNT(5)) dut(.local_timbre_commit(1'b0),.map_apply_audio(),.map_apply_fx(),.*);
 wire[174:0]map_notes;wire[6:0]map_input_base;wire map_enabled,map_apply;reg map_key_seen_valid=0;reg[4:0]map_key_seen_index=0;
 integer checks=0,events=0,replies=0,txindex=0,i,old_events;
 reg[31:0]seen[0:2047];reg[7:0]reply[0:21];reg[7:0]last_result=0;
 reg[15:0]last_reply_seq=0,crc_reply=16'hffff;
 task check(input bit ok,input string label);begin checks++;if(!ok)$fatal(1,"WIFI_CHECK_FAILED %s",label);end endtask
 function automatic[15:0]crc(input[15:0]c,input[7:0]b);
 reg[15:0]v;integer k;begin v=c^{b,8'd0};for(k=0;k<8;k++)v=v[15]?(v<<1)^16'h1021:v<<1;crc=v;end endfunction
 always @(posedge clk)begin
  if(!rst&&event_valid&&event_ready)begin seen[events]=event_data;events++;end
  if(!rst&&tx_valid&&tx_ready)begin
   reply[txindex]=tx_data;
   if(txindex>=2&&txindex<=19)crc_reply=crc(crc_reply,tx_data);
   if(txindex==21)begin
    check(reply[0]=="P"&&reply[1]=="W"&&reply[2]==1,"reply identity header");
    check({tx_data,reply[20]}==crc_reply,"reply CRC from actual wire");
    check({reply[19],reply[18],reply[17],reply[16]}==32'h50385731,"P8 WiFi identity");
    last_reply_seq={reply[5],reply[4]};last_result=reply[8];replies++;txindex=0;crc_reply=16'hffff;
   end else txindex++;
  end
 end
 task byte_in(input[7:0]b);begin
  @(negedge clk);rx_data=b;rx_valid=1;
  do @(posedge clk);while(!rx_ready);
  @(negedge clk);rx_valid=0;
 end endtask
 reg[7:0]packet[0:21];integer expected_replies;reg[15:0]c;
 task command(input[7:0]op,input[15:0]seq,session,input[31:0]a,b,d,input bit corrupt,input[7:0]result);
 integer j,timeout;begin
  packet[0]="P";packet[1]="W";packet[2]=1;packet[3]=op;
  packet[4]=seq[7:0];packet[5]=seq[15:8];packet[6]=session[7:0];packet[7]=session[15:8];
  for(j=0;j<4;j++)begin packet[8+j]=a>>(j*8);packet[12+j]=b>>(j*8);packet[16+j]=d>>(j*8);end
  c=16'hffff;for(j=2;j<20;j++)c=crc(c,packet[j]);packet[20]=c[7:0];packet[21]=c[15:8]^{7'd0,corrupt};
  expected_replies=replies+1;
  for(j=0;j<22;j++)byte_in(packet[j]);
  if(!corrupt)begin
   timeout=0;while(replies<expected_replies&&timeout<4000)begin @(negedge clk);timeout++;end
   check(replies==expected_replies,"command receives FPGA ACK");
   check(last_reply_seq==seq,"ACK sequence");
   if(last_result!=result)$display("op=%0d seq=%0d result=%0d expected=%0d",op,seq,last_result,result);
   check(last_result==result,"ACK result");
  end else begin repeat(80)@(negedge clk);check(replies==expected_replies-1,"bad CRC has no ACK or execution");end
 end endtask
 function automatic[15:0]score_crc(input[15:0]start,input[31:0]t,data);
 reg[15:0]v;integer k;begin v=start;for(k=0;k<4;k++)v=crc(v,t>>(8*k));for(k=0;k<4;k++)v=crc(v,data>>(8*k));score_crc=v;end endfunction
 reg[15:0]sc;integer before_reply,seqno;
 initial begin
  repeat(5)@(negedge clk);rst=0;seqno=1;
  command(0,seqno++,16'h1234,32'h50385731,0,0,0,0);
  old_events=events;command(1,seqno++,16'h1234,32'h00fff000,32'h3c64,0,0,0);
  check(events==old_events+12,"all12 live notes emitted");
  for(i=0;i<12;i++)check(seen[old_events+i][31:25]==12+i&&seen[old_events+i][14:8]==72+i&&seen[old_events+i][7:0]==8'h9e,"upper indexed keys preserve original identity");
  old_events=events;command(1,seqno++,16'h1234,32'h00001fff,32'h3c64,0,0,1);
  check(events==old_events,"13th live note rejected atomically");
  command(9,seqno++,16'h1234,4,0,0,0,0);check(wifi_timbre==4&&wifi_timbre_override,"fifth WiFi timbre accepted");
  command(9,seqno++,16'h1234,5,0,0,0,1);check(wifi_timbre==4,"sixth timbre rejected");
  old_events=events;command(1,seqno++,16'h1234,0,32'h3c64,0,0,0);
  check(events==old_events+12,"all12 independent noteoffs emitted");
  for(i=0;i<12;i++)check(seen[old_events+i][31:25]==12+i&&seen[old_events+i][7:0]==8'h8e,"noteoff retains upper original key");
  command(20,seqno++,16'h1234,48,1,0,0,0);
  command(21,seqno++,16'h1234,0,67,0,0,0);
  command(22,seqno++,16'h1234,0,0,0,0,5);
  check(map_input_base==60&&map_notes[6:0]==60,"incomplete PW1 mapping invisible");
  sc=crc(crc(16'hffff,48),1);
  for(i=0;i<25;i++)begin command(21,seqno++,16'h1234,i,67,0,0,0);sc=crc(sc,67);end
  command(22,seqno++,16'h1234,sc^1,1,0,0,5);
  check(map_notes[6:0]==60,"bad whole-table CRC no commit");
  command(22,seqno++,16'h1234,sc,1,0,0,0);
  check(map_notes[6:0]==67&&map_notes[168+:7]==67&&map_input_base==48,"whole table PW1 commit");
  old_events=events;command(22,seqno-1,16'h1234,sc,1,0,0,0);check(events==old_events,"commit retry idempotent");
  command(22,seqno-1,16'h1234,sc^1,1,0,0,4);
  command(23,seqno++,16'h1234,24,0,0,0,0);
  check(reply[9]==67&&reply[10]==48&&reply[11]==1&&{reply[13],reply[12]}==sc,"GET actual applied note/base/checksum");
  command(24,seqno++,16'h1234,1,0,0,0,0);@(negedge clk);map_key_seen_valid=1;map_key_seen_index=24;@(negedge clk);map_key_seen_valid=0;
  command(24,seqno++,16'h1234,0,0,0,0,0);check(reply[14][5]&&reply[14][4:0]==24,"PW1 physical key learn");
  command(20,seqno++,16'h1234,60,1,0,0,0);command(21,seqno++,16'h1234,0,10,0,0,0);
  command(0,0,16'h5678,32'h50385731,0,0,0,0);command(22,1,16'h5678,sc,0,0,0,5);
  check(map_input_base==48&&map_notes[6:0]==67,"reconnect discards unfinished transaction only");
  $display("POLY12_WIFI_PASS checks=%0d events=%0d replies=%0d",checks,events,replies);$finish;
 end
 initial begin #10000000;$fatal(1,"POLY25 wifi timeout");end
endmodule
