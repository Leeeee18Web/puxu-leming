`timescale 1ns/1ps
module poly_phase_transactions #(parameter N=2,EXPECT_PIPELINE=1,FRAME_CYCLES=400,RAM_DEPTH=262144)(output reg done=0);
 reg clk=0;always #10 clk=~clk;reg rst=1,start=0;
 reg[N-1:0]gates=0,triggers=0;reg[N*24-1:0]steps=0;reg[N*12-1:0]gains=0;reg[N*3-1:0]tones=0;
 wire[N*16-1:0]sa,sb,ea,eb;wire[N-1:0]aa,ab;wire ba,bb,da,db,va,vb;wire[2:0]ia,ib;wire signed[15:0]oa,ob;
 poly_voice_worker #(.CONTEXTS(N),.LOCAL_MEMORY_RESET(1),.PRECALC_SLOT_GATES(1),.LOCAL_CONTROL(1)) dut(.clk(clk),.rst(rst),.start(start),.gates(gates),.triggers(triggers),.steps(steps),.gains(gains),.timbres(tones),.samples(sa),.envelopes(ea),.active(aa),.busy(ba),.deadline_error(da),.out_valid(va),.out_index(ia),.out_sample(oa),.model_reset({3{rst}}),.memory_reset(rst),.control_resetn_early(1'b1));
 poly_worker_before_phase #(.CONTEXTS(N),.LOCAL_MEMORY_RESET(1),.PRECALC_SLOT_GATES(1)) reference(.clk(clk),.rst(rst),.start(start),.gates(gates),.triggers(triggers),.steps(steps),.gains(gains),.timbres(tones),.samples(sb),.envelopes(eb),.active(ab),.busy(bb),.deadline_error(db),.out_valid(vb),.out_index(ib),.out_sample(ob),.model_reset({3{rst}}),.memory_reset(rst));
 reg[35:0]qa[0:2][0:RAM_DEPTH-1],qb[0:2][0:RAM_DEPTH-1];integer ca[0:2],cb[0:2],matched[0:2];
 integer frame,scenario,pos,k,c,lane,checks=0,saves=0,init_saves=0,consumes=0,bubbles=0,max_sample_phase=0,max_write_phase=0,old_max_sample=0,old_max_write=0,pcm_events=0,raw_triggers=0,raw_mode_changes=0;
 reg[23:0]base_step;
 always @(posedge clk)if(!rst)begin
  if(dut.core_enable&&!dut.ctx_load)begin
   if(dut.memory.we_a)begin qa[0][ca[0]]={dut.context_index,dut.memory.wa,dut.memory.da};if($isunknown(qa[0][ca[0]]))$fatal(1,"RAM_DUT_X_A frame%0d phase%0d tone%0d wa%0d data%h refwa%0d refdata%h reedstate%0d/%0d qa%h/%h gate%b/%b pending%b/%b en%b/%b load%b/%b",frame,dut.phase,dut.tone,dut.memory.wa,dut.memory.da,reference.memory.wa,reference.memory.da,dut.reed.state,reference.reed.state,dut.qa,reference.qa,dut.gate,reference.gate,dut.pending,reference.pending,dut.memory.enable,reference.memory.enable,dut.memory.ctx_load,reference.memory.ctx_load);ca[0]++;end
   if(dut.memory.we_b)begin qa[1][ca[1]]={dut.context_index,dut.memory.wb,2'd0,dut.memory.db};if($isunknown(qa[1][ca[1]]))$fatal(1,"RAM_DUT_X_B");ca[1]++;end
   if(dut.memory.we_c)begin qa[2][ca[2]]={dut.context_index,dut.memory.wc,2'd0,dut.memory.dc};if($isunknown(qa[2][ca[2]]))$fatal(1,"RAM_DUT_X_C");ca[2]++;end
  end
  if(reference.core_enable&&!reference.ctx_load)begin
   if(reference.memory.we_a)begin qb[0][cb[0]]={reference.context_index,reference.memory.wa,reference.memory.da};if($isunknown(qb[0][cb[0]]))$fatal(1,"RAM_REFERENCE_X_A");cb[0]++;end
   if(reference.memory.we_b)begin qb[1][cb[1]]={reference.context_index,reference.memory.wb,2'd0,reference.memory.db};if($isunknown(qb[1][cb[1]]))$fatal(1,"RAM_REFERENCE_X_B");cb[1]++;end
   if(reference.memory.we_c)begin qb[2][cb[2]]={reference.context_index,reference.memory.wc,2'd0,reference.memory.dc};if($isunknown(qb[2][cb[2]]))$fatal(1,"RAM_REFERENCE_X_C");cb[2]++;end
  end
  for(lane=0;lane<3;lane++)while(matched[lane]<ca[lane]&&matched[lane]<cb[lane])begin
   if(qa[lane][matched[lane]]!==qb[lane][matched[lane]])$fatal(1,"BRIDGE_RAM_TRANSACTION_EQ N%0d frame%0d lane%0d txn%0d got%h want%h",N,frame,lane,matched[lane],qa[lane][matched[lane]],qb[lane][matched[lane]]);
   matched[lane]++;
  end
  if(dut.is_strings&&dut.trigger_fire)begin
   if(dut.strings.a.state>3||dut.strings.b.state>3||dut.strings.c.state>3)$fatal(1,"BRIDGE_RAW_TRIGGER_CONSUMER_CONFLICT");
   raw_triggers++;if(dut.strings.piano_bridge!==(dut.tone==1))raw_mode_changes++;
  end
  if(dut.is_strings&&dut.core_enable&&!dut.ctx_load)begin
   if(dut.strings.a.state==28)begin
    if(dut.strings.b.state!=28||dut.strings.c.state!=28)$fatal(1,"BRIDGE_WAIT_NOT_SYNCHRONOUS");bubbles++;
   end
   if(dut.strings.a.state==16)begin
    if(dut.strings.b.state!=16||dut.strings.c.state!=16)$fatal(1,"BRIDGE_CONSUME_NOT_SYNCHRONOUS");
    if({dut.strings.a.bridge_return,dut.strings.b.bridge_return,dut.strings.c.bridge_return}!=={dut.strings.return0,dut.strings.return1,dut.strings.return2})$fatal(1,"BRIDGE_CONSUME_Q_MISMATCH N%0d frame%0d phase%0d",N,frame,dut.phase);
    consumes++;
   end
   if(dut.strings.a.state==18&&dut.phase>max_write_phase)max_write_phase=dut.phase;
   if(dut.strings.state==15&&dut.phase>max_sample_phase)max_sample_phase=dut.phase;
  end
  if(reference.is_strings&&reference.core_enable&&!reference.ctx_load)begin
   if(reference.strings.a.state==18&&reference.phase>old_max_write)old_max_write=reference.phase;
   if(reference.strings.state==15&&reference.phase>old_max_sample)old_max_sample=reference.phase;
  end
  if(dut.running&&dut.phase==133)begin
   if({dut.raw_sample,dut.raw_env,dut.raw_active}!=={reference.raw_sample,reference.raw_env,reference.raw_active})$fatal(1,"BRIDGE_PHASE133_EQ N%0d frame%0d",N,frame);
  end
  if(dut.is_reed&&dut.core_enable&&!dut.ctx_load)begin
   if(dut.reed.state>=4&&dut.reed.state<=7&&dut.rra!==reference.rra)$fatal(1,"REED_TAP_ADDRESS_EQ frame%0d state%0d %0d/%0d",frame,dut.reed.state,dut.rra,reference.rra);
   if(dut.reed.state>=5&&dut.reed.state<=8&&dut.qa!==reference.qa)$fatal(1,"REED_TAP_VALUE_EQ frame%0d state%0d",frame,dut.reed.state);
  end
  if({dut.memory.enable,dut.ep_enabled.ep.ctx_enable,dut.reed.ctx_enable,dut.strings.ctx_enable,dut.strings.a.ctx_enable,dut.strings.b.ctx_enable,dut.strings.c.ctx_enable,dut.strings.body.ctx_enable}!=={8{reference.core_enable}})$fatal(1,"REGIONAL_ENABLE_ORIGINAL_CURRENT_EDGE N%0d phase%0d",N,dut.phase);
  if(dut.is_strings&&dut.strings.ctx_enable&&!dut.ctx_load)begin
   if(dut.strings.gain_zero_q!==(dut.gain==0))$fatal(1,"GAIN_ZERO_CONSUMER_EDGE");
   if(dut.strings.a.state==18&&dut.strings.a.dc_shift!==reference.strings.a.dc_shift)$fatal(1,"PICKUP_A_CURRENT_EDGE");
   if(dut.strings.b.state==18&&dut.strings.b.dc_shift!==reference.strings.b.dc_shift)$fatal(1,"PICKUP_B_CURRENT_EDGE");
   if(dut.strings.c.state==18&&dut.strings.c.dc_shift!==reference.strings.c.dc_shift)$fatal(1,"PICKUP_C_CURRENT_EDGE");
  end
  if({dut.context_clear,dut.render_fire,dut.trigger_fire}!=={reference.context_clear,reference.render_fire,reference.trigger_fire})$fatal(1,"LOCAL_PHASE_CONTROL_CURRENT_EDGE");
  if({dut.ep_enabled.ep.rst,dut.reed.rst,dut.strings.rst,dut.strings.body.rst}!=={reference.ep.rst,reference.reed.rst,reference.strings.rst,reference.strings.body.rst})$fatal(1,"LOCAL_CLEAR_FAMILY_CURRENT_EDGE");
  if({dut.ep_enabled.ep.ctx_load,dut.reed.ctx_load,dut.strings.ctx_load,dut.strings.a.ctx_load,dut.strings.b.ctx_load,dut.strings.c.ctx_load,dut.strings.body.ctx_load}!=={reference.ep.ctx_load,reference.reed.ctx_load,reference.strings.ctx_load,reference.strings.a.ctx_load,reference.strings.b.ctx_load,reference.strings.c.ctx_load,reference.strings.body.ctx_load})$fatal(1,"LOCAL_RESTORE_ALL_DOMAINS_CURRENT_EDGE");
  if(dut.strings.body.m[0].mode_reset!==reference.strings.body.rst)$fatal(1,"LOCAL_BODY_MODE0_CURRENT_EDGE");
  if(dut.strings.body.m[1].mode_reset!==reference.strings.body.rst)$fatal(1,"LOCAL_BODY_MODE1_CURRENT_EDGE");
  if(dut.strings.body.m[2].mode_reset!==reference.strings.body.rst)$fatal(1,"LOCAL_BODY_MODE2_CURRENT_EDGE");
  if(dut.strings.body.m[3].mode_reset!==reference.strings.body.rst)$fatal(1,"LOCAL_BODY_MODE3_CURRENT_EDGE");
  if(dut.strings.body.m[4].mode_reset!==reference.strings.body.rst)$fatal(1,"LOCAL_BODY_MODE4_CURRENT_EDGE");
  if(dut.strings.body.m[5].mode_reset!==reference.strings.body.rst)$fatal(1,"LOCAL_BODY_MODE5_CURRENT_EDGE");
  if(dut.is_strings&&dut.core_enable&&!dut.ctx_load)begin
   if((dut.strings.a.state==0&&dut.strings.a.tick)||dut.strings.a.state==27)
    if({dut.strings.a.phase_compensation,dut.strings.b.phase_compensation,dut.strings.c.phase_compensation}!=={reference.strings.a.phase_compensation,reference.strings.b.phase_compensation,reference.strings.c.phase_compensation})$fatal(1,"TUNING_ADDRESS_ACTUAL_CONSUMER_EQ");
  end
  if(dut.memory.ctx_load!==reference.memory.ctx_load||dut.memory.rst!==reference.memory.rst)$fatal(1,"LOCAL_MEMORY_CURRENT_EDGE");
  if(dut.ctx_load)begin
   if(dut.context_snapshot!==reference.context_snapshot||dut.snapshot_known!==reference.snapshot_known)$fatal(1,"SNAPSHOT_RESTORE_EDGE_EQ N%0d frame%0d",N,frame);
   if(dut.memory.ctx_data!==reference.memory.ctx_data||dut.physical_restore!==reference.physical_restore)$fatal(1,"SNAPSHOT_ALL_RESTORE_FIELDS_EQ");
   if(!dut.snapshot_known&&dut.context_snapshot!==0)$fatal(1,"SNAPSHOT_UNWRITTEN_MASK");
  end
  if(dut.ctx_save)begin
   if(dut.context_state!==reference.context_state)$fatal(1,"BRIDGE_PHASE134_SNAPSHOT_EQ N%0d frame%0d slot%0d",N,frame,dut.context_index);
   if(dut.is_strings)begin
    if(dut.strings.a.state>3||dut.strings.b.state>3||dut.strings.c.state>3||dut.string_body_busy||(!dut.string_initializing&&dut.string_busy))$fatal(1,"BRIDGE_SLOT_BUDGET N%0d frame%0d",N,frame);
    if(dut.strings.a.state!=0)init_saves++;
   end
   for(lane=0;lane<3;lane++)if(ca[lane]!=cb[lane]||matched[lane]!=ca[lane])$fatal(1,"BRIDGE_SLOT_RAM_COUNT N%0d frame%0d lane%0d %0d/%0d",N,frame,lane,ca[lane],cb[lane]);
   saves++;
  end
 end
 always @(negedge clk)if(!rst)begin
  if({sa,ea,aa,ba,da,va,ia,oa,dut.phase,dut.context_index,dut.ctx_load,dut.ctx_save,dut.render_fire,dut.trigger_fire,dut.context_clear,dut.warm_enable,dut.core_enable}!==
     {sb,eb,ab,bb,db,vb,ib,ob,reference.phase,reference.context_index,reference.ctx_load,reference.ctx_save,reference.render_fire,reference.trigger_fire,reference.context_clear,reference.warm_enable,reference.core_enable})$fatal(1,"BRIDGE_EXTERNAL_CYCLE_EQ N%0d frame%0d phase%0d",N,frame,dut.phase);
  checks++;if(va)pcm_events++;
 end
 initial begin
  for(lane=0;lane<3;lane++)begin ca[lane]=0;cb[lane]=0;matched[lane]=0;end
  repeat(5)@(negedge clk);rst=0;
  for(frame=0;frame<2048;frame++)begin
   scenario=frame/64;pos=frame%64;
   case(scenario%8)
    0:base_step=45000;1:base_step=19456;2:base_step=9728;3:base_step=4864;
    4:base_step=4500;5:base_step=524288;6:base_step=1048576;7:base_step=4194304;
   endcase
   for(k=0;k<N;k++)begin
    steps[k*24+:24]=pos>=48?base_step:pos>=32?(base_step*3)/2:pos>=16?(base_step*2)/3:base_step;
    gains[k*12+:12]=(pos==40)?0:1000+k*1600;tones[k*3+:3]=scenario/8;
   end
   gates=pos<56?{N{1'b1}}:0;triggers=pos==0?{N{1'b1}}:0;
   start=1;@(negedge clk);start=0;repeat(FRAME_CYCLES-1)@(negedge clk);
   if(ba||da||db)$fatal(1,"BRIDGE_FRAME_DEADLINE N%0d frame%0d errors%b/%b",N,frame,da,db);
  end
  if(saves!=2048*N||consumes==0||init_saves==0||max_sample_phase>122||max_write_phase>109||old_max_sample>122||old_max_write>109||(EXPECT_PIPELINE&&bubbles!=consumes))$fatal(1,"BRIDGE_COVERAGE_BUDGET N%0d saves%0d init%0d bubbles%0d consume%0d phases%0d/%0d old%0d/%0d",N,saves,init_saves,bubbles,consumes,max_write_phase,max_sample_phase,old_max_write,old_max_sample);
  for(lane=0;lane<3;lane++)if(ca[lane]>=RAM_DEPTH||cb[lane]>=RAM_DEPTH)$fatal(1,"BRIDGE_TEST_FIFO_CAPACITY");
  if(raw_triggers==0||raw_mode_changes==0)$fatal(1,"BRIDGE_RAW_TRIGGER_COVERAGE");
  $display("POLY_BRIDGE_RAW_MODE_PASS N%0d triggers%0d modeChanges%0d all triggered at legal idle/init and no16consume",N,raw_triggers,raw_mode_changes);
  $display("POLY_ENABLE_TXN_PASS N%0d checks%0d saves%0d init%0d txn%0d/%0d/%0d bubbles%0d consumes%0d maxWrite%0d maxSample%0d oldWrite%0d oldSample%0d pcmEvents%0d all4tones/8freq/bend2of3-3of2/noteoff/zeroGain",N,checks,saves,init_saves,matched[0],matched[1],matched[2],bubbles,consumes,max_write_phase,max_sample_phase,old_max_write,old_max_sample,pcm_events);done=1;
 end
endmodule
module tb_poly_phase_transactions #(parameter EXPECT_PIPELINE=1);
 wire[1:0]done;poly_phase_transactions #(.N(2),.EXPECT_PIPELINE(EXPECT_PIPELINE)) n2(done[0]);poly_phase_transactions #(.N(1),.EXPECT_PIPELINE(EXPECT_PIPELINE)) n1(done[1]);
 initial begin wait(&done);$finish;end
endmodule
module tb_poly_bridge_pipeline_baseline;tb_poly_phase_transactions #(.EXPECT_PIPELINE(0)) test();endmodule

module tb_poly_phase_transactions34;
 wire[1:0]done;poly_phase_transactions #(.N(4),.FRAME_CYCLES(1024),.RAM_DEPTH(524288)) n4(done[0]);poly_phase_transactions #(.N(3),.FRAME_CYCLES(1024),.RAM_DEPTH(524288)) n3(done[1]);
 initial begin wait(&done);$finish;end
endmodule
