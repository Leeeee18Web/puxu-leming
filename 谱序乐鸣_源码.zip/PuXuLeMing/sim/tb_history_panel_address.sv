`timescale 1ns/1ps
module history_panel_address_case #(parameter BOUNDARY_ONLY=0)(output reg done=0);
 reg pixel_clk=0;always #9.756 pixel_clk=~pixel_clk;
 reg clk=0;always #10 clk=~clk;
 reg rstn=0,den=0,hsync=0,vsync=0,pedal_down=0;
 reg[13:0]x=0,y=0;reg[2:0]page=0;reg[1:0]mode=0;
 reg playing=1,muted=0,note_valid=1;reg[6:0]next_note=64,base_note=60;
 reg[3:0]gates=9;reg[27:0]notes=0;reg[47:0]gains=0;
 reg[6:0]home_gates=7'h55;reg[83:0]home_gains=0;
 reg piano_ready=1,touch_ready=1,recording=1,replaying=0,record_full=0;
 reg[12:0]record_count=321;reg[15:0]record_milliseconds=4321;
 reg[2:0]timbre=1;reg timbre_open=0,xy_overview=0;reg[31:0]synth_config=32'h123456;
 reg[6:0]knob=64,raw_knob=93;reg raw_known=1,pickup_wait=0;reg[1:0]touch_state=2;
 reg[1:0]pattern_mode=1;reg[6:0]pattern_selected=2;reg[48:0]pattern_notes=49'h10204081;
 reg pattern_busy=0;reg[2:0]pattern_count=4;reg pattern_full=0;
 reg[6:0]lesson_target=60,lesson_feedback_note=62;reg[1:0]lesson_feedback=1;
 reg[5:0]lesson_position=3;reg lesson_done=0;
 reg[1:0]knob_mode=1;reg[6:0]last_note=60,last_velocity=96,mod_depth=32;
 reg[47:0]wave_data=0;reg[7:0]spectrum_data=0,spectrum_peak=128;
 reg[1:0]spectrum_zoom=2;reg visual_valid=1,xy_data=0,xy_valid=1;reg[5:0]xy_settings=6'b101000;
 wire[9:0]wave_addr0,wave_addr1,tone_addr0,tone_addr1;wire[6:0]spectrum_addr0,spectrum_addr1;
 wire[15:0]xy_addr0,xy_addr1;wire[23:0]rgb0,rgb1;wire de0,de1,hs0,hs1,vs0,vs1;
 wire[10:0]tone0,tone1;wire[16:0]curve0,curve1;wire[9:0]count0,count1;
 final_panel #(.SHOW_PEDAL(1)) dut(.envelope_choices(8'h95),.preview_busy(1'b0),.keyboard_held(25'd0),.keyboard_labels(375'd0),.tone_data(tone0),.tone_curve(curve0),.tone_count(count0),
  .wave_addr(wave_addr0),.spectrum_addr(spectrum_addr0),.tone_addr(tone_addr0),.xy_addr(xy_addr0),
  .rgb(rgb0),.den_out(de0),.hsync_out(hs0),.vsync_out(vs0),.*);
 final_panel_history_reference #(.SHOW_PEDAL(1)) reference(.tone_data(tone1),.tone_curve(curve1),.tone_count(count1),
  .wave_addr(wave_addr1),.spectrum_addr(spectrum_addr1),.tone_addr(tone_addr1),.xy_addr(xy_addr1),
  .rgb(rgb1),.den_out(de1),.hsync_out(hs1),.vsync_out(vs1),.*);
 reg sample_tick=1,audio_recording=0;reg[10:0]pitch=768;reg pitch_valid=1;
 wire frame_start=x==0&&y==0;
 wire read_enable=page==1&&x>=128&&x<896;
 tone_history #(.TOTAL_SAMPLES(768),.READ_GATED(1)) history_new(
  .clk(clk),.rst(!rstn),.restart(1'b0),.sample_tick(sample_tick),.recording(audio_recording),.pitch(pitch),.pitch_valid(pitch_valid),
  .pixel_clk(pixel_clk),.pixel_rstn(rstn),.frame_start(frame_start),.read_addr(tone_addr0),.read_enable(read_enable),
  .pitch_data(tone0),.visible_count(count0),.curve_sum(curve0));
 tone_history_address_reference #(.TOTAL_SAMPLES(768),.READ_GATED(1)) history_old(
  .clk(clk),.rst(!rstn),.restart(1'b0),.sample_tick(sample_tick),.recording(audio_recording),.pitch(pitch),.pitch_valid(pitch_valid),
  .pixel_clk(pixel_clk),.pixel_rstn(rstn),.frame_start(frame_start),.read_addr(tone_addr1),.read_enable(read_enable),
  .pitch_data(tone1),.visible_count(count1),.curve_sum(curve1));
 integer ai=0;
 always @(negedge clk)begin
  if(rstn)begin
   if(history_new.column<768)audio_recording=1;else audio_recording=0;
   pitch=768+((ai*17)%590);pitch_valid=ai%19!=0;ai++;
  end
 end
 always @(posedge pixel_clk)begin
  wave_data<={32'd0,({6'd0,x[9:0]}<<5)};spectrum_data<={spectrum_addr0,1'b0};
  xy_data<=xy_addr0[7:0]==xy_addr0[15:8]||xy_addr0[7:0]==~xy_addr0[15:8];
 end
 integer p,xx,yy,k,i,checks=0,history_checks=0,graph_checks=0,disabled_addresses=0,random_steps=0,holds=0;
 integer per_page[0:7];reg[31:0]rng=32'h7381acde;reg[16:0]last_curve=0;integer curve_changes=0;
 task cycle;begin
  @(posedge pixel_clk);#1;
  if({history_new.display_bank,count0,history_new.seen,history_new.ack}!=={history_old.display_bank,count1,history_old.seen,history_old.ack})$fatal(1,"HISTORY_METADATA_EQ");
  if({rgb0,de0,hs0,vs0}!=={rgb1,de1,hs1,vs1})$fatal(1,"HISTORY_PANEL_PIXEL_EQ p%0d x%0d y%0d got%h want%h",page,x,y,rgb0,rgb1);
  if({dut.graph.color,dut.graph.s_x,dut.graph.s_y,dut.graph.s_page}!=={reference.graph.color,reference.graph.s_x,reference.graph.s_y,reference.graph.s_page})$fatal(1,"HISTORY_GRAPH_PIXEL_COORD_EQ");
  if(count0==768)begin
   if($isunknown({tone0,curve0,tone1,curve1,rgb0,rgb1}))$fatal(1,"HISTORY_PIXEL_X");
   if({tone0,curve0}!=={tone1,curve1})$fatal(1,"HISTORY_GATED_DATA_EQ p%0d x%0d",page,x);
   history_checks++;graph_checks++;if(curve0!=last_curve)curve_changes++;last_curve=curve0;
  end
  if(!read_enable&&tone_addr0!=tone_addr1)disabled_addresses++;
  checks++;@(negedge pixel_clk);
 end endtask
 initial begin
  for(i=0;i<4;i++)begin notes[i*7+:7]=60+i*4;gains[i*12+:12]=(i+1)*700;end
  for(i=0;i<7;i++)home_gains[i*12+:12]=(i+1)*500;
  for(i=0;i<8;i++)per_page[i]=0;
  if(BOUNDARY_ONLY)begin
   page=2;x=400;#1;if(tone_addr0!==10'd272)$fatal(1,"HISTORY_PAGE_TO_ADDRESS_BOUNDARY_MISSING");
   page=7;#1;if(tone_addr0!==10'd272)$fatal(1,"HISTORY_PAGE_TO_ADDRESS_BOUNDARY_MISSING");
   $display("HISTORY_ADDRESS_BOUNDARY_PASS no page-to-windowROM address cone");done=1;
  end else begin
   repeat(6)cycle;rstn=1;
   for(k=0;k<3000;k++)begin x=k%32==0?0:64;y=0;cycle;end
   if(count0!=768)$fatal(1,"HISTORY_FIXTURE_NOT_PUBLISHED count%0d",count0);
   den=1;
   for(p=0;p<8;p++)begin
    page=p;mode=p%4;timbre=p%4;timbre_open=p[0];pedal_down=p[1];
    for(yy=0;yy<600;yy++)for(xx=0;xx<1024;xx++)begin
     x=xx;y=yy;hsync=xx==0;vsync=yy==0;cycle;per_page[p]++;
    end
   end
   for(k=0;k<80000;k++)begin
    rng={rng[30:0],rng[31]^rng[21]^rng[1]^rng[0]};
    if(k%4==0)holds++;else begin
     x=rng[13:0]%1100;y=rng[27:14]%640;page=rng[2:0];
    end
    den=rng[7];hsync=rng[8];vsync=rng[9];cycle;random_steps++;
   end
   repeat(12)cycle;
   if(disabled_addresses==0||curve_changes<100||history_checks<4900000||holds==0)$fatal(1,"HISTORY_COVERAGE");
   $display("HISTORY_PANEL_ADDRESS_PASS checks%0d pages8 pixelsPerPage%0d graph%0d history%0d invisibleAddresses%0d random%0d holds%0d curveChanges%0d zeroPixelDelay privateOldPanelGraphHistory",checks,per_page[0],graph_checks,history_checks,disabled_addresses,random_steps,holds,curve_changes);done=1;
  end
 end
endmodule
module tb_history_panel_address;
 wire done;history_panel_address_case t(done);initial begin wait(done);$finish;end
endmodule
module tb_history_address_boundary;
 wire done;history_panel_address_case #(.BOUNDARY_ONLY(1)) t(done);initial begin wait(done);$finish;end
endmodule
