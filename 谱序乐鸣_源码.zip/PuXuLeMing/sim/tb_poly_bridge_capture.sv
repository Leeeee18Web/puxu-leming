`timescale 1ns/1ps
module tb_poly_bridge_capture;
 `include "src/poly/poly_model_layout.vh"
 reg clk=0;always #10 clk=~clk;
 reg en=1,load=0,mode=0;
 reg signed[19:0]stim_total=0,want_total=0;
 reg signed[17:0]a=0,b=0,c=0;
 wire signed[17:0]ra,rb,rc;
 reg[31:0]rng=32'h31415926;
 integer i,m,checks=0;
 poly_model_strings dut(.clk(clk),.rst(1'b0),.render_tick(1'b0),.trigger(1'b0),.gate(1'b1),.timbre(3'd1),.gain(12'd2400),.step(24'd151197),
  .ctx_enable(en),.ctx_load(load),.ctx_data({`POLY_MODEL_STRINGS_W{1'b0}}),.ctx_state(),
  .sample(),.envelope(),.active(),.busy(),.deadline_error(),
  .mem_qa(18'd0),.mem_qb(18'd0),.mem_qc(18'd0),.mem_ra(),.mem_rb(),.mem_rc(),
  .mem_wa(),.mem_wb(),.mem_wc(),.mem_we(),.mem_da(),.mem_db(),.mem_dc(),
  .initializing_out(),.body_busy_out(),.state_out());
 phys_string_bridge #(.PREDECODE_PIANO(1),.EXTERNAL_TOTAL(1)) reference_bridge(
  .kind(3'd1),.a(a),.b(b),.c(c),.ra(ra),.rb(rb),.rc(rc),.piano_mode(mode),.registered_total(want_total));
 initial begin
  force dut.bridge_total_next=stim_total;
  force dut.piano_bridge=mode;
  force dut.incident0=a;force dut.incident1=b;force dut.incident2=c;
  for(m=0;m<2;m++)for(i=0;i<1048576;i++)begin
   @(negedge clk);
   mode=m;stim_total=i;en=i%13!=0;load=i%37==0;
   rng={rng[30:0],rng[31]^rng[21]^rng[1]^rng[0]};a=rng[17:0];
   b=~rng[25:8];c=rng[31:14];
   if(load)want_total=0;else if(en)want_total=stim_total;
   @(posedge clk);#1;
   if(dut.bridge_total_q!==want_total ||
      dut.bridge_rem9_q!==((want_total<0)&&(want_total%512!=0)) ||
      dut.bridge_rem10_q!==((want_total<0)&&(want_total%1024!=0)))
    $fatal(1,"BRIDGE_CAPTURE_FAIL mode%0d total%0d",m,i);
   if(dut.return0!==ra||dut.return1!==rb||dut.return2!==rc)
    $fatal(1,"BRIDGE_RETURN_FAIL mode%0d total%0d",m,i);
   checks++;
  end
  $display("POLY_BRIDGE_CAPTURE_PASS checks=%0d full20bit/2modes/signed18saturation/ctx/pause",checks);$finish;
 end
 initial begin #45000000;$fatal(1,"BRIDGE_CAPTURE_TIMEOUT");end
endmodule
