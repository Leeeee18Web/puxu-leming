`timescale 1ns/1ps
module tb_poly_param_frame;
 `include "play_note_steps.vh"
 reg clk=0;always #10 clk=~clk;reg rst=1;
 reg[6:0]gates=0,triggers=0;reg[48:0]notes=0;reg[83:0]gains=0;reg[20:0]timbres=0;
 wire sample_tick,error;wire signed[15:0]pcm;
 poly25_audio #(.VOICE_COUNT(7)) dut(.clk(clk),.rst(rst),.gates(gates),.triggers(triggers),.notes(notes),.gains(gains),.timbres(timbres),
  .ratio(19'd262144),.mod_depth(7'd0),.synth_config(32'd0),.sample_tick(sample_tick),.pcm(pcm),.pcm_positive(),
  .hp_bck(),.hp_ws(),.hp_din(),.i2s_bck(),.i2s_ws(),.i2s_sd(),.active(),.monitor_steps(),.monitor_envelopes(),
  .deadline_error(error),.clip_active(),.map_apply(1'b0),.model_reset({12{rst}}),.control_resetn_early(1'b1));
 reg[6:0]want_gates;reg[48:0]want_notes;reg[83:0]want_gains;reg[20:0]want_timbres;
 integer age=-1,frames=0,checks=0,j,drive_cycle=0;
 always @(negedge clk)if(!rst)begin
  drive_cycle=drive_cycle+1;
  gates=drive_cycle[6:0];triggers=drive_cycle%317==0?7'h7f:0;
  for(integer k=0;k<7;k=k+1)begin
   notes[k*7+:7]=45+(drive_cycle+k)%24;gains[k*12+:12]=800+(drive_cycle+k*70)%1800;timbres[k*3+:3]=(drive_cycle/17+k)%4;
  end
 end
 always @(posedge clk)if(!rst)begin
  if(sample_tick)begin want_gates=gates;want_notes=notes;want_gains=gains;want_timbres=timbres;age=0;frames=frames+1;end
  else if(age>=0)age=age+1;
  #1;
  if(age>=0)begin
   if(dut.frame_gates!==want_gates||dut.frame_notes!==want_notes||dut.frame_gains!==want_gains||dut.frame_timbres!==want_timbres)
    $fatal(1,"PARAM_FRAME_UNSTABLE age%0d",age);
   if(age>=8)for(j=0;j<7;j=j+1)begin
    if(dut.event_steps[j*24+:24]!==midi_step(want_notes[j*7+:7]))$fatal(1,"PARAM_STEP_NOT_READY age%0d voice%0d",age,j);
    checks=checks+1;
   end
   if(dut.render_tick)begin
    if(age<8)$fatal(1,"PARAM_RENDER_TOO_EARLY age%0d",age);
    $display("PARAM_FRAME_RENDER frame%0d age%0d step_ready8 t%0t",frames,age,$time);
   end
   if(error)$fatal(1,"PARAM_FRAME_DEADLINE");
  end
  if(frames==5&&age==500)begin $display("POLY_PARAM_FRAME_PASS frames%0d checks%0d stable frame vectors; step ready8 before render31",frames,checks);$finish;end
 end
 genvar g;generate for(g=0;g<2;g=g+1)begin:observe
  localparam BASE=g==0?0:4;localparam N=g==0?4:3;
  always @(posedge clk)begin
   #2;
   if(!rst&&dut.physical.group[g].worker.running&&dut.physical.group[g].worker.phase==1)begin
    if(dut.physical.group[g].worker.step!==midi_step(want_notes[(BASE+dut.physical.group[g].worker.context_index)*7+:7])||
       dut.physical.group[g].worker.gain!==want_gains[(BASE+dut.physical.group[g].worker.context_index)*12+:12]||
       dut.physical.group[g].worker.tone!==want_timbres[(BASE+dut.physical.group[g].worker.context_index)*3+:3])$fatal(1,"PARAM_REAL_FRAME_SELECTION group%0d",g);
    $display("PARAM_REAL_CAPTURE frame%0d group%0d N%0d context%0d age%0d t%0t",frames,g,N,dut.physical.group[g].worker.context_index,age,$time);
   end
  end
 end endgenerate
 initial begin repeat(5)@(negedge clk);rst=0;end
 initial begin #200000;$fatal(1,"PARAM_FRAME_TIMEOUT");end
endmodule
