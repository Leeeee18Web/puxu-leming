`timescale 1ns/1ps
module tb_poly_q15_capture;
 `include "src/poly/poly_model_layout.vh"
 reg clk=0;always #10 clk=~clk;reg en=1,load=0,rst=0,trig=0;
 reg signed[51:0]fake_mul=0;reg signed[35:0]fake_bridge=0;
 poly_model_line dut(.clk(clk),.rst(rst),.tick(1'b0),.trigger(trig),.gate(1'b1),.kind(3'd1),.velocity(12'd2400),.step(24'd151197),.rate_shift(2'd0),.period_q10(24'd100000),.sample(),.envelope(),.busy(),.deadline_error(),.bridge_return(18'sd0),.bridge_incident(),.piano_mode(1'b1),.bridge_incident_next(),.ctx_enable(en),.ctx_load(load),.ctx_data({`POLY_MODEL_LINE_W{1'b0}}),.ctx_state(),.mem_q(18'd0),.mem_raddr(),.mem_waddr(),.mem_we(),.mem_data(),.shared_tuning(16'd0),.shared_impact(18'sd0),.impact_phase());
 reg[35:0]rng=36'hf973491ac,value=0;reg signed[35:0]want_raw=0;reg signed[17:0]want_q=0;reg signed[63:0]wide;
 integer h,l,k,n=0,checks=0;reg[4:0]writes_seen=0;
 task vector;
 begin
  en=n%13!=0;load=n%37==0;rst=n%127==0;trig=n%149==0;
  fake_mul={16'hd6a5,value};fake_bridge=value;
  case(n%5)
   0:force dut.state=6'd10;1:force dut.state=6'd11;2:force dut.state=6'd13;3:force dut.state=6'd14;4:force dut.state=6'd16;
  endcase
  if(load)begin want_raw=0;want_q=0;end
  else if(en&&!rst&&!trig)begin
   want_raw=value;wide=$signed(value);
   if(n%5!=4)want_q=wide/64'sd32768;
   writes_seen[n%5]=1;
  end
  @(posedge clk);#1;
  if(dut.product!==want_raw||dut.product_q15!==want_q)$fatal(1,"Q15_CAPTURE_FAIL n%0d raw%h/%h q%h/%h",n,dut.product,want_raw,dut.product_q15,want_q);
  @(negedge clk);checks++;n++;
 end endtask
 initial begin
  force dut.mul_y=fake_mul;force dut.filter_product=fake_bridge;force dut.bridge_loss_product=fake_bridge;
  for(h=0;h<16;h++)for(l=0;l<32768;l++)begin
   case(h)
    0:value={21'd0,l[14:0]};1:value={21'd1,l[14:0]};2:value={21'h1fffff,l[14:0]};3:value={21'h100000,l[14:0]};
    4:value={21'h0fffff,l[14:0]};5:value={21'h000fff,l[14:0]};6:value={21'h1ff000,l[14:0]};7:value={21'h1ffffe,l[14:0]};
    default:value={(21'h13579*(h-7)),l[14:0]};
   endcase
   vector;
  end
  for(k=0;k<1000000;k++)begin rng={rng[34:0],rng[35]^rng[24]^rng[9]^rng[0]};value=rng;vector;end
  if(writes_seen!==5'b11111)$fatal(1,"Q15_CAPTURE_WRITE_COVERAGE");
  $display("POLY_Q15_CAPTURE_PASS vectors=%0d all32768residues/16heads/1Mrandom dedicatedSigned36filter/4filterCapture/bridgeRawOnly/ctx/pause/rst/trigger",checks);$finish;
 end
 initial begin #40000000;$fatal(1,"Q15_CAPTURE_TIMEOUT");end
endmodule
