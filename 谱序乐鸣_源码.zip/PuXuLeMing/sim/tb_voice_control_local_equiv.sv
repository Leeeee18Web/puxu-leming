`timescale 1ns/1ps
module voice_control_local_case #(parameter N=7, PEDAL=1, REL=1)(output reg done=0);
 reg clk=0;always #5 clk=~clk;
 reg rst=1,sample_tick=0,event_valid=0,panic=0,centre=0,pedal_down=0,map_enabled=1,map_apply=0;
 reg [2:0] timbre_select=0;reg [N-1:0] voice_active=0;reg [31:0] event_data=0;
 reg [1:0] knob_mode=1,event_source=0;reg [174:0] map_notes=0;reg [6:0] map_input_base=48;
 wire [N*3-1:0] ta,tb;wire [N-1:0] ga,gb,xa,xb;wire [N*7-1:0] na,nb;wire [N*12-1:0] aa,ab;
 wire [18:0] ra,rb;wire [6:0] ka,kb,lna,lnb,lva,lvb,ma,mb,rka,rkb;
 wire era,erb,rwa,rwb,pa,pb,kva,kvb;wire [4:0] kia,kib;
 final_voice_control #(.VOICE_COUNT(N),.ENABLE_PEDAL(PEDAL),.RELATIVE_KNOB(REL)) dut(
 .clk(clk),.rst(rst),.sample_tick(sample_tick),.event_valid(event_valid),.event_data(event_data),.event_ready(era),
 .panic(panic),.centre(centre),.pedal_down(pedal_down),.timbre_select(timbre_select),.voice_active(voice_active),
 .timbres(ta),.gates(ga),.notes(na),.gains(aa),.triggers(xa),.ratio(ra),.knob(ka),.last_note(lna),.last_velocity(lva),
 .mod_depth(ma),.knob_mode(knob_mode),.raw_knob(rka),.raw_known(rwa),.pickup_wait(pa),.event_source(event_source),
 .map_notes(map_notes),.map_input_base(map_input_base),.map_enabled(map_enabled),.map_apply(map_apply),.key_seen_valid(kva),.key_seen_index(kia),.ready_raw());
 final_voice_decode_reference #(.VOICE_COUNT(N),.ENABLE_PEDAL(PEDAL),.RELATIVE_KNOB(REL)) ref_old(
 .clk(clk),.rst(rst),.sample_tick(sample_tick),.event_valid(event_valid&&era),.event_data(event_data),.event_ready(erb),
 .panic(panic),.centre(centre),.pedal_down(pedal_down),.timbre_select(timbre_select),.voice_active(voice_active),
 .timbres(tb),.gates(gb),.notes(nb),.gains(ab),.triggers(xb),.ratio(rb),.knob(kb),.last_note(lnb),.last_velocity(lvb),
 .mod_depth(mb),.knob_mode(knob_mode),.raw_knob(rkb),.raw_known(rwb),.pickup_wait(pb),.event_source(event_source),
 .map_notes(map_notes),.map_input_base(map_input_base),.map_enabled(map_enabled),.map_apply(map_apply),.key_seen_valid(kvb),.key_seen_index(kib));
 integer match_count=0,free_count=0,tail_count=0,pedal_count=0,full_count=0;
 reg last_accepted;integer accepted=0,canceled=0;
 integer checks=0,events=0,i,j,seed=32'h38a1+N+PEDAL,rv,kind;
 task tick;begin
  @(posedge clk);last_accepted=event_valid&&era;
  if(last_accepted&&!rst&&!panic&&!(N>4&&map_apply))accepted=accepted+1;
  if(!rst&&!panic&&!map_apply&&last_accepted&&event_data[7:4]==9&&event_data[22:16]!=0&&!event_data[15]&&!event_data[23])begin
   if(|ref_old.match_slots)match_count=match_count+1;
   else if(|ref_old.free_slots)free_count=free_count+1;
   else if(|ref_old.oldest_tails)tail_count=tail_count+1;
   else if(PEDAL&&(|ref_old.oldest_pedals))pedal_count=pedal_count+1;
   else full_count=full_count+1;
  end
  #1;checks=checks+1;
  if({ta,ga,na,aa,xa,ra,ka,lna,lva,ma,rka,rwa,pa,kva,kia}!=={tb,gb,nb,ab,xb,rb,kb,lnb,lvb,mb,rkb,rwb,pb,kvb,kib})
   $fatal(1,"OUTPUT_MISMATCH N%0d pedal%0d cycle%0d source%0d data%h",N,PEDAL,checks,event_source,event_data);
  if({dut.held,dut.sustain,dut.target,dut.anchor_valid,dut.pickup_owned,dut.previous_mode}!=={ref_old.held,ref_old.sustain,ref_old.target,ref_old.anchor_valid,ref_old.pickup_owned,ref_old.previous_mode})$fatal(1,"STATE_MISMATCH N%0d cycle%0d",N,checks);
  for(j=0;j<N;j=j+1)if({dut.owners[j],dut.channels[j],dut.original_keys[j],dut.newer[j]}!=={ref_old.owners[j],ref_old.channels[j],ref_old.original_keys[j],ref_old.newer[j]})$fatal(1,"IDENTITY_MISMATCH N%0d cycle%0d slot%0d",N,checks,j);
  @(negedge clk);
 end endtask
 task send(input [1:0] src,input [7:0] status,input [6:0] key,vel,index);begin
  event_valid=1;event_source=src;event_data={index,src[0],1'b0,vel,1'b0,key,status};events=events+1;tick;
  if(rst||panic||(N>4&&map_apply))canceled=canceled+1;
  else while(!last_accepted)tick;
  event_valid=0;
 end endtask
 initial begin
  for(i=0;i<25;i=i+1)map_notes[i*7+:7]=60+(i%12);
  tick;rst=0;tick;
  // Fill held slots, ignore the next onset, and retrigger/release duplicate identities.
  for(i=0;i<N;i=i+1)send(1,8'h90,i+48,90,0);
  send(2,8'h93,100,111,0);if(xa!=0)$fatal(1,"HELD_PROTECTION N%0d",N);
  send(1,8'h90,48,100,0);send(2,8'h80,48,0,0);send(1,8'h81,48,0,0);send(1,8'h80,48,0,0);
  voice_active={N{1'b1}};send(2,8'h92,99,88,0);
  // Physical-pedal-only held note yields, then CC64 ownership and source/channel cleanup.
  panic=1;tick;panic=0;voice_active={N{1'b1}};pedal_down=1;
  for(i=0;i<N;i=i+1)begin send(1,8'h90,i+48,90,0);send(1,8'h80,i+48,0,0);end
  send(2,8'h93,100,111,0);pedal_down=0;send(1,8'hb0,64,127,0);send(1,8'h90,52,90,0);send(1,8'h80,52,0,0);send(2,8'hb0,64,0,0);send(1,8'hb0,64,0,0);
  // Indexed WiFi original keys are independent of the mapped sounding pitch.
  panic=1;tick;panic=0;
  send(3,8'h9e,70,80,4);send(3,8'h9e,70,99,5);send(3,8'h8e,70,0,4);
  map_notes[5*7+:7]=90;send(3,8'h8e,12,0,5);
  map_apply=1;send(0,8'h90,48,90,0);map_apply=0;send(1,8'h80,48,0,0);
  send(0,8'h90,48,90,0);send(1,8'h90,48,100,0);send(0,8'hff,0,0,0);send(1,8'h80,48,0,0);
  // Back-to-back legal, malformed, note, CC, mapping, disconnect, pedal and knob cycles.
  for(i=0;i<16000;i=i+1)begin
   rv=$random(seed);timbre_select=rv[4:2];voice_active=rv>>5;
   pedal_down=rv[10];sample_tick=rv[11];panic=(rv[21:13]==0);centre=(rv[28:22]==0);map_apply=(rv[20:13]==1);map_enabled=rv[30];knob_mode=rv[31:30];
   if(!event_valid)begin
   event_valid=rv[12];event_source=rv[1:0];
   rv=$random(seed);kind=(rv&15);event_data=rv;
   case(kind)
    0,1,2,3,4:event_data={rv[31:25],rv[24],1'b0,rv[22:16],1'b0,rv[14:8],4'h9,rv[3:0]};
    5,6,7:event_data={rv[31:25],rv[24],1'b0,7'd0,1'b0,rv[14:8],4'h8,rv[3:0]};
    8:event_data={rv[31:25],rv[24],1'b0,rv[22:16],1'b0,7'd64,4'hb,rv[3:0]};
    9:event_data={rv[31:25],rv[24],1'b0,rv[22:16],1'b0,7'd120,4'hb,rv[3:0]};
    10:event_data={rv[31:25],rv[24],1'b0,rv[22:16],1'b0,7'd123,4'hb,rv[3:0]};
    11:event_data[7:0]=8'hff;
    12:event_data[7:0]=8'h9e;
    13:event_data[7:0]=8'h8e;
   endcase
   events=events+event_valid;end
   tick;
   if(event_valid&&(rst||panic||(N>4&&map_apply)))begin canceled=canceled+1;event_valid=0;end
   else if(last_accepted)event_valid=0;
  end
  panic=0;map_apply=0;
  while(event_valid)begin tick;if(last_accepted)event_valid=0;end
  if(events!=accepted+canceled)$fatal(1,"EVENT_ACCOUNTING N%0d generated%0d accepted%0d canceled%0d",N,events,accepted,canceled);
  if(match_count==0||free_count==0||tail_count==0||full_count==0||(PEDAL&&pedal_count==0))$fatal(1,"COVERAGE N%0d match%0d free%0d tail%0d pedal%0d full%0d",N,match_count,free_count,tail_count,pedal_count,full_count);
  $display("PASS VOICE_LOCAL N%0d pedal%0d rel%0d checks%0d events%0d accepted%0d canceled%0d match%0d free%0d tail%0d pedal%0d full%0d",N,PEDAL,REL,checks,events,accepted,canceled,match_count,free_count,tail_count,pedal_count,full_count);done=1;
 end
endmodule
module tb_voice_control_local_equiv;
 wire [3:0] done;
 voice_control_local_case #(.N(7)) c7(done[0]);
 voice_control_local_case #(.N(4),.REL(0)) c4(done[1]);
 voice_control_local_case #(.N(25)) c25(done[2]);
 voice_control_local_case #(.N(4),.REL(0),.PEDAL(0)) legacy(done[3]);
 initial begin wait(&done);$display("PASS VOICE_LOCAL_ALL");$finish;end
endmodule
