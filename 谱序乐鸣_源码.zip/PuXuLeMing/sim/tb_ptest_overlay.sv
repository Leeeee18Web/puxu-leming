`timescale 1ns/1ps
module tb_ptest_overlay;
 reg clk=0,rstn=0,den=0;reg[13:0]x=0,y=0;always #5 clk=~clk;
 wire[23:0]out;integer checks=0,letters=0,digits=0,markers=0;
 reg[7:0]expected_area=0,expected_zero=0,expected_marker=0;reg[255:0]debug_data=0;
 ptest_overlay dut(.pixel_clk(clk),.rstn(rstn),.x(x),.y(y),.den(den),
  .debug_data(debug_data),.rgb_in(24'h563412),.rgb_out(out));
 // Reference '0' in the supplied public 5x7 font; fixed column zero stroke.
 function automatic zero_left(input integer yy);begin
  zero_left=yy>=2&&yy<12;
 end endfunction
 always @(posedge clk)begin
  if(!rstn)begin expected_area<=0;expected_zero<=0;expected_marker<=0;end
  else begin
   expected_area<={expected_area[6:0],den&&x>=512&&x<768&&y<128};
   expected_zero<={expected_zero[6:0],den&&x==576&&zero_left(y)};
   expected_marker<={expected_marker[6:0],den&&debug_data[111]&&debug_data[110]&&debug_data[226]&&
    ((x==120&&y>=296&&y<=304)||(y==300&&x>=116&&x<=124))};
   #1;checks=checks+1;
   if(expected_area[7])begin
    if(out!==24'h8cffe2&&out!==24'h081b28)$fatal(1,"FAIL overlay area/latency");
    if(out==24'h8cffe2)letters=letters+1;
   end else if(expected_marker[7])begin markers=markers+1;if(out!==24'hffb347)$fatal(1,"FAIL touch marker alignment");end
   else if(out!==24'h563412)$fatal(1,"FAIL overlay changed pixel outside panel");
   if(expected_zero[7])begin digits=digits+1;if(out!==24'h8cffe2)$fatal(1,"FAIL zero glyph/coordinate alignment");end
  end
 end
 integer a,b;
 initial begin
  repeat(10)@(negedge clk);rstn=1;den=1;
  for(b=0;b<144;b=b+1)for(a=480;a<800;a=a+1)begin @(negedge clk);x=a;y=b;end
  @(negedge clk);den=0;repeat(10)@(negedge clk);
  debug_data[111]=1;debug_data[110]=1;debug_data[226]=1;debug_data[63:32]={16'd300,16'd120};den=1;
  for(b=290;b<311;b=b+1)for(a=110;a<131;a=a+1)begin @(negedge clk);x=a;y=b;end
  @(negedge clk);den=0;repeat(10)@(negedge clk);debug_data[111]=0;den=1;
  for(b=290;b<311;b=b+1)for(a=110;a<131;a=a+1)begin @(negedge clk);x=a;y=b;end
  @(negedge clk);den=0;repeat(10)@(negedge clk);
  if(letters<1000||digits!=10||markers!=17)$fatal(1,"FAIL diagnostic text/marker missing");
  $display("PTEST_OVERLAY_PASS checks=%0d text_pixels=%0d zero_strokes=%0d marker_pixels=%0d",checks,letters,digits,markers);$finish;
 end
 initial begin #2000000;$fatal(1,"timeout");end
endmodule
