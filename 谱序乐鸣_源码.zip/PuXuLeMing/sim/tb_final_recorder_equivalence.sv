`timescale 1ns/1ps
module tb_final_recorder_equivalence;
 reg clk=0,rst=1;always #10 clk=~clk;
 reg[5:0]phase=0;always @(posedge clk)phase<=phase+1'b1;
 wire sample_tick=phase==63;
 reg record_toggle=0,replay_toggle=0,clear=0,panic=0;
 reg[3:0]in_gates=0,in_triggers=0;reg[27:0]in_notes=0;
 reg[47:0]in_gains=0;reg[11:0]in_timbres=0;reg[18:0]in_ratio=262144;
 reg[6:0]in_mod_depth=0;reg[31:0]in_synth_config=0;
 wire[3:0]g[0:1],t[0:1];wire[27:0]n[0:1];wire[47:0]v[0:1];wire[11:0]tm[0:1];wire[18:0]r[0:1];wire[6:0]m[0:1];wire[31:0]c[0:1];
 wire rec[0:1],play[0:1],full[0:1],limit[0:1],ready[0:1];wire[12:0]count[0:1];wire[31:0]time_samples[0:1],duration[0:1];
 wire[95:0] exported[0:1];wire er[0:1];wire[31:0]take[0:1];
 final_recorder #(.EVENT_CAPACITY(32),.MAX_SAMPLES(40))dut(.observer_gains(),.clk(clk),.rst(rst),.sample_tick(sample_tick),.record_toggle(record_toggle),.replay_toggle(replay_toggle),.clear(clear),.panic(panic),
  .in_gates(in_gates),.in_triggers(in_triggers),.in_notes(in_notes),.in_gains(in_gains),.in_timbres(in_timbres),.in_ratio(in_ratio),.in_mod_depth(in_mod_depth),.in_synth_config(in_synth_config),
  .out_gates(g[0]),.out_triggers(t[0]),.out_notes(n[0]),.out_gains(v[0]),.out_timbres(tm[0]),.out_ratio(r[0]),.out_mod_depth(m[0]),.out_synth_config(c[0]),
  .recording(rec[0]),.replaying(play[0]),.full(full[0]),.time_limit(limit[0]),.replay_frame_ready(ready[0]),.count(count[0]),.time_samples(time_samples[0]),.duration_samples(duration[0]),.export_address(12'd0),.export_word(exported[0]),.export_ready(er[0]),.take_id(take[0]),.preview_rst(1'b0),.preview_gates('0),.preview_notes('0),.preview_gains('0),.preview_timbres('0),.preview_ratio('0),.preview_mod_depth('0),.preview_synth_config('0));
 final_recorder_reference #(.EVENT_CAPACITY(32),.MAX_SAMPLES(40))reference(.clk(clk),.rst(rst),.sample_tick(sample_tick),.record_toggle(record_toggle),.replay_toggle(replay_toggle),.clear(clear),.panic(panic),
  .in_gates(in_gates),.in_triggers(in_triggers),.in_notes(in_notes),.in_gains(in_gains),.in_timbres(in_timbres),.in_ratio(in_ratio),.in_mod_depth(in_mod_depth),.in_synth_config(in_synth_config),
  .out_gates(g[1]),.out_triggers(t[1]),.out_notes(n[1]),.out_gains(v[1]),.out_timbres(tm[1]),.out_ratio(r[1]),.out_mod_depth(m[1]),.out_synth_config(c[1]),
  .recording(rec[1]),.replaying(play[1]),.full(full[1]),.time_limit(limit[1]),.replay_frame_ready(ready[1]),.count(count[1]),.time_samples(time_samples[1]),.duration_samples(duration[1]),.export_address(12'd0),.export_word(exported[1]),.export_ready(er[1]),.take_id(take[1]));
 reg prior_export_ready=0;
 integer checks=0,frames=0,plays=0,fulls=0,limits=0,seed=32'h31415926,k,j;
 always @(negedge clk)if(!rst)begin
  checks++;
  // Playback preparation may take one extra clock/event. The real audio
  // consumes the controls at sample_tick; exported RAM has a synchronous read.
  if({er[0],take[0],rec[0],play[0],full[0],limit[0],count[0],time_samples[0],duration[0]}!==
     {er[1],take[1],rec[1],play[1],full[1],limit[1],count[1],time_samples[1],duration[1]})
   $fatal(1,"RECORDER_METADATA clock=%0d phase=%0d",checks,phase);
  if(er[0]&&prior_export_ready&&exported[0]!==exported[1])$fatal(1,"RECORDER_EXPORT_WORD");
  prior_export_ready=er[0];
  if(sample_tick)begin
   if(ready[0]!==ready[1]||(play[0]&&!ready[0]))$fatal(1,"RECORDER_FRAME_NOT_READY");
   if({g[0],t[0],n[0],v[0],tm[0],r[0],m[0],c[0]}!=={g[1],t[1],n[1],v[1],tm[1],r[1],m[1],c[1]})
    $fatal(1,"RECORDER_AUDIO_FRAME clock=%0d",checks);
  end
  if(sample_tick)begin frames++;if(play[0])plays++;if(full[0])fulls++;if(limit[0])limits++;end
 end
 task frame(input bit record_cmd,replay_cmd);begin
  @(posedge clk);while(phase!=10)@(posedge clk);
  @(negedge clk);record_toggle=record_cmd;replay_toggle=replay_cmd;
  @(negedge clk);record_toggle=0;replay_toggle=0;
  @(posedge sample_tick);repeat(3)@(posedge clk);
 end endtask
 initial begin
  repeat(5)@(negedge clk);rst=0;
  in_gates=1;in_gains=100;in_notes=60;frame(1,0);
  repeat(4)frame(0,0);in_triggers=1;in_notes=62;frame(0,1);in_triggers=0;
  repeat(15)frame(0,0);frame(1,0);repeat(45)frame(0,0);frame(0,1);repeat(45)frame(0,0);
  clear=1;frame(0,0);clear=0;frame(1,0);
  for(k=0;k<15;k++)begin in_notes=k;in_gates=k;in_gains=k*987;in_timbres=k;frame(0,0);end
  frame(0,1);repeat(20)frame(0,0);
  for(k=0;k<700;k++)begin
   j=$unsigned($random(seed))%32;
   if(j<12)begin in_gates=$random(seed);in_triggers=$random(seed);in_notes=$random(seed);in_gains={$random(seed),$random(seed)};in_timbres=$random(seed);end
   if(j==12)begin in_ratio=$random(seed);in_mod_depth=$random(seed);in_synth_config=$random(seed);end
   clear=j==13;panic=j==14;frame(j==15||j==17,j==16||j==17);in_triggers=0;clear=0;panic=0;
  end
  if(plays==0||fulls==0||limits==0)$fatal(1,"RECORDER_EQ coverage incomplete plays=%0d full=%0d limit=%0d",plays,fulls,limits);
  $display("RECORDER_EQ_PASS clocks=%0d frames=%0d replayframes=%0d fullframes=%0d limitframes=%0d",checks,frames,plays,fulls,limits);$finish;
 end
 initial begin #10000000;$fatal(1,"RECORDER_EQ timeout");end
endmodule
