`timescale 1ns/1ps
module tb_history_rom_root;
 wire done;history_rom_root_driver original(done);
 initial begin wait(done);$finish;end
 initial begin #150000000;$fatal(1,"HISTORY_ROM_ROOT_TIMEOUT");end
 wire[10:0]old_pitch;wire[9:0]old_count;wire[16:0]old_curve;
 tone_history_before_sync_rom #(.TOTAL_SAMPLES(1464844),.READ_GATED(1),.PIPELINED_READ(1)) old(
 .clk(original.dut.visual.history.clk),.rst(original.dut.visual.history.rst),.restart(original.dut.visual.history.restart),
 .sample_tick(original.dut.visual.history.sample_tick),.recording(original.dut.visual.history.recording),
 .pitch(original.dut.visual.history.pitch),.pitch_valid(original.dut.visual.history.pitch_valid),
 .pixel_clk(original.dut.pixel_clk),.pixel_rstn(original.dut.visual.history.pixel_rstn),
 .frame_start(original.dut.visual.history.frame_start),.read_addr(original.dut.visual.history.read_addr),.read_enable(original.dut.visual.history.read_enable),
 .pitch_data(old_pitch),.visible_count(old_count),.curve_sum(old_curve));
 integer checks=0,de_checks=0,read_checks=0,nonempty_reads=0,zero_unknown=0,source_checks=0;realtime first_real_edge=0;
 always @(posedge original.dut.pixel_clk)begin
  if($realtime==0)begin
   if($isunknown({original.dut.visual.history.read_addr,original.dut.visual.history.visible_count}))zero_unknown++;
   #0.001;
   if(original.dut.video_lock!==0||original.dut.video_rstn!==0||original.dut.visual.history.pixel_rstn!==0||original.dut.den!==0)$fatal(1,"HISTORY_ROM_ZERO_DELTA_WAS_VALID");
   $display("HISTORY_ROM_ZERO_DELTA lock%0b videoResetReleased%0b historyResetReleased%0b DE%0b windowNew%h windowOld%h",original.dut.video_lock,original.dut.video_rstn,original.dut.visual.history.pixel_rstn,original.dut.den,original.dut.visual.history.address_window,old.address_window);
  end else begin
   if($isunknown({original.dut.visual.history.read_addr,original.dut.visual.history.visible_count}))$fatal(1,"HISTORY_ROM_ROOT_UNKNOWN_REAL_EDGE");
   if(first_real_edge==0)first_real_edge=$realtime;
   #0.001;checks++;
   if({original.dut.visual.history.pitch_data,original.dut.visual.history.visible_count,original.dut.visual.history.curve_sum,original.dut.visual.history.display_bank,original.dut.visual.history.seen,original.dut.visual.history.ack}!==
      {old_pitch,old_count,old_curve,old.display_bank,old.seen,old.ack})$fatal(1,"HISTORY_ROM_ROOT_OLD_PUBLIC_OR_ACK");
   if({original.dut.visual.history.address_window,original.dut.visual.history.address_edge,original.dut.visual.history.address_right,original.dut.visual.history.address_bank,original.dut.visual.history.address_count,original.dut.visual.history.address_column,original.dut.visual.history.address_valid,original.dut.visual.history.address_enable}!==
      {old.address_window,old.address_edge,old.address_right,old.address_bank,old.address_count,old.address_column,old.address_valid,old.address_enable})$fatal(1,"HISTORY_ROM_ROOT_OLD_STAGE_EPOCH");
   if(original.dut.den)de_checks++;
   if(original.dut.visual.history.read_enable)read_checks++;
   if(original.dut.den&&original.dut.visual.history.read_enable&&old_count!=0)nonempty_reads++;
  end
 end
 always @(posedge original.dut.clk)begin #0.001;
  if({original.dut.visual.history.source_count,original.dut.visual.history.source_bank,original.dut.visual.history.writer,original.dut.visual.history.column,original.dut.visual.history.publish,original.dut.visual.history.ack_sync}!==
     {old.source_count,old.source_bank,old.writer,old.column,old.publish,old.ack_sync})$fatal(1,"HISTORY_ROM_ROOT_OLD_SOURCE_MAILBOX");source_checks++;
 end
 final begin
  if(checks==0||de_checks==0||read_checks==0||nonempty_reads==0)$error("HISTORY_ROM_ROOT_COVERAGE");
  $display("HISTORY_ROM_ROOT_OLD_PASS knownRealEdges%0d DE%0d readEnabled%0d nonemptyVisibleReads%0d sourceClocks%0d zeroDeltaUnknown%0d firstRealEdgeNs%0f overwrittenBeforeConsumer exactOldPublicAndBankACK",checks,de_checks,read_checks,nonempty_reads,source_checks,zero_unknown,first_real_edge);
 end
endmodule

// Real production hub, original IO/firmware-boundary stubs and native timing.
// Use actual HID publication, no forced internal page/count or shortened window.
module history_rom_root_driver(output reg done=0);
 reg clk=0,rstn=0;always #10 clk=~clk;
 tri dp,dm;wire[7:0]led;wire bck,ws,sd,ib,iw,idata;
 hub_play_top dut(.clk(clk),.rstn(rstn),.key1_n(1'b1),.key2_n(1'b1),.uart_rx(1'b1),.uart_tx(),
 .usb_dp(dp),.usb_dm(dm),.hp_bck(bck),.hp_ws(ws),.hp_din(sd),.i2s_bck(ib),.i2s_ws(iw),.i2s_sd(idata),
 .pa_en(),.led_o(led),.tmds_clk_p_0(),.tmds_clk_n_0(),.tmds_d_p_0(),.tmds_d_n_0());
 task touch(input bit down);begin dut.soc.hid_report(300,280,down,1);repeat(40)@(negedge clk);end endtask
 initial begin
  repeat(10)@(negedge clk);rstn=1;repeat(1000)@(negedge clk);
  dut.soc.ptest_debug[255:224]=32'h0c;repeat(80)@(negedge clk);
  touch(0);touch(1);touch(0);
  if(dut.page!=1||dut.mode!=1)$fatal(1,"HISTORY_ROM_ROOT_REAL_NAV");
  wait(dut.visual.history.visible_count>0);
  repeat(2000)@(posedge dut.pixel_clk);done=1;
 end
endmodule
