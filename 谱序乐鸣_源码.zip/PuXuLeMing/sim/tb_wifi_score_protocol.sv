`timescale 1ns/1ps
module tb_wifi_score_protocol;
reg clk=0;always #5 clk=~clk;reg rst=1;reg[7:0]rx=0;reg rv=0;wire rr;wire[7:0]tx;wire tv;wire[31:0]ed;wire ev;integer i,j,n,ri=0,fd;reg[175:0]req[0:517];
p8_wifi_control dut(.map_apply_audio(),.map_apply_fx(),.clk(clk),.rst(rst),.sample_tick(1'b0),.playable(1'b1),.clear_notes(1'b0),.live_link_lost(1'b0),.mode(2'd0),.muted(1'b0),.rx_data(rx),.rx_valid(rv),.rx_ready(rr),.tx_data(tx),.tx_valid(tv),.tx_ready(1'b1),.event_data(ed),.event_valid(ev),.event_ready(1'b1));
always @(posedge clk)if(tv)begin $fwrite(fd,"%02x",tx);ri=ri+1;if(ri%22==0)$fwrite(fd,"\n");end
initial begin fd=$fopen("actual_pw_replies.hex","w");$readmemh("fixtures/pw512.hex",req);repeat(4)@(negedge clk);rst=0;
for(i=0;i<518;i=i+1)begin
 for(j=0;j<22;j=j+1)begin @(negedge clk);n=0;while(!rr)begin @(negedge clk);n=n+1;if(n>20000)$fatal(1,"FAIL rx");end rx=req[i][(21-j)*8+:8];rv=1;@(negedge clk);rv=0;end
 n=0;while(ri<(i+1)*22)begin @(negedge clk);n=n+1;if(n>20000)$fatal(1,"FAIL ACK %0d",i);end
end
$fclose(fd);$display("REAL_PROTOCOL_RTL_PASS frames=%0d",ri/22);$finish;end
initial begin #50000000;$fatal(1,"FAIL timeout");end
endmodule
