`timescale 1ns/1ps
module poly_param_local_test #(parameter N=2);
 reg clk=0;always #10 clk=~clk;
 reg rst=1,start=0;reg[N-1:0]gates=0,triggers=0;
 reg[N*24-1:0]steps=0;reg[N*12-1:0]gains=0;reg[N*3-1:0]timbres=0;
 wire busy,error;
 poly_voice_worker #(.CONTEXTS(N)) dut(.clk(clk),.rst(rst),.start(start),.gates(gates),.triggers(triggers),
  .steps(steps),.gains(gains),.timbres(timbres),.samples(),.envelopes(),.active(),.busy(busy),
  .deadline_error(error),.out_valid(),.out_index(),.out_sample(),.model_reset({3{rst}}),.control_resetn_early(1'b1));
 integer frame,slot,c,checks=0;reg[23:0]want_step;reg[11:0]want_gain;reg[2:0]want_tone;
 initial begin
  repeat(5)@(negedge clk);rst=0;
  for(frame=0;frame<8;frame=frame+1)begin
   start=1;@(negedge clk);start=0;
   for(slot=0;slot<N;slot=slot+1)begin
    wait(dut.running&&dut.phase==0);
    want_step=45000+frame*1200+slot*16000;want_gain=900+frame*50+slot*300;want_tone=(frame+slot)%4;
    steps[slot*24+:24]=want_step;gains[slot*12+:12]=want_gain;timbres[slot*3+:3]=want_tone;
    gates[slot]=1;triggers[slot]=0;
    @(negedge clk);
    $display("PARAM_CAPTURE N%0d frame%0d slot%0d phase%0d t%0t step%0d gain%0d tone%0d",N,frame,slot,dut.phase,$time,dut.step,dut.gain,dut.tone);
    // Inputs change after preparation; selected parameters must remain local until this slot ends.
    steps[slot*24+:24]=want_step+24'd777;gains[slot*12+:12]=want_gain+12'd111;timbres[slot*3+:3]=(want_tone+1)%4;
    gates[slot]=0;triggers[slot]=1;#1;
    for(c=1;c<=135;c=c+1)begin
     if(dut.step!==want_step||dut.gain!==want_gain||dut.tone!==want_tone)
      $fatal(1,"PARAM_BOUNDARY_MISSING N%0d frame%0d slot%0d phase%0d",N,frame,slot,dut.phase);
     if(dut.is_ep!==(want_tone==0)||dut.is_strings!==(want_tone==1||want_tone==2)||dut.is_reed!==(want_tone==3))
      $fatal(1,"PARAM_FAMILY_CHANGED N%0d slot%0d phase%0d",N,slot,dut.phase);
     if(dut.ep_enabled.ep.gate!==0||dut.strings.gate!==0||dut.reed.gate!==0)$fatal(1,"PARAM_GATE_DELAYED");
     if(dut.phase==5&&!dut.trigger_fire)$fatal(1,"PARAM_TRIGGER_DELAYED");
     checks=checks+1;@(negedge clk);
    end
   end
   wait(!busy);@(negedge clk);
   if(error)$fatal(1,"PARAM_DEADLINE N%0d",N);
  end
  $display("POLY_PARAM_LOCAL_PASS N%0d checks%0d all4families gate/trigger live same phase1/5/134/135",N,checks);$finish;
 end
 initial begin #1000000;$fatal(1,"PARAM_TIMEOUT");end
endmodule
module tb_poly_param_local;poly_param_local_test #(.N(2)) test();endmodule
module tb_poly_param_local1;poly_param_local_test #(.N(1)) test();endmodule
