`timescale 1ns/1ps
module tb_p8_gesture_link;
 reg clk=0,rstn=0,rx=1;always #10 clk=~clk;
 tri dp,dm;wire tx,bck,ws,sd,ib,iw,idata;
 hub_play_top dut(.clk(clk),.rstn(rstn),.key1_n(1'b1),.key2_n(1'b1),.uart_rx(rx),.uart_tx(tx),
  .usb_dp(dp),.usb_dm(dm),.hp_bck(bck),.hp_ws(ws),.hp_din(sd),.i2s_bck(ib),.i2s_ws(iw),.i2s_sd(idata),
  .pa_en(),.led_o(),.tmds_clk_p_0(),.tmds_clk_n_0(),.tmds_d_p_0(),.tmds_d_n_0());
 // Only watchdog duration is accelerated here. Separate bench verifies actual500ms.
 defparam dut.host_link.WATCHDOG_MS=30;
 reg[7:0]stimulus[0:611];string outdir;integer fd;
 integer checks=0,host_events=0,pcm_nz=0,i2s_nz=0,pt_nz=0,before_events,j;
 reg[6:0]expected_notes[0:6];
 wire[15:0]left,right;wire serial_valid;
 i2s_rx16 decoder(.clk(clk),.rst(dut.rst),.bck(ib),.ws(iw),.sd(idata),.pcm_l(left),.pcm_r(right),.frame_valid(serial_valid));
 reg[15:0]pt_shift=0;integer pt_bits=0;
 always @(posedge bck)if(!dut.rst)begin
  pt_shift={pt_shift[14:0],sd};pt_bits=pt_bits+1;
  if(pt_bits==16)begin if(pt_shift!=0)pt_nz=pt_nz+1;pt_bits=0;end
 end
 always @(posedge clk)if(!dut.rst)begin
  if(dut.gesture_event_valid&&dut.gesture_event_ready)host_events=host_events+1;
  if(dut.sample_tick&&dut.pcm!=0)pcm_nz=pcm_nz+1;
  if(serial_valid&&(left!=0||right!=0))i2s_nz=i2s_nz+1;
 end
 task check(input bit ok,input string message);begin
  checks=checks+1;if(!ok)$fatal(1,"P8_GESTURE_FAIL %s @%0t",message,$time);
 end endtask
 task send_byte(input[7:0]b);integer j;begin
  @(negedge clk);rx=0;repeat(434)@(negedge clk);
  for(j=0;j<8;j=j+1)begin rx=b[j];repeat(434)@(negedge clk);end
  rx=1;repeat(434)@(negedge clk);
 end endtask
 task command(input integer n);integer j;begin
  for(j=0;j<18;j=j+1)send_byte(stimulus[n*18+j]);
  repeat(200000)@(negedge clk);
 end endtask
 task wait_ms(input integer n);begin repeat(n*50000)@(negedge clk);end endtask
 task tap(input integer x,y);begin
  dut.soc.hid_report(x,y,0,1);repeat(3000)@(negedge clk);
  dut.soc.hid_report(x,y,1,1);repeat(3000)@(negedge clk);
  dut.soc.hid_report(x,y,0,1);repeat(3000)@(negedge clk);
 end endtask
 initial begin:read_tx
  reg[7:0]b;integer k;
  wait(fd!=0);
  forever begin
   @(negedge tx);#13020;
   for(k=0;k<8;k=k+1)begin b[k]=tx;#8680;end
   check(tx===1'b1,"UART stop bit");$fdisplay(fd,"%02h",b);$fflush(fd);
  end
 end
 initial begin
  if(!$value$plusargs("OUTDIR=%s",outdir))$fatal(1,"OUTDIR required");
  $readmemh({outdir,"/stimulus.hex"},stimulus);fd=$fopen({outdir,"/uart_reply.hex"},"w");
  repeat(10)@(negedge clk);rstn=1;repeat(1000)@(negedge clk);
  check(dut.page==0&&dut.mode==0,"unchanged P8 home startup");
  command(0);check(host_events==0,"handshake cannot sound");
  command(1);check($countones(dut.live_gates)==1&&dut.last_note==60,"C4 reaches actual P8 controller from home");
  before_events=host_events;command(2);check(host_events==before_events,"held heartbeat never retriggers");
  command(3);check(host_events==before_events+2&&dut.last_note==62,"change emits old-off then new-on");
  command(4);check(dut.live_gates==0,"explicit gesture off");
  command(5);dut.soc.midi_event(32'h00644090);repeat(2000)@(negedge clk);
  check($countones(dut.live_gates)==2,"USB and gesture own same E4 separately");
  command(6);check($countones(dut.live_gates)==1,"gesture off preserves USB same-pitch note");
  dut.soc.midi_event(32'h00004080);repeat(2000)@(negedge clk);check(dut.live_gates==0,"USB off keeps normal routing");
  command(7);before_events=host_events;
  command(8);check(host_events==before_events,"bad CRC cannot alter sound");
  command(9);check(host_events==before_events,"Studio magic cannot control P8");
  command(10);check(host_events==before_events,"undefined8 rejected");
  wait_ms(35);check(dut.live_gates==0&&host_events==before_events+1,"loss watchdog emits exactly one off");command(11);
  tap(300,280);tap(656,96);check(dut.mode==1&&dut.page==5,"original touchscreen perform/keyboard navigation");
  dut.soc.hid_report(64,550,1,1);repeat(3000)@(negedge clk);check($countones(dut.live_gates)==1,"touch key sounds");
  command(18);check($countones(dut.live_gates)==2,"touch and gesture coexist");
  wait_ms(35);check($countones(dut.live_gates)==1,"watchdog preserves held touchscreen note");
  dut.soc.hid_report(64,550,0,1);repeat(3000)@(negedge clk);
  tap(480,32);check(dut.muted,"original screen mute");command(12);check(dut.host_link.held_note==0,"muted gesture refused");
  tap(480,32);command(13);check($countones(dut.live_gates)==1,"unmute restores gesture availability");command(14);
  tap(620,200);check(dut.pattern_mode==2,"original chord selection preserved");
  command(15);check(dut.pattern_count==0&&dut.host_link.held_note==0,"gesture cannot pollute silent pattern selection");command(16);
  tap(64,550);check(dut.pattern_count==1,"touch pattern selection still works");
  tap(928,200);repeat(10000)@(negedge clk);check(dut.pattern_gates!=0,"original chord trigger still sounds");
  tap(620,200);check(dut.pattern_mode==0,"same button restores direct play");
  tap(300,32);check(dut.mode==2,"original auto mode");command(17);check(dut.host_link.held_note==0,"no gesture injection into automatic score");
  tap(180,32);command(18);check(dut.mode==1&&$countones(dut.live_gates)==1,"perform mode restores gesture");command(19);
  check(dut.live_gates==0,"final gesture release");
  expected_notes[0]=60;expected_notes[1]=62;expected_notes[2]=64;expected_notes[3]=65;
  expected_notes[4]=67;expected_notes[5]=69;expected_notes[6]=71;
  for(j=0;j<7;j=j+1)begin
   command(20+j*2);check($countones(dut.live_gates)==1&&dut.last_note==expected_notes[j],"each of seven gestures reaches its exact MIDI note");
   command(21+j*2);check(dut.live_gates==0,"each of seven gestures releases");
  end
  check(pcm_nz>10&&i2s_nz>10&&pt_nz>10,"actual PCM and independently decoded serial audio nonzero");
  $display("P8_GESTURE_PASS checks=%0d events=%0d PCM=%0d I2S=%0d PT=%0d",checks,host_events,pcm_nz,i2s_nz,pt_nz);
  $fclose(fd);$finish;
 end
 initial begin #400000000;$fatal(1,"P8 gesture bench deadline");end
endmodule
