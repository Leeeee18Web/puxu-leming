`timescale 1ns/1ps
module tb_p8_pattern_panel;
 reg clk=0;always #5 clk=~clk;
 reg rstn=0,den=0,hs=0,vs=0;
 reg [13:0] x=0,y=0;reg [2:0] page=5;reg [1:0] mode=1;
 reg [1:0] pattern_mode=0;reg [6:0] pattern_selected=0;reg [48:0] pattern_notes=0;
 reg pattern_busy=0,pattern_full=0;reg [2:0] pattern_count=0;
 reg [6:0] gates=0;reg [48:0] notes=0;
 wire [23:0] rgb;wire de,ho,vo;integer checks=0,m,k,i;
 p8_panel dut(.pixel_clk(clk),.rstn(rstn),.den(den),.hsync(hs),.vsync(vs),.x(x),.y(y),
 .page(page),.mode(mode),.playing(1'b0),.muted(1'b0),.note_valid(1'b0),.next_note(7'd64),
 .base_note(7'd60),.gates(gates),.notes(notes),.gains(84'd0),.knob(7'd64),.raw_knob(7'd0),
 .raw_known(1'b0),.pickup_wait(1'b0),.knob_mode(2'd0),.touch_state(2'd0),
 .lesson_target(7'd60),.lesson_feedback_note(7'd61),.lesson_feedback(2'd1),
 .lesson_position(6'd0),.lesson_done(1'b0),.last_note(7'd60),.last_velocity(7'd96),.mod_depth(7'd0),
 .wave_data(48'd0),.spectrum_data(8'd0),.spectrum_peak(8'd0),.spectrum_zoom(2'd0),.visual_valid(1'b0),
 .tone_data(11'd0),.tone_curve(17'd0),.tone_count(10'd0),.xy_data(1'b0),.xy_valid(1'b0),.xy_settings(6'd0),
`ifdef P8_PATTERN_NEW
 .pattern_mode(pattern_mode),.pattern_selected(pattern_selected),.pattern_notes(pattern_notes),
 .pattern_busy(pattern_busy),.pattern_count(pattern_count),.pattern_full(pattern_full),
`endif
 .wave_addr(),.tone_addr(),.spectrum_addr(),.xy_addr(),.rgb(rgb),.den_out(de),.hsync_out(ho),.vsync_out(vo));
 task probe(input integer xx,yy,input [23:0] expected);
 begin x=xx;y=yy;den=1;repeat(12)begin @(posedge clk);#1;@(negedge clk);end
 checks=checks+1;if(rgb!==expected)$fatal(1,"PATTERN_PANEL_FAIL x%0d y%0d mode%0d pattern%0d expected%h actual%h",xx,yy,mode,pattern_mode,expected,rgb);
 end endtask
 initial begin
 repeat(4)@(negedge clk);rstn=1;
 // The old RTL compiles without new ports and must fail this visual feature assertion.
 probe(416,176,24'h536975);
`ifdef P8_PATTERN_NEW
 for(m=1;m<=3;m=m+1)begin
  pattern_mode=m;pattern_selected=3;pattern_count=2;pattern_notes[6:0]=60;pattern_notes[13:7]=61;
  for(k=1;k<=3;k=k+1)probe(416+(k-1)*144,176,k==m?24'h60d9ed:24'h536975);
  probe(64,550,24'hf5c767);probe(96,320,24'hf5c767);
  gates=1;notes[6:0]=60;probe(64,550,24'hf5c767);probe(96,320,24'hf5c767);
  notes[6:0]=61;probe(96,320,24'hf5c767);probe(64,550,24'hf5c767);gates=0;
  probe(32,550,24'h36434e);probe(76,320,24'h0a1118);
 end
 pattern_busy=1;probe(848,176,24'h78e6af);probe(850,178,24'h244438);
 pattern_busy=0;probe(848,176,24'h536975);
 for(k=0;k<7;k=k+1)begin
  pattern_notes=0;pattern_selected=1<<k;pattern_notes[k*7+:7]=60;
  probe(64,550,24'hf5c767);probe(96,320,24'h101010);
  pattern_notes[k*7+:7]=61;probe(96,320,24'hf5c767);
  pattern_selected=0;probe(96,320,24'h101010);
 end
 pattern_selected=3;pattern_notes[6:0]=60;pattern_notes[13:7]=61;
 pattern_mode=0;probe(64,550,24'hffffff);probe(96,320,24'h101010);
 mode=3;pattern_mode=1;probe(64,550,24'hf5c767);probe(96,320,24'h78e6af);
 probe(416,176,24'h78e6af); // existing follow restart
 mode=2;probe(416,176,24'h10151b);
 for(i=0;i<1024;i=i+1)begin
  if(dut.p8_pattern_hit(i,175)!=0||dut.p8_pattern_hit(i,224)!=0)$fatal(1,"PATTERN geometry vertical");
  k=i>=416&&i<548?1:i>=560&&i<692?2:i>=704&&i<836?3:i>=848&&i<996?4:0;
  if(dut.p8_pattern_hit(i,176)!=k||dut.p8_pattern_hit(i,223)!=k)$fatal(1,"PATTERN geometry horizontal");checks=checks+4;
 end
 // Vary pattern and key context every sample; output must follow input edge N+7.
 mode=1;x=64;y=550;pattern_selected=1;pattern_notes[6:0]=60;
 for(i=0;i<40;i=i+1)begin
  pattern_mode=i%2;@(posedge clk);#1;
  if(i>=7)begin checks=checks+1;if(rgb!==((i-7)%2?24'hf5c767:24'hffffff))$fatal(1,"PATTERN context N+7 i%0d rgb%h",i,rgb);end
  @(negedge clk);
 end
`endif
 $display("PATTERN_PANEL_PASS checks=%0d",checks);$finish;
 end
endmodule
