`timescale 1ns/1ps
module tb_poly_warm_busy_boundary;
 reg clk=0;always #10 clk=~clk;reg rst=1,start=0;wire busy,err;
 poly_voice_worker #(.CONTEXTS(1)) dut(.clk(clk),.rst(rst),.start(start),.gates(1'b1),.triggers(1'b0),.steps(24'd45000),.gains(12'd1000),.timbres(3'd1),
 .samples(),.envelopes(),.active(),.busy(busy),.deadline_error(err),.out_valid(),.out_index(),.out_sample(),.model_reset({3{rst}}),.control_resetn_early(1'b1));
 reg expected;integer c;
 initial begin
  repeat(4)@(negedge clk);rst=0;start=1;@(negedge clk);start=0;
  wait(!busy);@(negedge clk);start=1;@(negedge clk);start=0;
  wait(dut.phase==2);#1;if(dut.fresh_context)$fatal(1,"WARM_BOUNDARY_STIMULUS_FRESH");expected=!dut.selected_busy;
  // Only the live busy output is perturbed after the actual restore edge.
  // The restored busy decision already belongs to this slot's warm period.
  if(expected)force dut.selected_busy=1'b1;else force dut.selected_busy=1'b0;#1;
  for(c=0;c<3;c=c+1)begin
   if(dut.warm_enable!==expected)$fatal(1,"WARM_BUSY_BOUNDARY_MISSING phase%0d",dut.phase);
   @(negedge clk);
  end
  $display("POLY_WARM_BUSY_BOUNDARY_PASS no live line-state-to-worker-warm cone");$finish;
 end
 initial begin #100000;$fatal(1,"WARM_BUSY_BOUNDARY_TIMEOUT");end
endmodule
