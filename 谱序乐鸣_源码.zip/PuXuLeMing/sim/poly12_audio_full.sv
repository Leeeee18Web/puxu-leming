`timescale 1ns/1ps
module tb_poly12_audio;
 parameter TEST_TONE=4,FRAMES=6500;
 reg clk=0;always #10 clk=~clk;reg rst=1;
 reg[11:0]gates=12'hfff,triggers=0;reg[83:0]notes=0;reg[143:0]gains=0;reg[35:0]tones=0;
 reg[18:0]ratio=262144;reg[6:0]modulation=0;reg[31:0]config_word=0;
 wire tick;wire signed[15:0]pcm;wire positive,hb,hw,hd,ib,iw,id;
 wire[11:0]active;wire[287:0]steps;wire[191:0]env;wire error,clip;
 poly25_audio #(.VOICE_COUNT(12),.ENABLE_FX(1),.DISTRIBUTED_RESET(1),.REGIONAL_MODEL_CONTROLS(1)) dut(
  .clk(clk),.rst(rst),.gates(gates),.triggers(triggers),.notes(notes),.gains(gains),.timbres(tones),
  .ratio(ratio),.mod_depth(modulation),.synth_config(config_word),.sample_tick(tick),.pcm(pcm),.pcm_positive(positive),
  .hp_bck(hb),.hp_ws(hw),.hp_din(hd),.i2s_bck(ib),.i2s_ws(iw),.i2s_sd(id),.active(active),
  .monitor_steps(steps),.monitor_envelopes(env),.deadline_error(error),.clip_active(clip),.map_apply(1'b0),
  .model_reset({12{rst}}),.control_resetn_early(1'b1));
 integer i,f,age=0,last_change=0,max_settle=0,seen_frames=0,first_audio=-1;
 reg[191:0]old_phys=0,old_fade=0;reg signed[15:0]old_source=0;reg[11:0]heard=0;
 always @(negedge clk)begin
  if(rst)begin age=0;old_phys=0;old_fade=0;old_source=0;last_change=0;end
  else if(tick)begin
   if(seen_frames>5&&last_change>928)$fatal(1,"FRAME_SETTLE_OVER_928 age%0d",last_change);
   if(last_change>max_settle)max_settle=last_change;
   seen_frames=seen_frames+1;age=0;last_change=0;
  end else begin
   age=age+1;
   if(dut.phys_samples!==old_phys||dut.fade_samples!==old_fade||dut.source_pcm!==old_source)last_change=age;
  end
  old_phys=dut.phys_samples;old_fade=dut.fade_samples;old_source=dut.source_pcm;
 end
 initial begin
  for(i=0;i<12;i=i+1)begin notes[i*7+:7]=48+i*2;gains[i*12+:12]=2200;tones[i*3+:3]=TEST_TONE==5?i%5:TEST_TONE;end
  repeat(8)@(negedge clk);rst=0;triggers=12'hfff;
  for(f=0;f<FRAMES;f=f+1)begin
   @(negedge clk);while(!tick)@(negedge clk);
   if(dut.physical.BANK_WORKERS!=2)$fatal(1,"TWO_WORKERS_REQUIRED");
   if(error||dut.physical.busy)$fatal(1,"AUDIO_DEADLINE frame%0d",f);
   if(f>100&&f<2000&&active!==12'hfff)$fatal(1,"TWELVE_ACTIVE frame%0d active%h",f,active);
   if(pcm!=0&&first_audio<0)first_audio=f;
   for(i=0;i<12;i=i+1)if($signed(dut.fade_samples[i*16+:16])!=0)heard[i]=1;
   triggers=0;
   if(f==2000)gates[11]=0;
   if(f==2600)begin notes[0+:7]=72;triggers[0]=1;end
   if(f==3000)gains[10*12+:12]=0;
   if(f==3200)begin gains[10*12+:12]=2200;triggers[10]=1;end
   if(f==3800)begin ratio=280000;modulation=72;end
   if(f==4000)config_word=15;
   if(f>6100&&TEST_TONE==4&&active[11]!==0)$fatal(1,"VOICE11_CUSTOM_RELEASE frame%0d",f);
   if(f==6100&&TEST_TONE!=4)gains[11*12+:12]=0;
   if(f>6104&&TEST_TONE!=4&&active[11]!==0)$fatal(1,"VOICE11_HARD_MUTE frame%0d",f);
  end
  if(heard!==12'hfff||first_audio<0||first_audio>488)$fatal(1,"VOICE_OR_LATENCY_MISSING heard%h first%0d",heard,first_audio);
  $display("POLY12_AUDIO_PASS tone%0d frames%0d heard%h firstAudio%0d maxSettle%0d clocks 12voices/FX/modulation/release/steal/mute",TEST_TONE,FRAMES,heard,first_audio,max_settle);$finish;
 end
 initial begin #160000000;$fatal(1,"POLY12_AUDIO_TIMEOUT");end
endmodule
module tb_poly12_audio_0;tb_poly12_audio #(.TEST_TONE(0)) test();endmodule
module tb_poly12_audio_1;tb_poly12_audio #(.TEST_TONE(1)) test();endmodule
module tb_poly12_audio_2;tb_poly12_audio #(.TEST_TONE(2)) test();endmodule
module tb_poly12_audio_3;tb_poly12_audio #(.TEST_TONE(3)) test();endmodule
module tb_poly12_audio_mixed;tb_poly12_audio #(.TEST_TONE(5)) test();endmodule
