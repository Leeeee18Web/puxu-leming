`timescale 1ns/1ps
module tb_score2_fx;
 reg clk=0;always #10 clk=~clk;reg rst=1,tick=0,clear=0;reg signed[15:0]dry=0;reg[1:0]c=0,r=0;
 wire signed[15:0]pcm;wire ready,deadline,pcm_positive;wire[63:0]taps;
 final_fx dut(.clk(clk),.rst(rst),.sample_tick(tick),.clear(clear),.dry(dry),.dry_positive($signed(dry)>0),.chorus_level(c),.reverb_level(r),.pcm(pcm),.pcm_positive(pcm_positive),.ready(ready),.deadline_error(deadline),.tap_delays(taps));
 always @(negedge clk) #1 if(pcm_positive!==($signed(pcm)>0))$fatal(1,"FX_POSITIVE_METADATA");
 task frame;input integer s;begin @(negedge clk);dry=s;tick=1;@(negedge clk);tick=0;repeat(1022)@(negedge clk);if(deadline)$fatal(1,"DEADLINE");if(^pcm===1'bx)$fatal(1,"UNKNOWN_AUDIO");end endtask
 function[31:0]magnitude;input signed[15:0]v;reg signed[16:0]w;begin w=v;magnitude=w<0?-w:w;end endfunction
 integer i,nonzero;reg[63:0]first_taps;integer varied;reg[63:0]energy_early,energy_late;
 initial begin repeat(4)@(negedge clk);rst=0;
  for(i=0;i<25;i=i+1)begin frame(i*100-1000);if(pcm!==dry)$fatal(1,"BYPASS_IDENTITY");end
  c=2;for(i=0;i<600;i=i+1)frame(0);
  first_taps=taps;nonzero=0;varied=0;
  for(i=0;i<3000;i=i+1)begin frame(i==0?20000:0);if(i>10&&pcm!=0)nonzero=nonzero+1;if(taps!=first_taps)varied=1;end
  if(nonzero==0)$fatal(1,"CHORUS_MISSING_DELAYED_COPY");if(!varied)$fatal(1,"CHORUS_NO_MODULATION");
  clear=1;frame(0);clear=0;c=0;r=2;for(i=0;i<650;i=i+1)frame(0);
  nonzero=0;energy_early=0;energy_late=0;
  for(i=0;i<70000;i=i+1)begin
   frame(i==0?22000:0);
   if(i>1000&&pcm!=0)nonzero=nonzero+1;
   if(i>1000&&i<15000)energy_early=energy_early+{32'd0,magnitude(pcm)};
   if(i>55000)energy_late=energy_late+{32'd0,magnitude(pcm)};
  end
  if(nonzero<100)$fatal(1,"REVERB_MISSING_DENSE_TAIL %d",nonzero);
  if(energy_early==0||energy_early>100000000||energy_late>=energy_early)$fatal(1,"REVERB_NOT_DECAYING %d %d",energy_early,energy_late);
  c=3;r=3;for(i=0;i<1500;i=i+1)frame(i[4]?18000:-18000);
  clear=1;frame(0);if(pcm!=0)$fatal(1,"CLEAR_NOT_IMMEDIATE");clear=0;
  for(i=0;i<7000;i=i+1)begin frame(0);if(pcm!=0)$fatal(1,"STALE_TAIL_AFTER_CLEAR");end
  c=0;r=0;for(i=0;i<700;i=i+1)frame(0);
  for(i=0;i<100;i=i+1)begin frame(i[0]?-32768:32767);if(pcm!==dry)$fatal(1,"FINAL_BYPASS");end
  $display("SCORE2_FX_PASS chorus delayed/modulated reverb_tail=%0d early=%0d late=%0d deadline bypass clear",nonzero,energy_early,energy_late);$finish;
 end
 initial begin #2000000000;$fatal(1,"TIMEOUT");end
endmodule
