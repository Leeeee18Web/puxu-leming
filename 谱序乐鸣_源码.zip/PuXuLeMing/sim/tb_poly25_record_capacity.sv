`timescale 1ns/1ps
module tb_poly25_record_capacity;
 reg clk=0;always #10 clk=~clk;reg rst=1,sample_tick=0,record_toggle=0;reg[24:0]g=0;wire recording,full;wire[12:0]count;
 final_recorder #(.VOICE_COUNT(25),.EVENT_CAPACITY(50))dut(.observer_gains(),.clk(clk),.rst(rst),.sample_tick(sample_tick),.record_toggle(record_toggle),.replay_toggle(1'b0),.clear(1'b0),.panic(1'b0),.in_gates(g),.in_triggers(25'd0),.in_notes(175'd0),.in_gains(300'd0),.in_timbres(75'd0),.in_ratio(19'd262144),.in_mod_depth(7'd0),.in_synth_config(32'd0),.recording(recording),.full(full),.count(count),.out_gates(),.out_triggers(),.out_notes(),.out_gains(),.out_timbres(),.out_ratio(),.out_mod_depth(),.out_synth_config(),.replaying(),.time_limit(),.replay_frame_ready(),.time_samples(),.export_word(),.export_ready(),.take_id(),.duration_samples(),.export_address(12'd0),.preview_rst(1'b0),.preview_gates('0),.preview_notes('0),.preview_gains('0),.preview_timbres('0),.preview_ratio('0),.preview_mod_depth('0),.preview_synth_config('0));
 task frame;begin sample_tick=1;@(negedge clk);sample_tick=0;repeat(1023)@(negedge clk);end endtask
 initial begin repeat(5)@(negedge clk);rst=0;g='1;record_toggle=1;frame();record_toggle=0;
 if(count!=26||!recording||full)$fatal(1,"CAP25 initial26 failed");
 g=0;frame();if(count!=26||recording||!full)$fatal(1,"CAP25 partial frame admitted count%0d",count);
 if(dut.event_ram[24][62:57]!=24||dut.event_ram[24][56]!=1)$fatal(1,"CAP25 highest voice lost");
 $display("POLY25_RECORD_CAPACITY_PASS initial26 rejected25 atomically at50");$finish;end
endmodule
