`timescale 1ns/1ps
module tb_keyboard_candidate;
 reg clk=0,rst=1,event_valid=0,panic=0,map_apply=0;always #10 clk=~clk;
 reg[31:0]event_data=0;reg[1:0]event_source=0;reg[6:0]map_input_base=60,base_note=60;reg[174:0]map_notes=0;reg map_enabled=1,live_mode=1;
 wire event_ready;wire[11:0]live_gates;wire[83:0]live_notes,original_keys;wire[23:0]owners;wire[47:0]channels;
 wire[24:0]key_held;wire[374:0]key_labels;
 reg[11:0]gates=0;reg[83:0]notes=0;
 final_voice_control #(.VOICE_COUNT(12)) allocator(.clk(clk),.rst(rst),.sample_tick(1'b0),.event_valid(event_valid),.event_data(event_data),.event_source(event_source),.event_ready(event_ready),.panic(panic),.centre(1'b0),.pedal_down(1'b0),.timbre_select(3'd0),.voice_active(12'd0),.knob_mode(2'd1),.map_notes(map_notes),.map_input_base(map_input_base),.map_enabled(map_enabled),.map_apply(map_apply),.gates(live_gates),.notes(live_notes),.gains(),.timbres(),.triggers(),.ratio(),.knob(),.last_note(),.last_velocity(),.mod_depth(),.raw_knob(),.raw_known(),.pickup_wait(),.key_seen_valid(),.key_seen_index(),.ready_raw(),.display_original_keys(original_keys),.display_owners(owners),.display_channels(channels));
 final_keyboard_view view(.*);
 reg touch_update=0,touch_valid=1,touch_down=0;reg[15:0]touch_x=0,touch_y=0;wire[6:0]touch_key_base=map_enabled?map_input_base:base_note;
 wire touch_event_valid;wire[31:0]touch_event_data;wire[2:0]page;wire[6:0]nav_base;integer ons=0,nav_note=-1;
 final_navigation nav(.clk(clk),.rst(rst),.touch_key_base(touch_key_base),.touch_update(touch_update),.touch_valid(touch_valid),.touch_down(touch_down),.touch_x(touch_x),.touch_y(touch_y),.event_ready(1'b1),.event_valid(touch_event_valid),.event_data(touch_event_data),.page(page),.base_note(nav_base),.panic_key(1'b0),.centre_key(1'b0),.preview_busy(1'b0),.knob_mode(),.mode(),.centre(),.panic(),.clear_live(),.start_score(),.stop_score(),.muted(),.restart_lesson(),.xy_config(),.spectrum_zoom(),.pattern_mode(),.pattern_start(),.record_toggle(),.replay_toggle(),.transport_stop(),.timbre_open(),.xy_overview(),.envelope_choices(),.preview_toggle(),.timbre_commit(),.timbre(),.synth_config());
 always @(posedge clk)if(!rst&&touch_event_valid&&touch_event_data[7:4]==9)begin ons++;nav_note=touch_event_data[14:8];end
 integer i,k,b,n,checks=0,px[0:24],py[0:24];reg[24:0]expected;reg[14:0]label;
 task check(input bit ok,input string text);begin checks++;if(!ok)$fatal(1,"KEYBOARD_NORMAL %s held%h expected%h",text,key_held,expected);end endtask
 task clocks(input integer c);begin repeat(c)@(negedge clk);end endtask
 task reset;begin rst=1;event_valid=0;clocks(4);rst=0;clocks(60);end endtask
 task send(input integer source,key,status,input bit indexed_event);begin
  @(negedge clk);event_source=source;event_data=indexed_event?{7'(key),1'b1,8'd100,8'(map_input_base+key),8'(status)}:{8'd0,8'd100,8'(key),8'(status)};event_valid=1;
  do @(negedge clk);while(!event_ready);
  @(negedge clk);event_valid=0;clocks(60);
 end endtask
 task touch(input integer x,y,input bit down);begin
  @(negedge clk);touch_x=x;touch_y=y;touch_down=down;touch_update=1;@(negedge clk);touch_update=0;clocks(10);
 end endtask
 initial begin
  for(i=0;i<25;i++)map_notes[i*7+:7]=60+i;
  reset;
  for(i=0;i<12;i++)send(i%2,60+i,8'h90,0);
  expected=25'hfff;check(live_gates==12'hfff&&key_held==expected,"all12 simultaneous physical keys shown");
  for(i=0;i<12;i++)begin send(i%2,60+i,8'h80,0);expected[i]=0;check(key_held==expected,"independent release each voice");end
  for(i=0;i<15;i++)begin k=nav.white_semitone(i);px[k]=64+64*i;py[k]=540;end
  for(i=0;i<14;i++)if(nav.black_after(i))begin k=nav.white_semitone(i)+1;px[k]=96+64*i;py[k]=350;end
  for(b=36;b<=84;b+=24)begin
   map_input_base=b;for(i=0;i<25;i++)map_notes[i*7+:7]=36+(i*7+b)%61;reset;
   touch(160,32,1);touch(160,32,0);touch(640,96,1);touch(640,96,0);check(page==5&&nav_base==60,"global pattern base remains60");
   for(k=0;k<25;k++)begin
    label=key_labels[k*15+:15];check(label[14:8]==map_notes[k*7+:7],"all25 labels show WiFi assignment");
    n=ons;touch(px[k],py[k],1);check(ons==n+1&&nav_note==b+k,"touch emits correct mapped input-window key");touch(px[k],py[k],0);
    send(0,b+k,8'h90,0);expected=25'b1<<k;check(key_held==expected&&live_notes[6:0]==label[14:8],"touch/USB pitch equals displayed label");send(0,b+k,8'h80,0);
   end
  end
  map_input_base=36;map_notes[0+:7]=64;map_notes[7+:7]=64;reset;
  send(0,36,8'h90,0);send(1,37,8'h90,0);expected=3;check(key_held==expected,"duplicate mapped pitches keep two original keys");
  send(0,36,8'h80,0);expected=2;check(key_held==expected,"release one duplicate retains other");send(1,37,8'h80,0);
  send(3,24,8'h9e,1);expected=25'b1<<24;check(key_held==expected,"WiFi mobile original index24 displayed");send(3,24,8'h8e,1);
  send(3,0,8'h9e,1);send(3,1,8'h9e,1);expected=3;check(key_held==expected,"WiFi duplicate index ownership");send(3,0,8'h8e,1);expected=2;check(key_held==expected,"WiFi duplicate release identity");
  map_apply=1;clocks(1);map_apply=0;clocks(60);expected=0;check(key_held==0&&live_gates==0,"normal mapping Apply clears held state");
  live_mode=0;gates=1;notes[6:0]=64;clocks(60);expected=0;for(i=0;i<25;i++)if(map_notes[i*7+:7]==64)expected[i]=1;check(key_held==expected,"replay pattern score uses actual-pitch feedback");
  live_mode=1;gates=0;send(2,64,8'h90,0);check(key_held==expected,"gesture bypass map uses actual-pitch feedback");send(2,64,8'h80,0);
  map_enabled=0;clocks(60);for(k=0;k<25;k++)check(key_labels[k*15+8+:7]==60+k,"mapping disabled returns PIF labels");
  $display("KEYBOARD_CANDIDATE_PASS checks%0d all12 75normalTouchMapPairs duplicateRelease indexedWiFi25",checks);$finish;
 end
endmodule
