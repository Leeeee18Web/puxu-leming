// Pixel rectangles are half-open and shared by touch and display.
`include "sim/pif_ui_reference/src/play/play_geometry.vh"
function automatic integer p8_header_hit(input integer px,input integer py);
 begin
 p8_header_hit=0;
 if(py>=8&&py<56)begin
  if(px>=8&&px<104)p8_header_hit=1;
  else if(px>=116&&px<244)p8_header_hit=2;
  else if(px>=260&&px<388)p8_header_hit=3;
  else if(px>=416&&px<544)p8_header_hit=4;
  else if(px>=560&&px<688)p8_header_hit=7;
 end
 end
endfunction
function automatic integer p8_tab_hit(input integer px,input integer py);
 integer i;
 begin p8_tab_hit=0;
 if(py>=72&&py<120)for(i=0;i<6;i=i+1)
  if(px>=8+i*144&&px<144+i*144)p8_tab_hit=i==5?7:i+1;
 end
endfunction
function automatic integer p8_home_hit(input integer px,input integer py);
 begin p8_home_hit=0;
 if(py>=144&&py<344)begin
  if(px>=244&&px<412)p8_home_hit=2;
  else if(px>=428&&px<596)p8_home_hit=3;
  else if(px>=612&&px<780)p8_home_hit=8;
 end
 end
endfunction
function automatic integer p8_octave_hit(input integer px,input integer py);
 begin p8_octave_hit=0;
 if(py>=176&&py<224)begin
  if(px>=32&&px<200)p8_octave_hit=-1;
  else if(px>=216&&px<384)p8_octave_hit=1;
 end
 end
endfunction

function automatic integer p8_pattern_hit(input integer px,input integer py);
 begin p8_pattern_hit=0;
 if(py>=176&&py<224)begin
  if(px>=416&&px<548)p8_pattern_hit=1;
  else if(px>=560&&px<692)p8_pattern_hit=2;
  else if(px>=704&&px<836)p8_pattern_hit=3;
  else if(px>=848&&px<996)p8_pattern_hit=4;
 end
 end
endfunction
