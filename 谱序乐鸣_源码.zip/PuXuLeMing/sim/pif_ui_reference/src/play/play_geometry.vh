// Shared by renderer and hit test: every rectangle is half-open.
localparam integer KEY_X=32, KEY_Y=270, KEY_W=64, KEY_BOTTOM=570;
localparam integer BLACK_W=40, BLACK_BOTTOM=450;
function automatic integer white_semitone(input integer k);
 begin case(k)
 0:white_semitone=0;1:white_semitone=2;2:white_semitone=4;
 3:white_semitone=5;4:white_semitone=7;5:white_semitone=9;
 6:white_semitone=11;7:white_semitone=12;8:white_semitone=14;
 9:white_semitone=16;10:white_semitone=17;11:white_semitone=19;
 12:white_semitone=21;13:white_semitone=23;14:white_semitone=24;
 default:white_semitone=0;endcase end
endfunction
function automatic integer black_after(input integer k);
 begin case(k)
 0,1,3,4,5,7,8,10,11,12:black_after=1;
 default:black_after=0;endcase end
endfunction
function automatic integer key_hit(input integer px,input integer py);
 integer k;
 begin
 key_hit=-1;
 if(px>=KEY_X && px<KEY_X+15*KEY_W && py>=KEY_Y && py<KEY_BOTTOM) begin
   key_hit=white_semitone((px-KEY_X)/KEY_W);
   for(k=0;k<14;k=k+1)
     if(black_after(k) && py<BLACK_BOTTOM &&
        px>=KEY_X+(k+1)*KEY_W-BLACK_W/2 &&
        px<KEY_X+(k+1)*KEY_W+BLACK_W/2)
       key_hit=white_semitone(k)+1;
 end
 end
endfunction
function automatic integer button_hit(input integer px,input integer py);
 begin
 button_hit=0;
 if(py>=24 && py<80) begin
 if(px>=32&&px<218) button_hit=1;
 else if(px>=232&&px<418) button_hit=2;
 else if(px>=448&&px<550) button_hit=3;
 else if(px>=562&&px<664) button_hit=4;
 else if(px>=688&&px<830) button_hit=5;
 else if(px>=846&&px<992) button_hit=6;
 end
 end
endfunction
