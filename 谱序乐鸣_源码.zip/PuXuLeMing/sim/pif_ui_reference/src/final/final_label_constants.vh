localparam [6:0] P8_HZ_LABEL=7'd73;
localparam [6:0] P8_GUIDE_LABEL=7'd74;
localparam [6:0] P8_CURRENT_LABEL=7'd75;
localparam [6:0] P8_NEXT_LABEL=7'd76;
localparam [6:0] P8_REPLAY_LABEL=7'd77;
localparam [6:0] P8_MUTE_LABEL=7'd78;
localparam [6:0] P8_UNMUTE_LABEL=7'd79;
localparam [6:0] P8_PLAYING_LABEL=7'd80;
localparam [6:0] P8_STOPPED_LABEL=7'd81;
localparam [6:0] P8_FOLLOW_LABEL=7'd83;
localparam [6:0] P8_DONE_LABEL=7'd84;
localparam [6:0] P8_RESTART_LABEL=7'd85;
localparam [6:0] P8_INDEX_LABEL=7'd86;
localparam [6:0] P8_NOTE_LABEL=7'd87;
localparam [6:0] P8_BEND_LABEL=7'd88;
localparam [6:0] P8_TOUCH_UP_LABEL=7'd89;
localparam [6:0] P8_TOUCH_DOWN_LABEL=7'd90;
localparam [6:0] P8_TOUCH_PRESS_LABEL=7'd91;
localparam [6:0] P8_TOUCH_RELEASE_LABEL=7'd92;
localparam [6:0] P8_PATTERN_STRUM_LABEL=7'd93;
localparam [6:0] P8_PATTERN_CHORD_LABEL=7'd94;
localparam [6:0] P8_PATTERN_ARP_LABEL=7'd95;
localparam [6:0] P8_PATTERN_TRIGGER_LABEL=7'd96;
localparam [6:0] P8_PATTERN_COUNT_LABEL=7'd97;
localparam [6:0] P8_PATTERN_FULL_LABEL=7'd98;
localparam [6:0] P8_PATTERN_CAPACITY_LABEL=7'd99;
localparam [6:0] FINAL_RECORD_LABEL=7'd100;
localparam [6:0] FINAL_REPLAY_TAKE_LABEL=7'd101;
localparam [6:0] FINAL_RECORDING_LABEL=7'd102;
localparam [6:0] FINAL_REPLAYING_LABEL=7'd103;
localparam [6:0] FINAL_FULL_LABEL=7'd104;
localparam [6:0] FINAL_PIANO_READY_LABEL=7'd105;
localparam [6:0] FINAL_PIANO_WAIT_LABEL=7'd106;
localparam [6:0] FINAL_TOUCH_READY_LABEL=7'd107;
localparam [6:0] FINAL_TOUCH_WAIT_LABEL=7'd108;
localparam [6:0] FINAL_PIANO_LABEL=7'd109;
localparam [6:0] FINAL_GRAND_LABEL=7'd110;
localparam [6:0] FINAL_GUITAR_LABEL=7'd111;
localparam [6:0] FINAL_SAX_LABEL=7'd112;
localparam [6:0] FINAL_EXIT_LABEL=7'd113;
localparam [6:0] FINAL_MATRIX_LABEL=7'd114;
localparam [6:0] FINAL_TIMBRE_LABEL=7'd115;
localparam [6:0] FINAL_TIME_LABEL=7'd116;
localparam [6:0] FINAL_EVT_LABEL=7'd117;
localparam [6:0] FINAL_CHORUS_LABEL=7'd118;
localparam [6:0] FINAL_REVERB_LABEL=7'd119;
localparam [6:0] FINAL_VIBRATO_LABEL=7'd120;
localparam [6:0] FINAL_FX_OFF_LABEL=7'd121;
localparam [6:0] FINAL_FX_LOW_LABEL=7'd122;
localparam [6:0] FINAL_FX_MID_LABEL=7'd123;
localparam [6:0] FINAL_FX_HIGH_LABEL=7'd124;
localparam [6:0] FINAL_PEDAL_LABEL=7'd125;
localparam [6:0] FINAL_PEDAL_SECOND_LABEL=7'd126;
