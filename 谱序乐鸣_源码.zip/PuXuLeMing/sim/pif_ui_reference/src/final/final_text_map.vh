function automatic [7:0] p8_glyph(input [6:0] label,input [3:0] ci);
begin case({label,ci})
11'd0:p8_glyph=8'd0; // 首
11'd1:p8_glyph=8'd1; // 页
11'd16:p8_glyph=8'd2; // 演
11'd17:p8_glyph=8'd3; // 奏
11'd32:p8_glyph=8'd4; // 播
11'd33:p8_glyph=8'd5; // 放
11'd48:p8_glyph=8'd6; // 原
11'd49:p8_glyph=8'd7; // 调
11'd64:p8_glyph=8'd8; // 急
11'd65:p8_glyph=8'd9; // 停
11'd80:p8_glyph=8'd9; // 停
11'd81:p8_glyph=8'd10; // 止
11'd96:p8_glyph=8'd11; // 音
11'd97:p8_glyph=8'd12; // 高
11'd112:p8_glyph=8'd13; // 频
11'd113:p8_glyph=8'd14; // 谱
11'd128:p8_glyph=8'd15; // 李
11'd129:p8_glyph=8'd16; // 萨
11'd130:p8_glyph=8'd17; // 如
11'd144:p8_glyph=8'd18; // 波
11'd145:p8_glyph=8'd19; // 形
11'd160:p8_glyph=8'd20; // 虚
11'd161:p8_glyph=8'd21; // 拟
11'd162:p8_glyph=8'd22; // 琴
11'd163:p8_glyph=8'd23; // 键
11'd176:p8_glyph=8'd24; // 控
11'd177:p8_glyph=8'd25; // 制
11'd178:p8_glyph=8'd26; // 条
11'd192:p8_glyph=8'd27; // 八
11'd193:p8_glyph=8'd28; // 度
11'd194:p8_glyph=8'd29; //  
11'd195:p8_glyph=8'd30; // -
11'd208:p8_glyph=8'd27; // 八
11'd209:p8_glyph=8'd28; // 度
11'd210:p8_glyph=8'd29; //  
11'd211:p8_glyph=8'd31; // +
11'd224:p8_glyph=8'd32; // 旋
11'd225:p8_glyph=8'd33; // 钮
11'd226:p8_glyph=8'd34; // 模
11'd227:p8_glyph=8'd35; // 式
11'd240:p8_glyph=8'd36; // 拾
11'd241:p8_glyph=8'd37; // 取
11'd256:p8_glyph=8'd38; // 相
11'd257:p8_glyph=8'd39; // 对
11'd272:p8_glyph=8'd40; // 环
11'd273:p8_glyph=8'd41; // 绕
11'd288:p8_glyph=8'd42; // 实
11'd289:p8_glyph=8'd43; // 际
11'd290:p8_glyph=8'd44; // 弯
11'd291:p8_glyph=8'd11; // 音
11'd304:p8_glyph=8'd45; // 物
11'd305:p8_glyph=8'd46; // 理
11'd306:p8_glyph=8'd32; // 旋
11'd307:p8_glyph=8'd33; // 钮
11'd320:p8_glyph=8'd47; // 等
11'd321:p8_glyph=8'd48; // 待
11'd322:p8_glyph=8'd49; // 接
11'd323:p8_glyph=8'd50; // 管
11'd336:p8_glyph=8'd51; // 尚
11'd337:p8_glyph=8'd52; // 未
11'd338:p8_glyph=8'd53; // 转
11'd339:p8_glyph=8'd54; // 动
11'd352:p8_glyph=8'd55; // 力
11'd353:p8_glyph=8'd28; // 度
11'd368:p8_glyph=8'd42; // 实
11'd369:p8_glyph=8'd56; // 时
11'd370:p8_glyph=8'd57; // 合
11'd371:p8_glyph=8'd58; // 成
11'd384:p8_glyph=8'd59; // ×
11'd385:p8_glyph=8'd60; // 4
11'd400:p8_glyph=8'd59; // ×
11'd401:p8_glyph=8'd61; // 2
11'd416:p8_glyph=8'd59; // ×
11'd417:p8_glyph=8'd62; // 1
11'd432:p8_glyph=8'd63; // 自
11'd433:p8_glyph=8'd54; // 动
11'd448:p8_glyph=8'd64; // 0
11'd449:p8_glyph=8'd65; // °
11'd464:p8_glyph=8'd60; // 4
11'd465:p8_glyph=8'd66; // 5
11'd466:p8_glyph=8'd65; // °
11'd480:p8_glyph=8'd67; // 9
11'd481:p8_glyph=8'd64; // 0
11'd482:p8_glyph=8'd65; // °
11'd496:p8_glyph=8'd62; // 1
11'd497:p8_glyph=8'd68; // 3
11'd498:p8_glyph=8'd66; // 5
11'd499:p8_glyph=8'd65; // °
11'd512:p8_glyph=8'd62; // 1
11'd513:p8_glyph=8'd69; // 8
11'd514:p8_glyph=8'd64; // 0
11'd515:p8_glyph=8'd65; // °
11'd528:p8_glyph=8'd62; // 1
11'd529:p8_glyph=8'd70; // :
11'd530:p8_glyph=8'd62; // 1
11'd544:p8_glyph=8'd62; // 1
11'd545:p8_glyph=8'd70; // :
11'd546:p8_glyph=8'd61; // 2
11'd560:p8_glyph=8'd62; // 1
11'd561:p8_glyph=8'd70; // :
11'd562:p8_glyph=8'd68; // 3
11'd576:p8_glyph=8'd61; // 2
11'd577:p8_glyph=8'd70; // :
11'd578:p8_glyph=8'd68; // 3
11'd592:p8_glyph=8'd62; // 1
11'd593:p8_glyph=8'd29; //  
11'd594:p8_glyph=8'd71; // k
11'd595:p8_glyph=8'd72; // H
11'd596:p8_glyph=8'd73; // z
11'd608:p8_glyph=8'd61; // 2
11'd609:p8_glyph=8'd29; //  
11'd610:p8_glyph=8'd71; // k
11'd611:p8_glyph=8'd72; // H
11'd612:p8_glyph=8'd73; // z
11'd624:p8_glyph=8'd60; // 4
11'd625:p8_glyph=8'd29; //  
11'd626:p8_glyph=8'd71; // k
11'd627:p8_glyph=8'd72; // H
11'd628:p8_glyph=8'd73; // z
11'd640:p8_glyph=8'd64; // 0
11'd641:p8_glyph=8'd29; //  
11'd642:p8_glyph=8'd72; // H
11'd643:p8_glyph=8'd73; // z
11'd656:p8_glyph=8'd61; // 2
11'd657:p8_glyph=8'd66; // 5
11'd658:p8_glyph=8'd64; // 0
11'd659:p8_glyph=8'd29; //  
11'd660:p8_glyph=8'd72; // H
11'd661:p8_glyph=8'd73; // z
11'd672:p8_glyph=8'd66; // 5
11'd673:p8_glyph=8'd64; // 0
11'd674:p8_glyph=8'd64; // 0
11'd675:p8_glyph=8'd29; //  
11'd676:p8_glyph=8'd72; // H
11'd677:p8_glyph=8'd73; // z
11'd688:p8_glyph=8'd62; // 1
11'd689:p8_glyph=8'd64; // 0
11'd690:p8_glyph=8'd64; // 0
11'd691:p8_glyph=8'd64; // 0
11'd692:p8_glyph=8'd29; //  
11'd693:p8_glyph=8'd72; // H
11'd694:p8_glyph=8'd73; // z
11'd704:p8_glyph=8'd74; // C
11'd705:p8_glyph=8'd60; // 4
11'd720:p8_glyph=8'd74; // C
11'd721:p8_glyph=8'd66; // 5
11'd736:p8_glyph=8'd74; // C
11'd737:p8_glyph=8'd75; // 6
11'd752:p8_glyph=8'd74; // C
11'd753:p8_glyph=8'd76; // 7
11'd768:p8_glyph=8'd62; // 1
11'd784:p8_glyph=8'd61; // 2
11'd800:p8_glyph=8'd68; // 3
11'd816:p8_glyph=8'd60; // 4
11'd832:p8_glyph=8'd66; // 5
11'd848:p8_glyph=8'd75; // 6
11'd864:p8_glyph=8'd76; // 7
11'd880:p8_glyph=8'd77; // #
11'd896:p8_glyph=8'd78; // M
11'd897:p8_glyph=8'd79; // O
11'd898:p8_glyph=8'd80; // D
11'd912:p8_glyph=8'd81; // −
11'd928:p8_glyph=8'd31; // +
11'd944:p8_glyph=8'd64; // 0
11'd960:p8_glyph=8'd69; // 8
11'd976:p8_glyph=8'd67; // 9
11'd992:p8_glyph=8'd74; // C
11'd993:p8_glyph=8'd68; // 3
11'd1008:p8_glyph=8'd68; // 3
11'd1009:p8_glyph=8'd69; // 8
11'd1010:p8_glyph=8'd62; // 1
11'd1024:p8_glyph=8'd76; // 7
11'd1025:p8_glyph=8'd75; // 6
11'd1026:p8_glyph=8'd68; // 3
11'd1040:p8_glyph=8'd62; // 1
11'd1041:p8_glyph=8'd62; // 1
11'd1042:p8_glyph=8'd60; // 4
11'd1043:p8_glyph=8'd60; // 4
11'd1056:p8_glyph=8'd62; // 1
11'd1057:p8_glyph=8'd60; // 4
11'd1058:p8_glyph=8'd76; // 7
11'd1059:p8_glyph=8'd69; // 8
11'd1072:p8_glyph=8'd62; // 1
11'd1073:p8_glyph=8'd66; // 5
11'd1074:p8_glyph=8'd61; // 2
11'd1075:p8_glyph=8'd75; // 6
11'd1088:p8_glyph=8'd61; // 2
11'd1089:p8_glyph=8'd61; // 2
11'd1090:p8_glyph=8'd69; // 8
11'd1091:p8_glyph=8'd67; // 9
11'd1104:p8_glyph=8'd68; // 3
11'd1105:p8_glyph=8'd64; // 0
11'd1106:p8_glyph=8'd64; // 0
11'd1107:p8_glyph=8'd60; // 4
11'd1120:p8_glyph=8'd68; // 3
11'd1121:p8_glyph=8'd64; // 0
11'd1122:p8_glyph=8'd66; // 5
11'd1123:p8_glyph=8'd61; // 2
11'd1136:p8_glyph=8'd60; // 4
11'd1137:p8_glyph=8'd66; // 5
11'd1138:p8_glyph=8'd76; // 7
11'd1139:p8_glyph=8'd69; // 8
11'd1152:p8_glyph=8'd75; // 6
11'd1153:p8_glyph=8'd64; // 0
11'd1154:p8_glyph=8'd66; // 5
11'd1155:p8_glyph=8'd75; // 6
11'd1168:p8_glyph=8'd72; // H
11'd1169:p8_glyph=8'd73; // z
11'd1184:p8_glyph=8'd82; // 导
11'd1185:p8_glyph=8'd3; // 奏
11'd1200:p8_glyph=8'd83; // 当
11'd1201:p8_glyph=8'd84; // 前
11'd1202:p8_glyph=8'd11; // 音
11'd1216:p8_glyph=8'd85; // 下
11'd1217:p8_glyph=8'd86; // 一
11'd1218:p8_glyph=8'd11; // 音
11'd1232:p8_glyph=8'd87; // 重
11'd1233:p8_glyph=8'd4; // 播
11'd1248:p8_glyph=8'd88; // 静
11'd1249:p8_glyph=8'd11; // 音
11'd1264:p8_glyph=8'd89; // 恢
11'd1265:p8_glyph=8'd90; // 复
11'd1280:p8_glyph=8'd4; // 播
11'd1281:p8_glyph=8'd5; // 放
11'd1282:p8_glyph=8'd91; // 中
11'd1296:p8_glyph=8'd92; // 已
11'd1297:p8_glyph=8'd9; // 停
11'd1298:p8_glyph=8'd10; // 止
11'd1312:p8_glyph=8'd2; // 演
11'd1313:p8_glyph=8'd3; // 奏
11'd1314:p8_glyph=8'd91; // 中
11'd1328:p8_glyph=8'd93; // 跟
11'd1329:p8_glyph=8'd94; // 弹
11'd1344:p8_glyph=8'd95; // 完
11'd1345:p8_glyph=8'd58; // 成
11'd1360:p8_glyph=8'd87; // 重
11'd1361:p8_glyph=8'd96; // 新
11'd1362:p8_glyph=8'd97; // 开
11'd1363:p8_glyph=8'd98; // 始
11'd1376:p8_glyph=8'd99; // 第
11'd1392:p8_glyph=8'd11; // 音
11'd1408:p8_glyph=8'd44; // 弯
11'd1409:p8_glyph=8'd11; // 音
11'd1424:p8_glyph=8'd105; // 触
11'd1425:p8_glyph=8'd106; // 屏
11'd1426:p8_glyph=8'd107; // 已
11'd1427:p8_glyph=8'd108; // 连
11'd1428:p8_glyph=8'd109; // 接
11'd1440:p8_glyph=8'd105; // 触
11'd1441:p8_glyph=8'd106; // 屏
11'd1442:p8_glyph=8'd110; // 未
11'd1443:p8_glyph=8'd108; // 连
11'd1444:p8_glyph=8'd109; // 接
11'd1456:p8_glyph=8'd111; // 按
11'd1457:p8_glyph=8'd112; // 下
11'd1472:p8_glyph=8'd113; // 松
11'd1473:p8_glyph=8'd114; // 开
11'd1488:p8_glyph=8'd115; // 拨
11'd1489:p8_glyph=8'd116; // 弦
11'd1504:p8_glyph=8'd117; // 和
11'd1505:p8_glyph=8'd116; // 弦
11'd1520:p8_glyph=8'd118; // 琶
11'd1521:p8_glyph=8'd11; // 音
11'd1536:p8_glyph=8'd100; // 触
11'd1537:p8_glyph=8'd119; // 发
11'd1552:p8_glyph=8'd107; // 已
11'd1553:p8_glyph=8'd121; // 选
11'd1568:p8_glyph=8'd107; // 已
11'd1569:p8_glyph=8'd122; // 满
11'd1584:p8_glyph=8'd120; // /
11'd1585:p8_glyph=8'd76; // 7
11'd1600:p8_glyph=8'd128; // 录
11'd1601:p8_glyph=8'd25; // 制
11'd1616:p8_glyph=8'd129; // 回
11'd1617:p8_glyph=8'd130; // 拨
11'd1632:p8_glyph=8'd131; // 录
11'd1633:p8_glyph=8'd25; // 制
11'd1634:p8_glyph=8'd91; // 中
11'd1648:p8_glyph=8'd132; // 回
11'd1649:p8_glyph=8'd133; // 拨
11'd1650:p8_glyph=8'd91; // 中
11'd1664:p8_glyph=8'd134; // 已
11'd1665:p8_glyph=8'd135; // 满
11'd1680:p8_glyph=8'd22; // 琴
11'd1681:p8_glyph=8'd23; // 键
11'd1682:p8_glyph=8'd136; // 就
11'd1683:p8_glyph=8'd137; // 绪
11'd1696:p8_glyph=8'd22; // 琴
11'd1697:p8_glyph=8'd23; // 键
11'd1698:p8_glyph=8'd138; // 未
11'd1699:p8_glyph=8'd139; // 连
11'd1712:p8_glyph=8'd100; // 触
11'd1713:p8_glyph=8'd140; // 屏
11'd1714:p8_glyph=8'd141; // 就
11'd1715:p8_glyph=8'd142; // 绪
11'd1728:p8_glyph=8'd100; // 触
11'd1729:p8_glyph=8'd143; // 屏
11'd1730:p8_glyph=8'd144; // 未
11'd1731:p8_glyph=8'd145; // 连
11'd1744:p8_glyph=8'd146; // 钢
11'd1745:p8_glyph=8'd22; // 琴
11'd1760:p8_glyph=8'd147; // 三
11'd1761:p8_glyph=8'd148; // 角
11'd1762:p8_glyph=8'd149; // 钢
11'd1763:p8_glyph=8'd22; // 琴
11'd1776:p8_glyph=8'd150; // 木
11'd1777:p8_glyph=8'd151; // 吉
11'd1778:p8_glyph=8'd152; // 他
11'd1792:p8_glyph=8'd153; // 柔
11'd1793:p8_glyph=8'd154; // 和
11'd1794:p8_glyph=8'd16; // 萨
11'd1795:p8_glyph=8'd155; // 克
11'd1796:p8_glyph=8'd156; // 斯
11'd1808:p8_glyph=8'd157; // 退
11'd1809:p8_glyph=8'd158; // 出
11'd1824:p8_glyph=8'd159; // 图
11'd1825:p8_glyph=8'd14; // 谱
11'd1826:p8_glyph=8'd160; // 总
11'd1827:p8_glyph=8'd161; // 览
11'd1840:p8_glyph=8'd11; // 音
11'd1841:p8_glyph=8'd162; // 色
11'd1856:p8_glyph=8'd163; // 秒
11'd1872:p8_glyph=8'd164; // 事
11'd1873:p8_glyph=8'd165; // 件
11'd1888:p8_glyph=8'd57; // 合
11'd1889:p8_glyph=8'd166; // 唱
11'd1904:p8_glyph=8'd167; // 混
11'd1905:p8_glyph=8'd168; // 响
11'd1920:p8_glyph=8'd169; // 颤
11'd1921:p8_glyph=8'd11; // 音
11'd1936:p8_glyph=8'd170; // 关
11'd1952:p8_glyph=8'd171; // 弱
11'd1968:p8_glyph=8'd91; // 中
11'd1984:p8_glyph=8'd172; // 强
11'd2000:p8_glyph=8'd173; // 延
11'd2016:p8_glyph=8'd11; // 音
default:p8_glyph=8'd29;endcase end endfunction
function automatic [6:0] p8_digit_label(input [3:0] n);begin case(n)
4'd0:p8_digit_label=7'd59;
4'd1:p8_digit_label=7'd48;
4'd2:p8_digit_label=7'd49;
4'd3:p8_digit_label=7'd50;
4'd4:p8_digit_label=7'd51;
4'd5:p8_digit_label=7'd52;
4'd6:p8_digit_label=7'd53;
4'd7:p8_digit_label=7'd54;
4'd8:p8_digit_label=7'd60;
4'd9:p8_digit_label=7'd61;
default:p8_digit_label=0;endcase end endfunction
function automatic [9:0] p8_thumb(input [6:0] n);begin case(n)
7'd0:p8_thumb=10'd192;
7'd1:p8_thumb=10'd197;
7'd2:p8_thumb=10'd202;
7'd3:p8_thumb=10'd207;
7'd4:p8_thumb=10'd212;
7'd5:p8_thumb=10'd217;
7'd6:p8_thumb=10'd222;
7'd7:p8_thumb=10'd227;
7'd8:p8_thumb=10'd232;
7'd9:p8_thumb=10'd237;
7'd10:p8_thumb=10'd242;
7'd11:p8_thumb=10'd247;
7'd12:p8_thumb=10'd252;
7'd13:p8_thumb=10'd258;
7'd14:p8_thumb=10'd263;
7'd15:p8_thumb=10'd268;
7'd16:p8_thumb=10'd273;
7'd17:p8_thumb=10'd278;
7'd18:p8_thumb=10'd283;
7'd19:p8_thumb=10'd288;
7'd20:p8_thumb=10'd293;
7'd21:p8_thumb=10'd298;
7'd22:p8_thumb=10'd303;
7'd23:p8_thumb=10'd308;
7'd24:p8_thumb=10'd313;
7'd25:p8_thumb=10'd318;
7'd26:p8_thumb=10'd323;
7'd27:p8_thumb=10'd328;
7'd28:p8_thumb=10'd333;
7'd29:p8_thumb=10'd338;
7'd30:p8_thumb=10'd343;
7'd31:p8_thumb=10'd348;
7'd32:p8_thumb=10'd353;
7'd33:p8_thumb=10'd358;
7'd34:p8_thumb=10'd363;
7'd35:p8_thumb=10'd368;
7'd36:p8_thumb=10'd373;
7'd37:p8_thumb=10'd378;
7'd38:p8_thumb=10'd383;
7'd39:p8_thumb=10'd389;
7'd40:p8_thumb=10'd394;
7'd41:p8_thumb=10'd399;
7'd42:p8_thumb=10'd404;
7'd43:p8_thumb=10'd409;
7'd44:p8_thumb=10'd414;
7'd45:p8_thumb=10'd419;
7'd46:p8_thumb=10'd424;
7'd47:p8_thumb=10'd429;
7'd48:p8_thumb=10'd434;
7'd49:p8_thumb=10'd439;
7'd50:p8_thumb=10'd444;
7'd51:p8_thumb=10'd449;
7'd52:p8_thumb=10'd454;
7'd53:p8_thumb=10'd459;
7'd54:p8_thumb=10'd464;
7'd55:p8_thumb=10'd469;
7'd56:p8_thumb=10'd474;
7'd57:p8_thumb=10'd479;
7'd58:p8_thumb=10'd484;
7'd59:p8_thumb=10'd489;
7'd60:p8_thumb=10'd494;
7'd61:p8_thumb=10'd499;
7'd62:p8_thumb=10'd504;
7'd63:p8_thumb=10'd509;
7'd64:p8_thumb=10'd515;
7'd65:p8_thumb=10'd520;
7'd66:p8_thumb=10'd525;
7'd67:p8_thumb=10'd530;
7'd68:p8_thumb=10'd535;
7'd69:p8_thumb=10'd540;
7'd70:p8_thumb=10'd545;
7'd71:p8_thumb=10'd550;
7'd72:p8_thumb=10'd555;
7'd73:p8_thumb=10'd560;
7'd74:p8_thumb=10'd565;
7'd75:p8_thumb=10'd570;
7'd76:p8_thumb=10'd575;
7'd77:p8_thumb=10'd580;
7'd78:p8_thumb=10'd585;
7'd79:p8_thumb=10'd590;
7'd80:p8_thumb=10'd595;
7'd81:p8_thumb=10'd600;
7'd82:p8_thumb=10'd605;
7'd83:p8_thumb=10'd610;
7'd84:p8_thumb=10'd615;
7'd85:p8_thumb=10'd620;
7'd86:p8_thumb=10'd625;
7'd87:p8_thumb=10'd630;
7'd88:p8_thumb=10'd635;
7'd89:p8_thumb=10'd641;
7'd90:p8_thumb=10'd646;
7'd91:p8_thumb=10'd651;
7'd92:p8_thumb=10'd656;
7'd93:p8_thumb=10'd661;
7'd94:p8_thumb=10'd666;
7'd95:p8_thumb=10'd671;
7'd96:p8_thumb=10'd676;
7'd97:p8_thumb=10'd681;
7'd98:p8_thumb=10'd686;
7'd99:p8_thumb=10'd691;
7'd100:p8_thumb=10'd696;
7'd101:p8_thumb=10'd701;
7'd102:p8_thumb=10'd706;
7'd103:p8_thumb=10'd711;
7'd104:p8_thumb=10'd716;
7'd105:p8_thumb=10'd721;
7'd106:p8_thumb=10'd726;
7'd107:p8_thumb=10'd731;
7'd108:p8_thumb=10'd736;
7'd109:p8_thumb=10'd741;
7'd110:p8_thumb=10'd746;
7'd111:p8_thumb=10'd751;
7'd112:p8_thumb=10'd756;
7'd113:p8_thumb=10'd761;
7'd114:p8_thumb=10'd766;
7'd115:p8_thumb=10'd772;
7'd116:p8_thumb=10'd777;
7'd117:p8_thumb=10'd782;
7'd118:p8_thumb=10'd787;
7'd119:p8_thumb=10'd792;
7'd120:p8_thumb=10'd797;
7'd121:p8_thumb=10'd802;
7'd122:p8_thumb=10'd807;
7'd123:p8_thumb=10'd812;
7'd124:p8_thumb=10'd817;
7'd125:p8_thumb=10'd822;
7'd126:p8_thumb=10'd827;
7'd127:p8_thumb=10'd832;
default:p8_thumb=512;endcase end endfunction
function automatic [9:0] p8_home_thumb(input [6:0] n);begin case(n)
7'd0:p8_home_thumb=10'd244;
7'd1:p8_home_thumb=10'd248;
7'd2:p8_home_thumb=10'd252;
7'd3:p8_home_thumb=10'd257;
7'd4:p8_home_thumb=10'd261;
7'd5:p8_home_thumb=10'd265;
7'd6:p8_home_thumb=10'd269;
7'd7:p8_home_thumb=10'd274;
7'd8:p8_home_thumb=10'd278;
7'd9:p8_home_thumb=10'd282;
7'd10:p8_home_thumb=10'd286;
7'd11:p8_home_thumb=10'd290;
7'd12:p8_home_thumb=10'd295;
7'd13:p8_home_thumb=10'd299;
7'd14:p8_home_thumb=10'd303;
7'd15:p8_home_thumb=10'd307;
7'd16:p8_home_thumb=10'd312;
7'd17:p8_home_thumb=10'd316;
7'd18:p8_home_thumb=10'd320;
7'd19:p8_home_thumb=10'd324;
7'd20:p8_home_thumb=10'd328;
7'd21:p8_home_thumb=10'd333;
7'd22:p8_home_thumb=10'd337;
7'd23:p8_home_thumb=10'd341;
7'd24:p8_home_thumb=10'd345;
7'd25:p8_home_thumb=10'd350;
7'd26:p8_home_thumb=10'd354;
7'd27:p8_home_thumb=10'd358;
7'd28:p8_home_thumb=10'd362;
7'd29:p8_home_thumb=10'd366;
7'd30:p8_home_thumb=10'd371;
7'd31:p8_home_thumb=10'd375;
7'd32:p8_home_thumb=10'd379;
7'd33:p8_home_thumb=10'd383;
7'd34:p8_home_thumb=10'd387;
7'd35:p8_home_thumb=10'd392;
7'd36:p8_home_thumb=10'd396;
7'd37:p8_home_thumb=10'd400;
7'd38:p8_home_thumb=10'd404;
7'd39:p8_home_thumb=10'd409;
7'd40:p8_home_thumb=10'd413;
7'd41:p8_home_thumb=10'd417;
7'd42:p8_home_thumb=10'd421;
7'd43:p8_home_thumb=10'd425;
7'd44:p8_home_thumb=10'd430;
7'd45:p8_home_thumb=10'd434;
7'd46:p8_home_thumb=10'd438;
7'd47:p8_home_thumb=10'd442;
7'd48:p8_home_thumb=10'd447;
7'd49:p8_home_thumb=10'd451;
7'd50:p8_home_thumb=10'd455;
7'd51:p8_home_thumb=10'd459;
7'd52:p8_home_thumb=10'd463;
7'd53:p8_home_thumb=10'd468;
7'd54:p8_home_thumb=10'd472;
7'd55:p8_home_thumb=10'd476;
7'd56:p8_home_thumb=10'd480;
7'd57:p8_home_thumb=10'd485;
7'd58:p8_home_thumb=10'd489;
7'd59:p8_home_thumb=10'd493;
7'd60:p8_home_thumb=10'd497;
7'd61:p8_home_thumb=10'd501;
7'd62:p8_home_thumb=10'd506;
7'd63:p8_home_thumb=10'd510;
7'd64:p8_home_thumb=10'd514;
7'd65:p8_home_thumb=10'd518;
7'd66:p8_home_thumb=10'd523;
7'd67:p8_home_thumb=10'd527;
7'd68:p8_home_thumb=10'd531;
7'd69:p8_home_thumb=10'd535;
7'd70:p8_home_thumb=10'd539;
7'd71:p8_home_thumb=10'd544;
7'd72:p8_home_thumb=10'd548;
7'd73:p8_home_thumb=10'd552;
7'd74:p8_home_thumb=10'd556;
7'd75:p8_home_thumb=10'd561;
7'd76:p8_home_thumb=10'd565;
7'd77:p8_home_thumb=10'd569;
7'd78:p8_home_thumb=10'd573;
7'd79:p8_home_thumb=10'd577;
7'd80:p8_home_thumb=10'd582;
7'd81:p8_home_thumb=10'd586;
7'd82:p8_home_thumb=10'd590;
7'd83:p8_home_thumb=10'd594;
7'd84:p8_home_thumb=10'd599;
7'd85:p8_home_thumb=10'd603;
7'd86:p8_home_thumb=10'd607;
7'd87:p8_home_thumb=10'd611;
7'd88:p8_home_thumb=10'd615;
7'd89:p8_home_thumb=10'd620;
7'd90:p8_home_thumb=10'd624;
7'd91:p8_home_thumb=10'd628;
7'd92:p8_home_thumb=10'd632;
7'd93:p8_home_thumb=10'd637;
7'd94:p8_home_thumb=10'd641;
7'd95:p8_home_thumb=10'd645;
7'd96:p8_home_thumb=10'd649;
7'd97:p8_home_thumb=10'd653;
7'd98:p8_home_thumb=10'd658;
7'd99:p8_home_thumb=10'd662;
7'd100:p8_home_thumb=10'd666;
7'd101:p8_home_thumb=10'd670;
7'd102:p8_home_thumb=10'd674;
7'd103:p8_home_thumb=10'd679;
7'd104:p8_home_thumb=10'd683;
7'd105:p8_home_thumb=10'd687;
7'd106:p8_home_thumb=10'd691;
7'd107:p8_home_thumb=10'd696;
7'd108:p8_home_thumb=10'd700;
7'd109:p8_home_thumb=10'd704;
7'd110:p8_home_thumb=10'd708;
7'd111:p8_home_thumb=10'd712;
7'd112:p8_home_thumb=10'd717;
7'd113:p8_home_thumb=10'd721;
7'd114:p8_home_thumb=10'd725;
7'd115:p8_home_thumb=10'd729;
7'd116:p8_home_thumb=10'd734;
7'd117:p8_home_thumb=10'd738;
7'd118:p8_home_thumb=10'd742;
7'd119:p8_home_thumb=10'd746;
7'd120:p8_home_thumb=10'd750;
7'd121:p8_home_thumb=10'd755;
7'd122:p8_home_thumb=10'd759;
7'd123:p8_home_thumb=10'd763;
7'd124:p8_home_thumb=10'd767;
7'd125:p8_home_thumb=10'd772;
7'd126:p8_home_thumb=10'd776;
7'd127:p8_home_thumb=10'd780;
default:p8_home_thumb=512;endcase end endfunction
function automatic [6:0] p8_freq_label(input [1:0] zoom,input [2:0] tick);begin case({zoom,tick})
5'd0:p8_freq_label=7'd59;
5'd1:p8_freq_label=7'd63;
5'd2:p8_freq_label=7'd64;
5'd3:p8_freq_label=7'd65;
5'd4:p8_freq_label=7'd66;
5'd8:p8_freq_label=7'd59;
5'd9:p8_freq_label=7'd64;
5'd10:p8_freq_label=7'd67;
5'd11:p8_freq_label=7'd68;
5'd12:p8_freq_label=7'd69;
5'd16:p8_freq_label=7'd59;
5'd17:p8_freq_label=7'd67;
5'd18:p8_freq_label=7'd70;
5'd19:p8_freq_label=7'd71;
5'd20:p8_freq_label=7'd72;
default:p8_freq_label=0;endcase end endfunction
function automatic [2:0] p8_freq_len(input [1:0] zoom,input [2:0] tick);begin case({zoom,tick})
5'd0:p8_freq_len=3'd1;
5'd1:p8_freq_len=3'd3;
5'd2:p8_freq_len=3'd3;
5'd3:p8_freq_len=3'd4;
5'd4:p8_freq_len=3'd4;
5'd8:p8_freq_len=3'd1;
5'd9:p8_freq_len=3'd3;
5'd10:p8_freq_len=3'd4;
5'd11:p8_freq_len=3'd4;
5'd12:p8_freq_len=3'd4;
5'd16:p8_freq_len=3'd1;
5'd17:p8_freq_len=3'd4;
5'd18:p8_freq_len=3'd4;
5'd19:p8_freq_len=3'd4;
5'd20:p8_freq_len=3'd4;
default:p8_freq_len=1;endcase end endfunction
