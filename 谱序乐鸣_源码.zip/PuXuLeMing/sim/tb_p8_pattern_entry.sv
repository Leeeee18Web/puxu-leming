`timescale 1ns/1ps
module tb_p8_pattern_entry;
 reg clk=0;always #10 clk=~clk;
 reg rst=1,update=0,valid=1,down=0;reg[15:0]x=0,y=0;
 wire ev,ready,controller_ready,clear_live,muted,stop,pattern_start,restart;wire[31:0]data;
 wire[1:0]pattern_mode;reg[5:0]sample_div=0;
 always @(posedge clk)if(rst)sample_div<=0;else sample_div<=sample_div+1'b1;
 wire sample_tick=sample_div==0;
 wire[2:0]page;wire[1:0]mode;wire[6:0]base;
 wire[6:0]live_gates;wire[48:0]live_notes;wire[83:0]live_gains;
 p8_navigation nav(.clk(clk),.rst(rst),.touch_update(update),.touch_valid(valid),.touch_down(down),
  .touch_x(x),.touch_y(y),.event_ready(ready),.event_valid(ev),.event_data(data),
  .panic_key(1'b0),.centre_key(1'b0),.page(page),.mode(mode),.base_note(base),
  .clear_live(clear_live),.muted(muted),.stop_score(stop),.pattern_mode(pattern_mode),.pattern_start(pattern_start),
  .knob_mode(),.centre(),.panic(),.start_score(),.restart_lesson(restart),.xy_config(),.spectrum_zoom());
 assign ready=controller_ready&&!clear_live;
 wire pattern_select=mode==1&&pattern_mode!=0;
 wire note_event=data[7:4]==8||data[7:4]==9;
 play_voice_control controller(.clk(clk),.rst(rst),.sample_tick(sample_tick),
  .event_valid(ev&&ready&&!(pattern_select&&note_event)),
  .event_data(data),.event_ready(controller_ready),.panic(clear_live),.centre(1'b0),
  .gates(live_gates),.notes(live_notes),.gains(live_gains),.knob_mode(2'd1),
  .triggers(),.ratio(),.knob(),.last_note(),.last_velocity(),.mod_depth(),.raw_knob(),.raw_known(),.pickup_wait());
 wire[6:0]selected,gates,triggers;wire[48:0]selected_notes,notes;wire[83:0]selected_gains,gains;
 wire busy,full;wire[2:0]count;
 p8_patterns #(.STRUM_SAMPLES(4),.ARP_SAMPLES(12),.HOLD_SAMPLES(32)) patterns(
  .clk(clk),.rst(rst),.sample_tick(sample_tick),.cancel(clear_live||stop||muted||mode!=1),
  .pattern_mode(pattern_mode),.start(pattern_start),.event_valid(ev&&ready&&pattern_select),.event_data(data),
  .selected(selected),.selected_notes(selected_notes),.selected_gains(selected_gains),
  .gates(gates),.triggers(triggers),.notes(notes),.gains(gains),.busy(busy),.count(count),.full(full));
 integer checks=0,starts=0,restarts=0,s;
 always @(posedge clk)begin if(pattern_start)starts=starts+1;if(restart)restarts=restarts+1;end
 task check(input bit ok,input string message);begin checks=checks+1;if(!ok)$fatal(1,"%s",message);end endtask
 task report(input bit d,input integer xx,yy);begin
  @(negedge clk);x=xx;y=yy;down=d;update=1;
  @(negedge clk);update=0;repeat(12)@(negedge clk);
 end endtask
 task tap(input integer xx,yy);begin report(1,xx,yy);report(0,xx,yy);end endtask
 initial begin
  repeat(5)@(negedge clk);rst=0;
  tap(300,280);tap(656,96);check(mode==1&&page==5,"perform keyboard entry");
  report(1,64,550);check(live_gates==1,"normal direct performance retained");report(0,64,550);
  tap(620,200); // chord
  check(pattern_mode==2,"chord button selects mode");
  report(1,64,550);
  check(live_gates==0,"pattern selection must remain silent until trigger");
  check(count==1&&selected_notes[6:0]==60,"selection accepted actual C4");
  repeat(3)report(1,64,550);check(count==1,"held contact cannot repeatedly toggle selection");
  report(0,64,550);check(count==1,"release retains selection");
  tap(192,550);tap(320,550);check(count==3&&gates==0,"three selected notes remain silent");
  tap(192,550);check(count==2,"retap deselects");tap(192,550);
  report(1,928,200);s=starts;repeat(10)report(1,928,200);
  check(starts==s&&starts==1,"held trigger fires once");report(0,928,200);
  repeat(200)@(negedge clk);check(gates==selected&&busy,"trigger starts complete chord");
  tap(450,200);check(pattern_mode==1&&count==3&&gates==0,"switch to strum retains choices and cancels old run");
  tap(552,200);check(pattern_mode==1,"interbutton gap is inert");
  tap(280,200);check(base==72&&count==3,"octave navigation retains actual selected pitches");
  tap(96,320);check(count==4,"black Csharp5 joins selection");
  tap(928,200);repeat(200)@(negedge clk);check(busy&&gates!=0,"strum trigger schedules first note");
  tap(760,200);check(pattern_mode==3&&gates==0,"arp mode switch stops strum");
  tap(760,200);check(pattern_mode==0,"same mode button returns to ordinary direct play");
  report(1,64,550);check(live_gates==1&&live_notes[6:0]==72,"direct C5 restored");report(0,64,550);
  s=starts;tap(928,200);check(starts==s,"trigger with no selected mode is inert");
  report(1,450,200);report(1,96,320);check(count==4,"button contact cannot become piano selection by drag");report(0,96,320);
  tap(40,32);tap(660,280);check(mode==3&&page==5&&pattern_mode==0,"follow entry clears pattern mode");
  s=restarts;tap(450,200);check(restarts==s+1&&pattern_mode==0,"follow restart still owns overlapping button region");
  check(starts==2,"only two intentional pattern triggers");
  $display("P8_PATTERN_ENTRY_PASS checks=%0d starts=%0d",checks,starts);$finish;
 end
 initial begin #1000000;$fatal(1,"deadline");end
endmodule
