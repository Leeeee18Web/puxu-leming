`timescale 1ns/1ps
module tb_enable12_busy;
 reg clk=0;always #10 clk=~clk;
 reg rst=0,tick=0,trigger=0,gate=1,ctx_enable=0,ctx_load=0;
 reg[406:0]ctx_data=0;reg[17:0]mem_q=0;reg signed[17:0]bridge_return=0;
 wire[2:0]busy,error,we;wire[2:0][406:0]context_state;
 wire[2:0][17:0]sample,incident,incident_next,mem_data;
 wire[2:0][15:0]envelope,impact;wire[2:0][12:0]ra,wa;
 genvar i;
 generate for(i=0;i<3;i=i+1)begin:model
  if(i==2)begin:old
   enable12_line_old #(.LENGTH(2048),.PREDECODE_PIANO(1),.PRECALC_TUNING(1),.EXTERNAL_TUNING(1),.EXTERNAL_IMPACT(1),.PRECALC_PICKUP(1)) dut(
    .clk(clk),.rst(rst),.tick(tick),.trigger(trigger),.gate(gate),.kind(3'd1),.velocity(12'd2500),.step(24'd45000),.rate_shift(2'd0),.period_q10(24'd90000),
    .sample(sample[i]),.envelope(envelope[i]),.busy(busy[i]),.deadline_error(error[i]),.bridge_return(bridge_return),.bridge_incident(incident[i]),.piano_mode(1'b1),.bridge_incident_next(incident_next[i]),
    .ctx_enable(ctx_enable),.ctx_load(ctx_load),.ctx_data(ctx_data),.ctx_state(context_state[i]),.mem_q(mem_q),.mem_raddr(ra[i]),.mem_waddr(wa[i]),.mem_we(we[i]),.mem_data(mem_data[i]),.shared_tuning(16'd137),.shared_impact(18'sd71),.impact_phase(impact[i]));
  end else begin:current
   poly_model_line #(.PRECALC_BUSY(i),.LENGTH(2048),.PREDECODE_PIANO(1),.PRECALC_TUNING(1),.EXTERNAL_TUNING(1),.EXTERNAL_IMPACT(1),.PRECALC_PICKUP(1)) dut(
    .clk(clk),.rst(rst),.tick(tick),.trigger(trigger),.gate(gate),.kind(3'd1),.velocity(12'd2500),.step(24'd45000),.rate_shift(2'd0),.period_q10(24'd90000),
    .sample(sample[i]),.envelope(envelope[i]),.busy(busy[i]),.deadline_error(error[i]),.bridge_return(bridge_return),.bridge_incident(incident[i]),.piano_mode(1'b1),.bridge_incident_next(incident_next[i]),
    .ctx_enable(ctx_enable),.ctx_load(ctx_load),.ctx_data(ctx_data),.ctx_state(context_state[i]),.mem_q(mem_q),.mem_raddr(ra[i]),.mem_waddr(wa[i]),.mem_we(we[i]),.mem_data(mem_data[i]),.shared_tuning(16'd137),.shared_impact(18'sd71),.impact_phase(impact[i]));
  end
 end endgenerate
 integer checks=0,s,e,r,t,k,j,restores=0,random_cycles=0;
 always @(negedge clk)begin
  #2;
  for(integer m=0;m<2;m=m+1)
   if({busy[m],error[m],we[m],context_state[m],sample[m],incident[m],incident_next[m],mem_data[m],envelope[m],impact[m],ra[m],wa[m]}!==
      {busy[2],error[2],we[2],context_state[2],sample[2],incident[2],incident_next[2],mem_data[2],envelope[2],impact[2],ra[2],wa[2]})$fatal(1,"ENABLE12_LINE_ALL_OUTPUTS state%0d enable%b rst%b trigger%b tick%b model%0d",s,ctx_enable,rst,trigger,tick,m);
  if(busy[1] !== (model[1].current.dut.state!=0))$fatal(1,"ENABLE12_BUSY_RAW_STATE_EXACT");
  checks++;
 end
 initial begin
  @(negedge clk);
  // Restore has priority even when enable is low or rst/trigger is high.
  // All 64 restored encodings exercise the original default transition too.
  for(s=0;s<64;s++)for(e=0;e<2;e++)for(r=0;r<2;r++)for(t=0;t<2;t++)for(k=0;k<2;k++)begin
   for(j=0;j<407;j++)ctx_data[j]=$random;
   ctx_data[366+:6]=s;ctx_load=1;ctx_enable=e;rst=r;trigger=t;tick=k;
   @(negedge clk);#3;ctx_load=0;restores++;
   @(negedge clk);#3;
  end
  for(j=0;j<12000;j++)begin
   ctx_load=(j%53)==0;ctx_enable=$random;rst=(j%179)==0;trigger=(j%127)==0;tick=(j%7)==0;
   gate=$random;mem_q=$random;bridge_return=$random;
   if(ctx_load)ctx_data=context_state[2];
   @(negedge clk);#3;random_cycles++;
  end
  $display("ENABLE12_BUSY_PASS checks%0d restores%0d all64states/enable/rst/trigger/tick randomCycles%0d default0+production1",checks,restores,random_cycles);
  $finish;
 end
endmodule
