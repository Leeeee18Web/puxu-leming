`timescale 1ns/1ps
module tb_poly_ratio_borrow_boundary;
 `include "src/poly/poly_model_layout.vh"
 reg clk=0;always #10 clk=~clk;reg rst=1,tick=0,trig=0,en=1,load=0;
 poly_model_line dut(.clk(clk),.rst(rst),.tick(tick),.trigger(trig),.gate(1'b1),.kind(3'd1),.velocity(12'd2400),.step(24'd151197),.rate_shift(2'd0),.period_q10(24'd100000),.sample(),.envelope(),.busy(),.deadline_error(),.bridge_return(18'sd0),.bridge_incident(),.piano_mode(1'b1),.bridge_incident_next(),.ctx_enable(en),.ctx_load(load),.ctx_data({`POLY_MODEL_LINE_W{1'b0}}),.ctx_state(),.mem_q(18'd1800),.mem_raddr(),.mem_waddr(),.mem_we(),.mem_data(),.shared_tuning(16'd0),.shared_impact(18'sd0),.impact_phase());
 reg signed[17:0]want_a,want_b;
 initial begin
  repeat(3)@(negedge clk);rst=0;tick=1;@(negedge clk);tick=0;
  wait(dut.state==24);#1;force dut.state=6'd26;#1;want_a={13'd0,dut.mul_b[9:5]};
  if(dut.z0[4:0]==0)force dut.z0[4:0]=5'd1;else force dut.z0[4:0]=5'd0;#1;
  if(dut.mul_b[9:5]!==want_a[4:0])$fatal(1,"RATIO_BORROW_BOUNDARY_MISSING");
  $display("POLY_RATIO_BORROW_BOUNDARY_PASS no low-z to upper complement borrow cone");$finish;
 end
 initial begin #100000;$fatal(1,"RATIO_BORROW_BOUNDARY_TIMEOUT");end
endmodule
