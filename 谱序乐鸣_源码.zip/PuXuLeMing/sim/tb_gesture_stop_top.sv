`timescale 1ns/1ps
module tb_gesture_stop_top;
 reg clk=0,rstn=0,key1_n=1,rx=1;always #10 clk=~clk;tri dp,dm;
 hub_play_top dut(.clk(clk),.rstn(rstn),.key1_n(key1_n),.key2_n(1'b1),.uart_rx(rx),.usb_dp(dp),.usb_dm(dm),
  .uart_tx(),.hp_bck(),.hp_ws(),.hp_din(),.pa_en(),.i2s_bck(),.i2s_ws(),.i2s_sd(),.led_o(),
  .tmds_clk_p_0(),.tmds_clk_n_0(),.tmds_d_p_0(),.tmds_d_n_0());
 always @(negedge clk)if(dut.model_resetn !== {12{dut.audio_reset[2]}})$fatal(1,"RESET_DISTRIBUTION_NOT_SAME_CYCLE");
 // Check real consumers during reset, fresh-context clearing, tone changes and stop/replay.
 genvar reset_group;generate for(reset_group=0;reset_group<2;reset_group=reset_group+1)begin:reset_checks
  always @(negedge clk)begin
   if(dut.audio.physical.group[reset_group].worker.model_reset !== {3{dut.rst}})$fatal(1,"MODEL_GROUP_NOT_SAME_CYCLE");
   if(dut.audio.physical.group[reset_group].worker.ENABLE_EP!==0)$fatal(1,"EP_MUST_BE_REMOVED");
   if(dut.audio.physical.group[reset_group].worker.strings.rst !== (dut.rst||dut.audio.physical.group[reset_group].worker.context_clear||!dut.audio.physical.group[reset_group].worker.is_strings))$fatal(1,"STRINGS_CLEAR_SEMANTICS");
   if(dut.audio.physical.group[reset_group].worker.reed.rst !== (dut.rst||dut.audio.physical.group[reset_group].worker.context_clear||!dut.audio.physical.group[reset_group].worker.is_reed))$fatal(1,"REED_CLEAR_SEMANTICS");
  end
 end endgenerate
 always @(negedge dut.usb_clk)if(dut.usb_reset_phy !== dut.usb_reset[2])$fatal(1,"PHY_RESET_NOT_SAME_CYCLE");
 always @(posedge dut.pixel_clk)if(dut.pixel_reset_timing !== dut.pixel_reset[2])$fatal(1,"PIXEL_RESET_NOT_SAME_CYCLE");
 defparam dut.host_link.UART_DIV=8;defparam dut.status_bridge.PERIOD=10;defparam dut.pedal_button.TICKS=4;
 task clocks(input integer n);repeat(n)@(negedge clk);endtask
 task frames(input integer n);repeat(n)begin @(posedge dut.sample_tick);@(negedge clk);end endtask
 task touch(input integer x,y,input bit down);begin dut.soc.hid_report(x,y,down,1);clocks(40);end endtask
 task tap(input integer x,y);begin touch(x,y,0);touch(x,y,1);touch(x,y,0);end endtask
 task ev(input[31:0]v);begin dut.soc.midi_event(v);clocks(100);end endtask
 function automatic[15:0]crcbyte(input[15:0]c,input[7:0]b);
  reg[15:0]v;integer k;begin v=c^{b,8'd0};for(k=0;k<8;k=k+1)v=v[15]?(v<<1)^16'h1021:v<<1;crcbyte=v;end
 endfunction
 task byteout(input[7:0]b);integer j;begin
  @(negedge clk);rx=0;clocks(8);for(j=0;j<8;j=j+1)begin rx=b[j];clocks(8);end rx=1;clocks(8);
 end endtask
 reg[15:0]stop_seq=9;
 task hardstop;reg[7:0]b[0:15];reg[15:0]crc;integer j;begin
  b[0]="G";b[1]="S";b[2]=2;b[3]=8'h26;b[4]=stop_seq[7:0];b[5]=stop_seq[15:8];b[6]=8;b[7]=0;stop_seq=stop_seq+1'b1;
  b[8]=2;b[9]=0;b[10]=0;b[11]=0;b[12]="P";b[13]="8";b[14]="G";b[15]="1";
  crc=16'hffff;for(j=2;j<16;j=j+1)crc=crcbyte(crc,b[j]);for(j=0;j<16;j=j+1)byteout(b[j]);byteout(crc[7:0]);byteout(crc[15:8]);
 end endtask
 integer checks=0,nz=0;task check(input bit ok,input string why);begin checks++;if(!ok)$fatal(1,"STOP_TOP_FAIL %s",why);end endtask
 always @(posedge clk)if(!dut.rst&&dut.sample_tick)begin if(dut.pcm!=0)nz++;check(!dut.audio_deadline_error,"audio deadline");end
 initial begin
  clocks(20);rstn=1;clocks(2000);dut.soc.ptest_debug[255:224]=32'h0c;clocks(100);tap(300,280);tap(650,96);
  key1_n=0;clocks(100);ev(32'h00643c90);frames(250);ev(32'h00003c80);frames(5);
  check(dut.live_gates!=0&&dut.pedal_down,"pedal really holds physical USB note");check(nz>10,"actual physical model sounding");
  hardstop;frames(6);check(dut.live_gains==0&&dut.gates==0&&dut.gains==0,"serial stop clears all owners despite pedal");
  check(dut.pcm==0&&!dut.recording&&!dut.replaying&&!dut.wifi_score_playing,"stop reaches PCM and transports");
  check(dut.host_link.reply_result==0,"emergency stop accepted");
  key1_n=1;clocks(100);ev(32'h00644090);frames(250);check(dut.live_gates!=0&&dut.pcm!=0,"ordinary performance resumes");
  tap(100,195);frames(2);check(dut.recording,"real recorder starts before FX configuration");
  tap(800,30);tap(800,304);tap(800,354);tap(800,399);tap(500,240);frames(700);
  check(dut.sound_config[5:0]==6'h15&&dut.audio.ui_depth==24,"all three effects actually enabled");
  check(dut.audio.effects.processor.engine.c_input!=0&&dut.audio.effects.processor.engine.r_input!=0,"real chorus/reverb running with audio");
  tap(100,195);frames(2);check(!dut.recording&&dut.record_count>2,"nonempty effect-bearing take retained");
  tap(280,195);frames(40);check(dut.replaying&&dut.sound_config[5:0]==6'h15,"real replay restores effect-bearing recorded controls");
  hardstop;frames(8);
  check(!dut.replaying&&!dut.recording&&dut.record_count>2,"hard stop cancels actual replay but retains take");
  check(dut.pcm==0&&dut.gains==0&&dut.audio.effects.processor.blend==0,"hard stop removes actual FX tail and dry PCM");
  // Reassert away from an edge: original asynchronous assertion, third-edge release.
  #3;rstn=0;#1;check(dut.audio_reset==0&&dut.model_resetn==0,"asynchronous reset assertion");
  clocks(3);rstn=1;
  repeat(2)begin @(posedge clk);#1;check(dut.rst&&dut.model_resetn==0,"reset holds first two edges");end
  @(posedge clk);#1;check(!dut.rst&&dut.model_resetn==12'hfff,"reset releases on original third edge");
  $display("GESTURE_STOP_TOP_PASS checks=%0d nonzero=%0d real UART/pedal/PCM/transports/recovery",checks,nz);$finish;
 end
 initial begin #60000000;$fatal(1,"STOP_TOP_TIMEOUT");end
endmodule
