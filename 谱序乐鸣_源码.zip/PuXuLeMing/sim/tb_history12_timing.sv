`timescale 1ns/1ps
module history12_timing_case #(parameter REAL=1)(output reg done=0);
 reg pixel_clock=0;always #10 pixel_clock=~pixel_clock;
 reg rstn=0,ext_sync=0;
 wire[13:0] x,y,ox,oy,h,v,oh,ov;wire[9:0]history_addr;
 wire hs,vs,de,ls,ohs,ovs,ode,ols;
 final_video_timing_ctrl #(.video_hlength(REAL==2?16384:REAL?1344:2200),.video_vlength(REAL?635:1125),
 .video_hsync_len(REAL==2?0:REAL?20:44),.video_hbp_len(REAL==2?0:REAL?140:148),.video_h_visible(REAL==2?16384:REAL?1024:1920),
 .video_vsync_len(REAL==2?0:REAL?3:5),.video_vbp_len(REAL==2?0:REAL?20:36),.video_v_visible(REAL?600:1080)) dut(
 .pixel_clock(pixel_clock),.rstn(rstn),.ext_sync(ext_sync),.timing_h_pos(h),.timing_v_pos(v),
 .pixel_x(x),.pixel_y(y),.history_addr(history_addr),.video_hsync(hs),.video_vsync(vs),.video_den(de),.video_line_start(ls));
 history12_old_timing #(.video_hlength(REAL==2?16384:REAL?1344:2200),.video_vlength(REAL?635:1125),
 .video_hsync_len(REAL==2?0:REAL?20:44),.video_hbp_len(REAL==2?0:REAL?140:148),.video_h_visible(REAL==2?16384:REAL?1024:1920),
 .video_vsync_len(REAL==2?0:REAL?3:5),.video_vbp_len(REAL==2?0:REAL?20:36),.video_v_visible(REAL?600:1080)) old(
 .pixel_clock(pixel_clock),.rstn(rstn),.ext_sync(ext_sync),.timing_h_pos(oh),.timing_v_pos(ov),
 .pixel_x(ox),.pixel_y(oy),.video_hsync(ohs),.video_vsync(ovs),.video_den(ode),.video_line_start(ols));
 wire[9:0] expected=ox>=14'd127&&ox<14'd895 ? ox-14'd127 : 0;
 integer checks=0,i,j;
 task cycle;begin
 @(posedge pixel_clock);#1;
 if({h,v,x,y,hs,vs,de,ls}!=={oh,ov,ox,oy,ohs,ovs,ode,ols})$fatal(1,"HISTORY12_PUBLIC_TIMING_CHANGED real%0d cycle%0d",REAL,checks);
 if(history_addr!==expected)$fatal(1,"HISTORY12_ADDR_RANGE real%0d h%0d v%0d x%0d got%0d expected%0d",REAL,h,v,x,history_addr,expected);
 checks++;@(negedge pixel_clock);
 end endtask
 initial begin
 repeat(3)cycle;rstn=1;
 // Each possible raw counter value, both visible and blanking vertical
 // branches, including values outside the configured raster and h wrap.
 for(j=0;j<2;j++)for(i=0;i<16384;i++)begin
 dut.h_pos=i;old.h_pos=i;dut.v_pos=REAL==2?(j?0:600):(j?(REAL?23:41):0);old.v_pos=dut.v_pos;
 cycle;
 end
 // Asynchronous reset and resynchronization preserve the same settled edge.
 repeat(2000)begin ext_sync=checks%37==0;rstn=checks%431!=0;cycle;end
 $display("HISTORY12_TIMING_PASS real%0d checks%0d all14bitHVisibleBlanking resetExtSync sameEpoch",REAL,checks);done=1;
 end
endmodule
module tb_history12_timing;
 wire[2:0]done;history12_timing_case #(.REAL(1)) actual(done[0]);history12_timing_case #(.REAL(0)) defaults(done[1]);history12_timing_case #(.REAL(2)) all14bitX(done[2]);
 initial begin wait(&done);$finish;end
endmodule
