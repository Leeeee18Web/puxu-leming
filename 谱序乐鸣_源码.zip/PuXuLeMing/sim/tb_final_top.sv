`timescale 1ns/1ps
// Native PLL/physical pads and firmware publication boundary are modeled.
// Every production navigation, CDC, arbiter, allocator, source, recorder,
// voice engine, serial output and display module is instantiated by real top.
module tb_final_top;
 reg clk=0,rstn=0;always #10 clk=~clk;
 tri dp,dm;wire[7:0]led;wire bck,ws,sd,ib,iw,idata;
 hub_play_top dut(.clk(clk),.rstn(rstn),.key1_n(1'b1),.key2_n(1'b1),.uart_rx(1'b1),.uart_tx(),
  .usb_dp(dp),.usb_dm(dm),.hp_bck(bck),.hp_ws(ws),.hp_din(sd),.i2s_bck(ib),.i2s_ws(iw),.i2s_sd(idata),
  .pa_en(),.led_o(led),.tmds_clk_p_0(),.tmds_clk_n_0(),.tmds_d_p_0(),.tmds_d_n_0());
 defparam dut.status_bridge.PERIOD=10;
 integer checks=0,nz=0,cycles=0,i,j,dual_left=0,dual_right=0,dual_mixed=0;
 reg dual_phase=0;
 reg[23:0]physical_step;reg[48:0]seven_notes_before;
 reg[11:0]physical_gain;
 reg[6:0]physical_slot,touch_slot;
 always @(posedge clk)if(!dut.rst)begin
  cycles++;
  if(dut.sample_tick)begin
   check(^dut.pcm!==1'bx,"actual mixed PCM is known including retrigger fades");
   check(!dut.audio_deadline_error,"all audio engines meet sample deadline");
   if(dut.pcm!=0)nz++;
   if(dual_phase)begin
    if(dut.audio.smooth_sample[0]!=0)dual_left++;
    if(dut.audio.smooth_sample[1]!=0)dual_right++;
    if(dut.pcm!=0)dual_mixed++;
   end
   if(dut.replaying)check(dut.replay_frame_ready,"coherent replay staged before render");
  end
 end
 task check(input bit ok,input string label_text);begin checks++;if(!ok)$fatal(1,"FINAL_TOP_FAIL %s",label_text);end endtask
 task waitclks(input integer count);begin repeat(count)@(negedge clk);end endtask
 task frames(input integer count);integer k;begin for(k=0;k<count;k++)begin @(posedge dut.sample_tick);@(negedge clk);end end endtask
 task touch(input integer x,y,input bit down);begin dut.soc.hid_report(x,y,down,1);waitclks(40);end endtask
 task tap(input integer x,y);begin touch(x,y,0);touch(x,y,1);touch(x,y,0);end endtask
 task eventword(input[31:0]word);begin dut.soc.midi_event(word);waitclks(50);end endtask
 task reset_all;begin rstn=0;waitclks(10);rstn=1;waitclks(1000);end endtask
 initial begin
  reset_all;
  check($bits(dut.gates)==7&&$bits(dut.notes)==49&&$bits(dut.monitor_steps)==168,"production root has exactly seven voices");
  check($bits(dut.audio.physical.worker_busy)==2&&$bits(dut.audio.physical.group[0].worker.gates)==4&&$bits(dut.audio.physical.group[1].worker.gates)==3,"physical workers contain 4/3 independent states");
  dut.soc.ptest_debug[255:224]=32'h0c;waitclks(80);
  check(dut.page==0&&dut.mode==0&&dut.timbre_select==1,"mature Home startup and accepted piano");
  check(dut.piano_ready&&dut.touch_ready&&dut.touch_state[0]==0,"configured devices reported independently before first input");
  tap(300,280);tap(650,96);
  check(dut.mode==1&&dut.page==5&&dut.base_note==60&&dut.knob==64,"performance and original tuning");
  eventword(32'h00643c90);frames(5);waitclks(100);
  physical_slot=0;
  for(i=0;i<7;i++)if(dut.live_gates[i]&&dut.live_notes[i*7+:7]==60)physical_slot=i;
  physical_step=dut.monitor_steps[physical_slot*24+:24];physical_gain=dut.live_gains[physical_slot*12+:12];
  check(physical_step!=0&&physical_gain!=0,"physical MIDI passes real mailbox to synthesis");
  eventword(32'h00644090);dual_phase=1;frames(400);dual_phase=0;
  check($countones(dut.live_gates)==2&&dut.active[0]&&dut.active[1],"two physical keys sustain two independent voices simultaneously");
  $display("GRAND_DUAL_DIAG left=%0d right=%0d mixed=%0d tones=%h active=%h steps=%h",dual_left,dual_right,dual_mixed,dut.audio_timbres,dut.active,dut.monitor_steps);
  check(dut.monitor_steps[0+:24]!=dut.monitor_steps[24+:24]&&dual_left>100&&dual_right>100&&dual_mixed>100,"C4 E4 both generate nonzero independent PCM and enter actual mix");
  eventword(32'h00003c80);frames(10);
  check($countones(dut.live_gates)==1&&dut.live_notes[7+:7]==64&&dut.live_gates[1],"release first physical key preserves second sustained key");
  eventword(32'h00004080);frames(1);
  eventword(32'h00643c90);frames(1);
  eventword(32'h00003c80);frames(1);
  touch(64,500,1);frames(5);waitclks(100);
  touch_slot=0;
  for(i=0;i<7;i++)if(dut.live_gates[i]&&dut.live_notes[i*7+:7]==60)touch_slot=i;
  check(dut.monitor_steps[touch_slot*24+:24]==physical_step&&dut.live_gains[touch_slot*12+:12]==physical_gain&&dut.live_timbres[touch_slot*3+:3]==1,"equal physical and touch note/velocity share pitch gain and timbre");
  touch(64,500,0);
  reset_all;tap(300,280);tap(650,96);
  for(i=0;i<4;i++)eventword((32'd100<<16)|((32'd40+i)<<8)|32'h90);
  frames(6);
  check($countones(dut.live_gates)==4&&$countones(dut.gates)==4,"real arbiter allocator source recorder audio boundary carries four voices");
  eventword((32'd100<<16)|(32'd90<<8)|32'h90);frames(2);
  check(dut.live_notes[0+:28]=={7'd43,7'd42,7'd41,7'd40}&&dut.live_gates[4:0]==5'b11111&&dut.live_notes[28+:7]==90,"fifth held key receives its own voice and preserves all four held notes");
  for(i=4;i<6;i++)eventword((32'd100<<16)|((32'd40+i)<<8)|32'h90);
  frames(140);
  check(dut.live_gates==7'h7f&&dut.active==7'h7f,"all7 physical keys held and audibly active through real production top");
  seven_notes_before=dut.live_notes;
  eventword((32'd100<<16)|(32'd91<<8)|32'h90);frames(2);
  check(dut.live_notes==seven_notes_before&&dut.live_gates==7'h7f,"eighth held key does not steal any of seven finger-held voices");
  eventword((32'd41<<8)|32'h80);frames(2);
  eventword((32'd100<<16)|(32'd41<<8)|32'h90);frames(2);
  check(dut.live_gates==7'h7f&&dut.live_notes[0+:28]=={7'd43,7'd42,7'd41,7'd40},"released owner retriggers independently while all6 neighbors remain held");
  eventword((32'd45<<8)|32'h80);frames(2);
  eventword((32'd100<<16)|(32'd91<<8)|32'h90);frames(2);
  check(dut.live_gates==7'h7f&&dut.live_notes[6*7+:7]==91,"released seventh slot is reused with a safe onset");
  eventword((32'd45<<8)|32'h80);frames(2);
  check(dut.live_gates==7'h7f&&dut.live_notes[6*7+:7]==91,"old noteoff cannot release the reused seventh owner");
  eventword((32'd91<<8)|32'h80);frames(2);
  eventword((32'd100<<16)|(32'd45<<8)|32'h90);frames(2);
  check(dut.home_gates!=0&&dut.active[3],"fourth voice remains audible and visible");
  check(nz>0,"actual HDL PCM nonzero");
  // Begin recording, switch page without changing recording state, capture release.
  tap(100,195);frames(2);check(dut.recording,"record command reaches recorder");
  tap(160,96);frames(2);check(dut.recording&&dut.page==2,"tab transition preserves independent recording");
  for(i=0;i<6;i++)eventword(((32'd40+i)<<8)|32'h80);eventword((32'd90<<8)|32'h80);
  frames(2);tap(280,150);frames(3);
  check(!dut.recording&&dut.replaying&&dut.record_count>=5,"Replay closes final frame and starts saved take");
  // Explicit global Stop affects replay, unlike navigation transitions.
  tap(600,32);frames(2);check(!dut.recording&&!dut.replaying&&dut.record_count>=5,"explicit Stop retains take and stops replay");
  reset_all;tap(300,280);tap(650,96);
  tap(100,195);frames(1);tap(300,32);frames(3);
  check(dut.recording&&dut.mode==2,"switch to song keeps recorder active");
  tap(280,150);frames(3);check(dut.replaying&&!dut.recording,"song controls record and replay through shared boundary");
  // Independent diagnostic owner loss is not inferred from held keys.
  dut.soc.ptest_debug[255:224]=32'h14;waitclks(80);
  check(!dut.piano_ready&&dut.touch_ready,"failed MIDI owner does not hide configured touch");
  $display("FINAL_TOP_PASS checks=%0d clocks=%0d nonzeroPCM=%0d dualPCM=%0d/%0d/mix%0d",checks,cycles,nz,dual_left,dual_right,dual_mixed);$finish;
 end
 initial begin #20000000;$fatal(1,"FINAL_TOP_FAIL timeout");end
endmodule
