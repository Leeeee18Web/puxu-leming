`timescale 1ns/1ps
module tb_p8_snapshot;
 reg clk=0,pclk=0;always #10 clk=~clk;always #9.756097561 pclk=~pclk;
 reg rstn=0,prstn=0,frame=0;reg[225:0]src=0;
 wire[225:0]old_data,new_data;
 snapshot_before #(.WIDTH(226),.PERIOD(19)) old_dut(.clk(clk),.rstn(rstn),.source_data(src),.pixel_clk(pclk),.pixel_rstn(prstn),.frame_start(frame),.data(old_data));
 instrument_snapshot #(.WIDTH(226),.PERIOD(19)) new_dut(.clk(clk),.rstn(rstn),.source_data(src),.pixel_clk(pclk),.pixel_rstn(prstn),.frame_start(frame),.data(new_data));
 integer i,checks=0,commits=0;reg[225:0]previous=0;
 always @(negedge clk)if(rstn)src<={src[224:0],src[225]^src[154]^src[91]^src[0]^1'b1};
 initial begin
  repeat(7)@(negedge pclk);rstn=1;prstn=1;
  for(i=0;i<20000;i=i+1)begin
   @(negedge pclk);frame=(i%73)==0;
   if(i==7000)prstn=0;if(i==7003)prstn=1;
   if(i==12000)rstn=0;if(i==12004)rstn=1;
   @(posedge pclk);#1;
   if(old_data!==new_data)$fatal(1,"snapshot cycle%0d changed",i);
   if(new_data!=previous)commits=commits+1;
   if(new_data!=previous&&!frame&&prstn)$fatal(1,"snapshot changed outside frame");
   previous=new_data;checks=checks+1;
  end
  if(commits<200)$fatal(1,"insufficient actual snapshot publications");
  $display("PASS tb_p8_snapshot checks=%0d commits=%0d zero_added_latency",checks,commits);$finish;
 end
endmodule
