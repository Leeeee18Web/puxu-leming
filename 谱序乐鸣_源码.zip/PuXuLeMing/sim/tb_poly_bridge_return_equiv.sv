`timescale 1ns/1ps
module tb_poly_bridge_return_equiv;
 `include "src/poly/poly_model_layout.vh"
 reg clk=0;always #10 clk=~clk;
 reg rst=1,render=0,trig=0,gate=1,en=1,load=0;
 reg[2:0]tone=1;reg[11:0]gain=2400;reg[23:0]step=45000;
 reg[17:0]qa=0,qb=0,qc=0;reg[`POLY_MODEL_STRINGS_W-1:0]restore=0,bank[0:2];
 wire[`POLY_MODEL_STRINGS_W-1:0]snapshota,snapshotb;
 wire signed[15:0]samplea,sampleb;wire[15:0]enva,envb;wire activea,activeb,busya,busyb,erra,errb,inita,initb,bodya,bodyb;
 wire[5:0]statea,stateb;wire[12:0]raa,rab,rba,rbb,rca,rcb,waa,wab,wba,wbb,wca,wcb;
 wire[2:0]wea,web;wire[17:0]daa,dab,dba,dbb,dca,dcb;
 poly_model_strings #(.LENGTH(64)) dut(.clk(clk),.rst(rst),.render_tick(render),.trigger(trig),.gate(gate),.timbre(tone),.gain(gain),.step(step),
 .ctx_enable(en),.ctx_load(load),.ctx_data(restore),.ctx_state(snapshota),.sample(samplea),.envelope(enva),.active(activea),.busy(busya),.deadline_error(erra),
 .mem_qa(qa),.mem_qb(qb),.mem_qc(qc),.mem_ra(raa),.mem_rb(rba),.mem_rc(rca),.mem_wa(waa),.mem_wb(wba),.mem_wc(wca),.mem_we(wea),.mem_da(daa),.mem_db(dba),.mem_dc(dca),.initializing_out(inita),.body_busy_out(bodya),.state_out(statea));
 poly_strings_before_return #(.LENGTH(64)) reference(.clk(clk),.rst(rst),.render_tick(render),.trigger(trig),.gate(gate),.timbre(tone),.gain(gain),.step(step),
 .ctx_enable(en),.ctx_load(load),.ctx_data(restore),.ctx_state(snapshotb),.sample(sampleb),.envelope(envb),.active(activeb),.busy(busyb),.deadline_error(errb),
 .mem_qa(qa),.mem_qb(qb),.mem_qc(qc),.mem_ra(rab),.mem_rb(rbb),.mem_rc(rcb),.mem_wa(wab),.mem_wb(wbb),.mem_wc(wcb),.mem_we(web),.mem_da(dab),.mem_db(dbb),.mem_dc(dcb),.initializing_out(initb),.body_busy_out(bodyb),.state_out(stateb));
 reg[31:0]rng=32'h35ac81ee;integer visit,c,row,checks=0,loads=0,nonzero_loads=0,pauses=0,triggers=0,resets=0,work9=0,work15=0,bridge16=0,saves=0;
 task cycle;begin
  #1;
  if(en&&!load)begin
   if(reference.a.state==9)work9++;if(reference.a.state==15)work15++;if(reference.a.state==16)bridge16++;
  end
  @(posedge clk);#1;
  if({snapshota,samplea,enva,activea,busya,erra,inita,bodya,statea,raa,rba,rca,waa,wba,wca,wea,daa,dba,dca}!==
     {snapshotb,sampleb,envb,activeb,busyb,errb,initb,bodyb,stateb,rab,rbb,rcb,wab,wbb,wcb,web,dab,dbb,dcb})$fatal(1,"BRIDGE_MODEL_EQ visit%0d c%0d state%0d",visit,c,statea);
  if({dut.a.bridge_return,dut.b.bridge_return,dut.c.bridge_return}!=={reference.return0,reference.return1,reference.return2})$fatal(1,"BRIDGE_RETURN_EVERY_EDGE_EQ visit%0d c%0d load%b en%b rst%b trig%b states%0d/%0d/%0d",visit,c,load,en,rst,trig,dut.a.state,dut.b.state,dut.c.state);
  if({dut.a.product,dut.b.product,dut.c.product}!=={reference.a.product,reference.b.product,reference.c.product})$fatal(1,"BRIDGE_PRODUCT_EQ visit%0d c%0d",visit,c);
  checks++;@(negedge clk);
 end endtask
 initial begin
  for(row=0;row<3;row++)bank[row]=0;
  repeat(3)cycle;rst=0;
  for(visit=0;visit<900;visit++)begin
   row=visit%3;en=0;load=1;restore=bank[row];step=45000+row*20000;gain=visit%97==30?0:1000+row*600;
   tone=1+row%2;gate=visit<870;loads++;if(|restore)nonzero_loads++;cycle;load=0;en=1;
   for(c=0;c<160;c++)begin
    rng={rng[30:0],rng[31]^rng[21]^rng[1]^rng[0]};qa=rng[17:0];qb=~rng[25:8];qc=rng[31:14];
    en=(c==0)||(rng[3:0]!=0);if(!en)pauses++;
    render=c==0;trig=c==0&&(visit<3||visit%97==0);if(trig)triggers++;
    rst=(visit==300||visit==600)&&c==0;if(rst)resets++;
    cycle;
   end
   if(reference.a.state>3||reference.b.state>3||reference.c.state>3)$fatal(1,"BRIDGE_LEGAL_SAVE_OVERFLOW visit%0d states%0d/%0d/%0d",visit,reference.a.state,reference.b.state,reference.c.state);
   bank[row]=snapshotb;saves++;
  end
  if(nonzero_loads==0||work9==0||work15==0||bridge16==0||pauses==0||triggers==0||resets==0)$fatal(1,"BRIDGE_EQ_COVERAGE");
  $display("POLY_BRIDGE_RETURN_EQ_PASS checks%0d loads%0d nonzero%0d pauses%0d triggers%0d resets%0d work9%0d work15%0d bridge16%0d legalSaves%0d same every edge/context/3modes",checks,loads,nonzero_loads,pauses,triggers,resets,work9,work15,bridge16,saves);$finish;
 end
endmodule
