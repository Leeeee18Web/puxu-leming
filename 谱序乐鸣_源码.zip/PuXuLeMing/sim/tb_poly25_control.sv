`timescale 1ns/1ps
module tb_poly25_control;
 reg clk=0;always #10 clk=~clk;reg rst=1,event_valid=0,panic=0,pedal_down=0,map_apply=0,map_enabled=1;
 reg[31:0]event_data=0;reg[1:0]event_source=1;reg[174:0]map_notes=0;reg[6:0]map_input_base=60;
 wire[24:0]gates,triggers;reg[24:0]tails=0;wire[174:0]notes;wire[299:0]gains;wire[74:0]timbres;wire event_ready;wire key_seen_valid;wire[4:0]key_seen_index;
 final_voice_control #(.VOICE_COUNT(25),.ENABLE_PEDAL(1))dut(.clk(clk),.rst(rst),.sample_tick(1'b0),.event_valid(event_valid),.event_data(event_data),.event_source(event_source),.event_ready(event_ready),.panic(panic),.centre(1'b0),.pedal_down(pedal_down),.timbre_select(3'd1),.voice_active(gates|tails),.timbres(timbres),.gates(gates),.notes(notes),.gains(gains),.triggers(triggers),.ratio(),.knob(),.last_note(),.last_velocity(),.mod_depth(),.knob_mode(2'd1),.raw_knob(),.raw_known(),.pickup_wait(),.map_notes(map_notes),.map_input_base(map_input_base),.map_enabled(map_enabled),.map_apply(map_apply),.key_seen_valid(key_seen_valid),.key_seen_index(key_seen_index),.ready_raw());
 integer checks=0,i,j;reg[24:0]before_gates;
 task check(input bit ok,input string msg);begin checks++;if(!ok)$fatal(1,"POLY25_CONTROL_FAIL %s gates=%h",msg,gates);end endtask
 task send(input[1:0]src,input[7:0]st,a,b,input[6:0]idx=0);begin @(negedge clk);event_source=src;event_data={idx,1'b1,b,a,st};event_valid=1;@(posedge clk);while(!event_ready)@(posedge clk);@(negedge clk);event_valid=0;end endtask
 task reset;begin @(negedge clk);rst=1;repeat(3)@(negedge clk);rst=0;tails=0;pedal_down=0;end endtask
 task apply;begin @(negedge clk);map_apply=1;@(negedge clk);map_apply=0;end endtask
 initial begin
 for(i=0;i<25;i++)map_notes[i*7+:7]=60+i;
 reset();for(i=0;i<25;i++)begin send(1,8'h90,60+i,100);check(key_seen_valid&&key_seen_index==i,"USB learn source key index");end
 check(gates==25'h1ffffff,"all25 held simultaneously");
 send(1,8'h90,110,100);check(gates==25'h1ffffff,"26th held rejected without stealing");
 for(i=0;i<25;i++)begin send(1,8'h80,60+i,0);check($countones(gates)==24-i,"all25 release independently");end
 reset();map_notes[6:0]=72;map_notes[13:7]=72;
 send(1,8'h90,60,100);send(1,8'h90,61,100);check($countones(gates)==2&&notes[6:0]==72&&notes[13:7]==72,"duplicate targets retain2 identities");
 map_notes[6:0]=12;map_notes[13:7]=13;check(notes[6:0]==72&&notes[13:7]==72,"editing table does not retune held voices");
 send(1,8'h80,60,0);check(gates==2,"first original off leaves duplicate held");
 send(1,8'h90,61,90);check(gates==2&&triggers==2,"same original key retriggers existing voice");
 send(0,8'h90,61,90);send(2,8'h90,61,90);send(3,8'h9e,72,90,1);send(3,8'h9d,61,90);
 check($countones(gates)==5,"touch USB gesture WiFi score ownership");
 check(notes[20:14]==61,"gesture note stays absolute");
 send(1,8'hff,0,0);check($countones(gates)==4&&!gates[1],"USB disconnect clears only USB");
 send(3,8'h8e,72,0,1);check($countones(gates)==3,"indexed WiFi off original ID");
 send(3,8'hff,0,0);check($countones(gates)==2,"WiFi disconnect clears WiFi score only");
 send(0,8'h80,61,0);send(2,8'h80,61,0);check(gates==0,"remaining owners independent off");
 reset();for(i=0;i<25;i++)send(i%4,8'h90|(i%3),60+i,100);
 check($countones(gates)==25,"mixed-source25 simultaneously held");
 for(j=0;j<4;j++)begin send(j,8'hff,0,0);check($countones(gates)==(j==0?18:j==1?12:j==2?6:0),"source disconnect independently clears mixed25");end
 reset();send(1,8'hb0,64,127);send(1,8'h90,60,100);send(1,8'h80,60,0);check($countones(gates)==1,"CC64 sustains");
 send(0,8'hb0,64,0);check($countones(gates)==1,"other source CC64 no effect");send(1,8'hb0,64,0);check(gates==0,"own CC64 releases");
 pedal_down=1;send(1,8'h90,60,100);send(1,8'h80,60,0);check($countones(gates)==1,"physical pedal holds");
 @(negedge clk);pedal_down=0;repeat(2)@(negedge clk);check(gates==0,"physical pedal release");
 send(1,8'hb0,64,127);send(1,8'h90,60,100);send(1,8'h80,60,0);apply();check(gates==0&&gains==0,"map apply clears gates/gains");
 send(1,8'h90,61,100);send(1,8'h80,61,0);check(gates==0,"map apply clears stale CC64");
 reset();for(i=0;i<25;i++)begin send(1,8'h90,60+i,100);end
 tails=gates;send(1,8'h80,60,0);send(1,8'h90,100,100);check(gates==25'h1ffffff&&notes[6:0]==100,"release tail can yield while held protected");
 send(1,8'h80,60,0);check(gates==25'h1ffffff,"stale tail off cannot release replacement");
 reset();map_notes[6:0]=0;map_notes[13:7]=127;send(1,8'h90,60,1);send(1,8'h90,61,127);check(notes[6:0]==0&&notes[13:7]==127,"mapped MIDI endpoints0/127");
 map_enabled=0;send(0,8'h90,62,100);check(notes[20:14]==62,"disabled mapper absolute");
 panic=1;@(negedge clk);panic=0;check(gates==0,"panic all");
 $display("POLY25_CONTROL_PASS checks=%0d",checks);$finish;
 end
 initial begin #100000;$fatal(1,"control timeout");end
endmodule
