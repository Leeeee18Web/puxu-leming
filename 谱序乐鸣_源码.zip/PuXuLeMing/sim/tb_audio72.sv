`timescale 1ns/1ps
module tb_audio72 #(parameter TONE=0);
 reg clk=0;always #10 clk=~clk;reg rst=1,rec=0,rep=0,panic=0;
 reg[6:0]gates=7'h7f,triggers=0;reg[48:0]notes=0;reg[83:0]gains=0;reg[20:0]timbres=0;
 reg[18:0]ratio=262144;reg[6:0]mod_depth=0;reg[31:0]config_word=0;
 wire tick;
 wire[6:0]rg,rt;wire[48:0]rn;wire[83:0]rga,obs;wire[20:0]rti;wire[18:0]rr;wire[6:0]rm;wire[31:0]rc;
 wire recording,replaying,full,limit,ready,export_ready;wire[12:0]count;wire[31:0]time_samples,take_id,duration;wire[95:0]export_word;
 final_recorder #(.VOICE_COUNT(7),.EVENT_CAPACITY(128),.MAX_SAMPLES(256)) recorder(
  .clk(clk),.rst(rst),.sample_tick(tick),.record_toggle(rec),.replay_toggle(rep),.clear(1'b0),.panic(panic),
  .in_gates(gates),.in_triggers(triggers),.in_notes(notes),.in_gains(gains),.in_timbres(timbres),.in_ratio(ratio),.in_mod_depth(mod_depth),.in_synth_config(config_word),
  .out_gates(rg),.out_triggers(rt),.out_notes(rn),.out_gains(rga),.out_timbres(rti),.out_ratio(rr),.out_mod_depth(rm),.out_synth_config(rc),
  .recording(recording),.replaying(replaying),.full(full),.time_limit(limit),.replay_frame_ready(ready),.count(count),.time_samples(time_samples),.export_address(12'd0),
  .export_word(export_word),.export_ready(export_ready),.take_id(take_id),.duration_samples(duration),.observer_gains(obs),
  .preview_rst(rst),.preview_gates(gates),.preview_notes(notes),.preview_gains(gains),.preview_timbres(timbres),.preview_ratio(ratio),.preview_mod_depth(mod_depth),.preview_synth_config(config_word));
 wire old_tick;wire signed[15:0]pcm,old_pcm;wire pos,old_pos,hb,old_hb,hw,old_hw,hd,old_hd,ib,old_ib,iw,old_iw,id,old_id,err,old_err,clip,old_clip;
 wire[6:0]active,old_active;wire[167:0]steps,old_steps;wire[111:0]env,old_env;
poly25_audio #(.VOICE_COUNT(7),.ENABLE_FX(1),.DISTRIBUTED_RESET(1),.REGIONAL_MODEL_CONTROLS(1)) dut(.clk(clk),.rst(rst),.gates(rg),.triggers(rt),.notes(rn),.gains(rga),.timbres(rti),.ratio(rr),.mod_depth(rm),.synth_config(rc),.sample_tick(tick),.pcm(pcm),.pcm_positive(pos),.hp_bck(hb),.hp_ws(hw),.hp_din(hd),.i2s_bck(ib),.i2s_ws(iw),.i2s_sd(id),.active(active),.monitor_steps(steps),.monitor_envelopes(env),.deadline_error(err),.clip_active(clip),.map_apply(1'b0),.model_reset({12{rst}}),.control_resetn_early(!rst));
audio72_old_audio #(.VOICE_COUNT(7),.ENABLE_FX(1),.DISTRIBUTED_RESET(1),.REGIONAL_MODEL_CONTROLS(1)) old(.clk(clk),.rst(rst),.gates(rg),.triggers(rt),.notes(rn),.gains(rga),.timbres(rti),.ratio(rr),.mod_depth(rm),.synth_config(rc),.sample_tick(old_tick),.pcm(old_pcm),.pcm_positive(old_pos),.hp_bck(old_hb),.hp_ws(old_hw),.hp_din(old_hd),.i2s_bck(old_ib),.i2s_ws(old_iw),.i2s_sd(old_id),.active(old_active),.monitor_steps(old_steps),.monitor_envelopes(old_env),.deadline_error(old_err),.clip_active(old_clip),.map_apply(1'b0),.model_reset({12{rst}}),.control_resetn_early(!rst));
 integer edges=0,frames=0,rec_seen=0,replay_seen=0,checks=0,exhaustive=0,xz=0;reg check_deadline=1;
 always @(posedge clk)begin
  #1;edges++;
  if({tick,pcm,pos,hb,hw,hd,ib,iw,id,active,steps,env,err,clip}!=={old_tick,old_pcm,old_pos,old_hb,old_hw,old_hd,old_ib,old_iw,old_id,old_active,old_steps,old_env,old_err,old_clip})$fatal(1,"AUDIO72_PUBLIC tone%0d edge%0d",TONE,edges);
if(dut.ui_depth!==old.ui_depth)$fatal(1,"AUDIO72_PRIVATE ui_depth edge%0d",edges);
if(dut.effective_depth!==old.effective_depth)$fatal(1,"AUDIO72_PRIVATE effective_depth edge%0d",edges);
if(dut.mod_phase!==old.mod_phase)$fatal(1,"AUDIO72_PRIVATE mod_phase edge%0d",edges);
if(dut.mod_depth_product!==old.mod_depth_product)$fatal(1,"AUDIO72_PRIVATE mod_depth_product edge%0d",edges);
if(dut.mod_offset!==old.mod_offset)$fatal(1,"AUDIO72_PRIVATE mod_offset edge%0d",edges);
if(dut.mod_bend_product!==old.mod_bend_product)$fatal(1,"AUDIO72_PRIVATE mod_bend_product edge%0d",edges);
if(dut.modulated_ratio!==old.modulated_ratio)$fatal(1,"AUDIO72_PRIVATE modulated_ratio edge%0d",edges);
if(dut.frame_ratio!==old.frame_ratio)$fatal(1,"AUDIO72_PRIVATE frame_ratio edge%0d",edges);
if(dut.frame_gates!==old.frame_gates)$fatal(1,"AUDIO72_PRIVATE frame_gates edge%0d",edges);
if(dut.frame_triggers!==old.frame_triggers)$fatal(1,"AUDIO72_PRIVATE frame_triggers edge%0d",edges);
if(dut.pending_triggers!==old.pending_triggers)$fatal(1,"AUDIO72_PRIVATE pending_triggers edge%0d",edges);
if(dut.frame_notes!==old.frame_notes)$fatal(1,"AUDIO72_PRIVATE frame_notes edge%0d",edges);
if(dut.frame_gains!==old.frame_gains)$fatal(1,"AUDIO72_PRIVATE frame_gains edge%0d",edges);
if(dut.frame_timbres!==old.frame_timbres)$fatal(1,"AUDIO72_PRIVATE frame_timbres edge%0d",edges);
if(dut.frame_gain_zero!==old.frame_gain_zero)$fatal(1,"AUDIO72_PRIVATE frame_gain_zero edge%0d",edges);
if(dut.event_steps!==old.event_steps)$fatal(1,"AUDIO72_PRIVATE event_steps edge%0d",edges);
if(dut.index!==old.index)$fatal(1,"AUDIO72_PRIVATE index edge%0d",edges);
if(dut.product!==old.product)$fatal(1,"AUDIO72_PRIVATE product edge%0d",edges);
if(dut.render_wait!==old.render_wait)$fatal(1,"AUDIO72_PRIVATE render_wait edge%0d",edges);
if(dut.phys_triggers!==old.phys_triggers)$fatal(1,"AUDIO72_PRIVATE phys_triggers edge%0d",edges);
if(dut.phys_samples!==old.phys_samples)$fatal(1,"AUDIO72_PRIVATE phys_samples edge%0d",edges);
if(dut.phys_envelopes!==old.phys_envelopes)$fatal(1,"AUDIO72_PRIVATE phys_envelopes edge%0d",edges);
if(dut.phys_active!==old.phys_active)$fatal(1,"AUDIO72_PRIVATE phys_active edge%0d",edges);
if(dut.physical.group[0].worker.context_data!==old.physical.group[0].worker.context_data)$fatal(1,"AUDIO72_CTX physical.group[0].worker.context_data edge%0d",edges);
if(dut.physical.group[0].worker.context_state!==old.physical.group[0].worker.context_state)$fatal(1,"AUDIO72_CTX physical.group[0].worker.context_state edge%0d",edges);
if(dut.physical.group[0].worker.context_snapshot!==old.physical.group[0].worker.context_snapshot)$fatal(1,"AUDIO72_CTX physical.group[0].worker.context_snapshot edge%0d",edges);
if(dut.physical.group[0].worker.snapshot_known!==old.physical.group[0].worker.snapshot_known)$fatal(1,"AUDIO72_CTX physical.group[0].worker.snapshot_known edge%0d",edges);
if(dut.physical.group[0].worker.phase!==old.physical.group[0].worker.phase)$fatal(1,"AUDIO72_CTX physical.group[0].worker.phase edge%0d",edges);
if(dut.physical.group[0].worker.context_index!==old.physical.group[0].worker.context_index)$fatal(1,"AUDIO72_CTX physical.group[0].worker.context_index edge%0d",edges);
if(dut.physical.group[0].worker.running!==old.physical.group[0].worker.running)$fatal(1,"AUDIO72_CTX physical.group[0].worker.running edge%0d",edges);
if(dut.physical.group[0].worker.memory_state!==old.physical.group[0].worker.memory_state)$fatal(1,"AUDIO72_CTX physical.group[0].worker.memory_state edge%0d",edges);
if(dut.physical.group[0].worker.string_state!==old.physical.group[0].worker.string_state)$fatal(1,"AUDIO72_CTX physical.group[0].worker.string_state edge%0d",edges);
if(dut.physical.group[0].worker.ep_state!==old.physical.group[0].worker.ep_state)$fatal(1,"AUDIO72_CTX physical.group[0].worker.ep_state edge%0d",edges);
if(dut.physical.group[0].worker.reed_state!==old.physical.group[0].worker.reed_state)$fatal(1,"AUDIO72_CTX physical.group[0].worker.reed_state edge%0d",edges);
if(dut.physical.group[1].worker.context_data!==old.physical.group[1].worker.context_data)$fatal(1,"AUDIO72_CTX physical.group[1].worker.context_data edge%0d",edges);
if(dut.physical.group[1].worker.context_state!==old.physical.group[1].worker.context_state)$fatal(1,"AUDIO72_CTX physical.group[1].worker.context_state edge%0d",edges);
if(dut.physical.group[1].worker.context_snapshot!==old.physical.group[1].worker.context_snapshot)$fatal(1,"AUDIO72_CTX physical.group[1].worker.context_snapshot edge%0d",edges);
if(dut.physical.group[1].worker.snapshot_known!==old.physical.group[1].worker.snapshot_known)$fatal(1,"AUDIO72_CTX physical.group[1].worker.snapshot_known edge%0d",edges);
if(dut.physical.group[1].worker.phase!==old.physical.group[1].worker.phase)$fatal(1,"AUDIO72_CTX physical.group[1].worker.phase edge%0d",edges);
if(dut.physical.group[1].worker.context_index!==old.physical.group[1].worker.context_index)$fatal(1,"AUDIO72_CTX physical.group[1].worker.context_index edge%0d",edges);
if(dut.physical.group[1].worker.running!==old.physical.group[1].worker.running)$fatal(1,"AUDIO72_CTX physical.group[1].worker.running edge%0d",edges);
if(dut.physical.group[1].worker.memory_state!==old.physical.group[1].worker.memory_state)$fatal(1,"AUDIO72_CTX physical.group[1].worker.memory_state edge%0d",edges);
if(dut.physical.group[1].worker.string_state!==old.physical.group[1].worker.string_state)$fatal(1,"AUDIO72_CTX physical.group[1].worker.string_state edge%0d",edges);
if(dut.physical.group[1].worker.ep_state!==old.physical.group[1].worker.ep_state)$fatal(1,"AUDIO72_CTX physical.group[1].worker.ep_state edge%0d",edges);
if(dut.physical.group[1].worker.reed_state!==old.physical.group[1].worker.reed_state)$fatal(1,"AUDIO72_CTX physical.group[1].worker.reed_state edge%0d",edges);
  if(check_deadline&&!rst&&(err||old_err))$fatal(1,"AUDIO72_DEADLINE tone%0d edge%0d",TONE,edges);
  checks++;
 end
 integer f,i,a,b,k,q;reg[6:0]force_ui,force_depth;reg signed[15:0]force_triangle;
 initial begin
  for(i=0;i<7;i++)begin notes[i*7+:7]=48+i*3;gains[i*12+:12]=1600+i*197;timbres[i*3+:3]=TONE;end
  repeat(8)@(negedge clk);rst=0;triggers=7'h7f;
  for(f=0;f<256;f++)begin
   @(negedge clk);while(!tick)@(negedge clk);frames++;
   rec_seen+=recording;replay_seen+=replaying;
   rec=0;rep=0;panic=0;triggers=0;
   mod_depth=(f*37)%128;ratio=(f%3==0)?174763:(f%3==1)?262144:393216;
   config_word=((f%4)<<4)|(f%16);
   if(f==5||f==25)rec=1;
   if(f==31||f==85)rep=1;
   if(f==50)begin gates[3]=0;gains[3*12+:12]=0;end
   if(f==60)begin gates[3]=1;gains[3*12+:12]=2191;triggers[3]=1;end
   if(f==100)panic=1;
   if(f==150)begin rst=1;repeat(8)@(negedge clk);rst=0;triggers=7'h7f;end
   if(rec||rep||panic)begin @(negedge clk);rec=0;rep=0;panic=0;end
  end
  if(rec_seen<10||replay_seen<10)$fatal(1,"AUDIO72_RECORD_COVERAGE rec%0d replay%0d count%0d",rec_seen,replay_seen,count);
  check_deadline=0;
  force dut.ui_depth=force_ui;force old.ui_depth=force_ui;
  force rm=force_depth;force dut.mod_triangle=force_triangle;force old.mod_triangle=force_triangle;
  for(a=0;a<128;a++)for(b=0;b<128;b++)begin
   @(negedge clk);force_ui=a;force_depth=b;force_triangle=(a*597+b*4051)-32768;exhaustive++;
  end
  for(q=0;q<5;q++)for(k=0;k<7;k++)begin
   @(negedge clk);force_ui=7'd96;force_depth=7'd17;force_depth[k]=1'bx;force_triangle=q==0?0:q==1?1:q==2?-1:q==3?32767:-32768;xz++;
   @(negedge clk);force_ui=7'd96;force_depth=7'd17;force_depth[k]=1'bz;xz++;
   @(negedge clk);force_ui=7'd96;force_depth=7'd17;force_ui[k]=1'bx;xz++;
   @(negedge clk);force_ui=7'd96;force_depth=7'd17;force_ui[k]=1'bz;xz++;
  end
  @(negedge clk);rst=1'bx;repeat(5)@(negedge clk);rst=1'bz;repeat(5)@(negedge clk);rst=1;repeat(5)@(negedge clk);
  release dut.ui_depth;release old.ui_depth;release rm;release dut.mod_triangle;release old.mod_triangle;
  repeat(5)@(negedge clk);rst=0;repeat(8)@(negedge clk);
  $display("AUDIO72_STRICT_PASS tone%0d edges%0d frames%0d rec%0d replay%0d exhaustive%0d xz%0d private19 ctx2 PCMserialFX",TONE,edges,frames,rec_seen,replay_seen,exhaustive,xz);$finish;
 end
 initial begin #10000000;$fatal(1,"AUDIO72_TIMEOUT");end
endmodule
module tb_audio72_1;tb_audio72 #(.TONE(1)) test();endmodule
module tb_audio72_2;tb_audio72 #(.TONE(2)) test();endmodule
module tb_audio72_3;tb_audio72 #(.TONE(3)) test();endmodule
