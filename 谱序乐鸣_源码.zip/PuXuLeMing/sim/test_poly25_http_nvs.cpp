#include <cassert>
#include <iostream>
#include "P8_WiFi_Web.ino"
p8::MapBlob deviceMap{},pendingMap{};uint32_t noteMask=0;bool rejectCommit=false;
size_t SerialStub::write(const uint8_t* data,size_t size){
 assert(size==28);writes++;output.assign(data,data+size);if(!online)return size;
 uint8_t reply[28];memcpy(reply,data,28);auto* p=reply+4;const auto op=p[3];uint32_t a=p8::u32(p+8),b=p8::u32(p+12);uint8_t result=0;
 if(op==20){pendingMap={};pendingMap.version=1;pendingMap.base=uint8_t(a);pendingMap.enabled=uint8_t(b);noteMask=0;}
 if(op==21&&a<25){pendingMap.notes[a]=uint8_t(b);noteMask|=1UL<<a;}
 if(op==22){if(rejectCommit||noteMask!=0x1ffffff||a!=p8::mapCRC(pendingMap))result=5;else{deviceMap=pendingMap;deviceMap.crc=uint16_t(a);}}
 p[3]|=128;memset(p+8,0,12);p[8]=result;p8::put16(p+12,deviceMap.crc);
 for(unsigned i=0;i<4;i++)p[16+i]=uint8_t(p8::IDENTITY>>(8*i));
 p8::put16(p+20,p8::crc(p+2,18));p8::put16(reply+26,p8::crc(reply+2,24));for(uint8_t byte:reply)input.push_back(byte);return size;
}
void request(uint8_t op,uint32_t a=0,uint32_t b=0){
 static uint16_t seq=0;uint8_t p[22]={'P','W',1,op};p8::put16(p+4,seq++);p8::put16(p+6,7);
 for(unsigned i=0;i<4;i++){p[8+i]=uint8_t(a>>(8*i));p[12+i]=uint8_t(b>>(8*i));}p8::put16(p+20,p8::crc(p+2,18));
 String text;const char* digits="0123456789abcdef";for(auto byte:p){text+=digits[byte>>4];text+=digits[byte&15];}http.body=text;command();
}
int main(){
 setup();request(0,p8::IDENTITY);assert(owner==7&&http.code==200);assert(Preferences::writes==0);
 request(20,48,1);for(unsigned i=0;i<25;i++)request(21,i,67);auto checksum=p8::mapCRC(pendingMap);
 rejectCommit=true;request(22,checksum,1);assert(http.code==200&&http.socket.sent[8]==5&&Preferences::writes==0);
 rejectCommit=false;Serial0.online=false;request(22,checksum,1);assert(http.code==503&&Preferences::writes==0);
 Serial0.online=true;request(22,checksum,1);assert(http.code==200&&Preferences::writes==1&&Preferences::stored.size()==sizeof(p8::MapBlob));
 request(20,36,1);for(unsigned i=0;i<25;i++)request(21,i,84);checksum=p8::mapCRC(pendingMap);
 Preferences::failWrite=true;request(22,checksum,1);assert(http.code==507&&Preferences::writes==2);
 Preferences::failWrite=false;command();assert(http.code==200&&Preferences::writes==3); // same exact HTTP packet retry
 owner=0;restorePending=true;deviceMap={};restoreSavedMap();assert(!restorePending&&deviceMap.base==36&&deviceMap.notes[24]==84&&Preferences::writes==3);
 // FPGA absent at boot: keep pending for bounded retry; never mark saved/restore done.
 restorePending=true;Serial0.online=false;restoreSavedMap();assert(restorePending&&Preferences::writes==3);
 std::cout<<"POLY25_HTTP_NVS_PASS real handlers+Link, failedACK/timeout no save, ACK save,NVSfailure retry,CRC blob restore and bounded retry\n";
}
