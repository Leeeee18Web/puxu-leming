`timescale 1ns/1ps
module tb_wifi_score_storage;
reg clk=0;always #5 clk=~clk;
reg rst=1,tick=0,clear=0,link_lost=0;reg[7:0]rx=0;reg rv=0;wire rr;wire[7:0]tx;wire tv;
wire[31:0]ed;wire ev;wire playing;wire[9:0]position,count;
reg[63:0]fixture[0:511];reg[7:0]packet[0:21],reply[0:21];integer ri=0,seq=0,sess=37,checks=0,played=0;
reg[15:0]crc,expected_crc;reg[31:0]meta;reg run_play=0;
p8_wifi_control #(.CLOCK_HZ(100000),.WATCHDOG_MS(500)) dut(.map_apply_audio(),.map_apply_fx(),.clk(clk),.rst(rst),.sample_tick(tick),.playable(1'b1),.clear_notes(clear),.live_link_lost(link_lost),.mode(2'd0),.muted(1'b0),
.rx_data(rx),.rx_valid(rv),.rx_ready(rr),.tx_data(tx),.tx_valid(tv),.tx_ready(1'b1),.event_data(ed),.event_valid(ev),.event_ready(1'b1),.score_playing(playing),.score_position(position),.score_count(count));
function automatic[15:0]cb(input[15:0]c,input[7:0]b);reg[15:0]v;integer k;begin v=c^{b,8'd0};for(k=0;k<8;k=k+1)v=v[15]?(v<<1)^16'h1021:v<<1;cb=v;end endfunction
function automatic[15:0]wc(input[15:0]c,input[63:0]w);integer k;reg[15:0]v;begin v=c;for(k=0;k<8;k=k+1)v=cb(v,w[k*8+:8]);wc=v;end endfunction
task check(input bit yes,input string message);begin checks=checks+1;if(!yes)$fatal(1,"FAIL %s seq=%0d result=%0d count=%0d",message,seq,reply[8],count);end endtask
always @(posedge clk)begin
 if(tv)begin reply[ri]=tx;ri=ri+1;end
 if(run_play&&ev&&(ed[7:4]==9||ed[7:4]==8))begin
  check(played<512,"no extra playback event");check(ed[14:8]==fixture[played][38:32],"RAM playback pitch/order");check(ed[7:4]==(fixture[played][48]?9:8),"RAM playback on/off");played=played+1;
 end
end
task command(input integer op,input[31:0]a,b,c,input integer result);integer k,n;reg[15:0]v;begin
 ri=0;packet[0]=80;packet[1]=87;packet[2]=1;packet[3]=op;packet[4]=seq;packet[5]=seq>>8;packet[6]=sess;packet[7]=sess>>8;
 for(k=0;k<4;k=k+1)begin packet[8+k]=a>>(8*k);packet[12+k]=b>>(8*k);packet[16+k]=c>>(8*k);end
 v=16'hffff;for(k=2;k<20;k=k+1)v=cb(v,packet[k]);packet[20]=v;packet[21]=v>>8;
 for(k=0;k<22;k=k+1)begin @(negedge clk);n=0;while(!rr)begin @(negedge clk);n=n+1;if(n>20000)$fatal(1,"FAIL rx timeout");end rx=packet[k];rv=1;@(negedge clk);rv=0;end
 n=0;while(ri<22)begin @(negedge clk);n=n+1;if(n>20000)$fatal(1,"FAIL ACK timeout op=%0d",op);end
 v=16'hffff;for(k=2;k<20;k=k+1)v=cb(v,reply[k]);check(v=={reply[21],reply[20]},"reply CRC");check(reply[3]==(op|128),"reply opcode");check(reply[8]==result,"command result");meta={reply[15],reply[14],reply[13],reply[12]};seq=seq+1;
end endtask
integer i;reg[63:0]w;reg[15:0]small_crc;
initial begin
 $readmemh("fixtures/score512.hex",fixture);repeat(5)@(negedge clk);rst=0;
 command(0,32'h50385731,0,0,0);
 command(4,512,0,0,0);
 expected_crc=16'hffff;
 for(i=0;i<512;i=i+1)begin w=fixture[i];command(5,i,w[31:0],w[63:32],0);expected_crc=wc(expected_crc,w);if(i==256)begin seq=seq-1;command(5,i,w[31:0],w[63:32],0);end end
 command(6,expected_crc,0,0,0);check(count==512,"512 committed count");
 command(12,0,0,0,0);check(meta=={expected_crc,16'd512},"RAM reread CRC/count");
 // Different half-bank contents must survive beyond index255.
 check(dut.score_ram[{dut.active_bank,9'd255}]==fixture[255],"RAM255");check(dut.score_ram[{dut.active_bank,9'd256}]==fixture[256],"RAM256");check(dut.score_ram[{dut.active_bank,9'd511}]==fixture[511],"RAM511");
 command(4,2,0,0,0);command(5,0,0,32'h00015a3c,0);command(6,0,0,0,5);check(count==512,"partial keeps old song");
 command(0,32'h50385731,0,0,0);command(12,0,0,0,0);check(meta=={expected_crc,16'd512},"HELLO preserves committed song");
 // Readback must inspect RAM rather than echo the incoming checksum.
 dut.score_block[{dut.active_bank,9'd256}]=fixture[256][30:0]^31'd1;
 command(12,0,0,0,0);check(meta[31:16]!=expected_crc,"readback detects RAM difference");dut.score_block[{dut.active_bank,9'd256}]=fixture[256][30:0];
 run_play=1;command(7,0,0,0,0);command(2,0,0,0,0);sess=38;command(0,32'h50385731,0,0,0);check(playing,"release/new phone does not stop autonomous song");link_lost=1;repeat(3)@(negedge clk);link_lost=0;check(playing,"USB owner loss preserves autonomous playback");
 // Advance the independent board clock past all fixture timestamps.
 for(i=0;i<fixture[511][31:0]+5000&&playing;i=i+1)begin @(negedge clk);tick=1;end tick=0;
 repeat(30)@(negedge clk);check(!playing&&played==512,"autonomous full512 playback");run_play=0;
 command(4,2,0,0,0);command(5,0,0,32'h00015a3c,0);command(5,1,10,32'h0000003c,0);small_crc=wc(wc(16'hffff,64'h00015a3c00000000),64'h0000003c0000000a);
 command(6,small_crc^1,0,0,5);check(count==512,"wrong CRC preserves active song");command(6,small_crc,0,0,0);check(count==2,"atomic replacement");command(12,0,0,0,0);check(meta=={small_crc,16'd2},"replacement reread");
 command(4,513,0,0,1);rst=1;repeat(4)@(negedge clk);rst=0;check(count==0,"reset clears commitment");
 $display("WIFI_SCORE_STORAGE_PASS checks=%0d played=%0d",checks,played);$finish;
end
initial begin #300000000;$fatal(1,"FAIL overall timeout");end
endmodule
