`timescale 1ns/1ps
module tb_play_touch;
 reg clk=0;always #10 clk=~clk;
 reg rst=1,touch_update=0,touch_valid=1,touch_down=0,event_ready=1;
 reg [15:0] touch_x=0,touch_y=0;
 wire event_valid,page,centre,panic;wire [31:0] event_data;wire [6:0] base_note;
 play_touch_controller dut(.*);
 reg [31:0] got[0:1023];integer n=0,i,oldn,checks=0;
 reg blocked=0;reg[31:0] held;
 always @(posedge clk) if(!rst) begin
  if(blocked && (!event_valid || event_data!==held)) $fatal(1,"held transaction changed");
  blocked<=event_valid&&!event_ready;held<=event_data;
  if(event_valid&&event_ready) begin got[n]=event_data;n=n+1;end
 end
 task touch(input integer xx,yy,input bit down);
 begin @(negedge clk);touch_x=xx;touch_y=yy;touch_down=down;touch_update=1;
 @(negedge clk);touch_update=0;repeat(10) @(negedge clk);end endtask
 task expect_event(input integer idx,status,note);
 begin checks=checks+1;if(got[idx][7:0]!==status || got[idx][15:8]!==note || got[idx][24]!==1'b1)
 $fatal(1,"event %0d expected %h/%d got %h",idx,status,note,got[idx]);end endtask
 initial begin
 repeat(3) @(negedge clk);rst=0;
 touch(32,270,1);expect_event(0,'h90,60);
 touch(76,270,1);expect_event(1,'h80,60);expect_event(2,'h90,61);
 touch(116,270,1);expect_event(3,'h80,61);expect_event(4,'h90,62);
 touch(96,450,1);if(n!=5) $fatal(1,"black bottom must be white D");
 touch(32,570,1);expect_event(5,'h80,62);
 touch(991,569,1);expect_event(6,'h90,84);
 touch(992,569,1);expect_event(7,'h80,84);
 // Backpressure then move and disconnect: stale accepted ON must get OFF.
 event_ready=0;touch(40,500,1);oldn=n;
 touch(200,500,1);touch_valid=0;repeat(8) @(negedge clk);
 if(n!=oldn) $fatal(1,"accepted while blocked");
 event_ready=1;repeat(20) @(negedge clk);
 expect_event(oldn,'h90,60);expect_event(oldn+1,'h80,60);
 touch_valid=1;touch(0,0,0);
 touch(500,40,1);if(base_note!=48) $fatal(1,"oct minus");
 touch(0,0,0);touch(600,40,1);if(base_note!=60) $fatal(1,"oct plus");
 touch(0,0,0);touch(280,40,1);if(page!=1) $fatal(1,"page wave");
 oldn=n;touch(40,500,1);if(n!=oldn) $fatal(1,"wave page played note");
 touch(0,0,0);touch(60,40,1);if(page!=0) $fatal(1,"page keyboard");
 touch(0,0,0);touch(40,500,1);expect_event(n-1,'h90,60);
 // Lift then switch: no global panic/off source event is sent.
 touch(0,0,0);expect_event(n-1,'h80,60);oldn=n;
 touch(280,40,1);if(n!=oldn) $fatal(1,"page must preserve physical MIDI");
 // All 25 keys and boundaries from independently enumerated semitones.
 touch(0,0,0);touch(60,40,1);touch(0,0,0);
 for(i=0;i<15;i=i+1) begin
  touch(32+i*64+32,500,1);
  case(i)0:oldn=60;1:oldn=62;2:oldn=64;3:oldn=65;4:oldn=67;5:oldn=69;6:oldn=71;
   7:oldn=72;8:oldn=74;9:oldn=76;10:oldn=77;11:oldn=79;12:oldn=81;13:oldn=83;14:oldn=84;endcase
  expect_event(n-1,'h90,oldn);touch(0,0,0);expect_event(n-1,'h80,oldn);
 end
 for(i=0;i<10;i=i+1) begin
  case(i)0:begin oldn=61;touch_x=96;end 1:begin oldn=63;touch_x=160;end
   2:begin oldn=66;touch_x=288;end 3:begin oldn=68;touch_x=352;end
   4:begin oldn=70;touch_x=416;end 5:begin oldn=73;touch_x=544;end
   6:begin oldn=75;touch_x=608;end 7:begin oldn=78;touch_x=736;end
   8:begin oldn=80;touch_x=800;end 9:begin oldn=82;touch_x=864;end endcase
  touch(touch_x-20,449,1);expect_event(n-1,'h90,oldn);touch(0,0,0);expect_event(n-1,'h80,oldn);
 end
 $display("PASS touch %0d assertions, %0d ordered events; black-first, drag, stall, unplug, pages",checks,n);$finish;
 end
 initial begin #1000000;$fatal(1,"timeout");end
endmodule
