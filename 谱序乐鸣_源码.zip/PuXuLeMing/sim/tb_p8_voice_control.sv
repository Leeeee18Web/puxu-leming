`timescale 1ns/1ps
// Literal behavioral fixtures: anchor, deltas, pickup, wrap, ownership and reset.
module tb_p8_voice_control;
 reg clk=0;always #10 clk=~clk;
 reg rst=1,sample_tick=0,event_valid=0,panic=0,centre=0;
 reg[31:0]event_data=0;reg[1:0]knob_mode=1;
 wire event_ready;wire[6:0]gates,triggers,knob,last_note,last_velocity,mod_depth,raw_knob;
 wire[48:0]notes;wire[83:0]gains;wire[18:0]ratio;wire raw_known,pickup_wait;
 play_voice_control #(.RELATIVE_KNOB(1)) dut(.*);
 integer checks=0;
 task check(input bit ok,input string msg);begin checks++;if(!ok)$fatal(1,"%s knob=%0d raw=%0d known=%b wait=%b",msg,knob,raw_knob,raw_known,pickup_wait);end endtask
 task send(input bit src,input[7:0]st,a,b);begin @(negedge clk);event_data={7'd0,src,b,a,st};event_valid=1;@(negedge clk);event_valid=0;check(event_ready,"event_ready always asserted/no latency");end endtask
 task reset;begin @(negedge clk);rst=1;knob_mode=1;repeat(3)@(negedge clk);rst=0;end endtask
 task cent;begin @(negedge clk);centre=1;@(negedge clk);centre=0;end endtask
 task mode(input[1:0]m);begin @(negedge clk);knob_mode=m;repeat(2)@(negedge clk);end endtask
 task ticks(input integer n);integer k;begin for(k=0;k<n;k++)begin @(negedge clk);sample_tick=1;@(negedge clk);sample_tick=0;end end endtask
 initial begin
 reset();check(knob==64&&!raw_known&&!pickup_wait,"reset relative neutral");
 send(0,8'hc0,110,0);check(knob==64&&raw_knob==110&&raw_known,"first physical PC only anchors");
 send(0,8'hc0,115,0);check(knob==69,"raw delta adds current bend");
 cent();check(knob==64&&raw_knob==115,"centre retains physical anchor");
 send(0,8'hc0,116,0);check(knob==65,"first post-centre increment is 65");
 send(0,8'hb0,74,110);check(knob==59&&raw_knob==110,"CC74 shares physical anchor");
 cent();send(0,8'hc0,111,0);check(knob==65,"required raw110 to111 aftercentre64");
 send(0,8'hc0,0,0);check(knob==0,"negative delta saturates0");
 send(0,8'hc0,127,0);check(knob==127,"positive delta saturates127");
 send(0,8'hc0,126,0);check(knob==126,"reverse after saturation has no dead band");
 send(0,8'hff,0,0);check(knob==126&&!raw_known,"disconnect leaves bend and clears raw");
 send(0,8'hc0,50,0);check(knob==126&&raw_known,"reconnect first sample anchors");
 send(0,8'hc0,49,0);check(knob==125,"reconnect subsequent delta");
 mode(0);check(knob==125&&pickup_wait,"mode0 waits without value jump");cent();
 send(0,8'hc0,110,0);check(knob==64&&pickup_wait,"pickup high sample does not jump");
 send(0,8'hc0,70,0);check(knob==64&&pickup_wait,"pickup high approaches");
 send(0,8'hc0,60,0);check(knob==60&&!pickup_wait,"pickup crosses centre64 and owns");
 send(0,8'hb0,74,61);check(knob==61,"picked up absolute follows");
 cent();check(knob==64&&pickup_wait,"centre disarms pickup");
 send(0,8'hc0,63,0);check(knob==64&&pickup_wait,"pickup lower approach");
 send(0,8'hc0,65,0);check(knob==65&&!pickup_wait,"upward crossing also acquires");
 send(0,8'he0,0,100);check(knob==100&&pickup_wait,"pitch remains absolute and disarms pickup");
 send(0,8'hc0,99,0);check(knob==100&&pickup_wait,"pitch target pickup not reached");
 send(0,8'hc0,100,0);check(knob==100&&!pickup_wait,"exact pickup target acquires");
 mode(2);check(knob==100&&!pickup_wait,"wrap selection does not jump");
 send(0,8'hc0,127,0);check(knob==100,"wrap mode first sample reanchors");
 send(0,8'hc0,0,0);check(knob==101,"wrap127 to0 is plus1");
 send(0,8'hc0,127,0);check(knob==100,"wrap0 to127 is minus1");
 send(0,8'hc0,63,0);check(knob==36,"wrap exactly64 resolves minus64");
 send(0,8'hc0,0,0);check(knob==0,"wrap negative saturation");
 send(0,8'hc0,63,0);check(knob==63,"wrap max plus63");
 mode(1);send(0,8'hc0,127,0);check(knob==63,"mode2 to1 reanchors");
 send(0,8'hc0,0,0);check(knob==0,"bounded mode127 to0 is minus127");
 mode(3);send(0,8'hc0,10,0);check(knob==10,"invalid mode safely uses boundedrelative");
 send(0,8'hb0,1,127);check(knob==10&&raw_knob==10&&mod_depth==127,"CC1 is MOD only");
 send(0,8'hc0,8'h80,0);check(knob==10&&raw_knob==10,"invalid PC data ignored");
 send(0,8'hb0,74,8'h80);check(knob==10&&raw_knob==10,"invalid CC74 data ignored");
 send(0,8'hf5,127,1);send(0,8'hf6,2,2);send(0,8'hf7,0,3);check(knob==10&&raw_knob==10,"no board-only host command backdoor");
 send(0,8'h90,60,100);check(gates==1&&triggers==1&&gains[11:0]==3200,"USB note immediate original gain");
 send(1,8'h90,60,90);check(gates==3&&triggers==2&&gains[23:12]==2880,"virtual duplicate isolated ownership");
 send(0,8'h80,60,0);check(gates==2,"USB noteoff preserves virtual note");
 send(0,8'hff,0,0);check(gates==2&&!raw_known&&mod_depth==0,"disconnect preserves virtual voice clears MOD");
 send(1,8'h80,60,0);check(gates==0,"virtual noteoff releases virtual");
 send(0,8'he0,0,0);check(knob==0,"pitch min exact");ticks(800);check(ratio==174960,"unchanged smoothing lower endpoint");
 send(0,8'he0,127,127);check(knob==127,"pitch max exact");ticks(800);check(ratio==392772,"unchanged smoothing upper endpoint");
 cent();ticks(800);check(ratio==262144,"unchanged smoothing centre");
 send(0,8'h90,64,127);send(1,8'h90,65,127);send(0,8'hb0,1,127);
 @(negedge clk);panic=1;@(negedge clk);panic=0;check(gates==0&&gains==0&&mod_depth==0,"panic urgent all sources");
 // Explicit CENTRE wins a simultaneous physical update.
 send(0,8'hc0,110,0);@(negedge clk);event_valid=1;event_data=32'h00006fc0;centre=1;
 @(negedge clk);event_valid=0;centre=0;check(knob==64&&raw_knob==111,"centre last priority and raw captured");
 send(0,8'hc0,112,0);check(knob==65,"simultaneous centre retains latest anchor");
 send(1,8'he0,0,32);check(knob==32&&raw_knob==112,"touch slider pitch is absolute preserving physical anchor");
 send(0,8'hc0,113,0);check(knob==33,"physical delta follows absolute touch slider");
 @(negedge clk);knob_mode=2;event_valid=1;event_data=32'h00007fc0;
 @(negedge clk);event_valid=0;check(knob==33&&raw_knob==127,"simultaneous mode change raw reanchors without jump");
 send(0,8'hc0,0,0);check(knob==34,"wrapped delta follows simultaneous mode change anchor");
 $display("PASS tb_p8_voice_control checks=%0d",checks);$finish;
 end
endmodule
