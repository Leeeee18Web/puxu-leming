`timescale 1ns/1ps
module visual_capture_slice_case #(parameter MODE=0, REG_POS=1)(output reg done=0);
 reg clk=0,pclk=0,rst=1,prstn=0,tick=0,frame=0;
 always #10 clk=~clk;
 initial begin #3;forever #7 pclk=~pclk;end
 reg signed[15:0] pcm=0;
 reg positive=0,active=0,restart=0;
 reg[6:0] note=60;reg[10:0] pitch=960;reg[23:0] step=151183;
 reg[15:0] envelope=40000;reg[5:0] settings=6'b101000;
 reg[9:0] wa=0,ta=0;reg[6:0] sa=0;reg[15:0] xa=0;reg[13:0] x=0;
 wire[47:0] nw,rw;wire[7:0] ns,rs,np,rp;wire nv,rv,nx,rx,nxv,rxv;
 wire[10:0] nt,rt;wire[16:0] nc,rc;wire[9:0] nn,rn;wire[5:0] nxs,rxs;
 p8_visuals #(.REGISTERED_PCM_POSITIVE(REG_POS),.HISTORY_SAMPLES(3072),.XY_POINTS(16)) dut(
 .clk(clk),.rst(rst),.sample_tick(tick),.pcm(pcm),.pcm_positive(positive),
 .leading_note(note),.leading_pitch(pitch),.leading_step(step),.leading_envelope(envelope),.leading_valid(active),.restart(restart),.requested_config(settings),
 .pixel_clk(pclk),.pixel_rstn(prstn),.frame_start(frame),.page(3'd1),.x(x),.wave_addr(wa),.spectrum_addr(sa),.tone_addr(ta),.xy_addr(xa),
 .wave_data(nw),.spectrum_data(ns),.spectrum_peak(np),.visual_valid(nv),.tone_data(nt),.tone_curve(nc),.tone_count(nn),.xy_data(nx),.xy_valid(nxv),.xy_settings(nxs));
 p8_visuals_capture_reference #(.REGISTERED_PCM_POSITIVE(REG_POS),.HISTORY_SAMPLES(3072),.XY_POINTS(16)) original(
 .clk(clk),.rst(rst),.sample_tick(tick),.pcm(pcm),.pcm_positive(positive),
 .leading_note(note),.leading_pitch(pitch),.leading_step(step),.leading_envelope(envelope),.leading_valid(active),.restart(restart),.requested_config(settings),
 .pixel_clk(pclk),.pixel_rstn(prstn),.frame_start(frame),.page(3'd1),.x(x),.wave_addr(wa),.spectrum_addr(sa),.tone_addr(ta),.xy_addr(xa),
 .wave_data(rw),.spectrum_data(rs),.spectrum_peak(rp),.visual_valid(rv),.tone_data(rt),.tone_curve(rc),.tone_count(rn),.xy_data(rx),.xy_valid(rxv),.xy_settings(rxs));
 localparam FRAME_PIXELS=614400;
 integer cycle=0,pixel=0,frame_number=0,next_frame=0,raster=0;
 integer raw_checks=0,rgb_checks=0,same_clock_raw_differences=0,turnover_raw_differences=0;
 reg raster_started=0;
 reg[13:0] y=0,gx=0,gy=0;
 reg[76:0] reference_pixels[0:FRAME_PIXELS-1];
 reg[47:0] reference_colors[0:FRAME_PIXELS-1];
 integer raster_q0=0,raster_q1=0,raster_q2=0,frame_q0=0,frame_q1=0,frame_q2=0;
 wire[23:0] nwc,rwc,nsc,rsc;
 p8_p3_graph n_wave(pclk,gx,gy,3'd4,nw,ns,np,nv,nt,nc,nn,nx,nxv,nxs,nwc);
 p8_p3_graph r_wave(pclk,gx,gy,3'd4,rw,rs,rp,rv,rt,rc,rn,rx,rxv,rxs,rwc);
 p8_p3_graph n_spec(pclk,gx,gy,3'd2,nw,ns,np,nv,nt,nc,nn,nx,nxv,nxs,nsc);
 p8_p3_graph r_spec(pclk,gx,gy,3'd2,rw,rs,rp,rv,rt,rc,rn,rx,rxv,rxs,rsc);
 always @(posedge pclk)begin
  gx<=x;gy<=y;raster_q0<=raster;raster_q1<=raster_q0;raster_q2<=raster_q1;
  frame_q0<=frame_number+(frame?1:0);frame_q1<=frame_q0;frame_q2<=frame_q1;
 end
 integer reference_frame=-1,candidate_frame=-1,producer_checks=0,pixel_checks=0,unchanged_checks=0;
 reg boundary_armed=0,producer_active=1,prior_valid=0;
 reg[102:0] prior_original=0;
 wire[102:0] original_state={original.fft.state,original.fft.clear_addr,original.fft.capture_index,original.fft.trigger_previous,original.fft.trigger_previous_positive,original.fft.trigger_count,original.fft.trigger_wait,original.fft.group_base,original.fft.j,original.fft.stage,original.fft.mag_index,original.fft.publish_toggle,original.fft.meta_source};
 wire[102:0] candidate_state={dut.fft.state,dut.fft.clear_addr,dut.fft.capture_index,dut.fft.trigger_previous,dut.fft.trigger_previous_positive,dut.fft.trigger_count,dut.fft.trigger_wait,dut.fft.group_base,dut.fft.j,dut.fft.stage,dut.fft.mag_index,dut.fft.publish_toggle,dut.fft.meta_source};
 always @(negedge clk)begin
  if(!rst)begin
   cycle=cycle+1;tick=(cycle%4)==0;
   // Deliberately changes between sample strobes as well as on them.
   pcm=((cycle*73)^(cycle>>3))-16384;positive=$signed(pcm)>0;
   note=cycle%128;active=(cycle%13)!=0;
   restart=(cycle==21);pitch=960;step=151183;envelope=40000;
  end
 end
 always @(posedge clk)begin
  #1;
  if(rst)begin prior_valid=0;producer_active=1;end
  else begin
   // The expected state comes from the untouched old RTL, one real clock ago.
   if(prior_valid&&producer_active)begin
    if(candidate_state!==prior_original)$fatal(1,"FFT_SOURCE_CYCLE_NOT_DELAYED mode%0d registered%0d cycle%0d",MODE,REG_POS,cycle);
    producer_checks=producer_checks+1;
   end
   prior_original=original_state;prior_valid=1;
   if(original.fft.publish_toggle)producer_active=0;
  end
 end
 always @(negedge pclk)begin
  frame=0;
  if(prstn)begin
   pixel=pixel+1;
   if(MODE==0&&pixel%FRAME_PIXELS==0)begin frame=1;raster=0;raster_started=1;end
   else if(MODE==1&&!boundary_armed&&original.fft.publish_sync[1]!=original.fft.seen&&dut.fft.publish_sync[1]==dut.fft.seen)begin
    frame=1;boundary_armed=1;raster=0;raster_started=1;next_frame=pixel+FRAME_PIXELS;
   end else if(MODE==1&&boundary_armed&&pixel==next_frame)begin frame=1;raster=0;next_frame=next_frame+FRAME_PIXELS;end
   else if(raster_started)raster=raster+1;
   x=raster%1024;y=raster/1024;wa=x;sa=(x>=128&&x<896)?(x-128)/6:0;ta=x;xa={y[7:0]-8'd216,x[7:0]-8'd128};
   if(frame&&(x!=0||y!=0))$fatal(1,"FRAME_START_NOT_REAL_ACTIVE_ORIGIN");
  end
 end
 always @(posedge pclk)begin
  if(frame)frame_number=frame_number+1;
  #1;
  if(prstn&&!done)begin
   if({nt,nc,nn,nx,nxv,nxs}!=={rt,rc,rn,rx,rxv,rxs})$fatal(1,"HISTORY_XY_CHANGED mode%0d registered%0d",MODE,REG_POS);
   unchanged_checks=unchanged_checks+1;
   if(rv&&reference_frame<0)reference_frame=frame_number;
   if(nv&&candidate_frame<0)candidate_frame=frame_number;
   if(rv&&frame_number==reference_frame&&raster<FRAME_PIXELS)
    reference_pixels[raster]={rw,rs,rp,original.fft.meta};
   if(nv&&rv&&{nw,ns,np,dut.fft.meta}!=={rw,rs,rp,original.fft.meta})begin
    same_clock_raw_differences=same_clock_raw_differences+1;
    if(frame)turnover_raw_differences=turnover_raw_differences+1;
   end
   if(nv&&frame_number==candidate_frame&&raster<FRAME_PIXELS)begin
    if(candidate_frame<reference_frame||candidate_frame>reference_frame+1)$fatal(1,"FFT_PUBLICATION_MORE_THAN_ONE_FRAME");
    if({nw,ns,np,dut.fft.meta}!==reference_pixels[raster])$fatal(1,"PAIRED_FRAME_FFT_DATA_DIFFER mode%0d registered%0d raster%0d",MODE,REG_POS,raster);
    raw_checks=raw_checks+1;
   end
   // Compare the real graph consumer's RGB for corresponding first published
   // frames. Boundary cases intentionally differ by one whole display frame.
   if(frame_q2==reference_frame&&reference_frame>0&&raster_q2<FRAME_PIXELS)
    reference_colors[raster_q2]={rwc,rsc};
   if(frame_q2==candidate_frame&&candidate_frame>0&&raster_q2<FRAME_PIXELS)begin
    if(^{nwc,nsc}===1'bx)$fatal(1,"UNKNOWN_VISIBLE_RGB mode%0d raster%0d",MODE,raster_q2);
    if({nwc,nsc}!==reference_colors[raster_q2])$fatal(1,"PAIRED_FRAME_GRAPH_RGB_DIFFER mode%0d registered%0d raster%0d",MODE,REG_POS,raster_q2);
    rgb_checks=rgb_checks+1;
   end
   if(raw_checks>=FRAME_PIXELS&&rgb_checks>=FRAME_PIXELS)begin
    if(MODE==1&&(!boundary_armed||candidate_frame-reference_frame!=1))$fatal(1,"ADJACENT_FRAME_BOUNDARY_NOT_EXERCISED");
    $display("VISUAL_CAPTURE_SLICE_CASE_PASS mode%0d registered%0d producer%0d raw%0d rgb%0d unchanged%0d frame_delta%0d simultaneous_raw_differences%0d turnover_differences%0d",MODE,REG_POS,producer_checks,raw_checks,rgb_checks,unchanged_checks,candidate_frame-reference_frame,same_clock_raw_differences,turnover_raw_differences);done=1;
   end
  end
 end
 initial begin repeat(6)@(negedge clk);rst=0;prstn=1;end
endmodule
module tb_visual_capture_slice;
 wire[3:0] done;
 visual_capture_slice_case #(0,0) c0(done[0]);
 visual_capture_slice_case #(0,1) c1(done[1]);
 visual_capture_slice_case #(1,0) c2(done[2]);
 visual_capture_slice_case #(1,1) c3(done[3]);
 initial begin wait(&done);$display("VISUAL_CAPTURE_SLICE_PASS original reference, 4 cases, exact waveform/spectrum pixels and history/XY, boundary delta reported");$finish;end
 initial begin #50000000;$fatal(1,"VISUAL_CAPTURE_SLICE_TIMEOUT");end
endmodule
