#include <cassert>
#include <deque>
#include <vector>
#include <cstring>
#include <iostream>
#include "p8_link.h"

using Bytes=std::vector<uint8_t>;
Bytes packet(unsigned op,unsigned seq=0,unsigned session=23,uint32_t identity=p8::IDENTITY){
  Bytes p(22);p[0]='P';p[1]='W';p[2]=1;p[3]=op;p8::put16(p.data()+4,seq);p8::put16(p.data()+6,session);
  unsigned offset=op&128?16:8;for(int i=0;i<4;i++)p[offset+i]=identity>>(i*8);
  p8::put16(p.data()+20,p8::crc(p.data()+2,18));return p;
}
Bytes envelope(const Bytes& p){Bytes w={'W','F',1,22};w.insert(w.end(),p.begin(),p.end());uint16_t c=p8::crc(w.data()+2,24);w.push_back(c);w.push_back(c>>8);return w;}
struct Port {
  uint32_t time=0;unsigned writes=0,drop=0,split=1;bool online=true,shortWrite=false;
  std::deque<uint8_t> input,scheduled;std::vector<Bytes> sent;
  Bytes prelude;
  uint32_t now(){return time;}
  int read(){if(input.empty())return -1;int c=input.front();input.pop_front();return c;}
  void pause(){time++;for(unsigned i=0;i<split&&!scheduled.empty();i++){input.push_back(scheduled.front());scheduled.pop_front();}}
  size_t write(const uint8_t* p,size_t n){
    writes++;sent.emplace_back(p,p+n);assert(n==28&&p[0]=='W'&&p[1]=='F'&&p8::crc(p+2,24)==p8::u16(p+26));
    if(shortWrite)return n-1;
    scheduled.insert(scheduled.end(),prelude.begin(),prelude.end());prelude.clear();
    if(!online||writes<=drop)return n;
    Bytes ack(p+4,p+26);ack[3]|=128;memset(ack.data()+8,0,12);
    for(unsigned i=0;i<4;i++)ack[16+i]=p8::IDENTITY>>(8*i);
    p8::put16(ack.data()+20,p8::crc(ack.data()+2,18));
    auto wire=envelope(ack);scheduled.insert(scheduled.end(),wire.begin(),wire.end());return n;
  }
};
int main(){
  auto request=packet(0);uint8_t reply[22];
  for(unsigned split=1;split<=32;split++){
    Port port;port.split=split;p8::Link<Port> link(port);
    assert(link.transact(request.data(),reply)==p8::Result::Ok);assert(p8::valid(reply)&&reply[3]==128);
    assert(link.stats.tx==1&&link.stats.matched==1);
  }
  {Port port;port.input={101,116,115,32,49,50,51,'W','F',1,64,0,'W',0};port.drop=2;
    p8::Link<Port> link(port);assert(link.transact(request.data(),reply)==p8::Result::Ok);
    assert(port.writes==3&&port.sent[0]==port.sent[1]&&port.sent[1]==port.sent[2]);}
  {Port port;port.online=false;p8::Link<Port> link(port);assert(link.transact(request.data(),reply)==p8::Result::Timeout);
    assert(port.time==600&&link.stats.timeouts==1&&link.stats.matched==0);}
  {Port port;port.time=0xfffffff0;port.drop=1;p8::Link<Port> link(port);assert(link.transact(request.data(),reply)==p8::Result::Ok);assert(port.writes==2);}
  {Port port;port.shortWrite=true;p8::Link<Port> link(port);assert(link.transact(request.data(),reply)==p8::Result::WriteFailed);}
  {Port port;p8::Link<Port> link(port);auto bad=request;bad[20]^=1;assert(link.transact(bad.data(),reply)==p8::Result::Invalid&&port.writes==0);}
  {Port port;port.split=4;p8::Link<Port> link(port);
    auto append=[&](Bytes bytes){port.prelude.insert(port.prelude.end(),bytes.begin(),bytes.end());};
    auto bad=envelope(packet(128));bad[27]^=1;append(bad);
    append(envelope(packet(128,0,23,0)));append(envelope(packet(128,0,24)));
    append(envelope(packet(129,0,23)));append(envelope(packet(128,99,23)));
    assert(link.transact(request.data(),reply)==p8::Result::Ok);
    assert(link.stats.badCrc==1&&link.stats.matched==1&&link.stats.ignored==4);}
  {uint8_t release[22];p8::releasePacket(release,65535,23);assert(p8::requestValid(release)&&release[3]==2&&p8::u16(release+4)==65535);}
  std::cout<<"P8_DIRECT_LINK_PASS: 32 fragment sizes, boot noise, CRC, ACK filtering, retries, timeout, time wrap, release\n";
}
