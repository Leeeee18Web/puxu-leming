`timescale 1ns/1ps
// Catches a disconnected, swapped or delayed root reset operand at real models.
module tb_poly_reset_distribution;
 reg clk=0,rst=1;always #10 clk=~clk;
 reg[11:0]resets=12'hfff;
 poly25_audio #(.VOICE_COUNT(7),.DISTRIBUTED_RESET(1)) dut(
  .clk(clk),.rst(rst),.gates(7'd0),.triggers(7'd0),.notes(49'd0),.gains(84'd0),.timbres(21'd0),
  .ratio(19'd262144),.mod_depth(7'd0),.synth_config(32'd0),.map_apply(1'b0),.model_reset(resets),.sample_tick(),.pcm(),.pcm_positive(),.hp_bck(),.hp_ws(),.hp_din(),
  .i2s_bck(),.i2s_ws(),.i2s_sd(),.active(),.monitor_steps(),.monitor_envelopes(),.deadline_error(),.clip_active(),.control_resetn_early(1'b1));
 // Default25 path selects rst once at the audio boundary, even with a distinct port value.
 poly25_audio legacy(.clk(clk),.rst(rst),.gates(25'd0),.triggers(25'd0),.notes(175'd0),.gains(300'd0),.timbres(75'd0),
  .ratio(19'd262144),.mod_depth(7'd0),.synth_config(32'd0),.map_apply(1'b0),.model_reset(resets),.sample_tick(),.pcm(),.pcm_positive(),.hp_bck(),.hp_ws(),.hp_din(),
  .i2s_bck(),.i2s_ws(),.i2s_sd(),.active(),.monitor_steps(),.monitor_envelopes(),.deadline_error(),.clip_active(),.control_resetn_early(1'b1));
 reg[2:0]tone=0;integer checks=0;
 genvar g;generate for(g=0;g<2;g=g+1)begin:check_group
  initial begin
   // Hold the existing parameter preparation phase to isolate the root reset operand.
   force dut.physical.group[g].worker.running=1;force dut.physical.group[g].worker.phase=0;
   // Holding phase0 also holds its legal lookahead windows, instead of replaying phase0 preparation forever.
   force dut.physical.group[g].worker.phase_restore_q=0;force dut.physical.group[g].worker.phase_warm_q=0;
  end
  always @(negedge clk)begin
   if(dut.physical.group[g].worker.ep_enabled.ep.rst !== (resets[g*3] || tone!=0))$fatal(1,"EP_ROOT_RESET_DISCONNECTED group=%0d",g);
   if(dut.physical.group[g].worker.strings.rst !== (resets[g*3+1] || (tone!=1&&tone!=2)))$fatal(1,"STRINGS_ROOT_RESET_DISCONNECTED group=%0d",g);
   if(dut.physical.group[g].worker.reed.rst !== (resets[g*3+2] || tone!=3))$fatal(1,"REED_ROOT_RESET_DISCONNECTED group=%0d",g);
   if(dut.physical.group[g].worker.memory.rst !== resets[6+g])$fatal(1,"MEMORY_ROOT_RESET_DISCONNECTED group=%0d",g);
   if(dut.physical.group[g].worker.rst !== rst)$fatal(1,"SCHEDULER_RESET_CHANGED group=%0d",g);
  end
 end endgenerate
 genvar oldg;generate for(oldg=0;oldg<4;oldg=oldg+1)begin:check_legacy
  always @(negedge clk)if(legacy.physical.group[oldg].worker.ep_enabled.ep.rst !== rst)$fatal(1,"DEFAULT25_RESET_FALLBACK group=%0d",oldg);
 end endgenerate
 integer t,b;
 initial begin
  // Isolate root wiring from normal sampled-frame controls; the real model consumers remain instantiated.
  force dut.frame_timbres={7{tone}};force dut.render_wait=0;force legacy.render_wait=0;
  repeat(3)@(posedge clk);#1;rst=0;
  for(t=0;t<4;t=t+1)begin
   tone=t;@(posedge clk);#1;
   for(b=0;b<14;b=b+1)begin
    resets=b<12 ? (12'b1<<b):b==12 ? 12'd0:12'hfff;
    @(negedge clk);#1;checks=checks+8;@(posedge clk);#1;
   end
  end
  $display("POLY_RESET_DISTRIBUTION_PASS checks=%0d 8 consumed routes/upper4 unused four tones/default25 four-worker fallback",checks);$finish;
 end
endmodule
