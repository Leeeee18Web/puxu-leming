`timescale 1ns/1ps
module tb_p8_pitch;
 reg clk=0;always #10 clk=~clk;
 reg rst=1;reg[6:0]active=0;reg[48:0]notes=0;reg[83:0]gains=0;reg[167:0]steps=0;reg[111:0]env=0;
 wire[6:0]note;wire[10:0]pitch;wire[23:0]step;wire[15:0]envelope;wire valid;
 p8_leading_voice dut(.clk(clk),.rst(rst),.active(active),.notes(notes),.gains(gains),.steps(steps),.envelopes(env),
 .leading_note(note),.leading_pitch(pitch),.leading_step(step),.leading_envelope(envelope),.leading_valid(valid));
 reg[23:0]table_steps[0:2047];integer i,checks=0;
 task ck(input bit good,input string msg);begin checks=checks+1;if(!good)$fatal(1,"%s pitch%0d step%0d",msg,pitch,step);end endtask
 initial begin
  $readmemh("src/play/p8_pitch_steps.hex",table_steps);
  repeat(4)@(negedge clk);rst=0;active=1;gains[11:0]=3200;notes[6:0]=60;env[15:0]=40000;
  for(i=0;i<2048;i=i+1)begin
   steps[23:0]=table_steps[i];repeat(50)@(negedge clk);
   ck(valid&&pitch==i&&step==table_steps[i],"actual step exact quarter-semitone measurement");
  end
  active=7'b1000100;gains=0;gains[35:24]=3000;gains[83:72]=2000;
  notes[20:14]=72;steps[71:48]=table_steps[1152];env[47:32]=35000;
  notes[48:42]=48;steps[167:144]=table_steps[768];env[111:96]=20000;
  repeat(50)@(negedge clk);ck(note==72&&pitch==1152&&envelope==35000,"first active slot selection coherent");
  gains[35:24]=0;repeat(50)@(negedge clk);ck(note==48&&pitch==768,"muted slot skipped");
  active=0;repeat(50)@(negedge clk);ck(!valid,"rest invalidates pitch");
  $display("PASS tb_p8_pitch checks=%0d",checks);$finish;
 end
endmodule
