`timescale 1ns/1ps
module tb_reed_timing_equiv;
 reg clk=0,rst=1,tick=0,trigger=0,gate=0;always #10 clk=~clk;
 reg[23:0]step=16;reg[11:0]gain=2500;
 wire[15:0]s,e,rs,re;wire a,b,d,ra,rb,rd;
 phys_reed_voice #(.PRECALC_STEP(1)) dut(clk,rst,tick,gate,trigger,step,gain,s,e,a,b,d);
 ref_r1_phys_reed_voice refdut(clk,rst,tick,gate,trigger,step,gain,rs,re,ra,rb,rd);
 integer scene,frame,clocks=0,nonzero=0;
 always @(negedge clk)begin #1;
  if(!rst)begin
   clocks++;
   if({s,e,a,b,d}!=={rs,re,ra,rb,rd})$fatal(1,"REED_TIMING_EQ_FAIL scene=%0d frame=%0d",scene,frame);
   if(tick && (dut.step_fast_q!==(step>=32768) || dut.step_medium_q!==(step>=8192)))$fatal(1,"REED_STEP_NOT_SETTLED");
   if(d)$fatal(1,"REED_DEADLINE");if(s!=0)nonzero++;
  end
 end
 task render;begin
  @(negedge clk);tick=1;@(negedge clk);tick=0;trigger=0;
  repeat(1022)@(negedge clk);
 end endtask
 initial begin
  repeat(8)@(negedge clk);rst=0;
  for(scene=0;scene<12;scene++)begin
   case(scene)
    0:step=16;1:step=31;2:step=32;3:step=8191;
    4:step=8192;5:step=8193;6:step=32767;7:step=32768;
    8:step=32769;9:step=90000;10:step=176128;11:step=1000000;
   endcase
   gain=scene[0]?3200:1200;gate=1;trigger=1;
   for(frame=0;frame<512;frame++)begin
    if(frame==256)gate=0;
    if(frame==320)begin gate=1;trigger=1;end
    if(frame==480)gain=0;
    render;
   end
  end
  if(nonzero==0)$fatal(1,"REED_SILENT");
  $display("REED_TIMING_EQ_PASS clocks=%0d scenes=12 thresholds/release/retrigger/mute nonzero=%0d",clocks,nonzero);$finish;
 end
endmodule
