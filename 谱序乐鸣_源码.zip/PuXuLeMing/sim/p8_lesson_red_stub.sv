module p8_lesson(input wire clk,rst,sample_tick,enabled,restart, input wire[6:0]base_note,
 input wire event_valid,input wire[31:0]event_data,input wire panic,
 output wire[6:0]target_note,feedback_note,correct_count,output wire[1:0]feedback,
 output wire[5:0]position,output wire done,output wire[15:0]wrong_count);
 assign target_note=base_note;assign feedback_note=0;assign correct_count=0;
 assign feedback=0;assign position=0;assign done=0;assign wrong_count=0;
endmodule
