`timescale 1ns/1ps
module tb_poly_strings_context #(parameter LENGTH=2112);
 `include "src/poly/poly_model_layout.vh"
 localparam MW=`POLY_MODEL_STRINGS_W,W=MW+56;reg clk=0;always #10 clk=~clk;
 reg rst=1,first_reset=0,en=0,load=0,save=0,tick=0,trig=0,gate=1;reg[2:0]idx=0,tone=1;
 reg[23:0]step=24'd45000;reg[11:0]gain=12'd2400;
 wire[MW-1:0]snapshot;wire[W-1:0]restore;wire known;wire signed[15:0]s;wire[15:0]e;wire active,busy,err;
 wire[12:0]ra,rb,rc,wa,wb,wc;wire[2:0]we;wire[17:0]da,db,dc;wire[19:0]qa;wire[17:0]qb,qc;wire[55:0]ms;
 poly_context_store #(.WIDTH(W),.COUNT(7),.INDEX_WIDTH(3)) bank(clk,rst,save,idx,{snapshot,ms},restore,known);
 poly_delay_pool #(.CONTEXTS(7),.LENGTH(LENGTH)) mem(clk,rst,en,load,idx,restore[55:0],ms,ra,rb,rc,wa,wb,wc,we[0],we[1],we[2],{2'd0,da},db,dc,qa,qb,qc);
 poly_model_strings #(.LENGTH(LENGTH)) dut(.clk(clk),.rst(rst||first_reset),.render_tick(tick),.gate(gate),.trigger(trig),.step(step),.gain(gain),.timbre(tone),.sample(s),.envelope(e),.active(active),.busy(busy),.deadline_error(err),.ctx_enable(en),.ctx_load(load),.ctx_data(restore[W-1:56]),.ctx_state(snapshot),.mem_qa(qa[17:0]),.mem_qb(qb),.mem_qc(qc),.mem_ra(ra),.mem_rb(rb),.mem_rc(rc),.mem_wa(wa),.mem_wb(wb),.mem_wc(wc),.mem_we(we),.mem_da(da),.mem_db(db),.mem_dc(dc));
 wire signed[15:0]gs[0:6];wire[15:0]ge[0:6];wire[6:0]ga,gb,gerr;
 genvar k;generate for(k=0;k<7;k=k+1)begin:refvoice
  wire gc=clk&&(rst||(en&&idx==k));
  phys_string_voice refm(.clk(gc),.rst(rst||first_reset),.render_tick(tick),.gate(gate),.trigger(trig),.step(step),.gain(gain),.timbre(tone),.sample(gs[k]),.envelope(ge[k]),.active(ga[k]),.busy(gb[k]),.deadline_error(gerr[k]));
 end endgenerate
 integer round,c,checks=0,wraps=0;
 always @(posedge clk)if(en&&!load&&dut.a.state==18&&dut.a.wr==LENGTH-1)wraps=wraps+1;
 initial begin repeat(4)@(negedge clk);rst=0;
 for(round=0;round<24000;round=round+1)begin
  @(negedge clk);idx=round%7;load=1;en=0;save=0;step=24'd45000+idx*24'd12000;gain=12'd1000+idx*12'd330;tone=idx[0]?1:2;gate=round<22000;
  #1;first_reset=!known;
  @(negedge clk);load=0;en=1;
  if(first_reset)begin repeat(4)@(negedge clk);first_reset=0;end
  tick=round>=490;trig=round<7;
  for(c=0;c<128+round%7;c=c+1)begin
   if(c>=108&&dut.initializing&&dut.state==10)en=0;
   @(negedge clk);
   tick=0;trig=0;
  end
  if(dut.body_busy||(!dut.initializing&&busy))$fatal(1,"STRINGS_SLOT_OVERRUN state%0d",dut.state);
  // Compare the same completed acoustic transaction, after both pipelines settle.
  if(round>=490)begin
   if(s!==gs[idx]||e!==ge[idx]||active!==ga[idx]||busy!==gb[idx]||err!==gerr[idx])$fatal(1,"STRINGS_CONTEXT_SLOT_EQ visit%0d row%0d s=%0d/%0d",round,idx,s,gs[idx]);
   checks=checks+1;
  end
  en=0;save=1;@(negedge clk);save=0;
 end
 if(wraps<7)$fatal(1,"STRINGS_RING_WRAP_NOT_EXERCISED count%0d",wraps);
 $display("POLY_STRINGS_CONTEXT_PASS checks=%0d wraps=%0d 7 independent R2 grand/guitar completed slots; coupled3strings+6body modes; internal wait+1",checks,wraps);$finish;
 end
 initial begin #100000000;$fatal(1,"STRINGS_CONTEXT_TIMEOUT");end
endmodule
module tb_poly_strings_context2048;tb_poly_strings_context #(.LENGTH(2048)) t();endmodule
