`timescale 1ns/1ps
module tb_wifi_score_packed_boundaries;
reg clk=0;always #5 clk=~clk;
reg rst=1,tick=0,clear=0,link_lost=0;reg[7:0]rx=0;reg rv=0;wire rr;wire[7:0]tx;wire tv;
wire[31:0]ed;wire ev;wire playing;wire[9:0]position,count;
reg[63:0]fixture[0:511];reg[7:0]packet[0:21],reply[0:21];integer ri=0,seq=0,sess=37,checks=0,played=0;
reg[15:0]crc,expected_crc;reg[31:0]meta;reg run_play=0;
p8_wifi_control #(.CLOCK_HZ(100000),.WATCHDOG_MS(500)) dut(.map_apply_audio(),.map_apply_fx(),.clk(clk),.rst(rst),.sample_tick(tick),.playable(1'b1),.clear_notes(clear),.live_link_lost(link_lost),.mode(2'd0),.muted(1'b0),
.rx_data(rx),.rx_valid(rv),.rx_ready(rr),.tx_data(tx),.tx_valid(tv),.tx_ready(1'b1),.event_data(ed),.event_valid(ev),.event_ready(1'b1),.score_playing(playing),.score_position(position),.score_count(count));
function automatic[15:0]cb(input[15:0]c,input[7:0]b);reg[15:0]v;integer k;begin v=c^{b,8'd0};for(k=0;k<8;k=k+1)v=v[15]?(v<<1)^16'h1021:v<<1;cb=v;end endfunction
function automatic[15:0]wc(input[15:0]c,input[63:0]w);integer k;reg[15:0]v;begin v=c;for(k=0;k<8;k=k+1)v=cb(v,w[k*8+:8]);wc=v;end endfunction
task check(input bit yes,input string message);begin checks=checks+1;if(!yes)$fatal(1,"FAIL %s seq=%0d result=%0d count=%0d",message,seq,reply[8],count);end endtask
always @(posedge clk)begin
 if(tv)begin reply[ri]=tx;ri=ri+1;end
 if(run_play&&ev&&(ed[7:4]==9||ed[7:4]==8))begin
  check(played<512,"no extra playback event");check(ed[14:8]==fixture[played][38:32],"RAM playback pitch/order");check(ed[7:4]==(fixture[played][48]?9:8),"RAM playback on/off");played=played+1;
 end
end
task command(input integer op,input[31:0]a,b,c,input integer result);integer k,n;reg[15:0]v;begin
 ri=0;packet[0]=80;packet[1]=87;packet[2]=1;packet[3]=op;packet[4]=seq;packet[5]=seq>>8;packet[6]=sess;packet[7]=sess>>8;
 for(k=0;k<4;k=k+1)begin packet[8+k]=a>>(8*k);packet[12+k]=b>>(8*k);packet[16+k]=c>>(8*k);end
 v=16'hffff;for(k=2;k<20;k=k+1)v=cb(v,packet[k]);packet[20]=v;packet[21]=v>>8;
 for(k=0;k<22;k=k+1)begin @(negedge clk);n=0;while(!rr)begin @(negedge clk);n=n+1;if(n>20000)$fatal(1,"FAIL rx timeout");end rx=packet[k];rv=1;@(negedge clk);rv=0;end
 n=0;while(ri<22)begin @(negedge clk);n=n+1;if(n>20000)$fatal(1,"FAIL ACK timeout op=%0d",op);end
 v=16'hffff;for(k=2;k<20;k=k+1)v=cb(v,reply[k]);check(v=={reply[21],reply[20]},"reply CRC");check(reply[3]==(op|128),"reply opcode");check(reply[8]==result,"command result");meta={reply[15],reply[14],reply[13],reply[12]};seq=seq+1;
end endtask
integer i,j,round;reg[63:0]w;reg[31:0]tm,note_word,badbit;
initial begin
 repeat(5)@(negedge clk);rst=0;command(0,32'h50385731,0,0,0);
 for(round=0;round<4;round++)begin
  command(4,32,0,0,0);expected_crc=16'hffff;
  for(i=0;i<32;i++)begin
   tm=i==31?32'h7fffffff:(32'd1<<i);
   if(i<7)note_word=32'h00017f00|(32'd1<<i);
   else if(i<14)note_word=32'h0001007f|((32'd1<<(i-7))<<8);
   else if(i==14)note_word=32'h00010100;
   else if(i==15)note_word=32'h00007f7f;
   else note_word=((i&1)?32'h00010000:0)|(((i*7)&127)<<8)|((i*13)&127);
   note_word=note_word^((round*29)&127);w={note_word,tm};fixture[i]=w;
   command(5,i,tm,note_word,0);expected_crc=wc(expected_crc,w);
  end
  command(6,expected_crc,0,0,0);command(12,0,0,0,0);
  check(meta=={expected_crc,16'd32},"wire64 CRC after packed reconstruction");
  for(i=0;i<32;i++)check(dut.score_ram[{dut.active_bank,i[8:0]}]==fixture[i],"packed fields preserve original64bit bytes");
 end
 command(4,1,0,0,0);command(5,0,32'h80000000,32'h0001013c,1);
 for(j=0;j<17;j++)begin
  badbit=j==0?(32'd1<<7):j==1?(32'd1<<15):(32'd1<<(j+15));
  command(5,0,32'd0,32'h0001013c|badbit,1);
 end
 command(0,32'h50385731,0,0,0);command(12,0,0,0,0);check(meta=={expected_crc,16'd32},"invalid omitted bits never change committed data");
 $display("PACKED_SCORE_BOUNDARIES_PASS checks=%0d four bank commits, all31 timestamp bits/max, note/velocity basis, padding rejection, exact wire CRC",checks);$finish;
end
initial begin #5000000;$fatal(1,"FAIL packed boundary timeout");end
endmodule
