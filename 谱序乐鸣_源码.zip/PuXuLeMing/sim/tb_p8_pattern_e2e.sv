`timescale 1ns/1ps
// Production composition. Native and lesson phases use only touch.
// Separate physical phase replays production firmware-decoded USB-MIDI words via actual CDC.
module tb_p8_pattern_e2e;
reg clk=0,pixel_clk=0,usb_clk=0;
always #10 clk=~clk;
always #9.756097561 pixel_clk=~pixel_clk;
always #10.416666667 usb_clk=~usb_clk;
reg rst=1,pixel_rstn=0,frame_start=0,frames_on=1;
wire [1:0]usb_up_sync=2'b11;
wire usb_event_valid;wire[31:0]usb_event_data;wire usb_event_ready;
reg[31:0]midi_source_data=0;reg midi_source_request=0;wire midi_source_ack;
play_event_cdc midi_mailbox(.source_clk(usb_clk),.source_rst(rst),.source_data(midi_source_data),.source_request(midi_source_request),.source_ack(midi_source_ack),.clk(clk),.rst(rst),.valid(usb_event_valid),.data(usb_event_data),.ready(usb_event_ready));
reg[31:0] midi_trace[0:85];
wire panic_key=0;reg centre_key=0;
reg [13:0]x=0,y=0;wire den=1,hs=1,vs=1;
wire [1:0]video_up_sync=2'b11;
reg [31:0] touch_status_source=0,touch_xy_source=0,touch_raw_source=0,touch_vidpid_source=0,touch_meta_source=0;
reg touch_toggle=0;
reg[31:0] trace_words[0:191];
reg[31:0]shadow_status=0,shadow_xy=0,shadow_raw=0,shadow_vidpid=0,shadow_meta=0;
integer pc=0;
always @(negedge pixel_clk)begin pc=pc+1;frame_start=frames_on&&pc%1000==0;end
 wire[31:0]touch_status,touch_xy;wire touch_report;
 usb_touch_bridge touch_bridge(.pixel_clk(clk),.rstn(!rst),.source_toggle(touch_toggle),.source_status(touch_status_source),
  .source_xy(touch_xy_source),.source_raw(touch_raw_source),.source_vidpid(touch_vidpid_source),.source_meta(touch_meta_source),
  .status_q(touch_status),.xy_q(touch_xy),.raw_q(),.vidpid_q(),.meta_q(),.report_valid(touch_report));
 wire touch_good=touch_status[14]&&touch_status[12]&&usb_up_sync[1];reg previous_touch_good=0;
 always @(posedge clk)if(rst)previous_touch_good<=0;else previous_touch_good<=touch_good;
 wire touch_update=touch_report||(previous_touch_good&&!touch_good);
 wire [1:0] touch_state={touch_status[12]&&usb_up_sync[1],touch_good&&touch_status[24]};

 wire [2:0]page;wire [1:0]mode,knob_mode,spectrum_zoom;wire [5:0]xy_config;
 wire centre_touch,panic_touch,clear_live,start_score,stop_score,touch_event_valid,touch_event_ready,muted,restart_lesson;
 wire [6:0]base_note;wire[31:0]touch_event_data;
 wire[1:0]pattern_mode;wire pattern_start;

 p8_navigation touch_controls(.clk(clk),.rst(rst),.touch_update(touch_update),.touch_valid(touch_good),
  .touch_down(touch_status[24]&&touch_status[12]),.touch_x(touch_xy[15:0]),.touch_y(touch_xy[31:16]),
  .event_ready(touch_event_ready),.event_valid(touch_event_valid),.event_data(touch_event_data),.panic_key(panic_key),.centre_key(centre_key),
  .page(page),.mode(mode),.knob_mode(knob_mode),.base_note(base_note),.centre(centre_touch),.panic(panic_touch),
  .clear_live(clear_live),.start_score(start_score),.stop_score(stop_score),.muted(muted),.restart_lesson(restart_lesson),.xy_config(xy_config),.spectrum_zoom(spectrum_zoom),.pattern_mode(pattern_mode),.pattern_start(pattern_start));
 wire[6:0]live_gates,live_triggers,knob,last_note,last_velocity,mod_depth,raw_knob;
 wire raw_known,pickup_wait;wire[48:0]live_notes;wire[83:0]live_gains;wire[18:0]ratio;
 wire sample_tick;wire signed[15:0]pcm;
 wire selected_valid=touch_event_valid||usb_event_valid;wire selected_ready,controller_ready;
 wire[31:0]selected_data=touch_event_valid?touch_event_data:usb_event_data;
 assign touch_event_ready=selected_ready;assign usb_event_ready=selected_ready&&!touch_event_valid;
 wire panic_all=panic_touch||panic_key||!usb_up_sync[1];
 assign selected_ready=controller_ready&&!clear_live&&!panic_all;
 wire pattern_select=mode==1&&pattern_mode!=0;
 wire selected_note_event=selected_data[7:4]==8||selected_data[7:4]==9;
 play_voice_control #(.RELATIVE_KNOB(1)) voices(.clk(clk),.rst(rst),.sample_tick(sample_tick),.event_valid(selected_valid&&selected_ready&&!(pattern_select&&selected_note_event)),.event_data(selected_data),.event_ready(controller_ready),
  .panic(panic_all||clear_live),.centre(centre_touch||centre_key),.gates(live_gates),.notes(live_notes),.gains(live_gains),.triggers(live_triggers),
  .ratio(ratio),.knob(knob),.last_note(last_note),.last_velocity(last_velocity),.mod_depth(mod_depth),
  .knob_mode(knob_mode),.raw_knob(raw_knob),.raw_known(raw_known),.pickup_wait(pickup_wait));
 reg touch_connected_q=0,muted_q=0;
 always @(posedge clk)if(rst)begin touch_connected_q<=0;muted_q<=0;end
 else begin touch_connected_q<=touch_state[1];muted_q<=muted;end
 wire touch_lost=touch_connected_q&&!touch_state[1];
 wire mute_enter=muted&&!muted_q;
 wire pattern_all_off=selected_valid&&selected_ready&&selected_data[7:4]==11&&
  !selected_data[15]&&!selected_data[23]&&(selected_data[14:8]==120||selected_data[14:8]==123);
 wire[6:0]pattern_selected,pattern_gates,pattern_triggers;
 wire[48:0]pattern_notes,pattern_sound_notes;wire[83:0]pattern_selected_gains,pattern_gains;
 wire pattern_busy,pattern_full;wire[2:0]pattern_count;
 p8_patterns #(.STRUM_SAMPLES(32),.ARP_SAMPLES(256),.HOLD_SAMPLES(600)) patterns(.clk(clk),.rst(rst),.sample_tick(sample_tick),
  .cancel(panic_all||clear_live||stop_score||mute_enter||pattern_all_off||mode!=1||touch_lost),
  .pattern_mode(pattern_mode),.start(pattern_start),
  .event_valid(selected_valid&&selected_ready&&pattern_select),.event_data(selected_data),
  .selected(pattern_selected),.selected_notes(pattern_notes),.selected_gains(pattern_selected_gains),
  .gates(pattern_gates),.triggers(pattern_triggers),.notes(pattern_sound_notes),.gains(pattern_gains),
  .busy(pattern_busy),.count(pattern_count),.full(pattern_full));
 wire[6:0]perform_gates=pattern_select?pattern_gates:live_gates;
 wire[6:0]perform_triggers=pattern_select?pattern_triggers:live_triggers;
 wire[48:0]perform_notes=pattern_select?pattern_sound_notes:live_notes;
 wire[83:0]perform_gains=pattern_select?pattern_gains:live_gains;
 wire[6:0]gates,triggers,active;wire[48:0]notes;wire[83:0]gains;wire playing,score_done;wire[6:0]next_note;
 p8_audio_source sources(.clk(clk),.rst(rst),.sample_tick(sample_tick),.mode(mode),.start_score(start_score),.stop_score(stop_score),.panic(panic_all),.transition_mute(clear_live),.muted(muted),
  .live_gates(perform_gates),.live_triggers(perform_triggers),.live_notes(perform_notes),.live_gains(perform_gains),
  .gates(gates),.triggers(triggers),.notes(notes),.gains(gains),.playing(playing),.done(score_done),.next_note(next_note));
 wire[167:0]monitor_steps;wire[111:0]monitor_envelopes;
 play_audio audio(.clk(clk),.rst(rst),.gates(gates),.notes(notes),.gains(gains),.triggers(triggers),.ratio(ratio),.mod_depth(mod_depth),
  .sample_tick(sample_tick),.pcm(pcm),.hp_bck(hp_bck),.hp_ws(hp_ws),.hp_din(hp_din),
  .i2s_bck(i2s_bck),.i2s_ws(i2s_ws),.i2s_sd(i2s_sd),.active(active),.monitor_steps(monitor_steps),.monitor_envelopes(monitor_envelopes));
 wire[6:0]lesson_target,lesson_feedback_note,lesson_correct;wire[1:0]lesson_feedback;wire[5:0]lesson_position;wire lesson_done;wire[15:0]lesson_wrong;
 p8_lesson lesson(.clk(clk),.rst(rst),.sample_tick(sample_tick),.enabled(mode==3),.restart(restart_lesson),.base_note(base_note),
  .event_valid(selected_valid&&selected_ready),.event_data(selected_data),.panic(panic_all),
  .target_note(lesson_target),.feedback_note(lesson_feedback_note),.feedback(lesson_feedback),.position(lesson_position),.done(lesson_done),.correct_count(lesson_correct),.wrong_count(lesson_wrong));
 wire[6:0]ui_next_note=mode==3?lesson_target:mode==2?next_note:7'd127;
 wire[6:0]leading_note;wire[10:0]leading_pitch;wire[23:0]leading_step;wire[15:0]leading_envelope;wire leading_valid;
 wire[290:0]view;
 instrument_snapshot #(.WIDTH(291),.PERIOD(500)) ui_snapshot(.clk(clk),.rstn(!rst),
  .source_data({page,mode,playing,base_note,gates,notes,gains,knob,raw_knob,raw_known,pickup_wait,knob_mode,leading_note,last_velocity,mod_depth,spectrum_zoom,muted,leading_valid,ui_next_note,lesson_target,lesson_feedback_note,lesson_feedback,lesson_position,lesson_done,touch_state,pattern_mode,pattern_selected,pattern_notes,pattern_busy,pattern_count,pattern_full}),
  .pixel_clk(pixel_clk),.pixel_rstn(pixel_rstn),.frame_start(frame_start),.data(view));
 wire[2:0]vpage;wire[1:0]vmode,vknob_mode,vzoom;wire vplaying,vraw_known,vpickup,vmuted,vnote_valid,vlesson_done;
 wire[6:0]vnext,vlesson_target,vlesson_note;wire[1:0]vlesson_feedback;wire[5:0]vlesson_position;
 wire[1:0]vtouch_state,vpattern_mode;wire[6:0]vpattern_selected;wire[48:0]vpattern_notes;wire vpattern_busy,vpattern_full;wire[2:0]vpattern_count;
 wire[6:0]vbase,vgates,vknob,vraw,vnote,vvelocity,vmod;wire[48:0]vnotes;wire[83:0]vgains;
 assign {vpage,vmode,vplaying,vbase,vgates,vnotes,vgains,vknob,vraw,vraw_known,vpickup,vknob_mode,vnote,vvelocity,vmod,vzoom,vmuted,vnote_valid,vnext,vlesson_target,vlesson_note,vlesson_feedback,vlesson_position,vlesson_done,vtouch_state,vpattern_mode,vpattern_selected,vpattern_notes,vpattern_busy,vpattern_count,vpattern_full}=view;

 p8_leading_voice leading(.clk(clk),.rst(rst),.active(active),.notes(notes),.gains(gains),.steps(monitor_steps),.envelopes(monitor_envelopes),
  .leading_note(leading_note),.leading_pitch(leading_pitch),.leading_step(leading_step),.leading_envelope(leading_envelope),.leading_valid(leading_valid));
 wire[9:0]wave_addr,tone_addr;wire[6:0]spectrum_addr;wire[15:0]xy_addr;
 wire[47:0]wave_data;wire[7:0]spectrum_data,spectrum_peak;wire visual_valid,xy_data,xy_valid;
 wire[10:0]tone_data;wire[16:0]tone_curve;wire[9:0]tone_count;wire[5:0]xy_settings;
 p8_visuals visual(.clk(clk),.rst(rst||!video_up_sync[1]),.sample_tick(sample_tick),.pcm(pcm),
  .leading_note(leading_note),.leading_pitch(leading_pitch),.leading_step(leading_step),.leading_envelope(leading_envelope),.leading_valid(leading_valid),
  .restart(clear_live||start_score),.requested_config(xy_config),.pixel_clk(pixel_clk),.pixel_rstn(pixel_rstn),.frame_start(frame_start),
  .page(vpage),.x(x),.wave_addr(wave_addr),.spectrum_addr(spectrum_addr),.tone_addr(tone_addr),.xy_addr(xy_addr),
  .wave_data(wave_data),.spectrum_data(spectrum_data),.spectrum_peak(spectrum_peak),.visual_valid(visual_valid),
  .tone_data(tone_data),.tone_curve(tone_curve),.tone_count(tone_count),.xy_data(xy_data),.xy_valid(xy_valid),.xy_settings(xy_settings));
 wire[23:0]rgb;wire de,ohs,ovs;
 p8_panel panel(.pixel_clk(pixel_clk),.rstn(pixel_rstn),.den(den),.hsync(hs),.vsync(vs),.x(x),.y(y),
  .pattern_mode(vpattern_mode),.pattern_selected(vpattern_selected),.pattern_notes(vpattern_notes),.pattern_busy(vpattern_busy),.pattern_count(vpattern_count),.pattern_full(vpattern_full),
  .touch_state(vtouch_state),.page(vpage),.mode(vmode),.playing(vplaying),.muted(vmuted),.note_valid(vnote_valid),.next_note(vnext),
  .lesson_target(vlesson_target),.lesson_feedback_note(vlesson_note),.lesson_feedback(vlesson_feedback),.lesson_position(vlesson_position),.lesson_done(vlesson_done),.base_note(vbase),.gates(vgates),.notes(vnotes),.gains(vgains),
  .knob(vknob),.raw_knob(vraw),.raw_known(vraw_known),.pickup_wait(vpickup),.knob_mode(vknob_mode),.last_note(vnote),.last_velocity(vvelocity),.mod_depth(vmod),.spectrum_zoom(vzoom),
  .wave_data(wave_data),.spectrum_data(spectrum_data),.spectrum_peak(spectrum_peak),.visual_valid(visual_valid),
  .tone_data(tone_data),.tone_curve(tone_curve),.tone_count(tone_count),.xy_data(xy_data),.xy_valid(xy_valid),.xy_settings(xy_settings),
  .rgb(rgb),.den_out(de),.hsync_out(ohs),.vsync_out(ovs),.wave_addr(wave_addr),.spectrum_addr(spectrum_addr),.tone_addr(tone_addr),.xy_addr(xy_addr));

integer checks=0,accepted=0,commits=0,samples=0,nonzero=0,pubcount=0,i,physical_fixture_events=0,physical_note_events=0,events_before=0,mailbox_sent=0,handoff_cycles=0;
reg physical_fixture_phase=0;
reg[15:0] expected[0:2047];reg old_bank=0;
always @(posedge clk)if(!rst)begin
 if(clear_live||panic_all)begin check(!selected_ready,"source mode handoff revokes shared READY before voice/lesson accept");handoff_cycles=handoff_cycles+1;end
 if(selected_valid&&selected_ready)begin
  if(!selected_data[24])begin
   if(!physical_fixture_phase)$fatal(1,"physical MIDI forbidden in touch-only phase");physical_fixture_events=physical_fixture_events+1;
   if(selected_data[7:4]==8||selected_data[7:4]==9)physical_note_events=physical_note_events+1;
  end else accepted=accepted+1;
 end
 if(sample_tick)begin samples=samples+1;if(pcm!=0)nonzero=nonzero+1;end
 if(visual.fft.state==1&&sample_tick)expected[{visual.fft.bank,visual.fft.capture_index}]=pcm;
end
always @(posedge pixel_clk)begin #1;
 if(pixel_rstn&&visual.fft.display_bank!=old_bank)begin
  if(!frame_start)$fatal(1,"FFT bank changed inside frame");pubcount=pubcount+1;
 end
 old_bank=visual.fft.display_bank;
end
task check(input bit ok,input string msg);begin checks=checks+1;if(!ok)$fatal(1,"%s",msg);end endtask
task report(input integer index);
integer w;reg[31:0]address,value;begin
 for(w=0;w<6;w=w+1)begin
 @(negedge usb_clk);address=trace_words[index*12+w*2];value=trace_words[index*12+w*2+1];
 case(address)
 32'h02000200:shadow_status=value;32'h02000204:shadow_xy=value;
 32'h02000208:shadow_raw=value;32'h0200020c:shadow_vidpid=value;32'h02000210:shadow_meta=value;
 32'h02000214:begin touch_status_source=shadow_status;touch_xy_source=shadow_xy;touch_raw_source=shadow_raw;touch_vidpid_source=shadow_vidpid;touch_meta_source=shadow_meta;touch_toggle=~touch_toggle;commits=commits+1;end
 default:$fatal(1,"non-touch MMIO address");endcase end
 repeat(30)@(negedge clk);
end endtask
// Separate synthetic touch fixture used ONLY for additional lesson and disconnect coverage.
// Native HID->MMIO trace coverage remains exactly the first16 reports /96 pairs.
task fixture(input integer xx,yy,input bit down,valid);begin
 @(negedge usb_clk);touch_xy_source={yy[15:0],xx[15:0]};
 touch_status_source=shadow_status;touch_status_source[24]=down;touch_status_source[14]=valid;touch_status_source[12]=valid;
 touch_toggle=~touch_toggle;repeat(30)@(negedge clk);
end endtask
task tap(input integer xx,yy);begin fixture(xx,yy,1,1);fixture(xx,yy,0,1);end endtask
task syncview;begin repeat(3000)@(negedge pixel_clk);end endtask
task pixel(input integer xx,yy,input[23:0]want);begin
 @(negedge pixel_clk);x=xx;y=yy;repeat(12)@(negedge pixel_clk);
 if(rgb!==want)$display("pixel%0d,%0d got%h want%h",xx,yy,rgb,want);
 check(rgb===want,"production font/panel RGB");end endtask
task measure(output real period);
integer k,n,first,last;reg signed[15:0]prev;begin n=0;prev=0;first=0;last=0;
 for(k=0;k<2400;k=k+1)begin
 @(negedge clk);while(!sample_tick)@(negedge clk);
 if(k>800&&pcm>0&&prev<=0)begin if(!n)first=k;last=k;n=n+1;end
 prev=pcm;
 end
 check(n>=6,"actual final PCM periodic crossings");period=1.0*(last-first)/(n-1);
end endtask
integer a,maxbin,maxvalue;reg bankheld;real c4,c5;
task verify_graph(output integer fftbin);
integer q,pub;begin
 pub=pubcount;wait(pubcount>pub);frames_on=0;repeat(5)@(negedge pixel_clk);bankheld=visual.fft.display_bank;
 for(q=0;q<1024;q=q+1)begin
 @(negedge pixel_clk);x=q;y=300;repeat(2)@(negedge pixel_clk);
 check(wave_data[47:16]===0&&wave_data[15:0]===expected[{bankheld,q[9:0]}],"wave equals1024 consecutive actual mixed PCM samples");
 end
 // Address via production panel on spectrum page, zoom2 gives every bin.
 // Read producer data through direct read address force only during this DSP probe.
 maxvalue=0;maxbin=0;
 for(q=0;q<128;q=q+1)begin
 force spectrum_addr=q;repeat(2)@(negedge pixel_clk);
 if(spectrum_data>maxvalue)begin maxvalue=spectrum_data;maxbin=q;end
 end
 release spectrum_addr;fftbin=maxbin;check(maxvalue>0,"FFT nonzero actual PCM response");frames_on=1;
end endtask
task physical_word(input[31:0]word);begin
 @(negedge usb_clk);midi_source_data=word;midi_source_request=~midi_source_request;mailbox_sent=mailbox_sent+1;
 wait(midi_source_ack==midi_source_request);repeat(5)@(negedge clk);
end endtask
task physical_pc(input[6:0]raw);begin physical_word({16'd0,1'b0,raw,8'hc0});end endtask
integer song_i,physical_nonzero;

integer pcm_nz=0,hp_nz=0,i2s_nz=0,onsets=0,onset_frames[0:63],onset_notes[0:63];
reg[15:0]hp_shift=0;integer hp_bits=0;integer v,previous_onsets;
always @(posedge hp_bck)if(!rst)begin
 hp_shift={hp_shift[14:0],hp_din};
 if(hp_bits==15)begin if(hp_shift!=0)hp_nz=hp_nz+1;hp_bits=0;end else hp_bits=hp_bits+1;
end
wire[15:0]decoded_l,decoded_r;wire decoded_valid;
i2s_rx16 decode(.clk(clk),.rst(rst),.bck(i2s_bck),.ws(i2s_ws),.sd(i2s_sd),.pcm_l(decoded_l),.pcm_r(decoded_r),.frame_valid(decoded_valid));
always @(negedge clk)if(!rst)begin
 if(sample_tick&&pcm!=0)pcm_nz=pcm_nz+1;
 if(decoded_valid)begin
  check(decoded_l===decoded_r,"serial I2S stereo words agree");
  if(decoded_l!=0)i2s_nz=i2s_nz+1;
 end
 for(v=0;v<7;v=v+1)if(pattern_triggers[v])begin
  onset_notes[onsets]=pattern_sound_notes[v*7+:7];onset_frames[onsets]=samples;onsets=onsets+1;
 end
end
task frames(input integer n);integer f;begin
 for(f=0;f<n;f=f+1)begin @(negedge clk);while(!sample_tick)@(negedge clk);end
end endtask
task silence;begin frames(8);check(pcm==0&&gates==0&&gains==0,"stopped pattern is silent at actual mixer");end endtask
task audible;begin
 pcm_nz=0;hp_nz=0;i2s_nz=0;frames(100);
 check(pcm_nz>50&&hp_nz>50&&i2s_nz>50,"current pattern reaches PCM/PT8211/I2S wires");
end endtask
integer pattern_index;reg[6:0]expected_note[0:6];reg[6:0]held_selection;
initial begin
 physical_fixture_phase=1;shadow_status=32'h00007f05;
 repeat(8)@(negedge clk);rst=0;pixel_rstn=1;
 fixture(0,0,0,1);tap(300,280);tap(656,96);
 check(mode==1&&page==5,"actual touch bridge opens performance keyboard");
 tap(620,200);check(pattern_mode==2,"actual chord button enters selection");
 tap(320,550);tap(96,320);tap(64,550);
 check(pattern_count==3&&live_gates==0&&gates==0,"unsorted black/white selections are silent");
 frames(20);check(pcm==0,"selection produces no synthesized sample before trigger");
 syncview();check(vpattern_count==3&&vpattern_mode==2,"selection crosses coherent291-bit frame snapshot");
 pixel(96,320,24'hf5c767);pixel(40,550,24'hf5c767);
 tap(928,200);frames(6);check(pattern_busy&&gates==pattern_selected,"trigger starts all chord notes");
 syncview();check(vpattern_busy&&vgates==vpattern_selected,"actual chord state reaches panel snapshot");
 pixel(96,320,24'hf5c767);pixel(40,550,24'hf5c767);audible();
 // Retrigger same retained selection and verify a new distinct three-note onset.
 previous_onsets=onsets;tap(928,200);frames(6);
 check(onsets==previous_onsets+3&&gates==pattern_selected,"same chord can be retriggered without reselecting");
 audible();tap(600,32);silence();check(pattern_count==3,"stop retains chosen notes");
 // Four real canonical MIDI events join the same selection; note-offs do not remove them.
 physical_word(32'h00644690);physical_word(32'h00004680);
 physical_word(32'h00644890);physical_word(32'h00004880);
 physical_word(32'h00644c90);physical_word(32'h00004c80);
 physical_word(32'h00644f90);physical_word(32'h00004f80);
 check(pattern_count==7&&live_gates==0,"USB MIDI and touchscreen share the seven-note selection");
 held_selection=pattern_selected;physical_word(32'h00645090);
 check(pattern_count==7&&pattern_full&&pattern_selected==held_selection,"eighth note is visibly refused without replacing chosen notes");
 tap(450,200);check(pattern_mode==1,"strum selection preserves seven pitches");
 expected_note[0]=60;expected_note[1]=61;expected_note[2]=67;expected_note[3]=70;
 expected_note[4]=72;expected_note[5]=76;expected_note[6]=79;
 previous_onsets=onsets;tap(928,200);frames(240);
 check(onsets==previous_onsets+7&&gates==pattern_selected,"strum sounds every selected pitch");
 for(pattern_index=0;pattern_index<7;pattern_index=pattern_index+1)begin
  check(onset_notes[previous_onsets+pattern_index]==expected_note[pattern_index],"strum sorts actual pitches low to high");
  if(pattern_index>0)check(onset_frames[previous_onsets+pattern_index]-onset_frames[previous_onsets+pattern_index-1]==32,"strum exact parameterized onset spacing");
 end
 audible();tap(600,32);silence();
 tap(760,200);check(pattern_mode==3,"arp mode selected");
 previous_onsets=onsets;tap(928,200);
 for(pattern_index=0;pattern_index<7;pattern_index=pattern_index+1)begin
  wait(onsets==previous_onsets+pattern_index+1);frames(8);
  check($countones(gates)==1,"arp has exactly one sounding note");audible();
 end
 frames(300);check(!pattern_busy&&gates==0,"arp ends after one complete pass");
 for(pattern_index=0;pattern_index<7;pattern_index=pattern_index+1)begin
  check(onset_notes[previous_onsets+pattern_index]==expected_note[pattern_index],"arp actual note order");
  if(pattern_index>0)check(onset_frames[previous_onsets+pattern_index]-onset_frames[previous_onsets+pattern_index-1]==256,"arp exact parameterized onset spacing");
 end
 silence();syncview();pixel(96,320,24'hf5c767);
 tap(480,32);check(muted,"manual mute before editing selection");
 tap(64,550);check(pattern_count==6&&muted&&gates==0,"muted selection editing must deselect silently");
 tap(64,550);check(pattern_count==7&&muted&&gates==0,"muted selection editing must reselect silently");
 tap(928,200);frames(6);physical_word(32'h000078b0);
 check(!pattern_busy&&gates==0&&pattern_count==7,"MIDI All Sound Off cancels pattern without losing selection");silence();
 tap(928,200);frames(6);physical_word(32'h00007bb0);
 check(!pattern_busy&&gates==0&&pattern_count==7,"MIDI All Notes Off cancels pattern without losing selection");silence();
 tap(928,200);frames(6);tap(480,32);repeat(5)@(negedge clk);check(muted&&!pattern_busy&&gates==0,"mute stops active pattern");
 tap(928,200);frames(6);check(!muted&&pattern_busy,"trigger explicitly restores sound after mute");audible();
 fixture(0,0,0,0);repeat(12)@(negedge clk);check(!pattern_busy&&gates==0,"touchscreen disconnect cancels active run");
 fixture(0,0,0,1);tap(760,200);check(pattern_mode==0,"same mode button restores normal piano");
 fixture(64,550,1,1);frames(8);check(live_gates!=0,"ordinary virtual piano still owns live notes");audible();fixture(64,550,0,1);
 tap(40,32);tap(660,280);check(mode==3&&pattern_mode==0&&lesson_position==0,"follow mode remains separate and available");
 fixture(64,550,1,1);frames(8);check(lesson_feedback==1&&lesson_position==1&&live_gates!=0,"follow grades and sounds original virtual key");audible();fixture(64,550,0,1);
 $display("P8_PATTERN_E2E_PASS checks=%0d onsets=%0d samples=%0d PCM=%0d PT=%0d I2S=%0d framebits=291",checks,onsets,samples,pcm_nz,hp_nz,i2s_nz);$finish;
end
initial begin #180000000;$fatal(1,"pattern E2E deadline");end
endmodule
