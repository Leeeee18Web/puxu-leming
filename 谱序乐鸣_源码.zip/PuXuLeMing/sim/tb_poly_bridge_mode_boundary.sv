`timescale 1ns/1ps
module tb_poly_bridge_mode_boundary;
 `include "src/poly/poly_model_layout.vh"
 reg clk=0;always #10 clk=~clk;reg mode=1,trig=0;
 poly_model_strings dut(.clk(clk),.rst(1'b0),.render_tick(1'b0),.trigger(trig),.gate(1'b1),.timbre(3'd2),.gain(12'd2400),.step(24'd151197),
 .ctx_enable(1'b1),.ctx_load(1'b0),.ctx_data({`POLY_MODEL_STRINGS_W{1'b0}}),.ctx_state(),.sample(),.envelope(),.active(),.busy(),.deadline_error(),
 .mem_qa(18'd0),.mem_qb(18'd0),.mem_qc(18'd0),.mem_ra(),.mem_rb(),.mem_rc(),.mem_wa(),.mem_wb(),.mem_wc(),.mem_we(),.mem_da(),.mem_db(),.mem_dc(),.initializing_out(),.body_busy_out(),.state_out());
 reg signed[17:0]want;
 initial begin
  force dut.piano_bridge=mode;
  force dut.incident0=18'sd100000;force dut.incident1=18'sd50000;force dut.incident2=-18'sd30000;
  force dut.next_incident0=18'sd100000;force dut.next_incident1=18'sd50000;force dut.next_incident2=-18'sd30000;
  #1;trig=1;#1;
  if(dut.bridge_total_next!==20'sd120000)$fatal(1,"BRIDGE_REGISTERED_MODE_BOUNDARY_MISSING total%0d",dut.bridge_total_next);
  $display("POLY_BRIDGE_REGISTERED_MODE_BOUNDARY_PASS raw trigger/timbre cannot bypass registered bridge mode");$finish;
 end
endmodule
