`timescale 1ns/1ps
module tb_lesson_held_local_equiv;
 reg clk=0;always #5 clk=~clk;
 reg rst=1,sample_tick=0,enabled=1,restart=0,event_valid=0,panic=0;
 reg[6:0]base_note=60;reg[31:0]event_data=0;
 wire[6:0]target[0:1],fbnote[0:1],good[0:1];wire[1:0]fb[0:1];wire[5:0]pos[0:1];wire done[0:1];wire[15:0]bad[0:1];
 p8_lesson dut(.clk(clk),.rst(rst),.sample_tick(sample_tick),.enabled(enabled),.restart(restart),.base_note(base_note),.event_valid(event_valid),.event_data(event_data),.panic(panic),
 .target_note(target[0]),.feedback_note(fbnote[0]),.feedback(fb[0]),.position(pos[0]),.done(done[0]),.correct_count(good[0]),.wrong_count(bad[0]));
 p8_lesson_before_held_local reference(.clk(clk),.rst(rst),.sample_tick(sample_tick),.enabled(enabled),.restart(restart),.base_note(base_note),.event_valid(event_valid),.event_data(event_data),.panic(panic),
 .target_note(target[1]),.feedback_note(fbnote[1]),.feedback(fb[1]),.position(pos[1]),.done(done[1]),.correct_count(good[1]),.wrong_count(bad[1]));
 integer cycles=0,events=0,graded=0,consecutive=0,last_event=0,same_channel=0,cross_channel=0,forward_hits=0;
 integer src,ch,n,i,b,op;reg[4:0]prior_channel=0;reg[31:0]rng=32'h8a607e12;
 always @(posedge clk)begin
  #1;cycles++;
  if(event_valid)begin events++;if(last_event)consecutive++;if({event_data[24],event_data[3:0]}==prior_channel)same_channel++;else cross_channel++;prior_channel={event_data[24],event_data[3:0]};end
  last_event=event_valid;
  if(dut.forward_valid&&dut.forward_channel==dut.channel_index)forward_hits++;
  if({target[0],fbnote[0],good[0],fb[0],pos[0],done[0],bad[0]} !== {target[1],fbnote[1],good[1],fb[1],pos[1],done[1],bad[1]})$fatal(1,"LESSON_FULL_OLD_OUTPUT cycle%0d data%08x pos%0d/%0d",cycles,event_data,pos[0],pos[1]);
  if(dut.held!==reference.held||dut.row_valid!==reference.row_valid||dut.feedback_ticks!==reference.feedback_ticks)$fatal(1,"LESSON_FULL_OLD_HOLD_TIMER cycle%0d",cycles);
 end
 task ev(input integer source,status,note,velocity);begin
  @(negedge clk);event_valid=1;event_data=(source<<24)|(velocity<<16)|(note<<8)|status;
 end endtask
 task idle(input integer clocks);begin
  @(negedge clk);event_valid=0;repeat(clocks)@(negedge clk);
 end endtask
 task fresh(input integer base);begin
  @(negedge clk);enabled=1;restart=1;panic=0;event_valid=0;base_note=base;
  @(negedge clk);restart=0;
 end endtask
 function automatic integer offset(input integer p);begin
  case(p)
   0,1,13,28,29,41:offset=0;
   2,3,6,14,15,21,22,30,31,34:offset=7;
   4,5,32,33:offset=9;
   7,8,16,17,23,24,35,36:offset=5;
   9,10,18,19,25,26,37,38:offset=4;
   11,12,20,27,39,40:offset=2;
   default:offset=0;
  endcase
 end endfunction
 initial begin
  repeat(3)@(negedge clk);rst=0;
  // All128 bases, including sum>127, grade a fully back-to-back42-event song.
  // Use32 distinct channel identities, then16..25 with different pitches, so
  // repeated pitches are real new presses rather than unreleased owner duplicates.
  for(b=0;b<128;b++)begin
   fresh(b);
   for(i=0;i<42;i++)ev(((i<32?i:i-16)>>4)&1,8'h90|((i<32?i:i-16)&15),(b+offset(i)>127)?127:b+offset(i),100);
   idle(2);
   if(b<=118&&(!done[0]||pos[0]!=42||good[0]!=42))$fatal(1,"LESSON_BACK_TO_BACK_SONG base%0d pos%0d good%0d",b,pos[0],good[0]);
   if(b<=118)graded++;
  end
  fresh(60);
  for(src=0;src<2;src++)for(ch=0;ch<16;ch++)for(n=0;n<128;n++)begin
   ev(src,8'h90|ch,n,100);ev(src,8'h90|ch,n,100);
   ev(src^1,8'h80|ch,n,0);ev(src,8'h80|ch,n,0);ev(src,8'h90|ch,n,99);
  end
  for(src=0;src<2;src++)for(ch=0;ch<16;ch++)begin
   ev(src,8'hb0|ch,123,0);for(n=0;n<128;n++)ev(src,8'h90|ch,n,127);
   ev(src,8'hb0|ch,120,0);for(n=0;n<128;n++)ev(src,8'h90|ch,n,64);
  end
  ev(1,8'hff,255,255);
  for(src=0;src<2;src++)for(ch=0;ch<16;ch++)for(n=0;n<128;n++)begin ev(src,8'h90|ch,n,100);ev(src,8'h90|ch,n,0);end
  // Reuse the real legal/malformed MIDI and mode/reset/restart/base stress contract.
  for(i=0;i<30000;i++)begin
   @(negedge clk);rng=rng^(rng<<13);rng=rng^(rng>>17);rng=rng^(rng<<5);
   event_data=rng;event_valid=(rng[2:0]!=0);rst=(rng[14:0]==0);enabled=(rng[8:5]!=0);restart=(rng[13:9]==0);panic=(rng[19:14]==0);sample_tick=rng[20];
   if(rng[26:21]==0)base_note=rng[6:0];op=rng[31:27];
   if(op<12)begin event_data[7:4]=9;event_data[15]=0;event_data[23]=0;end
   else if(op<20)begin event_data[7:4]=8;event_data[15]=0;event_data[23]=0;end
   else if(op==20)event_data[7:0]=8'hff;
   else if(op<24)begin event_data[7:4]=11;event_data[15:8]=op[0]?123:120;event_data[23]=0;end
   else if(op<26)begin event_data[7:4]=9;event_data[23:16]=0;event_data[15]=0;end
  end
  @(negedge clk);rst=0;sample_tick=0;fresh(60);ev(0,8'h90,60,100);idle(2);
  @(negedge clk);sample_tick=1;repeat(14650)@(negedge clk);idle(2);
  if(graded!=119||consecutive==0||same_channel==0||cross_channel==0||forward_hits==0)$fatal(1,"LESSON_LOCAL_COVERAGE");
  $display("LESSON_HELD_LOCAL_EQ_PASS cycles%0d events%0d consecutive%0d sameChannel%0d crossChannel%0d forwarding%0d fullSongs%0d all4096holds/timer/allOutputsEveryClk currentOldRTL",cycles,events,consecutive,same_channel,cross_channel,forward_hits,graded);$finish;
 end
 initial begin #3000000;$fatal(1,"LESSON_HELD_LOCAL_TIMEOUT");end
endmodule
