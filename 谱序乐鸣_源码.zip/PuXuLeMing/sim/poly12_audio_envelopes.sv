`timescale 1ns/1ps
module tb_poly12_envelopes;
 parameter LONG=0;
 reg clk=0;always #10 clk=~clk;
 reg rst=1,tick=0;reg[7:0]choices=0;
 reg[11:0]gates=0,triggers=0,resets=0;
 wire[191:0]levels,reference_levels;wire[35:0]phases,reference_phases;
 wire[11:0]active;wire error;wire[2:0]reference_errors;
 final_envelope12 dut(clk,rst,tick,choices,gates,triggers,resets,levels,phases,active,error);
 genvar g;generate for(g=0;g<3;g=g+1)begin:oracle
  final_envelope4_gold old(.clk(clk),.rst(rst),.sample_tick(tick),.choices(choices),
   .gates(gates[g*4+:4]),.triggers(triggers[g*4+:4]),.resets(resets[g*4+:4]),
   .levels(reference_levels[g*64+:64]),.phases(reference_phases[g*12+:12]),.active(),.deadline_error(reference_errors[g]));
 end endgenerate
 integer f,c;reg[11:0]seen=0;integer frames;
 initial begin
  repeat(6)@(negedge clk);rst=0;
  choices=LONG?8'hff:8'h00;gates=12'hfff;triggers=12'hfff;frames=LONG?64000:12000;
  for(f=0;f<frames;f=f+1)begin
   tick=1;@(negedge clk);tick=0;
   for(c=1;c<1024;c=c+1)@(negedge clk);
   if(error||reference_errors!=0)$fatal(1,"ADSR_DEADLINE frame%0d",f);
   if(levels!==reference_levels||phases!==reference_phases)$fatal(1,"ADSR_INTEGER_OR_OWNERSHIP frame%0d levels%h ref%h phases%h ref%h",f,levels,reference_levels,phases,reference_phases);
   for(c=0;c<12;c=c+1)begin
    if(active[c]!==(|phases[c*3+:3]))$fatal(1,"ADSR_ACTIVE_FLAG frame%0d voice%0d",f,c);
    if(levels[c*16+:16]!=0)seen[c]=1;
   end
   triggers=0;resets=0;
   if(f==(LONG?4500:100))gates=0;
   if(!LONG)begin
    if(f==4300)begin gates=12'h555;triggers=12'h555;end
    if(f==4400)begin gates=12'haaa;triggers=12'haaa;end
    if(f==4450)begin resets=12'h801;gates[11]=0;gates[0]=0;end
    if(f==4500)gates=0;
    if(f==9000)begin choices=8'h55;gates=12'hfff;triggers=12'hfff;end
    if(f==9500)begin choices=8'h95;triggers=12'h3c3;end
   end
   if(LONG&&f>63100&&active!==0)$fatal(1,"LONG_RELEASE_NOT_IDLE frame%0d active%h",f,active);
   if(!LONG&&f==8800&&active!==0)$fatal(1,"SHORT_RELEASE_NOT_IDLE active%h",active);
  end
  if(seen!==12'hfff)$fatal(1,"ADSR_MISSING_VOICE %h",seen);
  $display("POLY12_ENVELOPE_PASS frames%0d long%0d 12independent bitexact-old-envelope sample1024 release/retrigger/reset",frames,LONG);$finish;
 end
 initial begin #1400000000;$fatal(1,"ADSR_TIMEOUT");end
endmodule
module tb_poly12_envelopes_long;tb_poly12_envelopes #(.LONG(1)) test();endmodule
