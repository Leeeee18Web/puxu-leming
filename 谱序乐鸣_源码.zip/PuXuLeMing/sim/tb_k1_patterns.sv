`timescale 1ns/1ps
module tb_k1_patterns;
 reg clk=0;always #10 clk=~clk;
 reg rst=1,sample_tick=0,cancel=0,start=0,event_valid=0,pedal_down=0;
 reg[1:0]pattern_mode=2;reg[31:0]event_data=0;reg[2:0]timbre_select=1;
 wire[6:0]selected;wire[48:0]selected_notes;wire[83:0]selected_gains;
 wire[3:0]raw_gates,raw_triggers,gates,triggers;wire[27:0]raw_notes,notes;
 wire[47:0]raw_gains,gains;wire[11:0]timbres;wire busy,full;wire[2:0]count;
 final_patterns #(.SAMPLE_HZ(20),.STRUM_SAMPLES(2),.ARP_SAMPLES(5),.HOLD_SAMPLES(6)) raw(.clk(clk),.rst(rst),.sample_tick(sample_tick),.cancel(cancel),.start(start),.event_valid(event_valid),.event_data(event_data),.pattern_mode(pattern_mode),.selected(selected),.selected_notes(selected_notes),.selected_gains(selected_gains),.gates(raw_gates),.triggers(raw_triggers),.notes(raw_notes),.gains(raw_gains),.busy(busy),.count(count),.full(full),.full_touch_mode(2'd0),.full_wifi_mode(2'd0),.full_owner(1'b0),.full_touch_enabled(1'b0),.full_note_request(1'b0),.full_base_cancel(1'b0));
 wire selection_event=event_valid&&event_data[7:4]==9&&event_data[22:16]!=0;
 final_pattern_pedal dut(.clk(clk),.rst(rst),.cancel(cancel||start||selection_event),.pedal_down(pedal_down),.pattern_mode(pattern_mode),.in_gates(raw_gates),.in_triggers(raw_triggers),.in_notes(raw_notes),.in_gains(raw_gains),.timbre_select(timbre_select),.gates(gates),.triggers(triggers),.notes(notes),.gains(gains),.timbres(timbres));
 integer checks=0,i,t,attacks=0;reg[127:0]seen=0;
 always @(negedge clk)for(integer k=0;k<4;k++)if(triggers[k])begin seen[notes[k*7+:7]]=1;attacks++;end
 task check(input bit ok,input string why);begin checks++;if(!ok)$fatal(1,"K1_PATTERN_FAIL %s",why);end endtask
 task clocks(input integer n);repeat(n)@(negedge clk);endtask
 task tick;begin sample_tick=1;clocks(1);sample_tick=0;clocks(65);end endtask
 task ev(input[6:0]p);begin event_data={8'd0,8'd100,1'b0,p,8'h90};event_valid=1;clocks(1);event_valid=0;clocks(3);end endtask
 task reset_all(input[1:0]m);begin rst=1;clocks(3);rst=0;pattern_mode=m;pedal_down=1;clocks(4);seen=0;attacks=0;end endtask
 task launch;begin start=1;clocks(1);start=0;clocks(60);tick;tick;end endtask
 initial begin
  reset_all(2);ev(60);ev(64);check(count==2&&gates==0,"pedal never sounds silent selection");
  launch;check(gates==3&&timbres[5:0]=={3'd1,3'd1},"chord trigger preserves per onset timbre");
  repeat(8)tick;check(!busy&&raw_gates==0&&gates==3&&gains[11:0]!=0,"chord ends scheduler but retains pedal sound and gain");
  pedal_down=0;clocks(3);check(gates==0&&gains[11:0]!=0&&triggers==0,"release retains natural tail controls without attack");
  pedal_down=1;clocks(3);check(gates==0,"no resurrection after completed release");
  reset_all(3);for(i=0;i<7;i++)ev(60+i);launch;repeat(40)tick;
  check(!busy&&gates==15&&attacks==7,"arp continues seven onsets with four held slots");
  for(i=0;i<7;i++)check(seen[60+i],"all seven selected pitches triggered");
  check(notes=={7'd63,7'd66,7'd65,7'd64},"arp retains latest four pitches by rotating oldest");
  cancel=1;clocks(1);cancel=0;clocks(3);check(gates==0&&gains==0&&count==7,"cancel overrides pedal but retains selected list");
  launch;repeat(3)tick;ev(60);check(gates==0&&count==6,"new selection cancels old sustained pattern");
  reset_all(1);ev(60);ev(64);launch;repeat(12)tick;
  check(gates==3&&!busy,"strum sustains after scheduled hold");
  pattern_mode=0;clocks(3);check(gates==0&&gains==0,"mode exit flushes pedal pattern");
  $display("K1_PATTERN_PASS checks=%0d attacks=%0d",checks,attacks);$finish;
 end
endmodule
