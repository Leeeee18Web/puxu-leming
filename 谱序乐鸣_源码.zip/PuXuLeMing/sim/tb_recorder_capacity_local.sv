`timescale 1ns/1ps
`include "sim/fixtures/final_recorder_decode_reference.sv"
module recorder_capacity_equiv_case #(parameter N=7,CAP=64,CASE_ID=0,FRAME=64)(output reg done=0);
 reg clk=0,rst=1;always #10 clk=~clk;
 reg[$clog2(FRAME)-1:0]phase=0;always @(posedge clk)phase<=phase+1'b1;
 wire sample_tick=phase==FRAME-1;
 reg record_toggle=0,replay_toggle=0,clear=0,panic=0;
 reg[N-1:0]in_gates=0,in_triggers=0;reg[N*7-1:0]in_notes=0;
 reg[N*12-1:0]in_gains=0;reg[N*3-1:0]in_timbres=0;reg[18:0]in_ratio=262144;
 reg[6:0]in_mod_depth=0;reg[31:0]in_synth_config=0;
 wire[N-1:0]g[0:1],t[0:1];wire[N*7-1:0]n[0:1];wire[N*12-1:0]v[0:1];wire[N*3-1:0]tm[0:1];wire[18:0]r[0:1];wire[6:0]m[0:1];wire[31:0]c[0:1];
 wire rec[0:1],play[0:1],full[0:1],limit[0:1],ready[0:1];wire[12:0]count[0:1];wire[31:0]time_samples[0:1],duration[0:1];
 wire[95:0] exported[0:1];wire er[0:1];wire[31:0]take[0:1];
 final_recorder #(.EVENT_CAPACITY(CAP),.MAX_SAMPLES(40),.VOICE_COUNT(N))dut(.observer_gains(),.clk(clk),.rst(rst),.sample_tick(sample_tick),.record_toggle(record_toggle),.replay_toggle(replay_toggle),.clear(clear),.panic(panic),
  .in_gates(in_gates),.in_triggers(in_triggers),.in_notes(in_notes),.in_gains(in_gains),.in_timbres(in_timbres),.in_ratio(in_ratio),.in_mod_depth(in_mod_depth),.in_synth_config(in_synth_config),
  .out_gates(g[0]),.out_triggers(t[0]),.out_notes(n[0]),.out_gains(v[0]),.out_timbres(tm[0]),.out_ratio(r[0]),.out_mod_depth(m[0]),.out_synth_config(c[0]),
  .recording(rec[0]),.replaying(play[0]),.full(full[0]),.time_limit(limit[0]),.replay_frame_ready(ready[0]),.count(count[0]),.time_samples(time_samples[0]),.duration_samples(duration[0]),.export_address(12'd0),.export_word(exported[0]),.export_ready(er[0]),.take_id(take[0]),.preview_rst(1'b0),.preview_gates('0),.preview_notes('0),.preview_gains('0),.preview_timbres('0),.preview_ratio('0),.preview_mod_depth('0),.preview_synth_config('0));
 final_recorder_decode_reference #(.EVENT_CAPACITY(CAP),.MAX_SAMPLES(40),.VOICE_COUNT(N))reference(.clk(clk),.rst(rst),.sample_tick(sample_tick),.record_toggle(record_toggle),.replay_toggle(replay_toggle),.clear(clear),.panic(panic),
  .in_gates(in_gates),.in_triggers(in_triggers),.in_notes(in_notes),.in_gains(in_gains),.in_timbres(in_timbres),.in_ratio(in_ratio),.in_mod_depth(in_mod_depth),.in_synth_config(in_synth_config),
  .out_gates(g[1]),.out_triggers(t[1]),.out_notes(n[1]),.out_gains(v[1]),.out_timbres(tm[1]),.out_ratio(r[1]),.out_mod_depth(m[1]),.out_synth_config(c[1]),
  .recording(rec[1]),.replaying(play[1]),.full(full[1]),.time_limit(limit[1]),.replay_frame_ready(ready[1]),.count(count[1]),.time_samples(time_samples[1]),.duration_samples(duration[1]),.export_address(12'd0),.export_word(exported[1]),.export_ready(er[1]),.take_id(take[1]));
 integer voice_index;
 reg prior_export_ready=0;
 reg prior_capture_busy=0;
 integer ram_checks=0,ram_index,prep_cycles=0,max_prep=0,raw_differences=0;
 integer checks=0,frames=0,plays=0,fulls=0,limits=0,seed=32'h31415926,k,j;
 always @(negedge clk)if(!rst)begin
  checks++;
  if({dut.capture_busy,dut.capture_index,dut.write_index}!=={reference.capture_busy,reference.capture_index,reference.write_index})$fatal(1,"RECORDER_WRITER_TIMING");
  if(prior_capture_busy&&!dut.capture_busy)begin
   for(ram_index=0;ram_index<count[0];ram_index=ram_index+1)begin
    if($isunknown(dut.event_ram[ram_index])||dut.event_ram[ram_index]!==reference.event_ram[ram_index])$fatal(1,"RECORDER_RAM_DATA address=%0d",ram_index);
    ram_checks++;
   end
  end
  prior_capture_busy=dut.capture_busy;
  if(play[0]&&!ready[0])begin prep_cycles++;if(prep_cycles>max_prep)max_prep=prep_cycles;end else prep_cycles=0;
  if({g[0],t[0],n[0],v[0],tm[0],r[0],m[0],c[0],ready[0]}!=={g[1],t[1],n[1],v[1],tm[1],r[1],m[1],c[1],ready[1]})raw_differences++;
  // Playback preparation may take one extra clock/event. The real audio
  // consumes the controls at sample_tick; exported RAM has a synchronous read.
  if({er[0],take[0],rec[0],play[0],full[0],limit[0],count[0],time_samples[0],duration[0]}!==
     {er[1],take[1],rec[1],play[1],full[1],limit[1],count[1],time_samples[1],duration[1]})
   $fatal(1,"RECORDER_METADATA clock=%0d phase=%0d",checks,phase);
  if(er[0]&&prior_export_ready&&exported[0]!==exported[1])$fatal(1,"RECORDER_EXPORT_WORD");
  prior_export_ready=er[0];
  if(sample_tick)begin
   if(ready[0]!==ready[1]||(play[0]&&!ready[0]))$fatal(1,"RECORDER_FRAME_NOT_READY");
   if({g[0],t[0],n[0],v[0],tm[0],r[0],m[0],c[0]}!=={g[1],t[1],n[1],v[1],tm[1],r[1],m[1],c[1]})
    $fatal(1,"RECORDER_AUDIO_FRAME clock=%0d",checks);
  end
  if(sample_tick)begin frames++;if(play[0])plays++;if(full[0])fulls++;if(limit[0])limits++;end
 end
 task frame(input bit record_cmd,replay_cmd);begin
  @(posedge clk);while(phase!=10)@(posedge clk);
  @(negedge clk);record_toggle=record_cmd;replay_toggle=replay_cmd;
  @(negedge clk);record_toggle=0;replay_toggle=0;
  @(posedge sample_tick);repeat(3)@(posedge clk);
 end endtask
 initial begin
  repeat(5)@(negedge clk);rst=0;
  // All voices plus a high-bit config event share timestamp0; Record->Replay
  // then waits for a second dense capture. Config must not alias voice1.
  if(CAP>=N+1)begin
   in_gates='1;in_synth_config=32'h80000a55;in_mod_depth=127;
   for(voice_index=0;voice_index<N;voice_index=voice_index+1)begin
    in_notes[voice_index*7+:7]=48+voice_index;in_gains[voice_index*12+:12]=1000+voice_index;in_timbres[voice_index*3+:3]=voice_index%4;
   end
   frame(1,0);repeat(2)frame(0,0);
   in_notes=in_notes+1'b1;in_synth_config=32'h000005aa;in_ratio=300001;frame(0,1);
   repeat(8)frame(0,0);clear=1;frame(0,0);clear=0;
   in_gates=0;in_notes=0;in_gains=0;in_timbres=0;in_synth_config=0;in_mod_depth=0;in_ratio=262144;
  end
  in_gates=1;in_gains=100;in_notes=60;frame(1,0);
  repeat(4)frame(0,0);in_triggers=1;in_notes=62;frame(0,1);in_triggers=0;
  repeat(15)frame(0,0);frame(1,0);repeat(45)frame(0,0);frame(0,1);repeat(45)frame(0,0);
  clear=1;frame(0,0);clear=0;frame(1,0);
  for(k=0;k<15;k++)begin in_notes=k;in_gates=k;in_gains=k*987;in_timbres=k;frame(0,0);end
  frame(0,1);repeat(20)frame(0,0);
  for(k=0;k<700;k++)begin
   j=$unsigned($random(seed))%32;
   if(j<12)begin
    in_gates=$random(seed);in_triggers=$random(seed);
    for(voice_index=0;voice_index<N;voice_index=voice_index+1)begin
     in_notes[voice_index*7+:7]=$random(seed);in_gains[voice_index*12+:12]=$random(seed);in_timbres[voice_index*3+:3]=$random(seed);
    end
   end
   if(j==12)begin in_ratio=$random(seed);in_mod_depth=$random(seed);in_synth_config=$random(seed);end
   clear=j==13;panic=j==14;frame(j==15||j==17,j==16||j==17);in_triggers=0;clear=0;panic=0;
  end
  if(plays==0||fulls==0||limits==0)$fatal(1,"RECORDER_EQ coverage incomplete plays=%0d full=%0d limit=%0d",plays,fulls,limits);
  if(ram_checks==0)$fatal(1,"RECORDER_RAM_COVERAGE");
  $display("RECORDER_EQ_PASS N%0d frame%0d clocks=%0d frames=%0d replayframes=%0d fullframes=%0d limitframes=%0d RAM%0d maxprep%0d rawdelta%0d",N,FRAME,checks,frames,plays,fulls,limits,ram_checks,max_prep,raw_differences);done=1;
 end
 initial begin #30000000;if(!done)$fatal(1,"RECORDER_EQ timeout");end
endmodule

module recorder_configuration_boundary(output reg done=0);
 localparam N=7;
 reg [57:0] current_configuration=0,previous_configuration=0;
 integer seed=32'h31649ad7,i,j,checks=0;
 final_recorder #(.VOICE_COUNT(N),.EVENT_CAPACITY(3)) dut(
 .observer_gains(),.clk(1'b0),.rst(1'b1),.sample_tick(1'b0),.record_toggle(1'b0),.replay_toggle(1'b0),.clear(1'b0),.panic(1'b0),
 .in_gates({N{1'b0}}),.in_triggers({N{1'b0}}),.in_notes({N*7{1'b0}}),.in_gains({N*12{1'b0}}),.in_timbres({N*3{1'b0}}),
 .in_ratio(current_configuration[57:39]),.in_mod_depth(current_configuration[38:32]),.in_synth_config(current_configuration[31:0]),.export_address(12'd0),
 .out_gates(),.out_triggers(),.out_notes(),.out_gains(),.out_timbres(),.out_ratio(),.out_mod_depth(),.out_synth_config(),
 .recording(),.replaying(),.full(),.time_limit(),.replay_frame_ready(),.count(),.time_samples(),.export_word(),.export_ready(),.take_id(),.duration_samples(),.preview_rst(1'b0),.preview_gates('0),.preview_notes('0),.preview_gains('0),.preview_timbres('0),.preview_ratio('0),.preview_mod_depth('0),.preview_synth_config('0));
 final_recorder_decode_reference #(.VOICE_COUNT(N),.EVENT_CAPACITY(3)) reference(
 .clk(1'b0),.rst(1'b1),.sample_tick(1'b0),.record_toggle(1'b0),.replay_toggle(1'b0),.clear(1'b0),.panic(1'b0),
 .in_gates({N{1'b0}}),.in_triggers({N{1'b0}}),.in_notes({N*7{1'b0}}),.in_gains({N*12{1'b0}}),.in_timbres({N*3{1'b0}}),
 .in_ratio(current_configuration[57:39]),.in_mod_depth(current_configuration[38:32]),.in_synth_config(current_configuration[31:0]),.export_address(12'd0),
 .out_gates(),.out_triggers(),.out_notes(),.out_gains(),.out_timbres(),.out_ratio(),.out_mod_depth(),.out_synth_config(),
 .recording(),.replaying(),.full(),.time_limit(),.replay_frame_ready(),.count(),.time_samples(),.export_word(),.export_ready(),.take_id(),.duration_samples());
 task compare(input [57:0] a,b);begin
  current_configuration=a;previous_configuration=b;#1;
  if(dut.changed[N]!==reference.changed[N])$fatal(1,"CONFIGURATION_CHANGED_DIFFER");checks++;
 end endtask
 initial begin
  force dut.previous_ratio=previous_configuration[57:39];force reference.previous_ratio=previous_configuration[57:39];
  force dut.previous_mod=previous_configuration[38:32];force reference.previous_mod=previous_configuration[38:32];
  force dut.previous_config=previous_configuration[31:0];force reference.previous_config=previous_configuration[31:0];
  for(i=0;i<58;i++)begin compare(58'd0,58'd1<<i);compare(58'd1<<i,58'd1<<i);end
  for(i=0;i<58;i++)for(j=0;j<58;j++)compare((58'd1<<i)|(58'd1<<j),58'd0);
  for(i=0;i<131072;i++)begin
   current_configuration={$random(seed),$random(seed)};
   compare(current_configuration,(i&1)?current_configuration:{$random(seed),$random(seed)});
  end
  $display("CONFIGURATION_CHANGED_PASS vectors=%0d",checks);done=1;
 end
endmodule

module recorder_capacity_boundary_case #(parameter N=7,CAP=4096)(output reg done=0);
 reg [12:0] forced_count=0;
 reg [N:0] mask=0;
 integer occupied,increment,checks=0;
 final_recorder #(.VOICE_COUNT(N),.EVENT_CAPACITY(CAP)) dut(.observer_gains(),.clk(1'b0),.rst(1'b1),.sample_tick(1'b0),.record_toggle(1'b0),.replay_toggle(1'b0),.clear(1'b0),.panic(1'b0),
 .in_gates({N{1'b0}}),.in_triggers({N{1'b0}}),.in_notes({N*7{1'b0}}),.in_gains({N*12{1'b0}}),.in_timbres({N*3{1'b0}}),
 .in_ratio(19'd0),.in_mod_depth(7'd0),.in_synth_config(32'd0),.export_address(12'd0),
 .out_gates(),.out_triggers(),.out_notes(),.out_gains(),.out_timbres(),.out_ratio(),.out_mod_depth(),.out_synth_config(),
 .recording(),.replaying(),.full(),.time_limit(),.replay_frame_ready(),.count(),.time_samples(),.export_word(),.export_ready(),.take_id(),.duration_samples(),.preview_rst(1'b0),.preview_gates('0),.preview_notes('0),.preview_gains('0),.preview_timbres('0),.preview_ratio('0),.preview_mod_depth('0),.preview_synth_config('0));
 final_recorder_capacity_reference #(.VOICE_COUNT(N),.EVENT_CAPACITY(CAP)) reference(.clk(1'b0),.rst(1'b1),.sample_tick(1'b0),.record_toggle(1'b0),.replay_toggle(1'b0),.clear(1'b0),.panic(1'b0),
 .in_gates({N{1'b0}}),.in_triggers({N{1'b0}}),.in_notes({N*7{1'b0}}),.in_gains({N*12{1'b0}}),.in_timbres({N*3{1'b0}}),
 .in_ratio(19'd0),.in_mod_depth(7'd0),.in_synth_config(32'd0),.export_address(12'd0),
 .out_gates(),.out_triggers(),.out_notes(),.out_gains(),.out_timbres(),.out_ratio(),.out_mod_depth(),.out_synth_config(),
 .recording(),.replaying(),.full(),.time_limit(),.replay_frame_ready(),.count(),.time_samples(),.export_word(),.export_ready(),.take_id(),.duration_samples());
 initial begin
  force dut.count=forced_count;force reference.count=forced_count;
  force dut.changed=mask;force reference.changed=mask;
  for(occupied=0;occupied<8192;occupied=occupied+1)begin
   forced_count=occupied;
   for(increment=0;increment<=N+1;increment=increment+1)begin
    mask=(32'd1<<increment)-1;#1;
    if(dut.changed_count!==increment||reference.changed_count!==increment)$fatal(1,"CAPACITY_POPCOUNT N=%0d",N);
    if(dut.capacity_exceeded[dut.changed_count] !== (reference.count+reference.changed_count>CAP))
     $fatal(1,"CAPACITY_BOUNDARY N=%0d CAP=%0d count=%0d increment=%0d",N,CAP,occupied,increment);
    checks=checks+1;
   end
  end
  $display("CAPACITY_BOUNDARY_PASS N=%0d CAP=%0d checks=%0d",N,CAP,checks);done=1;
 end
endmodule

module recorder_decode_boundary_case(output reg done=0);
 reg clk=0,rst=1,tick=0,record_cmd=0,replay_cmd=0;always #10 clk=~clk;
 reg [95:0] mutated_word=0;
 final_recorder #(.VOICE_COUNT(7),.EVENT_CAPACITY(16)) dut(
 .observer_gains(),.clk(clk),.rst(rst),.sample_tick(tick),.record_toggle(record_cmd),.replay_toggle(replay_cmd),.clear(1'b0),.panic(1'b0),
 .in_gates(7'b0000001),.in_triggers(7'd0),.in_notes(49'd60),.in_gains(84'd1000),.in_timbres(21'd3),
 .in_ratio(19'd262144),.in_mod_depth(7'd0),.in_synth_config(32'h80000001),.export_address(12'd0),
 .out_gates(),.out_triggers(),.out_notes(),.out_gains(),.out_timbres(),.out_ratio(),.out_mod_depth(),.out_synth_config(),
 .recording(),.replaying(),.full(),.time_limit(),.replay_frame_ready(),.count(),.time_samples(),.export_word(),.export_ready(),.take_id(),.duration_samples(),.preview_rst(1'b0),.preview_gates('0),.preview_notes('0),.preview_gains('0),.preview_timbres('0),.preview_ratio('0),.preview_mod_depth('0),.preview_synth_config('0));
 task command(input bit record_value,replay_value);begin
  @(negedge clk);tick=1;record_cmd=record_value;replay_cmd=replay_value;
  @(negedge clk);tick=0;record_cmd=0;replay_cmd=0;
 end endtask
 initial begin
  repeat(4)@(negedge clk);rst=0;
  command(1,0);repeat(12)@(negedge clk);command(1,0);repeat(12)@(negedge clk);command(0,1);
  while(dut.replay_state!=2)@(negedge clk);
  @(posedge clk);#1;if(dut.replay_state!==6)$fatal(1,"RECORDER_DECODE_STAGE_MISSING state=%0d",dut.replay_state);
  @(posedge clk);#1;if(dut.replay_state!==3)$fatal(1,"RECORDER_APPLY_STAGE_MISSING");
  // Only this boundary probe perturbs the RAM index after DECODE. The actual
  // frame/transaction oracle above drives ordinary inputs without such forces.
  @(negedge clk);mutated_word=dut.read_word;mutated_word[62:57]=6;force dut.read_word=mutated_word;
  @(posedge clk);#1;
  if(dut.stage_notes[6:0]!==60||dut.stage_notes[48:42]!==0||dut.stage_gains[11:0]!==1000)$fatal(1,"RECORDER_INDEX_NOT_CAPTURED");
  release dut.read_word;
  $display("RECORDER_DECODE_BOUNDARY_PASS registered index after synchronous RAM WAIT");done=1;
 end
 initial begin #20000;if(!done)$fatal(1,"RECORDER_DECODE_BOUNDARY_TIMEOUT");end
endmodule

module tb_recorder_decode_boundary;
 wire done;recorder_decode_boundary_case check_boundary(done);
 initial begin wait(done);$finish;end
endmodule

module tb_recorder_capacity_local;
 wire [9:0] done;
 recorder_capacity_equiv_case #(.N(4),.CAP(32),.CASE_ID(0)) e4(done[0]);
 recorder_capacity_equiv_case #(.N(7),.CAP(64),.CASE_ID(1)) e7(done[1]);
 recorder_capacity_equiv_case #(.N(25),.CAP(128),.CASE_ID(2),.FRAME(256)) e25(done[2]);
 recorder_capacity_equiv_case #(.N(7),.CAP(3),.CASE_ID(3)) e_small(done[3]);
 recorder_capacity_boundary_case #(.N(4),.CAP(32)) b4(done[4]);
 recorder_capacity_boundary_case #(.N(7),.CAP(4096)) b7(done[5]);
 recorder_capacity_boundary_case #(.N(25),.CAP(3)) b25(done[6]);
 recorder_capacity_equiv_case #(.N(7),.CAP(64),.CASE_ID(4),.FRAME(1024)) e_real(done[7]);
 recorder_configuration_boundary configuration_vectors(done[8]);
 recorder_decode_boundary_case decode_boundary(done[9]);
 initial begin wait(&done);$display("RECORDER_CAPACITY_LOCAL_PASS");$finish;end
 initial begin #31000000;$fatal(1,"CAPACITY_LOCAL_TIMEOUT");end
endmodule
