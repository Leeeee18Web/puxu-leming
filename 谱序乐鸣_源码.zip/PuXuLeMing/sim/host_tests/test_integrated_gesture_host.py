"""Gesture-only acceptance. No physical serial, camera, or audio access."""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import binascii
import queue
import struct
import time
import unittest
from pathlib import Path

from gesture_link import Decoder, encode_command, parse_status, GestureLink

def reply(seq, firmware=0x5008, caps=1, ack=None,flags=0,mode=1):
    payload=struct.pack('<HHHBBHHHBBBBHI',firmware,caps,seq if ack is None else ack,
                        0,flags,0,0,0,mode,5,1,60,0,1234)
    body=struct.pack('<BBHH',2,0x27,seq,24)+payload
    return b'GS'+body+struct.pack('<H',binascii.crc_hqx(body,0xffff))

class Peer:
    mode='valid'
    def __init__(self,*args,**kwargs):
        self.pending=bytearray();self.writes=[];self.closed=False;self.kwargs=kwargs
    def write(self,data):
        self.writes.append(bytes(data));seq=struct.unpack_from('<H',data,4)[0]
        if self.mode=='silent':return len(data)
        packet=reply(seq)
        if self.mode=='zero':packet=reply(seq,firmware=0,caps=0)
        if self.mode=='wrong':packet=reply(seq,firmware=0x3241)
        if self.mode=='stale':packet=reply(seq^0x8000,firmware=0,caps=0)+packet
        if self.mode=='bad_ack':packet=reply(seq,ack=seq^1)
        if self.mode=='bad_crc':packet=packet[:-1]+bytes((packet[-1]^1,))
        if self.mode=='blocked':packet=reply(seq,flags=4)
        self.pending.extend(packet);return len(data)
    def read(self,size):
        if self.pending:
            data=bytes(self.pending[:size]);del self.pending[:size];return data
        time.sleep(.002);return b''
    def close(self):self.closed=True

class LinkTests(unittest.TestCase):
    def launch(self,mode='valid',timeout=.12):
        peers=[];events=queue.Queue()
        def factory(*args,**kwargs):
            p=Peer(*args,**kwargs);p.mode=mode;peers.append(p);return p
        worker=GestureLink('TEST',events,serial_factory=factory,handshake_timeout=timeout,initial_seq=0x613a)
        self.addCleanup(lambda:(worker.disconnect(),worker.join(1)))
        worker.start();return worker,events,peers
    def wait(self,events,kind,timeout=1):
        seen=[];until=time.monotonic()+timeout
        while time.monotonic()<until:
            try:e=events.get(timeout=.01);seen.append(e)
            except queue.Empty:continue
            if e['type']==kind:return e
        self.fail(repr(seen))
    def test_wire_matches_actual_hdl_contract(self):
        raw=encode_command(0x613a,0)
        self.assertEqual(raw.hex(),'475302263a6108000000000050384731a26e')
        self.assertEqual(encode_command(1,1,7,100)[8:16],b'\x01\x07\x64\0P8G1')
        for args in ((1,1,8,100),(1,2,1,0),(1,1,1,128)):
            with self.assertRaises(ValueError):encode_command(*args)
    def test_actual_rtl_uart_capture_and_fragmented_decode(self):
        path=Path(os.environ['GS2_CAPTURE'])
        raw=bytes(int(x,16) for x in path.read_text().split());d=Decoder();frames=[]
        for b in raw:frames.extend(d.feed(bytes((b,))))
        self.assertTrue(frames);self.assertEqual(d.errors,0)
        self.assertTrue(all(parse_status(p)['firmware']==0x5008 for s,p in frames))
    def test_real_worker_requires_matching_reply(self):
        w,q,ps=self.launch();self.wait(q,'connected');w.set_note(3,100)
        time.sleep(.06);w.disconnect();w.join(1)
        self.assertTrue(ps[0].closed);self.assertEqual(ps[0].kwargs['baudrate'],115200)
        self.assertTrue(any(raw[8:11]==b'\x01\x03\x64' for raw in ps[0].writes))
        self.assertEqual(ps[0].writes[-1][8:11],b'\x01\0\0')
        self.assertTrue(all(raw[8] in (0,1) for raw in ps[0].writes),'gesture host must never send recording/mix/WAV commands')
    def test_unmatched_zero_status_is_not_firmware_failure(self):
        w,q,ps=self.launch('stale');self.wait(q,'connected');self.assertTrue(w.connected)
    def test_zero_identity_has_specific_reply_error(self):
        w,q,ps=self.launch('zero');message=self.wait(q,'error')['message']
        self.assertIn('应答内容异常',message);self.assertNotIn('固件不匹配：0000',message)
        self.assertFalse(w.connected)
    def test_wrong_firmware_remains_rejected(self):
        w,q,ps=self.launch('wrong');message=self.wait(q,'error')['message']
        self.assertIn('3241',message);self.assertFalse(w.connected)
    def test_no_reply_crc_or_wrong_ack_cannot_enable_play(self):
        for mode in ('silent','bad_crc','bad_ack'):
            with self.subTest(mode=mode):
                w,q,ps=self.launch(mode);self.wait(q,'error');self.assertFalse(w.connected)
    def test_frozen_vision_cannot_be_renewed_by_serial_heartbeat(self):
        w,q,ps=self.launch();self.wait(q,'connected');w.set_note(5,100)
        time.sleep(.67)
        payloads=[p[8:11] for p in ps[0].writes]
        first=payloads.index(b'\x01\x05\x64')
        self.assertIn(b'\x01\0\0',payloads[first+1:])
    def test_p8_screen_status_fields_and_studio_rejection(self):
        self.assertFalse(parse_status(reply(1,flags=1)[8:32])['playable'])
        status=parse_status(reply(1,flags=4)[8:32]);self.assertEqual(status['pattern_mode'],2);self.assertFalse(status['playable'])
        self.assertFalse(parse_status(reply(1,mode=2)[8:32])['playable'])
        self.assertTrue(parse_status(reply(1,mode=0)[8:32])['playable'])
        with self.assertRaisesRegex(ValueError,r'ProjectIntegratedFinal\.fs'):parse_status(reply(1,firmware=0x4098)[8:32])
    def test_pattern_mode_keeps_recognition_but_sends_no_note_on(self):
        w,q,ps=self.launch('blocked');self.wait(q,'connected');w.set_note(3,100);time.sleep(.08)
        self.assertTrue(w.connected);self.assertFalse(w.playable)
        self.assertFalse(any(raw[8]==1 and raw[9]!=0 for raw in ps[0].writes))

class UiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from PySide6.QtWidgets import QApplication
        cls.application=QApplication.instance() or QApplication([])
    def window(self):
        from app import MainWindow
        w=MainWindow(port_scanner=lambda:[]);self.addCleanup(w.close);return w
    def test_only_gesture_controls_and_camera_independent_of_serial(self):
        from PySide6.QtWidgets import QPushButton,QTabWidget
        w=self.window();self.assertTrue(w.camera_button.isEnabled())
        self.assertFalse(w.findChildren(QTabWidget))
        texts=' '.join(b.text() for b in w.findChildren(QPushButton))
        for excluded in ('录','混','案例','琴键','播放'):self.assertNotIn(excluded,texts)
        self.assertFalse(w.sound.isEnabled())
    def test_matching_port_label_does_not_become_serial_name(self):
        w=self.window();w.port.addItem('COM14 · USB Serial Port','COM14');w.port.setCurrentIndex(0)
        self.assertEqual(w.port.device_name(),'COM14')
        w.port.setEditText('COM15');self.assertEqual(w.port.device_name(),'COM15')
    def test_actual_frames_only_renew_sound_when_armed(self):
        w=self.window()
        class Worker:
            def __init__(self):self.calls=[]
            def set_note(self,*args):self.calls.append(args)
            def disconnect(self):pass
            def join(self,*args):pass
        worker=Worker();w.worker=worker;w.connected=True;w.sound.setEnabled(True);w.sound.setChecked(True)
        w.on_vision_event(dict(type='frame',tracking=True,note=3,pose='3',enabled=True))
        self.assertEqual(worker.calls[-1],(3,100));self.assertEqual(w.digit.text(),'3')
        w.mute();w.on_vision_event(dict(type='frame',tracking=True,note=3,pose='3',enabled=True))
        self.assertEqual(worker.calls[-1],(0,0))
        self.assertEqual(w.digit.text(),'3','recognition remains visible while muted')
        w.sound.setChecked(True)
        w.on_vision_event(dict(type='frame',tracking=False,note=0,pose='unknown',enabled=True))
        self.assertEqual(worker.calls[-1],(0,0));self.assertEqual(w.digit.text(),'—')
    def test_camera_failure_and_stalled_frames_release(self):
        w=self.window()
        class Worker:
            def __init__(self):self.calls=[]
            def set_note(self,*args):self.calls.append(args)
            def disconnect(self):pass
            def join(self,*args):pass
        w.worker=Worker();w.connected=True;w.last_frame=time.monotonic()-1
        w.check_freshness();self.assertEqual(w.worker.calls[-1],(0,0))
        w.on_vision_event(dict(type='error',message='camera failed'))
        self.assertEqual(w.worker.calls[-1],(0,0));self.assertIn('camera failed',w.vision_status.text())
    def test_intentional_camera_shutdown_is_not_reported_as_startup_failure(self):
        from PySide6.QtCore import QProcess
        w=self.window();process=QProcess(w);w.vision=process;w.closing=True
        w.camera_error(process)
        self.assertFalse(w.camera_failed)
        self.assertNotIn('无法启动',w.vision_status.text())
        w.vision=None

if __name__=='__main__':unittest.main()
