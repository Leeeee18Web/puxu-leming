`timescale 1ns/1ps
module tb_play_control_sta_equiv;
 reg clk=0;always #10 clk=~clk;
 reg rst=1,sample_tick=0,event_valid=0,panic=0,centre=0;reg[31:0]event_data=0;
 wire event_ready,event_ready_r;
 wire[6:0]gates,triggers,knob,last_note,last_velocity,mod_depth;
 wire[6:0]gates_r,triggers_r,knob_r,last_note_r,last_velocity_r,mod_depth_r;
 wire[48:0]notes,notes_r;wire[83:0]gains,gains_r;wire[18:0]ratio,ratio_r;
 wire [1:0] knob_mode=1;wire [6:0] raw_knob;wire raw_known,pickup_wait;
 play_voice_control dut(.*);
 play_voice_control_reference reference(.clk(clk),.rst(rst),.sample_tick(sample_tick),.event_valid(event_valid),.event_data(event_data),.panic(panic),.centre(centre),.event_ready(event_ready_r),.gates(gates_r),.triggers(triggers_r),.notes(notes_r),.gains(gains_r),.ratio(ratio_r),.knob(knob_r),.last_note(last_note_r),.last_velocity(last_velocity_r),.mod_depth(mod_depth_r));
 reg[31:0]rng=32'h24b6c831;integer k,cycles=0,events=0;
 task random_next;begin rng=rng^(rng<<13);rng=rng^(rng>>17);rng=rng^(rng<<5);end endtask
 always @(negedge clk)begin
  if({event_ready,gates,triggers,notes,gains,ratio,knob,last_note,last_velocity,mod_depth}!=={event_ready_r,gates_r,triggers_r,notes_r,gains_r,ratio_r,knob_r,last_note_r,last_velocity_r,mod_depth_r})
   $fatal(1,"real controller cycle mismatch cycle%0d event%h gates%h/%h notes%h/%h",cycles,event_data,gates,gates_r,notes,notes_r);
  cycles=cycles+1;
 end
 initial begin
  repeat(5)@(negedge clk);rst=0;
  for(k=0;k<100000;k=k+1)begin
   @(negedge clk);random_next();
   event_valid=rng[1:0]!=0;sample_tick=rng[4:2]==0;panic=rng[15:4]==0;centre=rng[18:8]==0;
   event_data={7'd0,rng[31],1'b0,rng[30:24],1'b0,rng[23:17],4'h9,2'd0,rng[16:15]};
   case(rng[7:5])
    0,1,2:event_data[7:4]=9;
    3:event_data[7:4]=8;
    4:begin event_data[7:4]=11;case(rng[10:8])0:event_data[15:8]=64;1:event_data[15:8]=120;2:event_data[15:8]=123;3:event_data[15:8]=74;default:event_data[15:8]=1;endcase end
    5:event_data[7:4]=12;
    6:event_data[7:4]=14;
    7:if(rng[12])event_data[7:0]=8'hff;
   endcase
   if(event_valid)events=events+1;
  end
  @(negedge clk);event_valid=0;panic=0;centre=0;repeat(10)@(negedge clk);
  $display("PASS tb_play_control_sta_equiv cycles=%0d events=%0d original/new all public outputs cycle exact; no event latency added",cycles,events);$finish;
 end
endmodule
