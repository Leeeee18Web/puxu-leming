`timescale 1ns/1ps
module poly_two_worker_audio_case #(parameter N=7,FX=0)(output reg done=0);
 reg clk=0;always #10 clk=~clk;reg rst=1,map_apply=0;
 reg[N-1:0]gates=0,triggers=0;reg[N*7-1:0]notes=0;reg[N*12-1:0]gains=0;reg[N*3-1:0]tones=0;reg[18:0]ratio=262144;
 wire ticka,tickb,posa,posb,hba,hbb,hwa,hwb,hda,hdb,iba,ibb,iwa,iwb,ida,idb,erra,errb,clipa,clipb;
 wire signed[15:0]pcma,pcmb;wire[N-1:0]activea,activeb;wire[N*24-1:0]stepa,stepb;wire[N*16-1:0]enva,envb;
 poly25_audio #(.VOICE_COUNT(N),.ENABLE_FX(FX)) dut(.clk(clk),.rst(rst),.gates(gates),.triggers(triggers),.notes(notes),.gains(gains),.timbres(tones),.ratio(ratio),.mod_depth(7'd0),.synth_config(32'h00000005),
 .sample_tick(ticka),.pcm(pcma),.pcm_positive(posa),.hp_bck(hba),.hp_ws(hwa),.hp_din(hda),.i2s_bck(iba),.i2s_ws(iwa),.i2s_sd(ida),.active(activea),.monitor_steps(stepa),.monitor_envelopes(enva),.deadline_error(erra),.clip_active(clipa),.map_apply(map_apply),.model_reset({12{rst}}),.control_resetn_early(1'b1));
 poly_audio_before_two_workers #(.VOICE_COUNT(N),.ENABLE_FX(FX)) reference(.clk(clk),.rst(rst),.gates(gates),.triggers(triggers),.notes(notes),.gains(gains),.timbres(tones),.ratio(ratio),.mod_depth(7'd0),.synth_config(32'h00000005),
 .sample_tick(tickb),.pcm(pcmb),.pcm_positive(posb),.hp_bck(hbb),.hp_ws(hwb),.hp_din(hdb),.i2s_bck(ibb),.i2s_ws(iwb),.i2s_sd(idb),.active(activeb),.monitor_steps(stepb),.monitor_envelopes(envb),.deadline_error(errb),.clip_active(clipb),.map_apply(map_apply),.model_reset({12{rst}}));
 genvar voice;generate for(voice=0;voice<N;voice++)begin:fade_checks
  integer loads=0,reloads=0,decrements=0,expires=0,quiet_fades=0,holds=0,resets_fading=0;
  always @(posedge clk)begin
   if(rst&&reference.outputs[voice].crossfade!=0)resets_fading++;
   if(!rst&&tickb)begin
    if((reference.pending_triggers[voice]||triggers[voice])&&activeb[voice])begin
     loads++;if(reference.outputs[voice].crossfade!=0)reloads++;
    end else if(reference.outputs[voice].crossfade!=0)begin
     decrements++;if(reference.outputs[voice].crossfade==1)expires++;
    end
   end
   if(reference.frame_gain_zero[voice]&&reference.outputs[voice].crossfade!=0)quiet_fades++;
   if(!tickb&&reference.outputs[voice].crossfade!=0)holds++;
   #1;
   if(dut.outputs[voice].crossfade!==reference.outputs[voice].crossfade||
      dut.outputs[voice].fading_nonzero!==(reference.outputs[voice].crossfade!=0))
    $fatal(1,"FADING_NONZERO_OLD_COUNTER_EQ N%0d slot%0d counter%0d flag%b old%0d",N,voice,dut.outputs[voice].crossfade,dut.outputs[voice].fading_nonzero,reference.outputs[voice].crossfade);
  end
  always @(posedge done)begin
   if(loads==0||reloads==0||decrements==0||expires==0||quiet_fades==0||holds==0||resets_fading==0)$fatal(1,"FADING_COVERAGE N%0d slot%0d load%0d reload%0d dec%0d expiry%0d quiet%0d hold%0d reset%0d",N,voice,loads,reloads,decrements,expires,quiet_fades,holds,resets_fading);
   $display("FADING_FLAG_COVERAGE N%0d slot%0d loads%0d reloads%0d decrements%0d expires%0d quiet%0d hold%0d resets%0d",N,voice,loads,reloads,decrements,expires,quiet_fades,holds,resets_fading);
  end
 end endgenerate
 integer internal_pcm_differences=0,active_differences=0,envelope_differences=0,frame_checks=0,checks=0,frames=0,writes=0,v,reset_remaining=0;reg[127:0]notes_seen=0;
 initial begin
  repeat(5)@(negedge clk);rst=0;
  while(frames<340)begin
   @(negedge clk);
   if(reset_remaining!=0)begin reset_remaining--;if(reset_remaining==0)rst=0;end
   if(ticka)begin
    for(v=0;v<N;v++)begin
     notes[v*7+:7]=(frames+v*23)%128;notes_seen[(frames+v*23)%128]=1;
     gains[v*12+:12]=(frames%17==0)?0:1000+(v*53)%3000;tones[v*3+:3]=(frames/16+v)%4;
    end
    gates=(frames%9==0)?0:{N{1'b1}};triggers=(frames%7==0)?{N{1'b1}}:0;
    ratio=frames%3==0?174763:frames%3==1?262144:393216;map_apply=frames==69;
    if(frames>=128&&frames<220)begin triggers=0;gates=0;if(frames>=140)gains=0;end
    if(frames>=220)begin
     for(v=0;v<N;v++)begin tones[v*3+:3]=0;notes[v*7+:7]=60+v%12;gains[v*12+:12]=2000;end
     gates={N{1'b1}};triggers=(frames<230||frames==235||frames==240)?{N{1'b1}}:0;
     if(frames>=230&&frames<233)gains=0;
     if(frames==232)begin rst=1;reset_remaining=4;end
     if(frames>=250)begin gates=0;gains=0;end
    end
    frames++;
   end
   #1;
   // Physical voices commit at different mid-frame clocks. Serial pins and
   // the actual frame/DAC/FX sampling boundary remain the observable contract.
   if({ticka,hba,hwa,hda,iba,iwa,ida,stepa,erra,clipa}!=={tickb,hbb,hwb,hdb,ibb,iwb,idb,stepb,errb,clipb})$fatal(1,"TWO_WORKER_SERIAL_CYCLE_EQ FX%0d frame%0d",FX,frames);
   if(ticka)begin
    if({pcma,posa,activea,enva,dut.phys_samples,dut.source_pcm}!=={pcmb,posb,activeb,envb,reference.phys_samples,reference.source_pcm})$fatal(1,"TWO_WORKER_FRAME_CAPTURE_EQ FX%0d frame%0d",FX,frames);
    if(dut.phys_busy||reference.phys_busy||erra||errb)$fatal(1,"TWO_WORKER_AUDIO_FRAME_DEADLINE");frame_checks++;
   end
   if(pcma!==pcmb)internal_pcm_differences++;
   if(activea!==activeb)active_differences++;
   if(enva!==envb)envelope_differences++;
   if(dut.index>=2&&dut.index<=N+1)writes++;
   checks++;
  end
  if(notes_seen!=={128{1'b1}}||writes<120*N)$fatal(1,"AUDIO_FADING_COVERAGE N%0d writes%0d",N,writes);
  $display("TWO_WORKER_INTERNAL_DIFFERENCES FX%0d pcm%0d active%0d envelope%0d frameChecks%0d",FX,internal_pcm_differences,active_differences,envelope_differences,frame_checks);
  $display("POLY_TWO_WORKER_AUDIO_PASS N%0d checks%0d frames%0d writes%0d all128notes/3ratios/all4tones/map/gate/trigger serial bitstream cycle-exact and actual frame capture equality",N,checks,frames,writes);done=1;
 end
endmodule
module tb_poly_two_worker_audio;
 wire[1:0]done;poly_two_worker_audio_case #(.N(7),.FX(0)) dry(done[0]);poly_two_worker_audio_case #(.N(7),.FX(1)) fx(done[1]);
 initial begin wait(&done);#1;$finish;end
endmodule
