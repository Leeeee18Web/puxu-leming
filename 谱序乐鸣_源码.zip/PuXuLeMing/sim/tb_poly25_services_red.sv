`timescale 1ns/1ps
module tb_poly25_services_red;
 reg clk=0;always #10 clk=~clk;reg rst=1;reg[24:0]active=0,gates=0;reg[174:0]notes=0;reg[299:0]gains=0;reg[599:0]steps=0;reg[399:0]envelopes=0;
 wire[6:0]home_gates,leading_note;wire[83:0]home_gains;wire[10:0]leading_pitch;wire[23:0]leading_step;wire[15:0]leading_envelope;wire leading_valid;
 final_voice_display display_dut(.clk(clk),.rst(rst),.gates(gates),.gains(gains),.home_gates(home_gates),.home_gains(home_gains));
 final_leading_voice leading_dut(.clk(clk),.rst(rst),.active(active),.notes(notes),.gains(gains),.steps(steps),.envelopes(envelopes),.*);
 integer i,checks=0;task check(input bit ok,input string msg);begin checks++;if(!ok)$fatal(1,"SERVICES25_FAIL %s",msg);end endtask
 initial begin repeat(5)@(negedge clk);rst=0;
 gates[24]=1;active[24]=1;gains[24*12+:12]=2345;notes[24*7+:7]=84;steps[24*24+:24]=500000;envelopes[24*16+:16]=4567;
 @(negedge clk);check(home_gates==8&&home_gains[3*12+:12]==2345,"voice24 visible in modulo7 bin3");
 repeat(50)@(negedge clk);check(leading_valid&&leading_note==84&&leading_step==500000&&leading_envelope==4567,"voice24 becomes leading");
 gates[3]=1;active[3]=1;gains[3*12+:12]=3000;notes[3*7+:7]=63;steps[3*24+:24]=300000;envelopes[3*16+:16]=1234;
 @(negedge clk);check(home_gains[3*12+:12]==3000,"bin gain uses max across grouped voices");
 repeat(50)@(negedge clk);check(leading_note==63&&leading_envelope==1234,"balanced leading lowest valid index remains legacy priority");
 active[3]=0;gates[3]=0;@(negedge clk);check(home_gates==8&&home_gains[3*12+:12]==2345,"lower sibling release preserves voice24 bin");
 for(i=0;i<25;i++)begin gates[i]=1;gains[i*12+:12]=100+i;end
 @(negedge clk);check(home_gates==127,"all25 cover all7 display bins");
 for(i=0;i<7;i++)check(home_gains[i*12+:12]==100+((24-i)/7)*7+i,"each bin shows greatest gain");
 gates=0;active=0;@(negedge clk);check(home_gates==0&&home_gains==0,"display silent cleared");
 repeat(50)@(negedge clk);check(!leading_valid,"leading silence cleared");
 $display("POLY25_SERVICES_PASS checks=%0d",checks);$finish;end
endmodule

