`timescale 1ns/1ps
// Real VexRiscv + compiled C + MMIO + host/PHY reset. No forced CPU bus.
// Only the millisecond timer is accelerated;256 clocks still exceed32 reset clocks.
module tb_p8_firmware_recovery;
 GSR GSR(.GSRI(1'b1));
 reg clk=0,resetn=0,full_speed=0;always #10.416667 clk=~clk;
 tri dp,dm;assign(weak1,weak0)dp=full_speed;assign(weak1,weak0)dm=!full_speed;
 usb_play_soc #(.TIMER_TICKS(256))dut(.clk(clk),.resetn(resetn),.uart_rx(1'b1),.uart_tx(),.usb_dp(dp),.usb_dm(dm),
 .debug_status(),.debug_xy(),.debug_raw(),.debug_vidpid(),.debug_meta(),.debug_valid_reports(),.debug_toggle(),
 .midi_data(),.midi_request(),.midi_ack(1'b1),.play_status(),.wifi_rx_data(),.wifi_rx_valid(),.wifi_rx_ready(1'b1),
  .wifi_tx_data(8'd0),.wifi_tx_valid(1'b0),.wifi_tx_ready(),.link_diagnostics(),.ptest_debug());
 integer cycles=0,low_cycles=0;reg initialized=0,reset_seen=0,new_enumeration=0;
 always @(posedge clk)if(resetn)begin
  cycles++;
  if(!dut.usb_host_resetn)begin low_cycles++;reset_seen=1;end
  if(dut.usb_restarts!=0&&dut.usb_host_resetn)full_speed<=1;
  if(dut.dbus_cmd_valid&&dut.dbus_cmd_ready&&dut.dbus_cmd_wr&&dut.dbus_cmd_a==32'h02000100)begin
   if(dut.dbus_cmd_data==32'h68)initialized=1;
   if(reset_seen&&dut.dbus_cmd_data==32'hc4)new_enumeration=1;
  end
  if(new_enumeration)begin
   if(!initialized||dut.usb_restarts!=1||low_cycles!=32)$fatal(1,"CPU recovery or host reset duration incorrect");
   $display("P8_CPU_RECOVERY_PASS cycles=%0d restarts=%0d host_reset_clocks=%0d pc=%08x",cycles,dut.usb_restarts,low_cycles,dut.ibus_cmd_pc);$finish;
  end
 end
 initial begin repeat(10)@(negedge clk);resetn=1;repeat(1000000)@(negedge clk);$fatal(1,"CPU recovery deadline pc=%08x",dut.ibus_cmd_pc);end
endmodule
