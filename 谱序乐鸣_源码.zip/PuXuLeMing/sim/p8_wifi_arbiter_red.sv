module p8_wifi_arbiter(input clk,rst,flush,input[31:0]touch_data,usb_data,gesture_data,wifi_data,
 input touch_valid,usb_valid,gesture_valid,wifi_valid,output touch_ready,usb_ready,gesture_ready,wifi_ready,
 output[31:0]data,output valid,input ready);
 assign data=touch_valid?touch_data:usb_valid?usb_data:gesture_valid?gesture_data:wifi_data;
 assign valid=touch_valid||usb_valid||gesture_valid||wifi_valid;
 assign touch_ready=ready;assign usb_ready=ready&&!touch_valid;
 assign gesture_ready=ready&&!touch_valid&&!usb_valid;assign wifi_ready=ready&&!touch_valid&&!usb_valid&&!gesture_valid;
endmodule
