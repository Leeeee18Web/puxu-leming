`timescale 1ns/1ps
module hw113_writer_case #(parameter T=2003,C=768,P=1,E=1,LIMIT=60000)(output reg done=0);
 reg clk=0,pixel_clk=0;always #10 if(!done)clk=~clk;always #9.756 if(!done)pixel_clk=~pixel_clk;
 reg rst=1,restart=0,sample_tick=0,recording=0,pitch_valid=0,pixel_rstn=0,frame_start=0,read_enable=1;
 reg[10:0]pitch=0;reg[9:0]read_addr=0;
 wire[10:0]a,b;wire[9:0]ca,cb;wire[16:0]sa,sb;
 tone_history #(.TOTAL_SAMPLES(T),.COLUMNS(C),.PIPELINED_READ(P),.READ_GATED(1),.PREDICT_WRITE(E)) dut(
 .clk(clk),.rst(rst),.restart(restart),.sample_tick(sample_tick),.recording(recording),.pitch(pitch),.pitch_valid(pitch_valid),
 .pixel_clk(pixel_clk),.pixel_rstn(pixel_rstn),.frame_start(frame_start),.read_addr(read_addr),.read_enable(read_enable),.pitch_data(a),.visible_count(ca),.curve_sum(sa));
 hw113_old_history #(.TOTAL_SAMPLES(T),.COLUMNS(C),.PIPELINED_READ(P),.READ_GATED(1)) old(
 .clk(clk),.rst(rst),.restart(restart),.sample_tick(sample_tick),.recording(recording),.pitch(pitch),.pitch_valid(pitch_valid),
 .pixel_clk(pixel_clk),.pixel_rstn(pixel_rstn),.frame_start(frame_start),.read_addr(read_addr),.read_enable(read_enable),.pitch_data(b),.visible_count(cb),.curve_sum(sb));
 integer cycles=0,writes=0,switches=0,accepts=0,consecutive=0,sporadic=0,invalid=0,resets=0,restarts=0,pauses=0;
 reg prior_tick=0,prior_writer=0,prior_seen=0,write_edge=0,scan_all=0;integer i;
 genvar g;
 generate for(g=0;g<7;g=g+1)begin:check_banks
  integer j;initial for(j=0;j<256;j=j+1)begin dut.banks[g].samples[j]=(j*113+g*983)&8191;old.banks[g].samples[j]=(j*113+g*983)&8191;end
  always @(posedge clk)begin
   if({dut.store_sample&&(dut.write_slot==g),dut.writer,dut.write_group,dut.mapped_y}!=={old.store_sample&&(old.write_slot==g),old.writer,old.write_group,old.mapped_y})$fatal(1,"HW113_BANK_WRITE_PORT T%0d bank%0d",T,g);
   #1;if(!done&&(cycles%4096==0||scan_all))for(j=0;j<256;j=j+1)if(dut.banks[g].samples[j]!==old.banks[g].samples[j])$fatal(1,"HW113_BANK_RAM T%0d bank%0d word%0d",T,g,j);
  end
 end
 for(g=0;g<4;g=g+1)begin:check_heads
  integer j;initial for(j=0;j<8;j=j+1)begin dut.head_reads[g].head_samples[j]=j*373+g;old.head_reads[g].head_samples[j]=j*373+g;end
  always @(posedge clk)begin #1;if(!done&&(write_edge||scan_all))for(j=0;j<8;j=j+1)if(dut.head_reads[g].head_samples[j]!==old.head_reads[g].head_samples[j])$fatal(1,"HW113_HEAD_RAM");end
 end endgenerate
 always @(posedge clk)begin
  write_edge=old.store_sample;
  if({dut.bin_ready,dut.new_pass,dut.store_sample,dut.writer,dut.column,dut.write_group,dut.write_slot,dut.value,dut.mapped_y}!==
     {old.bin_ready,old.new_pass,old.store_sample,old.writer,old.column,old.write_group,old.write_slot,old.value,old.mapped_y})$fatal(1,"HW113_COMPLETE_WRITE_PORT T%0d cycle%0d",T,cycles);
  if(write_edge)begin writes++;if(!pitch_valid)invalid++;end
  if(sample_tick&&prior_tick)consecutive++;if(sample_tick&&!prior_tick)sporadic++;prior_tick=sample_tick;
  if(rst)resets++;if(restart)restarts++;if(!recording)pauses++;
  #1;cycles++;
  if({dut.phase,dut.column,dut.source_count,dut.writer,dut.source_bank,dut.last_recording,dut.publish,dut.ack_sync,dut.dirty,dut.restart_pending}!==
     {old.phase,old.column,old.source_count,old.writer,old.source_bank,old.last_recording,old.publish,old.ack_sync,old.dirty,old.restart_pending})$fatal(1,"HW113_SOURCE_STATE T%0d cycle%0d",T,cycles);
  if(dut.PREDICT_PHASE&&dut.phase_bin_ready!==(old.phase>=T-C))$fatal(1,"HW113_LOOKAHEAD T%0d phase%0d",T,dut.phase);
  if(dut.writer!=prior_writer)switches++;prior_writer=dut.writer;
  if(!done&&(cycles%4096==0||scan_all))begin
   for(i=0;i<2048;i++)if(dut.history[i]!==old.history[i])$fatal(1,"HW113_HISTORY_RAM T%0d word%0d",T,i);
   for(i=0;i<8;i++)if(dut.first_sample[i]!==old.first_sample[i])$fatal(1,"HW113_FIRST_RAM");
   for(i=0;i<2;i++)if(dut.first_pitch[i]!==old.first_pitch[i])$fatal(1,"HW113_FIRST_PITCH_RAM");
  end
 end
 always @(posedge pixel_clk)begin #1;
  if({a,b,ca,sa,dut.publish_sync,dut.seen,dut.ack,dut.display_bank}!=={b,b,cb,sb,old.publish_sync,old.seen,old.ack,old.display_bank})$fatal(1,"HW113_PIXEL_PUBLIC T%0d",T);
  if(dut.seen!=prior_seen)accepts++;prior_seen=dut.seen;
 end
 integer n;
 initial begin
  for(i=0;i<2048;i++)begin dut.history[i]=(i*31)&2047;old.history[i]=(i*31)&2047;end
  for(i=0;i<8;i++)begin dut.first_sample[i]=i*73;old.first_sample[i]=i*73;end
  for(i=0;i<2;i++)begin dut.first_pitch[i]=i*13;old.first_pitch[i]=i*13;end
  repeat(8)@(negedge clk);rst=0;pixel_rstn=1;
  for(n=0;n<LIMIT;n++)begin
   @(negedge clk);sample_tick=n<LIMIT*3/4?1:n%3==0;recording=1;
   if(T<10000)begin rst=n%19001<2;restart=n%3719==3718;recording=n%2000<1700;end
   else begin rst=0;restart=n==1800000;recording=n<1700000||n>1700100;end
   pitch=n%2048;pitch_valid=n%11!=0;read_addr=n;read_enable=n%5!=0;frame_start=n%47==0;
  end
  @(negedge clk);sample_tick=0;scan_all=1;repeat(10)@(negedge clk);scan_all=0;
  if(writes<100||switches<2||accepts<5||consecutive<100||sporadic<100||invalid<5||pauses<5)$fatal(1,"HW113_WRITER_COVERAGE T%0d w%0d sw%0d a%0d c%0d s%0d iv%0d p%0d",T,writes,switches,accepts,consecutive,sporadic,invalid,pauses);
  $display("HW113_WRITER_PASS T%0d C%0d P%0d cycles%0d writes%0d switches%0d accepts%0d consecutive%0d sporadic%0d invalid%0d pauses%0d exactWritePorts/allRAM/source/CDC/public",T,C,P,cycles,writes,switches,accepts,consecutive,sporadic,invalid,pauses);done=1;
 end
 initial begin #150000000;$fatal(1,"HW113_WRITER_TIMEOUT T%0d",T);end
endmodule
module tb_hw113_writer;
 wire[5:0]done;
 hw113_writer_case #(.T(1464844),.LIMIT(3700000)) prod(done[0]);
 hw113_writer_case #(.T(2003)) consecutive_and_sporadic(done[1]);
 hw113_writer_case #(.T(1536)) exact_boundary(done[2]);
 hw113_writer_case #(.T(1000)) fallback(done[3]);
 hw113_writer_case #(.T(2003),.P(0)) legacy_read(done[4]);
 hw113_writer_case #(.T(2003),.E(0)) default_api(done[5]);
 initial begin wait(&done);$finish;end
endmodule
