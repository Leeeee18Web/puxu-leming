`timescale 1ns/1ps
module tb_play_mod;
 reg clk=0;always #10 clk=~clk;
 reg rst=1;reg [6:0] gates=0,triggers=0,mod_depth=0;
 reg [48:0] notes=72;reg [83:0] gains=3200;reg [18:0] ratio=262144;
 wire sample_tick;wire signed [15:0] pcm;wire hp_bck,hp_ws,hp_din,i2s_bck,i2s_ws,i2s_sd;wire [6:0] active;
 play_audio dut(.*);
 wire old_tick;wire signed [15:0] old_pcm;wire [5:0] old_serial;wire [6:0] old_active;
 play_audio_before_mod baseline(.clk(clk),.rst(rst),.gates(gates),.notes(notes),.gains(gains),.triggers(triggers),.ratio(ratio),.sample_tick(old_tick),.pcm(old_pcm),.hp_bck(old_serial[0]),.hp_ws(old_serial[1]),.hp_din(old_serial[2]),.i2s_bck(old_serial[3]),.i2s_ws(old_serial[4]),.i2s_sd(old_serial[5]),.active(old_active));
 integer k,v,min_index=0,max_index=0,min_step=16777215,max_step=0,last_cross=-1,min_period=10000,max_period=0,crosses=0,zero_cycles=0;
 integer slot_min[0:6],slot_max[0:6];
 reg signed [15:0] previous=0;
 always @(negedge clk)if(!rst&&mod_depth==0)begin
  if({sample_tick,pcm,hp_bck,hp_ws,hp_din,i2s_bck,i2s_ws,i2s_sd,active}!=={old_tick,old_pcm,old_serial[0],old_serial[1],old_serial[2],old_serial[3],old_serial[4],old_serial[5],old_active})$fatal(1,"MOD0 changed original PCM/serial path");zero_cycles=zero_cycles+1;
 end
 initial begin
  for(v=0;v<7;v=v+1)begin slot_min[v]=16777215;slot_max[v]=0;end
  repeat(5)@(negedge clk);rst=0;gates=1;triggers=1;@(negedge clk);triggers=0;
  repeat(512)begin @(negedge clk);while(!sample_tick)@(negedge clk);end
  mod_depth=127;
  for(k=0;k<10500;k=k+1)begin
   @(negedge clk);while(!sample_tick)@(negedge clk);
   if(k>500)begin
    if(dut.event_steps[23:0]<min_step)begin min_step=dut.event_steps[23:0];min_index=k;end
    if(dut.event_steps[23:0]>max_step)begin max_step=dut.event_steps[23:0];max_index=k;end
    for(v=0;v<7;v=v+1)begin
     if(dut.event_steps[v*24+:24]<slot_min[v])slot_min[v]=dut.event_steps[v*24+:24];
     if(dut.event_steps[v*24+:24]>slot_max[v])slot_max[v]=dut.event_steps[v*24+:24];
    end
    if(pcm>0&&previous<=0)begin
     if(last_cross>=0)begin if(k-last_cross<min_period)min_period=k-last_cross;if(k-last_cross>max_period)max_period=k-last_cross;end
     last_cross=k;crosses=crosses+1;
    end
   end
   previous=pcm;
  end
  if(!(min_step<178000&&max_step>181500))$fatal(1,"MOD must vary real sevenvoice pitch steps near +/-25cents");
  if(!(crosses>80&&min_period<=92&&max_period>=95))$fatal(1,"MOD must vary actual PCM crossing period");
  for(v=0;v<7;v=v+1)if(slot_min[v]>=slot_max[v])$fatal(1,"MOD must reach every voice pitch step");
  if(min_index-max_index<4800||min_index-max_index>4960)$fatal(1,"actual pitch modulation halfperiod must be about100ms/5Hz");
  $display("PASS tb_play_mod MOD0exactcycles=%0d modsteps=%0d..%0d actualPCMperiod=%0d..%0d crossings=%0d all7slots halfperiod_samples=%0d",zero_cycles,min_step,max_step,min_period,max_period,crosses,min_index-max_index);$finish;
 end
endmodule
