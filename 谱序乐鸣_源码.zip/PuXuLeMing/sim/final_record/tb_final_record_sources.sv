`timescale 1ns/1ps
// Real legacy pattern/song engines -> four-source mux -> recorder. No PCM mocks.
module tb_final_record_sources;
 reg clk=0;always #5 clk=~clk;
 reg rst=1,sample_tick=0,start_score=0,stop_score=0,panic=0,transition_mute=0,muted=0;
 reg [1:0]mode=1;reg[2:0]timbre_select=2;
 reg [3:0]direct_gates=0,direct_triggers=0;reg[27:0]direct_notes=0;reg[47:0]direct_gains=0;reg[11:0]direct_timbres=0;
 reg use_pattern=0;reg [1:0]pattern_mode=2;reg p_start=0,p_cancel=0,event_valid=0;reg[31:0]event_data=0;
 wire[3:0]p_gates,p_triggers;wire[6:0]p_selected;wire[27:0]p_notes;wire[48:0]p_selected_notes;wire[47:0]p_gains;wire[83:0]p_selected_gains;wire p_busy,p_full;wire[2:0]p_count;
 final_patterns #(.SAMPLE_HZ(16),.STRUM_SAMPLES(2),.ARP_SAMPLES(4),.HOLD_SAMPLES(8)) patterns(.clk(clk),.rst(rst),.sample_tick(sample_tick),.cancel(p_cancel),.pattern_mode(pattern_mode),.start(p_start),.event_valid(event_valid),.event_data(event_data),.selected(p_selected),.selected_notes(p_selected_notes),.selected_gains(p_selected_gains),.gates(p_gates),.triggers(p_triggers),.notes(p_notes),.gains(p_gains),.busy(p_busy),.count(p_count),.full(p_full),.full_touch_mode(2'd0),.full_wifi_mode(2'd0),.full_owner(1'b0),.full_touch_enabled(1'b0),.full_note_request(1'b0),.full_base_cancel(1'b0));
 wire[3:0]live_gates=use_pattern?p_gates:direct_gates;
 wire[3:0]live_triggers=use_pattern?p_triggers:direct_triggers;
 wire[27:0]live_notes=use_pattern?p_notes:direct_notes;
 wire[47:0]live_gains=use_pattern?p_gains:direct_gains;
 wire[11:0]live_timbres=use_pattern?{4{3'd3}}:direct_timbres;
 wire[3:0]gates,triggers;wire[27:0]notes;wire[47:0]gains;wire[11:0]timbres;wire playing,done;wire[6:0]next_note;
 final_audio_source #(.SCORE_TOTAL_SAMPLES(16)) source(.*);
 reg record_toggle=0,replay_toggle=0,clear=0;
 wire[3:0]out_gates,out_triggers;wire[27:0]out_notes;wire[47:0]out_gains;wire[11:0]out_timbres;
 wire[18:0]out_ratio;wire[6:0]out_mod_depth;wire[31:0]out_synth_config;
 wire recording,replaying,full,time_limit,replay_frame_ready;wire[12:0]count;wire[31:0]time_samples,duration_samples;
 final_recorder #(.MAX_SAMPLES(128)) recorder(.export_address(12'd0),.export_word(),.export_ready(),.take_id(),.clk(clk),.rst(rst),.sample_tick(sample_tick),.record_toggle(record_toggle),.replay_toggle(replay_toggle),.clear(clear),.panic(panic),.in_gates(gates),.in_triggers(triggers),.in_notes(notes),.in_gains(gains),.in_timbres(timbres),.in_ratio(19'd262144),.in_mod_depth(7'd4),.in_synth_config(32'h48822),.observer_gains(),.*,.preview_rst(1'b0),.preview_gates('0),.preview_notes('0),.preview_gains('0),.preview_timbres('0),.preview_ratio('0),.preview_mod_depth('0),.preview_synth_config('0));
 reg[3:0] fixture_g[0:63],fixture_t[0:63];reg[27:0]fixture_n[0:63];reg[47:0]fixture_v[0:63];reg[11:0]fixture_i[0:63];
 reg[3:0]observed_triggers=0;
 integer checks=0,j,p,heard;
 always @(posedge clk)if(rst)observed_triggers<=0;else if(sample_tick)observed_triggers<=0;else observed_triggers<=observed_triggers|triggers;
 task check(input bit ok,input string why);begin checks=checks+1;if(!ok)begin $display("FINAL_RECORD_SOURCES_FAIL %s",why);$fatal(1);end end endtask
 task gap;begin repeat(1022)@(posedge clk);#1;end endtask
 task tick;begin @(negedge clk);sample_tick=1;@(posedge clk);#1;@(negedge clk);sample_tick=0;gap;end endtask
 task reset_all;begin
  @(negedge clk);rst=1;mode=1;use_pattern=0;start_score=0;stop_score=0;panic=0;transition_mute=0;muted=0;
  direct_gates=0;direct_triggers=0;direct_notes=0;direct_gains=0;direct_timbres=0;
  record_toggle=0;replay_toggle=0;clear=0;p_start=0;p_cancel=0;event_valid=0;
  repeat(3)@(posedge clk);@(negedge clk);rst=0;gap;
 end endtask
 task cmd(input bit rec,input bit rep);begin @(negedge clk);record_toggle=rec;replay_toggle=rep;@(negedge clk);record_toggle=0;replay_toggle=0;end endtask
 task store(input integer idx);begin
  fixture_g[idx]=gates;fixture_n[idx]=notes;fixture_v[idx]=gains;fixture_i[idx]=timbres;fixture_t[idx]=observed_triggers|triggers;tick;
 end endtask
 task replay_fixture(input integer frames);begin
  heard=0;
  for(j=0;j<frames;j=j+1)begin
   check(replaying&&replay_frame_ready,"actual source replay meets 1024-clock preparation deadline");
   check(out_gates==fixture_g[j]&&out_notes==fixture_n[j]&&out_gains==fixture_v[j]&&out_timbres==fixture_i[j],"post-expansion source frame reproduced exactly");
   if(|out_gates)heard=heard+1;
   @(negedge clk);sample_tick=1;#1;check(out_triggers==(fixture_t[j]|((j==0)?fixture_g[j]:4'd0)),"frame-zero gated notes initialize once; later source triggers exact");
   @(posedge clk);#1;@(negedge clk);sample_tick=0;gap;
  end
  check(heard>0,"real source produced sounding controls before replay");
  check(!replaying&&out_gates==0,"source replay ends with silence");
 end endtask
 task select_note(input [6:0]pitch);begin
  @(negedge clk);event_valid=1;event_data={8'd0,1'b0,7'd100,1'b0,pitch,8'h90};
  @(negedge clk);event_valid=0;gap;
 end endtask
 initial begin
  reset_all;
  // Break caught: widening only declarations silently truncates voice 3.
  direct_gates=4'h8;direct_triggers=4'h8;direct_notes[21+:7]=91;direct_gains[36+:12]=1234;direct_timbres[9+:3]=3;#1;
  check(gates==4'h8&&triggers==4'h8&&notes[21+:7]==91&&gains[36+:12]==1234&&timbres[9+:3]==3,"all four live voice fields survive source mux");
  @(negedge clk);muted=1;#1;check(gates==0&&gains==0&&triggers==0,"mute suppresses every live voice");muted=0;transition_mute=1;#1;check(gates==0,"mode transition mute");transition_mute=0;
  reset_all;mode=2;timbre_select=2;
  @(negedge clk);start_score=1;@(negedge clk);start_score=0;gap;
  check(playing&&gates[0]&&notes[6:0]==62&&gains[11:0]==3200&&timbres[2:0]==2,"real score first note and onset timbre");
  timbre_select=3;gap;check(timbres[2:0]==2,"sustained score note retains onset timbre");
  cmd(1,0);for(j=0;j<40;j=j+1)store(j);
  cmd(0,1);store(40);
  direct_gates=4'hf;mode=1;
  replay_fixture(41);
  for(p=1;p<=3;p=p+1)begin
   reset_all;pattern_mode=p;use_pattern=1;gap;
   select_note(64);select_note(60);select_note(67);select_note(72);
   if(p!=2)begin select_note(76);select_note(81);select_note(84);end
   check(p_count==((p==2)?4:7),"real pattern selection matches compact chord/full sequential scope");
   cmd(1,0);store(0);
   @(negedge clk);p_start=1;@(negedge clk);p_start=0;gap;
   for(j=1;j<40;j=j+1)store(j);
   cmd(0,1);store(40);
   @(negedge clk);p_cancel=1;@(negedge clk);p_cancel=0;
   replay_fixture(41);
  end
  $display("FINAL_RECORD_SOURCES_PASS checks=%0d",checks);$finish;
 end
 initial begin #10000000;$display("FINAL_RECORD_SOURCES_FAIL timeout");$fatal(1);end
endmodule

