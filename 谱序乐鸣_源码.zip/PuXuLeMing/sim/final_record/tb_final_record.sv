`timescale 1ns/1ps
module tb_final_record;
 reg clk=0;always #5 clk=~clk;
 reg rst=1,sample_tick=0,record_toggle=0,replay_toggle=0,clear=0,panic=0;
 reg [3:0] in_gates=0,in_triggers=0;
 reg [27:0] in_notes=0;reg [47:0] in_gains=0;reg [11:0] in_timbres=0;
 reg [18:0] in_ratio=65536;reg [6:0] in_mod_depth=0;reg [31:0] in_synth_config=32'h48822;
 wire [3:0] out_gates,out_triggers;wire [27:0]out_notes;wire [47:0]out_gains;wire [11:0]out_timbres;
 wire [18:0]out_ratio;wire[6:0]out_mod_depth;wire[31:0]out_synth_config;
 wire recording,replaying,full,time_limit,replay_frame_ready;
 wire[12:0]count;wire[31:0]time_samples,duration_samples;
 final_recorder #(.EVENT_CAPACITY(8),.MAX_SAMPLES(8)) dut(.observer_gains(),.*,.preview_rst(1'b0),.preview_gates('0),.preview_notes('0),.preview_gains('0),.preview_timbres('0),.preview_ratio('0),.preview_mod_depth('0),.preview_synth_config('0));
 integer checks=0,i,prep_clocks=0,max_prep_clocks=0;
 always @(posedge clk)begin
  if(replaying&&!replay_frame_ready)prep_clocks<=prep_clocks+1;
  else begin if(prep_clocks>max_prep_clocks)max_prep_clocks<=prep_clocks;prep_clocks<=0;end
 end
 task check(input bit condition,input [600:0]why);begin
  checks=checks+1;if(!condition)begin $display("FINAL_RECORD_FAIL %0s",why);$fatal(1);end
 end endtask
 task gap;begin repeat(140)@(posedge clk);#1;end endtask
 task step;begin @(negedge clk);sample_tick=1;@(posedge clk);#1;@(negedge clk);sample_tick=0;gap;end endtask
 task command(input bit rec,input bit rep);begin
  @(negedge clk);record_toggle=rec;replay_toggle=rep;
  @(negedge clk);record_toggle=0;replay_toggle=0;
 end endtask
 task reset_all;begin
  @(negedge clk);rst=1;sample_tick=0;record_toggle=0;replay_toggle=0;clear=0;panic=0;
  in_gates=0;in_triggers=0;in_notes=0;in_gains=0;in_timbres=0;in_ratio=65536;in_mod_depth=0;in_synth_config=32'h48822;
  repeat(3)@(posedge clk);@(negedge clk);rst=0;gap;
 end endtask
 task pulse_trigger(input [3:0]mask);begin @(negedge clk);in_triggers=mask;@(negedge clk);in_triggers=0;end endtask
 task replay_check(input[3:0]g,input[3:0]tr,input[6:0]note0,input[11:0]gain0,input[2:0]tim0,input[18:0]ratio,input[6:0]md,input[31:0]cfg);begin
  check(replaying&&replay_frame_ready,"replay frame ready before boundary");
  check(out_gates==g&&out_notes[6:0]==note0&&out_gains[11:0]==gain0&&out_timbres[2:0]==tim0,"replay expanded sounding voice controls");
  check(out_ratio==ratio&&out_mod_depth==md&&out_synth_config==cfg,"replay bend modulation ADSR FX atomically");
  check(out_triggers==0,"replay triggers do not remain high between samples");
  @(negedge clk);sample_tick=1;#1;check(out_triggers==tr,"exact retrigger pulse at sample boundary");
  @(posedge clk);#1;@(negedge clk);sample_tick=0;gap;
 end endtask
 initial begin
  reset_all;
  // Break caught: recording state wrongly depends on live/performance mode.
  in_gates=1;in_notes[6:0]=60;in_gains[11:0]=100;in_timbres[2:0]=1;
  command(1,0);pulse_trigger(1);step;
  check(recording&&!replaying,"record starts independently of performance mode");
  check(out_gates==1&&out_gains[11:0]==100,"live pass never backpressures while committing");
  in_gains[11:0]=200;in_ratio=70000;in_mod_depth=3;in_synth_config=32'h412345;step;
  in_notes[6:0]=67;in_timbres[2:0]=3;pulse_trigger(1);step;
  // Final accepted transition occurs on the exact Record->Replay boundary.
  in_gates=2;in_notes[13:7]=72;in_gains[23:12]=333;in_timbres[5:3]=2;
  command(0,1);pulse_trigger(2);step;
  check(!recording&&replaying,"record replay closes before exclusive replay");
  check(duration_samples==3&&count==7,"last boundary committed including note off and song note");
  in_gates=4'hf;in_notes=0;in_gains=0;in_ratio=2;in_mod_depth=99;in_synth_config=0;
  replay_check(1,1,60,100,1,65536,0,32'h48822);
  replay_check(1,0,60,200,1,70000,3,32'h412345);
  replay_check(1,1,67,200,3,70000,3,32'h412345);
  check(out_gates==2&&out_notes[13:7]==72&&out_gains[23:12]==333&&out_timbres[5:3]==2,"last accepted song transition replayed");
  replay_check(2,2,67,200,3,70000,3,32'h412345);
  check(!replaying&&out_gates==0&&out_triggers==0,"natural replay end supplies clean silent frame");
  step;check(out_gates==in_gates,"live source resumes after silent boundary");
  check(count==7,"replay never records itself");
  command(0,1);step;check(replaying,"idle replay starts saved take");
  command(0,1);step;check(!replaying&&out_gates==0,"replaying replay stops with no stuck gate");
  command(0,1);step;command(1,0);step;
  check(recording&&!replaying,"replaying record starts new take");
  command(1,0);step;check(!recording,"record toggle closes and retains new take");
  // Break caught: a four-voice frame is partially written or replayed.
  reset_all;in_gates=4'hf;
  for(i=0;i<4;i=i+1)begin in_notes[i*7+:7]=i+40;in_gains[i*12+:12]=i+100;in_timbres[i*3+:3]=i%4;end
  command(1,0);pulse_trigger(4'hf);step;check(count==5,"four simultaneous voices plus global stored compactly");
  command(0,1);step;
  check(replaying&&replay_frame_ready&&out_gates==4'hf&&out_notes==in_notes&&out_gains==in_gains&&out_timbres==in_timbres,"four simultaneous replay changes coherent");
  @(negedge clk);sample_tick=1;#1;check(out_triggers==4'hf,"all four triggers coherent in one frame");
  @(posedge clk);#1;@(negedge clk);sample_tick=0;gap;
  @(negedge clk);panic=1;@(negedge clk);panic=0;step;
  check(!recording&&!replaying&&out_gates==0&&count==5,"panic silences and retains take");
  @(negedge clk);clear=1;@(negedge clk);clear=0;step;
  check(count==0&&!recording&&!replaying&&out_gates==0,"clear discards and silences");
  // Break caught: overflowing capture stalls live or admits half the chord.
  reset_all;in_gates=4'hf;
  for(i=0;i<4;i=i+1)begin in_notes[i*7+:7]=i+40;in_gains[i*12+:12]=123;end
  command(1,0);step;check(count==5,"overflow setup captured all four");
  in_gains={4{12'd222}};step;
  check(full&&!recording&&count==5,"overflow rejects whole new frame");
  check(out_gains=={4{12'd222}}&&out_gates==in_gates,"overflow never stalls live performance");
  command(0,1);step;check(replaying&&out_gains=={4{12'd123}},"overflow saved take remains replayable");
  // Break caught: timer ends live performance or loses the final frame.
  reset_all;in_gates=1;in_notes[6:0]=60;in_gains[11:0]=500;command(1,0);step;
  repeat(8)step;
  check(time_limit&&!recording&&!full&&duration_samples==7,"bounded take closes at configured sample limit");
  check(out_gates==1&&out_gains[11:0]==500,"time limit does not stop live performance");
  // A take begun with a held live key and no fresh input trigger must
  // still initialize a fresh attack on the first replay frame.
  reset_all;in_gates=1;in_notes[6:0]=60;in_gains[11:0]=500;
  command(1,0);step;command(1,0);step;command(0,1);step;
  check(replaying&&out_gates==1&&replay_frame_ready,"held live first replay frame preserved");
  @(negedge clk);sample_tick=1;#1;check(out_triggers==1,"held live note retriggers first replay frame without live new onset");
  @(posedge clk);#1;@(negedge clk);sample_tick=0;gap;
  check(max_prep_clocks<=22,"four-voice synchronous replay preparation meets declared budget");
  $display("FINAL_RECORD_PASS checks=%0d max_prep_clocks=%0d",checks,max_prep_clocks);$finish;
 end
 initial begin #10000000;$display("FINAL_RECORD_FAIL timeout");$fatal(1);end
endmodule
