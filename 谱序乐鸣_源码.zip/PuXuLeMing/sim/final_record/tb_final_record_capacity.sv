`timescale 1ns/1ps
module tb_final_record_capacity;
 reg clk=0;always #5 clk=~clk;
 reg rst=1,sample_tick=0,record_toggle=0,replay_toggle=0,clear=0,panic=0;
 reg[3:0]in_gates=1,in_triggers=0;reg[27:0]in_notes=60;reg[47:0]in_gains=100;
 reg[11:0]in_timbres=0;reg[18:0]in_ratio=262144;reg[6:0]in_mod_depth=0;reg[31:0]in_synth_config=32'h48822;
 wire[3:0]out_gates,out_triggers;wire[27:0]out_notes;wire[47:0]out_gains;wire[11:0]out_timbres;
 wire[18:0]out_ratio;wire[6:0]out_mod_depth;wire[31:0]out_synth_config;
 wire recording,replaying,full,time_limit,replay_frame_ready;wire[12:0]count;wire[31:0]time_samples,duration_samples;
 reg[11:0]export_address=0;wire[95:0]export_word;wire export_ready;wire[31:0]take_id;
 final_recorder dut(.observer_gains(),.*,.preview_rst(1'b0),.preview_gates('0),.preview_notes('0),.preview_gains('0),.preview_timbres('0),.preview_ratio('0),.preview_mod_depth('0),.preview_synth_config('0));
 integer i,checks=0,prep_clocks=0,max_prep_clocks=0;
 always @(posedge clk)begin
  if(replaying&&!replay_frame_ready)prep_clocks<=prep_clocks+1;
  else begin if(prep_clocks>max_prep_clocks)max_prep_clocks<=prep_clocks;prep_clocks<=0;end
 end
 task check(input bit ok,input string why);begin checks=checks+1;if(!ok)begin $display("FINAL_RECORD_CAPACITY_FAIL %s",why);$fatal(1);end end endtask
 task tick;begin
  @(negedge clk);sample_tick=1;@(posedge clk);#1;@(negedge clk);sample_tick=0;repeat(1022)@(posedge clk);#1;
 end endtask
 task cmd(input bit rec,input bit rep);begin @(negedge clk);record_toggle=rec;replay_toggle=rep;@(negedge clk);record_toggle=0;replay_toggle=0;end endtask
 initial begin
  repeat(3)@(posedge clk);@(negedge clk);rst=0;
  cmd(1,0);tick;check(count==2,"frame zero voice and global");
  for(i=0;i<4094;i=i+1)begin
   @(negedge clk);in_triggers=1;in_gains[11:0]=(i==4093)?1111:100;
   @(negedge clk);in_triggers=0;tick;
   check(recording&&count==i+3,"each retrigger retained through actual 4096-event capacity");
  end
  check(count==4096&&!full,"13-bit status represents full valid storage");
  @(negedge clk);in_triggers=1;@(negedge clk);in_triggers=0;tick;
  check(full&&!recording&&count==4096&&duration_samples==4094,"capacity+1 automatically closes without overwriting last event");
  check(export_ready,"full take export ready");
  export_address=4095;repeat(3)@(negedge clk);
  check(export_word==dut.event_ram[4095]&&export_word[47:36]==1111,"export last physical RAM address without 12-bit count truncation");
  export_address=0;repeat(3)@(negedge clk);check(export_word==dut.event_ram[0],"export first address");
  cmd(0,1);tick;
  for(i=0;i<4095;i=i+1)begin
   check(replaying&&replay_frame_ready&&out_gates==1&&out_notes[6:0]==60,"4096 stored events replay within real sample deadline");
   check(out_gains[11:0]==((i==4094)?1111:100),"last physical RAM address retains final accepted gain");
   @(negedge clk);sample_tick=1;#1;check(out_triggers==1,"frame-zero onset and every stored retrigger reproduced exactly once");
   @(posedge clk);#1;@(negedge clk);sample_tick=0;repeat(1022)@(posedge clk);#1;
  end
  check(!replaying&&out_gates==0,"full-capacity take ends without stuck gate");
  check(max_prep_clocks<=22,"synchronous compressed event preparation within declared clock budget");
  $display("FINAL_RECORD_CAPACITY_PASS checks=%0d max_prep_clocks=%0d",checks,max_prep_clocks);$finish;
 end
 initial begin #1000000000;$display("FINAL_RECORD_CAPACITY_FAIL timeout");$fatal(1);end
endmodule

