`timescale 1ns/1ps
module tb_final_patterns;
 reg clk=0;always #5 clk=~clk;
 reg rst=1,sample_tick=0,cancel=0,start=0,event_valid=0;
 reg[1:0]pattern_mode=2;reg[31:0]event_data=0;
 wire[6:0]selected;wire[48:0]selected_notes;wire[83:0]selected_gains;
 wire[3:0]gates,triggers;wire[27:0]notes;wire[47:0]gains;
 wire busy,full;wire[2:0]count;
 final_patterns #(.SAMPLE_HZ(20),.STRUM_SAMPLES(4),.ARP_SAMPLES(10),.HOLD_SAMPLES(12)) dut(.*,.full_touch_mode(2'd0),.full_wifi_mode(2'd0),.full_owner(1'b0),.full_touch_enabled(1'b0),.full_note_request(1'b0),.full_base_cancel(1'b0));
 integer checks=0,i,j,p,trial,temp,candidate,pitches[0:6];reg candidate_used;
 reg[3:0]last_triggers;reg[127:0]seen;
 task check(input bit ok,input string why);begin checks=checks+1;if(!ok)begin $display("FINAL_PATTERNS_FAIL %s time=%0t",why,$time);$fatal(1);end end endtask
 task cycles(input integer n);repeat(n)begin @(posedge clk);#1;end endtask
 task ev(input integer pitch,input integer velocity,input bit touch);begin
  @(negedge clk);event_data={7'd0,touch,1'b0,velocity[6:0],1'b0,pitch[6:0],8'h90};event_valid=1;
  cycles(1);@(negedge clk);event_valid=0;cycles(2);
 end endtask
 task tick;begin
  @(negedge clk);sample_tick=1;cycles(1);last_triggers=triggers;
  for(integer z=0;z<4;z=z+1)if(triggers[z])seen[notes[z*7+:7]]=1;
  check((triggers&~gates)==0,"trigger subset of gates");
  for(integer z=0;z<4;z=z+1)begin
   check(gains[z*12+:12]<=3200,"gain capped100");
   if(!gates[z])check(gains[z*12+:12]==0,"inactive compact slot has zero gain");
  end
  @(negedge clk);sample_tick=0;cycles(60);
 end endtask
 task mode(input[1:0]m);begin @(negedge clk);pattern_mode=m;cycles(3);end endtask
 task reset_all(input[1:0]m);begin
  @(negedge clk);rst=1;sample_tick=0;cancel=0;start=0;event_valid=0;pattern_mode=m;
  cycles(2);@(negedge clk);rst=0;cycles(3);seen=0;
 end endtask
 task launch;begin
  seen=0;@(negedge clk);start=1;cycles(1);@(negedge clk);start=0;cycles(60);
  check(gates==0&&gains==0,"launch clears output before complete sample");
  tick;check(gates==0,"first sample clear");tick;check(busy&&gates!=0,"second sample begins sorted snapshot");
 end endtask
 task silent;check(!busy&&gates==0&&gains==0&&triggers==0,"pattern ends without stuck slots");endtask
 initial begin
  reset_all(2);ev(64,127,0);ev(60,1,1);ev(72,80,0);ev(67,90,0);
  check(count==4&&gates==0,"four chord notes selected silently");
  ev(75,100,0);check(full&&count==4&&selected[4]==0,"fifth chord note rejected without stealing");
  launch;check(gates==15&&last_triggers==15,"four chord onsets simultaneous");
  check(notes[6:0]==60&&notes[13:7]==64&&notes[20:14]==67&&notes[27:21]==72,"chord compact slots sorted by actual pitch");
  check(gains[11:0]==3200&&gains[23:12]==3200&&gains[35:24]==2880&&gains[47:36]==2560,"touch and cap gain follow pitches");
  repeat(12)tick;silent;
  ev(64,100,0);ev(75,100,0);check(count==4&&selected_notes[6:0]==75,"chord existing toggles and freed slot reused");
  for(trial=0;trial<12;trial=trial+1)begin
   reset_all(1);
   for(i=0;i<7;i=i+1)begin pitches[i]=(i*17+trial*23)%128;ev(pitches[i],i*19+1,0);end
   check(count==7,"sequential modes retain all seven selected pitches");
   candidate=0;candidate_used=1;
   while(candidate_used)begin
    candidate_used=0;for(i=0;i<7;i=i+1)if(pitches[i]==candidate)candidate_used=1;
    if(candidate_used)candidate=candidate+1;
   end
   ev(candidate,100,0); // Choose a note absent from this trial's set.
   check(full&&count==7,"sequential eighth selection rejected");
   for(i=0;i<7;i=i+1)for(j=i+1;j<7;j=j+1)if(pitches[i]>pitches[j])begin temp=pitches[i];pitches[i]=pitches[j];pitches[j]=temp;end
   launch;check(gates==1&&notes[6:0]==pitches[0]&&last_triggers==1,"strum first onset in slot0");
   for(i=1;i<7;i=i+1)begin
    for(j=1;j<4;j=j+1)begin tick;check(last_triggers==0,"strum interval no extra onset");end
    tick;check(last_triggers==(4'b0001<<(i%4)),"strum onset rotates four slots");
    check(notes[(i%4)*7+:7]==pitches[i],"strum every pitch has exact compact note");
    check(gates==((i<4)?((1<<(i+1))-1):15),"strum global gate count limited to four");
    if(i>=4)check(notes[(i%4)*7+:7]!=pitches[i-4],"fifth onward reclaims oldest pattern slot");
   end
   for(i=0;i<7;i=i+1)check(seen[pitches[i]],"all seven strum selections triggered");
   repeat(12)tick;silent;
   mode(3);launch;
   for(i=0;i<7;i=i+1)begin
    check(last_triggers==(4'b0001<<(i%4))&&notes[(i%4)*7+:7]==pitches[i],"arp visits every sorted pitch in compact slot");
    for(j=1;j<10;j=j+1)begin tick;check(last_triggers==0,"arp no repeated interval trigger");if(j>=8)check(gates==0,"arp final20percent gated off");end
    tick;
   end
   for(i=0;i<7;i=i+1)check(seen[pitches[i]],"all seven arp selections triggered");silent;
   mode(2);check(count==4,"entering chord trims retained seven selection positions to four");launch;check(gates==15,"trimmed chord launches exactly four");
   @(negedge clk);cancel=1;start=1;event_valid=1;cycles(1);@(negedge clk);cancel=0;start=0;event_valid=0;cycles(3);
   silent;check(count==4,"cancel wins and retains chord selection");
  end
  reset_all(1);ev(48,100,0);ev(60,100,0);ev(72,100,0);ev(84,100,0);ev(96,100,0);
  ev(60,100,0);check(count==4&&!selected[1],"sparse selected slot removed");launch;
  check(notes[6:0]==48,"sparse sequence starts lowest");repeat(4)tick;check(notes[13:7]==72,"sparse sequence skips hole");
  @(negedge clk);event_data=32'h00ffffff;event_valid=1;cycles(1);@(negedge clk);event_valid=0;cycles(3);silent;check(count==4,"disconnect retains selection");
  $display("FINAL_PATTERNS_PASS checks=%0d",checks);$finish;
 end
 initial begin #100000000;$display("FINAL_PATTERNS_FAIL timeout");$fatal(1);end
endmodule
