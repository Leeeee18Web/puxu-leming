`timescale 1ns/1ps
module tb_final_record_held_audio;
 reg clk=0;always #5 clk=~clk;
 reg rst=1,record_toggle=0,replay_toggle=0,clear=0,panic=0;
 reg [3:0]in_gates=0,in_triggers=0;reg[27:0]in_notes=60;reg[47:0]in_gains=1800;reg[11:0]in_timbres=0;
 wire[18:0]in_ratio=262144;wire[6:0]in_mod_depth=0;wire[31:0]in_synth_config=32'h48822;
 wire[3:0]out_gates,out_triggers;wire[27:0]out_notes;wire[47:0]out_gains;wire[11:0]out_timbres;
 wire[18:0]out_ratio;wire[6:0]out_mod_depth;wire[31:0]out_synth_config;
 wire recording,replaying,full,time_limit,replay_frame_ready;wire[12:0]count;wire[31:0]time_samples,duration_samples;
 wire sample_tick;wire signed[15:0]pcm;wire[3:0]active;wire[95:0]monitor_steps;wire[63:0]monitor_envelopes;wire deadline_error,clip_active;
 final_recorder rec(.export_address(12'd0),.export_word(),.export_ready(),.take_id(),.observer_gains(),.*,.preview_rst(1'b0),.preview_gates('0),.preview_notes('0),.preview_gains('0),.preview_timbres('0),.preview_ratio('0),.preview_mod_depth('0),.preview_synth_config('0));
 final_audio audio(.model_reset(12'd0),.pcm_positive(),.clk(clk),.rst(rst),.gates(out_gates),.triggers(out_triggers),.notes(out_notes),.gains(out_gains),.timbres(out_timbres),.ratio(out_ratio),.mod_depth(out_mod_depth),.synth_config(out_synth_config),.sample_tick(sample_tick),.pcm(pcm),.active(active),.monitor_steps(monitor_steps),.monitor_envelopes(monitor_envelopes),.deadline_error(deadline_error),.clip_active(clip_active),.hp_bck(),.hp_ws(),.hp_din(),.i2s_bck(),.i2s_ws(),.i2s_sd());
 integer sample_count=0,replay_captures=0,replay_zero_captures=0,replay_trigger_captures=0,replay_voice_retriggers=0;
 reg[23:0]osc_before,osc_after;
 always @(posedge clk)begin
  if(!rst&&sample_tick)begin
   sample_count=sample_count+1;
   if(replaying&&replay_frame_ready)begin
    replay_captures=replay_captures+1;
    if(!out_gates[0])replay_zero_captures=replay_zero_captures+1;
    if(out_triggers[0])replay_trigger_captures=replay_trigger_captures+1;
   end
  end
  if(!rst&&replaying&&audio.physical.slot[0].ep.render_tick&&audio.physical.slot[0].ep.state==0&&audio.physical.slot[0].ep.trigger)
   replay_voice_retriggers=replay_voice_retriggers+1;
 end
 task frame;begin @(posedge clk);while(!sample_tick)@(posedge clk);repeat(600)@(posedge clk);#1;end endtask
 task cmd(input bit rr,input bit pp);begin @(negedge clk);record_toggle=rr;replay_toggle=pp;@(negedge clk);record_toggle=0;replay_toggle=0;end endtask
 initial begin
  repeat(5)@(posedge clk);@(negedge clk);rst=0;in_gates=1;in_triggers=1;@(negedge clk);in_triggers=0;
  repeat(512)frame;
  cmd(1,0);frame;if(!recording)$fatal(1,"setup recording");repeat(16)frame;
  cmd(1,0);frame;if(recording)$fatal(1,"setup stop");repeat(16)frame;
  osc_before=audio.physical.slot[0].ep.x[0];
  cmd(0,1);frame;if(!replaying||!replay_frame_ready)$fatal(1,"setup replay");repeat(3)frame;
  osc_after=audio.physical.slot[0].ep.x[0];
  $display("HELD_REPLAY_OBSERVATION captures=%0d silent_captures=%0d input_triggers=%0d voice_retriggers=%0d osc_before=%h osc_after=%h frame_gate=%b frame_trigger=%b",replay_captures,replay_zero_captures,replay_trigger_captures,replay_voice_retriggers,osc_before,osc_after,audio.frame_gates[0],audio.frame_triggers[0]);
  if(replay_voice_retriggers!=1||replay_trigger_captures!=1||replay_zero_captures!=0)$fatal(1,"HELD_REPLAY_FAIL frame zero must initialize one fresh attack without a muted interval");
  $display("HELD_REPLAY_PASS");$finish;
 end
 initial begin #10000000;$fatal(1,"timeout");end
endmodule

