`timescale 1ns/1ps
module tb_final_ingress_audio;
 reg clk=0;always #5 clk=~clk;
 reg rst=1,record_toggle=0,replay_toggle=0,clear=0,panic=0;
 reg[3:0]raw_gates=0,raw_triggers=0;reg[27:0]raw_notes=60;reg[47:0]raw_gains=1800;reg[11:0]raw_timbres=0;
 reg[18:0]raw_ratio=262144;reg[6:0]raw_mod=0;reg[31:0]raw_config=32'h48822;
 wire[3:0]in_gates,in_triggers;wire[27:0]in_notes;wire[47:0]in_gains;wire[11:0]in_timbres;wire[18:0]in_ratio;wire[6:0]in_mod_depth;wire[31:0]in_synth_config;
 final_sound_pipe pipe(.clk(clk),.rst(rst),.in_gates(raw_gates),.in_triggers(raw_triggers),.in_notes(raw_notes),.in_gains(raw_gains),.in_timbres(raw_timbres),.in_ratio(raw_ratio),.in_mod(raw_mod),.in_config(raw_config),.gates(in_gates),.triggers(in_triggers),.notes(in_notes),.gains(in_gains),.timbres(in_timbres),.ratio(in_ratio),.mod_depth(in_mod_depth),.config_word(in_synth_config));
 wire[3:0]out_gates,out_triggers;wire[27:0]out_notes;wire[47:0]out_gains;wire[11:0]out_timbres;
 wire[18:0]out_ratio;wire[6:0]out_mod_depth;wire[31:0]out_synth_config;
 wire recording,replaying,full,time_limit,replay_frame_ready;wire[12:0]count;wire[31:0]time_samples,duration_samples;
 wire sample_tick;wire signed[15:0]pcm;wire[3:0]active;wire[95:0]monitor_steps;wire[63:0]monitor_envelopes;wire deadline_error,clip_active;
 final_recorder rec(.observer_gains(),.*,.preview_rst(1'b0),.preview_gates('0),.preview_notes('0),.preview_gains('0),.preview_timbres('0),.preview_ratio('0),.preview_mod_depth('0),.preview_synth_config('0));
 final_audio audio(.clk(clk),.rst(rst),.gates(out_gates),.triggers(out_triggers),.notes(out_notes),.gains(out_gains),.timbres(out_timbres),.ratio(out_ratio),.mod_depth(out_mod_depth),.synth_config(out_synth_config),.sample_tick(sample_tick),.pcm(pcm),.active(active),.monitor_steps(monitor_steps),.monitor_envelopes(monitor_envelopes),.deadline_error(deadline_error),.clip_active(clip_active),.hp_bck(),.hp_ws(),.hp_din(),.i2s_bck(),.i2s_ws(),.i2s_sd());
 integer pipe_checks=0,frame_checks=0,capture_checks=0,boundaries=0,replay_last_seen=0;reg[153:0]expect_pipe;reg[114:0]expect_frame;reg[153:0]expect_capture;reg check_capture;
 always @(posedge clk)begin
  expect_pipe=rst?{4'd0,4'd0,28'd0,48'd0,12'd0,19'd262144,7'd0,32'd0}:{raw_gates,raw_triggers,raw_notes,raw_gains,raw_timbres,raw_ratio,raw_mod,raw_config};
  if(!rst&&sample_tick)begin
   if(replaying&&replay_frame_ready&&out_notes[6:0]==67&&out_timbres[2:0]==0&&out_gains[11:0]==1800)replay_last_seen=replay_last_seen+1;
   expect_frame={out_gates,out_notes,out_gains,out_timbres,out_ratio,out_triggers|audio.pending_triggers};
   check_capture=recording&&!replaying&&!clear&&!panic;
   expect_capture={in_gates,in_triggers|rec.pending_triggers,in_notes,in_gains,in_timbres,in_ratio,in_mod_depth,in_synth_config};
  end else check_capture=0;
  #1;
  if({in_gates,in_triggers,in_notes,in_gains,in_timbres,in_ratio,in_mod_depth,in_synth_config}!==expect_pipe)$fatal(1,"INGRESS_PIPE_ATOMIC_FAIL");pipe_checks=pipe_checks+1;
  if(!rst&&audio.render_wait==64)begin
   if({audio.frame_gates,audio.frame_notes,audio.frame_gains,audio.frame_timbres,audio.frame_ratio,audio.frame_triggers}!==expect_frame)$fatal(1,"INGRESS_AUDIO_FRAME_FAIL");frame_checks=frame_checks+1;
   if(check_capture)begin
    if({rec.captured_gates,rec.captured_triggers,rec.captured_notes,rec.captured_gains,rec.captured_timbres,rec.captured_ratio,rec.captured_mod,rec.captured_config}!==expect_capture)$fatal(1,"INGRESS_RECORD_FRAME_FAIL");capture_checks=capture_checks+1;
   end
  end
 end
 integer sample_count=0,replay_captures=0,replay_zero_captures=0,replay_trigger_captures=0,replay_voice_retriggers=0;
 reg[23:0]body_before,body_after;
 always @(posedge clk)begin
  if(!rst&&sample_tick)begin
   sample_count=sample_count+1;
   if(replaying&&replay_frame_ready)begin
    replay_captures=replay_captures+1;
    if(!out_gates[0])replay_zero_captures=replay_zero_captures+1;
    if(out_triggers[0])replay_trigger_captures=replay_trigger_captures+1;
   end
  end
  if(!rst&&replaying&&audio.piano.engine.engine_tick&&audio.piano.engine.voices[0].enabled.voice.engine.retrigger)
   replay_voice_retriggers=replay_voice_retriggers+1;
 end
 task frame;begin @(posedge clk);while(!sample_tick)@(posedge clk);repeat(600)@(posedge clk);#1;end endtask
 task cmd(input bit rr,input bit pp);begin @(negedge clk);record_toggle=rr;replay_toggle=pp;@(negedge clk);record_toggle=0;replay_toggle=0;end endtask
 task boundary(input integer offset,input integer nn,input integer tt);reg[6:0]old_note;begin
  old_note=raw_notes[6:0];
  // Locate actual transmitter phase; T is the next consuming sample_tick edge.
  @(negedge clk);while(!(audio.tx.div_count==14&&audio.tx.bck&&audio.tx.slot==0))@(negedge clk);
  if(offset>=0)@(negedge clk);if(offset>0)@(negedge clk);
  raw_notes=nn;raw_timbres=tt;raw_gains=1200+nn;raw_ratio=262144+nn;raw_mod=0;raw_config=32'h48822+nn;raw_triggers=1;
  @(negedge clk);raw_triggers=0;
  if(offset==-1)begin
   // At T the whole new vector has crossed the shared register.
   @(posedge clk);#2;if(audio.frame_notes[6:0]!=nn||audio.frame_timbres[2:0]!=tt)$fatal(1,"BOUNDARY_MINUS_ONE_FAIL");
  end else if(audio.frame_notes[6:0]!=old_note)$fatal(1,"BOUNDARY_ZERO_PLUS_FAIL");
  frame;#2;if(audio.frame_notes[6:0]!=nn||audio.frame_timbres[2:0]!=tt)$fatal(1,"BOUNDARY_NEXT_FRAME_FAIL");boundaries=boundaries+1;
 end endtask
 initial begin
  repeat(5)@(posedge clk);@(negedge clk);rst=0;
  raw_gates=4'hf;raw_triggers=4'ha;raw_notes={7'd99,7'd88,7'd77,7'd66};raw_gains=48'habcdef123456;raw_timbres={3'd3,3'd2,3'd1,3'd0};raw_ratio=19'h67abc;raw_mod=7'h67;raw_config=32'h89abcdef;
  @(negedge clk);raw_gates=4'h5;raw_triggers=4'h5;raw_notes=~raw_notes;raw_gains=~raw_gains;raw_timbres={3'd0,3'd1,3'd2,3'd3};raw_ratio=~raw_ratio;raw_mod=~raw_mod;raw_config=~raw_config;
  @(negedge clk);raw_gates=1;raw_triggers=1;raw_notes=60;raw_gains=1800;raw_timbres=0;raw_ratio=262144;raw_mod=0;raw_config=32'h48822;
  @(negedge clk);raw_triggers=0;
  repeat(3)frame;cmd(1,0);frame;if(!recording)$fatal(1,"setup record");
  boundary(-1,61,1);boundary(0,62,2);boundary(1,63,3);
  // Final accepted change and Replay command at the same sample boundary.
  @(negedge clk);while(!(audio.tx.div_count==14&&audio.tx.bck&&audio.tx.slot==0))@(negedge clk);
  raw_notes=67;raw_timbres=0;raw_gains=1800;raw_ratio=262144;raw_config=32'h48822;raw_triggers=1;
  @(negedge clk);raw_triggers=0;replay_toggle=1;@(negedge clk);replay_toggle=0;
  repeat(14)frame;
  if(replay_last_seen==0)$fatal(1,"LAST_ACCEPTED_AUDIO_FRAME_FAIL");
  if(rec.replay_notes[6:0]!=67||rec.replay_timbres[2:0]!=0||rec.replay_gains[11:0]!=1800)$fatal(1,"LAST_ACCEPTED_CHANGE_FAIL");
  // Reset for held-first-frame actual voice attack regression through the pipe.
  @(negedge clk);rst=1;raw_gates=0;repeat(5)@(negedge clk);rst=0;raw_gates=1;raw_notes=60;raw_gains=1800;raw_timbres=0;raw_triggers=1;
  @(negedge clk);raw_triggers=0;repeat(24)frame;
  cmd(1,0);frame;repeat(16)frame;cmd(1,0);frame;repeat(16)frame;
  replay_captures=0;replay_zero_captures=0;replay_trigger_captures=0;replay_voice_retriggers=0;
  cmd(0,1);frame;if(!replaying||!replay_frame_ready)$fatal(1,"setup replay");repeat(3)frame;
  if(replay_voice_retriggers!=1||replay_trigger_captures!=1||replay_zero_captures!=0)$fatal(1,"HELD_REPLAY_FAIL");
  cmd(0,1);frame;if(replaying)$fatal(1,"CANCEL_STATE_FAIL");frame;if(audio.frame_gates!=0||audio.frame_triggers!=0)$fatal(1,"CANCEL_MUTE_FAIL");
  // Source releases during the cancellation mute frame: no pending ghost note.
  @(negedge clk);raw_gates=0;raw_triggers=0;repeat(3)frame;
  if(audio.frame_gates!=0||audio.frame_triggers!=0||audio.pending_triggers!=0)$fatal(1,"CANCEL_GHOST_FAIL");
  $display("INGRESS_PASS pipe_checks=%0d frame_checks=%0d capture_checks=%0d boundaries=%0d held_voice_retriggers=%0d held_trigger_frames=%0d held_silent_frames=%0d last_accepted_note=%0d replay_last_frames=%0d",pipe_checks,frame_checks,capture_checks,boundaries,replay_voice_retriggers,replay_trigger_captures,replay_zero_captures,67,replay_last_seen);$finish;
 end
 initial begin #10000000;$fatal(1,"timeout");end
endmodule

