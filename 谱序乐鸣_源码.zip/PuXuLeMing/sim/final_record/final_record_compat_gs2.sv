`timescale 1ns/1ps
module final_record_compat_gs2;
 reg clk=0,rst=1,rx=1;always #10 clk=~clk;
 reg playable=1,muted=0;reg[1:0]mode=0,pattern_mode=0;
 wire tx,event_valid;wire[31:0]event_data;
 p8_gesture_link dut(.clk(clk),.rst(rst),.rx(rx),.tx(tx),.event_valid(event_valid),.event_data(event_data),.event_ready(1'b1),.clear_notes(1'b0),.playable(playable),.muted(muted),.mode(mode),.pattern_mode(pattern_mode),.page(3'd5),.gates(7'd1),.last_note(7'd64));
 reg[7:0]stimulus[0:179];string outdir;integer fd=0,checks=0,events=0,j;
 reg[31:0]observed[0:15];
 always @(posedge clk)if(!rst&&event_valid)begin observed[events]=event_data;events=events+1;end
 task check(input bit ok,input string why);begin checks=checks+1;if(!ok)begin $display("FINAL_COMPAT_GS2_FAIL %s",why);$fatal(1);end end endtask
 task send_byte(input[7:0]b);integer k;begin
  @(negedge clk);rx=0;repeat(434)@(negedge clk);
  for(k=0;k<8;k=k+1)begin rx=b[k];repeat(434)@(negedge clk);end
  rx=1;repeat(434)@(negedge clk);
 end endtask
 task command(input integer n);integer k;begin
  for(k=0;k<18;k=k+1)send_byte(stimulus[n*18+k]);
  repeat(170000)@(negedge clk);
 end endtask
 initial begin:read_uart
  reg[7:0]b;integer k;wait(fd!=0);
  forever begin
   @(negedge tx);#13020;
   for(k=0;k<8;k=k+1)begin b[k]=tx;#8680;end
   check(tx===1'b1,"115200 UART stop bit");$fdisplay(fd,"%02h",b);$fflush(fd);
  end
 end
 initial begin
  if(!$value$plusargs("OUTDIR=%s",outdir))$fatal(1,"OUTDIR required");
  $readmemh({outdir,"/gs2_stimulus.hex"},stimulus);fd=$fopen({outdir,"/gs2_uart_reply.hex"},"w");
  repeat(10)@(negedge clk);rst=0;
  command(0);check(events==0,"golden handshake produces no note");
  command(1);check(events==1&&observed[0]==32'h0164409f,"exact note3 MIDI64 and source ownership");
  command(2);check(events==1,"held heartbeat does not retrigger");
  command(3);check(events==3&&observed[1]==32'h0100408f&&observed[2]==32'h0164439f,"note change old-off then new-on");
  command(4);check(events==4&&observed[3]==32'h0100438f,"explicit release");
  command(5);check(events==4,"invalid CRC cannot control notes");
  command(6);check(events==4,"wrong Studio magic cannot control notes");
  command(7);check(events==4,"undefined gesture8 rejected");
  playable=0;muted=1;mode=2;pattern_mode=2;
  command(8);check(events==4,"blocked source cannot inject notes");
  playable=1;muted=0;mode=1;pattern_mode=0;
  command(9);check(events==4,"final handshake cannot sound");
  $display("FINAL_COMPAT_GS2_PASS checks=%0d events=%0d",checks,events);$fclose(fd);$finish;
 end
 initial begin #100000000;$display("FINAL_COMPAT_GS2_FAIL timeout");$fatal(1);end
endmodule
