`timescale 1ns/1ps
module tb_poly_body_context;
 reg clk=0;always #10 clk=~clk;reg rst=1,en=0,load=0,save=0,tick=0,piano=0;reg[2:0]idx=0;reg signed[21:0]drive=0;
 wire[319:0]snapshot,restore;wire known;wire signed[31:0]s;wire busy;
 poly_context_store #(.WIDTH(320),.COUNT(7),.INDEX_WIDTH(3)) bank(clk,rst,save,idx,snapshot,restore,known);
 poly_model_body dut(.clk(clk),.rst(rst),.tick(tick),.piano(piano),.drive(drive),.radiation(s),.busy(busy),.ctx_enable(en),.ctx_load(load),.ctx_data(restore),.ctx_state(snapshot));
 wire signed[31:0]gs[0:6];wire[6:0]gb;
 genvar k;generate for(k=0;k<7;k=k+1)begin:refvoice
  wire gc=clk&&(rst||(en&&idx==k));
  phys_body_modes refm(.clk(gc),.rst(rst),.tick(tick),.piano(piano),.drive(drive),.radiation(gs[k]),.busy(gb[k]));
 end endgenerate
 integer round,c,checks=0;
 initial begin repeat(4)@(negedge clk);rst=0;
 for(round=0;round<14000;round=round+1)begin
  @(negedge clk);idx=round%7;load=1;en=0;save=0;drive=$signed((round*227)%400000)-200000;piano=idx[0];
  @(negedge clk);load=0;en=1;tick=1;
  for(c=0;c<12;c=c+1)begin
   @(negedge clk);if(s!==gs[idx]||busy!==gb[idx])$fatal(1,"BODY_CONTEXT_FAIL visit%0d row%0d cycle%0d s=%0d/%0d",round,idx,c,s,gs[idx]);checks=checks+1;tick=0;
  end
  if(busy)$fatal(1,"BODY_CONTEXT_SAVE_BUSY");
  en=0;save=1;@(negedge clk);save=0;
 end
 $display("POLY_BODY_CONTEXT_PASS checks=%0d six exact modes/7 voices/idle-boundary scratch reuse",checks);$finish;
 end
 initial begin #10000000;$fatal(1,"BODY_CONTEXT_TIMEOUT");end
endmodule
