`timescale 1ns/1ps
module tb_poly_ep_idle;
 `include "src/poly/poly_model_layout.vh"
 localparam W=`POLY_MODEL_EP_W;reg clk=0;always #10 clk=~clk;
 reg rst=1,en=0,load=0,save=0,tick=0,trig=0,gate=1;reg[2:0]idx=0;
 reg[23:0]step=24'd151500;reg[11:0]gain=12'd2400;
 wire[W-1:0]snapshot,restore;wire known;wire signed[15:0]s;wire[15:0]e;wire active,busy,err;
 poly_context_store #(.WIDTH(W),.COUNT(7),.INDEX_WIDTH(3)) bank(clk,rst,save,idx,snapshot,restore,known);
 poly_model_ep dut(.clk(clk),.rst(rst),.render_tick(tick),.gate(gate),.trigger(trig),.step(step),.gain(gain),.sample(s),.envelope(e),.active(active),.busy(busy),.deadline_error(err),.ctx_enable(en),.ctx_load(load),.ctx_data(restore),.ctx_state(snapshot));
 wire signed[15:0]gs[0:6];wire[15:0]ge[0:6];wire[6:0]ga,gb,gerr;
 genvar k;generate for(k=0;k<7;k=k+1)begin:refvoice
  wire gc=clk&&(rst||(en&&idx==k));
  phys_ep_voice refm(.clk(gc),.rst(rst),.render_tick(tick),.gate(gate),.trigger(trig),.step(step),.gain(gain),.sample(gs[k]),.envelope(ge[k]),.active(ga[k]),.busy(gb[k]),.deadline_error(gerr[k]));
 end endgenerate
 integer round,j,c,checks=0;reg[31:0]rng=32'h51613a27;
 initial begin repeat(4)@(negedge clk);rst=0;
 for(round=0;round<1800;round=round+1)begin
  @(negedge clk);idx=round%7;load=1;en=0;save=0;step=24'd76000+idx*24'd12000;gain=12'd1000+idx*12'd330;gate=round<1400;
  @(negedge clk);load=0;en=1;tick=round<7||!gb[idx];trig=round<7||round%173==0;
  for(c=0;c<128+(round%7);c=c+1)begin
   @(negedge clk);
   if(s!==gs[idx]||e!==ge[idx]||active!==ga[idx]||busy!==gb[idx]||err!==gerr[idx])$fatal(1,"EP_CONTEXT_FAIL visit%0d row%0d cycle%0d s=%0d/%0d",round,idx,c,s,gs[idx]);
   checks=checks+1;tick=0;trig=0;
  end
  if(busy)$fatal(1,"IDLE_SWITCH_WHILE_BUSY");en=0;save=1;@(negedge clk);save=0;
 end
 $display("POLY_EP_IDLE_PASS checks=%0d seven independent voices incl in-flight pause/retrigger/release",checks);$finish;
 end
 initial begin #100000000;$fatal(1,"EP_CONTEXT_TIMEOUT");end
endmodule
