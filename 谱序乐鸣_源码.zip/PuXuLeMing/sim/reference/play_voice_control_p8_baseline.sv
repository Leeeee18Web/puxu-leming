`timescale 1ns/1ps
// Seven ownership tuples and a pairwise LRU matrix avoid stale-off/wrap hazards.
module play_voice_control_p8_baseline(
 input wire clk,rst,sample_tick,event_valid,input wire [31:0] event_data,
 output wire event_ready,input wire panic,centre,
 output reg [6:0] gates=0,output reg [48:0] notes=0,
 output reg [83:0] gains=0,output reg [6:0] triggers=0,
 output reg [18:0] ratio=19'd262144,output reg [6:0] knob=64,
 output reg [6:0] last_note=0,last_velocity=0,output reg [6:0] mod_depth=0
);
 assign event_ready=1'b1;
 reg [6:0] owners=0,held=0;
 reg [3:0] channels[0:6];reg [6:0] newer[0:6];reg [31:0] sustain=0;
 reg [18:0] target=262144;
 wire src=event_data[24];wire [7:0] status=event_data[7:0];
 wire [6:0] d1=event_data[14:8],d2=event_data[22:16];
 wire [4:0] pedal_index={src,status[3:0]};
 wire legal_data=!event_data[15]&&!event_data[23];
 `include "play_bend_lut.vh"
 wire [6:0] match_slots,free_slots,oldest_slots,candidate_slots,selected_slots;
 genvar v;
 generate for(v=0;v<7;v=v+1)begin:slot_choice
  assign match_slots[v]=gates[v]&&owners[v]==src&&channels[v]==status[3:0]&&notes[v*7+:7]==d1;
  assign free_slots[v]=!gates[v];
  // An active row with no newer-than peer is the oldest active slot.
  assign oldest_slots[v]=gates[v]&&!(|(newer[v]&gates));
  if(v==0)assign selected_slots[v]=candidate_slots[v];
  else assign selected_slots[v]=candidate_slots[v]&&!(|candidate_slots[v-1:0]);
 end endgenerate
 assign candidate_slots=(|match_slots)?match_slots:(|free_slots)?free_slots:oldest_slots;
 integer i; reg [6:0] bend_value;
 always @(posedge clk)begin
  triggers<=0;
  if(rst)begin
   gates<=0;notes<=0;gains<=0;owners<=0;held<=0;sustain<=0;
   ratio<=262144;target<=262144;knob<=64;last_note<=0;last_velocity<=0;mod_depth<=0;
   for(i=0;i<7;i=i+1)begin channels[i]<=0;newer[i]<=0;end
  end else begin
   if(sample_tick)begin
    if(target>ratio)ratio<=ratio+((target-ratio<64)?target-ratio:(target-ratio)>>6);
    else if(target<ratio)ratio<=ratio-((ratio-target<64)?ratio-target:(ratio-target)>>6);
   end
   if(panic)begin gates<=0;held<=0;sustain<=0;gains<=0;mod_depth<=0;end
   else if(event_valid)begin
    if(status==8'hff)begin
     // Disconnect always addresses USB; virtual ownership remains intact.
     for(i=0;i<7;i=i+1)if(!owners[i])begin gates[i]<=0;held[i]<=0;gains[i*12+:12]<=0;end
     sustain[15:0]<=0;mod_depth<=0;
    end else if(legal_data)begin
     if(status[7:4]==9&&d2!=0)begin
      // Static onehot writes avoid an age-comparator chain and dynamic slot
      // decode at the gain/ownership register enables. New slot is newest;
      // relative order of every other pair remains untouched across releases.
      for(i=0;i<7;i=i+1)begin
       if(selected_slots[i])begin
        newer[i]<=7'h7f^(7'b1<<i);
        gates[i]<=1;held[i]<=1;owners[i]<=src;channels[i]<=status[3:0];
        notes[i*7+:7]<=d1;gains[i*12+:12]<={d2,5'd0};triggers[i]<=1;
       end else newer[i]<=newer[i]&~selected_slots;
      end
      last_note<=d1;last_velocity<=d2;
     end else if(status[7:4]==8||(status[7:4]==9&&d2==0))begin
      for(i=0;i<7;i=i+1)if(gates[i]&&owners[i]==src&&channels[i]==status[3:0]&&notes[i*7+:7]==d1)begin
       held[i]<=0;if(!sustain[pedal_index])gates[i]<=0;
      end
     end else if(status[7:4]==11)begin
      if(d1==64)begin
       sustain[pedal_index]<=d2>=64;
       if(d2<64)for(i=0;i<7;i=i+1)if(owners[i]==src&&channels[i]==status[3:0]&&!held[i])gates[i]<=0;
      end else if(d1==120||d1==123)begin
       for(i=0;i<7;i=i+1)if(owners[i]==src&&channels[i]==status[3:0])begin
        held[i]<=0;if(d1==120||!sustain[pedal_index])gates[i]<=0;
        if(d1==120)gains[i*12+:12]<=0;
       end
       if(d1==120)sustain[pedal_index]<=0;
      end else if(d1==74)begin knob<=d2;target<=bend_ratio(d2);end
      else if(d1==1)mod_depth<=d2;
     end else if(status[7:4]==12)begin knob<=d1;target<=bend_ratio(d1);end
     else if(status[7:4]==14)begin
      // MSB bins preserve exact MIDI 14-bit endpoints and center.
      bend_value=d2;knob<=bend_value;target<=bend_ratio(bend_value);
     end
    end
   end
   if(centre)begin knob<=64;target<=262144;end
  end
 end
endmodule

