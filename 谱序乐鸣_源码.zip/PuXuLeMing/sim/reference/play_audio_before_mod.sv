`timescale 1ns/1ps
module play_audio_before_mod(input wire clk,rst,input wire [6:0] gates,input wire [48:0] notes,input wire [83:0] gains,input wire [6:0] triggers,input wire [18:0] ratio,output wire sample_tick,output wire signed [15:0] pcm,output wire hp_bck,hp_ws,hp_din,i2s_bck,i2s_ws,i2s_sd,output wire [6:0] active);
 `include "play_note_steps.vh"
 // Snapshot all ownership data on the serial frame boundary. Triggers arriving
 // between frames are retained; each trigger reaches the unchanged voice core.
 reg [6:0] frame_gates=0,frame_triggers=0,pending_triggers=0;
 reg [48:0] frame_notes=0;reg [83:0] frame_gains=0;
 reg [18:0] frame_ratio=262144;
 reg [167:0] event_steps=0;reg [2:0] index=0;reg [1:0] state=0;
 reg [42:0] product=0;
 wire [6:0] hard_mute_mask;
 genvar m;
 generate for(m=0;m<7;m=m+1)begin:urgent_mask
  assign hard_mute_mask[m]=frame_gains[m*12+:12]==0;
 end endgenerate
 always @(posedge clk)begin
  frame_triggers<=0;
  if(rst)begin
   frame_gates<=0;frame_notes<=0;frame_gains<=0;frame_ratio<=262144;
   frame_triggers<=0;pending_triggers<=0;event_steps<=0;index<=0;state<=0;product<=0;
  end else begin
   if(sample_tick)begin
    frame_gates<=gates;frame_notes<=notes;frame_gains<=gains;frame_ratio<=ratio;
    frame_triggers<=pending_triggers|triggers;pending_triggers<=0;index<=0;state<=1;
   end else begin
    pending_triggers<=pending_triggers|triggers;
    case(state)
     1:begin product<=midi_step(frame_notes[index*7+:7])*frame_ratio;state<=2;end
     2:begin
      event_steps[index*24+:24]<=product[41:18];
      if(index==6)state<=0;else begin index<=index+1'b1;state<=1;end
     end
     default:state<=0;
    endcase
   end
  end
 end
 // Existing electricpiano (preset0), gain/envelope/sine banks and both original
 // serializers. EVENT_SONG is only the seven-slot input path, no song player.
 // Shared render launches64 clocks after sample_tick, after the14-clock pitch MAC.
 keyboard_audio #(.SHARED_SONG(1),.EVENT_SONG(1),.DIRECT_PCM(1),.HARD_MUTE(1)) engine(
  .hard_mute_mask(hard_mute_mask),
  .clk(clk),.rst(rst),.running(1'b1),.ready(1'b1),.fault(1'b0),.clear_notes(1'b0),
  .audition_hold(1'b0),.audition_reset(1'b0),.fm_cfg(224'd0),.fx_cfg(416'd0),.fx_panic(1'b0),
  .mod_cfg(192'd0),.cfg(512'd0),.test_mode(2'd0),.mix_cfg(142'd0),.settings(14'd0),
  .song_mode(1'b1),.song_clear(1'b0),.song_gates(4'd0),.song_steps(96'd0),.song_gains(48'd0),
  .event_gates(frame_gates),.event_triggers(frame_triggers),.event_steps(event_steps),.event_gains(frame_gains),
  .gates(7'd0),.pressures(84'd0),.ratio(19'd262144),.voice_active(active),.sample_tick(sample_tick),
  .pcm_out(pcm),.hp_bck(hp_bck),.hp_ws(hp_ws),.hp_din(hp_din),.i2s_bck(i2s_bck),.i2s_ws(i2s_ws),.i2s_sd(i2s_sd),
  .fx_ready(),.fx_nodes(),.fx_delays(),.voice_samples(),.post_voice_samples(),.monitor_steps(),.monitor_envelopes(),
  .modulation_coefficients(),.modulation_flags(),.modulation_gain(),.monitor_phases(),.render_steps(),.render_active()
 );
endmodule
