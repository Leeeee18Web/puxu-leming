`timescale 1ns/1ps
module tb_new_entry;
 reg clk=0,rst=1,touch_update=0,touch_valid=1,touch_down=0;reg[15:0]touch_x=0,touch_y=0;always #10 clk=~clk;
 wire[2:0]page,timbre;wire[31:0]event_data,synth_config;wire event_valid,preview_toggle,timbre_commit;wire[7:0]envelope_choices;integer previews=0,commits=0;
 final_navigation nav(.clk(clk),.rst(rst),.touch_key_base(7'd60),.touch_update(touch_update),.touch_valid(touch_valid),.touch_down(touch_down),.touch_x(touch_x),.touch_y(touch_y),.event_ready(1'b1),.event_valid(event_valid),.event_data(event_data),.page(page),.panic_key(1'b0),.centre_key(1'b0),.preview_busy(1'b0),.timbre(timbre),.synth_config(synth_config),.preview_toggle(preview_toggle),.timbre_commit(timbre_commit),.envelope_choices(envelope_choices),.knob_mode(),.mode(),.base_note(),.centre(),.panic(),.clear_live(),.start_score(),.stop_score(),.muted(),.restart_lesson(),.xy_config(),.spectrum_zoom(),.pattern_mode(),.pattern_start(),.record_toggle(),.replay_toggle(),.transport_stop(),.timbre_open(),.xy_overview());
 always @(posedge clk)begin if(preview_toggle)previews++;if(timbre_commit)commits++;end
 task tap(input integer x,y);begin
  @(negedge clk);touch_x=x;touch_y=y;touch_down=1;touch_update=1;@(negedge clk);touch_update=0;repeat(8)@(negedge clk);
  touch_down=0;touch_update=1;@(negedge clk);touch_update=0;repeat(8)@(negedge clk);
 end endtask
 initial begin
  repeat(4)@(negedge clk);rst=0;tap(160,32);tap(940,96);if(page!=1)$fatal(1,"PIF_STATUS_BADGE_MUST_NOT_NAVIGATE");
  tap(796,96);if(page!=6)$fatal(1,"ENVELOPE_REPLACES_GUIDE_TAB expected6 got%0d",page);
  tap(880,180);if(envelope_choices[1:0]!=3)$fatal(1,"EDIT_ATTACK");
  tap(500,540);if(previews!=1)$fatal(1,"PREVIEW_ENTRY");
  tap(640,96);if(page!=5||timbre!=0||synth_config[15:8]!=8'h95)$fatal(1,"EXIT_CANCEL_PRESERVES_APPLIED_SOUND");
  tap(796,96);tap(910,570);if(timbre!=4||synth_config[15:8]!=8'h97||commits!=1)$fatal(1,"APPLY_CUSTOM_FIFTH");
  $display("NEW_ENTRY_PASS preview%0d apply%0d noGuidePage",previews,commits);$finish;
 end
endmodule
