`timescale 1ns/1ps
module tb_score2_sign_fft;
 reg clk=0,pixel_clk=0;always #5 clk=~clk;always #7 pixel_clk=~pixel_clk;
 reg rst=1,pixel_rstn=0,sample_tick=0,frame_start=0;reg signed[15:0]pcm=0;
 reg[9:0]wa=0;reg[6:0]sa=0;reg[15:0]xa=0;reg[31:0]rng=32'h9374abcd;integer cycle=0,checks=0,published=0;
 wire[47:0]w,rw;wire[7:0]s,rs,p,rp;wire xy,rxy,v,rv;wire[12:0]m,rm;
 audio_visualizer #(.REGISTERED_PCM_POSITIVE(1)) dut(.clk(clk),.rst(rst),.sample_tick(sample_tick),.pcm(pcm),.pcm_positive($signed(pcm)>0),.component_a(16'sd0),.component_b(16'sd0),.note_index(6'd12),.current_note(3'd0),.next_note(3'd0),.playing(1'b1),.pixel_clk(pixel_clk),.pixel_rstn(pixel_rstn),.frame_start(frame_start),.wave_addr(wa),.spectrum_addr(sa),.xy_addr(xa),.wave_data(w),.spectrum_data(s),.xy_data(xy),.valid(v),.meta(m),.spectrum_peak(p));
 audio_visualizer_sign_ref reference(.clk(clk),.rst(rst),.sample_tick(sample_tick),.pcm(pcm),.component_a(16'sd0),.component_b(16'sd0),.note_index(6'd12),.current_note(3'd0),.next_note(3'd0),.playing(1'b1),.pixel_clk(pixel_clk),.pixel_rstn(pixel_rstn),.frame_start(frame_start),.wave_addr(wa),.spectrum_addr(sa),.xy_addr(xa),.wave_data(rw),.spectrum_data(rs),.xy_data(rxy),.valid(rv),.meta(rm),.spectrum_peak(rp));
 always @(negedge clk)begin #1;
  if({dut.state,dut.capture_index,dut.trigger_wait,dut.trigger_count,dut.publish_toggle,dut.meta_source}!=={reference.state,reference.capture_index,reference.trigger_wait,reference.trigger_count,reference.publish_toggle,reference.meta_source})$fatal(1,"FFT_CONTROL_PHASE");
  checks=checks+1;
 end
 always @(negedge pixel_clk)begin #1;if({w,s,xy,v,m,p}!=={rw,rs,rxy,rv,rm,rp})$fatal(1,"FFT_PIXELS");end
 always @(dut.publish_toggle)if(!rst)published=published+1;
 initial begin
  for(cycle=0;cycle<700000;cycle=cycle+1)begin
   @(negedge clk);rst=cycle<5||(cycle>=200000&&cycle<200003)||(cycle>=400000&&cycle<400002);pixel_rstn=!rst;
   sample_tick=(cycle%16)==0;frame_start=(cycle%311)==0;
   if(sample_tick)begin rng={rng[30:0],rng[31]^rng[21]^rng[1]^rng[0]};pcm=(cycle<100000)?0:$signed(rng[15:0]);end
   wa=cycle[9:0];sa=cycle[6:0];xa=cycle[15:0];
  end
  if(published<3)$fatal(1,"FFT_COVERAGE %d",published);
  $display("SIGN_FFT_EQ_PASS clocks=%0d published=%0d every control and pixel",checks,published);$finish;
 end
endmodule
