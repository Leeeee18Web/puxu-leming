`timescale 1ns/1ps
module tb_play_wave;
 reg clk=0;always #10 clk=~clk;
 reg pixel_clk=0;always #7 pixel_clk=~pixel_clk;
 reg rst=1,pixel_rstn=0,sample_tick=0,frame_start=0;
 reg signed[15:0] pcm=0;reg[9:0] read_addr=0;
 wire signed[15:0] read_data;wire valid;
 play_wave_capture dut(.*);
 integer i,j,checks=0;reg[15:0] expected;
 always @(posedge clk)if(!rst&&sample_tick&&!dut.waiting&&valid&&dut.write_bank==dut.read_bank)
 $fatal(1,"writer overlaps displayed bank");
 task samples(input integer mode);
 begin for(j=0;j<1024;j=j+1) begin
 @(negedge clk);sample_tick=1;
 case(mode)0:pcm=j*61-30000;1:pcm=30000-j*59;default:pcm=j^16'h81a5;endcase
 @(negedge clk);sample_tick=0;
 // First block uses actual Fs=50MHz/1024, not accelerated sample timing.
 if(mode==0)repeat(1022)@(negedge clk);
 end end endtask
 task frame;
 begin repeat(6) @(negedge pixel_clk);frame_start=1;
 @(negedge pixel_clk);frame_start=0;repeat(6) @(negedge clk);end endtask
 task verify(input integer mode);
 begin for(i=0;i<1024;i=i+1) begin
 @(negedge pixel_clk);read_addr=i;@(posedge pixel_clk);#1;
 case(mode)0:expected=i*61-30000;1:expected=30000-i*59;default:expected=i^16'h81a5;endcase
 checks=checks+1;if(read_data!==expected) $fatal(1,"PCM mismatch index %d mode%d got%h expected%h",i,mode,read_data,expected);
 end end endtask
 initial begin
 repeat(4) @(negedge clk);rst=0;pixel_rstn=1;
 samples(0);if(valid) $fatal(1,"visible before frame");frame();if(!valid) $fatal(1,"not valid");verify(0);
 samples(1);verify(0); // complete pending bank cannot replace current frame
 // Additional incoming samples must not corrupt either published bank.
 samples(2);verify(0);frame();verify(1);
 samples(2);verify(1);frame();verify(2);
 @(negedge clk);rst=1;pixel_rstn=0;repeat(4)@(negedge clk);
 if(valid)$fatal(1,"valid survived global reset");rst=0;pixel_rstn=1;
 samples(2);frame();verify(2);
 $display("PASS wave %0d exact signed PCM reads, pending/stable frame banks, async clocks",checks);$finish;
 end
 initial begin #100000000;$fatal(1,"timeout");end
endmodule
