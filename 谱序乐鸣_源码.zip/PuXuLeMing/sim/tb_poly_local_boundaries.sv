`timescale 1ns/1ps
module poly_local_boundary #(parameter PROBE=0)(output reg done=0);
 reg clk=0;always #10 clk=~clk;reg rst=1,start=0;
 poly_voice_worker #(.CONTEXTS(2),.PRECALC_SLOT_GATES(1)) dut(.clk(clk),.rst(rst),.start(start),.gates(2'b01),.triggers(2'b10),.steps({24'd45000,24'd45000}),.gains({12'd2400,12'd2400}),.timbres({3'd1,3'd1}),.model_reset({3{rst}}),.memory_reset(rst),.samples(),.envelopes(),.active(),.busy(),.deadline_error(),.out_valid(),.out_index(),.out_sample(),.control_resetn_early(1'b1));
 reg g,p,e;
 initial begin
  repeat(3)@(negedge clk);rst=0;start=1;@(negedge clk);start=0;
  wait(dut.phase==20);@(negedge clk);
  if(PROBE==0)begin
   g=dut.gate;p=dut.pending;force dut.context_index=1;#1;
   if(dut.gate!==g||dut.pending!==p)$fatal(1,"GATE_PENDING_PHASE0_BOUNDARY_MISSING");
  end else if(PROBE==1)begin
   e=dut.next_enable;force dut.phase=0;#1;
   if(dut.next_enable!==e)$fatal(1,"PHASE_WINDOW_REGISTER_BOUNDARY_MISSING");
  end else begin
   // Structural fault injection only: legal string writes never use reed spill addresses.
   force dut.memory.we_a=1;force dut.memory.wa=2048;force dut.memory.da=20'h12345;
   @(posedge clk);#1;
   if(dut.memory.spill.voice[0].point[0].value===20'h12345)$fatal(1,"SEPARATE_REED_SPILL_BOUNDARY_MISSING");
  end
  $display("POLY_LOCAL_BOUNDARY_PASS probe%0d",PROBE);done=1;
 end
endmodule
module tb_poly_gate_boundary;wire d;poly_local_boundary #(.PROBE(0)) t(d);initial begin wait(d);$finish;end endmodule
module tb_poly_phase_boundary;wire d;poly_local_boundary #(.PROBE(1)) t(d);initial begin wait(d);$finish;end endmodule
module tb_poly_spill_boundary;wire d;poly_local_boundary #(.PROBE(2)) t(d);initial begin wait(d);$finish;end endmodule
