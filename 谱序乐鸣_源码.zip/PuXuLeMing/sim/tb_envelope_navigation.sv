`timescale 1ns/1ps
module tb_envelope_navigation;
 reg clk=0;always #5 clk=~clk;
 reg rst=1,update=0,down=0;reg [15:0]x=0,y=0;
 wire[2:0]page,timbre;wire[7:0]choices;wire[31:0]cfg;wire preview,ev;integer pulses=0,checks=0,r,c;
 final_navigation dut(.touch_key_base(7'd60),.clk(clk),.rst(rst),.touch_update(update),.touch_valid(1'b1),.touch_down(down),.touch_x(x),.touch_y(y),.event_ready(1'b1),.panic_key(1'b0),.centre_key(1'b0),.page(page),.timbre(timbre),.envelope_choices(choices),.preview_toggle(preview),.preview_busy(1'b0),.synth_config(cfg),.event_valid(ev));
 always @(posedge clk)begin #1;if(preview)pulses=pulses+1;end
 task tick;begin @(negedge clk);end endtask
 task touch(input integer ax,ay,pressed);begin x=ax;y=ay;down=pressed;update=1;tick;update=0;tick;end endtask
 task tap(input integer ax,ay);begin touch(ax,ay,1);touch(ax,ay,0);end endtask
 task check(input bit ok,input string name);begin checks=checks+1;if(!ok)$fatal(1,"ENVELOPE_NAV_FAIL %s",name);end endtask
 initial begin
 repeat(4)tick;rst=0;tick;
 check(cfg==32'h00009500&&choices==8'h95,"default config");
 tap(160,32);tap(796,96);check(page==6,"Envelope replaces the removed Guide tab");
 for(r=0;r<4;r=r+1)for(c=0;c<4;c=c+1)begin
 tap(220+196*c,180+64*r);check(choices[r*2+:2]==c,"parameter selection");check(cfg==32'h9500&&timbre==0,"draft isolated from applied sound");end
 touch(450,540,1);repeat(15)tick;check(pulses==1,"audition held exactly once");touch(80,500,1);check(!ev,"audition contact cannot become note");touch(0,0,0);
 tap(900,570);check(timbre==4&&cfg[15:8]==8'hff,"Apply selects custom piano");
 tap(80,570);check(choices==8'h95&&cfg[15:8]==8'hff,"Cancel resets draft only");
 tap(450,540);check(pulses==2,"second audition toggle");
 for(c=0;c<5;c=c+1)begin tap(760,32);tap(850,90+44*c);check(timbre==c,"five timbres");end
 tap(760,32);tap(850,310);check(cfg[1:0]==1&&cfg[15:8]==8'hff,"shifted FX separate from fifth timbre");
 $display("ENVELOPE_NAV_PASS checks=%0d",checks);$finish;end
endmodule
