const assert = require('node:assert/strict');
const test = require('node:test');
const P = require('../web/protocol.js');
function ack(frame, result=0, override={}) {
  const c=P.decode(frame); return P.encode({...c, op:c.op|128, a:result|0x1000, b:12, c:P.IDENTITY,...override});
}
test('PW1 CRC, unsigned args, exact length and corrupt/foreign ACK rejection',()=>{
  const f=P.encode({op:1,seq:65535,session:123,a:0x1000001,b:0x3c7f,c:0});
  assert.equal(f.length,22); assert.deepEqual(P.decode(f),{op:1,seq:65535,session:123,a:0x1000001,b:0x3c7f,c:0});
  f[8]^=1; assert.throws(()=>P.decode(f),/CRC/);
  assert.throws(()=>P.decode(new Uint8Array(21)),/长度/);
});
test('scores use actual sample clock, exact CRC and require balanced bounded polyphony',()=>{
  const s=P.validateScore({version:1,title:'一秒',events:[{ms:0,note:60,on:true,velocity:100},{ms:1000,note:60,on:false}]});
  assert.equal(s.events[1].tick,48828); assert.equal(P.scoreCRC(s.events),P.crc16(new Uint8Array([...P.entryBytes(s.events[0]),...P.entryBytes(s.events[1])])));
  assert.throws(()=>P.validateScore({version:1,events:[{ms:0,note:60,on:true,velocity:1}]}),/释放/);
  assert.throws(()=>P.validateScore({version:1,events:[{ms:0,note:60,on:false}]}),/未按下/);
  assert.throws(()=>P.validateScore({version:1,events:Array.from({length:814},(_,i)=>({ms:i,note:60,on:i%2===0,velocity:i%2?0:90}))}),/512/);
  assert.throws(()=>P.validateScore({version:1,events:[{ms:-1,note:60,on:false}]}),/时间/);
  assert.throws(()=>P.validateScore({version:1,events:[{ms:0,note:128,on:false}]}),/音高/);
  assert.throws(()=>P.validateScore({version:1,events:[...Array.from({length:8},(_,i)=>({ms:0,note:60+i,on:true,velocity:90})),...Array.from({length:8},(_,i)=>({ms:1,note:60+i,on:false}))]}),/7/);
});
test('stop and wait accepts only matching identity/session/seq/op; coalesces LIVE; release priority',async()=>{
  const sent=[]; const q=new P.CommandQueue({session:42,send:f=>sent.push(f),timeout:1000});
  const hello=q.command(0,P.IDENTITY); assert.equal(sent.length,1);
  assert.equal(q.receive(ack(sent[0],0,{session:41})),false);
  assert.equal(q.receive(ack(sent[0],0,{c:0})),false);
  const l1=q.live(1,100,60); const l2=q.live(2,100,60); const release=q.release();
  q.receive(ack(sent[0])); await hello;
  assert.equal(P.decode(sent[1]).op,2); q.receive(ack(sent[1])); await release;
  assert.equal(sent.length,2); await Promise.all([l1,l2]); q.close();
});
test('upload sends BEGIN then sequential entries then CRC COMMIT after every FPGA ACK',async()=>{
  const sent=[]; let q; q=new P.CommandQueue({session:9,send:f=>{sent.push(P.decode(f));setImmediate(()=>q.receive(ack(f,0,P.decode(f).op===12?{b:(P.scoreCRC(s.events)<<16)|s.events.length}:{})));}});
  const s=P.validateScore({version:1,events:[{ms:0,note:60,on:true,velocity:90},{ms:200,note:60,on:false}]});
  await P.uploadScore(q,s); assert.deepEqual(sent.map(x=>x.op),[4,5,5,6,12]); assert.deepEqual(sent.filter(x=>x.op===5).map(x=>x.a),[0,1]); assert.equal(sent[3].a,P.scoreCRC(s.events)); q.close();
});
test('application error rejects command, retry is byte-identical and timeout fails closed',async()=>{
  const sent=[]; let failures=0; const q=new P.CommandQueue({session:12,send:f=>sent.push(f.slice()),timeout:10,retries:1,onFailure:()=>failures++});
  const c=q.command(1,1,90|(60<<8)); q.receive(ack(sent[0],3)); await assert.rejects(c,/模式/);
  const h=q.command(3); await assert.rejects(h,/超时/); assert.deepEqual(sent[1],sent[2]); assert.equal(failures,1);
});
test('sequence wraps; in-flight LIVE is followed by RELEASE, never a stale queued press',async()=>{
  const sent=[];const q=new P.CommandQueue({session:31,send:f=>sent.push(f),timeout:1000});q.seq=65535;
  const l=q.live(1,90,60),next=q.live(2,90,60),r=q.release();q.receive(ack(sent[0]));await l;
  assert.equal(P.decode(sent[0]).seq,65535);assert.equal(P.decode(sent[1]).seq,0);assert.equal(P.decode(sent[1]).op,2);
  q.receive(ack(sent[1]));await r;await next;assert.equal(sent.length,2);q.close();
});
test('interrupted upload never commits; backward time, duplicates and oversized ticks reject',async()=>{
  const sent=[];let q,cancelled=false;q=new P.CommandQueue({session:9,send:f=>{sent.push(P.decode(f));setImmediate(()=>q.receive(ack(f)));}});
  const s=P.validateScore({version:1,events:[{ms:0,note:60,on:true,velocity:80},{ms:20,note:60,on:false}]});
  await assert.rejects(P.uploadScore(q,s,{cancelled:()=>cancelled,onProgress:()=>{cancelled=true;}}),/取消/);assert.deepEqual(sent.map(x=>x.op),[4,5]);q.close();
  assert.throws(()=>P.validateScore({version:1,events:[{ms:2,note:60,on:true,velocity:80},{ms:1,note:60,on:false}]}),/时间/);
  assert.throws(()=>P.validateScore({version:1,events:[{ms:0,note:60,on:true,velocity:80},{ms:1,note:60,on:true,velocity:90}]}),/重复/);
  assert.throws(()=>P.validateScore({version:1,events:[{ms:9e20,note:60,on:false}]}),/时间/);
});
test('performance controls use dedicated PW1 commands',async()=>{
  const sent=[];let q;q=new P.CommandQueue({session:77,send:f=>{sent.push(P.decode(f));setImmediate(()=>q.receive(ack(f)));}});
  await P.setTimbre(q,2);await P.setPattern(q,2);await P.setPattern(q,2,true);await P.setController(q,64,127);
  assert.deepEqual(sent.map(x=>[x.op,x.a,x.b]),[[9,2,0],[10,2,0],[10,2,1],[11,64,127]]);q.close();
});
