"""Portable source build. Never opens Programmer or accesses a board."""
from pathlib import Path
import argparse, datetime, json, os, shutil, subprocess, sys, time
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]

def tool(variable, executable):
    configured=os.environ.get(variable)
    found=Path(configured)/executable if configured else shutil.which(executable)
    if not found or not Path(found).is_file():
        raise SystemExit(f'Set {variable} to the directory containing {executable}, or add it to PATH.')
    return Path(found)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--stage',choices=['firmware','syn','full','esp'],default='full')
    args=parser.parse_args()
    run=ROOT/'build'/args.stage/datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    run.mkdir(parents=True)
    log=run/'build.log'
    (run/'temp').mkdir()
    environment=dict(os.environ,TEMP=str(run/'temp'),TMP=str(run/'temp'),ARDUINO_BUILD_CACHE_PATH=str(run/'cache'))
    started=time.time()
    if args.stage!='esp':
        current=ROOT/'impl/pnr/Final7.fs'
        if current.is_file():shutil.move(current,run/'previous_Final7.fs')
        (ROOT/'Final7.gprj.user').write_text('<UserConfig><Version>1.0</Version><FlowState><Process ID="Synthesis" State="0"/><Process ID="Pnr" State="0"/></FlowState><ResultFileList/></UserConfig>',encoding='utf-8')
        (ROOT/'BUILD_STATUS.json').write_text(json.dumps({'current_sources_built':False,'stage':args.stage,'bitstream':None}),encoding='utf-8')
    def call(command):
        with log.open('ab') as stream:
            stream.write(('\n> '+' '.join(map(str,command))+'\n').encode('utf-8'));stream.flush()
            subprocess.run(list(map(str,command)),cwd=ROOT,env=environment,stdout=stream,stderr=subprocess.STDOUT,check=True)
    if args.stage=='esp':
        cli=tool('ARDUINO_CLI_BIN','arduino-cli.exe')
        call([sys.executable,'-B',ROOT/'tools/build_wifi_web_assets.py'])
        command=[cli,'compile','--fqbn','esp32:esp32:esp32cam','--build-path',run/'objects','--output-dir',run/'output']
        if os.environ.get('ARDUINO_CONFIG'):command+=['--config-file',os.environ['ARDUINO_CONFIG']]
        call([*command,ROOT/'arduino/P8_WiFi_Web'])
    else:
        gcc=tool('RISCV_BIN','riscv-none-elf-gcc.exe')
        flags=['-march=rv32i','-mabi=ilp32','-msmall-data-limit=0','-mno-relax','-Os','-ffreestanding','-fno-builtin','-ffunction-sections','-fdata-sections','-fstack-usage','-fno-stack-protector','-Wall','-Wextra','-Werror','-Ifirmware']
        objects=[]
        for name in ('start.S','hid_touch_parser.c','usb_play.c','runtime.c'):
            obj=run/(Path(name).stem+'.o');call([gcc,*flags,'-c',ROOT/'firmware'/name,'-o',obj]);objects.append(obj)
        elf=run/'firmware.elf'
        call([gcc,'-march=rv32i','-mabi=ilp32','-mno-relax','-nostdlib','-Wl,--gc-sections','-Wl,-T,'+(ROOT/'firmware/baremetal.ld').as_posix(),'-Wl,-Map,'+(run/'firmware.map').as_posix(),*objects,'-lgcc','-o',elf])
        call([gcc.parent/'riscv-none-elf-objcopy.exe','-O','binary',elf,run/'firmware.bin'])
        payload=(run/'firmware.bin').read_bytes()
        if len(payload)>=45056:raise RuntimeError('Firmware exceeds 45056-byte memory')
        words=[int.from_bytes(payload[i:i+4].ljust(4,b'\0'),'little') for i in range(0,len(payload),4)]
        words.extend([0]*(11264-len(words)))
        for name,lo,hi in [('low',0,8192),('high',8192,10240),('tail',10240,11264)]:
            (ROOT/f'src/usb_host/firmware_{name}.hex').write_text(''.join(f'{word:08x}\n' for word in words[lo:hi]),encoding='ascii')
        if args.stage!='firmware':
            call([sys.executable,'-B',ROOT/'tools/generate_poly_models.py','--verify'])
            gowin=tool('GOWIN_BIN','gw_sh.exe')
            config=json.loads((ROOT/'tools/project_config_template.json').read_text(encoding='utf-8'))
            config['INCREMENTAL_PLACE_ONLY']=(ROOT/'implementation/placement_reference.p').as_posix()
            (ROOT/'impl').mkdir(exist_ok=True)
            (ROOT/'impl/Final7_process_config.json').write_text(json.dumps(config,indent=2),encoding='utf-8')
            tcl='set task_dir {'+ROOT.as_posix()+'}\ncd $task_dir\nopen_project [file join $task_dir Final7.gprj]\n'
            for key,value in [('top_module','hub_play_top'),('output_base_name','Final7'),('verilog_std','sysv2017'),('use_cpu_as_gpio','1'),('use_sspi_as_gpio','1'),('vccx','1.8'),('correct_hold_violation','1'),('timing_driven','1'),('place_option','1'),('route_option','0'),('clock_route_order','1'),('replicate_resources','1'),('gen_verilog_sim_netlist','1'),('convert_sdp32_36_to_sdp16_18','0')]:
                tcl+=f'set_option -{key} {value}\n'
            includes=['src/music','src/play','src/final','src/phys','src/poly','.']
            tcl+='set_option -include_path {'+';'.join((ROOT/x).as_posix() for x in includes)+'}\nrun syn\n'
            if args.stage=='full':tcl+='run pnr\n'
            script=run/'build.tcl';script.write_text(tcl,encoding='utf-8')
            log.touch()
            subprocess.Popen(['powershell.exe','-NoProfile','-NoExit','-ExecutionPolicy','Bypass','-File',str(ROOT/'tools/show_progress.ps1'),'-Log',str(log)],creationflags=subprocess.CREATE_NEW_CONSOLE)
            call([gowin,script])
            user=ET.Element('UserConfig');ET.SubElement(user,'Version').text='1.0'
            flow=ET.SubElement(user,'FlowState')
            ET.SubElement(flow,'Process',ID='Synthesis',State='2')
            ET.SubElement(flow,'Process',ID='Pnr',State='2' if args.stage=='full' else '0')
            results=ET.SubElement(user,'ResultFileList')
            entries={'RES.netlist':'impl/gwsynthesis/Final7.vg','RES.syn.report':'impl/gwsynthesis/Final7_syn.rpt.html','RES.syn.resource':'impl/gwsynthesis/Final7_syn_rsc.xml'}
            if args.stage=='full':
                entries.update({'RES.pnr.bitstream':'impl/pnr/Final7.fs','RES.pnr.pin.rpt':'impl/pnr/Final7.pin.html','RES.pnr.posp.bin':'impl/pnr/Final7.db','RES.pnr.pwr.rpt':'impl/pnr/Final7.power.html','RES.pnr.report':'impl/pnr/Final7.rpt.html','RES.pnr.timing.paths':'impl/pnr/Final7.timing_paths','RES.pnr.timing.rpt':'impl/pnr/Final7.tr.html'})
            for kind,relative in entries.items():
                output=ROOT/relative
                if output.is_file() and output.stat().st_mtime>=started-2:
                    ET.SubElement(results,'ResultFile',ResultFileType=kind,ResultFilePath=relative)
                elif kind in ('RES.netlist','RES.pnr.bitstream','RES.pnr.timing.rpt'):
                    raise RuntimeError('Missing fresh output: '+relative)
            ET.indent(user);ET.ElementTree(user).write(ROOT/'Final7.gprj.user',encoding='utf-8',xml_declaration=True)
            (ROOT/'BUILD_STATUS.json').write_text(json.dumps({'current_sources_built':True,'stage':args.stage,'bitstream':'impl/pnr/Final7.fs' if args.stage=='full' else None,'status':'BUILT_REVIEW_REPORTS'}),encoding='utf-8')
    (run/'result.json').write_text(json.dumps({'stage':args.stage,'completed':True,'output':str(run.relative_to(ROOT))},indent=2),encoding='utf-8')
    print(f'Completed {args.stage}: {run.relative_to(ROOT)}')

if __name__=='__main__':main()
