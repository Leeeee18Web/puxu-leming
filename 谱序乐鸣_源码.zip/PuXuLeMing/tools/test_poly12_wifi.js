const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const P=require('../web/protocol.js'),A=require('../web/performance.js');
const score=n=>({version:1,events:[...Array.from({length:n},(_,i)=>({ms:0,note:40+i,on:true,velocity:80})),...Array.from({length:n},(_,i)=>({ms:20,note:40+i,on:false}))]});
const word=(voice,timbre=0)=>((BigInt(voice)<<57n)|(1n<<56n)|(1n<<55n)|(60n<<48n)|(3000n<<36n)|(BigInt(timbre)<<33n)).toString(16).padStart(24,'0');
const take=(voice,timbre=0)=>({format:'p8-performance',version:1,sampleRate:48000,durationSamples:100,records:[word(voice,timbre)]});
test('7 concurrent score voices are valid; the eighth is rejected',()=>{
 assert.equal(P.MAX_VOICES,7);assert.equal(P.validateScore(score(7)).events.length,14);
 assert.equal(Math.max(...A.normalize(score(7)).events.map(e=>e.voice)),6);
 assert.throws(()=>P.validateScore(score(8)),/7/);assert.throws(()=>A.normalize(score(8)),/7/);
});
test('all seven captured voice indices and fifth timbre survive export normalization',()=>{
 for(let voice=0;voice<7;voice++)for(let timbre=0;timbre<5;timbre++)assert.deepEqual([A.normalize(take(voice,timbre)).events[0].voice,A.normalize(take(voice,timbre)).events[0].timbre],[voice,timbre]);
 for(const voice of [7,24,63])assert.throws(()=>A.normalize(take(voice)),/声部/);
 assert.throws(()=>A.normalize(take(0,5)),/音色/);
});
test('fifth timbre can be selected on hardware; unsupported values reject at the boundary',async()=>{
 const calls=[],queue={command:async(...args)=>{calls.push(args);return {};}};
 await P.setTimbre(queue,4);assert.deepEqual(calls,[[9,4]]);
 for(const bad of [-1,0,5,1.5])assert.throws(()=>P.setTimbre(queue,bad),/音色/);
});
test('original four browser approximations render 7 voices without clipping or silent output',()=>{
 for(let timbre=0;timbre<4;timbre++){
  const result=A.renderWav(score(7),{sampleRate:8000,timbre});
  const pcm=new Int16Array(result.wav,44);assert(pcm.some(x=>x!==0));assert(pcm.every(x=>Number.isInteger(x)&&x>=-32768&&x<=32767));
 }
});
test('custom piano JSON remains exportable while mobile envelope audition stays deferred',()=>{
 assert.equal(A.normalize(take(6,4)).events[0].timbre,4);
 assert.throws(()=>A.renderWav(take(6,4),{sampleRate:8000}),/自定义.*板端/);
 const s=score(1);s.events[0].timbre=4;assert.equal(A.normalize(s).events[0].timbre,4);
 assert.throws(()=>A.renderWav(s,{sampleRate:8000}),/自定义.*板端/);
});
test('7-voice interface text and firmware capacity diagnostics agree',()=>{
 const root=path.resolve(__dirname,'..'),index=fs.readFileSync(path.join(root,'web/index.html'),'utf8'),app=fs.readFileSync(path.join(root,'web/app.js'),'utf8'),ino=fs.readFileSync(path.join(root,'arduino/P8_WiFi_Web/P8_WiFi_Web.ino'),'utf8');
 assert(index.includes('7音同奏'),'7 voice user label');assert(index.includes('data-timbre="4"'),'fifth timbre button');assert(/P\.MAX_VOICES/.test(app),'shared voice boundary');
 assert(/voice_count\\":7/.test(ino),'ESP capacity diagnostic');assert(ino.includes('Final7-Grand-WiFi-2'),'paired firmware variant');
});
