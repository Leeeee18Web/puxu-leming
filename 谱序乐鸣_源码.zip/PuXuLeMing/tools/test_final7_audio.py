from pathlib import Path
import argparse
import subprocess
import sys

r=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--expect-fail',action='store_true');p.add_argument('--tone',choices=['0','1','2','3','4','mixed'],default='4');a=p.parse_args()
base=['src/phys/phys_strings_tuning.sv','src/phys/phys_string_bridge.sv','src/music/audio_serial.v','src/music/project4_envelope_bank.v','src/final/final_envelope12.sv','src/final/final_fx.sv','src/music/project4_fx_chain.v','src/music/project4_fx_fir.v']
models=[str(x.relative_to(r)) for x in (r/'src/poly').glob('*.sv') if x.name not in ['poly_keymap.sv','poly25_voice_control.sv']]
top='tb_final7_audio'+('' if a.tone=='4' else '_'+a.tone)
cmd=[sys.executable,'-B',r/'tools/final_run_sim.py',top,*base,*models,'sim/final7_audio_full.sv','--timeout','360']
if a.expect_fail:cmd.append('--expect-fail')
subprocess.run(cmd,cwd=r,check=True)
