"""Offline Qt, real serial-worker peer, and blank-model checks; no devices."""
from pathlib import Path
import os, subprocess, sys

root=Path(__file__).resolve().parents[1]
captures=sorted((root/'build/sim/tb_final_wifi').glob('*/final_uart_reply.hex'))
assert captures, 'Actual RTL response fixture required'
env=dict(os.environ,QT_QPA_PLATFORM='offscreen',PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',GS2_CAPTURE=str(captures[-1]))
commands=[
 [sys.executable,'-B','-m','unittest','discover','-v'],
 [sys.executable,'-B','app.py','--check'],
 [os.environ.get('INSTRUMENT_VISION_PYTHON',sys.executable),'-B','dual_camera.py','--check'],
]
for command in commands:
 subprocess.run(command,cwd=root/'gesture_host',env=env,check=True,timeout=90)
