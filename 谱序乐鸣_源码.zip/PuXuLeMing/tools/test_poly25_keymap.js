const assert=require('node:assert/strict');
const P=require('../web/protocol.js');globalThis.P8WiFi=P;
const {Draft,defaults}=require('../web/keymap_ui.js');
(async()=>{
 const m=new Draft(),baseline=JSON.stringify(m.applied);m.select(24);m.set(0);assert.equal(m.draft.notes[24],0);assert.equal(JSON.stringify(m.applied),baseline);
 m.select(0,true);m.set(67);assert.equal(m.draft.notes[0],67);assert.equal(m.draft.notes[24],67);
 m.transpose(12);assert.equal(m.draft.notes[24],79);m.set(127);assert.throws(()=>m.transpose(1),/超出/);assert.equal(m.draft.notes[0],127);
 await assert.rejects(m.apply({release:async()=>{},command:async()=>{throw Error('no ACK')}}),/no ACK/);assert.equal(JSON.stringify(m.applied),baseline);assert(m.dirty);
 let active=defaults(),draft=null,writes=0,failCommit=false,ops=[];
 const q=new P.CommandQueue({session:1,send(bytes){const req=P.decode(bytes);ops.push(req);let result=0;
  if(req.op===20)draft={base:req.a,enabled:!!req.b,notes:[]};
  if(req.op===21){draft.notes[req.a]=req.b;writes++;}
  if(req.op===22){if(failCommit)result=5;else{assert.equal(req.a,P.mapCRC(draft));active=P.validateMap(draft);}}
  const a=(result|((active.notes[req.a<25?req.a:0])<<8)|(active.base<<16)|(active.enabled?0x1000000:0))>>>0;
  queueMicrotask(()=>q.receive(P.encode({...req,op:req.op|128,a,b:P.mapCRC(active),c:P.IDENTITY})));
 }});
 m.reset();m.draft.notes.fill(0);await m.apply(q,true);assert.equal(writes,25);assert.equal(m.applied.notes[24],0);assert(!m.dirty);assert.deepEqual(ops.map(o=>o.op),[2,20,...Array(25).fill(21),22]);assert.equal(ops.at(-1).b,1);
 assert.deepEqual((await P.readKeymap(q)).notes,active.notes);
 failCommit=true;m.select(0);m.set(127);await assert.rejects(m.apply(q),/CRC/);assert.equal(m.applied.notes[0],0);assert(m.dirty);q.close();
 console.log('POLY25_KEYMAP_WEB_PASS: drafts, groups, bounds,25PUT,ACK-gated apply/save,GET CRC,failedACK');
})().catch(e=>{console.error(e);process.exitCode=1;});
