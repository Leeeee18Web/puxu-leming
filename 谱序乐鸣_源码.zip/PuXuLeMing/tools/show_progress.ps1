param([Parameter(Mandatory=$true)][string]$Log)
$Host.UI.RawUI.WindowTitle='谱序乐鸣 · 构建日志（只读）'
Write-Host $Log
Get-Content -LiteralPath $Log -Tail 30 -Wait
