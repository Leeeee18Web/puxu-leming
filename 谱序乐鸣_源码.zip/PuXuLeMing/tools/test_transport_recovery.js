const test=require('node:test'),assert=require('node:assert/strict'),P=require('../web/protocol.js'),T=require('../web/http_transport.js');
test('one transient network failure retries identical frame without closing session',async()=>{
 let calls=0,failures=0,q;const sent=[];
 const t=new T({base:'http://test',session:37,onFrame:f=>q.receive(f),onFailure:e=>{failures++;q.close(e);},fetchImpl:async(url,opt)=>{calls++;sent.push(opt.body);if(calls===1)throw Error('injected transient');const c=P.decode(Uint8Array.from(opt.body.match(/../g),x=>parseInt(x,16)));const r=P.encode({...c,op:c.op|128,c:P.IDENTITY,a:0,b:0});return {ok:true,arrayBuffer:async()=>r.buffer};}});
 q=new P.CommandQueue({session:37,send:f=>t.send(f),timeout:30,retries:2});await q.command(3);assert.equal(calls,2);assert.equal(failures,0);assert.equal(sent[0],sent[1]);q.close();
});
test('409 remains a clear terminal error, not an endless silent retry',async()=>{
 let q;const t=new T({base:'http://test',session:37,onFrame:f=>q.receive(f),onFailure:e=>q.close(e),fetchImpl:async()=>({ok:false,status:409,json:async()=>({error:'控制会话已结束'})})});q=new P.CommandQueue({session:37,send:f=>t.send(f),timeout:30,retries:2});await assert.rejects(q.command(3),/会话已结束/);
});
