const test=require('node:test'),assert=require('node:assert/strict'),P=require('../web/protocol.js');
const raw=require('../examples/wifi/0001.json');
test('all512 converter events retained and RAM verification follows COMMIT',async()=>{
 const s=P.validateScore(raw),crc=P.scoreCRC(s.events),sent=[];
 const q={command:async(op,a=0)=>{sent.push([op,a]);return {count:512,verifiedCRC:crc};}};
 await P.uploadScore(q,s);assert.equal(s.events.length,512);assert.deepEqual(sent.map(x=>x[0]),[4,...Array(512).fill(5),6,12]);
 assert.deepEqual(sent.filter(x=>x[0]===5).map(x=>x[1]),Array.from({length:512},(_,i)=>i));
});
test('wrong RAM CRC or count cannot be reported as successful download',async()=>{
 const s=P.validateScore(raw),crc=P.scoreCRC(s.events);
 for(const status of [{count:512,verifiedCRC:crc^1},{count:256,verifiedCRC:crc},{count:0}]){
  await assert.rejects(P.uploadScore({command:async()=>status},s),/板内.*复核/);
 }
});
test('old keyboard and incomplete song FPGA versions rejected before transfer',()=>{
 for(const status of [{},{capabilities:0},{capabilities:0x5303}])assert.throws(()=>P.requireScoreDevice(status),/FPGA.*版本/);
 assert.doesNotThrow(()=>P.requireScoreDevice({capabilities:0x5305}));
});
