"""Exercise PW1 through the production Final top and both clock mailboxes."""
from pathlib import Path
import json, subprocess, sys, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
files=['sim/p8_gesture_hardware_stubs.sv','sim/tb_final_wifi.sv']
for node in ET.parse(root/'Final7.gprj').getroot().find('FileList'):
    p=node.get('path','')
    if node.get('enable')=='1' and p.endswith(('.v','.sv')) and '/gowin_pll/' not in p and not p.endswith(('usb_play_soc.sv','usb_pll_mod.v')):
        files.append(p)
code=subprocess.call([sys.executable,'-B',root/'tools/final_run_sim.py','tb_final_wifi',*files,*sys.argv[1:]],cwd=root)
if code==0 and '--expect-fail' not in sys.argv:
    run=sorted((root/'build/sim/tb_final_wifi').glob('*/result.json'))[-1].parent
    sys.path.insert(0,str(root/'host_ui'))
    from gesture_link import Decoder, parse_status
    raw=bytes(int(b,16) for b in (run/'final_uart_reply.hex').read_text().split())
    for size in range(1,len(raw)+1):
        decoder=Decoder();frames=[]
        for i in range(0,len(raw),size):frames.extend(decoder.feed(raw[i:i+size]))
        assert len(frames)==1 and frames[0][0]==1, 'actual FinalWIFI UART reply rejected by original decoder'
        status=parse_status(frames[0][1]);assert status['firmware']==0x5008 and status['ack']==1 and status['result']==0
    (run/'gs2_decode.json').write_text(json.dumps(dict(passed=True,bytes=len(raw),fragment_sizes=len(raw),actual_top=True,hardware=False)),encoding='utf-8')
    print('FINAL_WIFI_GS2_PASS actual serial reply decoded in',len(raw),'fragment sizes')
raise SystemExit(code)
