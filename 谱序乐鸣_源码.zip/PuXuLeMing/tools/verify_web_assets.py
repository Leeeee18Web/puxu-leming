"""Read-only equality check between editable web sources and ESP embedded HTML."""
from pathlib import Path
import argparse,hashlib,json

def check_assets(root):
 root=Path(root);web=root/'web'
 html=(web/'index.html').read_text(encoding='utf-8')
 html=html.replace('<link rel="stylesheet" href="style.css">','<style>\n'+(web/'style.css').read_text(encoding='utf-8')+'\n</style>')
 scripts=['protocol.js','performance.js','singing.js','http_transport.js','keymap_ui.js','app.js','record_ui.js','singing_ui.js']
 for script in scripts:html=html.replace(f'<script src="{script}"></script>','<script>\n'+(web/script).read_text(encoding='utf-8')+'\n</script>')
 payload=html.encode('utf-8');digest=hashlib.sha256(payload).hexdigest()
 assert (web/'preview.html').read_bytes()==payload, 'offline preview differs from current editable web sources'
 manifest=json.loads((web/'asset_manifest.json').read_text(encoding='utf-8'))
 assert manifest['sha256']==digest and manifest['bytes']==len(payload), 'asset manifest differs from current web sources'
 header=(root/'arduino/P8_WiFi_Web/web_assets.h').read_text(encoding='utf-8')
 begin='static const char P8_WEB_HTML[] PROGMEM = R"P8WEBHTML(';end=')P8WEBHTML";'
 assert header.count(begin)==1 and header.count(end)==1, 'embedded HTML marker mismatch'
 assert header.split(begin,1)[1].rsplit(end,1)[0]==html, 'ESP embedded webpage differs from current editable web sources'
 assert '// SHA256 '+digest in header, 'embedded HTML digest comment mismatch'
 return {'passed':True,'bytes':len(payload),'sha256':digest}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--root');a=p.parse_args()
 print(json.dumps(check_assets(a.root or Path(__file__).resolve().parents[1])))
