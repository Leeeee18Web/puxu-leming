const {test}=require('node:test');
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const file=path.resolve(__dirname,'../web/singing.js');
test('3.0 provides phone-local singing transcription',()=>assert.ok(fs.existsSync(file),'missing singing transcription feature'));
if(fs.existsSync(file)){
 const S=require(file),P=require('../web/protocol.js');
 function melody(notes,{rate=16000,vibrato=0,noise=0,harmonic=false,gap=.10}={}){
  const duration=notes.length*(.4+gap)+.12,x=new Float32Array(Math.ceil(rate*duration));let seed=42;
  notes.forEach((note,k)=>{let phase=0;for(let i=0;i<.4*rate;i++){
   const t=i/rate,f=440*2**((note-69+vibrato*Math.sin(2*Math.PI*5*t))/12);phase+=2*Math.PI*f/rate;
   const env=Math.min(1,i/(rate*.015),(.4*rate-i)/(rate*.02));
   x[Math.floor((.06+k*(.4+gap))*rate)+i]=env*(harmonic?.12*Math.sin(phase)+.30*Math.sin(2*phase)+.08*Math.sin(3*phase):.4*Math.sin(phase));
  }});
  for(let i=0;i<x.length;i++){seed=(1664525*seed+1013904223)>>>0;x[i]+=noise*(seed/4294967296-.5);}
  return x;
 }
 test('sung melody, silence and adjacent semitones preserve pitches and pauses',()=>{
  const r=S.transcribe(melody([60,61,62,65,67]),16000);assert.deepEqual(r.notes.map(n=>n.note),[60,61,62,65,67]);
  assert.ok(r.notes.every(n=>n.endMs-n.startMs>280));assert.ok(r.notes[1].startMs-r.notes[0].endMs>40);P.validateScore(r.score);
 });
 test('vibrato and noise do not fragment a sustained note',()=>{const r=S.transcribe(melody([60,64,67],{vibrato:.20,noise:.009}),16000);assert.deepEqual(r.notes.map(n=>n.note),[60,64,67]);});
 test('a stronger second harmonic retains the fundamental',()=>{const r=S.transcribe(melody([55,60,64],{harmonic:true}),16000);assert.deepEqual(r.notes.map(n=>n.note),[55,60,64]);});
 test('repeated same-pitch attacks remain separate',()=>{const r=S.transcribe(melody([60,60,60],{gap:.06}),16000);assert.equal(r.notes.length,3);assert.ok(r.notes.every(n=>n.note===60));});
 test('different input sample rates map to valid FPGA events',()=>{for(const rate of [8000,44100,48000]){const r=S.transcribe(melody([60,67],{rate}),rate);assert.deepEqual(r.notes.map(n=>n.note),[60,67]);P.validateScore(r.score);}});
 test('silence, invalid samples, excessive duration and cancellation fail explicitly',()=>{
  assert.throws(()=>S.transcribe(new Float32Array(8000),8000),/未识别|清唱/);
  assert.throws(()=>S.transcribe(Float32Array.of(NaN),8000),/音频/);
  assert.throws(()=>S.transcribe(new Float32Array(8000*31),8000),/30/);
  assert.throws(()=>S.transcribe(melody([60]),16000,{cancelled:()=>true}),/取消/);
 });
 test('more than 256 notes is rejected, never silently shortened',()=>{
  const n=Array.from({length:257},(_,i)=>({note:60,startMs:i*90,endMs:i*90+70,confidence:.9}));
  assert.throws(()=>S.toScore(n,'too long'),/512|256|分段/);
 });
}
