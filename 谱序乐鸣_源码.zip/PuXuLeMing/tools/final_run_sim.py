"""ModelSim runner: every generated file stays in the global Final audit tree."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8")
root = Path(__file__).resolve().parents[1]
audit = root / 'build'
parser = argparse.ArgumentParser()
parser.add_argument("top")
parser.add_argument("sources", nargs="+")
parser.add_argument("--expect-fail", action="store_true")
parser.add_argument("--timeout", type=int, default=240)
args = parser.parse_args()
run = audit / "sim" / args.top / datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
run.mkdir(parents=True)
(run / "temp").mkdir()
env = dict(os.environ, TEMP=str(run / "temp"), TMP=str(run / "temp"))
tool = Path(os.environ['MODELSIM_BIN'])
ini = run / "modelsim.ini"
ini.write_text("[Library]\nwork = " + (run / "work").as_posix() + "\nothers = " + (tool.parent / "modelsim.ini").as_posix() + "\n", encoding="utf-8")
for source in (root / "src").rglob("*.hex"):
    target = run / source.relative_to(root)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
if (root / "sim/fixtures").exists():
    shutil.copytree(root / "sim/fixtures", run / "fixtures")
if (root / "sim/pif_ui_reference").exists():
    shutil.copytree(root / "sim/pif_ui_reference", run / "sim/pif_ui_reference")
sources = [(root / source).resolve() for source in args.sources]
if (root / "src/poly/poly25_audio.sv").resolve() in sources:
    for relative in ("src/music/project4_envelope_bank.v", "src/final/final_envelope12.sv"):
        dependency = (root / relative).resolve()
        if dependency not in sources:
            sources.append(dependency)
missing = [str(source) for source in sources if not source.is_file()]
if missing:
    message = 'Simulation source missing: ' + repr(missing)
    with (root / 'build/errors.md').open('a', encoding='utf-8') as log:
        log.write('\n\n### FINAL-SIM-INPUT-' + run.name + '\n- 原始错误：' + message +
                  '；条件仿真输入预检；路径缺失已确认，具体路径选择原因待核对。未进入编译，未操作硬件；修复及复验待记录。\n')
    (run/'result.json').write_text(json.dumps(dict(top=args.top,passed=False,error=message,run=str(run)),ensure_ascii=False,indent=2),encoding='utf-8')
    raise SystemExit(message)
inputs = sorted(set(sources) | set((root / "src").rglob("*.vh")) | set((root / "src").rglob("*.hex")))
def input_hashes():
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in inputs}
inputs += [p for p in (root / "sim/fixtures").rglob("*") if p.is_file()]
inputs += [p for p in (root / "sim/pif_ui_reference").rglob("*") if p.is_file()]
before = input_hashes()
(run / "inputs_before.json").write_text(json.dumps(before, indent=2), encoding="utf-8")
commands = [
    [tool / "vlib.exe", run / "work"],
    [tool / "vlog.exe", "-modelsimini", ini, "-sv", "+incdir+" + root.as_posix(),
     *["+incdir+" + (root / directory).as_posix() for directory in
       ("src/music", "src/play", "src/final", "src/phys", "sim/fixtures/pm_r1_sources", "sim/fixtures/pm_r2_strings", "src/usb_host/usb1_host")],
     "-work", run / "work", *sources],
    [tool / "vsim.exe", "-c", "-modelsimini", ini, "-lib", run / "work", args.top,
     "-l", run / "transcript.log", "-wlf", run / "wave.wlf", "-do",
     "onerror {quit -code 1}; onbreak {quit -code 1}; run -all; quit -code 0"],
]
failed = False
output = ""
for index, command in enumerate(commands):
    try:
        result = subprocess.run([value.as_posix() if isinstance(value, Path) else str(value) for value in command], cwd=run, env=env,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=args.timeout)
        output = result.stdout.decode("utf-8", "replace")
        bad = result.returncode != 0 or bool(re.search(r"\*\* (?:Error|Fatal)|\bFAIL\b|Errors:\s*[1-9]", output))
    except subprocess.TimeoutExpired as error:
        output = "TIMEOUT: " + str(error)
        bad = True
    (run / f"{index}.log").write_text(output, encoding="utf-8")
    if bad:
        failed = True
        with (root / 'build/errors.md').open("a", encoding="utf-8") as log:
            log.write("\n\n### FINAL-ROOT-SIM-" + run.name + "-" + str(index) +
                      "\n- 原始输出：\n```\n" + output[-4000:] + "\n```\n- 条件：" + args.top +
                      ("预期RED复现" if args.expect_fail else "离线RTL回归") +
                      "；尚未确认其他成因，未操作板卡。影响：该验证未通过。证据：" + str(run) +
                      "；修复与GREEN待后续独立核对。\n")
        break
after = input_hashes()
if before != after:
    failed = True
    output += "\nFAIL source/include/ROM bytes changed during simulation; GREEN rejected."
    with (root / 'build/errors.md').open("a", encoding="utf-8") as log:
        log.write("\n\n### FINAL-SIM-SOURCE-DRIFT-" + run.name + "\n- 原始现象：测试期间源/include/ROM SHA256改变；原因未确认，拒绝GREEN，需冻结重跑。未操作硬件；证据：" + str(run) + "\n")
result_data = {"top": args.top, "passed": not failed, "expected_red": args.expect_fail,
               "run": str(run), "sources": before, "inputs_after": after, "frozen": before == after}
(run / "result.json").write_text(json.dumps(result_data, indent=2), encoding="utf-8")
print(output[-2200:])
print(json.dumps({key: value for key, value in result_data.items() if key not in ("sources", "inputs_after")}))
raise SystemExit(0 if failed == args.expect_fail else 1)
