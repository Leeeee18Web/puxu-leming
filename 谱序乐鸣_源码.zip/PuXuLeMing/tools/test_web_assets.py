from pathlib import Path
import datetime,json,shutil,subprocess,sys
from verify_web_assets import check_assets
r=Path(__file__).resolve().parents[1]
run=r/'build/asset_test'/datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
fixture=run/'fixture';fixture.mkdir(parents=True)
shutil.copytree(r/'web',fixture/'web',ignore=shutil.ignore_patterns('qa'))
shutil.copytree(r/'arduino/P8_WiFi_Web',fixture/'arduino/P8_WiFi_Web')
(fixture/'tools').mkdir();(fixture/'examples/wifi').mkdir(parents=True)
shutil.copy2(r/'tools/build_wifi_web_assets.py',fixture/'tools/build_wifi_web_assets.py')
check_assets(fixture)
p=fixture/'web/app.js';p.write_text(p.read_text(encoding='utf-8')+'\n// isolated changed webpage fixture\n',encoding='utf-8')
rejected=False
try:check_assets(fixture)
except AssertionError as exc:rejected=True;reason=str(exc)
assert rejected, 'stale embedded webpage must be rejected'
subprocess.run([sys.executable,'-B',str(fixture/'tools/build_wifi_web_assets.py')],stdout=subprocess.DEVNULL,check=True)
fixed=check_assets(fixture)
result=dict(passed=True,stale_rejected=True,reason=reason,rebuild_restored=True,current_root=check_assets(r),fixture=fixed,run=str(run))
(run/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print('WEB_ASSET_SYNC_PASS edited source rejected, actual asset generator restores preview/header/manifest equality')
