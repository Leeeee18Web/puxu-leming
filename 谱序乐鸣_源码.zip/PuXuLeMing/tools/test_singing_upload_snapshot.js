const vm=require('node:vm'),fs=require('node:fs'),assert=require('node:assert/strict');
const root=require('node:path').resolve(__dirname,'..');
const protocol=require(root+'/web/protocol.js');
const performance=require(root+'/web/performance.js');
const elements=new Map();
function el(id=''){return {id,options:[],value:'',textContent:'',hidden:false,disabled:false,style:{},dataset:{},handlers:{},classList:{toggle(){},add(){},remove(){}},addEventListener(k,f){this.handlers[k]=f;},setAttribute(){},append(){},replaceChildren(){},contains(){return false;}};}
const document={hidden:false,getElementById(id){if(!elements.has(id))elements.set(id,el(id));return elements.get(id);},querySelectorAll(){return [];},createElement:()=>el(),addEventListener(){}};
let releases=0,unlock,received;
class Queue{constructor(o){this.o=o;this.waiting=[];}async command(op){const s={committed:false,muted:false,mode:0,playing:false,count:0,capabilities:0x5305};this.o.onStatus(s);return s;}release(){releases++;console.log('release',releases);if(releases===2)return new Promise(r=>unlock=r);return Promise.resolve();}close(){}live(){return Promise.resolve();}}
const window={P8WiFi:{...protocol,CommandQueue:Queue,uploadScore:async(q,s)=>{received=s;}},P8Performance:performance,P8HttpTransport:class{close(){}},P8RecorderUI:{setSource(){},connectionChanged(){}},addEventListener(){}};
const ctx={window,document,location:{protocol:'http:',origin:'http://piano'},setTimeout,clearTimeout,setInterval:()=>1,clearInterval,Date,Math,Uint16Array};
vm.runInNewContext(fs.readFileSync(root+'/web/app.js','utf8'),ctx,{filename:'app.js'});
const events=[];for(let i=0;i<7;i++)events.push({ms:i*450,note:72,on:true,velocity:96},{ms:i*450+380,note:72,on:false,velocity:0});
(async()=>{await new Promise(r=>setImmediate(r));const input={version:1,title:'Singing preview C5 repeated',events};const job=window.P8Session.submitSingingScore(input);for(let tries=0;!unlock&&tries<20;tries++)await new Promise(r=>setTimeout(r,10));if(!unlock){throw Error('release gate not reached');}elements.get('sample-score').handlers.click();unlock();const ok=await job;const evidence={submitReturned:ok,expectedNotes:input.events.filter(e=>e.on).map(e=>e.note),actualUploadedNotes:received.events.filter(e=>e.on).map(e=>e.note),actualTitle:received.title,eventCountsMatch:received.events.length===events.length};assert.equal(ok,true);assert.deepEqual(evidence.actualUploadedNotes,evidence.expectedNotes);console.log(JSON.stringify(evidence,null,2));console.log('UPLOAD_SNAPSHOT_PASS');})().catch(e=>{console.error(e);process.exitCode=1;});


