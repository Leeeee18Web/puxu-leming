@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start_Gesture_Host.ps1"
