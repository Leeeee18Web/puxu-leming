param([switch]$Check)
$taskPython=if($env:INSTRUMENT_UI_PYTHON){$env:INSTRUMENT_UI_PYTHON}else{'python'}
if($Check){& $taskPython -X utf8 -B (Join-Path $PSScriptRoot 'gesture_host/app.py') --check}
else{& $taskPython -X utf8 -B (Join-Path $PSScriptRoot 'gesture_host/app.py')}
exit $LASTEXITCODE
