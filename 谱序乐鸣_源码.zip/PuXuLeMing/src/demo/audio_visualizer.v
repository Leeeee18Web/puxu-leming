// 1024-point radix-2 FFT and frame-owned wave/XY/spectrum snapshots.
// Producer never overwrites the pixel-owned bank. All DSP executes in HDL.
module audio_visualizer #(parameter REGISTERED_PCM_POSITIVE=0)(input clk,rst,sample_tick,input pcm_positive,
 input signed [15:0] pcm,component_a,component_b,
 input [5:0] note_index,input [2:0] current_note,next_note,input playing,
 input pixel_clk,pixel_rstn,frame_start,
 input [9:0] wave_addr,input [6:0] spectrum_addr,input [15:0] xy_addr,
 output reg [47:0] wave_data=0,output reg [7:0] spectrum_data=0,output reg xy_data=0,
 output reg valid=0,output reg [12:0] meta=0,output [7:0] spectrum_peak);
localparam CLEAR=0,CAPTURE=1,READ=2,LATCH=3,MULTIPLY=4,ROTATE=5,WRITE=6,
 MAG_READ=7,MAG_WAIT=8,MAG_WRITE=9,WAIT_ACK=10;
reg [3:0] state=CLEAR;
reg trigger_previous_positive=0;
reg trigger_wait=1;reg [9:0] trigger_count=0;reg signed [15:0] trigger_previous=0;
wire rising_zero=REGISTERED_PCM_POSITIVE?(!trigger_previous_positive&&pcm_positive):(trigger_previous<=0&&pcm>0);
reg bank=1,publish_toggle=0,ack=0;
(* syn_preserve=1 *) reg [1:0] ack_sync=0,publish_sync=0;
reg seen=0,display_bank=0;
reg [12:0] meta_source=0;
reg [15:0] clear_addr=0;
reg [9:0] capture_index=0,group_base=0,j=0;
reg [3:0] stage=0;
reg [6:0] mag_index=0;
reg [15:0] wave_mem[0:2047];
reg [7:0] spectrum_mem[0:255];
 reg [7:0] peak_accum=0,bank_peak0=0,bank_peak1=0;
 (* syn_preserve=1 *) reg [7:0] peak_snapshot=0;
 assign spectrum_peak=peak_snapshot;

wire signed [16:0] x_scaled=(component_a>>>6)+17'sd128;
wire signed [16:0] y_scaled=17'sd128-(component_b>>>6);
wire [7:0] xy_x=x_scaled<0?0:(x_scaled>255?255:x_scaled[7:0]);
wire [7:0] xy_y=y_scaled<0?0:(y_scaled>255?255:y_scaled[7:0]);
wire [7:0] magnitude;
always @(posedge clk)begin
 if(state==CAPTURE&&sample_tick)wave_mem[{bank,capture_index}]<=pcm;
 if(state==MAG_WRITE)spectrum_mem[{bank,mag_index}]<=magnitude;
 if(state==CLEAR)peak_accum<=0;
 else if(state==MAG_WRITE)begin
  if(magnitude>peak_accum)peak_accum<=magnitude;
  if(mag_index==127)begin
   if(bank)bank_peak1<=magnitude>peak_accum?magnitude:peak_accum;
   else bank_peak0<=magnitude>peak_accum?magnitude:peak_accum;
  end
 end
end
always @(posedge pixel_clk)begin
 wave_data<={32'd0,wave_mem[{display_bank,wave_addr}]};
 spectrum_data<=spectrum_mem[{display_bank,spectrum_addr}];
 xy_data<=0;
end
always @(posedge pixel_clk or negedge pixel_rstn)begin
 if(!pixel_rstn)begin publish_sync<=0;seen<=0;ack<=0;valid<=0;meta<=0;display_bank<=0;peak_snapshot<=0;end
 else begin
  publish_sync<={publish_sync[0],publish_toggle};
  if(frame_start&&publish_sync[1]!=seen)begin
   seen<=publish_sync[1];ack<=publish_sync[1];display_bank<=bank;
   meta<=meta_source;valid<=1;
   peak_snapshot<=bank?bank_peak1:bank_peak0;
  end
 end
end
function [9:0] reverse10;input [9:0] v;integer i;begin
 for(i=0;i<10;i=i+1)reverse10[i]=v[9-i];end endfunction
wire [10:0] half_span=11'd1<<stage;
wire [9:0] addr_a=group_base+j;
wire [9:0] addr_b=group_base+j+half_span;
wire [8:0] twiddle_addr=j<<(9-stage);
wire [9:0] mem_addr0=state==CAPTURE?reverse10(capture_index):
 ((state==MAG_READ||state==MAG_WAIT||state==MAG_WRITE)?{3'b0,mag_index}:addr_a);
wire [9:0] mem_addr1=addr_b;
wire we0=(state==CAPTURE&&sample_tick)||(state==WRITE);
wire we1=state==WRITE;
reg signed [15:0] re_mem[0:1023],im_mem[0:1023];
reg signed [15:0] qr0=0,qi0=0,qr1=0,qi1=0;
reg signed [15:0] ar=0,ai=0,br=0,bi=0,wr=0,wi=0;
reg signed [15:0] tw_re[0:511],tw_im[0:511];
initial begin $readmemh("src/demo/twiddle_re.hex",tw_re);$readmemh("src/demo/twiddle_im.hex",tw_im);end
reg signed [31:0] rr=0,ii=0,ri=0,ir=0;
reg signed [16:0] tr=0,ti=0;
wire signed [17:0] sum_re=$signed({{2{ar[15]}},ar})+$signed({tr[16],tr});
wire signed [17:0] sum_im=$signed({{2{ai[15]}},ai})+$signed({ti[16],ti});
wire signed [17:0] diff_re=$signed({{2{ar[15]}},ar})-$signed({tr[16],tr});
wire signed [17:0] diff_im=$signed({{2{ai[15]}},ai})-$signed({ti[16],ti});
wire [15:0] write_r0=state==CAPTURE?pcm:(sum_re>>>1);
wire [15:0] write_i0=state==CAPTURE?16'b0:(sum_im>>>1);
// Explicit true-dual-port templates: two ports, one R/W address per port.
always @(posedge clk)begin
 if(we0)begin
  re_mem[mem_addr0]<=write_r0;im_mem[mem_addr0]<=write_i0;
  qr0<=write_r0;qi0<=write_i0;
 end else begin qr0<=re_mem[mem_addr0];qi0<=im_mem[mem_addr0];end
end
always @(posedge clk)begin
 if(we1)begin
  re_mem[mem_addr1]<=diff_re>>>1;im_mem[mem_addr1]<=diff_im>>>1;
  qr1<=diff_re>>>1;qi1<=diff_im>>>1;
 end else begin qr1<=re_mem[mem_addr1];qi1<=im_mem[mem_addr1];end
end
wire [16:0] abs_re=qr0[15]?- $signed({qr0[15],qr0}):{1'b0,qr0};
wire [16:0] abs_im=qi0[15]?- $signed({qi0[15],qi0}):{1'b0,qi0};
wire [17:0] mag_sum={1'b0,abs_re}+{1'b0,abs_im};
// The existing MAG_WAIT bubble owns the settled RAM output. Capture its
// absolute-value sum here, before saturation and the peak comparator. The
// MAG_WRITE/publication cycle and every visible spectrum bin stay unchanged.
(* syn_preserve=1 *) reg [17:0] mag_sum_q=0;
always @(posedge clk)begin
 if(rst)mag_sum_q<=0;
 else if(state==MAG_WAIT)mag_sum_q<=mag_sum;
end
assign magnitude=(mag_sum_q>18'd4080)?8'hff:mag_sum_q[11:4];
always @(posedge clk)begin
 ack_sync<={ack_sync[0],ack};
 if(sample_tick)begin trigger_previous<=pcm;trigger_previous_positive<=pcm_positive;end
 if(rst)begin state<=CLEAR;bank<=1;publish_toggle<=0;clear_addr<=0;capture_index<=0;
  group_base<=0;j<=0;stage<=0;mag_index<=0;ack_sync<=0;meta_source<=0;trigger_wait<=1;trigger_count<=0;trigger_previous<=0;trigger_previous_positive<=0;end
 else case(state)
  CLEAR:if(clear_addr==65535)begin clear_addr<=0;capture_index<=0;state<=CAPTURE;trigger_wait<=1;trigger_count<=0;end
        else clear_addr<=clear_addr+1'b1;
  CAPTURE:if(sample_tick)begin
   if(trigger_wait)begin
    if(rising_zero||trigger_count==1023)begin trigger_wait<=0;capture_index<=1;end
    else trigger_count<=trigger_count+1'b1;
   end else if(capture_index==1023)begin
    capture_index<=0;stage<=0;group_base<=0;j<=0;state<=READ;
    meta_source<={playing,note_index,current_note,next_note};
   end else capture_index<=capture_index+1'b1;
  end
  READ:state<=LATCH;
  LATCH:begin ar<=qr0;ai<=qi0;br<=qr1;bi<=qi1;wr<=tw_re[twiddle_addr];wi<=tw_im[twiddle_addr];state<=MULTIPLY;end
  MULTIPLY:begin rr<=br*wr;ii<=bi*wi;ri<=br*wi;ir<=bi*wr;state<=ROTATE;end
  ROTATE:begin tr<=($signed({rr[31],rr})-$signed({ii[31],ii}))>>>15;
   ti<=($signed({ri[31],ri})+$signed({ir[31],ir}))>>>15;state<=WRITE;end
  WRITE:begin
   state<=READ;
   if(j==half_span-1)begin
    j<=0;
    if({1'b0,group_base}+(half_span<<1)>=1024)begin
     group_base<=0;
     if(stage==9)begin mag_index<=0;state<=MAG_READ;end else stage<=stage+1'b1;
    end else group_base<=group_base+(half_span<<1);
   end else j<=j+1'b1;
  end
  MAG_READ:state<=MAG_WAIT;
  MAG_WAIT:state<=MAG_WRITE;
  MAG_WRITE:if(mag_index==127)begin publish_toggle<=~publish_toggle;state<=WAIT_ACK;end
            else begin mag_index<=mag_index+1'b1;state<=MAG_READ;end
  WAIT_ACK:if(ack_sync[1]==publish_toggle)begin bank<=~bank;clear_addr<=0;state<=CLEAR;end
  default:state<=CLEAR;
 endcase
end
endmodule
