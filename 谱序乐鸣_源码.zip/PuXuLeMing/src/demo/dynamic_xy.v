// HDL reference visualizer, not a measurement of speaker/PCM phase.
// A thin complete curve retains ratio/phase meaning; a 3px trail and 7px
// head expose motion even when audio-rate samples cover whole closed curves.
module dynamic_xy #(parameter POINTS=64)(
 input clk,rst,sample_tick,active,input [23:0] note_step,input [15:0] envelope,
 input [5:0] requested_config,
 input pixel_clk,pixel_rstn,frame_start,input [15:0] read_addr,
 output reg data=0,output reg valid=0,output reg [5:0] shown_config=0);
 localparam CLEAR=0,CAPTURE=1,WAIT0=2,WAIT1=3,POINT=4,DRAW=5,PUBLISH=6,WAIT_ACK=7;
 localparam COUNT_W=(POINTS<8)?4:$clog2(POINTS+1);
 localparam [23:0] CURVE_STEP=16777216/POINTS;
 reg [3:0] state=CLEAR;reg bank=1,publish=0,ack=0,seen=0,display_bank=0;
 reg [15:0] clear_addr=0;reg [COUNT_W-1:0] count=0;reg previous_valid=0;
 reg [5:0] settings=6'b101000;
 (* syn_preserve=1 *) reg [1:0] ack_sync=0,publish_sync=0;
 reg [23:0] base_phase=0,phase_offset=24'h400000;
 reg [23:0] frame_phase=24'h400000,frame_head=0,sample_phase=0;
 reg [15:0] frame_envelope=0;reg frame_active=0;
 reg [1:0] pass=0;reg [2:0] stencil_x=0,stencil_y=0;
 function [23:0] phase_value;input [2:0] n;
 begin case(n)0:phase_value=0;1:phase_value=24'h200000;2:phase_value=24'h400000;3:phase_value=24'h600000;default:phase_value=24'h800000;endcase end endfunction
 // Slow note DDS by 1024, bounded to 64..256 phase units/sample:
 // one visual orbit is 1.365..5.461 seconds at 48kHz. Zero step stays blank.
 wire [23:0] slow_step=note_step>>10;
 wire [23:0] visual_step=slow_step<64?24'd64:slow_step>256?24'd256:slow_step;
 wire [23:0] phase_x=settings[1:0]==3?(sample_phase<<1):sample_phase;
 wire [23:0] phase_y=(settings[1:0]==0?sample_phase:settings[1:0]==1?(sample_phase<<1):(sample_phase+(sample_phase<<1)))+frame_phase;
 wire signed [15:0] sx,sy;
 sine_rom x_sine(.clk(clk),.addr(phase_x[23:14]),.data(sx));
 sine_rom y_sine(.clk(clk),.addr(phase_y[23:14]),.data(sy));
 reg signed [32:0] product_x=0,product_y=0;
 wire signed [17:0] scaled_x=18'sd128+(product_x>>>24),scaled_y=18'sd128-(product_y>>>24);
 wire [7:0] next_x=scaled_x<0?0:scaled_x>255?255:scaled_x[7:0];
 wire [7:0] next_y=scaled_y<0?0:scaled_y>255?255:scaled_y[7:0];
 reg [7:0] previous_x=128,previous_y=128,line_x=128,line_y=128,target_x=128,target_y=128;
 reg [8:0] dx=0,dy=0;reg direction_x=0,direction_y=0;
 reg signed [10:0] error=0;
 wire signed [11:0] twice_error=$signed(error)*2;
 wire move_x=twice_error>-$signed({1'b0,dy});wire move_y=twice_error<$signed({1'b0,dx});
 wire [8:0] distance_x=next_x>previous_x?next_x-previous_x:previous_x-next_x;
 wire [8:0] distance_y=next_y>previous_y?next_y-previous_y:previous_y-next_y;
 wire [2:0] stencil_last=pass==2?3'd6:pass==1?3'd2:3'd0;
 wire signed [10:0] write_x=$signed({1'b0,line_x})+$signed({1'b0,stencil_x})-(pass==2?11'sd3:pass==1?11'sd1:11'sd0);
 wire signed [10:0] write_y=$signed({1'b0,line_y})+$signed({1'b0,stencil_y})-(pass==2?11'sd3:pass==1?11'sd1:11'sd0);
 wire stencil_done=stencil_x==stencil_last&&stencil_y==stencil_last;
 reg bitmap[0:131071];
 always @(posedge clk)begin
  if(!rst&&state==CLEAR)bitmap[{bank,clear_addr}]<=0;
  else if(!rst&&state==DRAW&&write_x>=0&&write_x<=255&&write_y>=0&&write_y<=255)bitmap[{bank,write_y[7:0],write_x[7:0]}]<=1;
  product_x<=sx*$signed({1'b0,frame_envelope});product_y<=sy*$signed({1'b0,frame_envelope});
  ack_sync<={ack_sync[0],ack};
  if(rst)begin
   state<=CLEAR;bank<=1;publish<=0;clear_addr<=0;count<=0;previous_valid<=0;ack_sync<=0;
   base_phase<=0;phase_offset<=24'h400000;settings<=6'b101000;frame_phase<=24'h400000;frame_head<=0;sample_phase<=0;
   frame_envelope<=0;frame_active<=0;pass<=0;stencil_x<=0;stencil_y<=0;
  end else begin
   if(sample_tick)begin
    if(active&&note_step!=0)begin base_phase<=base_phase+visual_step;if(settings[5])phase_offset<=phase_offset+24'd64;end
    else base_phase<=0;
   end
   case(state)
    CLEAR:begin
     // Capture ALL frame controls once; they remain stable through ACK.
     if(clear_addr==0)begin
      if(settings!=requested_config)begin phase_offset<=phase_value(requested_config[4:2]);frame_phase<=phase_value(requested_config[4:2]);end
      else frame_phase<=phase_offset;
      settings<=requested_config;frame_head<=base_phase;
      frame_envelope<=16'd32768+{1'b0,envelope[15:1]};frame_active<=active&&note_step!=0;
     end
     if(clear_addr==65535)begin clear_addr<=0;count<=0;previous_valid<=0;pass<=0;sample_phase<=0;state<=CAPTURE;end else clear_addr<=clear_addr+1'b1;
    end
    CAPTURE:if(frame_active)state<=WAIT0;else state<=PUBLISH;
    WAIT0:state<=WAIT1;
    WAIT1:state<=POINT;
    POINT:begin
     target_x<=next_x;target_y<=next_y;stencil_x<=0;stencil_y<=0;
     if(previous_valid)begin line_x<=previous_x;line_y<=previous_y;dx<=distance_x;dy<=distance_y;error<=$signed({1'b0,distance_x})-$signed({1'b0,distance_y});end
     else begin line_x<=next_x;line_y<=next_y;dx<=0;dy<=0;error<=0;end
     direction_x<=previous_x<next_x;direction_y<=previous_y<next_y;state<=DRAW;
    end
    DRAW:begin
     if(!stencil_done)begin
      if(stencil_x==stencil_last)begin stencil_x<=0;stencil_y<=stencil_y+1'b1;end else stencil_x<=stencil_x+1'b1;
     end else begin
      stencil_x<=0;stencil_y<=0;
      if(line_x==target_x&&line_y==target_y)begin
       previous_x<=target_x;previous_y<=target_y;previous_valid<=1;
       if(pass==0&&count==POINTS)begin pass<=1;count<=0;previous_valid<=0;sample_phase<=frame_head-24'h100000;state<=CAPTURE;end
       else if(pass==1&&count==8)begin pass<=2;previous_valid<=0;sample_phase<=frame_head;state<=CAPTURE;end
       else if(pass==2)state<=PUBLISH;
       else begin
        count<=count+1'b1;
        if(pass==0)sample_phase<=count==POINTS-1?24'd0:sample_phase+CURVE_STEP;
        else sample_phase<=sample_phase+24'h020000;
        state<=CAPTURE;
       end
      end else begin
       if(move_x)line_x<=direction_x?line_x+1'b1:line_x-1'b1;
       if(move_y)line_y<=direction_y?line_y+1'b1:line_y-1'b1;
       error<=error+(move_x?-$signed({1'b0,dy}):0)+(move_y?$signed({1'b0,dx}):0);
      end
     end
    end
    PUBLISH:begin publish<=~publish;state<=WAIT_ACK;end
    WAIT_ACK:if(ack_sync[1]==publish)begin bank<=~bank;state<=CLEAR;clear_addr<=0;end
    default:state<=CLEAR;
   endcase
  end
 end
 always @(posedge pixel_clk)data<=bitmap[{display_bank,read_addr}];
 always @(posedge pixel_clk or negedge pixel_rstn)begin
  if(!pixel_rstn)begin publish_sync<=0;seen<=0;ack<=0;display_bank<=0;valid<=0;shown_config<=0;end
  else begin
   publish_sync<={publish_sync[0],publish};
   if(frame_start&&publish_sync[1]!=seen)begin seen<=publish_sync[1];ack<=publish_sync[1];display_bank<=bank;shown_config<=settings;valid<=1;end
  end
 end
endmodule
