module Gowin_PLL(
    input  clkin,
    output clkout0,
    output clkout1,
    output lock,
    input  mdclk
);

// 50 MHz input, 1025 MHz VCO, 51.25/256.25 MHz EDID-native video clocks.
// PLL_INIT must run from a real 50 MHz management clock on GW5AT.
wire [7:0] mdrdo;
wire [7:0] mdwdi;
wire [1:0] mdopc;
wire mdainc;
wire pll_reset;
wire pll_lock;


    Gowin_PLL_MOD u_pll(
        .clkout1(clkout1),
        .clkout0(clkout0),
        .lock(pll_lock),
        .mdrdo(mdrdo),
        .clkin(clkin),
        .reset(pll_reset),
        .mdclk(mdclk),
        .mdopc(mdopc),
        .mdainc(mdainc),
        .mdwdi(mdwdi)
    );
    PLL_INIT #(.CLK_PERIOD(20), .MULTI_FAC(21)) u_pll_init (
        .I_RST(1'b0), .I_MD_CLK(mdclk),
        .O_RST(pll_reset), .I_LOCK(pll_lock), .O_LOCK(lock),
        .O_MD_INC(mdainc), .O_MD_OPC(mdopc), .O_MD_WR_DATA(mdwdi),
        .I_MD_RD_DATA(mdrdo), .PLL_INIT_BYPASS(1'b0),
        .MDRDO(), .MDOPC(2'b00), .MDAINC(1'b0), .MDWDI(8'h00)
    );
endmodule
