`timescale 1ns/1ps
module keyboard_top #(
 parameter integer ENABLE_PERFORMANCE=0, SHARED_SONG=0, PROJECT3=0,DIRECT_PCM=0,EVENT_SONG=0,TONE_REFINEMENT=0,CONTROLLED_MIX=0,ADVANCED_MODULATION=0,ADVANCED_EFFECTS=0,FM_EDITING=0,AUDITION_PREPARE=0,PITCH_METADATA=0,
 parameter integer POWER_WAIT_TICKS=2500000,RETRY_TICKS=500000,
 parameter integer CAL_BITS=6,DEBOUNCE_TICKS=50000,
 parameter integer HEARTBEAT_TICKS=25000000,FAULT_SLOT_TICKS=12500000
)(
 input wire audition_hold,audition_reset,output wire fx_ready,
 input wire[223:0]fm_cfg,
 input wire[415:0]fx_cfg,input wire fx_panic,output wire[111:0]fx_nodes,output wire[63:0]fx_delays,
 input wire[191:0]mod_cfg,
 input wire [511:0] cfg,input wire [1:0] test_mode,input wire [141:0] mix_cfg,
 input wire sys_clk,key2_n,key1_n,adc_busy,adc_douta,rst_ext,
 input wire song_mode,song_clear,input wire [3:0] song_gates,
 input wire [95:0] song_steps,input wire [47:0] song_gains,
 input wire [6:0] event_gates,event_triggers,input wire [167:0] event_steps,input wire [83:0] event_gains,
 input wire [15:0] function_press,matrix_keys,input wire matrix_ghost,recalibrate,
 output wire [63:0] control_state,output wire [6:0] teaching_note,
 output wire [3:0] teaching_progress,
 output wire adc_reset,adc_convst,adc_cs_n,adc_sclk,
 output wire hp_bck,hp_ws,hp_din,pa_en,i2s_bck,i2s_ws,i2s_sd,
 output wire signed [15:0] audio_pcm,output wire [111:0] audio_voices,audio_post_voices,
 output wire[167:0]audio_render_steps,output wire[6:0]audio_render_active,
 output wire[223:0]modulation_coefficients,output wire[31:0]modulation_flags,output wire[15:0]modulation_gain,
 output wire audio_sample_tick,
 output wire [7:0] led_o,
 output wire [127:0] monitor_raw,output wire [83:0] monitor_pressures,
 output wire [111:0] monitor_envelopes,output wire [20:0] monitor_phases,
 output wire [167:0] monitor_steps,output wire [18:0] monitor_ratio,
 output wire [6:0] monitor_gates,monitor_active,
 output wire monitor_ready,monitor_fault,
 output wire [6:0] monitor_armed,monitor_calibrated,
 output wire [2:0] monitor_fault_code,output wire monitor_sample_valid,
 output reg [15:0] monitor_frame_count=0
);
 reg [5:0] power_on=0;
 always @(posedge sys_clk)power_on<={power_on[4:0],1'b1};
 wire rst=rst_ext||~power_on[5];
 wire key2_press;
 project_button #(.TICKS(DEBOUNCE_TICKS)) k2(.clk(sys_clk),.rst(rst),.key_n(key2_n),.press(key2_press));
 reg running=1;
 always @(posedge sys_clk)begin
  if(rst)running<=1;
  else if(key2_press)running<=~running;
 end
 wire do_recalibrate=ENABLE_PERFORMANCE&&recalibrate;
 wire [127:0] frame_raw;
 wire signed [15:0] ch8_raw;
 wire frame_valid,sample_valid,fault;
 wire [2:0] fault_code;
 ad7606_serial_rx #(.POWER_WAIT_TICKS(POWER_WAIT_TICKS),.RETRY_TICKS(RETRY_TICKS)) receiver(
  .clk(sys_clk),.rst(rst),.busy_in(adc_busy),.douta_in(adc_douta),
  .adc_reset(adc_reset),.convst(adc_convst),.cs_n(adc_cs_n),.sclk(adc_sclk),
  .frame_raw(frame_raw),.ch8_raw(ch8_raw),.frame_valid(frame_valid),
  .sample_valid(sample_valid),.fault(fault),.fault_code(fault_code));
 wire [6:0] calibrated,armed,gates,voice_active;
 wire [83:0] pressures;
 genvar p;
 generate for(p=0;p<7;p=p+1)begin:pads
  wire [15:0] idle_raw,filtered_raw;
  pad_control #(.CAL_BITS(CAL_BITS),.ENABLE_RECOVERY(ENABLE_PERFORMANCE)) control(
   .clk(sys_clk),.rst(rst),.frame_valid(frame_valid),.sample_valid(sample_valid),.fault(fault),.recalibrate(do_recalibrate),
   .raw($signed(frame_raw[127-p*16 -:16])),.calibrated(calibrated[p]),.armed(armed[p]),
   .gate(gates[p]),.pressure(pressures[p*12+:12]),.idle_raw(idle_raw),.filtered_raw(filtered_raw));
 end endgenerate
 wire ready=&calibrated;

 assign monitor_armed=armed;assign monitor_calibrated=calibrated;
 assign monitor_fault_code=fault_code;assign monitor_sample_valid=sample_valid;
 always @(posedge sys_clk)if(rst)monitor_frame_count<=0;else if(frame_valid)monitor_frame_count<=monitor_frame_count+1'b1;
 assign monitor_raw=frame_raw;
 assign monitor_pressures=pressures;
 assign monitor_gates=gates;
 assign monitor_active=voice_active;
 assign monitor_ready=ready;
 assign monitor_fault=fault;
 wire sample_tick;
 assign audio_sample_tick=sample_tick;
 wire [18:0] ratio;
 assign monitor_ratio=ratio;
 wire [15:0] slider_raw;
 slider_control slider(.clk(sys_clk),.rst(rst),.frame_valid(frame_valid),
  .sample_valid(sample_valid),.fault(fault),.sample_tick(sample_tick),
  .raw($signed(frame_raw[15:0])),.ratio(ratio),.filtered_raw(slider_raw));
 wire [6:0] effective_gates,teaching_led;
 wire [83:0] effective_pressures;wire [18:0] effective_ratio;
 wire [13:0] performance_settings;wire clear_notes;
 generate if(ENABLE_PERFORMANCE)begin:performance
  performance_controls #(.EXCLUSIVE_MODES(EVENT_SONG)) controller(.clk(sys_clk),.rst(rst),.sample_tick(sample_tick),.fault(fault||do_recalibrate),
   .function_press(function_press),.matrix_keys(matrix_keys),.matrix_ghost(matrix_ghost),
   .gates(gates),.pressures(pressures),.ratio(ratio),
   .out_gates(effective_gates),.out_pressures(effective_pressures),.out_ratio(effective_ratio),
   .settings(performance_settings),.control_state(control_state),.clear_notes(clear_notes),
   .teaching_note(teaching_note),.teaching_led(teaching_led),.teaching_progress(teaching_progress));
 end else begin:legacy
  assign effective_gates=gates;assign effective_pressures=pressures;assign effective_ratio=ratio;
  assign performance_settings=0;assign control_state=0;assign clear_notes=0;
  assign teaching_note=127;assign teaching_led=0;assign teaching_progress=0;
 end endgenerate
 keyboard_audio #(.ENABLE_PERFORMANCE(ENABLE_PERFORMANCE),.SHARED_SONG(SHARED_SONG),.PROJECT3(PROJECT3),.DIRECT_PCM(DIRECT_PCM),.EVENT_SONG(EVENT_SONG),.TONE_REFINEMENT(TONE_REFINEMENT),.CONTROLLED_MIX(CONTROLLED_MIX),.ADVANCED_MODULATION(ADVANCED_MODULATION),.ADVANCED_EFFECTS(ADVANCED_EFFECTS),.FM_EDITING(FM_EDITING),.AUDITION_PREPARE(AUDITION_PREPARE),.PITCH_METADATA(PITCH_METADATA)) audio(
  .audition_hold(audition_hold),.audition_reset(audition_reset),.fx_ready(fx_ready),
  .fm_cfg(fm_cfg),
  .fx_cfg(fx_cfg),.fx_panic(fx_panic),.fx_nodes(fx_nodes),.fx_delays(fx_delays),
  .mod_cfg(mod_cfg),.cfg(cfg),.test_mode(test_mode),.mix_cfg(mix_cfg),
  .song_mode(song_mode),.song_clear(song_clear),.song_gates(song_gates),.song_steps(song_steps),.song_gains(song_gains),.clk(sys_clk),.rst(rst),.running(running),.ready(ready),.fault(fault),
  .event_gates(event_gates),.event_steps(event_steps),.event_gains(event_gains),.event_triggers(event_triggers),
  .gates(effective_gates),.pressures(effective_pressures),.ratio(effective_ratio),.clear_notes(clear_notes||do_recalibrate),.settings(performance_settings),.voice_active(voice_active),
  .sample_tick(sample_tick),.hp_bck(hp_bck),.hp_ws(hp_ws),.hp_din(hp_din),
  .i2s_bck(i2s_bck),.i2s_ws(i2s_ws),.i2s_sd(i2s_sd),
  .modulation_coefficients(modulation_coefficients),.modulation_flags(modulation_flags),.modulation_gain(modulation_gain),
  .pcm_out(audio_pcm),.voice_samples(audio_voices),.post_voice_samples(audio_post_voices),.render_steps(audio_render_steps),.render_active(audio_render_active),
  .monitor_steps(monitor_steps),.monitor_envelopes(monitor_envelopes),.monitor_phases(monitor_phases));
 assign pa_en=1'b0;
 reg [24:0] heartbeat_count=0;
 reg heartbeat=0;
 always @(posedge sys_clk)begin
  if(rst)begin heartbeat_count<=0;heartbeat<=0;end
  else if(heartbeat_count==HEARTBEAT_TICKS-1)begin heartbeat_count<=0;heartbeat<=~heartbeat;end
  else heartbeat_count<=heartbeat_count+1'b1;
 end
 wire fault_light;
 project_fault_led #(.SLOT_TICKS(FAULT_SLOT_TICKS)) indication(
  .clk(sys_clk),.rst(rst),.fault(fault),.code(fault_code),.light(fault_light));
 assign led_o=~{fault ? fault_light : heartbeat,(control_state[13]?teaching_led:voice_active)};
endmodule
