`timescale 1ns/1ps
// 16-bit stereo I2S: WS=0 left, WS=1 right; MSB one BCK after WS.
// All logic runs at clk; BCK is a registered output, not an FPGA fabric clock.
module i2s_tx16 #(parameter integer HALF_DIV=16)(
    input wire clk, input wire rst,
    input wire [15:0] pcm_l, pcm_r,
    output reg bck=1'b1, output reg ws=1'b1, output reg sd=1'b0,
    output wire sample_tick
);
    reg [7:0] div_count=0;
    reg [4:0] slot=0;
    reg [15:0] hold_l=0, hold_r=0;
    // Predict the next counter state so the registered tick has EXACTLY the
    // original phase, including the first frame. Reset spans a clock edge as
    // required by this transmitter's existing synchronous counters.
    generate if(HALF_DIV>=2)begin:registered_tick
        (* syn_preserve=1 *) reg tick_q=0;
        always @(posedge clk or posedge rst)
            if(rst)tick_q<=0;
            else tick_q<=div_count==HALF_DIV-2&&bck&&slot==0;
        assign sample_tick=tick_q;
    end else begin:single_clock_half_period
        assign sample_tick=!rst&&div_count==HALF_DIV-1&&bck&&slot==0;
    end endgenerate
    always @(posedge clk) begin
        if (rst) begin
            div_count<=0; slot<=0; bck<=1; ws<=1; sd<=0;
            hold_l<=0; hold_r<=0;
        end else if (div_count==HALF_DIV-1) begin
            div_count<=0; bck<=~bck;
            if (bck) begin
                ws<=slot[4];
                // Slot 0 carries the previous RIGHT LSB, while WS changes LEFT.
                // Slot 16 carries LEFT LSB, while WS changes RIGHT.
                if (slot==0) begin
                    sd<=hold_r[0]; hold_l<=pcm_l; hold_r<=pcm_r;
                end else if (slot<=16) sd<=hold_l[16-slot];
                else sd<=hold_r[32-slot];
                slot<=slot+1'b1;
            end
        end else div_count<=div_count+1'b1;
    end
endmodule

// Same-clk internal serial receiver. NOT an asynchronous external I2S receiver.
// It has no connection to the source PCM: only the three serial signals enter.
module i2s_rx16(
    input wire clk, input wire rst, input wire bck, ws, sd,
    output reg [15:0] pcm_l=0,
    output reg [15:0] pcm_r=0,
    output reg frame_valid=0
);
    reg bck_q=1, ws_q=1, channel=0, started=0, have_l=0;
    reg [4:0] count=0;
    reg [15:0] shift=0, pending_l=0;
    always @(posedge clk) begin
        frame_valid<=0;
        if (rst) begin
            bck_q<=1; ws_q<=1; channel<=0; started<=0; have_l<=0;
            count<=0; shift<=0; pending_l<=0; pcm_l<=0; pcm_r<=0;
        end else begin
            bck_q<=bck;
            if (!bck_q && bck) begin
                // The bit at a WS transition still belongs to the OLD channel.
                if (started && count<16) begin
                    shift<={shift[14:0],sd}; count<=count+1'b1;
                    if (count==15) begin
                        if (!channel) begin
                            pending_l<={shift[14:0],sd}; have_l<=1;
                        end else if (have_l) begin
                            pcm_l<=pending_l; pcm_r<={shift[14:0],sd};
                            frame_valid<=1;
                        end
                    end
                end
                if (ws!=ws_q) begin
                    ws_q<=ws; channel<=ws; count<=0; started<=1;
                end
            end
        end
    end
endmodule

// Board-specific PT8211 Japanese/LSBJ adapter, preserves the audible baseline:
// 16 BCK/channel, WS=0 RIGHT, WS=1 LEFT; no I2S one-bit delay at the DAC pins.
module pt8211_tx16 #(parameter integer HALF_DIV=16)(
    input wire clk, input wire rst,
    input wire [15:0] pcm_l, pcm_r,
    output reg bck=1, output reg ws=0, output reg sd=0
);
    reg [7:0] div_count=0;
    reg [4:0] slot=0;
    reg [15:0] hold_l=0, hold_r=0;
    always @(posedge clk) begin
        if (rst) begin
            div_count<=0; slot<=0; bck<=1; ws<=0; sd<=0; hold_l<=0; hold_r<=0;
        end else if (div_count==HALF_DIV-1) begin
            div_count<=0; bck<=~bck;
            if (bck) begin
                ws<=slot[4];
                if (slot==0) begin
                    hold_l<=pcm_l; hold_r<=pcm_r; sd<=pcm_r[15];
                end else if (!slot[4]) sd<=hold_r[15-slot[3:0]];
                else sd<=hold_l[15-slot[3:0]];
                slot<=slot+1'b1;
            end
        end else div_count<=div_count+1'b1;
    end
endmodule
