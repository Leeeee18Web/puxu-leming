`timescale 1ns/1ps
// Physical expression is transformed into synthesizer events before recording.
// 256 events packed as 1024 x 28-bit RAM words: milliseconds, settings, bend,
// seven 8-bit pressure values, seven gates. No PCM samples or SD writes.
module performance_controls #(
 parameter integer CLOCK_HZ=50000000, EVENT_DEPTH=256, RECORD_LIMIT_MS=60000,
 parameter integer EXCLUSIVE_MODES=0
)(
 input wire clk,rst,sample_tick,fault,
 input wire [15:0] function_press,matrix_keys,input wire matrix_ghost,
 input wire [6:0] gates,input wire [83:0] pressures,input wire [18:0] ratio,
 output wire [6:0] out_gates,output wire [83:0] out_pressures,
 output wire [18:0] out_ratio,output wire [13:0] settings,
 output wire [63:0] control_state,output reg clear_notes=0,
 output wire [6:0] teaching_note,teaching_led,output reg [3:0] teaching_progress=0
);
 localparam integer MS_TICKS=CLOCK_HZ/1000;
 reg [31:0] ms_counter=0;wire ms_tick=ms_counter==MS_TICKS-1;
 always @(posedge clk)if(rst||ms_tick)ms_counter<=0;else ms_counter<=ms_counter+1'b1;
 reg [13:0] live_settings=0;
 reg [4:0] last_key=0;
 reg [6:0] blocked=0,last_gates=0,sustained=0,pluck_gates=0;
 reg [83:0] held_pressures=0;
 wire [6:0] safe_gates=gates&~blocked;
 wire [6:0] note_rise=safe_gates&~last_gates;
 reg [8:0] bpm=120;reg [15:0] beat_ms=500,tap_elapsed=0;
 reg tapped=0;reg [4:0] divide_left=0;
 reg [15:0] quotient=0,divisor=500;reg [16:0] remainder=0;
 wire [16:0] trial={remainder[15:0],quotient[15]};
 // One captured gesture. Gate pulses do not reset previous voices' tails.
 reg [6:0] pluck_pending=0;
 reg [83:0] pluck_snapshot=0,pluck_pressures=0;
 reg [6:0] pluck_hold[0:6];
 reg [6:0] pluck_left=0;
 reg [3:0] pluck_strength=8;
 reg [1:0] pluck_settle=0;
 reg [31:0] pluck_phase=0;
 wire pluck_ms_tick=pluck_phase==MS_TICKS-1;
 // Start the spacing timebase at each attack, independent of global ms phase.
 always @(posedge clk)if(rst||pluck_left==0||pluck_ms_tick)pluck_phase<=0;
 else pluck_phase<=pluck_phase+1'b1;
 reg [15:0] arp_ms=0;reg [2:0] arp_index=0;
 reg teaching=0,recording=0,replaying=0,record_full=0;
 reg [10:0] event_count=0,play_index=0;
 reg [15:0] record_ms=0,record_length=0,play_ms=0;
 reg [4:0] expression_ms=0;
 reg store_write=0,store_read=0;
 reg [10:0] store_write_index=0,store_read_index=0;
 reg [111:0] store_write_entry=0;
 wire [111:0] store_read_entry;wire store_read_valid,store_busy;
 performance_event_store #(.EVENT_DEPTH(EVENT_DEPTH)) event_store(
  .clk(clk),.rst(rst),.write_request(store_write),.write_index(store_write_index),.write_entry(store_write_entry),
  .read_request(store_read),.read_index(store_read_index),.read_entry(store_read_entry),.read_valid(store_read_valid),.busy(store_busy));
 reg [111:0] play_entry=0;
 reg [95:0] replay_event=0,last_event=0;
 reg read_wait=0,read_pending=0,entry_valid=0;
 integer i;
 function [2:0] lesson_index;
 input [3:0] pos;
 begin case(pos)
 0,1,13:lesson_index=0;
 2,3,6:lesson_index=4;
 4,5:lesson_index=5;
 7,8:lesson_index=3;
 9,10:lesson_index=2;
 default:lesson_index=1;
 endcase end
 endfunction
 wire [2:0] expected_index=lesson_index(teaching_progress);
 assign teaching_led=teaching?(7'b1<<expected_index):0;
 assign teaching_note=!teaching?127:expected_index==0?60:expected_index==1?62:expected_index==2?64:expected_index==3?65:expected_index==4?67:expected_index==5?69:71;
 // C-major diatonic triads, wrapping within the seven physical voice slots.
 reg [6:0] chord_gates;
 reg [6:0] raw_notes;
 reg [11:0] chord_pressure=0;
 reg [11:0] max01=0,max23=0,max45=0,max6=0,max03=0,max46=0;
 wire [11:0] candidate_pressure[0:6];
 wire[6:0]candidate_active=safe_gates|((live_settings[8]&&!live_settings[10])?sustained:7'd0);
 function[11:0]max_valid;input[11:0]a,b;input va,vb;
 reg take_a,take_b;begin
  take_a=va&&(!vb||a>b);take_b=vb&&(!va||a<=b);
  max_valid=({12{take_a}}&a)|({12{take_b}}&b);
 end endfunction
 genvar m;
 generate for(m=0;m<7;m=m+1)begin:pressure_candidates
  assign candidate_pressure[m]=(live_settings[10]?safe_gates[m]:raw_notes[m])?held_pressures[m*12+:12]:12'd0;
 end endgenerate
 // Balanced three-stage tree: no serial seven-comparator critical path.
 always @(posedge clk)begin
  if(rst)begin max01<=0;max23<=0;max45<=0;max6<=0;max03<=0;max46<=0;chord_pressure<=0;end
  else begin
   max01<=max_valid(held_pressures[0+:12],held_pressures[12+:12],candidate_active[0],candidate_active[1]);
   max23<=max_valid(held_pressures[24+:12],held_pressures[36+:12],candidate_active[2],candidate_active[3]);
   max45<=max_valid(held_pressures[48+:12],held_pressures[60+:12],candidate_active[4],candidate_active[5]);
   max6<=candidate_pressure[6];
   max03<=max01>max23?max01:max23;max46<=max45>max6?max45:max6;
   chord_pressure<=max03>max46?max03:max46;
  end
 end
 reg [6:0] prepared_gates;
 reg [83:0] prepared_pressures;

 reg [2:0] chosen,next_arp;
 reg [2:0] next_arp_registered=0;
 reg [6:0] higher_notes;
 integer j;
 function [2:0] first_note;
 input [6:0] notes;
 begin
  if(notes[0])first_note=0;else if(notes[1])first_note=1;
  else if(notes[2])first_note=2;else if(notes[3])first_note=3;
  else if(notes[4])first_note=4;else if(notes[5])first_note=5;
  else if(notes[6])first_note=6;else first_note=0;
 end
 endfunction
 function [2:0] highest_note;
 input [6:0] notes;
 begin
  if(notes[6])highest_note=6;else if(notes[5])highest_note=5;
  else if(notes[4])highest_note=4;else if(notes[3])highest_note=3;
  else if(notes[2])highest_note=2;else if(notes[1])highest_note=1;
  else highest_note=0;
 end
 endfunction
 reg [6:0] pluck_selection;
 always @*begin
  pluck_selection=safe_gates;
  for(integer k=0;k<7;k=k+1)if(safe_gates[k]&&live_settings[12])begin
   pluck_selection[(k+2)%7]=1'b1;pluck_selection[(k+4)%7]=1'b1;
  end
 end
 wire [2:0] pluck_next=highest_note(pluck_pending);
 // A single shared multiplier, pipelined before the first audio sample.
 reg [2:0] pluck_next_q=0;
 reg [15:0] pluck_force_q=0;
 always @(posedge clk)begin
  pluck_next_q<=pluck_next;
  pluck_force_q<=pluck_snapshot[pluck_next*12+:12]*pluck_strength;
 end
 always @(posedge clk)if(rst)next_arp_registered<=0;else next_arp_registered<=next_arp;
 always @*begin
  raw_notes=live_settings[10]?pluck_gates:(safe_gates|(live_settings[8]?sustained:7'd0));
  chord_gates=raw_notes;
  for(j=0;j<7;j=j+1)begin
   if(raw_notes[j]&&live_settings[12]&&!live_settings[10])begin
    chord_gates[(j+2)%7]=1'b1;chord_gates[(j+4)%7]=1'b1;
   end
  end
  chosen=chord_gates[arp_index]?arp_index:first_note(chord_gates);
  // Constant comparisons replace seven variable modulo/mux chains.
  higher_notes=0;
  for(j=1;j<7;j=j+1)higher_notes[j]=chord_gates[j]&&(chosen<j);
  next_arp=first_note((|higher_notes)?higher_notes:chord_gates);
  // Select the held arp note or the lowest note directly in one-hot form.
  // Avoid the pressure-gate priority encoder followed by a barrel decoder.
  for(j=0;j<7;j=j+1)begin
   prepared_gates[j]=chord_gates[j]&&
    (!(live_settings[11]&&!live_settings[10])||
      arp_index==j||(!chord_gates[arp_index]&&!(|(chord_gates&((7'b1<<j)-1'b1)))));
  end
  for(j=0;j<7;j=j+1)begin
   prepared_pressures[j*12+:12]=safe_gates[j]?pressures[j*12+:12]:held_pressures[j*12+:12];
   if(!raw_notes[j]&&chord_gates[j])prepared_pressures[j*12+:12]=chord_pressure;
   if(live_settings[10])prepared_pressures[j*12+:12]=pluck_pressures[j*12+:12];
  end
 end
 wire [55:0] quant_pressure;
 genvar p;
 generate for(p=0;p<7;p=p+1)begin:packing
  assign quant_pressure[p*8+:8]=prepared_pressures[p*12+4+:8];
  assign out_pressures[p*12+:12]=replaying?{replay_event[7+p*8+:8],4'd0}:prepared_pressures[p*12+:12];
 end endgenerate
 wire [95:0] current_event={live_settings,ratio,quant_pressure,prepared_gates};
 reg [95:0] event_stage0=0,event_stage1=0;
 reg [5:0] changed_groups=0;reg notes_changed=0,settings_changed=0;
 // Comparators use a registered coherent snapshot, and their reductions are
 // registered separately. This isolates RAM CE and record counters from audio.
 always @(posedge clk)begin
  if(rst)begin event_stage0<=0;event_stage1<=0;changed_groups<=0;notes_changed<=0;settings_changed<=0;end
  else begin
   event_stage0<=current_event;event_stage1<=event_stage0;
   changed_groups[0]<=event_stage0[15:0]!=last_event[15:0];
   changed_groups[1]<=event_stage0[31:16]!=last_event[31:16];
   changed_groups[2]<=event_stage0[47:32]!=last_event[47:32];
   changed_groups[3]<=event_stage0[63:48]!=last_event[63:48];
   changed_groups[4]<=event_stage0[79:64]!=last_event[79:64];
   changed_groups[5]<=event_stage0[95:80]!=last_event[95:80];
   notes_changed<=event_stage0[6:0]!=last_event[6:0];
   settings_changed<=event_stage0[95:82]!=last_event[95:82];
  end
 end
 assign settings=replaying?replay_event[95:82]:live_settings;
 assign out_ratio=replaying?replay_event[81:63]:ratio;
 assign out_gates=fault?7'd0:replaying?replay_event[6:0]:prepared_gates;
 // Preserve every existing external field; bit 59 was reserved.
 assign control_state={4'd0,settings[13],matrix_keys,matrix_ghost,last_key,record_full,event_count,bpm,replaying,recording,teaching,settings[12:0]};
 always @(posedge clk)begin
  clear_notes<=0;store_write<=0;store_read<=0;
  if(rst)begin
   live_settings<=0;last_key<=0;blocked<=0;last_gates<=0;sustained<=0;held_pressures<=0;
   bpm<=120;beat_ms<=500;tap_elapsed<=0;tapped<=0;divide_left<=0;quotient<=0;remainder<=0;divisor<=500;
   pluck_left<=0;pluck_gates<=0;pluck_pending<=0;pluck_snapshot<=0;pluck_pressures<=0;pluck_strength<=8;pluck_settle<=0;
   for(i=0;i<7;i=i+1)pluck_hold[i]<=0;
   arp_ms<=0;arp_index<=0;teaching<=0;teaching_progress<=0;
   recording<=0;replaying<=0;record_full<=0;event_count<=0;play_index<=0;
   record_ms<=0;record_length<=0;play_ms<=0;expression_ms<=0;play_entry<=0;replay_event<=0;last_event<=0;read_wait<=0;read_pending<=0;entry_valid<=0;store_write_index<=0;store_read_index<=0;store_write_entry<=0;
  end else begin
   blocked<=blocked&gates;last_gates<=safe_gates;
   if(!live_settings[8])sustained<=safe_gates;else sustained<=sustained|safe_gates;
   for(i=0;i<7;i=i+1)if(safe_gates[i])held_pressures[i*12+:12]<=pressures[i*12+:12];
   // First note starts within clocks of S10, rather than waiting a millisecond.
   // Pipeline index/data must match the current pending note and strength.
   if(pluck_settle!=0)pluck_settle<=pluck_settle-1'b1;
   if(pluck_ms_tick&&pluck_left!=0)pluck_left<=pluck_left-1'b1;
   if(live_settings[10]&&!replaying&&pluck_pending!=0&&pluck_left==0&&pluck_settle==0&&pluck_next_q==pluck_next)begin
    pluck_gates[pluck_next]<=1;pluck_hold[pluck_next]<=72;
    pluck_pressures[pluck_next*12+:12]<=pluck_force_q[14:3];
    pluck_pending[pluck_next]<=0;pluck_left<=90;
    if(pluck_strength>2)pluck_strength<=pluck_strength-1'b1;
   end
   if(teaching&&note_rise[expected_index])begin
    if(teaching_progress==13)begin teaching<=0;teaching_progress<=14;end
    else teaching_progress<=teaching_progress+1'b1;
   end
   if(divide_left!=0)begin
    if(trial>={1'b0,divisor})begin remainder<=trial-{1'b0,divisor};quotient<={quotient[14:0],1'b1};end
    else begin remainder<=trial;quotient<={quotient[14:0],1'b0};end
    divide_left<=divide_left-1'b1;
    if(divide_left==1)begin
     if({quotient[7:0],trial>={1'b0,divisor}}<30)bpm<=30;
     else if({quotient[7:0],trial>={1'b0,divisor}}>300)bpm<=300;
     else bpm<={quotient[7:0],trial>={1'b0,divisor}};
    end
   end
   if(ms_tick)begin
    if(tap_elapsed<3000)tap_elapsed<=tap_elapsed+1'b1;else tapped<=0;
    for(i=0;i<7;i=i+1)if(pluck_hold[i]!=0)begin
     pluck_hold[i]<=pluck_hold[i]-1'b1;
     if(pluck_hold[i]==1)pluck_gates[i]<=0;
    end
    if(!live_settings[11])begin arp_ms<=0;arp_index<=chosen;end
    else if(arp_ms>=(beat_ms>>1)-1'b1)begin arp_ms<=0;arp_index<=next_arp_registered;end
    else arp_ms<=arp_ms+1'b1;
    if(recording)begin
     if(record_ms>=RECORD_LIMIT_MS)begin recording<=0;record_length<=record_ms;end
     else begin
      record_ms<=record_ms+1'b1;
      if(expression_ms==19)expression_ms<=0;else expression_ms<=expression_ms+1'b1;
      if(!store_busy && (event_count==0 || ((|changed_groups) && (notes_changed || settings_changed || expression_ms==19))))begin
       if(event_count<EVENT_DEPTH)begin
        store_write<=1;store_write_index<=event_count;store_write_entry<={record_ms,event_stage1};event_count<=event_count+1'b1;last_event<=event_stage1;
        if(event_count==EVENT_DEPTH-1)begin recording<=0;record_full<=1;record_length<=record_ms+1'b1;end
       end else begin recording<=0;record_full<=1;record_length<=record_ms;end
      end
     end
    end
    if(replaying)begin
     if(play_ms>=record_length)begin replaying<=0;replay_event<=0;clear_notes<=1;blocked<=gates;sustained<=0;pluck_gates<=0;end
     else play_ms<=play_ms+1'b1;
    end
   end
   // Four narrow synchronous RAM reads reconstruct each event. Prefetch is
   // completed long before the following 1 ms deadline, without a wide RAM port.
   if(replaying)begin
    if(read_wait&&!read_pending&&!store_busy&&!store_write)begin
     if(play_index<event_count)begin store_read<=1;store_read_index<=play_index;read_pending<=1;end
     read_wait<=0;
    end
    if(store_read_valid&&read_pending)begin play_entry<=store_read_entry;entry_valid<=1;read_pending<=0;end
    if(entry_valid&&play_index<event_count&&play_ms>=play_entry[111:96])begin
     replay_event<=play_entry[95:0];play_index<=play_index+1'b1;read_wait<=1;entry_valid<=0;
    end
   end else begin read_pending<=0;entry_valid<=0;end
   for(i=0;i<16;i=i+1)if(function_press[i])last_key<=i+1;
   if(function_press[0])begin
    if({live_settings[13],live_settings[1:0]}>=3'd3){live_settings[13],live_settings[1:0]}<=0;
    else {live_settings[13],live_settings[1:0]}<={live_settings[13],live_settings[1:0]}+3'd1;
   end
   if(function_press[1]&&$signed(live_settings[4:2])> -2)live_settings[4:2]<=$signed(live_settings[4:2])-1'b1;
   if(function_press[2]&&$signed(live_settings[4:2])<2)live_settings[4:2]<=$signed(live_settings[4:2])+1'b1;
   if(function_press[3])live_settings[6:5]<=live_settings[6:5]+1'b1;
   if(function_press[4])live_settings[7]<=~live_settings[7];
   if(function_press[5])begin live_settings[8]<=~live_settings[8];if(live_settings[8])sustained<=0;end
   if(function_press[6])live_settings[9]<=~live_settings[9];
   if(function_press[7])begin
    tap_elapsed<=0;tapped<=1;
    if(tapped&&tap_elapsed>=200&&tap_elapsed<=2000)begin
     beat_ms<=tap_elapsed;divisor<=tap_elapsed;quotient<=60000;remainder<=0;divide_left<=16;
    end
   end
   if(function_press[8])begin
    live_settings[10]<=~live_settings[10];pluck_gates<=0;pluck_left<=0;pluck_pending<=0;clear_notes<=1;
    if(EXCLUSIVE_MODES&&!live_settings[10])begin live_settings[11]<=0;live_settings[12]<=0;end
    for(i=0;i<7;i=i+1)pluck_hold[i]<=0;
   end
   if(function_press[9]&&live_settings[10]&&!replaying)begin
    pluck_pending<=pluck_selection;pluck_gates<=0;pluck_left<=0;pluck_strength<=8;pluck_settle<=3;clear_notes<=1;
    for(i=0;i<7;i=i+1)begin
     pluck_hold[i]<=0;
     pluck_snapshot[i*12+:12]<=safe_gates[i]?pressures[i*12+:12]:chord_pressure;
    end
   end
   if(function_press[10])begin
    live_settings[11]<=~live_settings[11];arp_ms<=0;arp_index<=chosen;
    if(EXCLUSIVE_MODES&&!live_settings[11])begin
     live_settings[10]<=0;live_settings[12]<=0;pluck_pending<=0;pluck_gates<=0;pluck_left<=0;clear_notes<=1;
     for(i=0;i<7;i=i+1)pluck_hold[i]<=0;
    end
   end
   if(function_press[11])begin
    live_settings[12]<=~live_settings[12];
    if(EXCLUSIVE_MODES&&!live_settings[12])begin
     live_settings[10]<=0;live_settings[11]<=0;pluck_pending<=0;pluck_gates<=0;pluck_left<=0;clear_notes<=1;
     for(i=0;i<7;i=i+1)pluck_hold[i]<=0;
    end
   end
   if(function_press[12])begin teaching<=~teaching;teaching_progress<=0;end
   if(function_press[13])begin
    recording<=~recording;replaying<=0;replay_event<=0;
    if(!recording)begin event_count<=0;record_ms<=0;record_full<=0;expression_ms<=0;end
    else record_length<=record_ms;
   end
   if(function_press[14])begin
    recording<=0;
    if(recording)record_length<=record_ms;
    pluck_pending<=0;pluck_gates<=0;pluck_left<=0;
    for(i=0;i<7;i=i+1)pluck_hold[i]<=0;
    if(!replaying&&event_count!=0)begin replaying<=1;play_ms<=0;play_index<=0;replay_event<=0;read_wait<=1;read_pending<=0;entry_valid<=0;clear_notes<=1;end
    else begin replaying<=0;replay_event<=0;clear_notes<=1;blocked<=gates;sustained<=0;pluck_gates<=0;end
   end
   // Panic has highest priority, including simultaneous record/play controls.
   if(fault||function_press[15])begin
    blocked<=gates;sustained<=0;pluck_gates<=0;pluck_left<=0;pluck_pending<=0;
    for(i=0;i<7;i=i+1)pluck_hold[i]<=0;
    recording<=0;replaying<=0;replay_event<=0;teaching<=0;clear_notes<=1;
    live_settings[8]<=0;live_settings[10]<=0;live_settings[11]<=0;live_settings[12]<=0;
    if(recording)record_length<=record_ms;
   end
  end
 end
endmodule


// Four 28-bit words per event use two 18-kbit BSRAMs at depth 1024.
// RAM read/write enables only depend on tiny registered transfer state.
module performance_event_store #(parameter EVENT_DEPTH=256)(
 input wire clk,rst,write_request,read_request,
 input wire [10:0] write_index,read_index,input wire [111:0] write_entry,
 output reg [111:0] read_entry=0,output reg read_valid=0,output wire busy
);
 localparam ADDR_BITS=$clog2(EVENT_DEPTH)+2;
 reg [27:0] memory[0:EVENT_DEPTH*4-1];
 reg writing=0,reading=0,read_pipeline=0;
 reg [ADDR_BITS-1:0] write_address=0,read_address=0;
 reg [111:0] write_buffer=0;
 reg [27:0] read_data=0;reg [1:0] read_word=0;
 assign busy=writing||reading||read_pipeline;
 // Keep RAM data paths free of reset muxes for block-memory inference.
 always @(posedge clk)begin
  if(writing)memory[write_address]<=write_buffer[27:0];
  if(reading)read_data<=memory[read_address];
 end
 always @(posedge clk)begin
  read_valid<=0;
  if(rst)begin writing<=0;reading<=0;read_pipeline<=0;write_address<=0;read_address<=0;write_buffer<=0;read_word<=0;read_entry<=0;end
  else begin
   read_pipeline<=reading;
   if(write_request&&!busy)begin writing<=1;write_address<=write_index<<2;write_buffer<=write_entry;end
   else if(writing)begin
    write_buffer<=write_buffer>>28;
    if(write_address[1:0]==3)writing<=0;else write_address<=write_address+1'b1;
   end
   if(read_request&&!busy&&!write_request)begin reading<=1;read_address<=read_index<<2;end
   else if(reading)begin
    read_word<=read_address[1:0];
    if(read_address[1:0]==3)reading<=0;else read_address<=read_address+1'b1;
   end
   if(read_pipeline)case(read_word)
    0:read_entry[27:0]<=read_data;
    1:read_entry[55:28]<=read_data;
    2:read_entry[83:56]<=read_data;
    3:begin read_entry[111:84]<=read_data;read_valid<=1;end
   endcase
  end
 end
endmodule
