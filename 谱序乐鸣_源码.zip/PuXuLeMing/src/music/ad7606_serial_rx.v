`timescale 1ns/1ps
// AD7606 (not B/C): CS supplies bit 127; rising SCLK advances output.
// All registers use clk. SCLK is an output waveform, never an internal clock.
module ad7606_serial_rx #(
    parameter integer POWER_WAIT_TICKS = 2500000, // 50 ms
    parameter integer RESET_TICKS = 50,          // 1 us
    parameter integer SETTLE_TICKS = 50,         // 1 us
    parameter integer PERIOD_TICKS = 25000,      // 500 us
    parameter integer HALF_SCLK_TICKS = 25,      // 1 MHz at 50 MHz
    parameter integer RISE_TIMEOUT_TICKS = 500,  // 10 us
    parameter integer FALL_TIMEOUT_TICKS = 1000, // 20 us
    parameter integer RETRY_TICKS = 500000       // 10 ms
)(
    input wire clk, input wire rst,
    input wire busy_in, input wire douta_in,
    output reg adc_reset = 0, output reg convst = 0,
    output reg cs_n = 1, output reg sclk = 1,
    output reg [127:0] frame_raw = 0, // CH1 [127:112] ... CH8 [15:0]
    output wire signed [15:0] ch8_raw,
    output reg frame_valid = 0, output reg sample_valid = 0,
    output reg fault = 0, output reg [2:0] fault_code = 0
);
    assign ch8_raw = $signed(frame_raw[15:0]);
    // Only the first stage is excepted from external asynchronous timing.
    reg busy_meta = 0, busy_sync = 0;
    reg dout_meta = 0, dout_sync = 0;
    always @(posedge clk) begin
        if (rst) begin
            busy_meta<=0; busy_sync<=0; dout_meta<=0; dout_sync<=0;
        end else begin
            busy_meta<=busy_in; busy_sync<=busy_meta;
            dout_meta<=douta_in; dout_sync<=dout_meta;
        end
    end

    localparam POWER=0, RESET=1, SETTLE=2, IDLE=3, PULSE=4,
               WAIT_RISE=5, WAIT_FALL=6, CS_SETUP=7, SERIAL=8,
               CS_HOLD=9, PUBLISH=10, RETRY=11, CONV_LOW=12;
    localparam CONV_LOW_TICKS=50; // Vendor example: 1 us low, rise, hold high.
    reg [3:0] state = POWER;
    reg [31:0] count = 0;
    reg [31:0] period_left = 0;
    reg [7:0] half_count = 0;
    reg [6:0] bit_index = 0;
    reg [127:0] shift_bits = 0;
    reg saw_busy = 0;
    wire timeout_rise = state==WAIT_RISE && !busy_sync && count==RISE_TIMEOUT_TICKS-1;
    wire timeout_fall = state==WAIT_FALL && busy_sync && count==FALL_TIMEOUT_TICKS-1;
    wire timeout_idle = state==IDLE && period_left==0 && busy_sync && count==FALL_TIMEOUT_TICKS-1;
    wire busy_during_read = busy_sync && (state==CS_SETUP || state==SERIAL || state==CS_HOLD || state==PUBLISH);

    always @(posedge clk) begin
        frame_valid<=0;
        if (rst) begin
            state<=POWER; count<=0; period_left<=0; half_count<=0;
            bit_index<=0; shift_bits<=0; frame_raw<=0; saw_busy<=0;
            adc_reset<=0; convst<=0; cs_n<=1; sclk<=1;
            sample_valid<=0; fault<=0; fault_code<=0;
        end else if (timeout_rise || timeout_fall || timeout_idle || busy_during_read) begin
            state<=RETRY; count<=0; period_left<=0;
            adc_reset<=0; convst<=0; cs_n<=1; sclk<=1;
            sample_valid<=0; fault<=1;
            // Preserve the last signed raw frame for debugging; invalidate it.
            fault_code<=timeout_rise ? 3'd1 : timeout_fall ? 3'd2 : timeout_idle ? 3'd4 : 3'd3;
        end else begin
            if (period_left!=0) period_left<=period_left-1'b1;
            case (state)
                POWER: begin
                    if (count==POWER_WAIT_TICKS-1) begin
                        adc_reset<=1; count<=0; state<=RESET;
                    end else count<=count+1'b1;
                end
                RESET: begin
                    if (count==RESET_TICKS-1) begin
                        adc_reset<=0; count<=0; state<=SETTLE;
                    end else count<=count+1'b1;
                end
                SETTLE: begin
                    if (count==SETTLE_TICKS-1) begin
                        count<=0; state<=IDLE;
                    end else count<=count+1'b1;
                end
                IDLE: begin
                    // Prepare the falling edge 1 us before the next start edge.
                    if (period_left<=CONV_LOW_TICKS) begin
                        if (!busy_sync) begin
                            convst<=0; saw_busy<=0; count<=0; state<=CONV_LOW;
                        end else if (period_left==0) count<=count+1'b1;
                        else count<=0;
                    end else count<=0;
                end
                CONV_LOW: begin
                    if (count==CONV_LOW_TICKS-1) begin
                        convst<=1; count<=0; state<=PULSE;
                        period_left<=PERIOD_TICKS-1;
                    end else count<=count+1'b1;
                end
                PULSE: begin
                    if (busy_sync) saw_busy<=1;
                    if (count==4) begin // Observe early BUSY; keep both CONVST high.
                        count<=0;
                        state<=(saw_busy || busy_sync) ? WAIT_FALL : WAIT_RISE;
                    end else count<=count+1'b1;
                end
                WAIT_RISE: begin
                    if (busy_sync) begin state<=WAIT_FALL; count<=0; end
                    else count<=count+1'b1;
                end
                WAIT_FALL: begin
                    if (!busy_sync) begin
                        count<=0; cs_n<=0; sclk<=1;
                        bit_index<=0; shift_bits<=0; state<=CS_SETUP;
                    end else count<=count+1'b1;
                end
                CS_SETUP: begin
                    // 500 ns for CS-to-first-bit and two-stage DOUT synchronizer.
                    if (count==HALF_SCLK_TICKS-1) begin
                        sclk<=0; shift_bits<={shift_bits[126:0],dout_sync};
                        half_count<=0; state<=SERIAL;
                    end else count<=count+1'b1;
                end
                SERIAL: begin
                    if (half_count==HALF_SCLK_TICKS-1) begin
                        half_count<=0; sclk<=~sclk;
                        if (!sclk) begin
                            // Finish all 128 full cycles, including the last rising edge.
                            if (bit_index==127) begin count<=0; state<=CS_HOLD; end
                            else bit_index<=bit_index+1'b1;
                        end else shift_bits<={shift_bits[126:0],dout_sync};
                    end else half_count<=half_count+1'b1;
                end
                CS_HOLD: begin
                    if (count==4) begin cs_n<=1; count<=0; state<=PUBLISH; end
                    else count<=count+1'b1;
                end
                PUBLISH: begin
                    frame_raw<=shift_bits; frame_valid<=1; sample_valid<=1;
                    fault<=0; fault_code<=0; count<=0; state<=IDLE;
                end
                RETRY: begin
                    // Hold fault visible; reset ADC, then require a NEW full valid frame.
                    if (count==RETRY_TICKS-1) begin
                        count<=0; adc_reset<=1; state<=RESET;
                    end else count<=count+1'b1;
                end
                default: begin
                    state<=RETRY; count<=0; sample_valid<=0; fault<=1; fault_code<=5;
                    adc_reset<=0; convst<=0; cs_n<=1; sclk<=1;
                end
            endcase
        end
    end
endmodule
