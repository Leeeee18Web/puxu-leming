`timescale 1ns/1ps
// 21 ms sample delay at 48.828 kHz, half feedback, 3/4 dry + 1/2 wet.
// This is a single short echo effect, not three independent contest effects.
module performance_effect(input wire clk,rst,sample_tick,enabled,
 input wire signed [15:0] dry,output wire signed [15:0] pcm);
 reg signed [15:0] delay_mem[0:1023];
 reg [9:0] index=0;reg [10:0] filled=0;
 reg signed [15:0] delayed=0;
 wire signed [16:0] blend=$signed({dry[15],dry})-($signed({dry[15],dry})>>>2)+($signed({delayed[15],delayed})>>>1);
 wire signed [16:0] feedback=($signed({dry[15],dry})>>>1)+($signed({delayed[15],delayed})>>>1);
 assign pcm=!enabled?dry:blend>32767?16'sd32767:blend< -32768?-16'sd32768:blend[15:0];
 always @(posedge clk)begin
  if(rst||!enabled)begin index<=0;filled<=0;delayed<=0;end
  else if(sample_tick)begin
   delayed<=filled==1024?delay_mem[index]:16'sd0;
   delay_mem[index]<=feedback[15:0];index<=index+1'b1;
   if(filled<1024)filled<=filled+1'b1;
  end
 end
endmodule
