function [23:0] base_step;
input [2:0] address;
begin
case(address)
3'd0:base_step=24'd89894;
3'd1:base_step=24'd100902;
3'd2:base_step=24'd113259;
3'd3:base_step=24'd119994;
3'd4:base_step=24'd134689;
3'd5:base_step=24'd151183;
3'd6:base_step=24'd169697;
default:base_step=0;
endcase
end
endfunction
