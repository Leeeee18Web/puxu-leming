`timescale 1ns/1ps
// Parameters freeze on each rising gate. Segment endpoints occur after exactly
// N subsequent sample ticks; zero-time segments jump immediately. Quotient and
// remainder use one preparation clock and a 16-cycle restoring divider,
// settled before the next 1024-clock sample, never a combinational divide.
module project3_adsr #(parameter EXPLICIT_RETRIGGER=0,REGISTERED_CONFIG=EXPLICIT_RETRIGGER)(
 input wire clk,rst,sample_tick,gate,input wire [511:0] cfg,
 input wire note_trigger,
 output reg [15:0] level=0,output reg [2:0] phase=0,
 output wire active,output reg custom=0
);
 reg previous_gate=0;reg [16:0] decay_time=0;reg [17:0] release_time=0;
 reg [15:0] sustain=0;
 reg [17:0] duration=0,left=0,error_acc=0,remainder=0;
 reg [15:0] increment=0,target=0;reg descending=0;
 reg [4:0] div_left=0;reg [15:0] div_q=0;reg [17:0] div_rem=0;
 reg div_prepare=0;
 wire [18:0] trial={div_rem,div_q[15]};
 wire take=trial>={1'b0,duration};
 wire [15:0] quotient_next={div_q[14:0],take};
 wire [17:0] remainder_next=take?trial-{1'b0,duration}:trial;
 wire [18:0] error_next={1'b0,error_acc}+{1'b0,remainder};
 wire carry=error_next>={1'b0,duration};
 wire [16:0] delta={1'b0,increment}+carry;
 // One carry-chain for both directions, including the subtract carry-in.
 wire [16:0] signed_update={1'b0,level}+{1'b0,(delta[15:0]^{16{descending}})}+descending;
 wire bounded_custom=(cfg[0]===1'b1);
 wire [16:0] bounded_attack=cfg[63:32]>97656?17'd97656:cfg[48:32];
 wire [16:0] bounded_decay=cfg[95:64]>97656?17'd97656:cfg[80:64];
 wire [17:0] bounded_release=cfg[159:128]>146484?18'd146484:cfg[145:128];
 wire [15:0] bounded_sustain=cfg[127:96]>65535?16'hffff:cfg[111:96];
 wire request_custom,attack_nonzero,decay_nonzero;
 wire [16:0] requested_attack,requested_decay;wire[17:0] requested_release;wire[15:0] requested_sustain;
 generate if(REGISTERED_CONFIG)begin:config_pipeline
  reg rc=0,an=0,dn=0;reg[16:0] a=0,d=0;reg[17:0] r=0;reg[15:0] s=0;
  // P4 commits controls at the output sample boundary, at least 64 clocks
  // before the voice launch. Bound and classify them off the envelope path.
  always @(posedge clk)begin
   if(rst)begin rc<=0;an<=0;dn<=0;a<=0;d<=0;r<=0;s<=0;end
   else begin rc<=bounded_custom;an<=|cfg[63:32];dn<=|cfg[95:64];a<=bounded_attack;d<=bounded_decay;r<=bounded_release;s<=bounded_sustain;end
  end
  assign request_custom=rc;assign attack_nonzero=an;assign decay_nonzero=dn;
  assign requested_attack=a;assign requested_decay=d;assign requested_release=r;assign requested_sustain=s;
 end else begin:config_direct
  assign request_custom=bounded_custom;assign attack_nonzero=|bounded_attack;assign decay_nonzero=|bounded_decay;
  assign requested_attack=bounded_attack;assign requested_decay=bounded_decay;assign requested_release=bounded_release;assign requested_sustain=bounded_sustain;
 end endgenerate
 assign active=custom&&(phase!=0);
 task segment;
 input [2:0] kind;input [15:0] from_level,to_level;input [17:0] samples;
 begin
  phase<=kind;level<=from_level;target<=to_level;duration<=samples;left<=samples;
  // Only three legal segments exist: A(current->65535),
  // D(65535->sustain), R(current->0). Their magnitudes need no subtractors.
  descending<=kind!=1;error_acc<=0;
  // Capture segment operands now; initialize the iterative remainder on a
  // separate clock so cfg/zero-time decisions do not reach its update mux.
  div_q<=kind==1?~from_level:kind==2?~to_level:from_level;
  div_prepare<=1;div_left<=0;
 end endtask
 always @(posedge clk)begin
  if(rst)begin
   level<=0;phase<=0;custom<=0;previous_gate<=0;decay_time<=0;release_time<=0;sustain<=0;
   duration<=0;left<=0;error_acc<=0;remainder<=0;increment<=0;target<=0;descending<=0;
   div_left<=0;div_q<=0;div_rem<=0;div_prepare<=0;
  end else begin
   if(div_prepare)begin
    div_prepare<=0;div_rem<=0;div_left<=16;
   end else if(div_left!=0)begin
    div_q<=quotient_next;div_rem<=remainder_next;div_left<=div_left-1'b1;
    if(div_left==1)begin increment<=quotient_next;remainder<=remainder_next;end
   end
   if(sample_tick)begin
    previous_gate<=gate;
    if(gate&&(!previous_gate||(EXPLICIT_RETRIGGER&&note_trigger)))begin
     custom<=request_custom;decay_time<=requested_decay;release_time<=requested_release;sustain<=requested_sustain;
     if(!request_custom)begin level<=0;phase<=0;div_left<=0;div_prepare<=0;end
     else if(attack_nonzero)segment(1,level,65535,{1'b0,requested_attack});
     else if(decay_nonzero)segment(2,65535,requested_sustain,{1'b0,requested_decay});
     else begin level<=requested_sustain;phase<=3;div_left<=0;div_prepare<=0;end
    end else if(!gate&&previous_gate&&custom)begin
     if(release_time!=0&&level!=0)segment(4,level,0,release_time);
     else begin level<=0;phase<=0;div_left<=0;div_prepare<=0;end
    end else if(custom&&!div_prepare&&div_left==0&&(phase==1||phase==2||phase==4))begin
     if(left<=1)begin
      level<=target;left<=0;
      if(phase==1)begin
       if(decay_time!=0)segment(2,65535,sustain,{1'b0,decay_time});
       else begin level<=sustain;phase<=3;end
      end else if(phase==2)phase<=3;
      else phase<=0;
     end else begin
      level<=signed_update[15:0];left<=left-1'b1;
      error_acc<=carry?error_next-duration:error_next;
     end
    end
   end
  end
 end
endmodule
