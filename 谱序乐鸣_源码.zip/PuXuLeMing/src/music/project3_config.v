`timescale 1ns/1ps
// GS extension transactions. Only complete validated configurations reach audio.
module project3_config #(parameter LEGACY_RECORDING=1)(
 input wire clk,rst,sample_tick,command_valid,locked,recording,replaying,panic,
 input wire [63:0] request,
 output reg command_done=0,output reg [127:0] response=0,
 output wire [511:0] cfg,output reg [1:0] test_mode=0,
 output reg lesson_valid=0,output reg [7:0] lesson_op=0,
 output reg [15:0] lesson_index=0,output reg [31:0] lesson_value=0,
 input wire lesson_done,input wire [7:0] lesson_status,input wire [31:0] lesson_result
);
 localparam [511:0] DEFAULTS={32'd0,32'd0,32'd0,32'd0,32'd7,32'd98,32'd43980,32'd14746,32'd5859,32'd64,32'd1,32'd8789,32'd16384,32'd29297,32'd195,32'd0};
 // The wire protocol uses 16 words; only 137 bits carry legal values.
 // Narrow state registers prevent unused upper bits becoming physical flops.
 function [136:0] pack_cfg;input [511:0] x;begin
  pack_cfg[0+:1]=x[0+:1];
  pack_cfg[1+:17]=x[32+:17];
  pack_cfg[18+:17]=x[64+:17];
  pack_cfg[35+:16]=x[96+:16];
  pack_cfg[51+:18]=x[128+:18];
  pack_cfg[69+:2]=x[160+:2];
  pack_cfg[71+:8]=x[192+:8];
  pack_cfg[79+:13]=x[224+:13];
  pack_cfg[92+:15]=x[256+:15];
  pack_cfg[107+:18]=x[288+:18];
  pack_cfg[125+:8]=x[320+:8];
  pack_cfg[133+:4]=x[352+:4];
 end endfunction
 function [511:0] unpack_cfg;input [136:0] x;begin
  unpack_cfg=0;
  unpack_cfg[0+:1]=x[0+:1];
  unpack_cfg[32+:17]=x[1+:17];
  unpack_cfg[64+:17]=x[18+:17];
  unpack_cfg[96+:16]=x[35+:16];
  unpack_cfg[128+:18]=x[51+:18];
  unpack_cfg[160+:2]=x[69+:2];
  unpack_cfg[192+:8]=x[71+:8];
  unpack_cfg[224+:13]=x[79+:13];
  unpack_cfg[256+:15]=x[92+:15];
  unpack_cfg[288+:18]=x[107+:18];
  unpack_cfg[320+:8]=x[125+:8];
  unpack_cfg[352+:4]=x[133+:4];
 end endfunction
 reg [136:0] active_bits=pack_cfg(DEFAULTS),shadow_bits=pack_cfg(DEFAULTS);
 wire [511:0] active_cfg=unpack_cfg(active_bits),shadow=unpack_cfg(shadow_bits);
 wire [511:0] record_cfg;
 wire record_valid;
 wire legacy_recording=LEGACY_RECORDING&&recording;
 wire legacy_replaying=LEGACY_RECORDING&&replaying;
 reg shadow_valid=0;
 generate if(LEGACY_RECORDING)begin:legacy_snapshot
  reg[136:0]record_bits=pack_cfg(DEFAULTS);reg record_q=0,valid=0;
  assign record_cfg=unpack_cfg(record_bits);assign record_valid=valid;
  always @(posedge clk)begin
   if(rst)begin record_bits<=pack_cfg(DEFAULTS);record_q<=0;valid<=0;end
   else begin
    record_q<=recording;
    if(recording&&!record_q)begin record_bits<=active_bits;valid<=1;end
   end
  end
 end else begin:continuous_audio_recording
  assign record_cfg=512'd0;assign record_valid=1'b0;
 end endgenerate
 reg [15:0] revision=0;reg [31:0] samples=0;
 // Keep counter carry local to each byte; replies use the same parallel next value.
 (* syn_keep=1 *) wire [7:0] samples_inc0=samples[7:0]+8'd1;
 (* syn_keep=1 *) wire [7:0] samples_inc1=samples[15:8]+8'd1;
 (* syn_keep=1 *) wire [7:0] samples_inc2=samples[23:16]+8'd1;
 (* syn_keep=1 *) wire [7:0] samples_inc3=samples[31:24]+8'd1;
 wire [31:0] samples_next={(&samples[23:0])?samples_inc3:samples[31:24],
  (&samples[15:0])?samples_inc2:samples[23:16],
  (&samples[7:0])?samples_inc1:samples[15:8],samples_inc0};

 reg [2:0] state=0;reg [63:0] pending=0;
 reg command_valid_q=0;reg[63:0]request_q=0;
 always @(posedge clk)begin
  if(rst)begin command_valid_q<=0;request_q<=0;end
  else begin command_valid_q<=command_valid;if(command_valid)request_q<=request;end
 end
 wire [7:0] op=request_q[7:0],id=request_q[15:8];
 wire [15:0] index=request_q[31:16];wire [31:0] value=request_q[63:32];
 assign cfg=(legacy_replaying&&record_valid)?record_cfg:active_cfg;
 function valid_word;input [7:0] n;input [31:0] v;
 begin case(n)
 0:valid_word=v<=1;1,2:valid_word=v<=97656;3:valid_word=v<=65535;
 4:valid_word=v<=146484;5:valid_word=v<=3;6:valid_word=v<=128;
 7:valid_word=v>=1953&&v<=7812;8:valid_word=v<=21299;
 9:valid_word=v>=8796&&v<=175922;10:valid_word=v<=200;11:valid_word=v<=15;
 12,13,14,15:valid_word=v==0;default:valid_word=0;
 endcase end endfunction
 task reply;input [7:0] rop,status;input [15:0] ri;input [31:0] rv;
 begin response<={samples,16'd0,revision,rv,ri,status,rop};command_done<=1;end endtask
 always @(posedge clk)begin
  command_done<=0;lesson_valid<=0;
  if(rst)begin
   active_bits<=pack_cfg(DEFAULTS);shadow_bits<=pack_cfg(DEFAULTS);shadow_valid<=0;
   revision<=0;samples<=0;state<=0;pending<=0;
   response<=0;test_mode<=0;lesson_op<=0;lesson_index<=0;lesson_value<=0;
  end else begin
   if(sample_tick)begin
    samples[7:0]<=samples_inc0;
    if(&samples[7:0])samples[15:8]<=samples_inc1;
    if(&samples[15:0])samples[23:16]<=samples_inc2;
    if(&samples[23:0])samples[31:24]<=samples_inc3;
   end
   if(state==1)begin
    if(locked||panic||legacy_recording||legacy_replaying)begin reply(pending[7:0],2,pending[31:16],0);state<=0;end
    else if(sample_tick)begin
     if(pending[7:0]==1)begin active_bits<=shadow_bits;shadow_valid<=0;revision<=revision+1'b1;end
     else test_mode<=pending[33:32];
     response<={samples_next,16'd0,revision+(pending[7:0]==1?16'd1:16'd0),pending[63:32],16'd0,8'd0,pending[7:0]};
     command_done<=1;state<=0;
    end
   end else if(state==2)begin
    if(lesson_done)begin reply(pending[7:0],lesson_status,pending[31:16],lesson_result);state<=0;end
   end else if(command_valid_q)begin
    pending<=request_q;
    if(panic)reply(op,2,index,0);
    else if(index!=0&&op!=4)reply(op,1,index,0);
    else if((locked||legacy_recording||legacy_replaying)&&op!=2&&op!=9)reply(op,2,index,0);
    else case(op)
     0:if(!shadow_valid)reply(op,3,index,0);
       else if(!valid_word(id,value))reply(op,1,index,0);
       else begin
        case(id)
         0:shadow_bits[0+:1]<=value[0:0];
         1:shadow_bits[1+:17]<=value[16:0];
         2:shadow_bits[18+:17]<=value[16:0];
         3:shadow_bits[35+:16]<=value[15:0];
         4:shadow_bits[51+:18]<=value[17:0];
         5:shadow_bits[69+:2]<=value[1:0];
         6:shadow_bits[71+:8]<=value[7:0];
         7:shadow_bits[79+:13]<=value[12:0];
         8:shadow_bits[92+:15]<=value[14:0];
         9:shadow_bits[107+:18]<=value[17:0];
         10:shadow_bits[125+:8]<=value[7:0];
         11:shadow_bits[133+:4]<=value[3:0];
         default:begin end
        endcase
        reply(op,0,index,value);end
     1:if(id!=0||value!=0)reply(op,1,index,0);
       else if(!shadow_valid)reply(op,3,index,0);
       else state<=1;
     2:if(id>15||value!=0)reply(op,1,index,0);else reply(op,0,index,active_cfg[id*32+:32]);
     3:if(id!=0||value!=0)reply(op,1,index,0);else begin shadow_bits<=active_bits;shadow_valid<=1;reply(op,0,index,0);end
     4,5,6,7:if(id!=0)reply(op,1,index,0);else begin
       lesson_op<=op;lesson_index<=index;lesson_value<=value;lesson_valid<=1;state<=2;
      end
     8:if(id!=0||value>3)reply(op,1,index,0);else state<=1;
     9:if(value!=0||id>4)reply(op,1,index,0);
       else if(id==0)reply(op,0,0,32'h50330101);
       else if(id==3)reply(op,0,0,{30'd0,test_mode});
       else begin lesson_op<=9;lesson_index<={8'd0,id};lesson_value<=0;lesson_valid<=1;state<=2;end
     default:reply(op,1,index,0);
    endcase
   end
   if(panic)begin test_mode<=0;shadow_valid<=0;
    if(state!=0)begin reply(pending[7:0],2,pending[31:16],0);state<=0;end
   end
  end
 end
endmodule
