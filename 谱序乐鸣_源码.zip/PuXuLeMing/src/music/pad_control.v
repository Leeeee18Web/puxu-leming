`timescale 1ns/1ps
// A-mode pressure: voltage falls with force. Every pad owns its calibration,
// averaging, gate hysteresis and continuous relative-force value.
module pad_control #(parameter CAL_BITS=6,parameter ENABLE_RECOVERY=0)(
 input wire clk,rst,frame_valid,sample_valid,fault,recalibrate,
 input wire signed [15:0] raw,
 output reg calibrated=0,
 output reg armed=0,
 output reg gate=0,
 output reg [11:0] pressure=0,
 output reg [15:0] idle_raw=0,
 output reg [15:0] filtered_raw=0
);
 wire [15:0] bounded=raw<0 ? 16'd0 : raw>21627 ? 16'd21627 : raw;
 reg [21:0] cal_sum=0;
 reg [CAL_BITS-1:0] cal_count=0;
 reg half_full=0;
 reg [15:0] first_raw=0;
 wire [16:0] pair_sum={1'b0,first_raw}+{1'b0,bounded};
 wire [15:0] average=pair_sum[16:1];
 wire [15:0] delta=idle_raw>average ? idle_raw-average : 16'd0;
 wire [17:0] force_times3={2'b00,delta}+{1'b0,delta,1'b0};
 wire [21:0] final_cal=cal_sum+{6'd0,bounded};
 always @(posedge clk) begin
  if(rst || (ENABLE_RECOVERY && (fault || recalibrate))) begin
   calibrated<=0;armed<=0;gate<=0;pressure<=0;idle_raw<=0;
   filtered_raw<=0;cal_sum<=0;cal_count<=0;half_full<=0;first_raw<=0;
  end else if(fault || !sample_valid) begin
   gate<=0;pressure<=0;half_full<=0;
   if(!calibrated) begin cal_sum<=0;cal_count<=0;end
  end else if(frame_valid) begin
   if(!calibrated) begin
    if(&cal_count) begin
     idle_raw<=final_cal>>CAL_BITS;
     armed<=(final_cal>>CAL_BITS)>=4096;
     calibrated<=1;cal_sum<=0;cal_count<=0;
    end else begin cal_sum<=final_cal;cal_count<=cal_count+1'b1;end
   end else if(!half_full) begin first_raw<=bounded;half_full<=1;end
   else begin
    half_full<=0;filtered_raw<=average;
    if(armed) begin
     pressure<=force_times3[17:4]>4095 ? 12'd4095 : force_times3[15:4];
     if(!gate && delta>=800) gate<=1;
     else if(gate && delta<=400) gate<=0;
    end else begin gate<=0;pressure<=0;end
   end
  end
 end
endmodule
