`timescale 1ns/1ps
module instrument_audio #(
 parameter ENABLE_PERFORMANCE=0,PROJECT3=0,PROJECT4=0,MUSIC_STREAM=0,FILE_SERVICE=0,PITCH_METADATA=0,SD_MANUAL_INIT=0,
 parameter TONE_REFINEMENT=PROJECT4,
 parameter POWER_WAIT_TICKS=2500000,RETRY_TICKS=500000,CAL_BITS=6,
 parameter DEBOUNCE_TICKS=50000,SONG_SAMPLES=1464844,SONG_EVENTS=262,
 parameter P4_SCORE_EVENTS=474,P4_SCORE_SAMPLES=2929688,
 parameter P4_SCORE_FILE="src/music/project4_default96.hex",
 parameter UART_DIV=434
)(
 input clk,resetn,key1_n,key2_n,command_valid,input [2:0] command,
 input [15:0] function_press,matrix_keys,input matrix_ghost,output [63:0] control_state,
 output [127:0] adc_raw,output [6:0] adc_armed,adc_calibrated,
 output [2:0] adc_fault_code,output adc_sample_valid,output [15:0] adc_frame_count,
 input adc_busy,adc_douta,uart_rx,output uart_tx,
 output file_rx_start,file_rx_write,file_rx_commit,file_rx_abort,
 output[15:0]file_rx_length,file_rx_sequence,file_rx_index,output[7:0]file_rx_byte,input file_rx_ready,
 input file_stream_valid,input[7:0]file_stream_kind,file_stream_byte,input[15:0]file_stream_length,
 output[15:0]file_stream_index,output file_stream_take,file_stream_done,
 input [127:0] usb_diagnostics,input usb_diagnostics_valid,
 output adc_reset,adc_convst,adc_cs_n,adc_sclk,
 output hp_bck,hp_ws,hp_din,pa_en,i2s_bck,i2s_ws,i2s_sd,
 output [7:0] led_o,output sample_tick,output signed [15:0] pcm,
 output reg [1:0] mode=0,output reg muted=0,
 output validation_active,output playing,done,ready,fault,output [6:0] gates,active,
 output [83:0] pressures,
 output reg [6:0] display_note=127,output [6:0] display_next,
 output reg display_valid=0,output reg [10:0] display_pitch=0,
 output reg [23:0] display_step=0,output reg [15:0] display_envelope=0,output reg trace_restart=0,
 output music_request_valid,output [7:0] music_request_command,music_request_index,input music_request_ready,
 output[31:0]music_request_begin,music_request_end,output music_request_loop,
 output reg music_cancel=0,input music_head_valid,output music_head_ready,input [95:0] music_head,
 input music_stream_done,music_start,music_stop,input [255:0] music_status,
 output host_upload_valid,output[127:0]host_upload_packet,input host_upload_ready,input[7:0]host_upload_result
);
 wire rst=!resetn;
 wire [511:0] p3_cfg;wire [1:0] p3_test;
 localparam integer EXT_BITS=PROJECT4?128:64;
 wire ext_valid,ext_done;wire [EXT_BITS-1:0] ext_request;wire [127:0] ext_response;wire link_high_speed;
 wire audition_hold,audition_reset,fx_ready,prepare_ext_done,prepare_stopped,prepare_release;wire[127:0]prepare_ext_response;
 wire prepare_ext_request=PROJECT4&&(ext_request[7:0]==96||ext_request[7:0]==97);
 generate if(PROJECT4)begin:audition_preparation
  project4_audition_prepare controller(.clk(clk),.rst(rst),.sample_tick(sample_tick),.command_valid(ext_valid&&prepare_ext_request),.request(ext_request[63:0]),
   .stopped(prepare_stopped),.new_source(prepare_release),.fx_ready(fx_ready),.hold(audition_hold),.fx_reset(audition_reset),.command_done(prepare_ext_done),.response(prepare_ext_response));
 end else begin:no_audition_preparation
  assign audition_hold=0;assign audition_reset=0;assign prepare_ext_done=0;assign prepare_ext_response=0;
 end endgenerate
 wire[223:0]p4_fm_cfg;wire fm_ext_done;wire[127:0]fm_ext_response;
 wire fm_ext_request=PROJECT4&&ext_request[7:0]>=100&&ext_request[7:0]<=105;
 generate if(PROJECT4)begin:fm_configuration
  project4_fm_config controller(.clk(clk),.rst(rst),.sample_tick(sample_tick),.command_valid(ext_valid&&fm_ext_request),.request(ext_request[63:0]),.command_done(fm_ext_done),.response(fm_ext_response),.cfg(p4_fm_cfg));
 end else begin:no_fm_configuration
  assign p4_fm_cfg=0;assign fm_ext_done=0;assign fm_ext_response=0;
 end endgenerate
 wire[415:0]p4_fx_cfg;wire fx_ext_done;wire[127:0]fx_ext_response;wire[111:0]fx_nodes;wire[63:0]fx_delays;
 wire fx_ext_request=PROJECT4&&ext_request[7:0]>=90&&ext_request[7:0]<=95;
 generate if(PROJECT4)begin:effects_configuration
  project4_effects_config controller(.clk(clk),.rst(rst),.sample_tick(sample_tick),.command_valid(ext_valid&&fx_ext_request),.request(ext_request[63:0]),.command_done(fx_ext_done),.response(fx_ext_response),.cfg(p4_fx_cfg));
 end else begin:no_effects_configuration
  assign p4_fx_cfg=0;assign fx_ext_done=0;assign fx_ext_response=0;
 end endgenerate
 wire[191:0]p4_mod_cfg;wire mod_ext_done;wire[127:0]mod_ext_response;
 wire mod_ext_request=PROJECT4&&ext_request[7:0]>=80&&ext_request[7:0]<=85;
 generate if(PROJECT4)begin:modulation_configuration
  project4_modulation_config controller(.clk(clk),.rst(rst),.sample_tick(sample_tick),.command_valid(ext_valid&&mod_ext_request),.request(ext_request[63:0]),.command_done(mod_ext_done),.response(mod_ext_response),.cfg(p4_mod_cfg));
 end else begin:no_modulation_configuration
  assign p4_mod_cfg=0;assign mod_ext_done=0;assign mod_ext_response=0;
 end endgenerate
 wire [141:0] p4_mix_cfg;wire p3_ext_done,p4_ext_done;wire[127:0] p3_ext_response,p4_ext_response;
 wire p4_mix_request=PROJECT4&&ext_request[7:0]>=32&&ext_request[7:0]<=37;
 wire [31:0] event_position,event_errors;wire event_abort;
 wire event_started;reg event_started_q=0;reg[15:0]event_started_generation=0;
 always @(posedge clk)begin
  if(rst)begin event_started_q<=0;event_started_generation<=0;end
  else begin event_started_q<=event_started;if(event_started&&!event_started_q)event_started_generation<=music_status[31:16];end
 end
 wire music_ext_request=PROJECT4&&MUSIC_STREAM&&ext_request[7:0]>=48&&ext_request[7:0]<=56;
 wire playback_paused;
 wire music_ext_done;wire[127:0]music_ext_response;
 wire upload_ext_request=PROJECT4&&MUSIC_STREAM&&ext_request[7:0]>=64&&ext_request[7:0]<=68;
 wire upload_ext_done;wire[127:0]upload_ext_response;
 wire card_request_valid,upload_request_valid;wire[7:0]card_request_command,card_request_index;
 assign music_request_valid=card_request_valid||upload_request_valid;
 assign music_request_command=upload_request_valid?8'd4:card_request_command;
 assign music_request_index=upload_request_valid?8'd0:card_request_index;
 wire taps_ext_request=PROJECT4&&ext_request[7:0]>=70&&ext_request[7:0]<=77;
 wire taps_ext_done;wire[127:0]taps_ext_response;
 wire tap_frame_valid,tap_frame_take,tap_frame_done;wire[7:0]tap_frame_kind,tap_byte;
 wire[15:0]tap_frame_length,tap_byte_index;
 wire serial_stream_valid,serial_stream_take,serial_stream_done;
 reg previous_high_speed=0;
 // The UART watchdog can abort a frame before its CRC. Release its source
 // lease on that same link-loss pulse so the next session can transmit.
 wire serial_stream_abort=previous_high_speed&&!link_high_speed;
 wire[7:0]serial_stream_kind,serial_stream_byte;wire[15:0]serial_stream_length,serial_stream_index;
 assign tap_byte_index=serial_stream_index;assign file_stream_index=serial_stream_index;
 generate if(FILE_SERVICE)begin:file_stream_arbitration
  project4_stream_mux mux(.clk(clk),.rst(rst||!link_high_speed),.tap_valid(tap_frame_valid),.file_valid(file_stream_valid),
   .tap_kind(tap_frame_kind),.file_kind(file_stream_kind),.tap_length(tap_frame_length),.file_length(file_stream_length),
   .tap_byte(tap_byte),.file_byte(file_stream_byte),.tap_take(tap_frame_take),.file_take(file_stream_take),
   .tap_done(tap_frame_done),.file_done(file_stream_done),.stream_valid(serial_stream_valid),
   .stream_kind(serial_stream_kind),.stream_length(serial_stream_length),.stream_byte(serial_stream_byte),
   .stream_take(serial_stream_take),.stream_done(serial_stream_done||serial_stream_abort));
 end else begin:no_file_stream
  assign serial_stream_valid=tap_frame_valid;assign serial_stream_kind=tap_frame_kind;
  assign serial_stream_length=tap_frame_length;assign serial_stream_byte=tap_byte;
  assign tap_frame_take=serial_stream_take;assign tap_frame_done=serial_stream_done;
  assign file_stream_take=0;assign file_stream_done=0;
 end endgenerate
 reg sd_source=0,requested_sd=0;
 reg host_source=0;
 wire host_link_lost=host_source&&previous_high_speed&&!link_high_speed;
 assign ext_done=prepare_ext_done||fm_ext_done||fx_ext_done||mod_ext_done||p3_ext_done||p4_ext_done||music_ext_done||taps_ext_done||upload_ext_done;
 assign ext_response=prepare_ext_done?prepare_ext_response:fm_ext_done?fm_ext_response:fx_ext_done?fx_ext_response:mod_ext_done?mod_ext_response:upload_ext_done?upload_ext_response:taps_ext_done?taps_ext_response:music_ext_done?music_ext_response:p4_ext_done?p4_ext_response:p3_ext_response;
 generate if(PROJECT4&&MUSIC_STREAM)begin:music_configuration
  project4_music_control #(.SD_MANUAL_INIT(SD_MANUAL_INIT)) controller(.clk(clk),.rst(rst),.sample_tick(sample_tick),.clear_pause(start_song||stop_song||mode!=2||done||event_abort),.paused(playback_paused),.command_valid(ext_valid&&music_ext_request),.request(ext_request[63:0]),
   .command_done(music_ext_done),.response(music_ext_response),.status_words(music_status),.position(event_position),
   .source_active(sd_source),.playing(playing),.done(done),.aborted(event_abort),.started(event_started&&(!sd_source||event_started_generation==music_status[31:16])),
   .request_valid(card_request_valid),.request_command(card_request_command),.request_index(card_request_index),.request_ready(music_request_ready&&!upload_request_valid),
   .request_begin(music_request_begin),.request_end(music_request_end),.request_loop(music_request_loop));
  project4_host_upload uploader(.clk(clk),.rst(rst),.high_speed(link_high_speed),
   .cancel(music_cancel||(ext_valid&&music_ext_request&&(ext_request[7:0]==50||ext_request[7:0]==51||ext_request[7:0]==55))),
   .command_valid(ext_valid&&upload_ext_request),.request(ext_request),.generation(music_status[31:16]),.command_done(upload_ext_done),.response(upload_ext_response),
   .request_valid(upload_request_valid),.request_ready(music_request_ready),
   .host_valid(host_upload_valid),.host_packet(host_upload_packet),.host_ready(host_upload_ready),.host_result(host_upload_result));
 end else begin:no_music_configuration
  assign music_ext_done=0;assign music_ext_response=0;assign card_request_valid=0;assign card_request_command=0;assign card_request_index=0;
  assign upload_request_valid=0;assign upload_ext_done=0;assign upload_ext_response=0;assign host_upload_valid=0;assign host_upload_packet=0;
  assign playback_paused=0;
  assign music_request_begin=0;assign music_request_end=0;assign music_request_loop=0;
 end endgenerate
 generate if(PROJECT4)begin:mix_configuration
  project4_mix_config controller(.clk(clk),.rst(rst),.sample_tick(sample_tick),.command_valid(ext_valid&&p4_mix_request),
   .request(ext_request[63:0]),.command_done(p4_ext_done),.response(p4_ext_response),.cfg(p4_mix_cfg));
 end else begin:legacy_mix_configuration
  assign p4_mix_cfg={7'd127,7'd0,{8{16'd32768}}};assign p4_ext_done=0;assign p4_ext_response=0;
 end endgenerate
 wire lesson_valid,lesson_done,lesson_running;wire [7:0] lesson_op,lesson_status;
 wire [15:0] lesson_index;wire [31:0] lesson_value,lesson_result,lesson_status_word;
 wire signed [31:0] lesson_error;wire [6:0] lesson_mask,lesson_next;
 wire [63:0] legacy_control_state;
 assign control_state=PROJECT3?((legacy_control_state&~64'h2000)|({63'd0,lesson_running}<<13)):legacy_control_state;
 wire pcm_session;
 assign validation_active=PROJECT3&&p3_test!=0;
 wire [15:0] host_function_press;
 wire host_command_valid;wire [2:0] host_command;
 // Consume each physical key once until its debounced level and request
 // are both released. Do not tie host commands to a held physical key.
 reg [15:0] matrix_consumed=0;
 always @(posedge clk)begin
  if(rst)matrix_consumed<=0;
  else matrix_consumed<=(matrix_consumed|function_press)&(matrix_keys|function_press);
 end
 wire [15:0] physical_function_press=function_press&~matrix_consumed&{16{!matrix_ghost}};
 // Project4 keeps the agreed performance keys. Obsolete event-recording and
 // teaching shortcuts cannot silently take over the shared audio source.
 wire [15:0] effective_function_press=ENABLE_PERFORMANCE?
  ((physical_function_press|host_function_press)&(PROJECT4?16'h8f0f:16'hffff)):16'd0;
 wire effective_command_valid=command_valid||host_command_valid;
 wire [2:0] effective_command=command_valid?command:host_command;
 always @(posedge clk)begin
  if(rst)begin host_source<=0;previous_high_speed<=0;end
  else begin
   previous_high_speed<=link_high_speed;
   if(host_link_lost)host_source<=0;
   else if(music_request_valid&&music_request_ready)host_source<=music_request_command==4;
   else if(effective_command_valid&&effective_command<=3)host_source<=0;
  end
 end
 wire recalibrate=ENABLE_PERFORMANCE&&effective_command_valid&&effective_command==5;
 wire manual_bck,manual_ws,manual_sd;
 wire signed [15:0] manual_pcm;wire [111:0] manual_voice_pcm,manual_post_voice_pcm;
 wire[167:0]manual_render_steps;wire[6:0]manual_render_active;
 wire manual_sample_tick;wire[223:0]modulation_coefficients;wire[31:0]modulation_flags;wire[15:0]modulation_gain;
 wire [7:0] manual_led;wire [127:0] raw;assign adc_raw=raw;
 wire [111:0] envelopes;wire [20:0] phases;wire [167:0] steps;wire [18:0] ratio;
 wire [6:0] teaching_note;wire [3:0] teaching_progress;
 reg start_song=0,stop_song=0;
 wire [3:0] score_gates;wire [27:0] score_notes;wire [47:0] score_gains;wire [95:0] score_steps;
 wire [6:0] event_gates,event_triggers;wire [48:0] event_notes;wire [83:0] event_gains;
 wire [167:0] event_steps;
 genvar sv;
 generate if(PROJECT4)begin:shared_score_pitch
  assign score_steps=event_steps[95:0];
 end else for(sv=0;sv<4;sv=sv+1)begin:score_pitch
  song_step_logic #(.PARTIAL(0)) decode(.clk(clk),.note(score_notes[sv*7+:7]),.value(score_steps[sv*24+:24]));
 end endgenerate
 keyboard_top #(.ENABLE_PERFORMANCE(ENABLE_PERFORMANCE),.SHARED_SONG(1),.PROJECT3(PROJECT3),.DIRECT_PCM(PROJECT4),.EVENT_SONG(PROJECT4),.TONE_REFINEMENT(TONE_REFINEMENT),.CONTROLLED_MIX(PROJECT4),.ADVANCED_MODULATION(PROJECT4),.ADVANCED_EFFECTS(PROJECT4),.FM_EDITING(PROJECT4),.AUDITION_PREPARE(PROJECT4),.PITCH_METADATA(PITCH_METADATA),.POWER_WAIT_TICKS(POWER_WAIT_TICKS),.RETRY_TICKS(RETRY_TICKS),.CAL_BITS(CAL_BITS),.DEBOUNCE_TICKS(DEBOUNCE_TICKS)) manual(
  .audition_hold(audition_hold),.audition_reset(audition_reset),.fx_ready(fx_ready),
  .fm_cfg(p4_fm_cfg),
  .modulation_coefficients(modulation_coefficients),.modulation_flags(modulation_flags),.modulation_gain(modulation_gain),
  .fx_cfg(p4_fx_cfg),.fx_panic(effective_function_press[15]),.fx_nodes(fx_nodes),.fx_delays(fx_delays),
  .mod_cfg(p4_mod_cfg),.cfg(p3_cfg),.test_mode(p3_test),.mix_cfg(p4_mix_cfg),
  .song_mode(mode==2),.song_clear(start_song||stop_song),.song_gates(score_gates),.song_steps(score_steps),.song_gains(score_gains),
  .event_gates(event_gates),.event_steps(event_steps),.event_gains(event_gains),.event_triggers(event_triggers),
  .sys_clk(clk),.rst_ext(rst),.recalibrate(recalibrate),.function_press(PROJECT3?(effective_function_press&16'hefff):effective_function_press),.matrix_keys(matrix_keys),.matrix_ghost(matrix_ghost),.control_state(legacy_control_state),.teaching_note(teaching_note),.teaching_progress(teaching_progress),.key1_n(1'b1),.key2_n(1'b1),.adc_busy(adc_busy),.adc_douta(adc_douta),
  .adc_reset(adc_reset),.adc_convst(adc_convst),.adc_cs_n(adc_cs_n),.adc_sclk(adc_sclk),
  .hp_bck(),.hp_ws(),.hp_din(),.pa_en(pa_en),.i2s_bck(manual_bck),.i2s_ws(manual_ws),.i2s_sd(manual_sd),.led_o(manual_led),
  .audio_pcm(manual_pcm),.audio_voices(manual_voice_pcm),.audio_post_voices(manual_post_voice_pcm),.audio_sample_tick(manual_sample_tick),.audio_render_steps(manual_render_steps),.audio_render_active(manual_render_active),
  .monitor_raw(raw),.monitor_pressures(pressures),.monitor_envelopes(envelopes),.monitor_phases(phases),
  .monitor_steps(steps),.monitor_ratio(ratio),.monitor_gates(gates),.monitor_active(active),.monitor_ready(ready),.monitor_fault(fault),.monitor_armed(adc_armed),.monitor_calibrated(adc_calibrated),.monitor_fault_code(adc_fault_code),.monitor_sample_valid(adc_sample_valid),.monitor_frame_count(adc_frame_count));
 wire [15:0] manual_l,manual_r;
 generate if(PROJECT4)begin:direct_manual
  assign manual_l=manual_pcm;assign manual_r=manual_pcm;
 end else begin:legacy_manual
  i2s_rx16 decode_manual(.clk(clk),.rst(rst),.bck(manual_bck),.ws(manual_ws),.sd(manual_sd),.pcm_l(manual_l),.pcm_r(manual_r),.frame_valid());
 end endgenerate
 wire signed [15:0] song_pcm;wire [3:0] song_active;
 wire [6:0] melody_note,melody_next;wire [23:0] melody_step;wire [15:0] melody_envelope;
 generate if(PROJECT4)begin:project4_player
  project4_score_player #(.EVENT_COUNT(P4_SCORE_EVENTS),.TOTAL_SAMPLES(P4_SCORE_SAMPLES),.SCORE_FILE(P4_SCORE_FILE),.STREAM_ENABLED(MUSIC_STREAM),.PAUSE_ENABLED(1)) player(
   .clk(clk),.rst(rst),.sample_tick(manual_sample_tick),.start(start_song),.stop(stop_song),.pause(playback_paused),
   .playing(playing),.done(done),.abort(event_abort),.started(event_started),.position(event_position),.gates(event_gates),
   .notes(event_notes),.gains(event_gains),.steps(event_steps),.retrigger(event_triggers),.event_errors(event_errors),
   .stream_select(sd_source),.stream_total(music_status[127:96]),.stream_valid(music_head_valid),.stream_event(music_head),
   .stream_finished(music_stream_done),.stream_ready(music_head_ready));
  assign score_gates=event_gates[3:0];assign score_notes=event_notes[27:0];assign score_gains=event_gains[47:0];
  assign melody_next=127;
 end else begin:legacy_player
 song_sequencer #(.TOTAL_SAMPLES(SONG_SAMPLES),.EVENT_COUNT(SONG_EVENTS)) player(
  .clk(clk),.rst(rst),.sample_tick(sample_tick),.start(start_song),.stop(stop_song),
  .playing(playing),.done(done),.gates(score_gates),.notes(score_notes),.gains(score_gains),.next_melody_note(melody_next));
  assign event_gates=0;assign event_triggers=0;assign event_notes=0;assign event_gains=0;assign event_steps=0;
  assign event_position=0;assign event_errors=0;assign event_abort=0;assign event_started=0;
 end endgenerate
 assign song_pcm=$signed(manual_l);assign song_active=active[3:0];
 assign melody_note=score_notes[6:0];assign melody_step=score_steps[23:0];assign melody_envelope=envelopes[15:0];
 wire k1,k2;
 project_button #(.TICKS(DEBOUNCE_TICKS)) key1(.clk(clk),.rst(rst),.key_n(key1_n),.press(k1));
 project_button #(.TICKS(DEBOUNCE_TICKS)) key2(.clk(clk),.rst(rst),.key_n(key2_n),.press(k2));
 reg [1:0] requested_mode=0;
 reg requested_play=0,restart_pending=0,stop_pending=0;
 reg [5:0] gain=0;
 assign prepare_stopped=mode==0&&requested_mode==0&&gain==0;
 assign prepare_release=start_song||mode==1;
 wire transitioning=(mode!=requested_mode)||(mode==2&&(restart_pending||stop_pending));
 wire can_sound=(PROJECT3&&p3_test!=0)||(mode==1)||(mode==2&&playing);
 always @(posedge clk)begin
  start_song<=0;stop_song<=0;trace_restart<=0;music_cancel<=0;
  if(rst)begin mode<=0;requested_mode<=0;requested_play<=0;muted<=0;gain<=0;restart_pending<=0;stop_pending<=0;sd_source<=0;requested_sd<=0;end
  else begin
   if(sample_tick)begin
    if(transitioning)begin
     if(gain!=0)gain<=gain-1'b1;
     else begin
      if(mode==2&&!(requested_mode==2&&requested_play))stop_song<=1;
      mode<=requested_mode;
      sd_source<=requested_sd;
      trace_restart<=1;
      if(requested_mode==2&&requested_play)start_song<=1;
      restart_pending<=0;stop_pending<=0;
     end
    end else if(can_sound&&!muted&&gain<32)gain<=gain+1'b1;
    else if((!can_sound||muted)&&gain!=0)gain<=gain-1'b1;
   end
   if(k2)muted<=~muted;
   if(k1)begin
    requested_sd<=0;sd_source<=0;if(sd_source||requested_sd)music_cancel<=1;
    if(mode==2)begin requested_mode<=1;requested_play<=0;end
    else begin requested_mode<=2;requested_play<=1;restart_pending<=1;end
   end
   // Commands run after frame scheduling so a coincident touch cannot be lost.
   if(effective_command_valid)case(effective_command)
    0:begin requested_mode<=0;requested_play<=0;requested_sd<=0;sd_source<=0;if(sd_source||requested_sd)music_cancel<=1;end
    1:begin requested_mode<=1;requested_play<=0;requested_sd<=0;sd_source<=0;if(sd_source||requested_sd)music_cancel<=1;end
    2:begin requested_mode<=2;requested_play<=1;restart_pending<=1;requested_sd<=0;sd_source<=0;if(sd_source||requested_sd)music_cancel<=1;end
    3:begin requested_play<=0;stop_pending<=1;requested_sd<=0;sd_source<=0;if(sd_source||requested_sd)music_cancel<=1;end
    4:muted<=~muted;
    default:begin end
   endcase
   if(ENABLE_PERFORMANCE&&!sd_source&&!requested_sd&&(effective_function_press[9]||effective_function_press[12]||effective_function_press[13]||effective_function_press[14]))begin
    requested_mode<=1;requested_play<=0;
   end
   if(ENABLE_PERFORMANCE&&effective_function_press[15])begin
    stop_song<=1;requested_play<=0;restart_pending<=0;stop_pending<=0;gain<=0;
    if(sd_source||requested_sd)music_cancel<=1;
   end
   if(PROJECT4&&MUSIC_STREAM&&music_request_valid&&music_request_ready&&(music_request_command==1||music_request_command==4||music_request_command==5))begin
    requested_sd<=1;requested_play<=0;stop_song<=1;requested_mode<=2;restart_pending<=0;
   end
   if(PROJECT4&&MUSIC_STREAM&&music_stop&&(sd_source||requested_sd))begin
    stop_song<=1;requested_play<=0;restart_pending<=0;stop_pending<=0;gain<=0;
   end
   if(PROJECT4&&MUSIC_STREAM&&music_start)begin
    requested_mode<=2;requested_play<=1;requested_sd<=1;restart_pending<=1;
   end
   if(PROJECT4&&host_link_lost)begin
    music_cancel<=1;stop_song<=1;requested_mode<=0;requested_play<=0;requested_sd<=0;sd_source<=0;
    restart_pending<=0;stop_pending<=0;gain<=0;
   end
  end
 end
 wire signed [15:0] selected=(PROJECT3&&p3_test!=0)?$signed(manual_l):mode==1?$signed(manual_l):mode==2?song_pcm:16'sd0;
 reg signed [22:0] product=0;reg signed [15:0] output_pcm=0;
 generate if(PROJECT4)begin:final_volume
  reg[15:0] volume=32768;reg signed[32:0] volume_product=0;
  wire[15:0] target=p4_mix_cfg[15:0];
  wire signed[15:0] transition_sample=product>>>5;
  always @(posedge clk)begin
   if(rst)begin product<=0;output_pcm<=0;volume<=32768;volume_product<=0;end
   else begin
    if(sample_tick)begin
     if(volume<target)volume<=target-volume<=256?target:volume+16'd256;
     else if(volume>target)volume<=volume-target<=256?target:volume-16'd256;
    end
    product<=selected*$signed({1'b0,gain});volume_product<=transition_sample*$signed({1'b0,volume});output_pcm<=volume_product>>>15;
   end
  end
 end else begin:legacy_final_volume
  always @(posedge clk)begin
   if(rst)begin product<=0;output_pcm<=0;end
   else begin product<=selected*$signed({1'b0,gain});output_pcm<=product>>>5;end
  end
 end endgenerate
 assign pcm=output_pcm;
 i2s_tx16 tx(.clk(clk),.rst(rst),.pcm_l(output_pcm),.pcm_r(output_pcm),.bck(i2s_bck),.ws(i2s_ws),.sd(i2s_sd),.sample_tick(sample_tick));
 wire [15:0] decoded_l,decoded_r;
 generate if(PROJECT4)begin:direct_dac
  assign decoded_l=output_pcm;assign decoded_r=output_pcm;
 end else begin:legacy_dac
  i2s_rx16 rx(.clk(clk),.rst(rst),.bck(i2s_bck),.ws(i2s_ws),.sd(i2s_sd),.pcm_l(decoded_l),.pcm_r(decoded_r),.frame_valid());
 end endgenerate
 pt8211_tx16 adapter(.clk(clk),.rst(rst),.pcm_l(decoded_l),.pcm_r(decoded_r),.bck(hp_bck),.ws(hp_ws),.sd(hp_din));
 wire signed [15:0] bend_cents;
 wire monitor_rx,monitor_tx;
 generate if(PROJECT4)begin:studio_link
  // Studio uses one negotiated link, so controls are never disconnected by
  // the old exclusive recording protocol. Continuous PCM taps share frames.
  assign monitor_rx=uart_rx;assign uart_tx=monitor_tx;assign pcm_session=0;
 end else begin:legacy_pcm_link
  uart_pcm_bridge #(.LOW_DIV(UART_DIV)) pcm_recorder(.clk(clk),.rst(rst),.rx(uart_rx),.legacy_tx(monitor_tx),.legacy_rx(monitor_rx),
   .tx(uart_tx),.sample_tick(sample_tick),.pcm(output_pcm),.session_active(pcm_session),.recording());
 end endgenerate
 generate if(PROJECT4)begin:studio_audio_taps
  // The existing FX engine publishes its pending frame one tick later;
  // the final serial latch observes the previous published value. Align the
  // independent dry voices to that exact two-frame baseline, not to host time.
  reg[111:0]previous_voices=0,aligned_voices=0;wire[1:0]tap_profile;
  always @(posedge clk)if(rst)begin previous_voices<=0;aligned_voices<=0;end
   else if(sample_tick)begin previous_voices<=tap_profile==1?manual_post_voice_pcm:manual_voice_pcm;aligned_voices<=previous_voices;end
  wire[167:0]aligned_render_steps;wire[6:0]aligned_render_active;
  if(PITCH_METADATA)begin:pitch_alignment
   reg[167:0]previous_steps=0,aligned_steps=0;reg[6:0]previous_active=0,aligned_active=0;
   always @(posedge clk)if(rst)begin previous_steps<=0;aligned_steps<=0;previous_active<=0;aligned_active<=0;end
    else if(sample_tick)begin previous_steps<=manual_render_steps;aligned_steps<=previous_steps;previous_active<=manual_render_active;aligned_active<=previous_active;end
   assign aligned_render_steps=aligned_steps;assign aligned_render_active=aligned_active;
  end else begin:no_pitch_alignment
   assign aligned_render_steps=0;assign aligned_render_active=0;
  end
  project4_audio_taps #(.EFFECTS(1),.PITCH_METADATA(PITCH_METADATA)) taps(.clk(clk),.rst(rst),.sample_tick(sample_tick),.high_speed(link_high_speed),
   .pitch_steps(aligned_render_steps),.pitch_active(aligned_render_active),
   .effect_nodes({output_pcm,fx_nodes}),.effect_delays(fx_delays),.trace_coefficients(modulation_coefficients),.trace_flags(modulation_flags),.trace_gain(modulation_gain),
   .voices(tap_profile==2?fx_nodes:PROJECT3?aligned_voices:manual_voice_pcm),.capture_profile(tap_profile),.pcm(output_pcm),
   .command_valid(ext_valid&&taps_ext_request),.request(ext_request[63:0]),.command_done(taps_ext_done),.response(taps_ext_response),
   .recording(),.record_samples(),.frame_valid(tap_frame_valid),.frame_kind(tap_frame_kind),.frame_length(tap_frame_length),
   .frame_take(tap_frame_take),.frame_done(tap_frame_done),.byte_index(tap_byte_index),.byte_data(tap_byte));
 end else begin:no_studio_audio_taps
  assign taps_ext_done=0;assign taps_ext_response=0;assign tap_frame_valid=0;assign tap_frame_kind=0;assign tap_frame_length=0;assign tap_byte=0;
 end endgenerate
 project3_config #(.LEGACY_RECORDING(!PROJECT4)) configuration(.clk(clk),.rst(rst),.sample_tick(sample_tick),
  .command_valid(ext_valid&&!p4_mix_request&&!music_ext_request&&!taps_ext_request&&!upload_ext_request&&!mod_ext_request&&!fx_ext_request&&!fm_ext_request&&!prepare_ext_request),.request(ext_request[63:0]),.locked(PROJECT4 ? 1'b0:pcm_session||control_state[14]||control_state[15]||(|effective_function_press[14:13])),
  .recording(PROJECT4 ? 1'b0:control_state[14]),.replaying(PROJECT4 ? 1'b0:control_state[15]),.panic(effective_function_press[15]||(|effective_function_press[14:13])||effective_command_valid&&effective_command<4),
  .command_done(p3_ext_done),.response(p3_ext_response),.cfg(p3_cfg),.test_mode(p3_test),
  .lesson_valid(lesson_valid),.lesson_op(lesson_op),.lesson_index(lesson_index),.lesson_value(lesson_value),
  .lesson_done(lesson_done),.lesson_status(lesson_status),.lesson_result(lesson_result));
 project3_lesson lesson(.clk(clk),.rst(rst),.stop(effective_function_press[15]||(PROJECT3&&p3_test!=0)||mode==2),.sample_tick(sample_tick),.raw_gates(gates),
  .input_fault(fault||!ready||recalibrate),.toggle(PROJECT3&&effective_function_press[12]),
  .command_valid(lesson_valid),.command_op(lesson_op),.command_index(lesson_index),.command_value(lesson_value),
  .command_done(lesson_done),.status(lesson_status),.value(lesson_result),.expected_mask(lesson_mask),.next_note(lesson_next),
  .status_word(lesson_status_word),.timing_error_ms(lesson_error),.running(lesson_running));
 uart_monitor #(.UART_DIV(UART_DIV),.DYNAMIC_BAUD(PROJECT4),.EXT_WORDS(EXT_BITS/32),.STREAMS(PROJECT4)) host(.ext_enabled(PROJECT3!=0),.ext_valid(ext_valid),.ext_request(ext_request),.ext_done(ext_done),.ext_response(ext_response),.high_speed(link_high_speed),.clk(clk),.rst(rst),.uart_rx(monitor_rx),.uart_tx(monitor_tx),.display_bend(bend_cents),.sample_tick(sample_tick),
  .file_enabled(FILE_SERVICE!=0),.file_rx_ready(file_rx_ready),.file_rx_start(file_rx_start),.file_rx_write(file_rx_write),
  .file_rx_commit(file_rx_commit),.file_rx_abort(file_rx_abort),.file_rx_length(file_rx_length),
  .file_rx_sequence(file_rx_sequence),.file_rx_index(file_rx_index),.file_rx_byte(file_rx_byte),
  .stream_valid(serial_stream_valid),.stream_kind(serial_stream_kind),.stream_length(serial_stream_length),.stream_byte(serial_stream_byte),
  .stream_take(serial_stream_take),.stream_done(serial_stream_done),.stream_byte_index(serial_stream_index),
  .usb_diagnostics(usb_diagnostics),.usb_diagnostics_valid(usb_diagnostics_valid),
  .adc_armed(adc_armed),.adc_calibrated(adc_calibrated),.adc_fault_code(adc_fault_code),.adc_sample_valid(adc_sample_valid),.adc_frame_count(adc_frame_count),
  .raw(raw),.pressures(pressures),.envelopes(envelopes),.phases(phases),.steps(steps),.ratio(ratio),.gates(gates),.active(active),
  .ready(ready),.muted(muted||(mode==0&&!(PROJECT3&&p3_test!=0))),.fault(fault),.song(mode==2),.pcm(output_pcm),
  .control_state(control_state),.audio_mode((PROJECT3&&p3_test!=0)?2'd1:mode),.playing(playing),.done(done),.current_note(display_note),.next_note(display_next),
  .command_busy(command_valid||k1||k2||(|function_press)),.remote_press(host_function_press),.remote_command_valid(host_command_valid),.remote_command(host_command));
 // Lesson timing is generated locally. Keep the physical fault-code lamp
 // ahead of the teaching beat; the other seven lamps indicate target keys.
 wire lesson_led7=fault ? manual_led[7] :
  (!ready||recalibrate||!lesson_status_word[25]) ? 1'b1 : ~lesson_status_word[27];
 assign led_o=(PROJECT3&&lesson_running)?{lesson_led7,~lesson_mask}:mode==2?(PROJECT4?{manual_led[7],~active}:{manual_led[7],~playing,2'b11,~song_active}):mode==1?manual_led:8'hff;
 // Balanced eight-leaf priority tree: seven voices followed by voice zero
 // as the silent fallback. Three mux levels, without an encoded index mux or
 // a shared one-hot mask that fans out across all seven payloads.
 wire [49:0] display_leaf[0:6];
 genvar dv;
 generate for(dv=0;dv<7;dv=dv+1)begin:display_priority
  localparam [6:0] NOTE=dv==0?60:dv==1?62:dv==2?64:dv==3?65:dv==4?67:dv==5?69:71;
  localparam [2:0] INDEX=dv;
  assign display_leaf[dv]={INDEX,NOTE,steps[dv*24+:24],envelopes[dv*16+:16]};
 end endgenerate
 wire [49:0] display_pair01=active[0]?display_leaf[0]:display_leaf[1];
 wire [49:0] display_pair23=active[2]?display_leaf[2]:display_leaf[3];
 wire [49:0] display_pair45=active[4]?display_leaf[4]:display_leaf[5];
 wire [49:0] display_pair60=active[6]?display_leaf[6]:display_leaf[0];
 wire [49:0] display_group03=(|active[1:0])?display_pair01:display_pair23;
 wire [49:0] display_group46=(|active[5:4])?display_pair45:display_pair60;
 wire [49:0] display_selected=(|active[3:0])?display_group03:display_group46;
 wire [2:0] leading=display_selected[49:47];
 wire [6:0] leading_note=display_selected[46:40];
 wire [23:0] leading_step=display_selected[39:16];
 wire [15:0] leading_envelope=display_selected[15:0];
 reg [6:0] base_note;
 reg signed [12:0] bend_product=0;wire signed [11:0] bend_quarters;reg signed [17:0] pitch_q4=960;
 generate if(PROJECT4)begin:display_bend_divide
  project4_div25 convert(.clk(clk),.rst(rst),.value(bend_product),.result(bend_quarters),.valid());
 end else begin:legacy_display_bend_divide
  reg signed[11:0]quarters=0;assign bend_quarters=quarters;
  always @(posedge clk)if(rst)quarters<=0;else quarters<=bend_product/13'sd25;
 end endgenerate
 always @(posedge clk)begin
  if(rst)begin bend_product<=0;pitch_q4<=960;end
  else begin bend_product<=$signed(bend_cents[10:0])*13'sd4;pitch_q4<=$signed({1'b0,base_note,4'b0})+bend_quarters;end
 end
 always @*begin
  base_note=leading_note;
  if(ENABLE_PERFORMANCE)case(control_state[4:2])
   3'b110:base_note=base_note-24;
   3'b111:base_note=base_note-12;
   3'b001:base_note=base_note+12;
   3'b010:base_note=base_note+24;
   default:base_note=base_note;
  endcase

 end
 assign display_next=(PROJECT3&&lesson_running)?lesson_next:mode==2&&playing?melody_next:control_state[13]?teaching_note:7'd127;
 always @(posedge clk)begin
  if(rst)begin display_note<=127;display_valid<=0;display_pitch<=0;display_step<=0;display_envelope<=0;end
  else if(PROJECT3&&p3_test!=0)begin
   display_note<=127;display_pitch<=0;display_step<=steps[23:0];display_envelope<=envelopes[15:0];
   display_valid<=0; // A multi-frequency test has no single MIDI pitch trajectory.
  end else if(mode==2)begin
   display_note<=melody_note;display_pitch<={melody_note,4'b0};display_step<=melody_step;display_envelope<=melody_envelope;
   display_valid<=playing&&song_active[0]&&!muted;
  end else if(mode==1)begin
   display_note<=(pitch_q4+8)>>>4;display_pitch<=pitch_q4[10:0];display_step<=leading_step;display_envelope<=leading_envelope;
   display_valid<=(ready&&!fault||(PROJECT3&&p3_test!=0))&&(|active)&&!muted;
  end else begin display_note<=127;display_pitch<=0;display_step<=0;display_envelope<=0;display_valid<=0;end
 end
endmodule
