`timescale 1ns/1ps
module keyboard_audio #(parameter ENABLE_PERFORMANCE=0,SHARED_SONG=0,PROJECT3=0,DIRECT_PCM=0,EVENT_SONG=0,TONE_REFINEMENT=0,CONTROLLED_MIX=0,SHARED_SINE=EVENT_SONG,SHARED_TEXTURE=EVENT_SONG,REGISTERED_EVENT_TRIGGER=EVENT_SONG,SHARED_GAIN=EVENT_SONG,SHARED_TUNING=EVENT_SONG,ADVANCED_MODULATION=0,SHARED_ENVELOPE=EVENT_SONG,SEQUENTIAL_PRESET=EVENT_SONG,SHARED_PRESET=SEQUENTIAL_PRESET,SHARED_COEFFICIENTS=EVENT_SONG,ADVANCED_EFFECTS=0,FM_EDITING=0,AUDITION_PREPARE=0,PITCH_METADATA=0,HARD_MUTE=0)(
 input wire [6:0] hard_mute_mask,
 input wire audition_hold,audition_reset,output wire fx_ready,
 input wire[223:0]fm_cfg,
 input wire[415:0]fx_cfg,input wire fx_panic,output wire[111:0]fx_nodes,output wire[63:0]fx_delays,
 input wire[191:0]mod_cfg,
 input wire [511:0] cfg,input wire [1:0] test_mode,input wire[141:0] mix_cfg,
 input wire song_mode,song_clear,input wire [3:0] song_gates,
 input wire [95:0] song_steps,input wire [47:0] song_gains,
 input wire [6:0] event_gates,event_triggers,input wire [167:0] event_steps,input wire [83:0] event_gains,
 input wire clk,rst,running,ready,fault,clear_notes,input wire [13:0] settings,
 input wire [6:0] gates,input wire [83:0] pressures,input wire [18:0] ratio,
 output wire [6:0] voice_active,output wire sample_tick,
 output wire hp_bck,hp_ws,hp_din,i2s_bck,i2s_ws,i2s_sd,
 output wire signed [15:0] pcm_out,output wire [111:0] voice_samples,post_voice_samples,
 output wire [167:0] monitor_steps,output wire [111:0] monitor_envelopes,
 output wire[223:0]modulation_coefficients,output wire[31:0]modulation_flags,output wire[15:0]modulation_gain,
 output wire [20:0] monitor_phases,output wire[167:0]render_steps,output wire[6:0]render_active
);
 wire [167:0] steps,base_steps,unmodulated_steps,modulated_steps;wire[6:0]mod_gates,mod_triggers;
 wire mod_pitch_active,mod_sine_request,mod_sine_valid;wire[7:0]mod_sine_address;wire signed[15:0]mod_sine_a,mod_sine_b;wire[15:0]tremolo_gain;wire[223:0]modulation_trace;
 // Drain each same-sample event burst before launching all seven voices.
 // With the ROM adapter each head consumes three clocks; even fourteen
 // simultaneous off/on events settle before this fixed 64-clock boundary.
 reg [7:0] render_wait=0;reg extended_frame=0;
 always @(posedge clk)begin
  if(rst)begin render_wait<=0;extended_frame<=0;end
  else if(sample_tick)begin render_wait<=ADVANCED_MODULATION ? 192:64;extended_frame<=ADVANCED_MODULATION&&mod_pitch_active;end
  else if(render_wait!=0)render_wait<=render_wait-1'b1;
 end
 wire engine_tick=EVENT_SONG?(render_wait==(ADVANCED_MODULATION&&!extended_frame ? 129:1)):sample_tick;
 wire modulation_tick=ADVANCED_MODULATION&&render_wait==129;
 reg [13:0] registered_controls=0;
 always @(posedge clk)if(rst)registered_controls<=0;else registered_controls<=settings;
 wire [13:0] controls=ENABLE_PERFORMANCE?registered_controls:14'd0;
 wire [1:0] test_select=PROJECT3?test_mode:2'd0;
 wire testing=(test_select!=0);
 assign modulation_coefficients=testing ? 224'd0:modulation_trace;assign modulation_gain=testing ? 16'd32768:tremolo_gain;
 assign modulation_flags={17'd0,(mod_gates|voice_active),6'd0,(testing ? 2'd0:mod_cfg[1:0])};

 // Only ADSR words 0..4 enter the voices. Register their shared selection
 // so test mode does not drive seven envelope state machines combinationally.
 // Config commits at sample boundaries; this settles alongside gate_q well
 // before the next sample. Mode changes retain the existing voice_reset.
 reg [159:0] voice_cfg=0;
 always @(posedge clk)begin
  if(rst)voice_cfg<=0;
  else voice_cfg<=PROJECT3&&(!testing||test_select==3)?cfg[159:0]:160'd0;
 end
 reg [1:0] last_test=0;
 reg [16:0] test_clock=0;
 always @(posedge clk)begin
  if(rst)begin last_test<=0;test_clock<=0;end
  else begin last_test<=test_select;
   if(last_test!=test_select)test_clock<=0;
   else if(sample_tick)test_clock<=test_clock==97655?17'd0:test_clock+1'b1;
  end
 end
 wire auto_source=SHARED_SONG&&song_mode&&!testing;
 reg last_auto_source=0;
 always @(posedge clk)if(rst)last_auto_source<=0;else last_auto_source<=auto_source;
 reg voice_reset=1;
 // A missing controller clears live performance, but does not reset the
 // independent sound-test source every clock. Panic exits test_select first.
 always @(posedge clk)voice_reset<=rst||(AUDITION_PREPARE&&audition_hold)||(last_test!=test_select)||(auto_source!=last_auto_source)||(auto_source?song_clear:(ENABLE_PERFORMANCE&&!testing&&(clear_notes||fault)));
 reg [12:0] lfo=0;
 always @(posedge clk)if(rst)lfo<=0;else if(sample_tick)lfo<=lfo+1'b1;
 wire [2:0] lfo_magnitude=lfo[11]?~lfo[10:8]:lfo[10:8];
 assign monitor_steps=steps;
 keyboard_pitch pitch(.clk(clk),.rst(rst),.sample_tick(sample_tick),.ratio(ratio),.steps(base_steps));
 wire signed [15:0] voice_pcm[0:6],voice_pcm_raw[0:6];
 wire [15:0] voice_envelope[0:6];
 wire[6:0]envelope_gates,envelope_triggers,envelope_resets,envelope_custom,envelope_busy;
 wire[111:0]shared_envelopes;wire[20:0]shared_envelope_phases;
 generate if(SHARED_ENVELOPE)begin:envelope_bank
  project4_envelope_bank shared_adsr(.clk(clk),.rst(voice_reset),.sample_tick(engine_tick),.cfg(voice_cfg),.gates(envelope_gates),.triggers(envelope_triggers),.resets(envelope_resets),
   .levels(shared_envelopes),.phases(shared_envelope_phases),.custom(envelope_custom),.busy(envelope_busy),.deadline_error());
 end else begin:no_envelope_bank
  assign shared_envelopes=0;assign shared_envelope_phases=0;assign envelope_custom=0;assign envelope_busy=0;
 end endgenerate
 wire[6:0]preset_gates,preset_strums,preset_triggers,preset_changes,preset_busy;wire[13:0]preset_sounds;wire[839:0]preset_values;
 generate if(SHARED_PRESET)begin:preset_bank
  project4_preset_bank shared_states(.clk(clk),.rst(voice_reset),.sample_tick(engine_tick),.gates(preset_gates),.strums(preset_strums),.triggers(preset_triggers),.changes(preset_changes),.sounds(preset_sounds),.values(preset_values),.busy(preset_busy),.deadline_error());
 end else begin:no_preset_bank
  assign preset_busy=0;assign preset_values=0;
 end endgenerate
 wire[6:0]tuning_requests,tuning_accepted,tuning_valid;wire[167:0]tuning_steps;wire[26:0]tuning_period;wire[16:0]tuning_allpass;
 generate if(SHARED_TUNING)begin:tuning_bank
  project4_tuning_bank shared_divider(.clk(clk),.rst(voice_reset),.request(tuning_requests),.steps(tuning_steps),.accepted(tuning_accepted),.valid(tuning_valid),.period(tuning_period),.allpass(tuning_allpass));
 end else begin:no_tuning_bank
  assign tuning_accepted=0;assign tuning_valid=0;assign tuning_period=0;assign tuning_allpass=0;
 end endgenerate
 wire[48:0]gain_indexes;wire[83:0]gain_values;wire[6:0]gain_valid;
 generate if(SHARED_GAIN)begin:gain_bank
  project4_smoothed_gain_bank shared_gain_rom(.clk(clk),.rst(voice_reset),.sample_tick(engine_tick),.indexes(gain_indexes),.gates(preset_gates),.active(voice_active),.valid(gain_valid),.values(gain_values),.sine_request(mod_sine_request),.sine_address(mod_sine_address),.sine_valid(mod_sine_valid),.sine_a(mod_sine_a),.sine_b(mod_sine_b));
 end else begin:no_gain_bank
  assign gain_valid=0;assign gain_values=0;assign mod_sine_valid=0;assign mod_sine_a=0;assign mod_sine_b=0;
 end endgenerate
 wire[6:0] sine_requests,sine_valid;wire[55:0] sine_addresses;wire[111:0] sine_a,sine_b;
 wire[6:0]texture_requests,texture_valid,texture_gates;wire[13:0]texture_timbres;wire[125:0]texture_signals,texture_samples;wire[111:0]texture_onsets;
 generate if(SHARED_TEXTURE&&TONE_REFINEMENT)begin:texture_bank
  project4_texture_bank shared_colour(.clk(clk),.rst(voice_reset),.request(texture_requests),.gates(texture_gates),.timbres(texture_timbres),.signals(texture_signals),.onsets(texture_onsets),.valid(texture_valid),.samples(texture_samples));
 end else begin:no_texture_bank
  assign texture_valid=0;assign texture_samples=0;
 end endgenerate
 generate if(SHARED_SINE)begin:sine_bank
  project4_sine_bank shared_rom(.clk(clk),.rst(voice_reset),.request(sine_requests),.addresses(sine_addresses),.valid(sine_valid),.samples_a(sine_a),.samples_b(sine_b));
 end else begin:no_sine_bank
  assign sine_valid=0;assign sine_a=0;assign sine_b=0;
 end endgenerate
 generate if(ADVANCED_MODULATION)begin:advanced_modulation
  project4_modulation modulation(.clk(clk),.rst(voice_reset),.sample_tick(sample_tick),.render_tick(modulation_tick),.cfg(mod_cfg),
   .gates(mod_gates),.triggers(mod_triggers),.active(voice_active),.base_steps(unmodulated_steps),.sine_request(mod_sine_request),.sine_address(mod_sine_address),
   .sine_valid(mod_sine_valid),.sine_a(mod_sine_a),.sine_b(mod_sine_b),.steps(modulated_steps),.tremolo_gain(tremolo_gain),.pitch_active(mod_pitch_active),.trace_coefficients(modulation_trace),.fade_levels(),.done(),.deadline_error());
 end else begin:no_advanced_modulation
  assign modulation_trace=0;assign modulated_steps=unmodulated_steps;assign tremolo_gain=32768;assign mod_pitch_active=0;assign mod_sine_request=0;assign mod_sine_address=0;
 end endgenerate
 wire[6:0]coefficient_requests,coefficient_valid;wire[531:0]coefficient_contexts;wire[559:0]coefficient_results;
 generate if(SHARED_COEFFICIENTS&&FM_EDITING)begin:editable_coefficients
  project4_fm_bank #(.TONE_REFINEMENT(TONE_REFINEMENT)) shared_coefficients(.clk(clk),.rst(voice_reset),.sample_tick(sample_tick),.cfg(fm_cfg),.request(coefficient_requests),.contexts(coefficient_contexts),.valid(coefficient_valid),.results(coefficient_results));
 end else if(SHARED_COEFFICIENTS)begin:coefficient_bank
  project4_coefficient_bank #(.TONE_REFINEMENT(TONE_REFINEMENT)) shared_coefficients(.clk(clk),.rst(voice_reset),.request(coefficient_requests),.contexts(coefficient_contexts),.valid(coefficient_valid),.results(coefficient_results));
 end else begin:no_coefficient_bank
  assign coefficient_valid=0;assign coefficient_results=0;
 end endgenerate
 genvar v;
 generate for(v=0;v<7;v=v+1)begin:voices
  wire [23:0] fundamental=base_steps[v*24+:24];
  wire [23:0] score_step;wire [11:0] score_gain;wire score_gate,score_trigger;
  if(EVENT_SONG)begin:event_score_slot
   assign score_step=event_steps[v*24+:24];assign score_gain=event_gains[v*12+:12];
   assign score_gate=event_gates[v];assign score_trigger=event_triggers[v];
  end else if(v<4)begin:score_slot
   assign score_step=song_steps[v*24+:24];assign score_gain=song_gains[v*12+:12];assign score_gate=song_gates[v];
   assign score_trigger=0;
  end else begin:unused_score_slot
   assign score_step=0;assign score_gain=0;assign score_gate=0;
   assign score_trigger=0;
  end
  reg [23:0] octave_step;
  // Events drain before the fixed 64-clock launch. Register the source/test
  // selection here so its high fanout cannot reach the ADSR segment mux.
  reg event_trigger_q=0;
  always @(posedge clk)if(rst)event_trigger_q<=0;else event_trigger_q<=auto_source&&score_trigger;
  always @*case(controls[4:2])
   3'b110:octave_step=fundamental>>2;
   3'b111:octave_step=fundamental>>1;
   3'b001:octave_step=fundamental<<1;
   3'b010:octave_step=fundamental<<2;
   default:octave_step=fundamental;
  endcase
  reg [23:0] octave_q=0,octave_q2=0,depth_q=0,vibrato_q=0,target_q=0;
  reg direction_q=0;
  wire [23:0] vibrato_amount=(lfo_magnitude[0]?depth_q:24'd0)+(lfo_magnitude[1]?(depth_q<<1):24'd0)+(lfo_magnitude[2]?(depth_q<<2):24'd0);
  reg [23:0] gliding=0,glide_delta=0;
  reg glide_up=0;
  // Continuous 50 MHz pipeline, settled hundreds of clocks before each audio
  // sample. The unchanged default pitch takes the original direct path.
  always @(posedge clk)begin
   if(rst)begin octave_q<=0;octave_q2<=0;depth_q<=0;vibrato_q<=0;target_q<=0;direction_q<=0;glide_delta<=0;glide_up<=0;end
   else begin
    octave_q<=octave_step;
    depth_q<=controls[6:5]==1?(octave_step>>10):controls[6:5]==2?(octave_step>>9):controls[6:5]==3?(octave_step>>8):24'd0;
    octave_q2<=octave_q;vibrato_q<=vibrato_amount;direction_q<=lfo[12];
    target_q<=direction_q?octave_q2-vibrato_q:octave_q2+vibrato_q;
    glide_delta<=target_q>gliding?target_q-gliding:gliding-target_q;
    glide_up<=target_q>gliding;
   end
  end
  always @(posedge clk)begin
   if(rst)gliding<=0;
   else if(sample_tick)begin
    if(!controls[7]||!voice_active[v]||gliding==0)gliding<=target_q;
    else if(glide_up)gliding<=gliding+((glide_delta<32)?glide_delta:(glide_delta<4096)?24'd1:glide_delta>>12);
    else gliding<=gliding-((glide_delta<32)?glide_delta:(glide_delta<4096)?24'd1:glide_delta>>12);
   end
  end
  localparam [23:0] TEST_STEP=v==0?106859:v==1?143967:v==2?191384:v==3?251857:v==4?325387:v==5?422281:543915;
  assign unmodulated_steps[v*24+:24]=testing?TEST_STEP:auto_source?score_step:(!ENABLE_PERFORMANCE||controls[7:2]==0)?fundamental:controls[7]?gliding:target_q;
  assign steps[v*24+:24]=extended_frame&&!testing ? modulated_steps[v*24+:24]:unmodulated_steps[v*24+:24];
  assign mod_gates[v]=testing ? (test_select!=3||test_clock<48828):auto_source ? score_gate:(gates[v]&&ready&&!fault);
  assign mod_triggers[v]=auto_source&&score_trigger;
  keyboard_voice #(.ENABLE_PERFORMANCE(ENABLE_PERFORMANCE),.EXPLICIT_RETRIGGER(EVENT_SONG),.TONE_REFINEMENT(TONE_REFINEMENT),.VOICE_ID(v),.SHARED_SINE(SHARED_SINE),.SHARED_TEXTURE(SHARED_TEXTURE),.SMOOTH_GAIN(SHARED_GAIN),.SHARED_GAIN(SHARED_GAIN),.SHARED_TUNING(SHARED_TUNING),.SHARED_ENVELOPE(SHARED_ENVELOPE),.SEQUENTIAL_PRESET(SEQUENTIAL_PRESET),.SHARED_PRESET(SHARED_PRESET),.SHARED_COEFFICIENTS(SHARED_COEFFICIENTS),.PITCH_METADATA(PITCH_METADATA)) voice(.clk(clk),.rst(voice_reset),.sample_tick(engine_tick),.cfg({352'd0,voice_cfg}),.timbre(testing?(test_select==2?3'd3:3'd1):{controls[13],controls[1:0]}),
   .coefficient_ready(coefficient_valid[v]),.coefficient_result(coefficient_results[v*80+:80]),.coefficient_request(coefficient_requests[v]),.coefficient_context(coefficient_contexts[v*76+:76]),
   .shared_preset_busy(preset_busy[v]),.shared_preset_value(preset_values[v*120+:120]),.preset_gate(preset_gates[v]),.preset_strum(preset_strums[v]),.preset_trigger(preset_triggers[v]),.preset_change(preset_changes[v]),.preset_sound(preset_sounds[v*2+:2]),
   .tuning_accepted(tuning_accepted[v]),.tuning_ready(tuning_valid[v]),.shared_period(tuning_period),.shared_allpass(tuning_allpass),.tuning_request(tuning_requests[v]),.tuning_step(tuning_steps[v*24+:24]),
   .envelope_busy(envelope_busy[v]),.shared_custom(envelope_custom[v]),.shared_envelope(shared_envelopes[v*16+:16]),.shared_envelope_phase(shared_envelope_phases[v*3+:3]),.envelope_gate(envelope_gates[v]),.envelope_trigger(envelope_triggers[v]),.envelope_reset(envelope_resets[v]),
   .gain_ready(gain_valid[v]),.shared_gain(gain_values[v*12+:12]),.gain_index(gain_indexes[v*7+:7]),
   .texture_ready(texture_valid[v]),.shared_texture(texture_samples[v*18+:18]),.texture_request(texture_requests[v]),.texture_gate(texture_gates[v]),.texture_timbre(texture_timbres[v*2+:2]),.texture_signal(texture_signals[v*18+:18]),.texture_onset(texture_onsets[v*16+:16]),
   .sine_ready(sine_valid[v]),.shared_sine_a(sine_a[v*16+:16]),.shared_sine_b(sine_b[v*16+:16]),.sine_request(sine_requests[v]),.sine_address(sine_addresses[v*8+:8]),
   .note_trigger(REGISTERED_EVENT_TRIGGER?event_trigger_q:auto_source&&score_trigger),
   .gate(testing?(test_select!=3||test_clock<48828):auto_source?score_gate:(gates[v] && ready && !fault)),.strum_mode(!testing&&!auto_source&&controls[10]),.pressure(testing?12'd1024:auto_source?score_gain:pressures[v*12+:12]),
   .step(steps[v*24+:24]),.pcm(voice_pcm_raw[v]),.active(voice_active[v]),
   .envelope_level(voice_envelope[v]),.envelope_phase(monitor_phases[v*3+:3]),.pcm_step(render_steps[v*24+:24]),.pcm_active(render_active[v]));
  // Optional dedicated-player urgent stop; default0 preserves the original path.
  assign voice_pcm[v]=(HARD_MUTE&&hard_mute_mask[v])?16'sd0:voice_pcm_raw[v];
  assign monitor_envelopes[v*16+:16]=voice_envelope[v];
  assign voice_samples[v*16+:16]=voice_pcm[v];
 end endgenerate
 // Fixed wide sum: chords retain each note's amplitude; no priority selector.
 wire signed [19:0] sum01={{4{voice_pcm[0][15]}},voice_pcm[0]}+{{4{voice_pcm[1][15]}},voice_pcm[1]};
 wire signed [19:0] sum23={{4{voice_pcm[2][15]}},voice_pcm[2]}+{{4{voice_pcm[3][15]}},voice_pcm[3]};
 wire signed [19:0] sum45={{4{voice_pcm[4][15]}},voice_pcm[4]}+{{4{voice_pcm[5][15]}},voice_pcm[5]};
 wire signed [19:0] sum6={{4{voice_pcm[6][15]}},voice_pcm[6]};
 wire signed [19:0] sum_all=sum01+sum23+sum45+sum6;
 wire signed[19:0] chosen_mix;
 generate if(CONTROLLED_MIX)begin:controlled_mix
  wire signed[15:0] protected_mix;
  wire [111:0] post_gain_samples;wire limiting,deadline_error;
  project4_mixer mixer(.clk(clk),.rst(rst),.sample_tick(sample_tick),.voices(voice_samples),
   .target_gains(mix_cfg[16+:112]),.mute_mask(mix_cfg[128+:7]),.enabled_mask(mix_cfg[135+:7]),
   .pcm(protected_mix),.post_gains(post_gain_samples),.limiting(limiting),.deadline_error(deadline_error));
  assign chosen_mix={{4{protected_mix[15]}},protected_mix};
  assign post_voice_samples=post_gain_samples;
 end else begin:fixed_mix
  assign chosen_mix=sum_all;
  assign post_voice_samples=voice_samples;
 end endgenerate
 wire signed[19:0]expressive_mix;
 generate if(ADVANCED_MODULATION&&CONTROLLED_MIX)begin:output_tremolo
  reg signed[32:0]product=0;reg signed[15:0]value=0;
  always @(posedge clk)if(rst)begin product<=0;value<=0;end else begin product<=$signed(chosen_mix[15:0])*$signed({1'b0,modulation_gain});value<=product>>>15;end
  assign expressive_mix={{4{value[15]}},value};
 end else begin:no_output_tremolo
  assign expressive_mix=chosen_mix;
 end endgenerate
 reg [5:0] master_gain=0;
 wire enabled=testing||auto_source||(running && ready && !fault);
 reg signed [19:0] mixed=0;
 reg signed [26:0] scaled=0;
 reg signed [15:0] source_pcm=0;
 wire signed [26:0] limited=scaled>>>5;
 always @(posedge clk)begin
  if(rst)begin master_gain<=0;mixed<=0;scaled<=0;source_pcm<=0;end
  else begin
   if(sample_tick)begin
    if(enabled && master_gain<32)master_gain<=master_gain+1'b1;
    else if(!enabled && master_gain!=0)master_gain<=master_gain-1'b1;
   end
   mixed<=expressive_mix;scaled<=mixed*$signed({1'b0,master_gain});
   if(limited>32767)source_pcm<=32767;
   else if(limited< -32768)source_pcm<=-32768;
   else source_pcm<=limited[15:0];
  end
 end
 wire signed [15:0] processed_pcm;
 generate if(ADVANCED_EFFECTS)begin:project4_effects
  project4_fx_chain processor(.clk(clk),.rst(rst||(AUDITION_PREPARE&&audition_reset)),.sample_tick(sample_tick),.panic(fx_panic),.dry((AUDITION_PREPARE&&audition_hold)?16'sd0:source_pcm),
   .enabled(testing?3'd0:fx_cfg[2:0]),.chorus_wet(fx_cfg[32+:16]),.chorus_rate(fx_cfg[64+:32]),.chorus_depth(fx_cfg[96+:17]),
   .delay_wet(fx_cfg[128+:16]),.delay_time(fx_cfg[160+:14]),.delay_feedback(fx_cfg[192+:16]),
   .reverb_wet(fx_cfg[224+:16]),.reverb_damping(fx_cfg[256+:16]),
   .reverb_gains({fx_cfg[384+:16],fx_cfg[352+:16],fx_cfg[320+:16],fx_cfg[288+:16]}),
   .pcm(processed_pcm),.nodes(fx_nodes),.tap_delays(fx_delays),.deadline_error(),.ready(fx_ready));
 end else if(PROJECT3)begin:project3_effect
  assign fx_ready=1;
  assign fx_nodes=0;assign fx_delays=0;
  wire deadline_error;
  project3_fx processor(.clk(clk),.rst(voice_reset),.sample_tick(sample_tick),
   .enabled(!testing&&controls[9]&&(auto_source||!fault)),.dry(source_pcm),.cfg(cfg),.pcm(processed_pcm),.deadline_error(deadline_error));
 end else if(ENABLE_PERFORMANCE)begin:effect
  assign fx_ready=1;
  assign fx_nodes=0;assign fx_delays=0;
  performance_effect echo(.clk(clk),.rst(voice_reset),.sample_tick(sample_tick),.enabled(controls[9]&&(auto_source||!fault)),.dry(source_pcm),.pcm(processed_pcm));
 end else begin:no_effect
  assign fx_ready=1;
  assign fx_nodes=0;assign fx_delays=0;
  assign processed_pcm=source_pcm;
 end endgenerate
 wire [15:0] decoded_l,decoded_r;
 wire decoded_valid;
 assign pcm_out=processed_pcm;
 i2s_tx16 tx(.clk(clk),.rst(rst),.pcm_l(processed_pcm),.pcm_r(processed_pcm),
  .bck(i2s_bck),.ws(i2s_ws),.sd(i2s_sd),.sample_tick(sample_tick));
 generate if(!DIRECT_PCM)begin:legacy_serial
  i2s_rx16 rx(.clk(clk),.rst(rst),.bck(i2s_bck),.ws(i2s_ws),.sd(i2s_sd),
   .pcm_l(decoded_l),.pcm_r(decoded_r),.frame_valid(decoded_valid));
 end else begin:direct_serial
  assign decoded_l=processed_pcm;assign decoded_r=processed_pcm;assign decoded_valid=sample_tick;
 end endgenerate
 pt8211_tx16 adapter(.clk(clk),.rst(rst),.pcm_l(decoded_l),.pcm_r(decoded_r),
  .bck(hp_bck),.ws(hp_ws),.sd(hp_din));
endmodule
