`timescale 1ns/1ps
module project_button #(parameter integer TICKS=50000)(
 input wire clk,rst,key_n,output reg press=0
);
 reg meta=1,sync=1,stable=1;
 reg [19:0] count=0;
 always @(posedge clk)begin
  press<=0;
  if(rst)begin meta<=1;sync<=1;stable<=1;count<=0;end
  else begin
   meta<=key_n;sync<=meta;
   if(sync==stable)count<=0;
   else if(count==TICKS-1)begin stable<=sync;count<=0;if(!sync)press<=1;end
   else count<=count+1'b1;
  end
 end
endmodule

module project_fault_led #(parameter integer SLOT_TICKS=12500000)(
 input wire clk,rst,fault,input wire [2:0] code,output wire light
);
 reg [23:0] count=0;
 reg [3:0] slot=0;
 reg [2:0] previous_code=0;
 assign light=fault && !slot[0] && slot<{code,1'b0};
 always @(posedge clk)begin
  previous_code<=code;
  if(rst || !fault || previous_code!=code)begin count<=0;slot<=0;end
  else if(count==SLOT_TICKS-1)begin count<=0;slot<=slot+1'b1;end
  else count<=count+1'b1;
 end
endmodule


module project_pedal #(parameter integer TICKS=50000)(
 input wire clk,rst,key_n,output wire down
);
 (* async_reg="true" *) reg meta=1,sync=1;
 reg stable=1;reg[19:0]count=0;
 assign down=!stable;
 always @(posedge clk)begin
  if(rst)begin meta<=1;sync<=1;stable<=1;count<=0;end
  else begin
   meta<=key_n;sync<=meta;
   if(sync==stable)count<=0;
   else if(count==TICKS-1)begin stable<=sync;count<=0;end
   else count<=count+1'b1;
  end
 end
endmodule
