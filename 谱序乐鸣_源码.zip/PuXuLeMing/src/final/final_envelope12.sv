`timescale 1ns/1ps
// Original seven-context services: one for seven voices, two six-voice groups for twelve.
// ADSR arithmetic and sample boundaries stay unchanged.
module final_envelope12 #(parameter VOICE_COUNT=12)(
 input wire clk,rst,sample_tick,input wire[7:0]choices,
 input wire[VOICE_COUNT-1:0]gates,triggers,resets,
 output wire[VOICE_COUNT*16-1:0]levels,output wire[VOICE_COUNT*3-1:0]phases,
 output wire[VOICE_COUNT-1:0]active,output wire deadline_error
);
 function automatic[31:0]attack(input[1:0]x);
 case(x)0:attack=0;1:attack=244;2:attack=977;3:attack=3906;endcase endfunction
 function automatic[31:0]decay(input[1:0]x);
 case(x)0:decay=2441;1:decay=7324;2:decay=19531;3:decay=39063;endcase endfunction
 function automatic[31:0]sustain(input[1:0]x);
 case(x)0:sustain=13107;1:sustain=26214;2:sustain=45875;3:sustain=65535;endcase endfunction
 function automatic[31:0]release_time(input[1:0]x);
 case(x)0:release_time=3906;1:release_time=9766;2:release_time=24414;3:release_time=58594;endcase endfunction
 wire[159:0]cfg={release_time(choices[7:6]),sustain(choices[5:4]),decay(choices[3:2]),attack(choices[1:0]),32'd1};
 localparam GROUP_SIZE=VOICE_COUNT==12?6:7;
 localparam GROUPS=(VOICE_COUNT+GROUP_SIZE-1)/GROUP_SIZE;
 wire[GROUPS-1:0]errors;
 genvar g;generate for(g=0;g<GROUPS;g=g+1)begin:group
  localparam FIRST=g*GROUP_SIZE;
  localparam SIZE=VOICE_COUNT-FIRST<GROUP_SIZE?VOICE_COUNT-FIRST:GROUP_SIZE;
  wire[111:0]all_levels;wire[20:0]all_phases;
  project4_envelope_bank bank(.clk(clk),.rst(rst),.sample_tick(sample_tick),.cfg(cfg),
   .gates({{(7-SIZE){1'b0}},gates[FIRST+:SIZE]}),.triggers({{(7-SIZE){1'b0}},triggers[FIRST+:SIZE]}),.resets({{(7-SIZE){1'b1}},resets[FIRST+:SIZE]}),
   .levels(all_levels),.phases(all_phases),.custom(),.busy(),.deadline_error(errors[g]));
  assign levels[FIRST*16+:SIZE*16]=all_levels[SIZE*16-1:0];assign phases[FIRST*3+:SIZE*3]=all_phases[SIZE*3-1:0];
 end
 for(g=0;g<VOICE_COUNT;g=g+1)begin:status
  assign active[g]=phases[g*3+:3]!=0;
 end endgenerate
 assign deadline_error=|errors;
endmodule

// One shared scaler tours each actual voice once.
module final_envelope12_scale #(parameter VOICE_COUNT=12)(input wire clk,rst,input wire[VOICE_COUNT*16-1:0]samples,levels,
 output wire[VOICE_COUNT*16-1:0]scaled);
 reg[3:0]slot=0,slot_q=0;reg signed[32:0]product=0;
 reg signed[15:0]source_q=0;reg unity_q=0;
 always @(posedge clk)begin
  if(rst)begin slot<=0;slot_q<=0;product<=0;source_q<=0;unity_q<=0;end
  else begin
   slot<=slot==VOICE_COUNT-1?0:slot+1'b1;slot_q<=slot;
   source_q<=samples[slot*16+:16];unity_q<=levels[slot*16+:16]==65535;
   product<=$signed(samples[slot*16+:16])*$signed({1'b0,levels[slot*16+:16]});
  end
 end
 genvar v;generate for(v=0;v<VOICE_COUNT;v=v+1)begin:voice
  reg[15:0]value=0;
  always @(posedge clk)begin
   if(rst)value<=0;
   else if(slot_q==v)value<=unity_q?source_q:product[31:16];
  end
  assign scaled[v*16+:16]=value;
 end endgenerate
endmodule
