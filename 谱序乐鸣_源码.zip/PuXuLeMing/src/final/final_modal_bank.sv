`timescale 1ns/1ps
// Six independently phased modes per note. One synchronous sine ROM and two
// scheduled products render four notes in 88 work clocks. No recorded sound samples.
module final_modal_bank(
 input wire clk,rst,render_tick,input wire [3:0] gates,triggers,
 input wire [95:0] steps,input wire [47:0] gains,input wire [11:0] timbres,
 // Retained as an ignored compatibility input; Final uses preset envelopes.
 input wire [159:0] adsr_cfg,
 output reg [63:0] samples=0,output wire [3:0] active,
 output wire [63:0] envelopes,output wire busy,output reg deadline_error=0
);
 reg signed [15:0] sine[0:1023];
 initial $readmemh("src/final/final_sine.hex",sine);
 reg [23:0] phase[0:23];
 reg [23:0] body[0:3];reg [15:0] bright[0:3],attack[0:3];
 reg [31:0] noise[0:3];reg [3:0] previous_gate=0;
 genvar g;
 generate for(g=0;g<4;g=g+1)begin:preset_envelopes
  assign envelopes[g*16+:16]=body[g][23:8];
  assign active[g]=body[g]>256;
 end endgenerate
 reg [1:0] slot=0;reg [2:0] mode=0;reg [3:0] state=0;
 reg signed [15:0] sine_q=0;reg [15:0] coefficient=0;
 reg signed [32:0] modal_product=0;reg signed [23:0] sum=0;
 reg signed [40:0] envelope_product=0;reg signed [36:0] gain_product=0;
 reg [15:0] env=0;reg [11:0] gain_q=0;
 reg [31:0] attack_product=0;reg [2:0] sound=0;
 reg [23:0] base_step=0;reg [15:0] brightness=0;
 wire [4:0] address_index=slot*6+mode;
 reg [11:0] multiplier;reg [15:0] weight;
 // Spectra evolve per note: grand hammer brightness and slight upper-mode
 // inharmonicity, plucked guitar's pick-position comb, mellow sax breath/reed.
 always @*begin
  multiplier=256;weight=0;
  case(sound)
   1:case(mode)
    0:begin multiplier=256;weight=19000;end
    1:begin multiplier=512;weight=7000+(brightness>>2);end
    2:begin multiplier=769;weight=3500+(brightness>>3);end
    3:begin multiplier=1027;weight=brightness>>3;end
    4:begin multiplier=1287;weight=brightness>>4;end
    5:begin multiplier=1548;weight=brightness>>5;end
   endcase
   2:case(mode)
    0:begin multiplier=256;weight=21000;end
    1:begin multiplier=512;weight=8500+(brightness>>4);end
    2:begin multiplier=768;weight=brightness>>3;end
    3:begin multiplier=1024;weight=brightness>>6;end
    4:begin multiplier=1280;weight=brightness>>4;end
    5:begin multiplier=1536;weight=brightness>>5;end
   endcase
   3:case(mode)
    0:begin multiplier=256;weight=16000;end
    1:begin multiplier=512;weight=10000+(brightness>>4);end
    2:begin multiplier=768;weight=7000+(brightness>>5);end
    3:begin multiplier=1024;weight=3500;end
    4:begin multiplier=1280;weight=2000;end
    5:begin multiplier=1536;weight=1200;end
   endcase
  endcase
  // Discard modes above Nyquist instead of folding them into audible aliases.
  if((({12'd0,base_step}*multiplier)>>8)>=36'h0800000)weight=0;
 end
 wire [35:0] step_product=base_step*multiplier;
 assign busy=state!=0;
 integer i;
 always @(posedge clk)begin
  if(rst)begin
   samples<=0;previous_gate<=0;slot<=0;mode<=0;state<=0;deadline_error<=0;
   sine_q<=0;coefficient<=0;modal_product<=0;sum<=0;envelope_product<=0;gain_product<=0;
   env<=0;gain_q<=0;attack_product<=0;sound<=0;base_step<=0;brightness<=0;
   for(i=0;i<24;i=i+1)phase[i]<=0;
   for(i=0;i<4;i=i+1)begin body[i]<=0;bright[i]<=0;attack[i]<=0;noise[i]<=32'h1aceb00c+i*571;end
  end else if(render_tick)begin
   if(busy)deadline_error<=1;
   slot<=0;mode<=0;state<=1;previous_gate<=gates;
   for(i=0;i<4;i=i+1)begin
    noise[i]<={noise[i][30:0],noise[i][31]^noise[i][21]^noise[i][1]^noise[i][0]};
    if(gates[i]&&(triggers[i]||!previous_gate[i]))begin
     body[i]<=24'hffffff;bright[i]<=65535;attack[i]<=0;
    end else begin
     if(body[i]>256)begin
      if(!gates[i])body[i]<=body[i]-(body[i]>>9)-1;
      else if(timbres[i*3+:3]==3)body[i]<=24'hffffff;
      else body[i]<=body[i]-(body[i]>>(timbres[i*3+:3]==2?13:15))-1;
     end else body[i]<=0;
     bright[i]<=bright[i]-(bright[i]>>12)-(bright[i]!=0);
     if(attack[i]<65520)attack[i]<=attack[i]+((65535-attack[i])>>(timbres[i*3+:3]==3?9:5))+1;
     else attack[i]<=65535;
    end
   end
  end else case(state)
   1:begin
    sound<=timbres[slot*3+:3];base_step<=steps[slot*24+:24];
    brightness<=bright[slot];gain_q<=gains[slot*12+:12];
    attack_product<=envelopes[slot*16+:16]*attack[slot];sum<=0;mode<=0;state<=2;
   end
   2:begin
    env<=attack_product[31:16];
    sine_q<=sine[phase[address_index][23:14]];coefficient<=weight;
    phase[address_index]<=phase[address_index]+step_product[31:8];state<=3;
   end
   3:begin modal_product<=sine_q*$signed({1'b0,coefficient});state<=4;end
   4:begin
    sum<=sum+(modal_product>>>15);
    if(mode==5)state<=5;else begin mode<=mode+1'b1;state<=2;end
   end
   5:begin
    // Low-level decorrelated breath on sax only; hammer/pick transients are
    // procedural noise multiplied by the independently decaying brightness.
    envelope_product<=(sum+((sound==3)?($signed(noise[slot][15:0])>>>7):24'sd0))*$signed({1'b0,env});state<=6;
   end
   6:begin gain_product<=$signed(envelope_product>>>16)*$signed({1'b0,gain_q});state<=7;end
   7:begin
    if(sound==0||gain_q==0)samples[slot*16+:16]<=0;
    else if((gain_product>>>14)>32767)samples[slot*16+:16]<=32767;
    else if((gain_product>>>14)<-32768)samples[slot*16+:16]<=-32768;
    else samples[slot*16+:16]<=gain_product>>>14;
    if(slot==3)state<=0;else begin slot<=slot+1'b1;state<=1;end
   end
   default:state<=0;
  endcase
 end
endmodule
