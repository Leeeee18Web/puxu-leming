module final_panel #(parameter SHOW_PEDAL=0,HISTORY_PREFETCH=0,KEYBOARD_VIEW=0,HIDE_EP=0,LARGE_STATUS=0)(
 input wire pixel_clk,rstn,den,hsync,vsync,input wire [13:0] x,y,input wire pedal_down,
 input wire [2:0] page,input wire [1:0] mode,input wire playing,muted,note_valid,input wire [6:0] next_note,
 input wire[24:0]keyboard_held,input wire[374:0]keyboard_labels,
 input wire [6:0] base_note,input wire [3:0] gates,input wire [27:0] notes,input wire [47:0] gains,
 input wire [6:0] home_gates,input wire [83:0] home_gains,
 input wire piano_ready,touch_ready,recording,replaying,record_full,
 input wire [12:0] record_count,input wire [15:0] record_milliseconds,
 input wire [2:0] timbre,input wire timbre_open,xy_overview,input wire [31:0] synth_config,
 input wire [7:0] envelope_choices,input wire preview_busy,
 input wire [6:0] knob,raw_knob,input wire raw_known,pickup_wait,
 input wire [1:0] touch_state,
 input wire [1:0] pattern_mode,input wire [6:0] pattern_selected,input wire [48:0] pattern_notes,
 input wire pattern_busy,input wire [2:0] pattern_count,input wire pattern_full,
 input wire [6:0] lesson_target,lesson_feedback_note,input wire [1:0] lesson_feedback,
 input wire [5:0] lesson_position,input wire lesson_done,
 input wire [1:0] knob_mode,input wire [6:0] last_note,last_velocity,mod_depth,
 input wire [47:0] wave_data,input wire [7:0] spectrum_data,spectrum_peak,
 input wire [1:0] spectrum_zoom,input wire visual_valid,
 input wire [10:0] tone_data,input wire [16:0] tone_curve,input wire [9:0] tone_count,
 input wire xy_data,xy_valid,input wire [5:0] xy_settings,
 output wire [9:0] wave_addr,output wire [6:0] spectrum_addr,
 output wire [9:0] tone_addr,output wire [15:0] xy_addr,
 output reg [23:0] rgb,output reg den_out,hsync_out,vsync_out
);
 `include "final_geometry.vh"
 `include "src/final/final_text_map.vh"
 `include "src/final/final_label_constants.vh"
 localparam [23:0] BG=24'h10151b,TEXT=24'heff7f7,EDGE=24'h536975,
  CYAN=24'h60d9ed,GREEN=24'h78e6af,YELLOW=24'hf5c767;
 reg pedal1=0,pedal2=0,pedal_o=0;
 always @(posedge pixel_clk)begin
  if(!rstn)begin pedal1<=0;pedal2<=0;pedal_o<=0;end
  else begin pedal1<=SHOW_PEDAL&&pedal_down;pedal2<=pedal1;pedal_o<=pedal2;end
 end
 reg [31:0] font[0:8191] /* synthesis syn_romstyle="block_rom" */;
 initial $readmemh("src/final/final_font.hex",font);
 wire [9:0] rel_x=x>=128&&x<896?x-128:0;
 wire [6:0] bin=rel_x/10'd6;
 assign wave_addr=x[9:0];
 // READ_GATED history supplies its head when this page/window is inactive.
 assign tone_addr=HISTORY_PREFETCH?(x>=14'd127&&x<14'd895 ? x-14'd127 : 14'd0):rel_x;
 assign spectrum_addr=page==2?(spectrum_zoom==0?{2'b0,bin[6:2]}:spectrum_zoom==1?{1'b0,bin[6:1]}:bin):0;
 assign xy_addr={y[7:0]-8'd216,x[7:0]-8'd128};
 reg [9:0] px0=0,py0=0,px1=0,py1=0,px=0,py=0;
 reg [2:0] pg0=0,pg1=0,pg=0;reg [1:0] md0=0,md1=0,md=0;
 wire [23:0] graph_color;
 p8_p3_graph graph(.pixel_clk(pixel_clk),.x({4'd0,px0}),.y({4'd0,py0}),.page(pg0),
  .wave_data(wave_data),.spectrum_data(spectrum_data),.spectrum_peak(spectrum_peak),
  .visual_valid(visual_valid),.tone_data(tone_data),.tone_curve(tone_curve),
  .tone_count(tone_count),.xy_data(xy_data),.xy_valid(xy_valid),.xy_settings(xy_settings),.color(graph_color));
 function automatic in_box(input integer ax,ay,bx,by);
 begin in_box=px>=ax&&px<bx&&py>=ay&&py<by;end endfunction
 function automatic edgebox(input integer ax,ay,bx,by);
 begin edgebox=in_box(ax,ay,bx,by)&&!in_box(ax+2,ay+2,bx-2,by-2);end endfunction
 // Fixed button geometry is evaluated on the existing px1 -> px edge.
 // The colour and text stages still consume the original pixel epoch.
 function automatic edgebox_pre(input integer ex,ey,ax,ay,bx,by);
 begin edgebox_pre=ex>=ax&&ex<bx&&ey>=ay&&ey<by&&
  !(ex>=ax+2&&ex<bx-2&&ey>=ay+2&&ey<by-2);end endfunction
 (* syn_preserve=1,syn_keep=1 *)reg[2:0]header_hit2=0;
 (* syn_preserve=1,syn_keep=1 *)reg header_edge2=0,tab_edge2=0;
 wire header_edge_pre=edgebox_pre(px1,py1,8,8,104,56)||edgebox_pre(px1,py1,116,8,244,56)||
  edgebox_pre(px1,py1,260,8,388,56)||edgebox_pre(px1,py1,416,8,544,56)||edgebox_pre(px1,py1,560,8,688,56);
 reg tab_edge_pre;
 always @*begin
  tab_edge_pre=0;
  for(integer ht=0;ht<6;ht=ht+1)tab_edge_pre=tab_edge_pre||edgebox_pre(px1,py1,8+144*ht,72,144+144*ht,120);
 end
 always @(posedge pixel_clk)begin
  if(!rstn)begin header_hit2<=0;header_edge2<=0;tab_edge2<=0;end
  else begin header_hit2<=3'(p8_header_hit(px1,py1));header_edge2<=header_edge_pre;tab_edge2<=tab_edge_pre;end
 end
 function automatic [6:0] digit_label(input integer n);begin digit_label=p8_digit_label(n[3:0]);end endfunction
 function automatic integer degree(input [6:0] semitone);
 begin case(semitone)
  7'd0,7'd1,7'd12,7'd13,7'd24,7'd25,7'd36,7'd37,7'd48,7'd49,7'd60,7'd61,7'd72,7'd73,7'd84,7'd85,7'd96,7'd97,7'd108,7'd109,7'd120,7'd121:degree=1;
  7'd2,7'd3,7'd14,7'd15,7'd26,7'd27,7'd38,7'd39,7'd50,7'd51,7'd62,7'd63,7'd74,7'd75,7'd86,7'd87,7'd98,7'd99,7'd110,7'd111,7'd122,7'd123:degree=2;
  7'd4,7'd16,7'd28,7'd40,7'd52,7'd64,7'd76,7'd88,7'd100,7'd112,7'd124:degree=3;
  7'd5,7'd6,7'd17,7'd18,7'd29,7'd30,7'd41,7'd42,7'd53,7'd54,7'd65,7'd66,7'd77,7'd78,7'd89,7'd90,7'd101,7'd102,7'd113,7'd114,7'd125,7'd126:degree=4;
  7'd7,7'd8,7'd19,7'd20,7'd31,7'd32,7'd43,7'd44,7'd55,7'd56,7'd67,7'd68,7'd79,7'd80,7'd91,7'd92,7'd103,7'd104,7'd115,7'd116,7'd127:degree=5;
  7'd9,7'd10,7'd21,7'd22,7'd33,7'd34,7'd45,7'd46,7'd57,7'd58,7'd69,7'd70,7'd81,7'd82,7'd93,7'd94,7'd105,7'd106,7'd117,7'd118:degree=6;
  7'd11,7'd23,7'd35,7'd47,7'd59,7'd71,7'd83,7'd95,7'd107,7'd119:degree=7;
  default:degree=1;endcase end endfunction
 function automatic integer octave_dots(input [6:0] n);
 begin
  if(n<12)octave_dots=-5;else if(n<24)octave_dots=-4;
  else if(n<36)octave_dots=-3;else if(n<48)octave_dots=-2;
  else if(n<60)octave_dots=-1;else if(n<72)octave_dots=0;
  else if(n<84)octave_dots=1;else if(n<96)octave_dots=2;
  else if(n<108)octave_dots=3;else if(n<120)octave_dots=4;else octave_dots=5;
 end endfunction
 reg u_piano_ready1=0,u_piano_ready2=0,u_touch_ready1=0,u_touch_ready2=0;
 reg u_recording1=0,u_recording2=0,u_replaying1=0,u_replaying2=0,u_full1=0,u_full2=0;
 reg [5:0]u_fx1=0,u_fx2=0,u_fx_o=0;
 reg u_dropdown1=0,u_dropdown2=0,u_overview1=0,u_overview2=0;
 reg [2:0] u_timbre1=0,u_timbre2=0;
 reg [19:0] record_digits1=0,record_digits2=0;
 reg [7:0] seconds_digits1=0,seconds_digits2=0;
 reg [127:0] xy_preview[0:1279] /* synthesis syn_romstyle="block_rom" */;
 initial $readmemh("src/final/final_xy.hex",xy_preview);
 // Registered preview address separates coordinate decode from BSRAM access.
 reg [127:0] xy_preview_row1=0;
 reg [10:0] preview_address1=0;
 reg [6:0] xy_preview_col1=0,xy_preview_col2=0;
 reg xy_preview_valid1=0,xy_preview_valid2=0,xy_preview_on3=0;
 wire [19:0] preview_tile_valid0;
 wire [10:0] preview_tile_address0[0:19];
 wire [6:0] preview_tile_col0[0:19];
 genvar pv;
 generate for(pv=0;pv<20;pv=pv+1)begin:preview_address_shape
  localparam integer LEFT=168+216*(pv%4),TOP=218+72*(pv/4);
  wire [5:0] ROW=py0[5:0]-6'(TOP);
  wire [6:0] COL=px0[6:0]-7'(LEFT);
  assign preview_tile_valid0[pv]=px0>=LEFT&&px0<LEFT+128&&py0>=TOP&&py0<TOP+64;
  assign preview_tile_address0[pv]=preview_tile_valid0[pv]?{5'(pv),ROW}:11'd0;
  assign preview_tile_col0[pv]=preview_tile_valid0[pv]?COL:7'd0;
 end endgenerate
 wire [10:0] preview_matrix_address0=preview_tile_address0[0]|preview_tile_address0[1]|preview_tile_address0[2]|preview_tile_address0[3]|preview_tile_address0[4]|preview_tile_address0[5]|preview_tile_address0[6]|preview_tile_address0[7]|preview_tile_address0[8]|preview_tile_address0[9]|preview_tile_address0[10]|preview_tile_address0[11]|preview_tile_address0[12]|preview_tile_address0[13]|preview_tile_address0[14]|preview_tile_address0[15]|preview_tile_address0[16]|preview_tile_address0[17]|preview_tile_address0[18]|preview_tile_address0[19];
 wire [6:0] preview_matrix_col0=preview_tile_col0[0]|preview_tile_col0[1]|preview_tile_col0[2]|preview_tile_col0[3]|preview_tile_col0[4]|preview_tile_col0[5]|preview_tile_col0[6]|preview_tile_col0[7]|preview_tile_col0[8]|preview_tile_col0[9]|preview_tile_col0[10]|preview_tile_col0[11]|preview_tile_col0[12]|preview_tile_col0[13]|preview_tile_col0[14]|preview_tile_col0[15]|preview_tile_col0[16]|preview_tile_col0[17]|preview_tile_col0[18]|preview_tile_col0[19];
 wire preview_normal_valid0=px0>=864&&px0<992&&py0>=204&&py0<268;
 wire [4:0] preview_normal_id0={(xy_settings[4:2]>4?3'd0:xy_settings[4:2]),xy_settings[1:0]};
 wire [5:0] preview_normal_row0=py0[5:0]-6'd12;
 wire [6:0] preview_normal_col0=px0[6:0]-7'd96;
 always @(posedge pixel_clk)begin
  preview_address1<=pg0==3?(xy_overview?preview_matrix_address0:{preview_normal_id0,preview_normal_row0}):11'd0;
  xy_preview_col1<=xy_overview?preview_matrix_col0:preview_normal_col0;
  xy_preview_valid1<=pg0==3&&(xy_overview?(|preview_tile_valid0):preview_normal_valid0);
  xy_preview_row1<=xy_preview[preview_address1];
  xy_preview_col2<=xy_preview_col1;xy_preview_valid2<=xy_preview_valid1;
  xy_preview_on3<=xy_preview_valid2&&xy_preview_row1[127-xy_preview_col2];
 end
 always @(posedge pixel_clk)begin
  u_piano_ready1<=piano_ready;u_piano_ready2<=u_piano_ready1;u_touch_ready1<=touch_ready;u_touch_ready2<=u_touch_ready1;
  u_recording1<=recording;u_recording2<=u_recording1;u_replaying1<=replaying;u_replaying2<=u_replaying1;u_full1<=record_full;u_full2<=u_full1;
  u_fx1<=synth_config[5:0];u_fx2<=u_fx1;
  u_dropdown1<=timbre_open;u_dropdown2<=u_dropdown1;u_overview1<=xy_overview;u_overview2<=u_overview1;
  u_timbre1<=timbre;u_timbre2<=u_timbre1;
  record_digits1<={4'd0,4'(record_count/1000),4'((record_count/100)%10),4'((record_count/10)%10),4'(record_count%10)};record_digits2<=record_digits1;
  seconds_digits1<={4'(record_milliseconds/10000),4'((record_milliseconds/1000)%10)};seconds_digits2<=seconds_digits1;
 end
 // Geometry selection is one stage. Glyph address and ROM are separate stages.
 reg [23:0] color,ink,key_state;reg [6:0] label;reg text_on,scale2,scale_half;
 integer tx,ty,dx,dy,i,bx,bw,hit,keyn,oct,dot,barh,thumb,fx,guide_note;
 reg held,sharp,key_active;
 reg [3:0] ci;reg [4:0] row,col;
 reg [6:0] eff_hund,eff_tens,eff_ones;
 always @(posedge pixel_clk)begin
  eff_hund<=knob/100;eff_tens<=(knob/10)%10;eff_ones<=knob%10;
 end
 // UI context follows the exact geometry sample through both added cuts.
 reg u_playing1=0,u_playing2=0;
 reg u_muted1=0,u_muted2=0;
 reg u_note_valid1=0,u_note_valid2=0;
 reg [6:0] u_base_note1=0,u_base_note2=0;
 reg [3:0] u_gates1=0,u_gates2=0;
 reg [27:0] u_notes1=0,u_notes2=0;
 reg [83:0] u_gains1=0,u_gains2=0;
 reg[24:0]u_keyboard_held1=0;reg[374:0]u_keyboard_labels1=0;
 reg [6:0] u_home_gates1=0;
 reg [6:0] u_knob1=0,u_knob2=0;
 reg [1:0] u_touch_state1=0,u_touch_state2=0;
 reg [6:0] u_lesson_target1=0,u_lesson_target2=0;
 reg [6:0] u_lesson_feedback_note1=0,u_lesson_feedback_note2=0;
 reg [1:0] u_lesson_feedback1=0,u_lesson_feedback2=0;
 reg [5:0] u_lesson_position1=0,u_lesson_position2=0;
 reg u_lesson_done1=0,u_lesson_done2=0;
 reg [1:0] u_spectrum_zoom1=0,u_spectrum_zoom2=0;
 reg [5:0] u_xy_settings1=0,u_xy_settings2=0;
 reg [1:0] u_pattern_mode0=0,u_pattern_mode1=0,u_pattern_mode2=0;
 reg [6:0] u_pattern_selected0=0;
 reg [48:0] u_pattern_notes0=0;
 reg u_pattern_busy0=0,u_pattern_full0=0;
 reg [2:0] u_pattern_count0=0;
 reg [6:0] u_pattern_selected1=0;
 reg [48:0] u_pattern_notes1=0;
 reg u_pattern_busy1=0,u_pattern_busy2=0,u_pattern_full1=0,u_pattern_full2=0;
 reg [2:0] u_pattern_count1=0,u_pattern_count2=0;
 reg [6:0] u_eff_hund1=0,u_eff_hund2=0;
 reg [6:0] u_eff_tens1=0,u_eff_tens2=0;
 reg [6:0] u_eff_ones1=0,u_eff_ones2=0;
 always @(posedge pixel_clk)begin
  u_pattern_mode0<=pattern_mode;u_pattern_mode1<=u_pattern_mode0;u_pattern_mode2<=u_pattern_mode1;
  u_pattern_selected0<=pattern_selected;u_pattern_selected1<=u_pattern_selected0;u_pattern_notes0<=pattern_notes;u_pattern_notes1<=u_pattern_notes0;
  u_pattern_busy0<=pattern_busy;u_pattern_busy1<=u_pattern_busy0;u_pattern_busy2<=u_pattern_busy1;
  u_pattern_count0<=pattern_count;u_pattern_count1<=u_pattern_count0;u_pattern_count2<=u_pattern_count1;
  u_pattern_full0<=pattern_full;u_pattern_full1<=u_pattern_full0;u_pattern_full2<=u_pattern_full1;
  u_playing1<=playing;u_playing2<=u_playing1;
  u_muted1<=muted;u_muted2<=u_muted1;
  u_note_valid1<=note_valid;u_note_valid2<=u_note_valid1;
  u_base_note1<=base_note;u_base_note2<=u_base_note1;
  u_gates1<=gates;u_gates2<=u_gates1;
  u_notes1<=notes;u_notes2<=u_notes1;
  u_keyboard_held1<=keyboard_held;u_keyboard_labels1<=keyboard_labels;
  u_home_gates1<=home_gates;u_gains1<=home_gains;u_gains2<=u_gains1;
  u_knob1<=knob;u_knob2<=u_knob1;
  u_touch_state1<=touch_state;u_touch_state2<=u_touch_state1;
  u_lesson_target1<=lesson_target;u_lesson_target2<=u_lesson_target1;
  u_lesson_feedback_note1<=lesson_feedback_note;u_lesson_feedback_note2<=u_lesson_feedback_note1;
  u_lesson_feedback1<=lesson_feedback;u_lesson_feedback2<=u_lesson_feedback1;
  u_lesson_position1<=lesson_position;u_lesson_position2<=u_lesson_position1;
  u_lesson_done1<=lesson_done;u_lesson_done2<=u_lesson_done1;
  u_spectrum_zoom1<=spectrum_zoom;u_spectrum_zoom2<=u_spectrum_zoom1;
  u_xy_settings1<=xy_settings;u_xy_settings2<=u_xy_settings1;
  u_eff_hund1<=eff_hund;u_eff_hund2<=u_eff_hund1;
  u_eff_tens1<=eff_tens;u_eff_tens2<=u_eff_tens1;
  u_eff_ones1<=eff_ones;u_eff_ones2<=u_eff_ones1;
 end
 // Keyboard geometry and notation use the existing graph alignment stages.
 reg signed [5:0] keyhit1=-1,keyhit2=-1;
 // Shape masks are decoded before the color-priority register cut.
 reg key_border2=0,key_accent2=0,key_gloss2=0,key_label_on2=0,key_accidental2=0;
 reg [9:0] key_text_x2=0,key_text_y2=0;
 reg [4:0] key_dot_up2=0,key_dot_down2=0;
 wire [5:0] white_pos_pre=px1-10'd32,black_pos_pre=px1-10'd12;
 wire [9:0] white_left_pre=((px1-10'd32)&10'h3c0)+10'd32;
 wire [9:0] black_left_pre=((px1-10'd12)&10'h3c0)+10'd12;
 wire keysharp_pre=keyhit1==6'sd1||keyhit1==6'sd3||keyhit1==6'sd6||keyhit1==6'sd8||keyhit1==6'sd10||
                   keyhit1==6'sd13||keyhit1==6'sd15||keyhit1==6'sd18||keyhit1==6'sd20||keyhit1==6'sd22;
 integer kd;
 reg [7:0] keyvalue2=0;reg keysharp2=0,keyheld2=0,keyselected2=0;
 reg [3:0] keydegree2=1;
 integer keyoct2=0;
 reg [7:0] lesson_digits2=0;
 function automatic [7:0] lesson_digits(input [5:0] position);
 begin case(position)
  6'd0:lesson_digits=8'h01;
  6'd1:lesson_digits=8'h02;
  6'd2:lesson_digits=8'h03;
  6'd3:lesson_digits=8'h04;
  6'd4:lesson_digits=8'h05;
  6'd5:lesson_digits=8'h06;
  6'd6:lesson_digits=8'h07;
  6'd7:lesson_digits=8'h08;
  6'd8:lesson_digits=8'h09;
  6'd9:lesson_digits=8'h10;
  6'd10:lesson_digits=8'h11;
  6'd11:lesson_digits=8'h12;
  6'd12:lesson_digits=8'h13;
  6'd13:lesson_digits=8'h14;
  6'd14:lesson_digits=8'h15;
  6'd15:lesson_digits=8'h16;
  6'd16:lesson_digits=8'h17;
  6'd17:lesson_digits=8'h18;
  6'd18:lesson_digits=8'h19;
  6'd19:lesson_digits=8'h20;
  6'd20:lesson_digits=8'h21;
  6'd21:lesson_digits=8'h22;
  6'd22:lesson_digits=8'h23;
  6'd23:lesson_digits=8'h24;
  6'd24:lesson_digits=8'h25;
  6'd25:lesson_digits=8'h26;
  6'd26:lesson_digits=8'h27;
  6'd27:lesson_digits=8'h28;
  6'd28:lesson_digits=8'h29;
  6'd29:lesson_digits=8'h30;
  6'd30:lesson_digits=8'h31;
  6'd31:lesson_digits=8'h32;
  6'd32:lesson_digits=8'h33;
  6'd33:lesson_digits=8'h34;
  6'd34:lesson_digits=8'h35;
  6'd35:lesson_digits=8'h36;
  6'd36:lesson_digits=8'h37;
  6'd37:lesson_digits=8'h38;
  6'd38:lesson_digits=8'h39;
  6'd39:lesson_digits=8'h40;
  6'd40:lesson_digits=8'h41;
  6'd41:lesson_digits=8'h42;
  6'd42:lesson_digits=8'h43;
  6'd43:lesson_digits=8'h44;
  6'd44:lesson_digits=8'h45;
  6'd45:lesson_digits=8'h46;
  6'd46:lesson_digits=8'h47;
  6'd47:lesson_digits=8'h48;
  6'd48:lesson_digits=8'h49;
  6'd49:lesson_digits=8'h50;
  6'd50:lesson_digits=8'h51;
  6'd51:lesson_digits=8'h52;
  6'd52:lesson_digits=8'h53;
  6'd53:lesson_digits=8'h54;
  6'd54:lesson_digits=8'h55;
  6'd55:lesson_digits=8'h56;
  6'd56:lesson_digits=8'h57;
  6'd57:lesson_digits=8'h58;
  6'd58:lesson_digits=8'h59;
  6'd59:lesson_digits=8'h60;
  6'd60:lesson_digits=8'h61;
  6'd61:lesson_digits=8'h62;
  6'd62:lesson_digits=8'h63;
  6'd63:lesson_digits=8'h64;
  default:lesson_digits=0;endcase end endfunction
 wire[14:0]key_label_pre=u_keyboard_labels1[keyhit1[4:0]*15+:15];
 wire[7:0]keyvalue_pre=KEYBOARD_VIEW?{1'b0,key_label_pre[14:8]}:{1'b0,u_base_note1}+keyhit1[4:0];
 wire key_note_sharp_pre=KEYBOARD_VIEW?key_label_pre[0]:keysharp_pre;
 integer kj;
 always @(posedge pixel_clk)begin
  keyhit1<=key_hit(px0,py0);keyhit2<=keyhit1;
  keyvalue2<=keyvalue_pre;
  keysharp2<=keysharp_pre;
  key_text_x2<=keysharp_pre?black_left_pre+10'd4:white_left_pre+10'd16;
  key_text_y2<=keysharp_pre?10'd392:10'd500;
  key_label_on2<=keysharp_pre?
    (black_pos_pre>=4&&black_pos_pre<36&&py1>=392&&py1<424):
    (white_pos_pre>=16&&white_pos_pre<48&&py1>=500&&py1<532);
  key_border2<=keysharp_pre?
    (black_pos_pre<2||black_pos_pre>=38||py1<272||py1>=448):
    (white_pos_pre<2||white_pos_pre>=62||py1<272||py1>=568);
  key_accent2<=keysharp_pre?
    (black_pos_pre>=2&&black_pos_pre<38&&py1>=272&&py1<448&&
     (black_pos_pre<4||black_pos_pre>=36||py1<274||py1>=442)):
    (white_pos_pre>=2&&white_pos_pre<62&&py1>=272&&py1<568&&
     (white_pos_pre<4||white_pos_pre>=60||py1<274||py1>=562));
  key_gloss2<=keysharp_pre&&black_pos_pre>=2&&black_pos_pre<38&&py1>=272&&py1<276;
  key_accidental2<=key_note_sharp_pre&&(keysharp_pre?
    (black_pos_pre>=(KEYBOARD_VIEW?3:11)&&black_pos_pre<(KEYBOARD_VIEW?15:27)&&py1>=376&&py1<388&&
     (black_pos_pre==(KEYBOARD_VIEW?6:15)||black_pos_pre==(KEYBOARD_VIEW?12:23)||py1==379||py1==384)):
    (white_pos_pre>=(KEYBOARD_VIEW?8:22)&&white_pos_pre<(KEYBOARD_VIEW?24:38)&&py1>=484&&py1<496&&
     (white_pos_pre==(KEYBOARD_VIEW?12:26)||white_pos_pre==(KEYBOARD_VIEW?20:34)||py1==487||py1==492)));
  for(kd=1;kd<=5;kd=kd+1)begin
   key_dot_up2[kd-1]<=keysharp_pre?
     (black_pos_pre>=18&&black_pos_pre<22&&py1>=392-kd*7-1&&py1<392-kd*7+3):
     (white_pos_pre>=30&&white_pos_pre<34&&py1>=500-kd*7-1&&py1<500-kd*7+3);
   key_dot_down2[kd-1]<=keysharp_pre?
     (black_pos_pre>=18&&black_pos_pre<22&&py1>=392+32+kd*7-5&&py1<392+32+kd*7-1):
     (white_pos_pre>=30&&white_pos_pre<34&&py1>=500+32+kd*7-5&&py1<500+32+kd*7-1);
  end
  keyselected2<=0;
  for(kj=0;kj<7;kj=kj+1)if(u_pattern_selected1[kj]&&u_pattern_notes1[kj*7+:7]==keyvalue_pre)keyselected2<=1;
  keyheld2<=0;
  if(KEYBOARD_VIEW)keyheld2<=u_keyboard_held1[keyhit1[4:0]];
  else for(kj=0;kj<4;kj=kj+1)if(u_gates1[kj]&&u_notes1[kj*7+:7]==keyvalue_pre)keyheld2<=1;
  keydegree2<=KEYBOARD_VIEW?{1'b0,key_label_pre[3:1]}:degree(keyvalue_pre[6:0]);
  keyoct2<=KEYBOARD_VIEW?$signed(key_label_pre[7:4]):octave_dots(keyvalue_pre[6:0]);
  lesson_digits2<=lesson_digits(u_lesson_position1);
 end
 // Coordinate-independent products finish before geometry selection.
 reg [9:0] home_thumb2=0;
 reg [7:0] barheight2[0:6];
 reg [3:0] tabhit1=0,tabhit2=0;
 reg [9:0] taborigin2=0;
 integer bi;
 always @(posedge pixel_clk)begin
  home_thumb2<=p8_home_thumb(u_knob1);
  for(bi=0;bi<7;bi=bi+1)barheight2[bi]<=u_home_gates1[bi]?((u_gains1[bi*12+:12]*20'd240)>>12):0;
  tabhit1<=p8_tab_hit(px0,py0);tabhit2<=tabhit1;
  case(tabhit1)
   1:taborigin2<=8;2:taborigin2<=152;3:taborigin2<=296;4:taborigin2<=440;
   5:taborigin2<=584;6:taborigin2<=728;default:taborigin2<=0;
  endcase
 end
 // Actual timing supplies x0..1023/y0..599, including all blanking.
 // x is zero outside DEN; y remains valid on visible-row horizontal blanking.
 // Register top-level region predicates before the colour priority chain.
 reg header_y2=0,tab_y2=0,touch_text2=0,touch_action2=0;
 reg header_text2=0;
 wire touch_status_y_pre=pg1==5?(py1>=238&&py1<254):(py1>=550&&py1<566);
 always @(posedge pixel_clk)begin
  header_text2<=py1>=16&&py1<48&&((px1>=24&&px1<88)||(px1>=148&&px1<212)||
   (md1==2?(px1>=276&&px1<372):(px1>=292&&px1<356))||(px1>=448&&px1<512)||(px1>=592&&px1<656));
  header_y2<=py1<10'd64;
  tab_y2<=py1>=10'd72&&py1<10'd120;
  touch_text2<=touch_status_y_pre&&px1>=32&&px1<112;
  touch_action2<=touch_status_y_pre&&px1>=128&&px1<160;

 end
 // Final fixed overlays share the existing px1/py1 -> px/py cut.
 reg [1:0] record_box2=0,record_edge2=0,record_text2=0,record_icon2=0;
 wire [9:0] record_top_pre=pg1==5?10'd176:10'd132;
 wire [9:0] record_text_top_pre=pg1==5?10'd184:10'd138;
 genvar rb;
 generate for(rb=0;rb<2;rb=rb+1)begin:record_shape
  localparam integer LEFT=32+184*rb,RIGHT=200+184*rb,TEXT_LEFT=80+184*rb;
  always @(posedge pixel_clk)begin
   record_box2[rb]<=pg1!=0&&px1>=LEFT&&px1<RIGHT&&py1>=record_top_pre&&py1<record_top_pre+(pg1==5?48:44);
   record_edge2[rb]<=px1>=LEFT&&px1<RIGHT&&py1>=record_top_pre&&py1<record_top_pre+(pg1==5?48:44)&&
    !(px1>=LEFT+2&&px1<RIGHT-2&&py1>=record_top_pre+2&&py1<record_top_pre+(pg1==5?46:42));
   record_text2[rb]<=px1>=TEXT_LEFT&&px1<TEXT_LEFT+64&&py1>=record_text_top_pre&&py1<record_text_top_pre+32;
   record_icon2[rb]<=px1>=LEFT+20&&px1<LEFT+30&&py1>=record_text_top_pre+10&&py1<record_text_top_pre+20;
  end
 end endgenerate
 reg [4:0] dropdown_box2=0,dropdown_edge2=0,dropdown_text2=0,dropdown_selected2=0;
 reg [2:0] dropdown_index2=0;
 reg [9:0] dropdown_text_y2=0;
 genvar dr;
 generate for(dr=0;dr<5;dr=dr+1)begin:dropdown_shape
  localparam integer TOP=72+44*(dr-HIDE_EP),BOTTOM=116+44*(dr-HIDE_EP);
  always @(posedge pixel_clk)begin
   dropdown_box2[dr]<=(!HIDE_EP||dr!=0)&&px1>=712&&px1<1000&&py1>=TOP&&py1<BOTTOM;
   dropdown_edge2[dr]<=(!HIDE_EP||dr!=0)&&px1>=712&&px1<1000&&py1>=TOP&&py1<BOTTOM&&
    !(px1>=714&&px1<998&&py1>=TOP+2&&py1<BOTTOM-2);
   dropdown_text2[dr]<=(!HIDE_EP||dr!=0)&&px1>=728&&px1<984&&py1>=TOP+6&&py1<TOP+38;
   dropdown_selected2[dr]<=u_timbre1==dr;
  end
 end endgenerate
 always @(posedge pixel_clk)begin
  dropdown_index2<=HIDE_EP?1:0;dropdown_text_y2<=78;
  if(py1>=72&&py1<116)begin dropdown_index2<=HIDE_EP?1:0;dropdown_text_y2<=78;end
  else if(py1>=116&&py1<160)begin dropdown_index2<=HIDE_EP?2:1;dropdown_text_y2<=122;end
  else if(py1>=160&&py1<204)begin dropdown_index2<=HIDE_EP?3:2;dropdown_text_y2<=166;end
  else if(py1>=204&&py1<248)begin dropdown_index2<=HIDE_EP?4:3;dropdown_text_y2<=210;end
  else if(py1>=248&&py1<292)begin dropdown_index2<=4;dropdown_text_y2<=254;end
 end
 wire dropdown_selected_row2=|(dropdown_box2&dropdown_selected2);
 reg [7:0] final_box2=0,final_edge2=0;
 always @(posedge pixel_clk)begin
  final_box2[0]<=px1>=880&&px1<1008&&py1>=72&&py1<120;
  final_box2[1]<=px1>=704&&px1<1008&&py1>=8&&py1<56;
  final_edge2[1]<=px1>=704&&px1<1008&&py1>=8&&py1<56&&!(px1>=706&&px1<1006&&py1>=10&&py1<54);
  final_box2[2]<=(px1>=986&&px1<996&&py1>=26&&py1<28)||(px1>=988&&px1<994&&py1>=28&&py1<30)||(px1>=990&&px1<992&&py1>=30&&py1<32);
  final_box2[3]<=px1>=848&&px1<1008&&py1>=132&&py1<176;
  final_edge2[3]<=px1>=848&&px1<1008&&py1>=132&&py1<176&&!(px1>=850&&px1<1006&&py1>=134&&py1<174);
  final_box2[4]<=px1>=856&&px1<1008&&py1>=192&&py1<280;
  final_edge2[4]<=px1>=856&&px1<1008&&py1>=192&&py1<280&&!(px1>=858&&px1<1006&&py1>=194&&py1<278);
  final_box2[5]<=px1>=864&&px1<1008&&py1>=288&&py1<320;
  final_box2[6]<=py1>=128;
  final_box2[7]<=px1>=704&&px1<1008&&py1>=64&&py1<432;
  final_edge2[7]<=px1>=704&&px1<1008&&py1>=64&&py1<432&&!(px1>=706&&px1<1006&&py1>=66&&py1<430);
 end
 // Constant tile predicates use the existing px1/py1 -> px/py geometry cut.
 // No added stage: ROM, colour, font and eight-cycle sync stay aligned.
 reg [19:0] matrix_box2=0,matrix_edge2=0,matrix_selected2=0;
 genvar mt;
 generate for(mt=0;mt<20;mt=mt+1)begin:matrix_shape
  localparam integer LEFT=136+216*(mt%4),RIGHT=328+216*(mt%4);
  localparam integer TOP=218+72*(mt/4),BOTTOM=282+72*(mt/4);
  always @(posedge pixel_clk)begin
   matrix_box2[mt]<=px1>=LEFT&&px1<RIGHT&&py1>=TOP&&py1<BOTTOM;
   matrix_edge2[mt]<=px1>=LEFT&&px1<RIGHT&&py1>=TOP&&py1<BOTTOM&&
    !(px1>=LEFT+2&&px1<RIGHT-2&&py1>=TOP+2&&py1<BOTTOM-2);
   matrix_selected2[mt]<=!u_xy_settings1[5]&&u_xy_settings1[4:2]==mt/4&&u_xy_settings1[1:0]==mt%4;
  end
 end endgenerate
 // Decode the four fixed button silhouettes in the existing geometry cut.
 // Keep integer hit/origin arithmetic out of the late pixel colour path.
 reg [3:0] pattern_box2=0,pattern_edge2=0,pattern_text2=0;
 reg [9:0] pattern_tx2=0;
 reg [6:0] pattern_label2=0;
 genvar pb;
 generate for(pb=0;pb<4;pb=pb+1)begin:pattern_shape
  localparam integer LEFT=416+pb*144,RIGHT=pb==3?996:548+pb*144;
  localparam integer TEXT_LEFT=pb==3?890:450+pb*144;
  always @(posedge pixel_clk)begin
   pattern_box2[pb]<=px1>=LEFT&&px1<RIGHT&&py1>=176&&py1<224;
   pattern_edge2[pb]<=px1>=LEFT&&px1<RIGHT&&py1>=176&&py1<224&&
    !(px1>=LEFT+2&&px1<RIGHT-2&&py1>=178&&py1<222);
   pattern_text2[pb]<=px1>=TEXT_LEFT&&px1<TEXT_LEFT+64&&py1>=184&&py1<216;
  end
 end endgenerate
 always @(posedge pixel_clk)begin
  pattern_tx2<=0;pattern_label2<=0;
  if(px1>=416&&px1<548)begin pattern_tx2<=450;pattern_label2<=P8_PATTERN_STRUM_LABEL;end
  else if(px1>=560&&px1<692)begin pattern_tx2<=594;pattern_label2<=P8_PATTERN_CHORD_LABEL;end
  else if(px1>=704&&px1<836)begin pattern_tx2<=738;pattern_label2<=P8_PATTERN_ARP_LABEL;end
  else if(px1>=848&&px1<996)begin pattern_tx2<=890;pattern_label2<=P8_PATTERN_TRIGGER_LABEL;end
 end
 wire pattern_selected_button2=(pattern_box2[0]&&u_pattern_mode2==1)||
  (pattern_box2[1]&&u_pattern_mode2==2)||(pattern_box2[2]&&u_pattern_mode2==3);
 // BASE_OVERLAY_PIPELINE9: mature renderer finishes before Final overlays.
 reg [23:0] b_color,b_ink,b_key_state;
 reg [6:0] b_label;reg b_text_on,b_scale2,b_scale_half,b_held,b_sharp,b_key_active;
 integer b_tx,b_ty,b_dx,b_dy,b_i,b_bx,b_bw,b_hit,b_keyn,b_oct,b_dot,b_barh,b_thumb,b_fx,b_guide_note;
 reg [3:0] b_ci;reg [4:0] b_row,b_col;
 reg [23:0] base_color3=0,base_ink3=0;
 reg [6:0] base_label3=0;
 reg base_text_on3=0,base_scale3=0,base_half3=0;
 reg [13:0] base_tx3=0,base_ty3=0;
 reg [9:0] px_o=0;
 reg [9:0] py_o=0;
 reg [2:0] pg_o=0;
 reg u_piano_ready2_o=0;
 reg u_touch_ready2_o=0;
 reg [2:0] u_timbre2_o=0;
 reg u_recording2_o=0;
 reg u_replaying2_o=0;
 reg u_full2_o=0;
 reg u_overview2_o=0;
 reg u_dropdown2_o=0;
 reg [19:0] record_digits2_o=0;
 reg [7:0] seconds_digits2_o=0;
 reg [5:0] u_xy_settings2_o=0;
 reg [7:0] final_box2_o=0;
 reg [7:0] final_edge2_o=0;
 reg [1:0] record_box2_o=0;
 reg [1:0] record_edge2_o=0;
 reg [1:0] record_text2_o=0;
 reg [1:0] record_icon2_o=0;
 reg [19:0] matrix_box2_o=0;
 reg [19:0] matrix_edge2_o=0;
 reg [19:0] matrix_selected2_o=0;
 reg [4:0] dropdown_box2_o=0;
 reg [4:0] dropdown_edge2_o=0;
 reg [4:0] dropdown_text2_o=0;
 reg dropdown_selected_row2_o=0;
 reg [2:0] dropdown_index2_o=0;
 reg [9:0] dropdown_text_y2_o=0;
 function automatic overlay_box(input integer ax,ay,bx,by);
 begin overlay_box=px_o>=ax&&px_o<bx&&py_o>=ay&&py_o<by;end endfunction
 always @*begin
  b_color=graph_color;b_ink=TEXT;b_label=0;b_text_on=0;b_scale2=0;b_scale_half=0;b_tx=0;b_ty=0;
  b_dx=0;b_dy=0;b_ci=0;b_row=0;b_col=0;b_bx=0;b_bw=0;b_hit=-1;b_keyn=0;b_oct=0;b_dot=0;
  b_barh=0;b_thumb=home_thumb2;b_held=0;b_sharp=0;b_fx=0;b_guide_note=0;b_key_active=0;b_key_state=YELLOW;
  if(header_y2)begin
   b_color=24'h202830;b_hit=header_hit2;
   case(b_hit)1:begin b_bx=8;b_bw=96;b_label=0;end 2:begin b_bx=116;b_bw=128;b_label=1;end
    3:begin b_bx=260;b_bw=128;b_label=md==2?(u_playing2?P8_PLAYING_LABEL:P8_STOPPED_LABEL):2;end
    4:begin b_bx=416;b_bw=128;b_label=u_muted2?P8_UNMUTE_LABEL:P8_MUTE_LABEL;end
    7:begin b_bx=560;b_bw=128;b_label=5;end default:begin b_bx=0;b_bw=0;end endcase
   if(b_hit>0)begin
    b_color=24'h11171d;
    if((b_hit==2&&(md==1||md==3))||(b_hit==3&&md==2))b_color=24'h244438;
    if(b_hit==4&&u_muted2)b_color=24'h3b222c;
    if(header_edge2)b_color=(b_hit==2&&(md==1||md==3))||(b_hit==3&&md==2)?GREEN:EDGE;
    b_tx=b_bx+(b_bw-((b_hit==3&&md==2)?96:64))/2;b_ty=16;b_text_on=header_text2;
   end
  end else if(pg!=0&&tab_y2)begin
   b_hit=tabhit2;
   if(b_hit>0)begin
    b_bx=taborigin2;b_color=pg==b_hit?24'h294550:24'h1d2932;
    if(tab_edge2)b_color=pg==b_hit?CYAN:EDGE;
    b_label=5+b_hit;b_tx=b_bx+(136-(b_hit==5?128:b_hit==3?96:64))/2;b_ty=80;
    b_text_on=in_box(b_tx,b_ty,b_bx+136,112);
   end
  end else if(pg==0)begin
   for(b_i=0;b_i<3;b_i=b_i+1)begin
    b_bx=244+b_i*184;
    if(in_box(b_bx,144,b_bx+168,344))begin
     b_color=b_i==0?24'h0c1915:24'h0b171f;
     if(edgebox(b_bx,144,b_bx+168,344))b_color=b_i==0?GREEN:CYAN;
     b_tx=b_bx+20;b_ty=212;b_label=b_i==2?P8_FOLLOW_LABEL:b_i+1;b_scale2=1;b_text_on=in_box(b_tx,b_ty,b_tx+128,b_ty+64);
    end
   end
   for(b_i=0;b_i<7;b_i=b_i+1)begin
    b_bx=b_i<4?32+40*b_i:824+52*(b_i-4);b_bw=b_i<4?24:28;
    b_barh=barheight2[b_i];
    if(in_box(b_bx,230,b_bx+b_bw,470))begin
     b_color=24'h1c2a34;
     if(py>=470-b_barh&&b_barh!=0)b_color=b_i<4?CYAN:GREEN;
     if(edgebox(b_bx,230,b_bx+b_bw,470))b_color=24'h405360;
    end
   end
   if(in_box(76,184,140,216)||in_box(844,184,908,216))begin
    b_tx=px<512?76:844;b_ty=184;b_label=22;b_text_on=1;b_ink=24'ha2b5bf;
   end
   if(in_box(244,352,308,384))begin b_tx=244;b_ty=352;b_label=P8_BEND_LABEL;b_text_on=1;end
   if(in_box(684,352,780,384))begin
    b_tx=684;b_ty=352;b_label=digit_label(u_eff_hund2);b_text_on=1;
    if(px>=716)begin b_tx=716;b_label=digit_label(u_eff_tens2);end
    if(px>=748)begin b_tx=748;b_label=digit_label(u_eff_ones2);end
   end
   if(in_box(244,392,780,472))begin
    b_thumb=home_thumb2;b_color=24'h162630;
    if(edgebox(244,392,780,472))b_color=EDGE;
    if(in_box(252,425,772,439))b_color=24'h335963;
    if(in_box(252,425,b_thumb,439))b_color=CYAN;
    if(in_box(b_thumb-6,402,b_thumb+7,462))b_color=YELLOW;
    if(px==512&&py>=400&&py<464)b_color=GREEN;
   end
   if(in_box(480,480,544,512))begin b_tx=480;b_ty=480;b_label=3;b_text_on=1;b_ink=24'ha2b5bf;end
  end else if(pg==5)begin
   if(md==1)begin
    if(|pattern_box2)begin
     b_color=24'h192933;
     if(pattern_selected_button2)b_color=24'h294550;
     if(pattern_box2[3]&&u_pattern_busy2)b_color=24'h244438;
     if(|pattern_edge2)b_color=pattern_box2[3]&&u_pattern_busy2?GREEN:pattern_selected_button2?CYAN:EDGE;
     b_tx=pattern_tx2;b_ty=184;b_label=pattern_label2;b_text_on=|pattern_text2;
    end
    if(u_pattern_mode2!=0&&in_box(LARGE_STATUS?416:216,238,LARGE_STATUS?584:300,LARGE_STATUS?270:254))begin
     b_tx=LARGE_STATUS?416:216;b_ty=238;b_scale_half=!LARGE_STATUS;b_ink=u_pattern_full2?YELLOW:CYAN;
     b_label=u_pattern_full2?P8_PATTERN_FULL_LABEL:P8_PATTERN_COUNT_LABEL;
     b_text_on=in_box(LARGE_STATUS?416:216,238,LARGE_STATUS?480:248,LARGE_STATUS?270:254);
     if(!u_pattern_full2&&in_box(LARGE_STATUS?488:252,238,LARGE_STATUS?520:268,LARGE_STATUS?270:254))begin b_tx=LARGE_STATUS?488:252;b_label=digit_label({1'b0,u_pattern_count2});b_text_on=1;end
     if(!u_pattern_full2&&in_box(LARGE_STATUS?520:268,238,LARGE_STATUS?584:300,LARGE_STATUS?270:254))begin b_tx=LARGE_STATUS?520:268;b_label=P8_PATTERN_CAPACITY_LABEL;b_text_on=1;end
    end
   end
   if(md==3&&in_box(416,176,600,224))begin
    b_color=24'h244438;if(edgebox(416,176,600,224))b_color=GREEN;
    b_tx=444;b_ty=184;b_label=P8_RESTART_LABEL;b_text_on=in_box(b_tx,b_ty,b_tx+128,b_ty+32);
   end
   if(md==3&&in_box(644,184,996,216))begin
    b_ty=184;b_tx=644;b_label=u_lesson_done2?P8_DONE_LABEL:P8_INDEX_LABEL;
    b_text_on=in_box(b_tx,b_ty,b_tx+(u_lesson_done2?64:32),b_ty+32);
    if(!u_lesson_done2&&px>=692&&px<756)begin
     b_tx=px<724?692:724;b_label=digit_label(px<724?lesson_digits2[7:4]:lesson_digits2[3:0]);b_text_on=1;
    end
    if(!u_lesson_done2&&in_box(772,184,804,216))begin b_tx=772;b_label=P8_NOTE_LABEL;b_text_on=1;end
   end
   b_hit=keyhit2;
   if(b_hit>=0)begin
    b_keyn=keyvalue2;
    b_sharp=keysharp2;
    b_held=keyheld2;
    // Full-key state fill; fixed outer silhouettes preserve the25-key layout.
    b_key_active=0;b_key_state=YELLOW;
    if(md==1&&u_pattern_mode2!=0&&keyselected2)begin b_key_active=1;b_key_state=YELLOW;end
    if(b_held)begin b_key_active=1;b_key_state=YELLOW;end
    if(md==3&&!u_lesson_done2&&b_keyn==u_lesson_target2)begin b_key_active=1;b_key_state=YELLOW;end
    if(md==3&&u_lesson_feedback2!=0&&b_keyn==u_lesson_feedback_note2)begin
     b_key_active=1;b_key_state=u_lesson_feedback2==1?GREEN:24'he56c79;
    end
    b_color=b_sharp?24'h101010:24'hffffff;
    if(key_gloss2)b_color=24'h354652;
    if(b_key_active)b_color=b_key_state;
    if(key_border2)b_color=b_sharp?24'h0a1118:24'h36434e;
    // Origins and silhouettes were decoded in parallel before this cut.
    b_tx=key_text_x2;b_ty=key_text_y2;b_label=digit_label(keydegree2);
    b_text_on=key_label_on2;b_ink=b_sharp&&!b_key_active?TEXT:24'h17202a;
    if(key_accidental2)b_color=b_ink;
    b_oct=keyoct2; // MIDI60=C4 is the undotted reference.
    if((key_dot_up2[0]&&b_oct>=1)||(key_dot_down2[0]&&b_oct<=-1)||
       (key_dot_up2[1]&&b_oct>=2)||(key_dot_down2[1]&&b_oct<=-2)||
       (key_dot_up2[2]&&b_oct>=3)||(key_dot_down2[2]&&b_oct<=-3)||
       (key_dot_up2[3]&&b_oct>=4)||(key_dot_down2[3]&&b_oct<=-4)||
       (key_dot_up2[4]&&b_oct>=5)||(key_dot_down2[4]&&b_oct<=-5))b_color=b_ink;
   end
  end
  if(pg!=0&&pg!=3&&pg!=5&&md==2&&py>=128&&py<184)begin
   if(in_box(384,128,544,184))begin
    b_color=24'h244438;if(edgebox(384,128,544,184))b_color=GREEN;
    b_tx=432;b_ty=140;b_label=P8_REPLAY_LABEL;b_text_on=in_box(b_tx,b_ty,b_tx+64,b_ty+32);
   end
   if(in_box(560,128,688,184))begin
    b_color=24'h34282c;if(edgebox(560,128,688,184))b_color=EDGE;
    b_tx=592;b_ty=140;b_label=5;b_text_on=in_box(b_tx,b_ty,b_tx+64,b_ty+32);
   end
  end
  if(pg==2)begin
   for(b_i=0;b_i<3;b_i=b_i+1)begin
    b_bx=720+b_i*92;
    if(in_box(b_bx,132,b_bx+88,176))begin
     b_color=u_spectrum_zoom2==b_i?24'h294550:24'h1d2932;if(edgebox(b_bx,132,b_bx+88,176))b_color=EDGE;
     b_tx=b_bx+12;b_ty=140;b_label=24+b_i;b_text_on=in_box(b_tx,b_ty,b_tx+64,b_ty+32);
    end
   end
   for(b_i=0;b_i<5;b_i=b_i+1)begin
    b_bx=b_i==4?890:128+b_i*192;
    if(in_box(b_bx,496,b_bx+1,505))b_color=EDGE;
    b_fx=b_bx-p8_freq_len(u_spectrum_zoom2,b_i)*16;
    if(in_box(b_fx,510,b_fx+p8_freq_len(u_spectrum_zoom2,b_i)*32,542))begin
     b_tx=b_fx;b_ty=510;b_label=p8_freq_label(u_spectrum_zoom2,b_i);b_text_on=1;b_ink=24'ha2b5bf;
    end
   end
   if(in_box(920,550,984,582))begin b_tx=920;b_ty=550;b_label=P8_HZ_LABEL;b_text_on=1;b_ink=24'ha2b5bf;end
  end
  if(pg==1)begin
   for(b_i=0;b_i<4;b_i=b_i+1)begin
    if(in_box(56,464-b_i*84,120,496-b_i*84))begin
     b_tx=56;b_ty=464-b_i*84;b_label=b_i==0?62:43+b_i;b_text_on=1;b_ink=24'ha2b5bf;
    end
   end
  end

 end
 always @(posedge pixel_clk)begin
  if(!rstn)begin
   base_color3<=0;base_ink3<=0;base_label3<=0;base_text_on3<=0;base_scale3<=0;base_half3<=0;base_tx3<=0;base_ty3<=0;
  end else begin
   base_color3<=b_color;base_ink3<=b_ink;base_label3<=b_label;base_text_on3<=b_text_on;
   base_scale3<=b_scale2;base_half3<=b_scale_half;base_tx3<=b_tx;base_ty3<=b_ty;
  end
  px_o<=px;
  py_o<=py;
  pg_o<=pg;
  u_piano_ready2_o<=u_piano_ready2;
  u_touch_ready2_o<=u_touch_ready2;
  u_timbre2_o<=u_timbre2;
  u_recording2_o<=u_recording2;
  u_replaying2_o<=u_replaying2;
  u_full2_o<=u_full2;
  u_overview2_o<=u_overview2;
  u_dropdown2_o<=u_dropdown2;u_fx_o<=u_fx2;
  record_digits2_o<=record_digits2;
  seconds_digits2_o<=seconds_digits2;
  u_xy_settings2_o<=u_xy_settings2;
  final_box2_o<=final_box2;
  final_edge2_o<=final_edge2;
  record_box2_o<=record_box2;
  record_edge2_o<=record_edge2;
  record_text2_o<=record_text2;
  record_icon2_o<=record_icon2;
  matrix_box2_o<=matrix_box2;
  matrix_edge2_o<=matrix_edge2;
  matrix_selected2_o<=matrix_selected2;
  dropdown_box2_o<=dropdown_box2;
  dropdown_edge2_o<=dropdown_edge2;
  dropdown_text2_o<=dropdown_text2;
  dropdown_selected_row2_o<=dropdown_selected_row2;
  dropdown_index2_o<=dropdown_index2;
  dropdown_text_y2_o<=dropdown_text_y2;
 end
 always @*begin
  color=base_color3;ink=base_ink3;label=base_label3;text_on=base_text_on3;
  scale2=base_scale3;scale_half=base_half3;tx=base_tx3;ty=base_ty3;
  dx=0;dy=0;ci=0;row=0;col=0;bx=0;bw=0;hit=-1;keyn=0;oct=0;dot=0;
  barh=0;thumb=0;held=0;sharp=0;fx=0;guide_note=0;key_active=0;key_state=YELLOW;
  // Final-only product controls; Home pixel geometry and priority are untouched.
  if(pg_o!=0)begin
   // Independent configured badges, intentionally unrelated to a held contact.
   if(final_box2_o[0])begin
    color=24'h162630;scale_half=1;ty=py_o<96?76:100;tx=888;
    label=py_o<96?(u_piano_ready2_o?FINAL_PIANO_READY_LABEL:FINAL_PIANO_WAIT_LABEL):
       (u_touch_ready2_o?FINAL_TOUCH_READY_LABEL:FINAL_TOUCH_WAIT_LABEL);
    ink=(py_o<96?u_piano_ready2_o:u_touch_ready2_o)?GREEN:24'h9aabb5;
    text_on=overlay_box(tx,ty,tx+112,ty+16);
   end
   if(final_box2_o[1])begin
    color=24'h192933;if(final_edge2_o[1])color=CYAN;
    tx=720;ty=16;label=HIDE_EP&&u_timbre2_o==4?FINAL_CUSTOM_PIANO_LABEL:FINAL_PIANO_LABEL+u_timbre2_o;
    text_on=(u_timbre2_o<4||(HIDE_EP&&u_timbre2_o==4))&&overlay_box(tx,ty,992,48);
    if(final_box2_o[2])color=CYAN;
   end
   // Record and Replay retain the removed octave positions on the keyboard.
   if((|record_box2_o)&&!(pg_o==3&&u_overview2_o))begin
    hit=record_box2_o[0]?1:2;bx=record_box2_o[0]?32:216;ty=pg_o==5?184:138;tx=bx+48;
    color=record_box2_o[0]?(u_recording2_o?24'h502b35:24'h29232e):(u_replaying2_o?24'h285448:24'h192933);
    if(|record_edge2_o)color=record_box2_o[0]?(u_recording2_o?24'he56c79:EDGE):(u_replaying2_o?GREEN:EDGE);
    label=record_box2_o[0]?FINAL_RECORD_LABEL:FINAL_REPLAY_TAKE_LABEL;text_on=|record_text2_o;
    if(|record_icon2_o)color=record_box2_o[0]?24'he56c79:CYAN;
   end
   if(!(pg_o==3&&u_overview2_o)&&overlay_box(32,pg_o==5?238:186,LARGE_STATUS?292:200,pg_o==5?(LARGE_STATUS?270:254):(LARGE_STATUS?218:202)))begin
    ty=pg_o==5?238:186;tx=32;scale_half=!LARGE_STATUS;ink=u_full2_o?YELLOW:GREEN;
    label=u_full2_o?FINAL_FULL_LABEL:u_recording2_o?FINAL_RECORDING_LABEL:u_replaying2_o?FINAL_REPLAYING_LABEL:FINAL_EVT_LABEL;
    text_on=overlay_box(tx,ty,tx+(u_recording2_o||u_replaying2_o?(LARGE_STATUS?96:48):(LARGE_STATUS?64:32)),ty+(LARGE_STATUS?32:16));
    if(px_o>=(LARGE_STATUS?132:92)&&px_o<(LARGE_STATUS?292:172))begin
     tx=(LARGE_STATUS?132:92)+((px_o-(LARGE_STATUS?132:92))/(LARGE_STATUS?32:16))*(LARGE_STATUS?32:16);label=digit_label(record_digits2_o[((4-(px_o-(LARGE_STATUS?132:92))/(LARGE_STATUS?32:16))*4)+:4]);text_on=1;
    end
   end
   if(!(pg_o==3&&u_overview2_o)&&overlay_box(310,pg_o==5?238:186,LARGE_STATUS?406:366,pg_o==5?(LARGE_STATUS?270:254):(LARGE_STATUS?218:202)))begin
    ty=pg_o==5?238:186;scale_half=!LARGE_STATUS;ink=24'ha2b5bf;
    tx=px_o<(LARGE_STATUS?342:326)?310:px_o<(LARGE_STATUS?374:342)?(LARGE_STATUS?342:326):(LARGE_STATUS?374:346);
    label=px_o<(LARGE_STATUS?342:326)?digit_label(seconds_digits2_o[7:4]):px_o<(LARGE_STATUS?374:342)?digit_label(seconds_digits2_o[3:0]):FINAL_TIME_LABEL;
    text_on=overlay_box(tx,ty,tx+(LARGE_STATUS?32:16),ty+(LARGE_STATUS?32:16));
   end
   if(pg_o==3)begin
    if(u_overview2_o)begin
     // Cover normal graph and old controls, then render full periodic previews.
     if(final_box2_o[6])begin color=BG;text_on=0;scale_half=0;scale2=0;end
     if(final_box2_o[3])begin
      color=24'h192933;if(final_edge2_o[3])color=CYAN;
      tx=896;ty=138;label=FINAL_EXIT_LABEL;text_on=overlay_box(tx,ty,tx+64,ty+32);
     end
     for(i=0;i<4;i=i+1)begin
      bx=136+216*i;
      if(overlay_box(bx+48,176,bx+144,208))begin tx=bx+48;ty=176;label=33+i;text_on=1;ink=CYAN;end
     end
     for(i=0;i<5;i=i+1)if(overlay_box(16,234+72*i,128,266+72*i))begin
      tx=16;ty=234+72*i;label=28+i;text_on=1;ink=24'ha2b5bf;
     end
     if(|matrix_box2_o)begin
      color=24'h0c151f;
      if(|matrix_edge2_o)color=|(matrix_edge2_o&matrix_selected2_o)?GREEN:EDGE;
      if(xy_preview_on3)color=YELLOW;
     end
    end else begin
     if(final_box2_o[3])begin
      color=u_xy_settings2_o[5]?24'h2a4d43:24'h192933;if(final_edge2_o[3])color=EDGE;
      tx=896;ty=138;label=27;text_on=overlay_box(tx,ty,tx+64,ty+32);
     end
     if(final_box2_o[4])begin
      color=24'h0c151f;if(final_edge2_o[4])color=CYAN;
      if(xy_preview_on3)color=YELLOW;
     end
     if(final_box2_o[5])begin tx=864;ty=288;label=FINAL_MATRIX_LABEL;text_on=1;end
    end
   end
   if(u_dropdown2_o&&final_box2_o[7])begin
    // Modal dropdown visually owns all its hit regions; long sax name has room.
    color=24'h101d27;ink=TEXT;text_on=0;scale_half=0;scale2=0;
    if(final_edge2_o[7])color=EDGE;
    if(|dropdown_box2_o)begin
     bx=712;ty=dropdown_text_y2_o;tx=728;
     color=dropdown_selected_row2_o?24'h254a43:24'h192933;
     if(|dropdown_edge2_o)color=dropdown_selected_row2_o?GREEN:24'h304653;
     label=HIDE_EP&&dropdown_index2_o==4?FINAL_CUSTOM_PIANO_LABEL:FINAL_PIANO_LABEL+dropdown_index2_o;text_on=|dropdown_text2_o;
    end
    if(overlay_box(712,292,1000,424))begin
     hit=py_o<336?0:py_o<380?1:2;
     ty=py_o<336?298:py_o<380?342:386;
     color=u_fx_o[hit*2+:2]!=0?24'h254a43:24'h192933;
     ink=u_fx_o[hit*2+:2]!=0?GREEN:TEXT;
     if(px_o<714||px_o>=998||py_o==292||py_o==335||py_o==336||py_o==379||py_o==380||py_o==423)color=EDGE;
     if(px_o<880)begin tx=728;label=FINAL_CHORUS_LABEL+hit;end
     else begin tx=928;label=FINAL_FX_OFF_LABEL+u_fx_o[hit*2+:2];end
     text_on=overlay_box(tx,ty,tx+(px_o<880?64:32),ty+32);
    end

   end
  end
  if(SHOW_PEDAL&&overlay_box(688,8,704,56))begin
   color=pedal_o?24'h244438:24'h202830;ink=pedal_o?YELLOW:24'h9aabb5;
   tx=688;ty=py_o<32?16:32;label=py_o<32?FINAL_PEDAL_LABEL:FINAL_PEDAL_SECOND_LABEL;scale_half=1;scale2=0;
   text_on=overlay_box(688,16,704,48);
  end
 end
 wire envelope_overlay_on;wire [23:0]envelope_overlay_rgb;
 envelope_ui #(.HIDE_EP(HIDE_EP)) envelope_renderer(.clk(pixel_clk),.rstn(rstn),.x(px_o),.y(py_o),.page(pg_o),
  .timbre(u_timbre2_o),.dropdown(u_dropdown2_o),.choices(envelope_choices),.preview_busy(preview_busy),
  .active(envelope_overlay_on),.rgb(envelope_overlay_rgb));
 // Geometry selection is separate from glyph-relative coordinates.
 reg [6:0] label0=0;reg text_on0=0,scale0=0,half0=0;
 reg [13:0] text_x0=0,text_y0=0,tx0=0,ty0=0;
 reg [23:0] bg0=0,ink0=0;
 wire [13:0] text_dx=text_x0-tx0,text_dy=text_y0-ty0;
 reg [6:0] label1;reg [3:0] ci1;reg [4:0] row1,col1,col2,col3;
 reg on1,on2,on3;reg [12:0] address2;reg [31:0] glyph3;
 reg [23:0] bg1,bg2,bg3,ink1,ink2,ink3;
 reg [7:0] dp=0,hp=0,vp=0;
 always @(posedge pixel_clk)begin
  if(!rstn)begin
   px0<=0;py0<=0;pg0<=0;md0<=0;px1<=0;py1<=0;pg1<=0;md1<=0;px<=0;py<=0;pg<=0;md<=0;dp<=0;hp<=0;vp<=0;rgb<=0;
   den_out<=0;hsync_out<=0;vsync_out<=0;on1<=0;on2<=0;on3<=0;
   label1<=0;ci1<=0;row1<=0;col1<=0;col2<=0;col3<=0;address2<=0;glyph3<=0;
   bg0<=0;ink0<=0;label0<=0;text_on0<=0;scale0<=0;half0<=0;text_x0<=0;text_y0<=0;tx0<=0;ty0<=0;
   bg1<=0;bg2<=0;bg3<=0;ink1<=0;ink2<=0;ink3<=0;
  end else begin
   px0<=x;py0<=y;pg0<=page;md0<=mode;
   px1<=px0;py1<=py0;pg1<=pg0;md1<=md0;px<=px1;py<=py1;pg<=pg1;md<=md1;
   label0<=label;text_on0<=text_on;scale0<=scale2;half0<=scale_half;text_x0<=px_o;text_y0<=py_o;tx0<=tx;ty0<=ty;bg0<=color;ink0<=ink;
   label1<=label0;ci1<=half0?text_dx[7:4]:scale0?text_dx[9:6]:text_dx[8:5];
   row1<=half0?{text_dy[3:0],1'b0}:scale0?text_dy[5:1]:text_dy[4:0];
   col1<=half0?{text_dx[3:0],1'b0}:scale0?text_dx[5:1]:text_dx[4:0];
   on1<=text_on0;bg1<=bg0;ink1<=ink0;
   address2<={p8_glyph(label1,ci1),row1};col2<=col1;on2<=on1;bg2<=bg1;ink2<=ink1;
   glyph3<=font[address2];col3<=col2;on3<=on2;bg3<=bg2;ink3<=ink2;
   dp<={dp[6:0],den};hp<={hp[6:0],hsync};vp<={vp[6:0],vsync};
   rgb<=dp[7]?(envelope_overlay_on?envelope_overlay_rgb:(on3&&glyph3[31-col3]?ink3:bg3)):0;
   den_out<=dp[7];hsync_out<=hp[7];vsync_out<=vp[7];
  end
 end
endmodule

