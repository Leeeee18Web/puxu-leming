`timescale 1ns/1ps
// Parameterized live source and unchanged four-voice, event-synthesized score.
// Replay is downstream of this selector and never re-enters the score engine.
module final_audio_source #(
 parameter integer SCORE_TOTAL_SAMPLES=1464844,
 parameter integer SCORE_EVENT_COUNT=262,
 parameter integer VOICE_COUNT=4
)(
 input wire clk,rst,sample_tick,
 input wire [1:0] mode,
 input wire start_score,stop_score,panic,transition_mute,muted,
 input wire [VOICE_COUNT-1:0] live_gates,live_triggers,
 input wire [VOICE_COUNT*7-1:0] live_notes,
 input wire [VOICE_COUNT*12-1:0] live_gains,
 input wire [VOICE_COUNT*3-1:0] live_timbres,
 input wire [2:0] timbre_select,
 output wire [VOICE_COUNT-1:0] gates,triggers,
 output wire [VOICE_COUNT*7-1:0] notes,
 output wire [VOICE_COUNT*12-1:0] gains,
 output wire [VOICE_COUNT*3-1:0] timbres,
 output wire playing,done,
 output wire [6:0] next_note
);
 wire [3:0] score_gates;
 wire [27:0] score_notes;
 wire [47:0] score_gains;
 song_sequencer #(.TOTAL_SAMPLES(SCORE_TOTAL_SAMPLES),.EVENT_COUNT(SCORE_EVENT_COUNT)) score(
  .clk(clk),.rst(rst),.sample_tick(sample_tick),.start(start_score&&!panic),
  .stop(stop_score||panic||mode!=2),.playing(playing),.done(done),
  .gates(score_gates),.notes(score_notes),.gains(score_gains),.next_melody_note(next_note));
 reg [3:0] previous_gates=0,score_triggers=0;
 reg [27:0] previous_notes=0;
 reg [11:0] score_timbres=0;
 integer i;
 always @(posedge clk)begin
  if(rst||stop_score||panic||mode!=2)begin
   previous_gates<=0;previous_notes<=0;score_triggers<=0;score_timbres<=0;
  end else begin
   previous_gates<=score_gates;previous_notes<=score_notes;
   for(i=0;i<4;i=i+1)begin
    score_triggers[i]<=score_gates[i]&&(!previous_gates[i]||score_notes[i*7+:7]!=previous_notes[i*7+:7]);
    if(score_gates[i]&&(!previous_gates[i]||score_notes[i*7+:7]!=previous_notes[i*7+:7]))
     score_timbres[i*3+:3]<=timbre_select;
   end
  end
 end
 wire silence=panic||transition_mute||muted;
 assign gates=silence?'0:mode==2?(VOICE_COUNT*1)'(score_gates):live_gates;
 assign triggers=silence?'0:mode==2?(VOICE_COUNT*1)'(score_triggers):live_triggers;
 assign notes=mode==2?(VOICE_COUNT*7)'(score_notes):live_notes;
 assign gains=silence?'0:mode==2?(VOICE_COUNT*12)'(score_gains):live_gains;
 assign timbres=mode==2?(VOICE_COUNT*3)'(score_timbres):live_timbres;
endmodule
