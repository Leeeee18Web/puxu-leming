`timescale 1ns/1ps
module final_pattern_pedal(
 input wire clk,rst,cancel,pedal_down,input wire[1:0]pattern_mode,
 input wire[3:0]in_gates,in_triggers,input wire[27:0]in_notes,
 input wire[47:0]in_gains,input wire[2:0]timbre_select,
 output reg[3:0]gates=0,triggers=0,output reg[27:0]notes=0,
 output reg[47:0]gains=0,output reg[11:0]timbres=0
);
 reg[1:0]previous_mode=0;integer i;
 always @(posedge clk)begin
  triggers<=0;previous_mode<=pattern_mode;
  if(rst||cancel||pattern_mode==0||pattern_mode!=previous_mode)begin
   gates<=0;triggers<=0;notes<=0;gains<=0;timbres<=0;
  end else for(i=0;i<4;i=i+1)begin
   if(in_triggers[i])begin
    gates[i]<=1;triggers[i]<=1;notes[i*7+:7]<=in_notes[i*7+:7];
    gains[i*12+:12]<=in_gains[i*12+:12];
    timbres[i*3+:3]<=timbre_select<=4?timbre_select:3'd0;
   end else if(!in_gates[i]&&!pedal_down)gates[i]<=0;
  end
 end
endmodule
