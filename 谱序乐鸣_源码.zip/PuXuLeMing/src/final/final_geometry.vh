// Shared half-open touch/display regions. Baseline key and Home shapes retained.
`include "p8_geometry.vh"
function automatic integer final_record_hit(input integer px,py,pg);
 integer top_y;begin
 top_y=pg==5?176:132;final_record_hit=0;
 if(pg!=0&&py>=top_y&&py<top_y+(pg==5?48:44))begin
  if(px>=32&&px<200)final_record_hit=1;
  else if(px>=216&&px<384)final_record_hit=2;
 end
 end
endfunction
function automatic integer final_matrix_hit(input integer px,py);
 integer c,r;begin final_matrix_hit=-1;
 for(r=0;r<5;r=r+1)for(c=0;c<4;c=c+1)
  if(px>=136+216*c&&px<328+216*c&&py>=218+72*r&&py<282+72*r)final_matrix_hit=r*4+c;
 end
endfunction
function automatic integer final_timbre_hit(input integer px,py);
 integer i;begin final_timbre_hit=-1;
 for(i=0;i<5;i=i+1)if(px>=712&&px<1000&&py>=72+44*i&&py<116+44*i)final_timbre_hit=i;
 end
endfunction

// Three independent effect rows, owned by the modal instrument menu.
function automatic integer final_fx_hit(input integer px,py);
 begin final_fx_hit=0;
  if(px>=712&&px<1000)begin
   if(py>=292&&py<336)final_fx_hit=1;
   else if(py>=336&&py<380)final_fx_hit=2;
   else if(py>=380&&py<424)final_fx_hit=3;
  end
 end
endfunction
