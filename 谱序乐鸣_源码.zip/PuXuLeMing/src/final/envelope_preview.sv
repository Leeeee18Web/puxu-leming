`timescale 1ns/1ps
// The phrase stores note events only. All sound comes from the live piano HDL.
module envelope_preview #(parameter NOTE_FRAMES=24414,TAIL_FRAMES=60000)(
 input wire clk,rst,sample_tick,toggle,stop,input wire[7:0]choices,
 output reg busy=0,output reg[3:0]gates=0,triggers=0,
 output wire[27:0]notes,output wire[47:0]gains,output wire[11:0]timbres,
 output reg[7:0]captured_choices=8'h95
);
 reg[2:0]segment=0;reg[15:0]frames_left=0;
 assign notes={7'd72,7'd67,7'd64,7'd60};
 assign gains=busy?{4{12'd2200}}:48'd0;
 assign timbres={4{3'd4}};
 always @(posedge clk)begin
  triggers<=0;
  if(rst||stop)begin busy<=0;gates<=0;segment<=0;frames_left<=0;end
  else if(toggle)begin
   if(busy)begin busy<=0;gates<=0;frames_left<=0;end
   else begin
    busy<=1;gates<=1;triggers<=1;segment<=0;frames_left<=NOTE_FRAMES;
    captured_choices<=choices;
   end
  end else if(sample_tick&&busy)begin
   if(frames_left>1)frames_left<=frames_left-1'b1;
   else begin
    segment<=segment+1'b1;frames_left<=NOTE_FRAMES;
    case(segment)
     0:begin gates<=2;triggers<=2;end
     1:begin gates<=4;triggers<=4;end
     2:begin gates<=8;triggers<=8;end
     3:begin gates<=15;triggers<=15;end
     4:begin end
     5:begin gates<=0;frames_left<=TAIL_FRAMES;end
     default:begin busy<=0;gates<=0;frames_left<=0;end
    endcase
   end
  end
 end
endmodule
