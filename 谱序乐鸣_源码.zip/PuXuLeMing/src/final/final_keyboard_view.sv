// App-domain observer. One complete25-key view is published together; the
// pixel path only indexes the resulting key metadata and held mask.
module final_keyboard_view #(parameter VOICE_COUNT=12)(
 input wire clk,rst,live_mode,map_enabled,input wire[6:0]base_note,map_input_base,
 input wire[174:0]map_notes,
 input wire[VOICE_COUNT-1:0]live_gates,gates,
 input wire[VOICE_COUNT*7-1:0]live_notes,notes,original_keys,
 input wire[VOICE_COUNT*2-1:0]owners,input wire[VOICE_COUNT*4-1:0]channels,
 output reg[24:0]key_held=0,output reg[374:0]key_labels=0
);
 reg[5:0]index=0;
 reg[24:0]working_held=0;reg[374:0]working_labels=0;
 reg[VOICE_COUNT-1:0]voice_gates=0;reg[VOICE_COUNT*7-1:0]voice_notes=0,keys=0;
 reg[VOICE_COUNT*2-1:0]source=0;reg[VOICE_COUNT*4-1:0]channel=0;
 reg live=0,mapped=0;reg[6:0]input_base=60;reg[174:0]mapping=0;
 wire[4:0]key_index=index-1'b1;
 wire[6:0]raw_note=input_base+key_index;
 reg[6:0]mapped_note;
 always @*begin
  mapped_note=7'd0;
  for(integer m=0;m<25;m=m+1)mapped_note=mapped_note | (mapping[m*7+:7] & {7{key_index==m}});
 end
 wire[6:0]target_note=mapped?mapped_note:raw_note;
 function automatic[14:0]label_data(input[6:0]note);
  reg[3:0]pc;reg[2:0]degree;reg signed[3:0]octave;reg sharp;
  begin
   pc=note%12;octave=note/12-5;
   case(pc)
    0,1:degree=1;2,3:degree=2;4:degree=3;5,6:degree=4;
    7,8:degree=5;9,10:degree=6;default:degree=7;
   endcase
   sharp=pc==1||pc==3||pc==6||pc==8||pc==10;
   label_data={note,octave,degree,sharp};
  end
 endfunction
 reg held;
 always @*begin
  held=0;
  for(integer v=0;v<VOICE_COUNT;v=v+1)if(voice_gates[v])begin
   if(live&&(source[v*2+:2]==0||source[v*2+:2]==1))
    held=held||(keys[v*7+:7]==raw_note);
   else if(live&&source[v*2+:2]==3&&channel[v*4+:4]==14)
    held=held||(keys[v*7+:7]==key_index);
   else held=held||(voice_notes[v*7+:7]==target_note);
  end
 end
 always @(posedge clk)begin
  if(rst)begin index<=0;key_held<=0;key_labels<=0;end
  else if(index==0)begin
   live<=live_mode;mapped<=map_enabled;input_base<=map_enabled?map_input_base:base_note;mapping<=map_notes;
   voice_gates<=live_mode?live_gates:gates;voice_notes<=live_mode?live_notes:notes;
   source<=owners;keys<=original_keys;channel<=channels;index<=1;
  end else if(index==26)begin key_held<=working_held;key_labels<=working_labels;index<=0;end
  else begin
   for(integer k=0;k<25;k=k+1)if(key_index==k)begin
    working_held[k]<=held;working_labels[k*15+:15]<=label_data(target_note);
   end
   index<=index+1'b1;
  end
 end
endmodule
