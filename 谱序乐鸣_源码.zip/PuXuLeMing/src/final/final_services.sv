// Display/guide observers only: none of these paths can stall USB or audio.
module final_status_bridge #(parameter PERIOD=48000)(
 input wire clk,rst,usb_clk,usb_rstn,usb_running,
 input wire[31:0]diagnostic,
 output wire piano_ready,touch_ready,esp_ready,esp_ready_patterns,status_pattern_raw
);
 wire[5:0]status;wire status_pattern;
 instrument_snapshot #(.WIDTH(6),.PERIOD(PERIOD),.PATTERN_MIRROR(1),.PATTERN_BIT(5)) ready_snapshot(
  .clk(usb_clk),.rstn(usb_rstn),.source_data(diagnostic[5:0]),
  .pixel_clk(clk),.pixel_rstn(!rst),.frame_start(1'b1),.data(status),.pattern_data(status_pattern));
 // Diagnostic error is historical; it must not hide a currently ready sibling.
 assign piano_ready=usb_running&&status[3];
 assign touch_ready=usb_running&&status[2];
 assign esp_ready=usb_running&&status[5];
 assign esp_ready_patterns=usb_running&&status_pattern;
 assign status_pattern_raw=status_pattern;
endmodule

module final_voice_display #(parameter integer VOICE_COUNT=4)(
 input wire clk,rst,input wire[VOICE_COUNT-1:0]gates,input wire[VOICE_COUNT*12-1:0]gains,
 output reg[6:0]home_gates=0,output reg[83:0]home_gains=0
);
 // Voice i belongs to bin i%7; balanced max trees preserve every voice.
 // Default4 is bit-for-bit the original display mapping and1-clock latency.
 localparam integer PER_BIN=(VOICE_COUNT+6)/7;
 localparam integer LEAVES=1<<$clog2(PER_BIN);
 genvar bin,leaf,node;
 generate for(bin=0;bin<7;bin=bin+1)begin:display_bins
  wire[11:0]gain_tree[1:2*LEAVES-1];wire valid_tree[1:2*LEAVES-1];
  for(leaf=0;leaf<LEAVES;leaf=leaf+1)begin:leaves
   if(leaf*7+bin<VOICE_COUNT)begin:voice
    assign gain_tree[LEAVES+leaf]=gates[leaf*7+bin]?gains[(leaf*7+bin)*12+:12]:12'd0;
    assign valid_tree[LEAVES+leaf]=gates[leaf*7+bin];
   end else begin:padding
    assign gain_tree[LEAVES+leaf]=0;assign valid_tree[LEAVES+leaf]=0;
   end
  end
  for(node=1;node<LEAVES;node=node+1)begin:branches
   assign valid_tree[node]=valid_tree[2*node]|valid_tree[2*node+1];
   assign gain_tree[node]=gain_tree[2*node]>=gain_tree[2*node+1]?gain_tree[2*node]:gain_tree[2*node+1];
  end
  always @(posedge clk)begin
   if(rst)begin home_gates[bin]<=0;home_gains[bin*12+:12]<=0;end
   else begin home_gates[bin]<=valid_tree[1];home_gains[bin*12+:12]<=gain_tree[1];end
  end
 end endgenerate
endmodule

module final_guide_led(
 input wire[1:0]mode,input wire[6:0]target_note,input wire done,
 input wire[6:0]activity,input wire usb_ready,output wire[7:0]led_o
);
 reg[6:0]target;
 reg[2:0]degree;
 reg sharp;
 wire guiding=mode==2||mode==3;
 always @*begin
  degree=0;sharp=0;target=0;
  case(target_note%12)
   0:degree=0;1:begin degree=0;sharp=1;end
   2:degree=1;3:begin degree=1;sharp=1;end
   4:degree=2;5:degree=3;6:begin degree=3;sharp=1;end
   7:degree=4;8:begin degree=4;sharp=1;end
   9:degree=5;10:begin degree=5;sharp=1;end
   11:degree=6;default:degree=0;
  endcase
  if(target_note!=127&&!done)target=7'b1<<degree;
 end
 assign led_o=~{guiding?(sharp&&target_note!=127&&!done):usb_ready,guiding?target:activity};
endmodule

module final_leading_voice #(parameter integer VOICE_COUNT=4)(
 input wire clk,rst,input wire[VOICE_COUNT-1:0]active,input wire[VOICE_COUNT*7-1:0]notes,
 input wire[VOICE_COUNT*12-1:0]gains,input wire[VOICE_COUNT*24-1:0]steps,input wire[VOICE_COUNT*16-1:0]envelopes,
 output reg[6:0]leading_note=0,output reg[10:0]leading_pitch=0,
 output reg[23:0]leading_step=0,output reg[15:0]leading_envelope=0,
 output reg leading_valid=0
);
 localparam integer LEAVES=1<<$clog2(VOICE_COUNT);
 localparam integer PAIRS=LEAVES>1?LEAVES/2:1;
 reg[1:0]state=0;
 // Lowest valid slot wins through ceil(log2(VOICE_COUNT)) mux levels.
 wire[46:0]tree[1:2*LEAVES-1];wire valid_tree[1:2*LEAVES-1];
 genvar leaf,node;
 generate for(leaf=0;leaf<LEAVES;leaf=leaf+1)begin:leaves
  if(leaf<VOICE_COUNT)begin:voice
   assign valid_tree[LEAVES+leaf]=active[leaf]&&gains[leaf*12+:12]!=0;
   assign tree[LEAVES+leaf]={notes[leaf*7+:7],steps[leaf*24+:24],envelopes[leaf*16+:16]};
  end else begin:padding
   assign valid_tree[LEAVES+leaf]=0;assign tree[LEAVES+leaf]=0;
  end
 end
 for(node=1;node<LEAVES;node=node+1)begin:branches
  assign valid_tree[node]=valid_tree[node*2]||valid_tree[node*2+1];
  assign tree[node]=valid_tree[node*2]?tree[node*2]:tree[node*2+1];
 end endgenerate
 // Capture the original state0 cohort through one local pair mux.
 // The existing state1 ROM wait completes selection before state2 consumes it.
 wire[46:0]pair_tree[1:2*PAIRS-1];wire pair_valid[1:2*PAIRS-1];
 genvar cp,cn;
 generate for(cp=0;cp<PAIRS;cp=cp+1)begin:candidate_pairs
  (* syn_preserve=1,syn_keep=1 *)reg[46:0]candidate=0;
  (* syn_preserve=1,syn_keep=1 *)reg valid=0;
  always @(posedge clk)if(state==0)begin candidate<=tree[PAIRS+cp];valid<=valid_tree[PAIRS+cp];end
  assign pair_tree[PAIRS+cp]=candidate;assign pair_valid[PAIRS+cp]=valid;
 end
 for(cn=1;cn<PAIRS;cn=cn+1)begin:remaining_selection
  assign pair_valid[cn]=pair_valid[cn*2]||pair_valid[cn*2+1];
  assign pair_tree[cn]=pair_valid[cn*2]?pair_tree[cn*2]:pair_tree[cn*2+1];
 end endgenerate
 reg[23:0]pitch_steps[0:2047] /* synthesis syn_romstyle="block_rom" */;
 initial $readmemh("src/play/p8_pitch_steps.hex",pitch_steps);
 reg[10:0]address=1024,base=0;reg[23:0]q=0,held_step=0;
 reg[6:0]held_note=0;reg[15:0]held_env=0;reg held_valid=0;
 reg[3:0]bit_index=10;
 wire[10:0]accepted=q<=held_step?address:base;
 always @(posedge clk)q<=pitch_steps[address];
 always @(posedge clk)begin
  if(rst)begin state<=0;address<=1024;base<=0;bit_index<=10;
   leading_note<=0;leading_pitch<=0;leading_step<=0;leading_envelope<=0;leading_valid<=0;
   held_step<=0;held_note<=0;held_env<=0;held_valid<=0;
  end else case(state)
   0:begin address<=1024;base<=0;bit_index<=10;state<=1;end
   1:begin held_note<=pair_tree[1][46:40];held_step<=pair_tree[1][39:16];held_env<=pair_tree[1][15:0];held_valid<=pair_valid[1];state<=2;end
   2:begin
    base<=accepted;
    if(bit_index==0)begin
     leading_note<=held_note;leading_pitch<=accepted;leading_step<=held_step;
     leading_envelope<=held_env;leading_valid<=held_valid;state<=0;
    end else begin address<=accepted|(11'd1<<(bit_index-1'b1));bit_index<=bit_index-1'b1;state<=1;end
   end
   default:state<=0;
  endcase
 end
endmodule

// One shared ingress register separates UI/source expansion from recorder
// reservation/commit control. Live audio and captured events see the same bus.
module final_sound_pipe #(parameter integer VOICE_COUNT=4)(
 input wire clk,rst,input wire[VOICE_COUNT-1:0] in_gates,in_triggers,
 input wire[VOICE_COUNT*7-1:0] in_notes,input wire[VOICE_COUNT*12-1:0] in_gains,input wire[VOICE_COUNT*3-1:0] in_timbres,
 input wire[18:0] in_ratio,input wire[6:0] in_mod,input wire[31:0] in_config,
 output reg[VOICE_COUNT-1:0] gates=0,triggers=0,output reg[VOICE_COUNT*7-1:0] notes=0,
 output reg[VOICE_COUNT*12-1:0] gains=0,output reg[VOICE_COUNT*3-1:0] timbres=0,
 output reg[18:0] ratio=262144,output reg[6:0] mod_depth=0,output reg[31:0] config_word=0
);
 always @(posedge clk)begin
  if(rst)begin gates<=0;triggers<=0;notes<=0;gains<=0;timbres<=0;ratio<=262144;mod_depth<=0;config_word<=0;end
  else begin gates<=in_gates;triggers<=in_triggers;notes<=in_notes;gains<=in_gains;timbres<=in_timbres;ratio<=in_ratio;mod_depth<=in_mod;config_word<=in_config;end
 end
endmodule

