`timescale 1ns/1ps
module final_audio #(parameter ENABLE_FX=0,DISTRIBUTED_RESET=0)(
 input wire clk,rst,input wire [3:0] gates,triggers,input wire [27:0] notes,
 input wire [47:0] gains,input wire [11:0] timbres,
 input wire [18:0] ratio,input wire [6:0] mod_depth,input wire [31:0] synth_config,
 output wire sample_tick,output wire signed [15:0] pcm,output wire pcm_positive,
 output wire hp_bck,hp_ws,hp_din,i2s_bck,i2s_ws,i2s_sd,
 output wire [3:0] active,output wire [95:0] monitor_steps,
 output wire [63:0] monitor_envelopes,output wire deadline_error,output reg clip_active=0,
 input wire[11:0]model_reset
);
 `include "play_note_steps.vh"
 reg [3:0] frame_gates=0,frame_triggers=0,pending_triggers=0;
 reg [27:0] frame_notes=0;reg [47:0] frame_gains=0;reg [11:0] frame_timbres=0;
 (* syn_preserve=1 *)reg[3:0]frame_gain_zero=4'hf;
 reg [18:0] frame_ratio=262144;
 reg [95:0] event_steps=0;reg [6:0] index=0;reg [42:0] product=0;
 reg [31:0] mod_phase=0;wire [14:0] mod_magnitude=mod_phase[30]?~mod_phase[29:15]:mod_phase[29:15];
 wire signed [15:0] mod_triangle=mod_phase[31]?-$signed({1'b0,mod_magnitude}):$signed({1'b0,mod_magnitude});
 reg signed [22:0] mod_depth_product=0;reg signed [13:0] mod_offset=0;
 reg signed [33:0] mod_bend_product=0;reg [18:0] modulated_ratio=262144;
 reg [6:0] render_wait=0;
 wire render_tick=render_wait==1;
 // Three UI levels travel through the existing 32-bit recorded configuration.
 wire fx_deadline;
 wire[6:0]ui_depth_target=!ENABLE_FX?7'd0:synth_config[5:4]==1?7'd24:synth_config[5:4]==2?7'd56:synth_config[5:4]==3?7'd96:7'd0;
 reg[6:0]ui_depth=0;
 always @(posedge clk)begin
  if(rst)ui_depth<=0;
  else if(sample_tick)begin
   if(ui_depth<ui_depth_target)ui_depth<=ui_depth+1'b1;
   else if(ui_depth>ui_depth_target)ui_depth<=ui_depth-1'b1;
  end
 end
 wire[6:0]effective_depth=ui_depth>mod_depth?ui_depth:mod_depth;
 always @(posedge clk)begin
  if(rst)begin mod_phase<=0;mod_depth_product<=0;mod_offset<=0;mod_bend_product<=0;modulated_ratio<=262144;end
  else begin
   if(sample_tick)mod_phase<=mod_phase+32'd439805;
   mod_depth_product<=mod_triangle*$signed({1'b0,effective_depth});
   mod_offset<=($signed(mod_depth_product)*28'sd30)>>>15;
   mod_bend_product<=$signed({1'b0,ratio})*mod_offset;
   modulated_ratio<=$signed({1'b0,ratio})+(mod_bend_product>>>18);
  end
 end
 always @(posedge clk)begin
  frame_triggers<=0;
  if(rst)begin
   frame_gates<=0;frame_triggers<=0;pending_triggers<=0;frame_notes<=0;frame_gains<=0;frame_timbres<=0;
   frame_gain_zero<=4'hf;frame_ratio<=262144;event_steps<=0;index<=0;product<=0;render_wait<=0;
  end else begin
   if(sample_tick)begin
    frame_gates<=gates;frame_notes<=notes;frame_gains<=gains;frame_timbres<=timbres;
    for(integer g=0;g<4;g=g+1)frame_gain_zero[g]<=gains[g*12+:12]==0;
    frame_ratio<=effective_depth==0?ratio:modulated_ratio;
    frame_triggers<=pending_triggers|triggers;pending_triggers<=0;index<=1;render_wait<=64;
   end else begin
    pending_triggers<=pending_triggers|triggers;
    if(render_wait!=0)render_wait<=render_wait-1'b1;
    if(index!=0)begin
     if(index<=4)product<=midi_step(frame_notes[(index-1)*7+:7])*frame_ratio;
     if(index>=2)event_steps[(index-2)*24+:24]<=product[41:18];
     index<=index==5?0:index+1'b1;
    end
   end
  end
 end
 assign monitor_steps=event_steps;
 // Mixed physical bank: R2 strings and R1 electric piano/reed, original per-voice ownership.
 reg [3:0] phys_triggers=0;
 always @(posedge clk)if(rst)phys_triggers<=0;else if(render_tick)phys_triggers<=0;else phys_triggers<=phys_triggers|frame_triggers;
 wire [63:0] phys_samples,phys_envelopes;
 wire [3:0] phys_active;wire phys_busy,phys_deadline;
 final_phys_bank #(.PREDECODE_MUTE(1),.PRECALC_REED(1),.DISTRIBUTED_RESET(DISTRIBUTED_RESET)) physical(.clk(clk),.rst(rst),.model_reset(model_reset),.render_tick(render_tick),.gates(frame_gates),.triggers(phys_triggers),.hard_mute_mask(frame_gain_zero),
  .steps(event_steps),.gains(frame_gains),.timbres(frame_timbres),.samples(phys_samples),.envelopes(phys_envelopes),
  .active(phys_active),.busy(phys_busy),.deadline_error(phys_deadline));
 assign deadline_error=phys_deadline|fx_deadline;
 genvar v;
 wire signed[15:0]selected[0:3],smooth_sample[0:3];
 reg signed[15:0]stolen_tail[0:3];reg[6:0]crossfade[0:3];
 wire[63:0]fade_samples,fade_tails,fade_history;wire[27:0]fade_weights;
 generate for(v=0;v<4;v=v+1)begin:outputs
  assign active[v]=!frame_gain_zero[v]&&(phys_active[v]||crossfade[v]!=0);
  assign monitor_envelopes[v*16+:16]=phys_envelopes[v*16+:16];
  assign selected[v]=frame_gain_zero[v]?16'sd0:$signed(phys_samples[v*16+:16]);
  assign fade_samples[v*16+:16]=selected[v];
  assign fade_tails[v*16+:16]=stolen_tail[v];
  assign fade_weights[v*7+:7]=crossfade[v];
  // Keep the original instantaneous fader for voice-steal history and
  // diagnostics. The PCM mixer uses its own equivalent three-edge cuts.
  wire signed[16:0]difference={stolen_tail[v][15],stolen_tail[v]}-{selected[v][15],selected[v]};
  wire signed[24:0]fade_product=difference*$signed({1'b0,crossfade[v]});
  wire signed[23:0]crossfaded=$signed(selected[v])+(fade_product>>>6);
  assign smooth_sample[v]=frame_gain_zero[v]?16'sd0:crossfade[v]==0?selected[v]:crossfaded[15:0];
  always @(posedge clk)begin
   if(rst)begin stolen_tail[v]<=0;crossfade[v]<=0;end
   else if(sample_tick)begin
    if((pending_triggers[v]||triggers[v])&&active[v])begin stolen_tail[v]<=smooth_sample[v];crossfade[v]<=64;end
    else if(crossfade[v]!=0)crossfade[v]<=crossfade[v]-1'b1;
   end
  end
 end endgenerate
 // Keep the original three-edge public PCM/sign/sticky-clip latency while
 // moving the cuts to local fader operands and weighted leaf sums.
 reg[5:0]master_gain=0;
 always @(posedge clk)if(rst)master_gain<=0;else if(sample_tick&&master_gain<32)master_gain<=master_gain+1'b1;
 wire[5:0]gain_after_this_edge=sample_tick&&master_gain<32?master_gain+1'b1:master_gain;
 wire signed[15:0]source_pcm;wire source_positive;
 final_cycle_mixer mixer(clk,rst,fade_samples,fade_tails,fade_weights,~frame_gain_zero,gain_after_this_edge,source_pcm,clip_active,fade_history,source_positive);
 generate if(ENABLE_FX)begin:effects
  final_fx processor(.clk(clk),.rst(rst),.sample_tick(sample_tick),.clear(synth_config[31]),.dry(source_pcm),.dry_positive(source_positive),
   .chorus_level(synth_config[1:0]),.reverb_level(synth_config[3:2]),.pcm(pcm),.pcm_positive(pcm_positive),.ready(),.deadline_error(fx_deadline),.tap_delays());
 end else begin:original_dry
  assign pcm=source_pcm;assign pcm_positive=source_positive;assign fx_deadline=0;
 end endgenerate
 i2s_tx16 tx(.clk(clk),.rst(rst),.pcm_l(pcm),.pcm_r(pcm),.bck(i2s_bck),.ws(i2s_ws),.sd(i2s_sd),.sample_tick(sample_tick));
 pt8211_tx16 adapter(.clk(clk),.rst(rst),.pcm_l(pcm),.pcm_r(pcm),.bck(hp_bck),.ws(hp_ws),.sd(hp_din));
endmodule

// Existing R2 verified mixer mapping; acoustic/control configuration remains in the parent.
module final_cycle_mixer(input wire clk,rst,input wire[63:0]samples,tails,
 input wire[27:0]weights,input wire[3:0]nonzero,input wire[5:0]gain_after_this_edge,
 output wire signed[15:0]pcm,output reg clip_active=0,output wire[63:0]smooth_history,
 output reg pcm_positive=0);
 (* syn_preserve=1 *)reg[5:0]gain1=0,gain2=0;
 reg valid1=0,valid2=0,valid3=0;
 always @(posedge clk)begin
  gain1<=gain_after_this_edge;gain2<=gain1;
  if(rst)begin valid1<=0;valid2<=0;valid3<=0;end
  else begin valid1<=1;valid2<=valid1;valid3<=valid2;end
 end
 wire signed[22:0]weighted_next[0:3];genvar m;
 generate for(m=0;m<4;m=m+1)begin:slot
  wire signed[15:0]sample_now=samples[m*16+:16],tail_now=tails[m*16+:16];
  (* syn_preserve=1 *)reg signed[16:0]difference_q=0;
  (* syn_preserve=1 *)reg signed[15:0]selected_q=0,smooth_q=0;
  (* syn_preserve=1 *)reg[6:0]weight_q=0;
  (* syn_preserve=1 *)reg nonzero_q=0;
  wire signed[24:0]fader_product=difference_q*$signed({1'b0,weight_q});
  wire signed[24:0]selected_shift=$signed({{9{selected_q[15]}},selected_q})<<<6;
  wire signed[24:0]combined=fader_product+selected_shift;
  always @(posedge clk)begin
   difference_q<=$signed({tail_now[15],tail_now})-$signed({sample_now[15],sample_now});
   selected_q<=sample_now;weight_q<=weights[m*7+:7];nonzero_q<=nonzero[m];
   smooth_q<=!nonzero_q ? 16'sd0 : weight_q==0 ? selected_q : combined[21:6];
  end
  assign weighted_next[m]=$signed(smooth_q)*$signed({1'b0,gain2});
  assign smooth_history[m*16+:16]=smooth_q;
 end endgenerate
 wire signed[23:0]pair01_next=$signed({weighted_next[0][22],weighted_next[0]})+$signed({weighted_next[1][22],weighted_next[1]});
 wire signed[23:0]pair23_next=$signed({weighted_next[2][22],weighted_next[2]})+$signed({weighted_next[3][22],weighted_next[3]});
 (* syn_preserve=1 *)reg signed[23:0]pair01_q=0,pair23_q=0;
 always @(posedge clk)begin pair01_q<=pair01_next;pair23_q<=pair23_next;end
 wire signed[24:0]sum_next=$signed({pair01_next[23],pair01_next})+$signed({pair23_next[23],pair23_next});
 wire signed[24:0]sum_q=$signed({pair01_q[23],pair01_q})+$signed({pair23_q[23],pair23_q});
 wire signed[24:0]limited_next=sum_next>>>5,limited_q=sum_q>>>5;
 // Register the sign predicate on the same edge as weighted pairs.
 // Saturation preserves the sign; no PCM or sample/trigger latency is added.
 always @(posedge clk)begin
  if(rst)pcm_positive<=0;else pcm_positive<=valid2&&(limited_next>25'sd0);
 end
 always @(posedge clk)begin
  if(rst)clip_active<=0;
  else if(valid2&&(limited_next>25'sd32767||limited_next< -25'sd32768))clip_active<=1;
 end
 assign pcm=!valid3?16'sd0:limited_q>25'sd32767 ? 16'sd32767 :
     limited_q< -25'sd32768 ? 16'sh8000 :limited_q[15:0];
endmodule
