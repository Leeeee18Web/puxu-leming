module final_navigation #(parameter DEFAULT_TIMBRE=0,HIDE_EP=0)(
 input wire clk,rst,touch_update,touch_valid,touch_down,input wire[6:0]touch_key_base,
 input wire [15:0] touch_x,touch_y,input wire event_ready,
 input wire panic_key,centre_key,
 output reg event_valid=0,output reg [31:0]event_data=0,
 output reg [2:0]page=0,output reg [1:0]mode=0,knob_mode=1,
 output reg [6:0]base_note=60,
 output reg centre=0,panic=0,clear_live=0,start_score=0,stop_score=0,muted=0,restart_lesson=0,
 output reg [5:0]xy_config=6'b101000,output reg [1:0]spectrum_zoom=0,
 output reg [1:0]pattern_mode=0,output reg pattern_start=0,
 output reg record_toggle=0,replay_toggle=0,transport_stop=0,timbre_open=0,xy_overview=0,
 output reg [7:0] envelope_choices=8'h95,output reg preview_toggle=0,output reg timbre_commit=0,input wire preview_busy,
 output reg [2:0] timbre=DEFAULT_TIMBRE,output reg [31:0] synth_config=32'h00009500
);
 `include "final_geometry.vh"
 localparam [7:0]NONE=8'hff;
 reg contact_down=0;
 reg [7:0]desired_note=NONE,sounding_note=NONE;
 // A contact belongs to the control it began on. A held tab/home touch must
 // never turn into a piano note after the page beneath that finger changes.
 reg [1:0]contact_kind=0; // 1 piano,0 buttons/background
 integer head,tab,choice,octave,hit,pattern_hit,i,rec_hit,matrix_hit,timbre_hit,fx_hit;
 always @*begin
  fx_hit=final_fx_hit(touch_x,touch_y);
  rec_hit=final_record_hit(touch_x,touch_y,page);
  matrix_hit=final_matrix_hit(touch_x,touch_y);timbre_hit=final_timbre_hit(touch_x,touch_y);
  if(HIDE_EP&&timbre_hit>=0)timbre_hit=timbre_hit<4?timbre_hit+1:-1;
  head=p8_header_hit(touch_x,touch_y);tab=p8_tab_hit(touch_x,touch_y);
  choice=p8_home_hit(touch_x,touch_y);octave=p8_octave_hit(touch_x,touch_y);
  hit=key_hit(touch_x,touch_y);pattern_hit=p8_pattern_hit(touch_x,touch_y);
 end
 always @(posedge clk)begin
  record_toggle<=0;replay_toggle<=0;transport_stop<=0;preview_toggle<=0;timbre_commit<=0;
  centre<=0;panic<=0;clear_live<=0;start_score<=0;stop_score<=0;restart_lesson<=0;pattern_start<=0;
  if(rst)begin
   page<=0;mode<=0;knob_mode<=1;base_note<=60;
   timbre<=DEFAULT_TIMBRE;timbre_open<=0;xy_overview<=0;synth_config<=32'h00009500;envelope_choices<=8'h95;
   event_valid<=0;event_data<=0;contact_down<=0;contact_kind<=0;
   desired_note<=NONE;sounding_note<=NONE;
   xy_config<=6'b101000;spectrum_zoom<=0;muted<=0;pattern_mode<=0;pattern_start<=0;
  end else begin
   if(event_valid&&event_ready)begin
    event_valid<=0;
    if(event_data[7:4]==9)sounding_note<=event_data[15:8];
    else if(event_data[7:4]==8)sounding_note<=NONE;
   end
   if(!event_valid)begin
    if(sounding_note!=desired_note)begin
     event_valid<=1;
     if(sounding_note!=NONE)event_data<={7'd0,1'b1,8'd0,sounding_note,8'h80};
     else event_data<={7'd0,1'b1,8'd100,desired_note,8'h90};
    end
   end
   if(!touch_valid)begin desired_note<=NONE;contact_down<=0;contact_kind<=0;end
   else if(touch_update)begin
    contact_down<=touch_down;
    if(!touch_down)begin desired_note<=NONE;contact_kind<=0;end
    else if(!contact_down)begin
     desired_note<=NONE;contact_kind<=0;
     if(page!=0&&timbre_open)begin
      // Modal contact is consumed, even outside the popup: never becomes a note.
      if(fx_hit!=0)begin
       case(fx_hit)
        1:synth_config[1:0]<=synth_config[1:0]+2'd1;
        2:synth_config[3:2]<=synth_config[3:2]+2'd1;
        3:synth_config[5:4]<=synth_config[5:4]+2'd1;
       endcase
      end else if(timbre_hit>=0)begin timbre<=timbre_hit[2:0];timbre_commit<=1;timbre_open<=0;end
      else timbre_open<=0;
     end else if(page!=0&&touch_x>=704&&touch_x<1008&&touch_y>=8&&touch_y<56)begin
      timbre_open<=1;
     end else if(page==3&&xy_overview&&touch_y>=128)begin
      if(touch_x>=848&&touch_x<1008&&touch_y>=132&&touch_y<176)xy_overview<=0;
      else if(matrix_hit>=0)begin xy_config<={1'b0,matrix_hit[4:2],matrix_hit[1:0]};xy_overview<=0;end
     end else if(head!=0||(page==0&&choice!=0))begin
      timbre_open<=0;xy_overview<=0;
      case(head!=0?head:choice)
       1:page<=0;
       2:begin mode<=1;page<=1;stop_score<=1;clear_live<=1;muted<=0;pattern_mode<=0;end
       3:begin mode<=2;page<=1;clear_live<=1;start_score<=1;pattern_mode<=0;end
       4:muted<=~muted;
       7:begin stop_score<=1;transport_stop<=1;end
       8:begin mode<=3;page<=5;stop_score<=1;clear_live<=1;restart_lesson<=1;muted<=0;pattern_mode<=0;end
      endcase
     end else if(page!=0&&tab!=0)begin page<=tab[2:0];xy_overview<=0;timbre_open<=0;end
     else if(page==6)begin
      // Draft controls consume this contact; no piano or recorder fall-through.
      for(i=0;i<4;i=i+1)begin
       if(touch_y>=168+64*i&&touch_y<216+64*i)begin
        if(touch_x>=200&&touch_x<380)envelope_choices[i*2+:2]<=0;
        else if(touch_x>=396&&touch_x<576)envelope_choices[i*2+:2]<=1;
        else if(touch_x>=592&&touch_x<772)envelope_choices[i*2+:2]<=2;
        else if(touch_x>=788&&touch_x<968)envelope_choices[i*2+:2]<=3;
       end
      end
      if(touch_x>=400&&touch_x<624&&touch_y>=520&&touch_y<560)preview_toggle<=1;
      if(touch_y>=552&&touch_y<592)begin
       if(touch_x>=32&&touch_x<200)envelope_choices<=8'h95;
       else if(touch_x>=824&&touch_x<992)begin synth_config[15:8]<=envelope_choices;timbre<=4;timbre_commit<=1;end
      end
     end
     else if(rec_hit!=0)begin if(rec_hit==1)record_toggle<=1;else replay_toggle<=1;end
     else if(mode==2&&page!=3&&page!=5&&touch_x>=384&&touch_x<688&&touch_y>=128&&touch_y<184)begin
      if(touch_x>=384&&touch_x<544)begin start_score<=1;clear_live<=1;end
      else if(touch_x>=560&&touch_x<688)stop_score<=1;
     end
     else if(page==5&&mode==1&&pattern_hit!=0)begin
      if(pattern_hit==4)begin
       if(pattern_mode!=0)begin pattern_start<=1;muted<=0;end
      end else begin
       pattern_mode<=pattern_mode==pattern_hit[1:0]?2'd0:pattern_hit[1:0];
       clear_live<=1;
      end
     end
     else if(page==5&&mode==3&&touch_x>=416&&touch_x<600&&touch_y>=176&&touch_y<224)restart_lesson<=1;
     else if(page==5&&mode!=2&&hit>=0)begin
      desired_note<=touch_key_base+hit;contact_kind<=1;
      if(mode==0)mode<=1;
     end else if(page==2&&touch_y>=132&&touch_y<176)begin
      if(touch_x>=720&&touch_x<812)spectrum_zoom<=0;
      else if(touch_x>=812&&touch_x<904)spectrum_zoom<=1;
      else if(touch_x>=904&&touch_x<996)spectrum_zoom<=2;
     end else if(page==3)begin
      if(touch_x>=848&&touch_x<1008&&touch_y>=132&&touch_y<176)xy_config[5]<=~xy_config[5];
      if(touch_x>=856&&touch_x<1008&&touch_y>=192&&touch_y<280)xy_overview<=1;
     end
    end else if(contact_kind==1&&page==5&&mode!=2)begin
     if(hit>=0)desired_note<=touch_key_base+hit;else desired_note<=NONE;
    end
   end
   if(panic_key)begin panic<=1;stop_score<=1;desired_note<=NONE;contact_kind<=0;end
   if(panic||clear_live)begin
    desired_note<=NONE;sounding_note<=NONE;event_valid<=0;
   end
  end
 end
endmodule
