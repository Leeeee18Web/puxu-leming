// Four cuts from the final-panel overlay coordinate to its existing RGB mux.
// All original pages retain their own pixel path and latency.
module envelope_ui #(parameter HIDE_EP=0)(
 input wire clk,rstn,input wire [9:0] x,y,input wire [2:0] page,timbre,
 input wire dropdown,input wire [7:0] choices,input wire preview_busy,
 output reg active=0,output reg [23:0] rgb=0
);
 `include "envelope_text_map.vh"
 localparam [23:0] BG=24'h10151b,EDGE=24'h536975,TEXT=24'heff7f7,CYAN=24'h60d9ed,GREEN=24'h78e6af;
 reg [23:0] font[0:1279] /* synthesis syn_romstyle="block_rom" */;
 initial $readmemh("src/final/envelope_font.hex",font);
 integer i,j,left,top,label_id,tx,ty,dx,dy;
 // Display snapshots change at frame start. Register their geometry before the
 // curve's first row444, so parameter decoding never joins a pixel multiplier.
 reg [7:0]peak_x=128;reg [8:0]decay_x=192;
 reg [9:0]release_x=352,end_x=480;
 reg [6:0]sh=26;reg [2:0]a_shift=5;reg [3:0]d_shift=6,r_shift=7;
 function automatic [26:0]curve_geometry(input [3:0]ad);
 begin case(ad)
 4'h0:curve_geometry={8'd96,9'd128,10'd288};
 4'h1:curve_geometry={8'd128,9'd160,10'd320};
 4'h2:curve_geometry={8'd160,9'd192,10'd352};
 4'h3:curve_geometry={8'd224,9'd256,10'd416};
 4'h4:curve_geometry={8'd96,9'd160,10'd320};
 4'h5:curve_geometry={8'd128,9'd192,10'd352};
 4'h6:curve_geometry={8'd160,9'd224,10'd384};
 4'h7:curve_geometry={8'd224,9'd288,10'd448};
 4'h8:curve_geometry={8'd96,9'd224,10'd384};
 4'h9:curve_geometry={8'd128,9'd256,10'd416};
 4'ha:curve_geometry={8'd160,9'd288,10'd448};
 4'hb:curve_geometry={8'd224,9'd352,10'd512};
 4'hc:curve_geometry={8'd96,9'd352,10'd512};
 4'hd:curve_geometry={8'd128,9'd384,10'd544};
 4'he:curve_geometry={8'd160,9'd416,10'd576};
 4'hf:curve_geometry={8'd224,9'd480,10'd640};
 endcase end endfunction
 always @(posedge clk)begin
  {peak_x,decay_x,release_x}<=curve_geometry(choices[3:0]);
  end_x<=release_x+(10'd32<<choices[7:6]);
  a_shift<=3'd4+{1'b0,choices[1:0]};d_shift<=4'd5+{2'b0,choices[3:2]};r_shift<=4'd5+{2'b0,choices[7:6]};
  case(choices[5:4])0:sh<=13;1:sh<=26;2:sh<=45;3:sh<=64;endcase
 end
 // Curve work shares the existing font cuts: subtract, multiply, then test.
 // Signed vertical distances replace a final base-height add on the RGB path.
 reg [9:0]curve_delta;reg [6:0]curve_coeff;reg [3:0]curve_shift;
 reg signed [10:0]curve_vertical;reg curve_rising,curve_valid;
 always @*begin
  curve_delta=0;curve_coeff=0;curve_shift=0;curve_rising=0;
  curve_vertical=$signed({1'b0,y})-11'sd508;
  curve_valid=page==6&&x>=96&&x<928&&y>=444&&y<510&&x<=end_x;
  if(x<peak_x)begin
   curve_delta=x-10'd96;curve_coeff=64;curve_shift={1'b0,a_shift};curve_rising=1;
   curve_vertical=11'sd508-$signed({1'b0,y});
  end else if(x<decay_x)begin
   curve_delta=x-{2'd0,peak_x};curve_coeff=7'd64-sh;curve_shift=d_shift;
   curve_vertical=$signed({1'b0,y})-11'sd444;
  end else if(x<release_x)begin
   curve_vertical=$signed({1'b0,y})+$signed({4'd0,sh})-11'sd508;
  end else if(x<end_x)begin
   curve_delta=x-release_x;curve_coeff=sh;curve_shift=r_shift;
   curve_vertical=$signed({1'b0,y})+$signed({4'd0,sh})-11'sd508;
  end
 end
 reg use_pixel,text_on,selected;reg [23:0] color,ink;reg [10:0] address;reg [4:0] column;
 function automatic env_box(input integer ax,ay,bx,by);
 begin env_box=x>=ax&&x<bx&&y>=ay&&y<by;end endfunction
 function automatic border(input integer ax,ay,bx,by);
 begin border=env_box(ax,ay,bx,by)&&!env_box(ax+2,ay+2,bx-2,by-2);end endfunction
 always @*begin
  use_pixel=0;text_on=0;color=BG;ink=TEXT;label_id=0;tx=0;ty=0;left=0;top=0;selected=0;dx=0;dy=0;
  address=0;column=0;
  // Envelope replaces the removed guide tab; readiness badges stay in PIF position.
  if(page!=0&&env_box(728,72,864,120))begin
   use_pixel=1;color=page==6?24'h254a43:24'h192933;
   if(border(728,72,864,120))color=page==6?GREEN:EDGE;
   label_id=0;tx=772;ty=84;text_on=env_box(772,84,820,108);
  end
  if(page==6&&y>=128)begin
   use_pixel=1;color=BG;text_on=0;
   for(i=0;i<4;i=i+1)begin
    top=168+64*i;
    if(env_box(48,top+12,144,top+36))begin label_id=2+i;tx=48;ty=top+12;text_on=1;ink=CYAN;end
    for(j=0;j<4;j=j+1)begin
     left=200+196*j;
     if(env_box(left,top,left+180,top+48))begin
      selected=choices[i*2+:2]==j;color=selected?24'h254a43:24'h192933;ink=selected?GREEN:TEXT;
      if(border(left,top,left+180,top+48))color=selected?GREEN:EDGE;
      label_id=6+i*4+j;tx=left+(180-env_length(label_id)*24)/2;ty=top+12;
      text_on=env_box(tx,ty,tx+env_length(label_id)*24,ty+24);
     end
    end
   end
   if(env_box(48,420,144,444))begin label_id=27;tx=48;ty=420;text_on=1;ink=CYAN;end
   if(env_box(96,444,928,510))begin
    text_on=0;
    if(y==508||x==96)color=EDGE;

   end
   if(env_box(400,520,624,560))begin
    color=preview_busy?24'h254a43:24'h192933;ink=preview_busy?GREEN:CYAN;
    if(border(400,520,624,560))color=preview_busy?GREEN:CYAN;
    label_id=preview_busy?23:22;tx=488;ty=528;text_on=env_box(tx,ty,tx+48,ty+24);
   end
   if(env_box(650,528,722,552)&&preview_busy)begin label_id=26;tx=650;ty=528;text_on=1;ink=GREEN;end
   if(env_box(32,552,200,592)||env_box(824,552,992,592))begin
    selected=x>=824;left=selected?824:32;color=selected?24'h254a43:24'h192933;ink=selected?GREEN:TEXT;
    if(border(left,552,left+168,592))color=selected?GREEN:EDGE;
    label_id=selected?25:24;tx=left+60;ty=560;text_on=env_box(tx,ty,tx+48,ty+24);
   end
  end
  // The fifth name is rendered independently; legacy four labels are unchanged.
  if(!HIDE_EP&&page!=0&&timbre==4&&env_box(720,16,856,48))begin
   use_pixel=1;color=24'h192933;label_id=1;tx=720;ty=20;ink=TEXT;text_on=env_box(tx,ty,tx+120,ty+24);
  end
  if(page!=0&&dropdown&&env_box(704,64,1008,432))begin
   // Popup owns this whole region, including when covering the envelope page.
   use_pixel=0;text_on=0;
   if(!HIDE_EP&&env_box(728,254,984,286))begin
    use_pixel=1;color=timbre==4?24'h254a43:24'h192933;label_id=1;tx=728;ty=HIDE_EP?214:258;ink=TEXT;
    text_on=env_box(tx,ty,tx+120,ty+24);
   end
  end
  if(text_on)begin dx=x-tx;dy=y-ty;address={env_glyph(label_id[5:0],4'(dx>=144?6:dx>=120?5:dx>=96?4:dx>=72?3:dx>=48?2:dx>=24?1:0)),5'(dy)};column=5'(dx>=144?dx-144:dx>=120?dx-120:dx>=96?dx-96:dx>=72?dx-72:dx>=48?dx-48:dx>=24?dx-24:dx);end
 end
 reg [9:0]curve_delta0=0;reg [6:0]curve_coeff0=0;
 reg [3:0]curve_shift0=0,curve_shift1=0;
 reg signed [10:0]curve_vertical0=0,curve_vertical1=0;
 reg curve_rising0=0,curve_rising1=0,curve_valid0=0,curve_valid1=0;
 reg [16:0]curve_product1=0;
 wire [6:0]curve_height1=curve_product1>>curve_shift1;
 wire signed [10:0]height_signed1={4'd0,curve_height1};
 wire curve_dot1=(height_signed1==curve_vertical1)||
  (curve_rising1?(height_signed1==curve_vertical1+11'sd1):(height_signed1+11'sd1==curve_vertical1));
 reg active0=0,active1=0,active2=0,text0=0,text1=0;
 reg [10:0] address0=0;reg [4:0]col0=0,col1=0;
 reg [23:0]bg0=0,bg1=0,ink0=0,ink1=0,glyph1=0,pixel2=0;
 always @(posedge clk)begin
  if(!rstn)begin active<=0;active0<=0;active1<=0;active2<=0;rgb<=0;end
  else begin
   curve_delta0<=curve_delta;curve_coeff0<=curve_coeff;curve_shift0<=curve_shift;
   curve_vertical0<=curve_vertical;curve_rising0<=curve_rising;curve_valid0<=curve_valid;
   curve_product1<=curve_delta0*curve_coeff0;curve_shift1<=curve_shift0;
   curve_vertical1<=curve_vertical0;curve_rising1<=curve_rising0;curve_valid1<=curve_valid0;
   active0<=use_pixel;address0<=address;col0<=column;text0<=text_on;bg0<=color;ink0<=ink;
   active1<=active0;glyph1<=font[address0];col1<=col0;text1<=text0;bg1<=bg0;ink1<=ink0;
   active2<=active1;pixel2<=curve_valid1&&curve_dot1?GREEN:(text1&&glyph1[23-col1]?ink1:bg1);
   active<=active2;rgb<=pixel2;
  end
 end
endmodule

