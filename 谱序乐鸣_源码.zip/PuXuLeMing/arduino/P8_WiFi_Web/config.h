#pragma once
// Connect the phone to this ESP32 access point, then open http://192.168.4.1/.
#define P8_AP_SSID "PuXu-Instrument"
#define P8_AP_PASSWORD "CHANGE_ME_123" // Example only; override in config.local.h.
// AP-only by default: no router, computer hotspot, DNS or mDNS is required.
#define P8_ENABLE_STA 0
#define P8_STA_SSID ""
#define P8_STA_PASSWORD "CHANGE_ME_123"
#define P8_UART_BAUD 115200


// Keep private settings in the ignored local file.
#if __has_include("config.local.h")
#include "config.local.h"
#endif
