#pragma once
#undef P8_AP_SSID
#undef P8_AP_PASSWORD
#define P8_AP_SSID "PuXu-Instrument"
#define P8_AP_PASSWORD "CHANGE_ME_123"
