#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>

// This layer has no Arduino dependency; the native test exercises these exact
// bytes, CRC, partial reads, retries and matching against a simulated FPGA.
namespace p8 {
constexpr size_t PW_SIZE = 22, WF_SIZE = 28;
constexpr uint32_t IDENTITY = 0x50385731;
inline uint16_t u16(const uint8_t* p) { return uint16_t(p[0]) | uint16_t(p[1]) << 8; }
inline uint32_t u32(const uint8_t* p) { return uint32_t(u16(p)) | uint32_t(u16(p+2)) << 16; }
inline void put16(uint8_t* p, uint16_t n) { p[0]=n; p[1]=n>>8; }
inline uint16_t crc(const uint8_t* p, size_t n) {
  uint16_t c=0xffff;
  while (n--) { c ^= uint16_t(*p++)<<8; for (int i=0;i<8;i++) c=uint16_t((c<<1)^((c&0x8000)?0x1021:0)); }
  return c;
}
inline bool valid(const uint8_t* p) {
  return p[0]=='P' && p[1]=='W' && p[2]==1 && u16(p+6)!=0 && crc(p+2,18)==u16(p+20);
}
inline bool requestValid(const uint8_t* p) {
  return valid(p) && (p[3]<=16 || (p[3]>=20 && p[3]<=24)) && (p[3]!=0 || (u32(p+8)==IDENTITY && !u32(p+12) && !u32(p+16)));
}
inline void releasePacket(uint8_t* p,uint16_t seq,uint16_t session) {
  memset(p,0,PW_SIZE);p[0]='P';p[1]='W';p[2]=1;p[3]=2;
  put16(p+4,seq);put16(p+6,session);put16(p+20,crc(p+2,18));
}
struct Stats { uint32_t tx=0,rxBytes=0,wf=0,badCrc=0,matched=0,ignored=0,timeouts=0; };
enum class Result { Ok, Invalid, WriteFailed, Timeout };

template<class Port> class Link {
 public:
  explicit Link(Port& p):port(p){}
  Stats stats;
  void service() {
    if (count && uint32_t(port.now()-lastByte)>25) count=0;
    for (unsigned budget=0;budget<512;budget++) {
      int c=port.read();if(c<0)break;stats.rxBytes++;lastByte=port.now();
      if(count==WF_SIZE)drop();
      buffer[count++]=uint8_t(c);
      while(count>=4) {
        if(buffer[0]!='W'||buffer[1]!='F'||buffer[2]!=1||buffer[3]!=PW_SIZE){drop();continue;}
        if(count<WF_SIZE)break;
        if(crc(buffer+2,24)!=u16(buffer+26)){stats.badCrc++;drop();continue;}
        stats.wf++;
        const uint8_t* ack=buffer+4;
        if(awaiting && valid(ack) && ack[3]==uint8_t(expected[3]|128) &&
           u16(ack+4)==u16(expected+4) && u16(ack+6)==u16(expected+6) && u32(ack+16)==IDENTITY) {
          memcpy(answer,ack,PW_SIZE);received=true;stats.matched++;
        } else stats.ignored++;
        count=0;
      }
    }
  }
  bool send(const uint8_t* request) {
    uint8_t wire[WF_SIZE]={'W','F',1,PW_SIZE};memcpy(wire+4,request,PW_SIZE);
    put16(wire+26,crc(wire+2,24));
    if(port.write(wire,WF_SIZE)!=WF_SIZE)return false;
    stats.tx++;return true;
  }
  Result transact(const uint8_t* request,uint8_t* reply) {
    if(!requestValid(request))return Result::Invalid;
    // Drain old traffic before installing the next expected identity.
    awaiting=false;service();memcpy(expected,request,PW_SIZE);received=false;awaiting=true;
    for(unsigned attempt=0;attempt<3;attempt++) {
      if(!send(request)){awaiting=false;return Result::WriteFailed;}
      uint32_t started=port.now();
      do {service();if(received){memcpy(reply,answer,PW_SIZE);awaiting=false;return Result::Ok;}port.pause();}
      while(uint32_t(port.now()-started)<200);
    }
    awaiting=false;stats.timeouts++;return Result::Timeout;
  }
 private:
  Port& port;
  uint8_t buffer[WF_SIZE]={},expected[PW_SIZE]={},answer[PW_SIZE]={};
  size_t count=0;uint32_t lastByte=0;bool awaiting=false,received=false;
  void drop(){if(count){memmove(buffer,buffer+1,count-1);count--;}}
};
}

