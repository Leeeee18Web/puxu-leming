#pragma once
#include <stdint.h>
#include <string.h>
// Portable transaction tracker; only matching successful FPGA replies reach ack().
namespace p8 {
struct MapBlob {uint8_t version,base,enabled,notes[25];uint16_t crc;};
inline uint16_t mapCRC(const MapBlob& m){uint16_t c=0xffff;const uint8_t* p=&m.base;for(unsigned i=0;i<27;i++){c^=uint16_t(p[i])<<8;for(unsigned k=0;k<8;k++)c=(c&0x8000)?uint16_t((c<<1)^0x1021):uint16_t(c<<1);}return c;}
inline bool mapValid(const MapBlob& m){if(m.version!=1||m.base>103||m.enabled>1||m.crc!=mapCRC(m))return false;for(auto note:m.notes)if(note>127)return false;return true;}
struct MapTracker {
 MapBlob draft{};uint32_t written=0;bool uploading=false;
 bool ack(const uint8_t* request,const uint8_t* reply){
  if(reply[8]!=0)return false;
  const uint8_t op=request[3];const uint32_t a=uint32_t(request[8])|(uint32_t(request[9])<<8)|(uint32_t(request[10])<<16)|(uint32_t(request[11])<<24);
  const uint32_t b=uint32_t(request[12])|(uint32_t(request[13])<<8)|(uint32_t(request[14])<<16)|(uint32_t(request[15])<<24);
  if(op==0){uploading=false;written=0;}
  if(op==20){draft={};draft.version=1;draft.base=uint8_t(a);draft.enabled=uint8_t(b);uploading=true;written=0;}
  if(op==21&&uploading&&a<25&&b<128){draft.notes[a]=uint8_t(b);written|=1UL<<a;}
  if(op==22&&written==0x1ffffff&&a==mapCRC(draft)){
   // Also verify the applied FPGA checksum carried by the commit ACK.
   const uint16_t applied=uint16_t(reply[12])|(uint16_t(reply[13])<<8);
   if(applied!=a)return false;
   draft.crc=uint16_t(a);uploading=false;return b==1;
  }
  return false;
 }
};
}
