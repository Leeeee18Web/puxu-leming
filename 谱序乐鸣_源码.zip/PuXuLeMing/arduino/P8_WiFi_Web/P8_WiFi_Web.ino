/* P8 direct USB edition. AI Thinker ESP32-CAM + CH340 carrier.
 * Phone HTTP -> PW1 -> WF1/UART0 -> CH340 -> FPGA USB-A.
 * UART0 contains binary protocol only. No camera, SD or WebSocket dependency.
 */
#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <esp_log.h>
#include <Preferences.h>
#include <esp_random.h>
#include "config.h"
#include "p8_link.h"
#include "p8_map_store.h"
#include "web_assets.h"

namespace {
struct UartPort {
  uint32_t now(){return millis();}
  int read(){return Serial0.available()?Serial0.read():-1;}
  size_t write(const uint8_t* data,size_t size){return Serial0.write(data,size);}
  void pause(){delay(1);}
} uartPort;
p8::Link<UartPort> fpgaLink(uartPort);
WebServer http(80);
uint16_t owner=0,lastSequence=0;
uint32_t lastCommandAt=0,pageRequests=0;
constexpr uint32_t CONTROLLER_IDLE_MS=30000;
bool apReady=false,restorePending=true;uint32_t restoreAttemptAt=0;
Preferences mapPreferences;p8::MapTracker mapTracker;
void restoreSavedMap(){
 restoreAttemptAt=millis();p8::MapBlob saved{};
 if(mapPreferences.getBytesLength("active")!=sizeof saved||mapPreferences.getBytes("active",&saved,sizeof saved)!=sizeof saved||!p8::mapValid(saved)){restorePending=false;return;}
 uint8_t request[p8::PW_SIZE],reply[p8::PW_SIZE];uint16_t seq=0;uint16_t internalSession=uint16_t(esp_random());if(!internalSession)internalSession=1;
 auto send=[&](uint8_t op,uint32_t a,uint32_t b)->bool{
  memset(request,0,sizeof request);request[0]='P';request[1]='W';request[2]=1;request[3]=op;
  request[4]=uint8_t(seq);request[5]=uint8_t(seq>>8);seq++;request[6]=uint8_t(internalSession);request[7]=uint8_t(internalSession>>8);
  for(unsigned i=0;i<4;i++){request[8+i]=uint8_t(a>>(8*i));request[12+i]=uint8_t(b>>(8*i));}
  uint16_t c=p8::crc(request+2,18);request[20]=uint8_t(c);request[21]=uint8_t(c>>8);
  return fpgaLink.transact(request,reply)==p8::Result::Ok&&reply[8]==0;
 };
 if(!send(0,p8::IDENTITY,0)||!send(20,saved.base,saved.enabled))return;
 for(unsigned i=0;i<25;i++)if(!send(21,i,saved.notes[i]))return;
 if(send(22,saved.crc,0))restorePending=false;
}


void noCache(){http.sendHeader("Cache-Control","no-store");http.sendHeader("X-Content-Type-Options","nosniff");}
void error(int code,const char* message){noCache();http.send(code,"application/json; charset=utf-8",String("{\"error\":\"")+message+"\"}");}
void releaseOwner() {
  if(owner){uint8_t p[p8::PW_SIZE];p8::releasePacket(p,++lastSequence,owner);fpgaLink.send(p);}
  owner=0;
}
void expireController(){if(owner&&uint32_t(millis()-lastCommandAt)>CONTROLLER_IDLE_MS)releaseOwner();}
bool decodeHex(const String& text,uint8_t* bytes,size_t size) {
  if(text.length()!=size*2)return false;
  for(size_t i=0;i<size;i++) {
    unsigned value=0;
    for(unsigned j=0;j<2;j++) {
      char c=text[i*2+j];unsigned digit;
      if(c>='0'&&c<='9')digit=c-'0';
      else if(c>='a'&&c<='f')digit=c-'a'+10;
      else if(c>='A'&&c<='F')digit=c-'A'+10;
      else return false;
      value=(value<<4)|digit;
    }
    bytes[i]=uint8_t(value);
  }
  return true;
}

void command() {
  // Arduino WebServer builds its plain argument with String(char*), truncating
  // raw bodies at a NUL. HTTP uses 44 ASCII hex characters; UART remains binary.
  const String& body=http.arg("plain");
  uint8_t request[p8::PW_SIZE],reply[p8::PW_SIZE];
  if(!decodeHex(body,request,sizeof request)){error(400,"命令长度或编码错误，请重新打开设备网页。");return;}
  if(!p8::requestValid(request)){error(400,"命令校验失败，请重新连接。");return;}
  if(request[3]>24||(request[3]>16&&request[3]<20)){error(400,"当前版本不支持该命令。");return;}
  expireController();
  uint16_t incoming=p8::u16(request+6);
  if(request[3]==0) {
    if(owner&&owner!=incoming){error(423,"已有手机正在控制，请先断开另一台手机。");return;}
  } else if(!owner||owner!=incoming){error(409,"控制会话已结束，请重新连接乐器。");return;}
  lastCommandAt=millis();lastSequence=p8::u16(request+4);
  p8::Result result=fpgaLink.transact(request,reply);
  if(result!=p8::Result::Ok) {
    // The FPGA's independent lease also releases live keys after loss of link.
    // Keep owner/sequence during a transient UART timeout. The FPGA live-note
    // lease releases keys independently; the client retries this exact frame.
    error(503,result==p8::Result::WriteFailed?"板端串口发送失败，请重新上电。":"ESP32 已发送，但 FPGA 未确认。请检查直连 USB-A，并烧录配套 Final7 码流；电脑串口日志可查看连接状态。");
    return;
  }
  if(request[3]==0 && reply[8]==0){owner=incoming;restorePending=false;}
  if(mapTracker.ack(request,reply)){
    // NVS writes are impossible before the successful whole-table FPGA ACK.
    // Failed persistence has an explicit HTTP error, never a false saved state.
    if(mapPreferences.putBytes("active",&mapTracker.draft,sizeof mapTracker.draft)!=sizeof mapTracker.draft){error(507,"FPGA已应用，但方案保存失败，请重试应用并保存。");return;}
  }
  lastCommandAt=millis();
  noCache();http.setContentLength(sizeof reply);http.send(200,"application/octet-stream","");
  http.client().write(reply,sizeof reply);
}
void release() {
  const String& body=http.arg("plain");
  uint8_t bytes[2];
  if(decodeHex(body,bytes,sizeof bytes) && owner && p8::u16(bytes)==owner)releaseOwner();
  noCache();http.send(204,"text/plain","");
}
void status() {
  char body[768];
  snprintf(body,sizeof body,
    "{\"firmware\":\"P8-SCORE-HTTP-6\",\"build_variant\":\"Final7-Grand-WiFi-2\",\"voice_count\":7,\"timbre_count\":4,\"ap_ready\":%s,\"ap_ip\":\"%s\",\"station_connected\":%s,\"station_ip\":\"%s\"," 
    "\"uptime_ms\":%lu,\"page_requests\":%lu,\"controller_active\":%s,\"uart_baud\":%u,\"uart_tx_frames\":%lu,"
    "\"uart_rx_bytes\":%lu,\"wf_rx_frames\":%lu,\"bad_crc\":%lu,\"fpga_acks\":%lu,\"ignored_frames\":%lu,\"ack_timeouts\":%lu}",
    apReady?"true":"false",WiFi.softAPIP().toString().c_str(),WiFi.status()==WL_CONNECTED?"true":"false",WiFi.localIP().toString().c_str(),
    static_cast<unsigned long>(millis()),static_cast<unsigned long>(pageRequests),owner?"true":"false",P8_UART_BAUD,
    static_cast<unsigned long>(fpgaLink.stats.tx),static_cast<unsigned long>(fpgaLink.stats.rxBytes),static_cast<unsigned long>(fpgaLink.stats.wf),
    static_cast<unsigned long>(fpgaLink.stats.badCrc),static_cast<unsigned long>(fpgaLink.stats.matched),static_cast<unsigned long>(fpgaLink.stats.ignored),static_cast<unsigned long>(fpgaLink.stats.timeouts));
  noCache();http.send(200,"application/json; charset=utf-8",body);
}
}

void setup() {
  esp_log_level_set("*",ESP_LOG_NONE);mapPreferences.begin("poly25-map",false);
  Serial0.setRxBufferSize(2048);Serial0.begin(P8_UART_BAUD,SERIAL_8N1,3,1);Serial0.setDebugOutput(false);
  WiFi.persistent(false);WiFi.mode(P8_ENABLE_STA?WIFI_AP_STA:WIFI_AP);WiFi.setSleep(false);
  IPAddress address(192,168,4,1),mask(255,255,255,0);
  apReady=WiFi.softAPConfig(address,address,mask)&&WiFi.softAP(P8_AP_SSID,P8_AP_PASSWORD,6,false,4);
#if P8_ENABLE_STA
  WiFi.setHostname("p8-piano");WiFi.setAutoReconnect(true);WiFi.begin(P8_STA_SSID,P8_STA_PASSWORD);
#endif
  http.on("/",HTTP_GET,[]{pageRequests++;noCache();http.send_P(200,"text/html; charset=utf-8",P8_WEB_HTML);});
  http.on("/status",HTTP_GET,status);
  http.on("/api/command",HTTP_POST,command);
  http.on("/api/release",HTTP_POST,release);
  http.on("/favicon.ico",HTTP_GET,[]{http.send(204,"text/plain","");});
  http.onNotFound([]{error(404,"页面不存在，请打开设备地址的首页。");});
  http.begin();
}
void loop(){if(restorePending&&!owner&&(!restoreAttemptAt||uint32_t(millis()-restoreAttemptAt)>2000))restoreSavedMap();fpgaLink.service();expireController();http.handleClient();delay(1);}
