#ifndef WIFI_FRAME_H
#define WIFI_FRAME_H
#include "touch.h"
// UART envelope: 'W','F', version=1, length=1..64, payload, CRC16-CCITT LE.
// CRC covers version, length and payload; boot/log text is never delivered.
typedef struct {
    uint8_t state, length, position, low, data[64];
    uint16_t crc;
} wifi_frame;
void wifi_frame_reset(wifi_frame *frame);
int wifi_frame_feed(wifi_frame *frame, uint8_t byte);
#endif
