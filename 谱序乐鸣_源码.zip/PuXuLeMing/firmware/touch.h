#ifndef TOUCH_H
#define TOUCH_H
#ifdef HOST_TEST
#include <stdint.h>
#else
typedef __UINT8_TYPE__ uint8_t;
typedef __UINT16_TYPE__ uint16_t;
typedef __UINT32_TYPE__ uint32_t;
typedef __INT32_TYPE__ int32_t;
#endif

#ifndef TOUCH_SWAP_XY
#define TOUCH_SWAP_XY 0
#endif
#ifndef TOUCH_FLIP_X
#define TOUCH_FLIP_X 0
#endif
#ifndef TOUCH_FLIP_Y
#define TOUCH_FLIP_Y 0
#endif

enum {USB_STATE_NO_DEVICE, USB_STATE_ATTACHED, USB_STATE_RESET,
      USB_STATE_ENUM, USB_STATE_CONFIGURED, USB_STATE_HID_READY, USB_STATE_ERROR};
enum {ERR_NONE, ERR_SPEED, ERR_DEVICE, ERR_ADDRESS, ERR_CONFIG,
      ERR_INTERFACE, ERR_SET_CONFIG, ERR_REPORT_DESC, ERR_HID_FORMAT,
      ERR_POLL, ERR_DISCONNECTED, ERR_PACKET, ERR_TIMEOUT};
typedef struct {uint16_t bit; uint8_t size, present; int32_t min, max;} hid_field;
#define HID_MAX_CONTACTS 10
typedef struct {
    hid_field tip, valid, in_range, contact, x, y;
} hid_contact;
typedef struct {
    uint8_t id, uses_id, num_contacts;
    uint16_t bits;
    hid_contact contacts[HID_MAX_CONTACTS];
    hid_field contact_count;
} hid_layout;
typedef struct {
    uint8_t valid, down;
    uint32_t raw_x, raw_y;
    uint16_t x, y;
} touch_sample;
int hid_parse_descriptor(const uint8_t *d, unsigned n, hid_layout *layout);
int hid_decode(const hid_layout *layout, const uint8_t *r, unsigned n,
               unsigned width, unsigned height, touch_sample *sample);
int touch_button(const touch_sample *s);
#endif
