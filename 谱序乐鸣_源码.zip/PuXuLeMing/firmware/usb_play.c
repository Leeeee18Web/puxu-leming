#include "usb_play.h"
/* USB2 chapters 9/11; USB-MIDI1.0 chapters4/6:
 https://www.usb.org/document-library/usb-20-specification
 https://www.usb.org/sites/default/files/midi10.pdf
 Enumeration is serialized: only one device at address0 at any instant. */
#define STATUS 0x02000200u
#define XY 0x02000204u
#define RAW 0x02000208u
#define VIDPID 0x0200020cu
#define META 0x02000210u
#define EVENT 0x02000214u
#define WIFI_BYTE 0x02000218u
#define WIFI_REPLY 0x0200021cu
#define MIDI_EVENT 0x02000220u
#define DIAG 0x02000228u
#define MAX_CONFIG 512u
#define MAX_REPORT 2048u
#define MAX_INTERFACES 8u
#define CONTROL_MS 250u
enum { KIND_HID=1,KIND_MIDI=2,KIND_HUB=3,KIND_SERIAL=4 };
typedef struct {uint8_t number,packet,interval,toggle,failures;uint32_t due;} endpoint;
typedef struct {
 uint8_t address,ep0,ready,hub,port,parent,depth;uint32_t vidpid;
 endpoint hid,midi,interrupt,serial_in,serial_out;uint8_t hid_interface;
} device;
typedef struct {uint8_t kind,iface,ep,mps,interval,header,jacks,out_ep,out_mps;uint16_t report_len,cs_length,cs_seen,interface_bytes;} candidate;
static device devices[8];
static hid_layout touch_layout;
static uint8_t packet[64],configuration[MAX_CONFIG],report_descriptor[MAX_REPORT];
typedef struct {uint8_t phase,retries,error;uint32_t since;} port_runtime;
typedef struct {uint8_t ports,cursor;uint32_t due,status_due;port_runtime port[8];} hub_runtime;
static hub_runtime hubs[8];
static uint32_t debug_sequence,debug_port,debug_enum,debug_hid,debug_errors;
static uint32_t debug_due;
static uint8_t port_phase[8]; /* legacy zeroed state; topology lives in hubs */
static uint32_t port_since[8],root_since;
static unsigned root_present,root_blocked,ports,port_cursor,touch_owner,midi_owner,wifi_owner,last_error;
static unsigned line_stable,line_candidate;
static uint32_t line_since;
static uint32_t root_retry_at;
static uint32_t touch_status,touch_xy,touch_raw,touch_vidpid,touch_meta,diagnostic;
static void zero(void *p,unsigned n){uint8_t *b=p;while(n--)*b++=0;}
static unsigned le16(const uint8_t *p){return p[0]|((unsigned)p[1]<<8);}
static int due(uint32_t now,uint32_t at){return (int32_t)(now-at)>=0;}
#ifndef HOST_TEST
#define REG(a) (*(volatile uint32_t *)(a))
#define USB(o) REG(0x02000100u+(o))
static uint32_t usb_play_now_ms(void){return REG(0x02000050u);}
static void usb_play_delay_ms(unsigned ms){uint32_t start=usb_play_now_ms();while((uint32_t)(usb_play_now_ms()-start)<ms){}}
static unsigned usb_play_root_speed(void){return USB(4)&3u;}
static unsigned usb_play_root_idle(void){uint32_t s=USB(0x1c);return !(s&(1u<<31))&&(s&(1u<<28));}
static void usb_play_publish(uint32_t a,uint32_t v){REG(a)=v;}
static void usb_play_root_reset(void){USB(0)=0xc4;usb_play_delay_ms(20);USB(0)=0x1e9;usb_play_delay_ms(20);}
static int wait_idle(void){
 uint32_t start=usb_play_now_ms();
 do{uint32_t s=USB(0x1c);if(!(s&(1u<<31))&&(s&(1u<<28)))return 1;}
 while((uint32_t)(usb_play_now_ms()-start)<20);
 return 0;
}
static int usb_play_transaction(unsigned address,unsigned pid,unsigned ep,unsigned toggle,
 const uint8_t *tx,unsigned tx_len,uint8_t *rx,unsigned rx_cap,unsigned *rx_pid){
 unsigned incoming=pid==USB_PLAY_IN;
 if(!incoming){USB(0)=USB(0)|(1u<<8);for(unsigned i=0;i<tx_len;i++)USB(0x20)=tx[i];}
 USB(0x14)=incoming?0:tx_len;
 USB(0x18)=(1u<<31)|(incoming<<30)|(1u<<29)|(toggle<<28)|(pid<<16)|(address<<9)|(ep<<5);
 if(!wait_idle())return USB_PLAY_TIMEOUT;
 uint32_t s=USB(0x1c);unsigned response=(s>>16)&255,n=s&65535;
 if(incoming){for(unsigned i=0;i<n;i++){unsigned b=USB(0x20);if(i<rx_cap)rx[i]=(uint8_t)b;}*rx_pid=response;}
 if(s&((1u<<29)|(1u<<30)))return USB_PLAY_TIMEOUT;
 if(response==0x5a)return USB_PLAY_NAK;
 if(response==0x1e)return USB_PLAY_STALL;
 if(incoming)return ((response==USB_PLAY_DATA0||response==USB_PLAY_DATA1)&&n<=rx_cap)?(int)n:USB_PLAY_PROTOCOL;
 return response==0xd2?0:USB_PLAY_PROTOCOL;
}
#endif
/* UTMI linestate includes our own SOF/DATA/EOP. Sample only across two idle
 * observations, and require3ms of matching idle observations. Busy periods
 * do not reset the timer: our SOF continues even after unplug. Once attached,
 * K is traffic, never a reason to reclassify a FS device as LS. */
static unsigned root_speed(void){
 uint32_t now=usb_play_now_ms();unsigned idle=usb_play_root_idle();
 unsigned raw=usb_play_root_speed();
 if(!idle||!usb_play_root_idle())return line_stable;
 if(raw!=line_candidate){line_candidate=raw;line_since=now;}
 if((uint32_t)(now-line_since)>=3){
  if(!raw)line_stable=0;
  else if(!line_stable)line_stable=raw;
 }
 return line_stable;
}
#include "wifi_transport.inc"
static void publish_touch(void){
 usb_play_publish(STATUS,touch_status);usb_play_publish(XY,touch_xy);usb_play_publish(RAW,touch_raw);
 usb_play_publish(VIDPID,touch_vidpid);usb_play_publish(META,touch_meta);usb_play_publish(EVENT,1);
}
static void publish_diagnostics(void){
 debug_hid=(debug_hid&~0xc000u)|((touch_status&(1u<<24))?0x8000u:0)|((touch_status&(1u<<14))?0x4000u:0);
 unsigned bitmap=0,count=0;for(unsigned i=0;i<8;i++)if(devices[i].ready){bitmap|=1u<<i;count++;}
 usb_play_publish(0x02000230u,diagnostic);
 usb_play_publish(0x02000234u,bitmap|(count<<8)|(debug_errors<<16));
 usb_play_publish(0x02000238u,debug_port);
 usb_play_publish(0x0200023cu,debug_enum);
 usb_play_publish(0x02000240u,debug_hid);
 usb_play_publish(0x02000244u,touch_raw);
 usb_play_publish(0x02000248u,touch_xy);
 usb_play_publish(0x0200024cu,++debug_sequence);
}
static void update_state(void){
 diagnostic=(root_present?1u:0)|(devices[0].hub?2u:0)|(touch_owner<8?4u:0)|(midi_owner<8?8u:0)|
 (last_error?16u:0)|(wifi_owner<8?32u:0)|((uint32_t)ports<<8)|((uint32_t)last_error<<16);
 usb_play_publish(DIAG,diagnostic);publish_diagnostics();
}
uint32_t usb_play_state(void){return diagnostic;}
static void panic_usb(void){usb_play_publish(MIDI_EVENT,255);}
static void release_touch(unsigned e){
 touch_owner=8;touch_xy=touch_raw=touch_vidpid=touch_meta=0;
 touch_status=(e?USB_STATE_ERROR:USB_STATE_NO_DEVICE)|((uint32_t)(e?ERR_POLL:ERR_DISCONNECTED)<<16);publish_touch();
}
static void remove_device(unsigned slot,unsigned e){
 /* Remove descendants before their parent; siblings retain address/toggle. */
 for(unsigned i=1;i<8;i++)if(i!=slot&&devices[i].address&&devices[i].parent==slot)remove_device(i,e);
 zero(&hubs[slot],sizeof(hubs[slot]));
 if(midi_owner==slot){panic_usb();midi_owner=8;}
 if(touch_owner==slot)release_touch(e);
 if(wifi_owner==slot){wifi_owner=8;wifi_transport_reset();}
 zero(&devices[slot],sizeof(device));if(e)last_error=e;update_state();
}
static void fault_device(unsigned slot,unsigned e){
 debug_errors++;debug_enum=((unsigned)devices[slot].parent<<28)|((unsigned)devices[slot].port<<24)|(e<<16)|((unsigned)devices[slot].address<<8)|slot;
 if(slot){
  unsigned parent=devices[slot].parent,p=devices[slot].port;
  port_runtime *r=&hubs[parent].port[p];r->error=(uint8_t)e;
  r->phase=(e==USB_PLAY_TRANSFER||e==USB_PLAY_CONTROL)&&r->retries<3?3:2;
  r->since=usb_play_now_ms();
 }
 remove_device(slot,e);if(slot==0){root_blocked=1;root_retry_at=usb_play_now_ms()+1000;}
}
/* Transfer-wide deadline; duplicates never copied/advanced. SETUP DATA0,
 control data starts DATA1 and status always DATA1. */
static int control(device *d,unsigned type,unsigned request,unsigned value,unsigned index,uint8_t *dst,unsigned length){
 uint8_t setup[8]={(uint8_t)type,(uint8_t)request,(uint8_t)value,(uint8_t)(value>>8),
 (uint8_t)index,(uint8_t)(index>>8),(uint8_t)length,(uint8_t)(length>>8)};
 uint32_t start=usb_play_now_ms();int r;unsigned pid=0,received=0,toggle=1;
 for(;;){
  r=usb_play_transaction(d->address,USB_PLAY_SETUP,0,0,setup,8,packet,64,&pid);
  if(r==0)break;
  if(r==USB_PLAY_STALL||r==USB_PLAY_PROTOCOL||!root_speed()||(uint32_t)(usb_play_now_ms()-start)>=CONTROL_MS)return -1;
  usb_play_delay_ms(2);
 }
 if(length){
  if(!(type&0x80)||!dst)return -1;
  while(received<length){
   r=usb_play_transaction(d->address,USB_PLAY_IN,0,toggle,0,0,packet,64,&pid);
   if(r>=0&&pid==(toggle?USB_PLAY_DATA1:USB_PLAY_DATA0)){
    if((unsigned)r>d->ep0||(unsigned)r>length-received)return -1;
    for(int i=0;i<r;i++)dst[received+(unsigned)i]=packet[i];
    received+=(unsigned)r;toggle^=1;
    if((unsigned)r<d->ep0||received==length)break;
   }else if(r==USB_PLAY_STALL||r==USB_PLAY_PROTOCOL)return -1;
   if(!root_speed()||(uint32_t)(usb_play_now_ms()-start)>=CONTROL_MS)return -1;
   if(r<0||pid!=(toggle?USB_PLAY_DATA0:USB_PLAY_DATA1))usb_play_delay_ms(2);
  }
 }
 for(;;){
  if(length)r=usb_play_transaction(d->address,USB_PLAY_OUT,0,1,0,0,packet,64,&pid);
  else {r=usb_play_transaction(d->address,USB_PLAY_IN,0,1,0,0,packet,64,&pid);if(r>=0&&(r||pid!=USB_PLAY_DATA1))r=USB_PLAY_PROTOCOL;}
  if(r==0)return (int)received;
  if(r==USB_PLAY_STALL||r==USB_PLAY_PROTOCOL||!root_speed()||(uint32_t)(usb_play_now_ms()-start)>=CONTROL_MS)return -1;
  usb_play_delay_ms(2);
 }
}
static int read_descriptor(device *d,unsigned type,unsigned value,unsigned index,uint8_t *dst,unsigned n){return control(d,type,6,value,index,dst,n);}
static int write_request(device *d,unsigned type,unsigned request,unsigned value,unsigned index){return control(d,type,request,value,index,0,0)==0;}
static void set_endpoint(endpoint *e,const candidate *c){
 zero(e,sizeof(*e));e->number=c->ep;e->packet=c->mps;
 /* USB-MIDI1 bulk bInterval is ignored (specified reset0). It must not
  * become a polling delay even for a nonconforming nonzero descriptor.
  * HID and hub interrupt intervals retain their descriptor scheduling. */
 e->interval=(c->kind==KIND_MIDI||c->kind==KIND_SERIAL)?1:(c->interval?c->interval:1);
 e->due=usb_play_now_ms();
}
static unsigned parse_configuration(candidate *out,unsigned *used,unsigned allow_serial){
 unsigned total=le16(configuration+2),active=MAX_INTERFACES,last_ep=0,endpoint_seen=0;
 unsigned interface_count=0,declared_endpoints=0,seen_endpoints=0,have_interface=0,alt=0;
 uint8_t interfaces[32],entities[32],embedded_out[32];zero(interfaces,sizeof(interfaces));
 zero(entities,sizeof(entities));zero(embedded_out,sizeof(embedded_out));*used=0;
 if(configuration[0]!=9||configuration[1]!=2||!configuration[4]||!configuration[5])return USB_PLAY_DESCRIPTOR;
 for(unsigned p=9;p<total;){
  unsigned len=configuration[p];if(len<2||len>total-p)return USB_PLAY_DESCRIPTOR;const uint8_t *b=configuration+p;
  if(b[1]==4){
   if(len<9)return USB_PLAY_DESCRIPTOR;
   if(have_interface&&declared_endpoints!=seen_endpoints)return USB_PLAY_DESCRIPTOR;
   have_interface=1;declared_endpoints=b[4];seen_endpoints=0;alt=b[3];
   if(!alt){
    if(interfaces[b[2]>>3]&(1u<<(b[2]&7)))return USB_PLAY_DESCRIPTOR;
    interfaces[b[2]>>3]|=(uint8_t)(1u<<(b[2]&7));interface_count++;
   }
   active=MAX_INTERFACES;last_ep=0;endpoint_seen=0;
   if(b[3]==0&&(b[5]==3||(b[5]==1&&b[6]==3)||b[5]==9||(allow_serial&&b[5]==0xff))){
    if(*used==MAX_INTERFACES)return USB_PLAY_UNSUPPORTED;
    candidate *c=&out[*used];zero(c,sizeof(*c));c->iface=b[2];c->kind=b[5]==3?KIND_HID:b[5]==9?KIND_HUB:b[5]==0xff?KIND_SERIAL:KIND_MIDI;
    if((c->kind==KIND_MIDI||c->kind==KIND_HUB)&&b[7]!=0)return USB_PLAY_UNSUPPORTED;
    active=(*used)++;
    zero(entities,sizeof(entities));zero(embedded_out,sizeof(embedded_out));
   }
  }else if(b[1]==5){
   if(len<7||(b[2]&0x70)||!(b[2]&15))return USB_PLAY_DESCRIPTOR;
   if(!have_interface)return USB_PLAY_DESCRIPTOR;
   seen_endpoints++;
   last_ep=0;
   if(active<MAX_INTERFACES){
    candidate *c=&out[active];unsigned kind=b[3]&3,mps=le16(b+4),expected=(c->kind==KIND_MIDI||c->kind==KIND_SERIAL)?2:3;
    /* CH340 also has a status interrupt endpoint: it is not serial data. */
    if(c->kind==KIND_SERIAL&&kind==3){p+=len;continue;}
    if(b[2]&0x80){
     if(kind!=expected||!mps||mps>64||(expected==3&&!b[6]))return USB_PLAY_UNSUPPORTED;
     if(endpoint_seen&(1u<<(b[2]&15)))return USB_PLAY_DESCRIPTOR;
     endpoint_seen|=1u<<(b[2]&15);if(c->ep)return USB_PLAY_UNSUPPORTED;
     c->ep=b[2]&15;c->mps=(uint8_t)mps;c->interval=b[6];last_ep=1;
    }else if(c->kind==KIND_SERIAL){
     if(kind!=2||!mps||mps>64)return USB_PLAY_UNSUPPORTED;
     if(c->out_ep)return USB_PLAY_DESCRIPTOR;
     c->out_ep=b[2]&15;c->out_mps=(uint8_t)mps;
    }
   }
  }else if(b[1]==0x21&&active<MAX_INTERFACES&&out[active].kind==KIND_HID){
   if(len<6||6u+3u*b[5]>len)return USB_PLAY_DESCRIPTOR;
   for(unsigned j=0;j<b[5];j++)if(b[6+j*3]==0x22)out[active].report_len=(uint16_t)le16(b+7+j*3);
  }else if(b[1]==0x24&&active<MAX_INTERFACES&&out[active].kind==KIND_MIDI){
   if(len<3)return USB_PLAY_DESCRIPTOR;
   candidate *c=&out[active];c->cs_seen=(uint16_t)(c->cs_seen+len);
   if(b[2]==1){
    if(len!=7||le16(b+3)!=0x0100)return USB_PLAY_UNSUPPORTED;
    if(c->header)return USB_PLAY_DESCRIPTOR;
    c->header=1;c->cs_length=(uint16_t)le16(b+5);
   }else if(b[2]==2||b[2]==3){
    if(len<6||!b[4]||(b[3]!=1&&b[3]!=2))return USB_PLAY_DESCRIPTOR;
    if(b[2]==2&&len!=6)return USB_PLAY_DESCRIPTOR;
    if(b[2]==3&&(len<7||!b[5]||len!=7u+2u*b[5]))return USB_PLAY_DESCRIPTOR;
    if(entities[b[4]>>3]&(1u<<(b[4]&7)))return USB_PLAY_DESCRIPTOR;
    entities[b[4]>>3]|=(uint8_t)(1u<<(b[4]&7));
    if(b[2]==3&&b[3]==1)embedded_out[b[4]>>3]|=(uint8_t)(1u<<(b[4]&7));
   }else if(b[2]!=4)return USB_PLAY_DESCRIPTOR;
  }else if(b[1]==0x25&&active<MAX_INTERFACES&&out[active].kind==KIND_MIDI&&last_ep){
   if(len<4||b[2]!=1||!b[3]||b[3]>16||4u+b[3]!=len)return USB_PLAY_DESCRIPTOR;
   /* Only cable0 is represented downstream. Multiple virtual cables cannot
    * share note identities safely, so reject them explicitly. */
   if(b[3]!=1)return USB_PLAY_UNSUPPORTED;
   if(!(embedded_out[b[4]>>3]&(1u<<(b[4]&7))))return USB_PLAY_DESCRIPTOR;
   out[active].jacks=b[3];
  }
  if(b[1]!=4&&active<MAX_INTERFACES&&out[active].kind==KIND_MIDI)
   out[active].interface_bytes=(uint16_t)(out[active].interface_bytes+len);
  p+=len;
 }
 if((have_interface&&declared_endpoints!=seen_endpoints)||interface_count!=configuration[4])return USB_PLAY_DESCRIPTOR;
 /* Table6-2 says header+Jack/Element lengths; official AppendixB TableB-6
  * uses65 including its endpoints (37+28). Accept exactly either convention,
  * both bounded by this actual interface, never an unchecked declared span. */
 for(unsigned i=0;i<*used;i++)if(out[i].kind==KIND_MIDI&&
   out[i].cs_length!=out[i].cs_seen&&out[i].cs_length!=out[i].interface_bytes)return USB_PLAY_DESCRIPTOR;
 return USB_PLAY_OK;
}
static unsigned enumerate(unsigned slot,unsigned wanted_address){
 device *d=&devices[slot];uint8_t desc[18];candidate candidates[MAX_INTERFACES];unsigned used=0;
 d->ep0=8;d->address=0;
 if(read_descriptor(d,0x80,0x100,0,desc,8)!=8||desc[0]!=18||desc[1]!=1)return USB_PLAY_DESCRIPTOR;
 if(desc[7]!=8&&desc[7]!=16&&desc[7]!=32&&desc[7]!=64)return USB_PLAY_DESCRIPTOR;
 d->ep0=desc[7];
 if(read_descriptor(d,0x80,0x100,0,desc,18)!=18||desc[0]!=18||desc[1]!=1||!desc[17])return USB_PLAY_DESCRIPTOR;
 if(desc[4]==9&&(devices[slot].depth>=5||desc[6]))return USB_PLAY_UNSUPPORTED;
 d->vidpid=le16(desc+8)|((uint32_t)le16(desc+10)<<16);
 if(!write_request(d,0,5,wanted_address,0))return USB_PLAY_CONTROL;
 d->address=(uint8_t)wanted_address;usb_play_delay_ms(3);
 if(read_descriptor(d,0x80,0x200,0,configuration,9)!=9||configuration[0]!=9||configuration[1]!=2)return USB_PLAY_DESCRIPTOR;
 unsigned total=le16(configuration+2),value=configuration[5];
 if(total<9||total>MAX_CONFIG||!value)return USB_PLAY_DESCRIPTOR;
 if(read_descriptor(d,0x80,0x200,0,configuration,total)!=(int)total)return USB_PLAY_DESCRIPTOR;
 if(le16(configuration+2)!=total||configuration[5]!=value)return USB_PLAY_DESCRIPTOR;
 unsigned e=parse_configuration(candidates,&used,d->vidpid==0x75231a86u);if(e)return e;
 unsigned has_hub=0;for(unsigned i=0;i<used;i++)if(candidates[i].kind==KIND_HUB)has_hub++;
 if(has_hub&&(devices[slot].depth>=5||has_hub!=1||used!=1))return USB_PLAY_UNSUPPORTED;
 if(!used)return USB_PLAY_UNSUPPORTED;
 if(!write_request(d,0,9,value,0))return USB_PLAY_CONTROL;
 for(unsigned i=0;i<used;i++){
  candidate *c=&candidates[i];if(!c->ep)continue;
  if(c->kind==KIND_HUB){
   if(read_descriptor(d,0xa0,0x2900,0,desc,9)!=9||desc[0]!=9||desc[1]!=0x29||!desc[2]||desc[2]>7)return USB_PLAY_UNSUPPORTED;
   hub_runtime *h=&hubs[slot];h->ports=desc[2];h->cursor=1;
   if(!slot)ports=desc[2];
   d->hub=1;set_endpoint(&d->interrupt,c);
   /* A self-powered hub still requires its logical downstream ports enabled.
    * This is not FPGA GPIO power generation. Never remove PORT_POWER blindly. */
   for(unsigned p=1;p<=h->ports;p++)if(!write_request(d,0x23,3,8,p))return USB_PLAY_CONTROL;
   usb_play_delay_ms((unsigned)desc[5]*2u+10u);
   h->due=h->status_due=usb_play_now_ms();
  }else if(c->kind==KIND_SERIAL){
   if(wifi_owner<8||!c->out_ep)return USB_PLAY_UNSUPPORTED;
   if(!wifi_ch340_initialize(d))return USB_PLAY_CONTROL;
   set_endpoint(&d->serial_in,c);set_endpoint(&d->serial_out,c);
   d->serial_out.number=c->out_ep;d->serial_out.packet=c->out_mps;
   wifi_owner=slot;wifi_transport_reset();
  }else if(c->kind==KIND_MIDI){
   if(midi_owner<8||!c->header||!c->jacks||c->mps%4)return USB_PLAY_UNSUPPORTED;
   set_endpoint(&d->midi,c);midi_owner=slot;
  }else if(c->kind==KIND_HID){
   if(touch_owner<8)continue; /* other mouse/vendor HID interfaces can coexist */
   if(!c->report_len||c->report_len>MAX_REPORT)continue;
   if(read_descriptor(d,0x81,0x2200,c->iface,report_descriptor,c->report_len)!=(int)c->report_len)continue;
   if(!hid_parse_descriptor(report_descriptor,c->report_len,&touch_layout)||touch_layout.bits+(touch_layout.uses_id?8u:0u)>c->mps*8u)continue;
   (void)write_request(d,0x21,10,0,c->iface); /* optional SET_IDLE may STALL */
   set_endpoint(&d->hid,c);d->hid_interface=c->iface;touch_owner=slot;
   touch_xy=touch_raw=0;touch_vidpid=d->vidpid;
   touch_meta=c->ep|((uint32_t)c->interval<<8)|((uint32_t)touch_layout.id<<16)|((uint32_t)c->iface<<24);
   touch_status=USB_STATE_HID_READY|(31u<<8);publish_touch();
  }
 }
 if(!d->hub&&!d->hid.number&&!d->midi.number&&!d->serial_in.number)return USB_PLAY_UNSUPPORTED;
 d->ready=1;update_state();return USB_PLAY_OK;
}
static unsigned child_slot(unsigned parent,unsigned p){
 for(unsigned i=1;i<8;i++)if(devices[i].address&&devices[i].parent==parent&&devices[i].port==p)return i;
 return 8;
}
static unsigned free_slot(unsigned parent,unsigned p){
 if(!parent&&!devices[p].address)return p;
 for(unsigned i=1;i<8;i++)if(!devices[i].address)return i;
 return 8;
}
static int port_status(unsigned hub,unsigned p,unsigned *status,unsigned *change){
 if(control(&devices[hub],0xa3,0,0,p,packet,4)!=4)return 0;
 *status=le16(packet);*change=le16(packet+2);
 debug_port=(hub<<28)|(p<<24)|((*change&255u)<<16)|*status;
 return 1;
}
static int clear_port_changes(unsigned hub,unsigned p,unsigned changes){
 for(unsigned i=0;i<5;i++)if(changes&(1u<<i))if(!write_request(&devices[hub],0x23,1,16+i,p))return 0;
 return 1;
}
static void port_fault(unsigned hub,unsigned p,unsigned error){
 unsigned slot=child_slot(hub,p);if(slot<8)remove_device(slot,error);
 port_runtime *r=&hubs[hub].port[p];r->error=(uint8_t)error;r->since=usb_play_now_ms();
 r->phase=(error==USB_PLAY_TRANSFER||error==USB_PLAY_CONTROL)&&r->retries<3?3:2;
 last_error=error;debug_enum=(hub<<28)|(p<<24)|(error<<16);debug_errors++;
 (void)write_request(&devices[hub],0x23,1,1,p); /* disable address-zero responder */
 update_state();
}
static void scan_port(unsigned hub){
 hub_runtime *h=&hubs[hub];unsigned p=h->cursor++,status,change;if(h->cursor>h->ports)h->cursor=1;
 port_runtime *r=&h->port[p];unsigned slot=child_slot(hub,p);
 if(!port_status(hub,p,&status,&change)||!clear_port_changes(hub,p,change)){fault_device(hub,USB_PLAY_CONTROL);return;}
 if(!(status&1)){
  if(slot<8)remove_device(slot,0);
  zero(r,sizeof(*r));return;
 }
 if(change&1){if(slot<8)remove_device(slot,0);zero(r,sizeof(*r));slot=8;}
 if(status&8){port_fault(hub,p,USB_PLAY_OVERCURRENT);return;}
 if(status&(0x200u|0x400u)){if(!r->phase)port_fault(hub,p,USB_PLAY_SPEED);return;}
 if(r->phase==3){
  if((uint32_t)(usb_play_now_ms()-r->since)<1000)return;
  r->retries++;r->phase=1;r->since=usb_play_now_ms();return;
 }
 if(!r->phase){r->phase=1;r->since=usb_play_now_ms();return;}
 if(r->phase==2){if(slot<8&&devices[slot].ready&&!(status&2))port_fault(hub,p,USB_PLAY_TRANSFER);return;}
 if((uint32_t)(usb_play_now_ms()-r->since)<100)return;
 slot=free_slot(hub,p);if(slot==8){port_fault(hub,p,USB_PLAY_UNSUPPORTED);return;}
 if(!write_request(&devices[hub],0x23,3,4,p)){port_fault(hub,p,USB_PLAY_CONTROL);return;}
 uint32_t start=usb_play_now_ms();
 for(;;){
  usb_play_delay_ms(10);
  if(!port_status(hub,p,&status,&change)||!clear_port_changes(hub,p,change)){port_fault(hub,p,USB_PLAY_CONTROL);return;}
  if(!(status&1)){zero(r,sizeof(*r));return;}
  if(status&(8u|0x200u|0x400u)){port_fault(hub,p,(status&8)?USB_PLAY_OVERCURRENT:USB_PLAY_SPEED);return;}
  if(!(status&16)&&(status&2))break;
  if((uint32_t)(usb_play_now_ms()-start)>=150){port_fault(hub,p,USB_PLAY_TRANSFER);return;}
 }
 usb_play_delay_ms(10);
 devices[slot].parent=(uint8_t)hub;devices[slot].port=(uint8_t)p;devices[slot].depth=devices[hub].depth+1;
 unsigned e=enumerate(slot,slot+1);r->phase=2;
 debug_enum=(hub<<28)|(p<<24)|(e<<16)|((slot+1)<<8)|slot;
 if(e){
  /* An error before SET_ADDRESS leaves address0: disable that exact port. */
  remove_device(slot,e);port_fault(hub,p,e);
 }else {r->error=0;update_state();}
}
static void midi_packet(unsigned n){
 for(unsigned p=0;p<n;p+=4){
  unsigned cin=packet[p]&15,status=packet[p+1],a=packet[p+2],b=packet[p+3];
  /* MMIO identity is channel+note, cable0 only. Skip zero/reserved/SysEx/
   * realtime. Device FF must never be mistaken for our transport panic. */
  if(packet[p]>>4){last_error=USB_PLAY_UNSUPPORTED;continue;}
  if(cin<8||cin>14||status<0x80||status>=0xf0||(status>>4)!=cin||a>=128)continue;
  if(cin==12||cin==13)b=0;else if(b>=128)continue;
  usb_play_publish(MIDI_EVENT,status|(a<<8)|(b<<16));
 }
}
static void poll_endpoint(unsigned slot,endpoint *ep,unsigned kind){
 if(!ep->number||!due(usb_play_now_ms(),ep->due))return;
 if(kind==KIND_SERIAL&&wifi_in_used>128)return;
 ep->due=usb_play_now_ms()+ep->interval;
 unsigned pid=0;device *d=&devices[slot];
 int n=usb_play_transaction(d->address,USB_PLAY_IN,ep->number,ep->toggle,0,0,packet,64,&pid);
 if(n==USB_PLAY_NAK){ep->failures=0;return;}
 if(n==USB_PLAY_STALL){
  if(kind==KIND_MIDI)panic_usb();
  if(kind==KIND_HID){touch_status&=~((64u<<8)|(3u<<24));touch_xy=0;publish_touch();}
  if(write_request(d,2,1,0,0x80u|ep->number)){ep->toggle=ep->failures=0;return;}
  if(kind==KIND_MIDI&&midi_owner==slot)midi_owner=8;
  fault_device(slot,USB_PLAY_TRANSFER);return;
 }
 if(n<0){
  /* No valid new report was received. Keep the last sample through USB
   * retries; a timeout is not a Tip Switch release. fault_device releases
   * immediately on protocol error or the third consecutive failed poll. */
  if(n==USB_PLAY_PROTOCOL||++ep->failures>=3)fault_device(slot,USB_PLAY_TRANSFER);
  return;
 }
 ep->failures=0;
 if((unsigned)n>ep->packet||(pid!=USB_PLAY_DATA0&&pid!=USB_PLAY_DATA1)){fault_device(slot,USB_PLAY_TRANSFER);return;}
 if(pid!=(ep->toggle?USB_PLAY_DATA1:USB_PLAY_DATA0))return;
 ep->toggle^=1;
 if(kind==KIND_MIDI){
  if(n%4){fault_device(slot,USB_PLAY_TRANSFER);return;}
  midi_packet((unsigned)n);update_state();
 }else if(kind==KIND_HID){
  debug_hid=((debug_hid+0x10000u)&0xffff0000u)|((unsigned)n<<8)|(n?packet[0]:0);
  touch_sample s;int r=hid_decode(&touch_layout,packet,(unsigned)n,1024,600,&s);
  if(r<0){fault_device(slot,USB_PLAY_TRANSFER);return;}
  if(r>0){
   debug_hid|=(s.down?1u<<15:0)|(s.valid?1u<<14:0);
   touch_xy=s.x|((uint32_t)s.y<<16);touch_raw=(s.raw_x&65535u)|((s.raw_y&65535u)<<16);
   touch_status=USB_STATE_HID_READY|(63u<<8)|(s.valid?64u<<8:0)|(s.down?1u<<24:0)|(touch_button(&s)?1u<<25:0);publish_touch();
  }
 }else if(kind==KIND_SERIAL){wifi_transport_receive((unsigned)n);
 }else if(n){if(n!=1){fault_device(slot,USB_PLAY_TRANSFER);return;}hubs[slot].due=usb_play_now_ms();}
}
// Restart just the USB host/PHY, keeping the instrument CPU/audio clocks alive.
// A failed address/configuration must never leave the root port blocked forever.
static void root_restart(void){
 for(unsigned i=0;i<8;i++)remove_device(i,0);
 zero(hubs,sizeof(hubs));zero(port_phase,sizeof(port_phase));zero(port_since,sizeof(port_since));
 root_present=root_blocked=ports=last_error=0;port_cursor=1;root_since=usb_play_now_ms();
 line_stable=line_candidate=0;line_since=root_since;root_retry_at=0;
 wifi_transport_reset();
#ifndef HOST_TEST
 REG(0x0200022cu)=1; // Reset host core + PHY + both FIFOs for32 USB clocks.
 usb_play_delay_ms(1);USB(0)=0x168; // SOF off, TX flush, normal idle sampling.
#elif defined(USB_PLAY_RECOVERY_TEST)
 usb_play_controller_restart();
#endif
 update_state();
}
void usb_play_init(void){
 zero(devices,sizeof(devices));zero(hubs,sizeof(hubs));zero(port_phase,sizeof(port_phase));zero(port_since,sizeof(port_since));
 debug_sequence=debug_port=debug_enum=debug_hid=debug_errors=debug_due=0;
 root_present=root_blocked=ports=last_error=0;touch_owner=midi_owner=wifi_owner=8;wifi_transport_reset();port_cursor=1;root_since=0;
 line_stable=line_candidate=0;line_since=usb_play_now_ms();root_retry_at=0;
 touch_status=USB_STATE_NO_DEVICE;touch_xy=touch_raw=touch_vidpid=touch_meta=0;
#ifndef HOST_TEST
 REG(0x02000010u)=417;USB(0)=0x68;
#endif
 publish_touch();update_state();
}
void usb_play_poll(void){
 unsigned speed=root_speed();uint32_t now=usb_play_now_ms();
 wifi_transport_collect();wifi_transport_pump();
 if(!speed){
  if(root_present)root_restart();
  return;
 }
 if(!root_present){root_present=1;root_since=now;update_state();return;}
 if(root_blocked){
  if(last_error!=USB_PLAY_OVERCURRENT&&due(now,root_retry_at))root_restart();
  return;
 }
 if(!devices[0].ready){
  if((uint32_t)(now-root_since)<100)return;
  if(speed!=1){fault_device(0,USB_PLAY_SPEED);return;}
  usb_play_root_reset();
  if(root_speed()!=1){fault_device(0,USB_PLAY_SPEED);return;}
  unsigned e=enumerate(0,1);if(e){fault_device(0,e);return;}update_state();
 }
 /* Topology controls are bounded; each leaf keeps its independent due/toggle. */
 for(unsigned hub=0;hub<8;hub++)if(devices[hub].ready&&devices[hub].hub){
  hub_runtime *h=&hubs[hub];
  if(due(usb_play_now_ms(),h->status_due)){
   h->status_due=usb_play_now_ms()+100;int r=control(&devices[hub],0xa0,0,0,0,packet,4);
   if(r!=4){fault_device(hub,USB_PLAY_CONTROL);continue;}
   unsigned status=le16(packet),change=le16(packet+2);
   if(status&2){fault_device(hub,USB_PLAY_OVERCURRENT);continue;}
   for(unsigned i=0;i<2;i++)if(change&(1u<<i))if(!write_request(&devices[hub],0x20,1,i,0)){fault_device(hub,USB_PLAY_CONTROL);break;}
   if(!devices[hub].ready)continue;
  }
  if(due(usb_play_now_ms(),h->due)){h->due=usb_play_now_ms()+2;scan_port(hub);if(root_blocked)return;}
  if(devices[hub].ready)poll_endpoint(hub,&devices[hub].interrupt,KIND_HUB);
  if(root_blocked)return;
 }
 for(unsigned i=0;i<8;i++)if(devices[i].ready){
  poll_endpoint(i,&devices[i].hid,KIND_HID);
  if(devices[i].ready)poll_endpoint(i,&devices[i].midi,KIND_MIDI);
  if(devices[i].ready)poll_endpoint(i,&devices[i].serial_in,KIND_SERIAL);
  if(devices[i].ready)wifi_transport_send(i);
 }
 if(due(usb_play_now_ms(),debug_due)){debug_due=usb_play_now_ms()+50;publish_diagnostics();}
}
#ifndef HOST_TEST
int main(void){usb_play_init();for(;;)usb_play_poll();}
#endif
