#ifndef USB_PLAY_H
#define USB_PLAY_H
#include "touch.h"
/* Full-Speed root/cascaded hubs, <=7 ports/hub, <=8 total device slots,
 * <=5 hub tiers. One absolute HID touch/pointer + one MIDI + one CH340.
 * No split transactions, LS/HS device traffic, MIDI2 or altsetting>0.
 * init/poll never enter the main loop. Production main is excluded HOST_TEST.
 * Poll does bounded synchronous control transfers during enumeration/reset.
 */
enum { USB_PLAY_SETUP=0x2d, USB_PLAY_IN=0x69, USB_PLAY_OUT=0xe1,
       USB_PLAY_DATA0=0xc3, USB_PLAY_DATA1=0x4b };
enum { USB_PLAY_NAK=-1, USB_PLAY_STALL=-2, USB_PLAY_TIMEOUT=-3,
       USB_PLAY_PROTOCOL=-4 };
enum { USB_PLAY_OK, USB_PLAY_SPEED, USB_PLAY_DESCRIPTOR, USB_PLAY_CONTROL,
       USB_PLAY_UNSUPPORTED, USB_PLAY_TRANSFER, USB_PLAY_OVERCURRENT };
void usb_play_init(void);
void usb_play_poll(void);
/* Diagnostic: bit0 root present, bit1 hub, bit2 touch ready, bit3 MIDI ready,
 * bit4 fault, bit5 CH340/WiFi ready, bits15:8 hub ports, bits23:16 last USB_PLAY_* error. */
uint32_t usb_play_state(void);
#ifdef HOST_TEST
/* Transaction hooks replace only the physical register interface. IN returns
 * byte count [0..rx_cap], stores DATA0/1 PID; OUT/SETUP returns 0 on ACK.
 * Every call must terminate; negative values above distinguish NAK/STALL/etc.
 * root_speed returns raw line0 SE0/1 J(FS)/2 K(LS)/3 SE1; root_idle is
 * true only when RX_STAT says IDLE and !START_PEND. Common production code
 * filters these samples so SOF/EOP never masquerades as attach/detach.
 * now wraps naturally uint32.
 * publish(address,value) is a blocking, lossless MMIO store in production;
 * MIDI writes are never dropped. touch EVENT is written after all fields. */
int usb_play_transaction(unsigned address,unsigned pid,unsigned endpoint,
                         unsigned toggle,const uint8_t *tx,unsigned tx_len,
                         uint8_t *rx,unsigned rx_cap,unsigned *rx_pid);
uint32_t usb_play_now_ms(void);
void usb_play_delay_ms(unsigned ms);
unsigned usb_play_root_speed(void);
unsigned usb_play_root_idle(void);
void usb_play_root_reset(void);
void usb_play_publish(uint32_t address,uint32_t value);
#ifdef USB_PLAY_RECOVERY_TEST
void usb_play_controller_restart(void);
#endif
#endif
#endif
