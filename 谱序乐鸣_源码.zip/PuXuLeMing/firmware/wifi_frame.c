#include "wifi_frame.h"
static uint16_t crc_byte(uint16_t crc,uint8_t byte) {
    crc^=(uint16_t)byte<<8;
    for(unsigned i=0;i<8;i++)crc=(crc&0x8000u)?(uint16_t)((crc<<1)^0x1021u):(uint16_t)(crc<<1);
    return crc;
}
void wifi_frame_reset(wifi_frame *f) {f->state=0;f->length=0;f->position=0;f->crc=0xffffu;}
int wifi_frame_feed(wifi_frame *f,uint8_t b) {
    switch(f->state) {
    case 0: if(b=='W')f->state=1;break;
    case 1: f->state=b=='F'?2:b=='W'?1:0;break;
    case 2:
        if(b!=1){f->state=b=='W'?1:0;break;}
        f->crc=crc_byte(0xffffu,b);f->state=3;break;
    case 3:
        if(!b||b>64){f->state=b=='W'?1:0;break;}
        f->length=b;f->position=0;f->crc=crc_byte(f->crc,b);f->state=4;break;
    case 4:
        f->data[f->position++]=b;f->crc=crc_byte(f->crc,b);
        if(f->position==f->length)f->state=5;
        break;
    case 5: f->low=b;f->state=6;break;
    case 6:
        f->state=0;
        if(((uint16_t)b<<8|f->low)==f->crc)return 1;
        if(b=='W')f->state=1;
        break;
    default: wifi_frame_reset(f);break;
    }
    return 0;
}
