#include "touch.h"
// Descriptor-driven Digitizer parser; each Finger collection owns its fields.
// This is NOT a SCREEN_SPECIFIC_HID_PARSER. No vendor packet offsets are assumed.
// Relative mouse data, ambiguous repeated fields, long items and unsupported global
// push/pop fail closed. Report IDs and non-byte-aligned fields are supported.
static void zero(void *p, unsigned n) {uint8_t *b=p; while(n--) *b++=0;}
static int32_t sign_value(uint32_t v, unsigned n) {
    if (n && n<4 && (v & (1u<<(n*8-1)))) v |= ~((1u<<(n*8))-1u);
    return (int32_t)v;
}
static hid_field field(unsigned bit,unsigned size,int32_t min,int32_t max) {
    hid_field f; f.bit=bit; f.size=size; f.present=1; f.min=min; f.max=max; return f;
}
typedef struct {uint8_t id,num_contacts;uint16_t bits;} report_meta;
static int parse_one(const uint8_t *d,unsigned n,hid_layout *out,unsigned wanted,unsigned *reports) {
    // At most 8 report IDs, 512 input bits/report (Full-Speed interrupt packet).
    report_meta maps[8]; unsigned used=1, current=0;
    unsigned page=0,size=0,count=0,usage_n=0,usage_min=0,usage_max=0,have_range=0;
    unsigned usages[32], depth=0, app=0, app_stack[16], id_used=0;
    int finger=-1, finger_stack[16];
    int32_t min=0,max=0;
    zero(maps,sizeof(maps)); zero(out,sizeof(*out));
    for(unsigned p=0;p<n;) {
        unsigned prefix=d[p++], len=prefix&3u, type=(prefix>>2)&3u, tag=prefix>>4;
        if(prefix==0xfe) return -1;
        if(len==3) len=4;
        if(p+len>n) return -1;
        uint32_t v=0; for(unsigned i=0;i<len;i++) v|=(uint32_t)d[p+i]<<(8*i);
        p+=len;
        if(type==1) {
            switch(tag) {
            case 0:page=v;break;
            case 1:min=sign_value(v,len);break;
            case 2:max=min<0 ? sign_value(v,len):(int32_t)v;break;
            case 7:size=v;break;
            case 8:
                if(v==0 || v>255 || maps[0].bits || finger>=0) return -1;
                id_used=1;
                for(current=1;current<used;current++) if(maps[current].id==v) break;
                if(current==used) {if(used==8) return -1; maps[used++].id=v;}
                break;
            case 9:count=v;break;
            case 10:case 11:return -1; // explicit unsupported push/pop
            default:break;
            }
        } else if(type==2) {
            if(tag==0) {if(usage_n==32) return -1; usages[usage_n++]=len==4?v:(page<<16)|v;}
            else if(tag==1) {usage_min=len==4?v:(page<<16)|v;have_range=1;}
            else if(tag==2) usage_max=len==4?v:(page<<16)|v;
        } else if(type==0) {
            report_meta *m=&maps[current];
            if(tag==10) {
                if(depth==16) return -1;
                app_stack[depth]=app;finger_stack[depth++]=finger;
                if(v==1) app=usage_n?usages[0]:0;
                if((app==0x000d0004u || app==0x000d0005u) &&
                   usage_n && usages[0]==0x000d0022u) {
                    if(finger>=0 || m->num_contacts==HID_MAX_CONTACTS)return -1;
                    finger=m->num_contacts++;
                }
            } else if(tag==12) {
                if(!depth) return -1;
                app=app_stack[--depth];finger=finger_stack[depth];
            } else if(tag==8) {
                if(size>32 || count>512 || size*count+m->bits>512) return -1;
                if(app==0x000d0004u || app==0x000d0005u || app==0x000d0002u || app==0x00010002u || app==0x00010001u) {
                    for(unsigned i=0;i<count;i++) {
                        unsigned u=i<usage_n?usages[i]:(have_range && usage_min+i<=usage_max?usage_min+i:0);
                        unsigned bit=m->bits+size*i;
                        if((v&3u)!=2u || !size) continue; // data,variable only
                        hid_contact *c=&out->contacts[finger>=0?(unsigned)finger:0];
                        hid_field *f=0;
                        if(u==0x000d0042u) f=&c->tip;
                        if((app==0x00010002u || app==0x00010001u) && u==0x00090001u) f=&c->tip;
                        if(u==0x000d0047u) f=&c->valid; // Confidence
                        if(u==0x000d0032u) f=&c->in_range; // independent In Range
                        if(u==0x000d0051u) f=&c->contact;
                        if(u==0x00010030u && !(v&4u)) f=&c->x;
                        if(u==0x00010031u && !(v&4u)) f=&c->y;
                        if(u==0x000d0054u && finger<0)f=&out->contact_count;
                        if(f) {
                            if(current==wanted) {
                                if(f->present)return -1;
                                *f=field(bit,size,min,max);
                            }
                            if(f!=&out->contact_count && !m->num_contacts)m->num_contacts=1;
                        }
                    }
                }
                m->bits+=size*count;
            }
            usage_n=0;have_range=0;usage_min=usage_max=0;
        }
    }
    if(depth) return -1;
    *reports=used;
    report_meta *m=&maps[wanted];
    out->id=m->id;out->bits=m->bits;out->num_contacts=m->num_contacts;
    unsigned valid=m->num_contacts!=0 && m->bits+(id_used?8u:0u)<=512;
    for(unsigned k=0;k<m->num_contacts && valid;k++) {
        hid_contact *c=&out->contacts[k];
        valid=c->tip.present && c->x.present && c->y.present &&
            c->x.min>=0 && c->y.min>=0 && c->x.size<=16 && c->y.size<=16 &&
            c->x.max>c->x.min && c->y.max>c->y.min &&
            (uint32_t)c->x.max<(1u<<c->x.size) && (uint32_t)c->y.max<(1u<<c->y.size);
    }
    if(valid){out->uses_id=id_used;return 1;}
    return 0;
}
int hid_parse_descriptor(const uint8_t *d,unsigned n,hid_layout *out) {
    // Every discovered report is fully checked, including malformed reports
    // after the first usable one. Keep the same first-valid selection order.
    hid_layout scratch;unsigned reports=1,found=0;
    zero(out,sizeof(*out));
    for(unsigned wanted=0;wanted<reports;wanted++) {
        int state=parse_one(d,n,&scratch,wanted,&reports);
        if(state<0){zero(out,sizeof(*out));return 0;}
        if(state&&!found){*out=scratch;found=1;}
    }
    return (int)found;
}
static uint32_t extract(const uint8_t *r, hid_field f) {
    uint32_t v=0; for(unsigned i=0;i<f.size;i++)
        v|=((uint32_t)((r[(f.bit+i)>>3]>>((f.bit+i)&7))&1u))<<i;
    return v;
}
static unsigned normalize(uint32_t v,hid_field f,unsigned pixels) {
    if(v<(uint32_t)f.min) v=f.min;
    if(v>(uint32_t)f.max) v=f.max;
    return (v-(uint32_t)f.min)*(pixels-1)/(uint32_t)(f.max-f.min);
}
int hid_decode(const hid_layout *m,const uint8_t *r,unsigned n,unsigned w,unsigned h,touch_sample *s) {
    zero(s,sizeof(*s));
    if(!w||!h||w>2048||h>2048) return -1;
    if(!n)return 0; // Legal zero-length interrupt data carries no sample.
    if(m->uses_id) {if(!n||r[0]!=m->id) return 0;r++;n--;}
    if(!m->num_contacts || m->num_contacts>HID_MAX_CONTACTS || n*8<m->bits)return -1;
    // Select the first active, valid contact, even when slot0 is inactive.
    // If every Tip Switch is clear, publish release. Contact Count alone is
    // not a release signal: in hybrid reports zero may indicate continuation.
    unsigned selected=0,found=0;
    for(unsigned i=0;i<m->num_contacts;i++) {
        const hid_contact *c=&m->contacts[i];
        if(!c->tip.present||!c->x.present||!c->y.present)return -1;
        if(extract(r,c->tip) && (!c->valid.present || extract(r,c->valid)) &&
           (!c->in_range.present || extract(r,c->in_range))) {
            selected=i;found=1;break;
        }
    }
    const hid_contact *c=&m->contacts[selected];
    s->raw_x=extract(r,c->x);s->raw_y=extract(r,c->y);
    s->down=found;
    s->valid=found || !extract(r,c->tip);
    s->x=TOUCH_SWAP_XY?normalize(s->raw_y,c->y,w):normalize(s->raw_x,c->x,w);
    s->y=TOUCH_SWAP_XY?normalize(s->raw_x,c->x,h):normalize(s->raw_y,c->y,h);
    if(TOUCH_FLIP_X)s->x=w-1-s->x;
    if(TOUCH_FLIP_Y)s->y=h-1-s->y;
    return 1;
}
int touch_button(const touch_sample *s) {
    return s->valid&&s->down&&s->x>=350&&s->x<674&&s->y>=220&&s->y<380;
}
