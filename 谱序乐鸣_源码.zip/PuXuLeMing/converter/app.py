"""Audio to score converter with a small Windows-friendly Tkinter UI.

The application has two transcription backends:

* Basic Pitch, when it is installed in the current interpreter or in the
  project's optional audio-analysis environment.
* A dependency-light monophonic autocorrelation detector.  It is deliberately
  kept as a fallback so the UI still works on a fresh Python installation.

The FPGA export follows ProjectFinalWIFI's version=1 score JSON contract:
absolute millisecond event times, MIDI notes, note-on/note-off state and MIDI
velocity.  The export is limited to four simultaneous voices and 512 events.
"""

from __future__ import annotations

import argparse
import csv
import io
import json
import math
import os
import queue
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import threading
import wave
import xml.etree.ElementTree as ET
from dataclasses import dataclass, replace
from datetime import date
from pathlib import Path
from typing import Callable, Iterable, Optional, Sequence

try:
    import numpy as np
except ImportError:  # pragma: no cover - the GUI reports this at run time.
    np = None


APP_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = APP_DIR.parent
DEFAULT_SAMPLE_RATE = 16_000
DEFAULT_MAX_SECONDS = 180.0
MAX_P8SONG_EVENTS = 512
MAX_P8SONG_NOTES = MAX_P8SONG_EVENTS // 2
SUPPORTED_AUDIO = {
    ".wav",
    ".mp3",
    ".flac",
    ".m4a",
    ".aac",
    ".ogg",
    ".opus",
    ".wma",
    ".aiff",
    ".aif",
}


class ConversionError(RuntimeError):
    """A user-facing conversion error."""


@dataclass
class Note:
    start: float
    end: float
    midi: int
    velocity: int = 90
    confidence: float = 0.5

    @property
    def duration(self) -> float:
        return max(0.0, self.end - self.start)


@dataclass
class AudioBuffer:
    samples: "np.ndarray"
    sample_rate: int
    duration: float
    envelope: "np.ndarray"


@dataclass
class Settings:
    backend: str = "auto"
    bpm: Optional[float] = 120.0
    grid: str = "1/8"
    max_voices: int = 4
    min_midi: int = 36
    max_midi: int = 96
    max_seconds: Optional[float] = DEFAULT_MAX_SECONDS
    onset_threshold: float = 0.4
    frame_threshold: float = 0.25

    def validate(self) -> None:
        if self.backend not in ("auto", "basic_pitch", "fallback"):
            raise ConversionError("识别引擎无效")
        if self.bpm is not None and not 20 <= self.bpm <= 300:
            raise ConversionError("BPM 应在 20 到 300 之间")
        if self.grid not in ("不量化", "1/4", "1/8", "1/16"):
            raise ConversionError("节奏量化选项无效")
        if not isinstance(self.max_voices, int) or not 1 <= self.max_voices <= 4:
            raise ConversionError("同时声部应为 1 到 4")
        if not all(isinstance(value, int) for value in (self.min_midi, self.max_midi)) or not 0 <= self.min_midi <= self.max_midi <= 127:
            raise ConversionError("MIDI 音高范围应为 0 到 127，且最低音不高于最高音")
        if self.max_seconds is not None and (not math.isfinite(self.max_seconds) or self.max_seconds < 0):
            raise ConversionError("最大时长应为有限的非负数，0 表示完整音频")
        if not all(math.isfinite(value) and 0 <= value <= 1 for value in (self.onset_threshold, self.frame_threshold)):
            raise ConversionError("识别阈值应在 0 到 1 之间")


@dataclass
class ConversionResult:
    source: Path
    title: str
    backend: str
    audio: AudioBuffer
    notes: list[Note]
    events: list[dict]
    outputs: list[Path]
    warnings: list[str]


def _require_numpy() -> None:
    if np is None:
        raise ConversionError(
            "缺少 numpy。请在命令行执行：python -m pip install numpy"
        )


def midi_name(midi: int) -> str:
    names = ("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    midi = int(max(0, min(127, midi)))
    return f"{names[midi % 12]}{midi // 12 - 1}"


def safe_title(value: str) -> str:
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", value).strip(" .")
    return value[:80] or "未命名曲谱"


def find_ffmpeg() -> Optional[str]:
    """Find ffmpeg on PATH or in the common winget installation location."""

    path = shutil.which("ffmpeg")
    if path:
        return path

    candidates: list[Path] = []
    local_app_data = os.environ.get("LOCALAPPDATA")
    if local_app_data:
        root = Path(local_app_data) / "Microsoft" / "WinGet" / "Packages"
        candidates.extend(root.glob("yt-dlp.FFmpeg_*/*/bin/ffmpeg.exe"))
        candidates.extend(root.glob("*FFmpeg*/*/bin/ffmpeg.exe"))
    candidates.extend(
        [
        ]
    )
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate)
    return None


def _pcm_to_float(raw: bytes, channels: int, sample_width: int, count: int) -> "np.ndarray":
    _require_numpy()
    if sample_width == 1:
        values = np.frombuffer(raw, dtype=np.uint8).astype(np.float32)
        values = (values - 128.0) / 128.0
    elif sample_width == 2:
        values = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0
    elif sample_width == 3:
        bytes_view = np.frombuffer(raw, dtype=np.uint8).reshape(-1, 3)
        values_i32 = (
            bytes_view[:, 0].astype(np.int32)
            | (bytes_view[:, 1].astype(np.int32) << 8)
            | (bytes_view[:, 2].astype(np.int32) << 16)
        )
        values_i32 = np.where(values_i32 & 0x800000, values_i32 - 0x1000000, values_i32)
        values = values_i32.astype(np.float32) / 8388608.0
    elif sample_width == 4:
        values = np.frombuffer(raw, dtype="<i4").astype(np.float32) / 2147483648.0
    else:
        raise ConversionError(f"不支持的 PCM 位宽：{sample_width * 8} bit")
    if channels > 1:
        usable = (len(values) // channels) * channels
        values = values[:usable].reshape(-1, channels).mean(axis=1)
    return np.asarray(values[:count if channels == 1 else len(values)], dtype=np.float32)


def read_wav_bytes(data: bytes) -> tuple["np.ndarray", int]:
    _require_numpy()
    try:
        with wave.open(io.BytesIO(data), "rb") as wav:
            channels = wav.getnchannels()
            sample_rate = wav.getframerate()
            sample_width = wav.getsampwidth()
            frames = wav.getnframes()
            raw = wav.readframes(frames)
    except (wave.Error, EOFError) as exc:
        raise ConversionError(f"无法读取 WAV 音频：{exc}") from exc
    values = _pcm_to_float(raw, channels, sample_width, frames * channels)
    if values.size == 0:
        raise ConversionError("音频没有可读取的采样数据")
    peak = float(np.max(np.abs(values)))
    if peak > 1.05:
        values = values / peak
    return values, int(sample_rate)


def _audio_envelope(samples: "np.ndarray", points: int = 1200) -> "np.ndarray":
    _require_numpy()
    if samples.size == 0:
        return np.zeros(points, dtype=np.float32)
    points = max(100, min(points, samples.size))
    edges = np.linspace(0, samples.size, points + 1, dtype=np.int64)
    result = np.zeros(points, dtype=np.float32)
    for i in range(points):
        part = samples[edges[i] : max(edges[i + 1], edges[i] + 1)]
        result[i] = float(np.max(np.abs(part))) if part.size else 0.0
    peak = float(np.max(result))
    return result / peak if peak > 0 else result


def decode_audio(path: Path, max_seconds: Optional[float]) -> AudioBuffer:
    """Decode any FFmpeg-supported file to mono 16 kHz PCM."""

    _require_numpy()
    ffmpeg = find_ffmpeg()
    data: bytes
    if ffmpeg:
        command = [
            ffmpeg,
            "-hide_banner",
            "-loglevel",
            "error",
            "-i",
            str(path),
        ]
        if max_seconds and max_seconds > 0:
            command.extend(["-t", f"{max_seconds:.3f}"])
        command.extend(
            [
                "-vn",
                "-ac",
                "1",
                "-ar",
                str(DEFAULT_SAMPLE_RATE),
                "-f",
                "wav",
                "-acodec",
                "pcm_s16le",
                "pipe:1",
            ]
        )
        try:
            completed = subprocess.run(
                command,
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=max(120.0, (max_seconds or 180.0) + 90.0),
            )
        except FileNotFoundError as exc:
            raise ConversionError("找不到 FFmpeg，请安装 FFmpeg 并加入 PATH") from exc
        except subprocess.CalledProcessError as exc:
            detail = exc.stderr.decode("utf-8", errors="replace").strip()
            raise ConversionError(f"FFmpeg 无法读取该音频：{detail[-500:]}") from exc
        except subprocess.TimeoutExpired as exc:
            raise ConversionError("音频解码超时，请先裁剪音频或缩短最大时长") from exc
        data = completed.stdout
    elif path.suffix.lower() == ".wav":
        try:
            data = path.read_bytes()
        except OSError as exc:
            raise ConversionError(f"无法读取文件：{exc}") from exc
    else:
        raise ConversionError("读取 MP3、FLAC、M4A 等格式需要 FFmpeg；当前只找到 WAV 兜底读取")

    samples, sample_rate = read_wav_bytes(data)
    if max_seconds and max_seconds > 0:
        samples = samples[:max(1, int(max_seconds * sample_rate))]
    duration = len(samples) / sample_rate
    return AudioBuffer(samples, sample_rate, duration, _audio_envelope(samples))


def _basic_pitch_python() -> Optional[str]:
    """Return an interpreter that can import basic_pitch, if available."""

    try:
        import importlib.util

        if importlib.util.find_spec("basic_pitch"):
            return sys.executable
    except (ImportError, ModuleNotFoundError):
        pass

    candidates = [
        PROJECT_ROOT / "_tools" / "audio_analysis" / "Scripts" / "python.exe",
        PROJECT_ROOT / "_tools" / "audio_analysis" / "bin" / "python",
    ]
    for candidate in candidates:
        if candidate.is_file():
            try:
                check = subprocess.run(
                    [str(candidate), "-c", "import basic_pitch"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    timeout=15,
                )
                if check.returncode == 0:
                    return str(candidate)
            except (OSError, subprocess.SubprocessError):
                continue
    return None


def _parse_basic_pitch_event(item) -> Optional[Note]:
    """Normalize Basic Pitch's tuple/dict event variants."""

    start = end = midi = confidence = None
    if isinstance(item, dict):
        start = item.get("start", item.get("start_time"))
        end = item.get("end", item.get("end_time"))
        midi = item.get("note", item.get("pitch", item.get("midi")))
        confidence = item.get("confidence", item.get("amplitude", item.get("probability", 0.5)))
    elif isinstance(item, (tuple, list)) and len(item) >= 4:
        start, end, midi = item[:3]
        # Basic Pitch 0.4 returns (start, end, midi, amplitude, pitch_bends).
        # Older releases returned only four values, with amplitude/confidence in slot 4.
        confidence = item[3]
    if start is None or end is None or midi is None:
        return None
    try:
        start_f = float(start)
        end_f = float(end)
        midi_i = int(round(float(midi)))
        confidence_f = float(confidence)
    except (TypeError, ValueError, OverflowError):
        return None
    if not all(math.isfinite(value) for value in (start_f, end_f, confidence_f)) or start_f < 0 or end_f <= start_f or not 0 <= midi_i <= 127:
        return None
    if confidence_f > 1.0:
        confidence_f = confidence_f / 127.0
    confidence_f = max(0.0, min(1.0, confidence_f))
    velocity = int(round(25 + 102 * confidence_f))
    return Note(start_f, end_f, midi_i, max(1, min(127, velocity)), confidence_f)


def _basic_pitch_worker(input_path: str, output_path: str, settings: Settings) -> int:
    """Run in a helper interpreter so optional ML dependencies stay isolated."""

    try:
        from basic_pitch.inference import predict
    except ImportError as exc:
        print(f"Basic Pitch 不可用：{exc}", file=sys.stderr)
        return 2
    try:
        _output, _midi, events = predict(
            input_path,
            onset_threshold=settings.onset_threshold,
            frame_threshold=settings.frame_threshold,
            minimum_note_length=80,
            minimum_frequency=440.0 * 2 ** ((settings.min_midi - 69) / 12),
            maximum_frequency=440.0 * 2 ** ((settings.max_midi + 1 - 69) / 12),
        )
        notes = []
        for item in events:
            note = _parse_basic_pitch_event(item)
            if note:
                notes.append(note.__dict__)
        Path(output_path).write_text(
            json.dumps(notes, ensure_ascii=False), encoding="utf-8"
        )
        return 0
    except Exception as exc:  # pragma: no cover - depends on optional model runtime.
        print(f"Basic Pitch 转谱失败：{exc}", file=sys.stderr)
        return 3


def transcribe_basic_pitch(path: Path, audio: AudioBuffer, settings: Settings) -> list[Note]:
    python_exe = _basic_pitch_python()
    if not python_exe:
        raise ConversionError(
            "没有找到 Basic Pitch。可选安装：python -m pip install -r requirements-optional.txt"
        )
    with tempfile.TemporaryDirectory(prefix="audio_to_score_") as temp_dir:
        wav_path = Path(temp_dir) / "audio_for_basic_pitch.wav"
        output = Path(temp_dir) / "notes.json"
        clipped = np.clip(audio.samples, -1.0, 1.0)
        pcm = (clipped * 32767.0).astype("<i2", copy=False).tobytes()
        with wave.open(str(wav_path), "wb") as wav:
            wav.setnchannels(1)
            wav.setsampwidth(2)
            wav.setframerate(audio.sample_rate)
            wav.writeframes(pcm)
        command = [
            python_exe,
            str(Path(__file__).resolve()),
            "--basic-pitch-worker",
            str(wav_path),
            str(output),
            "--min-midi",
            str(settings.min_midi),
            "--max-midi",
            str(settings.max_midi),
            "--onset-threshold",
            str(settings.onset_threshold),
            "--frame-threshold",
            str(settings.frame_threshold),
        ]
        try:
            completed = subprocess.run(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=max(300.0, audio.duration * 8.0),
            )
        except subprocess.TimeoutExpired as exc:
            raise ConversionError("Basic Pitch 转谱超时，请缩短音频或使用单旋律兜底模式") from exc
        if completed.returncode != 0 or not output.is_file():
            detail = (completed.stderr or completed.stdout).strip()
            raise ConversionError(detail[-1000:] or "Basic Pitch 没有返回转谱结果")
        try:
            raw = json.loads(output.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ConversionError(f"读取 Basic Pitch 结果失败：{exc}") from exc
    return [Note(**item) for item in raw if isinstance(item, dict)]


def _autocorrelation_pitch(frame: "np.ndarray", sample_rate: int, min_midi: int, max_midi: int):
    """Estimate one fundamental frequency using FFT autocorrelation."""

    _require_numpy()
    if frame.size == 0:
        return None
    frame = frame.astype(np.float32, copy=False)
    frame = frame - float(np.mean(frame))
    energy = float(np.sqrt(np.mean(frame * frame)))
    if energy < 1e-5:
        return None
    window = np.hanning(frame.size).astype(np.float32)
    framed = frame * window
    n_fft = 1
    while n_fft < frame.size * 2:
        n_fft <<= 1
    spectrum = np.fft.rfft(framed, n=n_fft)
    autocorr = np.fft.irfft(np.abs(spectrum) ** 2, n=n_fft)[: frame.size]
    if autocorr[0] <= 0:
        return None
    autocorr = autocorr / autocorr[0]
    f_min = 440.0 * 2 ** ((min_midi - 69) / 12)
    f_max = 440.0 * 2 ** ((max_midi + 1 - 69) / 12)
    min_lag = max(2, int(sample_rate / f_max))
    max_lag = min(frame.size - 2, int(sample_rate / f_min))
    if max_lag <= min_lag:
        return None
    values = autocorr[min_lag : max_lag + 1]
    lag = min_lag + int(np.argmax(values))
    confidence = float(autocorr[lag])
    if confidence < 0.22:
        return None
    # Parabolic interpolation makes the result less jumpy between MIDI notes.
    if 1 <= lag < len(autocorr) - 1:
        left, center, right = autocorr[lag - 1], autocorr[lag], autocorr[lag + 1]
        denominator = left - 2 * center + right
        if abs(float(denominator)) > 1e-8:
            lag = lag + 0.5 * (left - right) / denominator
    frequency = sample_rate / max(1e-6, float(lag))
    midi = 69.0 + 12.0 * math.log2(max(1e-6, frequency) / 440.0)
    if midi < min_midi - 1 or midi > max_midi + 1:
        return None
    return midi, confidence, energy


def transcribe_monophonic(audio: AudioBuffer, settings: Settings) -> list[Note]:
    """Fallback pitch tracker for a single prominent melody line."""

    _require_numpy()
    samples = audio.samples
    sample_rate = audio.sample_rate
    window_size = 2048 if sample_rate >= 12_000 else 1024
    hop = max(128, window_size // 8)
    frame_count = max(1, int(math.ceil(max(0, len(samples) - 1) / hop)))
    raw_pitch = np.full(frame_count, np.nan, dtype=np.float32)
    raw_conf = np.zeros(frame_count, dtype=np.float32)
    raw_energy = np.zeros(frame_count, dtype=np.float32)

    for index in range(frame_count):
        start = index * hop
        frame = samples[start : start + window_size]
        if frame.size < window_size:
            frame = np.pad(frame, (0, window_size - frame.size))
        result = _autocorrelation_pitch(frame, sample_rate, settings.min_midi, settings.max_midi)
        if result:
            raw_pitch[index], raw_conf[index], raw_energy[index] = result

    nonzero = raw_energy[raw_energy > 0]
    if nonzero.size:
        noise = float(np.percentile(nonzero, 15))
        # A sustained note may fill the entire clip. Its lower percentile is
        # then signal, so it must not raise the gate above the note itself.
        signal_level = float(np.percentile(nonzero, 95))
        energy_floor = max(0.006, min(noise * 1.45, signal_level * 0.5))
    else:
        energy_floor = 0.006
    valid = np.isfinite(raw_pitch) & (raw_conf >= 0.28) & (raw_energy >= energy_floor)
    pitch_int = np.full(frame_count, -1, dtype=np.int32)
    pitch_int[valid] = np.rint(raw_pitch[valid]).astype(np.int32)

    # Fill tiny tracker gaps and smooth single-frame pitch flips.
    for index in range(1, frame_count - 1):
        if pitch_int[index] < 0 and pitch_int[index - 1] >= 0 and pitch_int[index + 1] == pitch_int[index - 1]:
            pitch_int[index] = pitch_int[index - 1]
        elif pitch_int[index - 1] >= 0 and pitch_int[index + 1] == pitch_int[index - 1] and abs(pitch_int[index] - pitch_int[index - 1]) <= 2:
            pitch_int[index] = pitch_int[index - 1]

    notes: list[Note] = []
    start_index: Optional[int] = None
    current_pitch = -1
    for index in range(frame_count + 1):
        pitch = int(pitch_int[index]) if index < frame_count else -1
        if pitch >= 0 and start_index is None:
            start_index, current_pitch = index, pitch
            continue
        if pitch >= 0 and start_index is not None and abs(pitch - current_pitch) <= 1:
            # Keep the first stable pitch for a semitone of detector jitter.
            continue
        if start_index is not None:
            # Each estimate describes the centre of its analysis window.
            start = min(audio.duration, (start_index * hop + window_size / 2) / sample_rate)
            end = min(audio.duration, (index * hop + window_size / 2) / sample_rate)
            if end - start >= 0.075:
                segment = slice(start_index, min(index, frame_count))
                confidence = float(np.mean(raw_conf[segment])) if index > start_index else 0.35
                energy = float(np.mean(raw_energy[segment])) if index > start_index else energy_floor
                notes.append(Note(start, end, current_pitch, 90, confidence))
            start_index = index if pitch >= 0 else None
            current_pitch = pitch

    if not notes:
        return []
    energies = np.asarray([raw_energy[i] for i in range(frame_count) if raw_energy[i] > 0])
    low = float(np.percentile(energies, 10)) if energies.size else 0.0
    high = float(np.percentile(energies, 95)) if energies.size else 1.0
    span = max(1e-6, high - low)
    for note in notes:
        start_i = max(0, int(note.start * sample_rate / hop))
        end_i = min(frame_count, int(math.ceil(note.end * sample_rate / hop)))
        level = float(np.mean(raw_energy[start_i:end_i])) if end_i > start_i else low
        note.velocity = max(1, min(127, int(round(25 + 102 * (level - low) / span))))
    return notes


def merge_same_pitch(notes: Iterable[Note], gap: float = 0.035) -> list[Note]:
    grouped: dict[int, list[Note]] = {}
    for note in notes:
        if note.end <= note.start:
            continue
        grouped.setdefault(int(note.midi), []).append(note)
    merged: list[Note] = []
    for midi, pitch_notes in grouped.items():
        pitch_notes.sort(key=lambda n: (n.start, n.end))
        current: Optional[Note] = None
        for note in pitch_notes:
            if current is None:
                current = replace(note, midi=midi)
            elif note.start <= current.end + gap:
                current.end = max(current.end, note.end)
                current.velocity = max(current.velocity, note.velocity)
                current.confidence = max(current.confidence, note.confidence)
            else:
                merged.append(current)
                current = replace(note, midi=midi)
        if current is not None:
            merged.append(current)
    return sorted(merged, key=lambda n: (n.start, n.midi))


def quantize_notes(notes: Sequence[Note], bpm: Optional[float], grid: str) -> list[Note]:
    if not bpm or bpm <= 0 or grid == "不量化":
        return list(notes)
    fractions = {"1/4": 1.0, "1/8": 0.5, "1/16": 0.25}
    fraction = fractions.get(grid)
    if fraction is None:
        return list(notes)
    step = 60.0 / bpm * fraction
    quantized: list[Note] = []
    for note in notes:
        start = max(0.0, round(note.start / step) * step)
        end = max(start + step * 0.5, round(note.end / step) * step)
        quantized.append(replace(note, start=start, end=end))
    return quantized


def limit_polyphony(notes: Sequence[Note], max_voices: int) -> list[Note]:
    """Clip overlapping candidates to a deterministic number of voices."""

    max_voices = max(1, min(4, int(max_voices)))
    notes = merge_same_pitch(notes)
    if len(notes) <= max_voices:
        return notes
    boundaries = sorted({point for note in notes for point in (note.start, note.end)})
    slices: dict[int, list[Note]] = {}
    for start, end in zip(boundaries, boundaries[1:]):
        if end - start < 1e-5:
            continue
        active = [note for note in notes if note.start < end - 1e-8 and note.end > start + 1e-8]
        active.sort(
            key=lambda n: (n.confidence * (0.55 + min(1.5, n.duration)), n.velocity, n.midi),
            reverse=True,
        )
        for note in active[:max_voices]:
            slices.setdefault(note.midi, []).append(
                Note(start, end, note.midi, note.velocity, note.confidence)
            )
    clipped: list[Note] = []
    for midi, parts in slices.items():
        parts.sort(key=lambda n: n.start)
        current: Optional[Note] = None
        for part in parts:
            if current is None:
                current = part
            elif part.start <= current.end + 1e-8:
                current.end = max(current.end, part.end)
                current.velocity = max(current.velocity, part.velocity)
                current.confidence = max(current.confidence, part.confidence)
            else:
                clipped.append(current)
                current = part
        if current is not None:
            clipped.append(current)
    # Filling a gap here would reintroduce notes that lost a voice slot.
    return sorted(merge_same_pitch(clipped, gap=0.0), key=lambda n: (n.start, n.midi))


def _event_sort_key(event: dict) -> tuple[float, int, int]:
    # Note-off comes before note-on at an equal time, which allows an immediate
    # same-pitch retrigger and keeps the FPGA validator's active set consistent.
    return (float(event["ms"]), 0 if not event["on"] else 1, int(event["note"]))


def notes_to_events(notes: Sequence[Note], duration: Optional[float] = None) -> list[dict]:
    events: list[dict] = []
    for note in notes:
        start_ms = max(0, int(round(note.start * 1000)))
        end_ms = int(round(note.end * 1000))
        if end_ms <= start_ms:
            continue
        events.append(
            {"ms": start_ms, "note": int(note.midi), "on": True, "velocity": int(max(1, min(127, note.velocity)))}
        )
        events.append({"ms": end_ms, "note": int(note.midi), "on": False, "velocity": 0})
    events.sort(key=_event_sort_key)
    return events


def _vlq(value: int) -> bytes:
    value = max(0, int(value))
    buffer = value & 0x7F
    result = bytearray()
    while value > 0x7F:
        value >>= 7
        buffer = (buffer << 8) | ((value & 0x7F) | 0x80)
    while True:
        result.append(buffer & 0xFF)
        if buffer & 0x80:
            buffer >>= 8
        else:
            break
    return bytes(result)


def write_midi(path: Path, notes: Sequence[Note], bpm: Optional[float], title: str) -> None:
    ppq = 480
    tempo = int(round(60_000_000 / max(1.0, bpm or 120.0)))
    title_bytes = title.encode("utf-8")
    midi_events: list[tuple[int, int, bytes]] = [
        (0, 0, b"\xff\x03" + _vlq(len(title_bytes)) + title_bytes),
        (0, 0, b"\xff\x51\x03" + tempo.to_bytes(3, "big")),
        (0, 0, b"\xff\x58\x04\x04\x02\x18\x08"),
    ]
    for note in notes:
        start_tick = max(0, int(round(note.start * (bpm or 120.0) * ppq / 60.0)))
        end_tick = max(start_tick + 1, int(round(note.end * (bpm or 120.0) * ppq / 60.0)))
        velocity = max(1, min(127, int(note.velocity)))
        midi_events.append((start_tick, 1, bytes([0x90, note.midi & 0x7F, velocity])))
        midi_events.append((end_tick, 0, bytes([0x80, note.midi & 0x7F, 0])))
    midi_events.sort(key=lambda item: (item[0], item[1]))
    track = bytearray()
    previous = 0
    for tick, _order, message in midi_events:
        track.extend(_vlq(tick - previous))
        track.extend(message)
        previous = tick
    track.extend(b"\x00\xff\x2f\x00")
    header = b"MThd" + struct.pack(">IHHH", 6, 0, 1, ppq)
    body = b"MTrk" + struct.pack(">I", len(track)) + track
    path.write_bytes(header + body)


def write_p8song(path: Path, title: str, events: Sequence[dict], bpm: Optional[float]) -> None:
    duration = max((int(event["ms"]) for event in events), default=0)
    payload = {
        "version": 1,
        "title": title,
        "tempo": int(round(bpm)) if bpm else None,
        "duration": duration,
        "events": list(events),
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_csv(path: Path, notes: Sequence[Note]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["start_ms", "end_ms", "midi", "note", "velocity", "confidence"])
        for note in notes:
            writer.writerow(
                [
                    int(round(note.start * 1000)),
                    int(round(note.end * 1000)),
                    note.midi,
                    midi_name(note.midi),
                    note.velocity,
                    f"{note.confidence:.3f}",
                ]
            )


def _duration_tokens(ticks: int) -> list[tuple[int, str, bool]]:
    """Express a duration using common dotted/undotted MusicXML values."""

    values = [
        (3840, "whole", False),
        (2880, "half", True),
        (1920, "half", False),
        (1440, "quarter", True),
        (960, "quarter", False),
        (720, "eighth", True),
        (480, "eighth", False),
        (360, "16th", True),
        (240, "16th", False),
        (120, "32nd", False),
    ]
    remaining = max(120, int(ticks))
    result: list[tuple[int, str, bool]] = []
    for size, name, dotted in values:
        while remaining >= size:
            result.append((size, name, dotted))
            remaining -= size
    if remaining:
        result.append((remaining, "32nd", False))
    return result


def _xml_note_duration(parent, ticks: int, *, midi: Optional[int] = None, rest: bool = False, ties=()) -> None:
    """Append one or more MusicXML note fragments whose durations sum to ticks."""

    fragments = _duration_tokens(ticks)
    for index, (length, note_type, dotted) in enumerate(fragments):
        note_el = ET.SubElement(parent, "note")
        if rest:
            ET.SubElement(note_el, "rest")
        else:
            pitch_el = ET.SubElement(note_el, "pitch")
            note_names = (("C", 0), ("C", 1), ("D", 0), ("D", 1), ("E", 0), ("F", 0), ("F", 1), ("G", 0), ("G", 1), ("A", 0), ("A", 1), ("B", 0))
            step, alter = note_names[int(midi) % 12]
            ET.SubElement(pitch_el, "step").text = step
            if alter:
                ET.SubElement(pitch_el, "alter").text = str(alter)
            ET.SubElement(pitch_el, "octave").text = str(int(midi) // 12 - 1)
            tie_types = []
            if index > 0 or (index == 0 and "stop" in ties):
                tie_types.append("stop")
            if index < len(fragments) - 1 or (index == len(fragments) - 1 and "start" in ties):
                tie_types.append("start")
        ET.SubElement(note_el, "duration").text = str(length)
        if not rest:
            for tie_type in tie_types:
                ET.SubElement(note_el, "tie", type=tie_type)
        ET.SubElement(note_el, "voice").text = "1"
        ET.SubElement(note_el, "type").text = note_type
        if dotted:
            ET.SubElement(note_el, "dot")
        if not rest:
            ET.SubElement(note_el, "staff").text = "1"
            tie_types = []
            if index > 0 or (index == 0 and "stop" in ties):
                tie_types.append("stop")
            if index < len(fragments) - 1 or (index == len(fragments) - 1 and "start" in ties):
                tie_types.append("start")
            if tie_types:
                notations = ET.SubElement(note_el, "notations")
                for tie_type in tie_types:
                    ET.SubElement(notations, "tied", type=tie_type)


def write_musicxml(path: Path, notes: Sequence[Note], bpm: Optional[float], title: str) -> None:
    """Write an editable MusicXML score with up to four independent staves."""

    divisions = 960
    quarter_seconds = 60.0 / max(1.0, bpm or 120.0)
    measure_ticks = divisions * 4
    # Music notation is rounded to sixteenth notes, independently from the
    # millisecond timing kept in P8SONG and MIDI.
    arranged = []
    for note in notes:
        start = max(0, int(round(note.start / quarter_seconds * divisions / 240) * 240))
        end = max(start + 240, int(round(note.end / quarter_seconds * divisions / 240) * 240))
        arranged.append((start, end, note))
    arranged.sort(key=lambda item: (item[0], -item[2].midi, item[1]))
    lanes: list[list[tuple[int, int, Note]]] = []
    lane_ends: list[int] = []
    for start, end, note in arranged:
        available = next((index for index, lane_end in enumerate(lane_ends) if lane_end <= start), None)
        if available is None:
            lanes.append([])
            lane_ends.append(0)
            available = len(lanes) - 1
        lanes[available].append((start, end, note))
        lane_ends[available] = end
    maximum_tick = max((end for _start, end, _note in arranged), default=measure_ticks)
    measure_count = max(1, int(math.ceil(maximum_tick / measure_ticks)))

    root = ET.Element("score-partwise", version="4.0")
    work = ET.SubElement(root, "work")
    ET.SubElement(work, "work-title").text = title
    identification = ET.SubElement(root, "identification")
    encoding = ET.SubElement(identification, "encoding")
    ET.SubElement(encoding, "software").text = "Audio to Score Converter"
    ET.SubElement(encoding, "encoding-date").text = date.today().isoformat()
    part_list = ET.SubElement(root, "part-list")
    for index, lane in enumerate(lanes, 1):
        score_part = ET.SubElement(part_list, "score-part", id=f"P{index}")
        ET.SubElement(score_part, "part-name").text = f"声部 {index}"
        part = ET.SubElement(root, "part", id=f"P{index}")
        average_pitch = sum(item[2].midi for item in lane) / max(1, len(lane))
        for measure_index in range(measure_count):
            measure_start = measure_index * measure_ticks
            measure_end = measure_start + measure_ticks
            measure = ET.SubElement(part, "measure", number=str(measure_index + 1))
            if measure_index == 0:
                attributes = ET.SubElement(measure, "attributes")
                ET.SubElement(attributes, "divisions").text = str(divisions)
                key = ET.SubElement(attributes, "key")
                ET.SubElement(key, "fifths").text = "0"
                time = ET.SubElement(attributes, "time")
                ET.SubElement(time, "beats").text = "4"
                ET.SubElement(time, "beat-type").text = "4"
                clef = ET.SubElement(attributes, "clef")
                if average_pitch < 60:
                    ET.SubElement(clef, "sign").text = "F"
                    ET.SubElement(clef, "line").text = "4"
                else:
                    ET.SubElement(clef, "sign").text = "G"
                    ET.SubElement(clef, "line").text = "2"
                direction = ET.SubElement(measure, "direction", placement="above")
                direction_type = ET.SubElement(direction, "direction-type")
                metronome = ET.SubElement(direction_type, "metronome")
                ET.SubElement(metronome, "beat-unit").text = "quarter"
                ET.SubElement(metronome, "per-minute").text = str(int(round(bpm or 120.0)))
                ET.SubElement(direction, "sound", tempo=str(round(bpm or 120.0, 2)))
            cursor = measure_start
            for start, end, note in lane:
                if end <= measure_start or start >= measure_end:
                    continue
                segment_start = max(start, measure_start)
                segment_end = min(end, measure_end)
                if segment_start > cursor:
                    _xml_note_duration(measure, segment_start - cursor, rest=True)
                # The lane allocator guarantees non-overlap.  The max protects
                # against rounding edge cases after a note has crossed a bar.
                segment_start = max(segment_start, cursor)
                if segment_end <= segment_start:
                    continue
                ties = []
                if start < segment_start:
                    ties.append("stop")
                if end > segment_end:
                    ties.append("start")
                _xml_note_duration(measure, segment_end - segment_start, midi=note.midi, ties=ties)
                cursor = segment_end
            if cursor < measure_end:
                _xml_note_duration(measure, measure_end - cursor, rest=True)
    tree = ET.ElementTree(root)
    try:
        ET.indent(tree, space="  ")
    except AttributeError:  # pragma: no cover - Python < 3.9 compatibility.
        pass
    xml = ET.tostring(root, encoding="utf-8", xml_declaration=True)
    path.write_bytes(xml + b"\n")


def _reduce_for_p8song(notes: Sequence[Note]) -> tuple[list[Note], Optional[str]]:
    if len(notes) <= MAX_P8SONG_NOTES:
        return list(notes), None
    ranked = sorted(
        notes,
        key=lambda n: (n.confidence * math.sqrt(max(0.02, n.duration)), n.velocity),
        reverse=True,
    )
    kept = sorted(ranked[:MAX_P8SONG_NOTES], key=lambda n: (n.start, n.midi))
    return kept, f"检测到 {len(notes)} 个音符，P8SONG 已保留置信度最高的 {MAX_P8SONG_NOTES} 个（最多 512 个事件）。"


def convert_file(
    source: Path,
    output_dir: Path,
    settings: Settings,
    formats: Sequence[str],
    progress: Optional[Callable[[float, str], None]] = None,
) -> ConversionResult:
    settings.validate()
    source = source.expanduser().resolve()
    output_dir = output_dir.expanduser().resolve()
    if not source.is_file():
        raise ConversionError(f"找不到音频文件：{source}")
    if source.suffix.lower() not in SUPPORTED_AUDIO:
        raise ConversionError("当前文件扩展名不在支持列表中；可选择 MP3、WAV、FLAC、M4A、AAC、OGG 或 WMA")
    if not formats:
        raise ConversionError("请至少选择一种输出格式")
    if any(name not in ("p8song", "midi", "musicxml", "csv") for name in formats):
        raise ConversionError("输出格式应为 p8song、midi、musicxml 或 csv")
    if progress:
        progress(0.05, "正在解码音频…")
    audio = decode_audio(source, settings.max_seconds)
    if progress:
        progress(0.22, f"音频已读取：{audio.duration:.1f} 秒")

    warnings: list[str] = []
    backend = settings.backend
    notes: list[Note]
    if settings.backend in ("auto", "basic_pitch"):
        if progress:
            progress(0.3, "正在进行 Basic Pitch 多音符识别…")
        try:
            notes = transcribe_basic_pitch(source, audio, settings)
            backend = "Basic Pitch"
        except ConversionError as exc:
            if settings.backend == "basic_pitch":
                raise
            if progress:
                progress(0.35, "Basic Pitch 不可用，切换到单旋律检测…")
            notes = transcribe_monophonic(audio, settings)
            backend = "内置单旋律检测"
            warnings.append(f"高级识别不可用，已切换为单旋律检测：{exc}")
    else:
        if progress:
            progress(0.3, "正在进行单旋律音高检测…")
        notes = transcribe_monophonic(audio, settings)
        backend = "内置单旋律检测"
    if progress:
        progress(0.62, f"识别到 {len(notes)} 个候选音符，正在整理…")
    notes = [
        note
        for note in notes
        if settings.min_midi <= note.midi <= settings.max_midi and note.end > note.start
    ]
    notes = merge_same_pitch(notes)
    notes = quantize_notes(notes, settings.bpm, settings.grid)
    notes = merge_same_pitch(notes)
    notes = limit_polyphony(notes, settings.max_voices)
    if not notes:
        raise ConversionError("没有检测到稳定音符。请提高音量、选择更短的片段，或改用 Basic Pitch")

    p8song_notes, reduction_warning = _reduce_for_p8song(notes)
    if reduction_warning and "p8song" in formats:
        warnings.append(reduction_warning)
    events = notes_to_events(p8song_notes)
    if len(events) > MAX_P8SONG_EVENTS:
        raise ConversionError("整理后的曲谱仍超过 512 个事件，请提高量化粒度或缩短音频")
    title = safe_title(source.stem)
    output_dir.mkdir(parents=True, exist_ok=True)
    outputs: list[Path] = []
    if progress:
        progress(0.78, "正在写出曲谱文件…")
    if "p8song" in formats:
        target = output_dir / f"{title}.json"
        write_p8song(target, title, events, settings.bpm)
        outputs.append(target)
    if "midi" in formats:
        target = output_dir / f"{title}.mid"
        write_midi(target, notes, settings.bpm, title)
        outputs.append(target)
    if "musicxml" in formats:
        target = output_dir / f"{title}.musicxml"
        write_musicxml(target, notes, settings.bpm, title)
        outputs.append(target)
    if "csv" in formats:
        target = output_dir / f"{title}.csv"
        write_csv(target, notes)
        outputs.append(target)
    if progress:
        progress(1.0, f"完成：{len(outputs)} 个文件")
    return ConversionResult(source, title, backend, audio, notes, events, outputs, warnings)


def _format_name(name: str) -> str:
    return {"p8song": "FPGA P8SONG JSON", "midi": "MIDI", "musicxml": "MusicXML 乐谱", "csv": "CSV"}.get(name, name)


class ScoreApp:
    """Tkinter application. Imports tkinter lazily so CLI workers stay light."""

    def __init__(self, root) -> None:
        import tkinter as tk
        from tkinter import ttk

        self.tk = tk
        self.ttk = ttk
        self.root = root
        root.title("音频转曲谱 · FPGA / MIDI")
        root.geometry("1120x820")
        root.minsize(900, 680)
        root.configure(bg="#f4f6f8")

        self.input_var = tk.StringVar()
        self.output_var = tk.StringVar(value=str(APP_DIR / "score_output"))
        self.backend_var = tk.StringVar(value="auto")
        self.bpm_var = tk.StringVar(value="120")
        self.grid_var = tk.StringVar(value="1/8")
        self.voices_var = tk.StringVar(value="4")
        self.min_note_var = tk.StringVar(value="36")
        self.max_note_var = tk.StringVar(value="96")
        self.max_seconds_var = tk.StringVar(value=str(int(DEFAULT_MAX_SECONDS)))
        self.p8song_var = tk.BooleanVar(value=True)
        self.midi_var = tk.BooleanVar(value=True)
        self.musicxml_var = tk.BooleanVar(value=True)
        self.csv_var = tk.BooleanVar(value=False)
        self.status_var = tk.StringVar(value="请选择音频文件")
        self.backend_status_var = tk.StringVar(value="")
        self.progress_var = tk.DoubleVar(value=0)
        self.worker_queue: queue.Queue = queue.Queue()
        self.worker: Optional[threading.Thread] = None
        self.current_result: Optional[ConversionResult] = None
        self.wave_canvas = None
        self.note_tree = None
        self.log_text = None
        self.convert_button = None
        self.open_button = None
        self.progress_bar = None
        self._build_style()
        self._build_ui()
        root.after(100, self._poll_worker)

    def _build_style(self) -> None:
        style = self.ttk.Style(self.root)
        try:
            style.theme_use("vista")
        except Exception:
            pass
        style.configure("Title.TLabel", font=("Microsoft YaHei UI", 20, "bold"), foreground="#17212b", background="#f4f6f8")
        style.configure("Sub.TLabel", font=("Microsoft YaHei UI", 10), foreground="#5f6b76", background="#f4f6f8")
        style.configure("Card.TLabelframe", background="#ffffff", borderwidth=1, relief="solid")
        style.configure("Card.TLabelframe.Label", background="#ffffff", foreground="#17212b", font=("Microsoft YaHei UI", 10, "bold"))
        style.configure("Card.TFrame", background="#ffffff")
        style.configure("Action.TButton", font=("Microsoft YaHei UI", 10, "bold"), padding=(16, 8))
        style.configure("TLabel", background="#ffffff", foreground="#26323c")
        style.configure("TCheckbutton", background="#ffffff")

    def _card(self, parent, title: str):
        frame = self.ttk.LabelFrame(parent, text=title, style="Card.TLabelframe", padding=12)
        return frame

    def _build_ui(self) -> None:
        root = self.root
        ttk = self.ttk
        main = ttk.Frame(root, padding=(22, 18), style="Card.TFrame")
        main.pack(fill="both", expand=True)
        root.configure(bg="#f4f6f8")

        header = ttk.Frame(main, style="Card.TFrame")
        header.pack(fill="x", pady=(0, 12))
        ttk.Label(header, text="音频转曲谱", style="Title.TLabel").pack(anchor="w")
        ttk.Label(header, text="把 MP3 / WAV / FLAC / M4A 等音频整理为 FPGA P8SONG、MIDI、MusicXML 或 CSV", style="Sub.TLabel").pack(anchor="w", pady=(4, 0))

        source = self._card(main, "1 选择音频")
        source.pack(fill="x", pady=(0, 10))
        source_row = ttk.Frame(source, style="Card.TFrame")
        source_row.pack(fill="x")
        source_entry = ttk.Entry(source_row, textvariable=self.input_var)
        source_entry.pack(side="left", fill="x", expand=True)
        self._enable_drag_drop(source_entry)
        ttk.Button(source_row, text="选择文件…", command=self._choose_input).pack(side="left", padx=(8, 0))
        ttk.Label(source, text="支持：MP3、WAV、FLAC、M4A、AAC、OGG、OPUS、WMA、AIFF；可拖放文件；长音频默认只处理前 180 秒。", style="Sub.TLabel").pack(anchor="w", pady=(7, 0))

        settings_frame = ttk.Frame(main, style="Card.TFrame")
        settings_frame.pack(fill="x", pady=(0, 10))
        settings = self._card(settings_frame, "2 识别与输出设置")
        settings.pack(side="left", fill="both", expand=True, padx=(0, 6))
        output = self._card(settings_frame, "输出目录")
        output.pack(side="left", fill="both", expand=True, padx=(6, 0))

        grid = ttk.Frame(settings, style="Card.TFrame")
        grid.pack(fill="x")
        labels = [
            ("识别引擎", self.backend_var, ("自动（优先 Basic Pitch）", "Basic Pitch 高级识别", "内置单旋律检测"), None),
            ("速度 BPM", self.bpm_var, None, None),
            ("节奏量化", self.grid_var, ("不量化", "1/4", "1/8", "1/16"), None),
            ("同时声部", self.voices_var, ("1", "2", "3", "4"), None),
            ("最低音 MIDI", self.min_note_var, None, None),
            ("最高音 MIDI", self.max_note_var, None, None),
            ("最大时长(秒)", self.max_seconds_var, None, None),
        ]
        for row, (label, variable, values, display) in enumerate(labels):
            ttk.Label(grid, text=label).grid(row=row // 2, column=(row % 2) * 2, sticky="w", padx=(0, 7), pady=4)
            if values:
                box = ttk.Combobox(grid, textvariable=variable, values=values, state="readonly", width=19)
                if row == 0:
                    variable.set("自动（优先 Basic Pitch）")
                box.grid(row=row // 2, column=(row % 2) * 2 + 1, sticky="ew", padx=(0, 18), pady=4)
            else:
                ttk.Entry(grid, textvariable=variable, width=21).grid(row=row // 2, column=(row % 2) * 2 + 1, sticky="ew", padx=(0, 18), pady=4)
        grid.columnconfigure(1, weight=1)
        grid.columnconfigure(3, weight=1)
        ttk.Label(settings, text="音高范围使用 MIDI 编号，例如 36=C2，96=C7。BPM 只在选择量化或写 MIDI 时影响节拍。", style="Sub.TLabel").pack(anchor="w", pady=(7, 0))

        out_row = ttk.Frame(output, style="Card.TFrame")
        out_row.pack(fill="x")
        ttk.Entry(out_row, textvariable=self.output_var).pack(side="left", fill="x", expand=True)
        ttk.Button(out_row, text="浏览…", command=self._choose_output).pack(side="left", padx=(8, 0))
        formats = ttk.Frame(output, style="Card.TFrame")
        formats.pack(fill="x", pady=(12, 0))
        ttk.Checkbutton(formats, text="FPGA P8SONG JSON", variable=self.p8song_var).pack(anchor="w", pady=2)
        ttk.Checkbutton(formats, text="MIDI 文件", variable=self.midi_var).pack(anchor="w", pady=2)
        ttk.Checkbutton(formats, text="MusicXML 乐谱", variable=self.musicxml_var).pack(anchor="w", pady=2)
        ttk.Checkbutton(formats, text="CSV 音符表", variable=self.csv_var).pack(anchor="w", pady=2)

        action = ttk.Frame(main, style="Card.TFrame")
        action.pack(fill="x", pady=(0, 10))
        self.convert_button = ttk.Button(action, text="开始转换", style="Action.TButton", command=self._start)
        self.convert_button.pack(side="left")
        self.open_button = ttk.Button(action, text="打开输出目录", command=self._open_output, state="disabled")
        self.open_button.pack(side="left", padx=(8, 0))
        ttk.Label(action, textvariable=self.backend_status_var, style="Sub.TLabel").pack(side="right", padx=(10, 0))

        progress = ttk.Frame(main, style="Card.TFrame")
        progress.pack(fill="x", pady=(0, 10))
        self.progress_bar = ttk.Progressbar(progress, variable=self.progress_var, maximum=100)
        self.progress_bar.pack(fill="x")
        ttk.Label(progress, textvariable=self.status_var, style="Sub.TLabel").pack(anchor="w", pady=(5, 0))

        preview = ttk.PanedWindow(main, orient="vertical")
        preview.pack(fill="both", expand=True)
        wave_frame = self._card(preview, "3 音频与曲谱预览")
        preview.add(wave_frame, weight=2)
        self.wave_canvas = tk_canvas = self.tk.Canvas(wave_frame, height=230, background="#111820", highlightthickness=0)
        tk_canvas.pack(fill="both", expand=True)
        tk_canvas.bind("<Configure>", lambda _event: self._draw_preview())

        bottom = ttk.Frame(preview, style="Card.TFrame")
        preview.add(bottom, weight=3)
        table_frame = self._card(bottom, "识别音符")
        table_frame.pack(side="left", fill="both", expand=True, padx=(0, 6))
        columns = ("start", "end", "note", "midi", "velocity", "confidence")
        self.note_tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=8)
        headings = {"start": "开始(s)", "end": "结束(s)", "note": "音名", "midi": "MIDI", "velocity": "力度", "confidence": "置信度"}
        widths = {"start": 90, "end": 90, "note": 75, "midi": 60, "velocity": 60, "confidence": 75}
        for column in columns:
            self.note_tree.heading(column, text=headings[column])
            self.note_tree.column(column, width=widths[column], anchor="center")
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=self.note_tree.yview)
        self.note_tree.configure(yscrollcommand=scrollbar.set)
        self.note_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        log_frame = self._card(bottom, "处理日志")
        log_frame.pack(side="left", fill="both", expand=True, padx=(6, 0))
        self.log_text = self.tk.Text(log_frame, height=8, wrap="word", state="disabled", background="#f7f9fb", foreground="#26323c", relief="flat")
        self.log_text.pack(fill="both", expand=True)
        self._log("请选择音频后点击“开始转换”。")

    def _choose_input(self) -> None:
        from tkinter import filedialog

        path = filedialog.askopenfilename(
            title="选择音频文件",
            filetypes=[
                ("音频文件", "*.wav *.mp3 *.flac *.m4a *.aac *.ogg *.opus *.wma *.aiff *.aif"),
                ("所有文件", "*.*"),
            ],
        )
        if path:
            self.input_var.set(path)
            self.status_var.set("已选择音频，等待转换")
            self._log(f"已选择：{path}")

    def _enable_drag_drop(self, widget) -> None:
        """Enable file dropping when the optional native Tk DnD package exists."""

        try:
            from tkinterdnd2 import DND_FILES

            widget.drop_target_register(DND_FILES)
            widget.dnd_bind("<<Drop>>", self._drop_input)
        except (ImportError, AttributeError, self.tk.TclError):
            return

    def _drop_input(self, event):
        try:
            paths = self.root.tk.splitlist(event.data)
            path = next(Path(value) for value in paths if Path(value).is_file())
        except (TypeError, StopIteration, self.tk.TclError):
            self.status_var.set("拖入文件无法读取，请使用“选择文件”")
            return "break"
        self.input_var.set(str(path))
        self.status_var.set("已选择音频，等待转换")
        self._log(f"已拖入：{path}")
        return "break"

    def _choose_output(self) -> None:
        from tkinter import filedialog

        path = filedialog.askdirectory(title="选择输出目录")
        if path:
            self.output_var.set(path)

    def _open_output(self) -> None:
        path = Path(self.output_var.get()).expanduser()
        path.mkdir(parents=True, exist_ok=True)
        try:
            os.startfile(str(path))
        except AttributeError:
            subprocess.Popen(["xdg-open", str(path)])

    def _log(self, message: str) -> None:
        if self.log_text is None:
            return
        self.log_text.configure(state="normal")
        self.log_text.insert("end", message.rstrip() + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _settings(self) -> Settings:
        try:
            bpm_text = self.bpm_var.get().strip()
            bpm = float(bpm_text) if bpm_text else None
            if bpm is not None and not 20 <= bpm <= 300:
                raise ValueError("BPM 应在 20 到 300 之间")
            max_seconds_text = self.max_seconds_var.get().strip()
            max_seconds = float(max_seconds_text) if max_seconds_text else None
            if max_seconds is not None and max_seconds < 0:
                raise ValueError("最大时长不能为负数")
            settings = Settings(
                backend={
                    "自动（优先 Basic Pitch）": "auto",
                    "Basic Pitch 高级识别": "basic_pitch",
                    "内置单旋律检测": "fallback",
                }.get(self.backend_var.get(), "auto"),
                bpm=bpm,
                grid=self.grid_var.get(),
                max_voices=int(self.voices_var.get()),
                min_midi=int(self.min_note_var.get()),
                max_midi=int(self.max_note_var.get()),
                max_seconds=max_seconds,
            )
            settings.validate()
            return settings
        except ValueError as exc:
            raise ConversionError(str(exc)) from exc

    def _start(self) -> None:
        if self.worker and self.worker.is_alive():
            return
        source = Path(self.input_var.get().strip())
        output = Path(self.output_var.get().strip() or "score_output")
        formats = [
            name
            for name, variable in (("p8song", self.p8song_var), ("midi", self.midi_var), ("musicxml", self.musicxml_var), ("csv", self.csv_var))
            if variable.get()
        ]
        try:
            settings = self._settings()
            if not source.is_file():
                raise ConversionError("请先选择存在的音频文件")
            if not formats:
                raise ConversionError("请至少勾选一种输出格式")
        except ConversionError as exc:
            from tkinter import messagebox

            messagebox.showerror("参数错误", str(exc))
            return
        self.current_result = None
        self.progress_var.set(0)
        self.status_var.set("准备转换…")
        self.backend_status_var.set("处理中")
        self.convert_button.configure(state="disabled")
        self.open_button.configure(state="disabled")
        self._clear_preview()
        self._log(f"开始：{source.name}")

        def work() -> None:
            try:
                result = convert_file(source, output, settings, formats, lambda value, message: self.worker_queue.put(("progress", value, message)))
                self.worker_queue.put(("done", result))
            except Exception as exc:
                self.worker_queue.put(("error", exc))

        self.worker = threading.Thread(target=work, name="audio-to-score", daemon=True)
        self.worker.start()

    def _poll_worker(self) -> None:
        try:
            while True:
                message = self.worker_queue.get_nowait()
                kind = message[0]
                if kind == "progress":
                    _kind, value, text = message
                    self.progress_var.set(value * 100)
                    self.status_var.set(text)
                elif kind == "done":
                    self._finish(message[1])
                elif kind == "error":
                    self._fail(message[1])
        except queue.Empty:
            pass
        self.root.after(100, self._poll_worker)

    def _finish(self, result: ConversionResult) -> None:
        self.current_result = result
        self.progress_var.set(100)
        self.status_var.set(f"完成：{len(result.notes)} 个音符，{len(result.events)} 个 P8SONG 事件")
        self.backend_status_var.set(f"识别引擎：{result.backend}")
        self.convert_button.configure(state="normal")
        self.open_button.configure(state="normal")
        self._log(f"识别引擎：{result.backend}")
        self._log(f"音频时长：{result.audio.duration:.2f} 秒；输出音符：{len(result.notes)}")
        for warning in result.warnings:
            self._log("提示：" + warning)
        for output in result.outputs:
            self._log("已写出：" + str(output))
        self._fill_table(result.notes)
        self._draw_preview()

    def _fail(self, error: Exception) -> None:
        self.convert_button.configure(state="normal")
        self.backend_status_var.set("转换失败")
        self.status_var.set("转换失败，请查看日志")
        self._log("错误：" + str(error))
        from tkinter import messagebox

        messagebox.showerror("转换失败", str(error))

    def _clear_preview(self) -> None:
        if self.note_tree:
            for item in self.note_tree.get_children():
                self.note_tree.delete(item)
        if self.wave_canvas:
            self.wave_canvas.delete("all")

    def _fill_table(self, notes: Sequence[Note]) -> None:
        if not self.note_tree:
            return
        for item in self.note_tree.get_children():
            self.note_tree.delete(item)
        for note in notes:
            self.note_tree.insert("", "end", values=(f"{note.start:.3f}", f"{note.end:.3f}", midi_name(note.midi), note.midi, note.velocity, f"{note.confidence:.2f}"))

    def _draw_preview(self) -> None:
        if self.wave_canvas is None:
            return
        canvas = self.wave_canvas
        canvas.delete("all")
        width = max(10, canvas.winfo_width())
        height = max(10, canvas.winfo_height())
        canvas.create_text(12, 12, anchor="nw", text="波形 / 音符时间线", fill="#b7c7d8", font=("Microsoft YaHei UI", 9))
        result = self.current_result
        if result is None:
            canvas.create_text(width / 2, height / 2, text="转换后在这里预览", fill="#6f8192", font=("Microsoft YaHei UI", 12))
            return
        envelope = result.audio.envelope
        mid = height * 0.35
        scale = height * 0.25
        if len(envelope) > 1:
            points = []
            for index, value in enumerate(envelope):
                x = 8 + index / (len(envelope) - 1) * (width - 16)
                y = mid - float(value) * scale
                points.extend((x, y))
            canvas.create_line(*points, fill="#77b7d8", width=1, smooth=True)
            points = []
            for index, value in enumerate(envelope):
                x = 8 + index / (len(envelope) - 1) * (width - 16)
                y = mid + float(value) * scale
                points.extend((x, y))
            canvas.create_line(*points, fill="#77b7d8", width=1, smooth=True)
        duration = max(0.001, result.audio.duration)
        piano_top, piano_bottom = height * 0.52, height - 20
        canvas.create_line(8, piano_top, width - 8, piano_top, fill="#2c3d4c")
        for note in result.notes[:300]:
            x1 = 8 + note.start / duration * (width - 16)
            x2 = 8 + note.end / duration * (width - 16)
            y = piano_bottom - (note.midi - 20) / max(1, 110 - 20) * (piano_bottom - piano_top - 8)
            y = max(piano_top + 3, min(piano_bottom - 3, y))
            canvas.create_line(x1, y, max(x1 + 2, x2), y, fill="#f2c66d", width=3)
        canvas.create_text(10, height - 8, anchor="sw", text="0s", fill="#8ea3b6", font=("Arial", 8))
        canvas.create_text(width - 10, height - 8, anchor="se", text=f"{result.audio.duration:.1f}s", fill="#8ea3b6", font=("Arial", 8))


def launch_gui() -> None:
    import tkinter as tk

    try:
        from tkinterdnd2 import TkinterDnD

        root = TkinterDnD.Tk()
    except ImportError:
        root = tk.Tk()
    ScoreApp(root)
    root.mainloop()


def _cli_settings(args: argparse.Namespace) -> Settings:
    return Settings(
        backend=args.backend,
        bpm=args.bpm,
        grid=args.grid,
        max_voices=args.voices,
        min_midi=args.min_midi,
        max_midi=args.max_midi,
        max_seconds=args.max_seconds,
        onset_threshold=args.onset_threshold,
        frame_threshold=args.frame_threshold,
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="把音频转为 FPGA P8SONG / MIDI / MusicXML / CSV 曲谱")
    parser.add_argument("input", nargs="?", help="音频文件；不填写时打开可视化界面")
    parser.add_argument("--output-dir", default="score_output", help="输出目录")
    parser.add_argument("--format", nargs="+", choices=("p8song", "midi", "musicxml", "csv"), default=("p8song", "midi", "musicxml"), help="输出格式")
    parser.add_argument("--backend", choices=("auto", "basic_pitch", "fallback"), default="auto", help="识别引擎")
    parser.add_argument("--bpm", type=float, default=120.0, help="BPM")
    parser.add_argument("--grid", choices=("不量化", "1/4", "1/8", "1/16"), default="1/8", help="节奏量化")
    parser.add_argument("--voices", type=int, choices=(1, 2, 3, 4), default=4, help="同时声部数")
    parser.add_argument("--min-midi", type=int, default=36, help="最低 MIDI 音高")
    parser.add_argument("--max-midi", type=int, default=96, help="最高 MIDI 音高")
    parser.add_argument("--max-seconds", type=float, default=DEFAULT_MAX_SECONDS, help="最多处理秒数，0 表示完整音频")
    parser.add_argument("--onset-threshold", type=float, default=0.4)
    parser.add_argument("--frame-threshold", type=float, default=0.25)
    parser.add_argument("--basic-pitch-worker", nargs=2, metavar=("INPUT", "OUTPUT"), help=argparse.SUPPRESS)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.basic_pitch_worker:
        worker_settings = Settings(
            min_midi=args.min_midi,
            max_midi=args.max_midi,
            onset_threshold=args.onset_threshold,
            frame_threshold=args.frame_threshold,
        )
        return _basic_pitch_worker(args.basic_pitch_worker[0], args.basic_pitch_worker[1], worker_settings)
    if not args.input:
        launch_gui()
        return 0
    try:
        settings = _cli_settings(args)
        result = convert_file(Path(args.input), Path(args.output_dir), settings, args.format, lambda value, message: print(f"[{value * 100:5.1f}%] {message}"))
    except Exception as exc:
        print(f"错误：{exc}", file=sys.stderr)
        return 1
    print(f"识别引擎：{result.backend}")
    print(f"音符：{len(result.notes)}，P8SONG 事件：{len(result.events)}")
    for warning in result.warnings:
        print("提示：" + warning)
    for output in result.outputs:
        print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
