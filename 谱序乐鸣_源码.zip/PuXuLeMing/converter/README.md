# 桌面音频转谱

在工程根运行 `python converter/app.py`。基础依赖见本目录 requirements.txt；FFmpeg 从 PATH 查找。可选 Basic Pitch 依赖见 requirements-optional.txt，安装到当前 Python 后即可使用。

支持音频导入、预听及 P8SONG JSON/MIDI/MusicXML/CSV 导出。兼容导出最多 512 事件，默认最多 4 个同时音符；复杂音频请先试听并修订结果。命令行说明：`python converter/app.py --help`。
