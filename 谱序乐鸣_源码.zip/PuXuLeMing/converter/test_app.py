import json
import math
import tempfile
import unittest
from unittest.mock import patch
import wave
import xml.etree.ElementTree as ET
from pathlib import Path

import numpy as np

from app import (
    AudioBuffer,
    ConversionError,
    Note,
    Settings,
    _audio_envelope,
    convert_file,
    decode_audio,
    limit_polyphony,
    midi_name,
    notes_to_events,
    read_wav_bytes,
    transcribe_monophonic,
    write_midi,
    write_musicxml,
)


class ConverterTests(unittest.TestCase):
    def test_midi_note_name_and_event_order(self):
        self.assertEqual(midi_name(60), "C4")
        self.assertEqual(midi_name(61), "C#4")
        events = notes_to_events([Note(0.5, 1.0, 60), Note(1.0, 1.5, 60)])
        self.assertEqual(len(events), 4)
        self.assertFalse(events[1]["on"])
        self.assertTrue(events[2]["on"])
        self.assertEqual(events[1]["ms"], events[2]["ms"])

    def test_four_voice_limit_at_every_boundary(self):
        notes = [Note(0, 1, pitch, 80, 0.7) for pitch in range(60, 66)]
        limited = limit_polyphony(notes, 4)
        for start in np.arange(0, 1, 0.01):
            active = [note for note in limited if note.start <= start < note.end]
            self.assertLessEqual(len(active), 4)

    def test_voice_limit_preserves_short_interruptions(self):
        for voices in (1, 4):
            notes = [Note(0, 1, pitch, 80, 0.1) for pitch in range(60, 60 + voices)]
            notes.append(Note(0.49, 0.51, 72, 100, 1.0))
            events = notes_to_events(limit_polyphony(notes, voices))
            active = set()
            for event in events:
                if event["on"]:
                    self.assertNotIn(event["note"], active)
                    active.add(event["note"])
                else:
                    self.assertIn(event["note"], active)
                    active.remove(event["note"])
                self.assertLessEqual(len(active), voices)
            self.assertFalse(active)

    def test_submillisecond_notes_do_not_add_an_overlapping_voice(self):
        notes = [Note(0, 0.0004, 60), Note(0.0004, 1, 64)]
        events = notes_to_events(notes)
        self.assertEqual(len(events), 2)
        self.assertEqual(events[0]["note"], 64)

    def test_sustained_tone_without_leading_silence_is_detected(self):
        rate = 16000
        times = np.arange(rate * 2) / rate
        samples = (0.6 * np.sin(2 * math.pi * 440 * times)).astype(np.float32)
        audio = AudioBuffer(samples, rate, 2.0, _audio_envelope(samples))
        notes = transcribe_monophonic(audio, Settings(min_midi=48, max_midi=80))
        self.assertTrue(notes)
        self.assertEqual(notes[0].midi, 69)
        self.assertGreater(notes[0].duration, 1.5)

    def test_wav_fallback_obeys_duration_limit(self):
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / "source.wav"
            with wave.open(str(source), "wb") as wav:
                wav.setnchannels(1)
                wav.setsampwidth(2)
                wav.setframerate(8000)
                wav.writeframes(np.zeros(16000, dtype="<i2").tobytes())
            with patch("app.find_ffmpeg", return_value=None):
                audio = decode_audio(source, 0.25)
            self.assertEqual(len(audio.samples), 2000)
            self.assertEqual(audio.duration, 0.25)

    def test_long_score_keeps_full_preview_and_other_exports(self):
        notes = [Note(index * 0.3, index * 0.3 + 0.2, 60) for index in range(300)]
        audio = AudioBuffer(np.zeros(16000, dtype=np.float32), 16000, 90.0, np.zeros(100))
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / "long.wav"
            source.touch()
            with patch("app.decode_audio", return_value=audio), patch("app.transcribe_monophonic", return_value=notes):
                result = convert_file(source, Path(temp) / "out", Settings(backend="fallback", grid="不量化"), ("p8song", "csv"))
                csv_only = convert_file(source, Path(temp) / "csv_only", Settings(backend="fallback", grid="不量化"), ("csv",))
            self.assertEqual(len(result.notes), 300)
            self.assertEqual(len(result.events), 512)
            self.assertEqual(len((Path(temp) / "out" / "long.csv").read_text(encoding="utf-8-sig").splitlines()), 301)
            self.assertEqual(len(result.warnings), 1)
            self.assertEqual(csv_only.warnings, [])

    def test_invalid_settings_are_rejected_before_audio_work(self):
        cases = [
            {"bpm": float("nan")}, {"bpm": 0}, {"backend": "invalid"},
            {"min_midi": 80, "max_midi": 60}, {"max_voices": 5},
            {"max_seconds": float("inf")}, {"max_seconds": -1},
            {"frame_threshold": float("nan")}, {"onset_threshold": 2},
        ]
        for values in cases:
            with self.subTest(values=values), self.assertRaises(ConversionError):
                Settings(**values).validate()

    def test_wav_decode_downmix_and_envelope(self):
        sample_rate = 8000
        samples = np.column_stack(
            (
                np.zeros(sample_rate, dtype=np.int16),
                np.full(sample_rate, 8192, dtype=np.int16),
            )
        )
        memory = __import__("io").BytesIO()
        with wave.open(memory, "wb") as wav:
            wav.setnchannels(2)
            wav.setsampwidth(2)
            wav.setframerate(sample_rate)
            wav.writeframes(samples.tobytes())
        decoded, decoded_rate = read_wav_bytes(memory.getvalue())
        self.assertEqual(decoded_rate, sample_rate)
        self.assertEqual(decoded.size, sample_rate)
        self.assertAlmostEqual(float(decoded.mean()), 0.125, places=4)
        self.assertEqual(_audio_envelope(decoded, 100).size, 100)

    def test_midi_and_musicxml_are_structurally_valid(self):
        notes = [
            Note(0.0, 1.125, 60, 90, 0.9),
            Note(1.125, 2.5, 64, 85, 0.8),
            Note(0.5, 1.5, 48, 80, 0.7),
        ]
        with tempfile.TemporaryDirectory() as temp:
            midi = Path(temp) / "test.mid"
            musicxml = Path(temp) / "test.musicxml"
            write_midi(midi, notes, 120, "Test")
            write_musicxml(musicxml, notes, 120, "Test")
            self.assertEqual(midi.read_bytes()[:4], b"MThd")
            root = ET.parse(musicxml).getroot()
            self.assertEqual(root.tag, "score-partwise")
            self.assertEqual(len(root.findall("part")), 2)
            self.assertGreaterEqual(len(root.findall(".//pitch")), 3)
            self.assertTrue(root.findall(".//clef"))
            self.assertEqual({len(part.findall("measure")) for part in root.findall("part")}, {2})
            for measure in root.findall(".//measure"):
                self.assertEqual(sum(int(note.findtext("duration")) for note in measure.findall("note")), 3840)
            tied_notes = [note for note in root.findall(".//note") if note.find("tie") is not None]
            self.assertTrue(tied_notes)
            for note in tied_notes:
                tags = [child.tag for child in note]
                self.assertLess(tags.index("duration"), tags.index("tie"))

    def test_full_fallback_conversion_writes_fpga_contract(self):
        sample_rate = 16_000
        duration = 1.3
        times = np.arange(int(sample_rate * duration), dtype=np.float32) / sample_rate
        samples = np.zeros_like(times)
        samples[(times >= 0.12) & (times < 0.5)] = 0.7 * np.sin(2 * math.pi * 440 * times[(times >= 0.12) & (times < 0.5)])
        samples[(times >= 0.65) & (times < 1.15)] = 0.6 * np.sin(2 * math.pi * 523.251 * times[(times >= 0.65) & (times < 1.15)])
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            source = temp_path / "two_notes.wav"
            pcm = (samples * 32767).astype("<i2")
            with wave.open(str(source), "wb") as wav:
                wav.setnchannels(1)
                wav.setsampwidth(2)
                wav.setframerate(sample_rate)
                wav.writeframes(pcm.tobytes())
            settings = Settings(
                backend="fallback",
                bpm=None,
                grid="不量化",
                max_seconds=0,
                min_midi=48,
                max_midi=80,
            )
            result = convert_file(source, temp_path / "out", settings, ("p8song", "midi", "musicxml", "csv"))
            self.assertGreaterEqual(len(result.notes), 2)
            self.assertLessEqual(len(result.events), 512)
            self.assertEqual({p.suffix for p in result.outputs}, {".json", ".mid", ".musicxml", ".csv"})
            payload = json.loads((temp_path / "out" / "two_notes.json").read_text(encoding="utf-8"))
            self.assertEqual(payload["version"], 1)
            self.assertEqual(len(payload["events"]), len(result.events))
            self.assertGreaterEqual(payload["events"][0]["ms"], 80)
            active = set()
            for event in payload["events"]:
                if event["on"]:
                    active.add(event["note"])
                else:
                    active.remove(event["note"])
                self.assertLessEqual(len(active), 4)
            self.assertFalse(active)


if __name__ == "__main__":
    unittest.main()
