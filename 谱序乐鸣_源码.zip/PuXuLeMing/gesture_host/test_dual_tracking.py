import math
import unittest
from types import SimpleNamespace as NS
from dual_tracking import DualHandTracker, observations_from_result
from legacy_vision_tests import POSES

def obs(label,pose,score=.9,hand_score=.99,index=0):
    return dict(label=label,pose=pose,confidence=score,hand_score=hand_score,index=index,source='test',category='None')

class DualTrackingTests(unittest.TestCase):
    def stable(self,tracker,items):
        tracker.update(items,1.0)
        return tracker.update(items,1.07)
    def test_two_independent_poses(self):
        s=self.stable(DualHandTracker(),[obs('Left','1'),obs('Right','5',index=1)])
        self.assertEqual((s['Left']['digit'],s['Right']['digit']),(1,5))
    def test_model_order_does_not_swap_hands(self):
        t=DualHandTracker();self.stable(t,[obs('Left','2'),obs('Right','6',index=1)])
        s=t.update([obs('Right','6',index=0),obs('Left','2',index=1)],1.14)
        self.assertEqual((s['Left']['digit'],s['Right']['digit']),(2,6))
    def test_one_hand_loss_keeps_other(self):
        t=DualHandTracker();self.stable(t,[obs('Left','3'),obs('Right','4',index=1)])
        s=t.update([obs('Right','4')],1.14)
        self.assertEqual(s['Left']['digit'],0);self.assertEqual(s['Right']['digit'],4)
    def test_fist_on_one_side_preserves_other(self):
        t=DualHandTracker();self.stable(t,[obs('Left','1'),obs('Right','5',index=1)])
        s=t.update([obs('Left','fist'),obs('Right','5',index=1)],1.14)
        self.assertEqual((s['Left']['digit'],s['Right']['digit']),(0,5))
    def test_same_pose_is_not_merged(self):
        s=self.stable(DualHandTracker(),[obs('Left','7'),obs('Right','7',index=1)])
        self.assertEqual((s['Left']['digit'],s['Right']['digit']),(7,7))
    def test_duplicate_identity_cannot_invent_right_hand(self):
        t=DualHandTracker();self.stable(t,[obs('Left','1'),obs('Right','2',index=1)])
        s=t.update([obs('Left','3'),obs('Left','4',index=1)],1.14)
        self.assertEqual((s['Left']['digit'],s['Right']['digit']),(0,0))
    def test_uncertain_handedness_is_not_assigned(self):
        s=self.stable(DualHandTracker(),[obs('Left','5',hand_score=.51),obs('Right','3',index=1)])
        self.assertEqual((s['Left']['digit'],s['Right']['digit']),(0,3))
    def test_no_stale_pose_after_long_frame_gap(self):
        t=DualHandTracker();self.stable(t,[obs('Left','1')])
        self.assertEqual(t.update([obs('Left','1')],3.)['Left']['digit'],0)
    def test_noise_does_not_change_stable_digit(self):
        t=DualHandTracker();self.stable(t,[obs('Left','1')])
        s=t.update([obs('Left','5')],1.14)
        self.assertEqual(s['Left']['digit'],1)
        s=t.update([obs('Left','5')],1.21)
        self.assertEqual(s['Left']['digit'],5)
    def test_bad_confidence_clears_only_own_hand(self):
        for bad in (float('nan'),.1):
            t=DualHandTracker();self.stable(t,[obs('Left','1'),obs('Right','2',index=1)])
            s=t.update([obs('Left','1',score=bad),obs('Right','2',index=1)],1.14)
            self.assertEqual((s['Left']['digit'],s['Right']['digit']),(0,2))
    def test_full_result_uses_each_world_landmark_set(self):
        points=lambda pose:[NS(x=x,y=y,z=z) for x,y,z in POSES[pose]]
        result=NS(hand_landmarks=[points('5'),points('2')],hand_world_landmarks=[points('5'),points('2')],handedness=[[NS(category_name='Right',score=.99)],[NS(category_name='Left',score=.99)]],gestures=[[],[]])
        items=observations_from_result(result)
        s=self.stable(DualHandTracker(),items)
        self.assertEqual((s['Left']['digit'],s['Right']['digit']),(2,5))
    def test_missing_world_landmarks_not_reused_from_other_hand(self):
        points=[NS(x=x,y=y,z=z) for x,y,z in POSES['1']]
        result=NS(hand_landmarks=[points,points],hand_world_landmarks=[points],handedness=[[NS(category_name='Left',score=.99)],[NS(category_name='Right',score=.99)]],gestures=[[],[]])
        s=self.stable(DualHandTracker(),observations_from_result(result))
        self.assertEqual(s['Left']['digit'],1);self.assertEqual(s['Right']['digit'],0)
    def test_all_49_left_right_pose_pairs(self):
        points=lambda pose:[NS(x=x,y=y,z=z) for x,y,z in POSES[pose]]
        for left in '1234567':
            for right in '1234567':
                with self.subTest(left=left,right=right):
                    result=NS(hand_landmarks=[points(right),points(left)],hand_world_landmarks=[points(right),points(left)],handedness=[[NS(category_name='Right',score=.99)],[NS(category_name='Left',score=.99)]],gestures=[[],[]])
                    states=self.stable(DualHandTracker(),observations_from_result(result))
                    self.assertEqual((states['Left']['digit'],states['Right']['digit']),(int(left),int(right)))

if __name__=='__main__':unittest.main()
