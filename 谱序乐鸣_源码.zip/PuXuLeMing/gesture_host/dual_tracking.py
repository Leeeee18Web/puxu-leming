"""Two independent digit recognizers. No serial, sound or board dependencies."""
import math
from vision_worker import _best_category
from digit_recognition import recognize_digit

SIDES=('Left','Right')

def observations_from_result(result):
    hands=getattr(result,'hand_landmarks',()) or ()
    worlds=getattr(result,'hand_world_landmarks',()) or ()
    labels=getattr(result,'handedness',()) or ()
    gestures=getattr(result,'gestures',()) or ()
    items=[]
    for index,points in enumerate(hands):
        label,hand_score=_best_category(labels[index] if index<len(labels) else ())
        categories=gestures[index] if index<len(gestures) else ()
        category,category_score=_best_category(categories)
        evidence=dict(pose='unknown',confidence=0.,source='手部关键点不完整',reason='invalid_landmarks',diagnostics={})
        if index<len(worlds) and len(worlds[index])==21 and len(points)==21:
            evidence=recognize_digit([(p.x,p.y,p.z) for p in worlds[index]],categories)
        items.append(dict(evidence,label=label,hand_score=hand_score,
                          index=index,category=category,category_score=category_score))
    return items


class PreviewDigitFilter:
    """Two consistent observations; only brief 4/5 geometric doubt can coast."""
    def __init__(self):self.reset()
    def reset(self):
        self.stable='unknown';self.score=0.;self.last_evidence=None
        self.candidate=None;self.count=0;self.last_frame=None;self.provisional=False
    def update(self,pose,confidence,now,reason=''):
        if self.last_frame is not None and (now<=self.last_frame or now-self.last_frame>.5):self.reset()
        self.last_frame=now;self.provisional=False
        if pose=='fist':self.reset();return 'fist',0.
        valid=math.isfinite(confidence) and confidence>=.65 and pose in tuple('1234567')
        if not valid:
            soft=(pose=='unknown' and reason in ('thumb_uncertain','long_fingers_uncertain'))
            if (soft and self.stable in ('4','5') and self.last_evidence is not None
                    and now-self.last_evidence<=.16):
                self.candidate=None;self.count=0;self.provisional=True
                return self.stable,self.score*.8
            self.reset();return 'unknown',0.
        if pose==self.candidate:self.count+=1
        else:self.candidate=pose;self.count=1
        if self.count>=2:
            self.stable=pose;self.score=confidence;self.last_evidence=now
        elif pose==self.stable:
            self.score=confidence;self.last_evidence=now
        elif self.last_evidence is not None and now-self.last_evidence>.16:
            self.stable='unknown';self.score=0.
        self.provisional=self.stable!='unknown' and self.stable!=pose
        return self.stable,self.score


class DualHandTracker:
    def __init__(self):
        self.filters={side:PreviewDigitFilter() for side in SIDES}
        self.last_time=None
    def reset(self):
        for f in self.filters.values():f.reset()
        self.last_time=None
    def update(self,observations,now):
        if self.last_time is not None and (now<=self.last_time or now-self.last_time>.5):
            self.reset()
        self.last_time=now
        result={}
        for side in SIDES:
            matches=[o for o in observations if o.get('label')==side]
            item=matches[0] if len(matches)==1 else None
            reliable=item is not None and math.isfinite(item.get('hand_score',0.)) and item.get('hand_score',0.)>=.6
            if not reliable:
                self.filters[side].reset()
                message='左右身份待确认' if matches else '未检测到'
                result[side]=dict(digit=0,pose='unknown',raw_pose='unknown',present=False,confidence=0.,status=message,index=None)
                continue
            pose,score=self.filters[side].update(item.get('pose','unknown'),item.get('confidence',0.),now,item.get('reason',''))
            digit=int(pose) if pose in tuple('1234567') else 0
            provisional=self.filters[side].provisional
            status=('短暂不确定，保留上次数字' if provisional and item.get('pose')=='unknown'
                    else '正在确认新数字' if provisional else '已确认' if digit
                    else '握拳' if pose=='fist' else item.get('source','保持手势，等待确认'))
            result[side]=dict(digit=digit,pose=pose,raw_pose=item.get('pose','unknown'),present=True,
                              confidence=score,status=status,index=item.get('index'),source=item.get('source',''),
                              provisional=provisional,reason=item.get('reason',''),diagnostics=item.get('diagnostics',{}),
                              provisional_for_ms=max(0.,.16-(now-self.filters[side].last_evidence))*1000
                              if provisional and self.filters[side].last_evidence is not None else 0.)
        return result
