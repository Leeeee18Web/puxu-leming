# 双手手势演奏

使用方法与依赖见根目录 README.md。入口为 `app.py`；`dual_camera.py` 负责双手识别，`controller.py` 负责音序，`gesture_link.py` 负责串口握手与应答。`models/gesture_recognizer.task` 是随项目携带的 MediaPipe 模型；字体授权见 `assets/fonts/OFL.txt`。
