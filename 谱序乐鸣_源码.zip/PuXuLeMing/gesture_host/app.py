"""Dual-hand performance UI; camera and serial each have a single independent owner."""
import argparse,base64,json,os,queue,sys,time
from pathlib import Path
from PySide6.QtCore import QProcess,QTimer,Qt,QRectF
from PySide6.QtGui import QColor,QImage,QPainter,QKeySequence,QShortcut
from PySide6.QtWidgets import QApplication,QComboBox,QFrame,QHBoxLayout,QLabel,QMainWindow,QPushButton,QSpinBox,QVBoxLayout,QWidget
from controller import PerformanceController
from gesture_link import GestureLink
from fonts import initialize_fonts

ROOT=Path(__file__).resolve().parent
_vision_default=Path(sys.executable)
VISION=Path(os.environ.get('INSTRUMENT_VISION_PYTHON',str(_vision_default if _vision_default.is_file() else sys.executable)))
PALETTE=dict(bg='#151617',panel='#202124',field='#26282c',text='#f3f0ea',muted='#a8a39a',border='#5f6775',gold='#d7b56d',teal='#7fb7ad',button='#34363b',danger='#8f3f48')
STYLE='''
QWidget {background:#151617;color:#f3f0ea;font-size:14px;}
QFrame#card {background:#202124;border:1px solid #454a53;border-radius:12px;}
QFrame#card QLabel {background:transparent;border:0;}
QLabel#title {font-size:26px;font-weight:600;}
QLabel#subtle {color:#a8a39a;}
QLabel#message {color:#d7b56d;}
QPushButton,QComboBox,QSpinBox {background:#34363b;border:1px solid #5f6775;border-radius:6px;padding:9px 12px;min-height:22px;}
QPushButton:hover {background:#41444a;}
QPushButton:pressed {background:#25272a;}
QPushButton:focus,QComboBox:focus,QSpinBox:focus {border:2px solid #d7b56d;}
QPushButton:disabled {background:#24262a;color:#88847d;border-color:#454a53;}
QPushButton#primary {background:#416e68;border-color:#7fb7ad;}
QPushButton#danger {background:#8f3f48;border-color:#b77379;}
QComboBox::drop-down {border:0;width:24px;}
QComboBox QAbstractItemView {background:#26282c;color:#f3f0ea;selection-background-color:#416e68;}
'''

class SessionEvents:
 def __init__(self,target,session):self.target=target;self.session=session
 def put(self,event):self.target.put(dict(event,session_id=self.session))

class CameraView(QWidget):
 def __init__(self):
  super().__init__();self.image=QImage();self.caption='摄像头未打开';self.setMinimumSize(480,340)
 def paintEvent(self,event):
  p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing);p.setPen(Qt.PenStyle.NoPen)
  p.setBrush(QColor('#050505'));p.drawRoundedRect(self.rect(),12,12)
  if self.image.isNull():p.setPen(QColor(PALETTE['muted']));p.drawText(self.rect(),Qt.AlignmentFlag.AlignCenter,self.caption)
  else:
   size=self.image.size().scaled(self.size(),Qt.AspectRatioMode.KeepAspectRatio)
   p.drawImage(QRectF((self.width()-size.width())/2,(self.height()-size.height())/2,size.width(),size.height()),self.image)
 def clear(self,caption):self.image=QImage();self.caption=caption;self.update()
 def set_frame(self,data):
  image=QImage.fromData(data)
  if not image.isNull():self.image=image;self.update()

class HandCard(QFrame):
 def __init__(self,title,color,rule):
  super().__init__();self.setObjectName('card');layout=QVBoxLayout(self);layout.setContentsMargins(20,16,20,16);layout.setSpacing(8)
  heading=QLabel(title);heading.setStyleSheet(f'font-size:17px;font-weight:600;color:{color};');layout.addWidget(heading)
  self.digit=QLabel('—');self.digit.setStyleSheet(f'font-size:56px;font-weight:600;color:{color};');layout.addWidget(self.digit)
  self.state=QLabel('未检测到');self.state.setWordWrap(True);layout.addWidget(self.state)
  label=QLabel(rule);label.setObjectName('subtle');layout.addWidget(label)
 def set_result(self,item):
  digit=item.get('digit',0);pose=item.get('pose','unknown')
  self.digit.setText(str(digit) if digit else '握拳' if pose=='fist' else '—')
  self.state.setText('暂存上次数字' if item.get('provisional') else item.get('status','未检测到'))

class MainWindow(QMainWindow):
 def __init__(self,autostart=True,link_factory=GestureLink,ports_provider=None,clock=time.monotonic):
  super().__init__();self.setWindowTitle('手势演奏 · 最终整合版');self.resize(1280,840);self.setMinimumSize(1024,720);self.setStyleSheet(STYLE)
  self.clock=clock;self.link_factory=link_factory;self.ports_provider=ports_provider
  self.events=queue.Queue();self.session=0;self.worker=None;self.connected=False;self.capabilities=0;self.board_playable=False
  self.controller=PerformanceController(self.dispatch,is_acked=lambda note:bool(self.worker) and getattr(self.worker,'note_acknowledged',lambda n:True)(note));self.process=None;self.buffer=bytearray();self.stderr='';self.stopping=False
  self.last_frame=0.;self.provisional_deadlines={};self.camera_name='';self.camera_failed=False
  root=QWidget();self.setCentralWidget(root);layout=QVBoxLayout(root);layout.setContentsMargins(24,20,24,20);layout.setSpacing(16)
  header=QHBoxLayout();title=QLabel('手势演奏');title.setObjectName('title');header.addWidget(title)
  subtitle=QLabel('左手定起始音，右手定数量');subtitle.setObjectName('subtle');header.addSpacing(16);header.addWidget(subtitle);header.addStretch()
  self.link_status=QLabel('开发板未连接');self.link_status.setObjectName('subtle');header.addWidget(self.link_status);layout.addLayout(header)
  controls=QHBoxLayout();controls.setSpacing(10);controls.addWidget(QLabel('串口'))
  self.ports=QComboBox();self.ports.setMinimumWidth(220);self.ports.setAccessibleName('开发板串口');controls.addWidget(self.ports,1)
  refresh=QPushButton('刷新');refresh.clicked.connect(self.refresh_ports);controls.addWidget(refresh)
  self.connect_button=QPushButton('连接');self.connect_button.setMinimumWidth(80);self.connect_button.setObjectName('primary');self.connect_button.clicked.connect(self.connect_board);controls.addWidget(self.connect_button)
  self.camera_button=QPushButton('打开摄像头');self.camera_button.clicked.connect(self.toggle_camera);controls.addWidget(self.camera_button)
  controls.addWidget(QLabel('间隔'));self.interval=QSpinBox();self.interval.setRange(100,1000);self.interval.setSingleStep(50);self.interval.setValue(300);self.interval.setSuffix(' ms');self.interval.setAccessibleName('音符间隔');self.interval.valueChanged.connect(self.controller.set_interval);controls.addWidget(self.interval)
  self.stop_button=QPushButton('全部止音');self.stop_button.setObjectName('danger');self.stop_button.setEnabled(False);self.stop_button.setToolTip('与左手握拳相同；Esc也可止音');self.stop_button.clicked.connect(self.stop_all);controls.addWidget(self.stop_button);layout.addLayout(controls)
  self.stop_shortcut=QShortcut(QKeySequence('Escape'),self);self.stop_shortcut.activated.connect(self.stop_all)
  content=QHBoxLayout();content.setSpacing(16);left=QVBoxLayout();left.setSpacing(12)
  self.preview=CameraView();left.addWidget(self.preview,1)
  self.camera_status=QLabel('摄像头尚未打开');self.camera_status.setObjectName('subtle');left.addWidget(self.camera_status);content.addLayout(left,1)
  side=QVBoxLayout();side.setSpacing(12);self.left=HandCard('左手 · 起始音',PALETTE['gold'],'握拳：立即止音');self.right=HandCard('右手 · 音符数',PALETTE['teal'],'握拳：播放一次《小星星》');side.addWidget(self.left);side.addWidget(self.right);content.addLayout(side);layout.addLayout(content,1)
  phrase=QFrame();phrase.setObjectName('card');row=QHBoxLayout(phrase);row.setContentsMargins(20,16,20,16)
  info=QVBoxLayout();info.addWidget(QLabel('本次音符'))
  self.sequence_label=QLabel('等待左右手数字');self.sequence_label.setStyleSheet('font-size:25px;font-weight:600;color:#d7b56d;');self.sequence_label.setWordWrap(True);info.addWidget(self.sequence_label)
  self.play_status=QLabel('等待手势');self.play_status.setObjectName('subtle');info.addWidget(self.play_status);row.addLayout(info,1)
  self.current_note=QLabel('—');self.current_note.setMinimumWidth(80);self.current_note.setAlignment(Qt.AlignmentFlag.AlignCenter);self.current_note.setStyleSheet('font-size:42px;color:#7fb7ad;');row.addWidget(self.current_note);layout.addWidget(phrase)
  rule=QLabel('每组只奏一遍，数字变化后再演奏；超过 7 回到 1。声音从开发板耳机输出。');rule.setObjectName('subtle');rule.setWordWrap(True);layout.addWidget(rule)
  self.message=QLabel('先连接开发板，再用两手分别比出 1—7。');self.message.setObjectName('message');self.message.setWordWrap(True);layout.addWidget(self.message)
  self.timer=QTimer(self);self.timer.timeout.connect(self.tick);self.timer.start(20);self.refresh_ports()
  if autostart:QTimer.singleShot(300,self.start_camera)

 def refresh_ports(self):
  selected=self.ports.currentData();self.ports.clear()
  if self.ports_provider:ports=self.ports_provider()
  else:
   from serial.tools import list_ports
   ports=list_ports.comports()
  for port in ports:self.ports.addItem(f'{port.device} · {port.description}',port.device)
  index=self.ports.findData(selected)
  if index>=0:self.ports.setCurrentIndex(index)
  if not self.ports.count():self.ports.addItem('未找到串口',None)

 def connect_board(self):
  if self.worker:
   self.disconnect_board();return
  port=self.ports.currentData()
  if not port:self.message.setText('未找到串口，请接好开发板后刷新。');return
  self.session+=1;self.worker=self.link_factory(port,SessionEvents(self.events,self.session));self.worker.start();self.connect_button.setText('握手中…');self.connect_button.setEnabled(False)
  self.link_status.setText('正在等待开发板应答');self.message.setText('正在确认开发板连接。')

 def disconnect_board(self):
  self.controller.stop(False,'已断开开发板');self.controller.set_ready(False,False,self.clock())
  worker=self.worker;self.worker=None;self.session+=1;self.connected=False;self.capabilities=0
  if worker:worker.disconnect();worker.join(1)
  self.connect_button.setEnabled(True);self.connect_button.setText('连接');self.link_status.setText('开发板未连接')
  self.stop_button.setEnabled(False)

 def on_link_event(self,event):
  if 'session_id' in event and event['session_id']!=self.session:return
  kind=event.get('type')
  if kind=='connected':
   self.connected=True;self.connect_button.setEnabled(True);self.connect_button.setText('断开');self.link_status.setText('已连接 · 正在确认演奏能力')
  elif kind=='status':
   self.capabilities=event.get('capabilities',0);self.board_playable=bool(event.get('playable'))
   ready=self.connected and bool(self.capabilities&2)
   self.stop_button.setEnabled(ready)
   self.controller.set_ready(ready,self.board_playable,self.clock())
   if not ready:self.link_status.setText('已连接 · 请加载最终整合码流');self.message.setText('当前码流缺少双手演奏所需的硬止音能力。')
   elif self.board_playable:self.link_status.setText('已连接 · 可以演奏');self.message.setText('左手起始音，右手数量；左拳止音，右拳《小星星》。')
   else:self.link_status.setText('已连接 · 演奏暂停');self.message.setText('请在板端切换到自由演奏并关闭图案；左手握拳仍可止音。')
  elif kind=='error':self.message.setText(event.get('message','连接异常'))
  elif kind=='disconnected':
   self.controller.stop(False,'开发板已断开');self.controller.set_ready(False,False,self.clock());self.worker=None;self.connected=False;self.capabilities=0
   self.connect_button.setEnabled(True);self.connect_button.setText('连接');self.link_status.setText('开发板未连接')
   self.stop_button.setEnabled(False)

 def dispatch(self,event):
  if not self.worker:return
  if event[0]=='stop':self.worker.emergency_stop()
  else:self.worker.set_note(event[1],event[2])

 def stop_all(self):
  self.controller.stop(True,'已全部止音');self.render_performance()

 def toggle_camera(self):
  if self.process:self.stop_camera()
  else:self.start_camera()

 def start_camera(self):
  if self.process:return
  if not VISION.is_file():self.message.setText('找不到视觉运行环境：'+str(VISION));return
  self.stopping=False;self.camera_failed=False;self.buffer.clear();self.stderr='';self.preview.clear('正在打开摄像头…')
  process=QProcess(self);self.process=process;process.setWorkingDirectory(str(ROOT))
  process.readyReadStandardOutput.connect(self.read_output);process.readyReadStandardError.connect(self.read_errors)
  process.finished.connect(self.camera_finished);process.errorOccurred.connect(self.camera_error)
  process.start(str(VISION),['-B',str(ROOT/'dual_camera.py')]);self.camera_button.setText('关闭摄像头')

 def read_output(self):
  if not self.process:return
  self.buffer.extend(bytes(self.process.readAllStandardOutput()))
  while b'\n' in self.buffer:
   line,_,rest=self.buffer.partition(b'\n');self.buffer=bytearray(rest)
   try:event=json.loads(line)
   except (ValueError,UnicodeDecodeError):continue
   self.on_camera_event(event)

 def read_errors(self):
  if self.process:self.stderr=(self.stderr+bytes(self.process.readAllStandardError()).decode('utf-8','replace'))[-6000:]

 def on_camera_event(self,event):
  kind=event.get('type')
  if kind=='ready':self.camera_name=event.get('camera_name','');self.camera_status.setText(self.camera_name)
  elif kind=='error':
   self.controller.stop(False,'识别暂停');self.message.setText(event.get('message','摄像头异常'));self.reset_cards('画面中断')
  elif kind=='frame':
   self.last_frame=self.clock();self.camera_name=event.get('camera_name',self.camera_name)
   try:self.preview.set_frame(base64.b64decode(event.get('jpeg',''),validate=True))
   except (ValueError,TypeError):pass
   hands=event.get('hands',{});self.left.set_result(hands.get('Left',{}));self.right.set_result(hands.get('Right',{}))
   self.provisional_deadlines={side:self.last_frame+max(0.,min(160.,item.get('provisional_for_ms',160.)))/1000 for side,item in hands.items() if item.get('provisional')}
   self.controller.observe(hands,self.last_frame)
   self.camera_status.setText(f'{self.camera_name or "摄像头"}　·　检测到 {event.get("detected_hands",0)} 只手')
   self.render_performance()

 def reset_cards(self,status='未检测到'):
  self.provisional_deadlines={};self.left.set_result(dict(status=status));self.right.set_result(dict(status=status))

 def stop_camera(self):
  self.controller.stop(False,'摄像头已关闭')
  if self.process:
   self.stopping=True;self.process.write(b'{"type":"stop"}\n');self.process.closeWriteChannel()
   if not self.process.waitForFinished(2000):self.process.kill();self.process.waitForFinished(1000)
  self.preview.clear('摄像头已关闭');self.reset_cards();self.camera_button.setText('打开摄像头')

 def camera_finished(self,*args):
  process=self.process;self.process=None
  if process:process.deleteLater()
  self.controller.stop(False,'摄像头已关闭' if self.stopping else '识别进程已退出');self.reset_cards();self.camera_button.setText('打开摄像头')
  if not self.stopping:self.message.setText('识别进程已退出，可重新打开摄像头。')

 def camera_error(self,error):
  if self.stopping:return
  self.camera_failed=True;self.controller.stop(False,'识别暂停');self.message.setText('摄像头进程启动失败，可重新打开。')
  if error==QProcess.ProcessError.FailedToStart:
   process=self.process;self.process=None
   if process:process.deleteLater()
   self.reset_cards('启动失败');self.camera_button.setText('打开摄像头')

 def render_performance(self):
  c=self.controller
  if c.sequence:self.sequence_label.setText(' → '.join(map(str,c.sequence[:14]))+(' …' if len(c.sequence)>14 else ''))
  self.current_note.setText(str(c.current) if c.current else '—')
  self.play_status.setText(f'{c.label}　{c.index+1} / {len(c.items)}' if c.playing else c.label)

 def tick(self):
  now=self.clock()
  while True:
   try:event=self.events.get_nowait()
   except queue.Empty:break
   self.on_link_event(event)
  for side,deadline in list(self.provisional_deadlines.items()):
   if now>=deadline:(self.left if side=='Left' else self.right).set_result(dict(status='等待重新确认'));del self.provisional_deadlines[side]
  if self.process and self.last_frame and now-self.last_frame>.65:self.reset_cards('画面中断')
  self.controller.tick(now);self.render_performance()

 def closeEvent(self,event):
  self.timer.stop();self.stop_camera();self.disconnect_board();event.accept()

def main():
 p=argparse.ArgumentParser();p.add_argument('--check',action='store_true');p.add_argument('--screenshot',type=Path);args=p.parse_args()
 if args.check or args.screenshot:os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
 app=QApplication(sys.argv[:1]);fonts=initialize_fonts(app);w=MainWindow(autostart=not(args.check or args.screenshot))
 if args.check:
  assert w.worker is None and w.process is None;w.close();print(json.dumps(dict(passed=True,fonts=fonts,camera=False,serial=False),ensure_ascii=False));return 0
 w.show()
 if args.screenshot:
  w.message.setText('离线界面预览 · 未打开摄像头或串口')
  w.left.set_result(dict(digit=6,status='界面示例'));w.right.set_result(dict(digit=4,status='界面示例'));w.sequence_label.setText('6 → 7 → 1 → 2')
  def snapshot():
   args.screenshot.parent.mkdir(parents=True,exist_ok=True);w.grab().save(str(args.screenshot));w.close();app.quit()
  QTimer.singleShot(150,snapshot)
 return app.exec()

if __name__=='__main__':raise SystemExit(main())
