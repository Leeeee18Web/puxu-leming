"""Local camera -> two digit results. Never imports serial or audio services."""
import argparse
import base64
import json
import math
import sys
import threading
import time
from pathlib import Path
from dual_tracking import DualHandTracker, observations_from_result
from vision_worker import load_runtime, resolve_camera, CONNECTIONS, check

def emit(data):print(json.dumps(data,ensure_ascii=False,separators=(',',':')),flush=True)

def run(camera,model,fps):
    selected=resolve_camera(camera)
    cv2,mp,np,recognizer=load_runtime(model)
    capture=None;stop=threading.Event();tracker=DualHandTracker()
    def control():
        for line in sys.stdin:
            try:
                if json.loads(line).get('type')=='stop':break
            except (ValueError,TypeError):continue
        stop.set()
    threading.Thread(target=control,daemon=True).start()
    try:
        capture=cv2.VideoCapture(selected.index,cv2.CAP_DSHOW if sys.platform=='win32' else cv2.CAP_ANY)
        if not capture.isOpened():raise RuntimeError(f'无法打开 {selected.name}，请关闭其他正在使用摄像头的程序')
        capture.set(cv2.CAP_PROP_FRAME_WIDTH,640);capture.set(cv2.CAP_PROP_FRAME_HEIGHT,480)
        capture.set(cv2.CAP_PROP_BUFFERSIZE,1)
        emit(dict(type='ready',camera_name=selected.name,camera_index=selected.index))
        last_ms=-1
        while not stop.is_set():
            started=time.monotonic();ok,frame=capture.read()
            if not ok:raise RuntimeError('摄像头画面中断，请关闭后重新打开')
            if stop.is_set():break
            frame=cv2.flip(frame,1)
            rgb=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
            timestamp=max(last_ms+1,int(started*1000));last_ms=timestamp
            result=recognizer.recognize_for_video(mp.Image(image_format=mp.ImageFormat.SRGB,data=rgb),timestamp)
            observations=observations_from_result(result)
            hands=tracker.update(observations,time.monotonic())
            h,w=frame.shape[:2]
            for index,landmarks in enumerate(result.hand_landmarks):
                item=next((o for o in observations if o['index']==index),{})
                label=item.get('label','Unknown');color=(206,195,72) if label=='Left' else (88,192,244) if label=='Right' else (150,150,150)
                if len(landmarks)!=21 or any(not math.isfinite(p.x) or not math.isfinite(p.y) for p in landmarks):continue
                coords=[(round(p.x*w),round(p.y*h)) for p in landmarks]
                for a,b in CONNECTIONS:cv2.line(frame,coords[a],coords[b],color,2,cv2.LINE_AA)
                for point in coords:cv2.circle(frame,point,3,color,-1,cv2.LINE_AA)
                digit=hands.get(label,{}).get('digit',0)
                title=f'{label.upper()}  {digit if digit else "?"}'
                x=max(5,min(w-165,min(p[0] for p in coords)));y=max(24,min(h-6,min(p[1] for p in coords)-12))
                cv2.putText(frame,title,(x,y),cv2.FONT_HERSHEY_SIMPLEX,.65,color,2,cv2.LINE_AA)
            ok,jpeg=cv2.imencode('.jpg',frame,[cv2.IMWRITE_JPEG_QUALITY,80])
            if not ok:raise RuntimeError('摄像头预览编码失败')
            emit(dict(type='frame',jpeg=base64.b64encode(jpeg).decode('ascii'),hands=hands,
                      detected_hands=len(result.hand_landmarks),camera_name=selected.name,
                      processing_ms=round((time.monotonic()-started)*1000,1)))
            stop.wait(max(0.,1/fps-(time.monotonic()-started)))
    finally:
        tracker.reset()
        if capture is not None:capture.release()
        recognizer.close()

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--camera',type=int,default=None)
    parser.add_argument('--model',type=Path,default=Path(__file__).parent/'models/gesture_recognizer.task')
    parser.add_argument('--fps',type=float,default=15);parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    try:
        if args.check:check(args.model)
        else:run(args.camera,args.model,max(1.,min(30.,args.fps)))
        return 0
    except Exception as exc:
        emit(dict(type='error',message=str(exc)))
        error_log=Path(__file__).resolve().parents[1]/'build/errors.md'
        error_log.parent.mkdir(parents=True,exist_ok=True)
        with error_log.open('a',encoding='utf-8') as out:
            out.write('\n\n### DUALHAND-CAMERA-'+time.strftime('%Y%m%d_%H%M%S')+'\n- 原始错误：'+repr(exc)+'；条件本地双手摄像头预览，原因未确认；不涉及串口/音频/板卡。修复及复验待定位。\n')
        return 1

if __name__=='__main__':raise SystemExit(main())
