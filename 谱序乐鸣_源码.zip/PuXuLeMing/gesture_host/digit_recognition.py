"""Preview-only 4/5/6 evidence. Original host classifier and model stay intact.

Scores are heuristic evidence, not calibrated correctness probabilities.
All directions use a hand-local 3-D frame, never screen left/right.
"""
import math
from vision_worker import classify_with_evidence as legacy_classify, _best_category, MODEL_GESTURES


def _sub(a,b):return tuple(x-y for x,y in zip(a,b))
def _dot(a,b):return sum(x*y for x,y in zip(a,b))
def _norm(a):return math.sqrt(_dot(a,a))
def _unit(a):
    n=_norm(a)
    return tuple(x/n for x in a) if n>1e-9 else None
def _angle(a,b,c):
    u=_unit(_sub(a,b));v=_unit(_sub(c,b))
    return math.degrees(math.acos(max(-1.,min(1.,_dot(u,v))))) if u and v else 0.


def _six_shape(p,fingers,u,v,width,length):
    """Thumb+pinky or thumb-only, with definite folded index/middle/ring.

    A thumb's bent end joint alone must not veto either six shape. An
    ambiguous or extended index is never silently treated as folded.
    """
    closed=lambda f:f['chord']<=135 and (f['radial']<1.06 or f['advance']<.25)
    if not all(closed(f) for f in fingers[:3]):return None
    if not (fingers[3]['extended'] or closed(fingers[3])):return None
    root=_unit(_sub(p[2],p[1]))
    if root is None:return None
    lateral_tip=_dot(_sub(p[4],p[5]),u)/width
    lateral_middle=_dot(_sub(p[3],p[5]),u)/width
    thumb_distance=math.dist(p[4],p[5])/width
    outward=(_dot(root,u)>=.45 and lateral_middle>=.20
             and lateral_tip>=.20 and thumb_distance>=.45)
    chain=sum(math.dist(p[i],p[i+1]) for i in (1,2,3))
    straightness=math.dist(p[1],p[4])/max(chain,1e-9)
    distal_advance=_dot(_sub(p[4],p[2]),v)/length
    tip_long=_dot(_sub(p[4],p[5]),v)/length
    raised=tip_long>.25 and distal_advance>.35 and straightness>.83
    if not (outward or raised):return None
    return dict(form='thumb_pinky' if fingers[3]['extended'] else 'thumb_only',
                thumb_outward=outward,thumb_raised=raised,thumb_straightness=straightness)


def recognize_digit(landmarks,categories=()):
    """Return classification plus numeric reasons useful in local diagnostics."""
    details={}
    def result(pose='unknown',score=0.,source='关键点质量不足',reason='invalid_landmarks'):
        return dict(pose=pose,confidence=score,source=source,reason=reason,diagnostics=details)
    try:
        if len(landmarks)!=21:return result()
        p=[tuple(float(x) for x in point[:3]) for point in landmarks]
        if any(len(v)!=3 or not all(math.isfinite(x) for x in v) for v in p):return result()
    except (TypeError,ValueError,OverflowError):return result()

    width=math.dist(p[5],p[17]);length=math.dist(p[0],p[9])
    if min(width,length)<1e-6:return result()
    v=_unit(_sub(p[9],p[0]));raw_u=_sub(p[5],p[17])
    perpendicular=tuple(raw_u[i]-_dot(raw_u,v)*v[i] for i in range(3))
    u=_unit(perpendicular)
    details['palm']=dict(width=width,length=length,transverse_quality=_norm(perpendicular)/width)
    if u is None or _norm(perpendicular)/width<.25 or not .2<width/length<1.8:
        return result(source='掌部形状待确认',reason='palm_quality')

    fingers=[]
    for mcp in (5,9,13,17):
        chord=_angle(p[mcp],p[mcp+1],p[mcp+3])
        pip=_angle(p[mcp],p[mcp+1],p[mcp+2])
        dip=_angle(p[mcp+1],p[mcp+2],p[mcp+3])
        radial=math.dist(p[0],p[mcp+3])/max(math.dist(p[0],p[mcp+1]),1e-9)
        advance=_dot(_sub(p[mcp+3],p[mcp]),v)/length
        chain=sum(math.dist(p[i],p[i+1]) for i in range(mcp,mcp+3))
        straightness=math.dist(p[mcp],p[mcp+3])/max(chain,1e-9)
        strong=chord>=148 and radial>1.06
        # Mild curvature needs joint-chain and distal extension evidence;
        # a folded fourth finger must never promote a three into four/five.
        relaxed=(chord>=138 and pip>=140 and dip>=115 and radial>1.10
                 and advance>.35 and straightness>.83)
        fingers.append(dict(mcp=mcp,chord=chord,pip=pip,dip=dip,radial=radial,
                            advance=advance,straightness=straightness,
                            strong=strong,extended=strong or relaxed,
                            folded=chord<=135 or radial<.98))
    details['fingers']=fingers
    open_group=all(f['extended'] for f in fingers) and sum(f['strong'] for f in fingers)>=2
    category,model_score=_best_category(categories)
    details['model']=dict(category=category,score=model_score)
    legacy_pose,legacy_score,legacy_source=legacy_classify(p,categories)
    # Hard negative evidence precedes all soft thumb/finger early returns.
    # The original three-tip pinch exception to Closed_Fist remains intact.
    if category=='Closed_Fist' and model_score>=.72:
        return result(legacy_pose,legacy_score,legacy_source,
                      'fist' if legacy_pose=='fist' else 'confirmed')

    if not open_group:
        # A curled three-tip pinch can resemble three folded long fingers.
        # Preserve the existing, more specific seven shape before adding six.
        if legacy_pose=='7':return result(legacy_pose,legacy_score,legacy_source,'confirmed')
        six=_six_shape(p,fingers,u,v,width,length)
        if six:
            details['six']=six
            mapped=MODEL_GESTURES.get(category) if model_score>=.72 else None
            if mapped and mapped!='6':
                return result(source='模型与六手形不一致',reason='model_conflict')
            score=.80 if fingers[3]['strong'] or fingers[3]['folded'] else .78
            if mapped=='6':score=.6*model_score+.4*score
            return result('6',score,'拇指与收指关节联合判断','confirmed')
        pose,score,source=legacy_pose,legacy_score,legacy_source
        if pose=='unknown' and (category=='Open_Palm' or sum(f['extended'] for f in fingers)>=3):
            if any(f['folded'] for f in fingers):
                return result(source='收指手形与张掌不一致',reason='model_conflict')
            return result(source='长指伸展待确认',reason='long_fingers_uncertain')
        return result(pose,score,source,'confirmed' if pose!='unknown' else 'other_shape')

    mapped=MODEL_GESTURES.get(category) if model_score>=.72 else None
    if mapped and mapped!='5':
        return result(source='模型与手形不一致',reason='model_conflict')
    root=_unit(_sub(p[2],p[1]))
    if root is None:return result(source='拇指关节待确认',reason='thumb_uncertain')
    root_lateral=_dot(root,u)
    middle_direction=_unit(_sub(p[3],p[2]))
    middle_direction_lateral=_dot(middle_direction,u) if middle_direction else 0.
    base=_dot(_sub(p[2],p[5]),u)/width
    middle=_dot(_sub(p[3],p[5]),u)/width
    tip=_dot(_sub(p[4],p[5]),u)/width
    reach=math.dist(p[4],p[5])/width
    tip_long=_dot(_sub(p[4],p[5]),v)/length
    details['thumb']=dict(root_lateral=root_lateral,middle_direction_lateral=middle_direction_lateral,base_lateral=base,
        middle_lateral=middle,tip_lateral=tip,tip_distance=reach,tip_longitudinal=tip_long)
    root_open=root_lateral>=.50 and base>=.12 and middle>=.20
    open_thumb=(root_open and tip>=.12 and reach>=.30)
    # Strongly spread tip still requires outward root/base evidence.
    open_thumb=open_thumb or (tip>=.45 and reach>=.55 and middle>=.25
                             and (root_lateral>.15 or middle_direction_lateral>.30))
    root_tucked=root_lateral<=.30 and base<=.15
    tucked_thumb=(root_tucked and reach<1.20 and
        (tip<=.18 or (middle<=.10 and tip_long<=.15 and tip<=.45)))
    tucked_thumb=tucked_thumb or (middle_direction_lateral<-.30 and middle<=.15
                                 and tip<=.10 and reach<1.20)
    if open_thumb and not tucked_thumb:pose='5'
    elif tucked_thumb and not open_thumb:pose='4'
    else:return result(source='拇指张收待确认',reason='thumb_uncertain')

    finger_score=min(.90 if f['strong'] else .78 for f in fingers)
    thumb_score=.82 if pose=='5' else .84
    score=min(finger_score,thumb_score)
    if mapped=='5':score=.6*model_score+.4*score
    return result(pose,score,'拇指根部与四指联合判断','confirmed')
