"""Finite gesture-to-note schedules. Sends control events; never generates PC audio."""

def selected_notes(start,count):
 if type(start) is not int or type(count) is not int or not 1<=start<=7 or not 1<=count<=7:
  raise ValueError('起始音和数量须为1至7')
 return tuple((start-1+i)%7+1 for i in range(count))

_MELODY=(1,1,5,5,6,6,5,4,4,3,3,2,2,1,5,5,4,4,3,3,2,5,5,4,4,3,3,2,1,1,5,5,6,6,5,4,4,3,3,2,2,1)
TWINKLE=tuple((note,2 if index%7==6 else 1) for index,note in enumerate(_MELODY))

class PerformanceController:
 def __init__(self,send,interval_ms=300,is_acked=None):
  self.send=send;self.is_acked=is_acked or (lambda note:True);self.set_interval(interval_ms)
  self.linked=False;self.playable=False;self.playing=False
  self.last_pair=None;self.left_fist=False;self.right_armed=True
  self.items=();self.sequence=();self.label='等待手势';self.index=0
  self.phase='idle';self.current=0;self.deadline=0.;self.slot_end=0.
  self.last_frame=None;self.last_tick=None;self.starts=0

 def set_interval(self,milliseconds):
  if type(milliseconds) is not int or not 100<=milliseconds<=1000:raise ValueError('间隔须为100至1000毫秒')
  self.interval=milliseconds/1000.

 def set_ready(self,linked,playable,now):
  old=self.linked and self.playable;previous_link=self.linked
  self.linked=bool(linked);self.playable=bool(playable)
  if self.linked and not previous_link:self.left_fist=False
  if old and not (self.linked and self.playable):self.stop(False,'演奏已暂停')

 def stop(self,hard=False,label='已停止'):
  if hard and not self.linked:label='待连接 · 无法发送止音指令'
  if hard and self.linked:self.send(('stop',))
  elif self.current or self.playing:self.send(('note',0,0))
  self.current=0;self.playing=False;self.phase='idle';self.items=();self.label=label

 def _start(self,items,label,now):
  if self.current:self.send(('note',0,0))
  self.items=tuple(items);self.sequence=tuple(note for note,_ in self.items)
  self.index=0;self.label=label;self.playing=True;self.starts+=1
  self._on(now)

 def _on(self,now):
  self.current,beats=self.items[self.index]
  self.phase='on_wait';self.send(('note',self.current,100))
  if self.is_acked(self.current):self._confirmed_on(now)

 def _confirmed_on(self,now):
  duration=self.interval*self.items[self.index][1]
  self.slot_end=now+duration;self.deadline=self.slot_end-min(.08,duration*.25)
  self.phase='on'

 def observe(self,hands,now):
  self.last_frame=now
  left=hands.get('Left',{});right=hands.get('Right',{})
  lf=left.get('present',False) and left.get('pose')=='fist'
  rf=right.get('present',False) and right.get('pose')=='fist'
  # A fist is rearmed only by a confirmed non-fist digit, never by an
  # uncertain/missing frame. Holding a fist cannot restart Twinkle.
  right_digit=right.get('digit',0)
  if right.get('present') and type(right_digit) is int and 1<=right_digit<=7 and not right.get('provisional'):
   self.right_armed=True
  if lf:
   if not self.left_fist:self.stop(True,'左手握拳 · 已止音')
   self.left_fist=True
   if rf:self.right_armed=False
   return
  left_digit=left.get('digit',0)
  if left.get('present') and type(left_digit) is int and 1<=left_digit<=7 and not left.get('provisional'):
   self.left_fist=False
  if rf:
   armed=self.right_armed;self.right_armed=False
   if armed and self.linked and self.playable:self._start(TWINKLE,'小星星',now)
   return
  if not (self.linked and self.playable):return
  if not (left.get('present') and right.get('present')):return
  if left.get('provisional') or right.get('provisional'):return
  try:notes=selected_notes(left_digit,right_digit)
  except ValueError:return
  pair=(left_digit,right_digit)
  # A one-shot song does not require holding the fist for its whole length.
  # Consume subsequent numeric poses until it finishes; the left fist still
  # takes priority above, and a newly rearmed right fist can restart it.
  if self.playing and self.label=='小星星':self.last_pair=pair;return
  if pair!=self.last_pair:
   self.last_pair=pair;self._start(((n,1) for n in notes),'数字组选音',now)

 def tick(self,now):
  if self.last_tick is not None and now<self.last_tick:
   self.stop(False,'计时已重置');self.last_tick=now;return
  self.last_tick=now
  if not self.playing:return
  if self.last_frame is None or now-self.last_frame>.65:
   self.stop(False,'识别暂停');return
  if not (self.linked and self.playable):self.stop(False,'演奏已暂停');return
  if self.phase=='on_wait':
   self.send(('note',self.current,100))
   if self.is_acked(self.current):self._confirmed_on(now)
   return
  if self.phase=='off_wait':
   if not self.is_acked(0):return
   self.phase='gap';self.deadline=max(self.slot_end,now+.02)
   return
  if now>=self.deadline:
   if self.phase=='on':
    self.send(('note',0,0));self.current=0;self.phase='gap' if self.is_acked(0) else 'off_wait'
    # Never catch up overdue notes in a loop; leave a real off interval.
    self.deadline=max(self.slot_end,now+.02)
   else:
    self.index+=1
    if self.index>=len(self.items):
     self.playing=False;self.phase='idle';self.current=0;self.label='本组已完成 · 数字变化后再演奏'
    else:self._on(now)
  elif self.phase=='on':
   # Renew only the currently scheduled note's lease. The serial worker
   # coalesces identical values, while a long song note stays alive.
   self.send(('note',self.current,100))
