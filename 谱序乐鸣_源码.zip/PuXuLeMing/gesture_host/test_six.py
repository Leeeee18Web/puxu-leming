"""Six aliases with relaxed thumb joints; prevent confusion with seven/fist."""
import math
import unittest
from legacy_vision_tests import hand, POSES
from test_four_five import observed, relaxed


def relaxed_thumb(fingers):
    p=hand(fingers,True);p[3]=(.18,.67,.01)
    return p


class SixRecognitionTests(unittest.TestCase):
    def test_shaka_allows_a_bent_thumb_end_joint(self):
        self.assertEqual(observed(relaxed_thumb((0,0,0,1)))['pose'],'6')

    def test_thumb_only_allows_a_bent_thumb_end_joint(self):
        self.assertEqual(observed(relaxed_thumb((0,0,0,0)))['pose'],'6')

    def test_shaka_accepts_naturally_relaxed_little_finger(self):
        self.assertEqual(observed(relaxed(POSES['6'],17))['pose'],'6')

    def test_thumb_parallel_to_palm_axis_is_six_without_model_rescue(self):
        p=hand((0,0,0,0),False)
        p[2:5]=[(.40,.61,0),(.39,.49,0),(.39,.36,0)]
        self.assertEqual(observed(p)['pose'],'6')

    def test_both_six_forms_are_stable_under_rotation_and_mirror(self):
        for p in (relaxed_thumb((0,0,0,1)),relaxed_thumb((0,0,0,0))):
            for a in (0.,.8,2.4):
                for mirror in (-1,1):
                    q=[]
                    for x,y,z in p:
                        u=mirror*(x*math.cos(a)-y*math.sin(a))*.4
                        v=(x*math.sin(a)+y*math.cos(a))*.4
                        q.append((u+3,v*.6-z*.8-2,v*.8+z*.6+1))
                    self.assertEqual(observed(q)['pose'],'6')

    def test_pointing_index_does_not_become_six(self):
        self.assertEqual(observed(POSES['7'])['pose'],'7')
        p=hand((1,0,0,1),True)
        self.assertEqual(observed(p,'ILoveYou')['pose'],'7')

    def test_curled_three_tip_pinch_keeps_seven_priority(self):
        p=hand((0,0,0,0),True)
        p[6:9]=[(.39,.40,0),(.34,.39,0),(.30,.43,0)]
        p[10:13]=[(.475,.40,0),(.40,.39,0),(.34,.43,0)]
        p[4]=(.29,.43,0)
        for category in ('None','Closed_Fist','ILoveYou'):
            with self.subTest(category=category):self.assertEqual(observed(p,category)['pose'],'7')

    def test_ambiguous_index_does_not_become_six(self):
        p=relaxed_thumb((0,0,0,1))
        p[8]=(.39+.18*math.sin(math.radians(35)),.40-.18*math.cos(math.radians(35)),0)
        self.assertNotEqual(observed(p)['pose'],'6')

    def test_pinky_only_and_fist_are_not_six(self):
        self.assertNotEqual(observed(hand((0,0,0,1),False))['pose'],'6')
        self.assertEqual(observed(hand((0,0,0,0),False))['pose'],'fist')

    def test_explicit_model_conflicts_still_reject_new_six_variants(self):
        for label in ('ILoveYou','Victory','Open_Palm'):
            self.assertNotEqual(observed(relaxed_thumb((0,0,0,1)),label)['pose'],'6')
        self.assertEqual(observed(relaxed_thumb((0,0,0,1)),'Closed_Fist')['pose'],'fist')

    def test_original_straight_thumb_six_forms_remain_supported(self):
        self.assertEqual(observed(POSES['6'])['pose'],'6')
        self.assertEqual(observed(hand((0,0,0,0),True),'Thumb_Up')['pose'],'6')


if __name__=='__main__':unittest.main()
