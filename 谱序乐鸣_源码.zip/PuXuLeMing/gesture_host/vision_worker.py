"""Opt-in hand notes; no serial access or PC audio synthesis.

stdin JSONL: {"type":"enable","enabled":true/false}, {"type":"stop"}.
stdout JSONL: frame/jpeg/gesture/tracking, note/index/velocity/timestamp, error.
Only the parent app sends notes to the FPGA. --check never opens a camera.
World-coordinate distances/angles preserve the Project3 mirror/rotation policy.
"""
from __future__ import annotations

import argparse
import base64
from collections import Counter, deque
import hashlib
import json
import math
import os
from pathlib import Path
import queue
import sys
import threading
import time

from camera_source import resolve_camera, enumerate_dshow_cameras, choose_camera

DEFAULT_PYTHON = Path(sys.executable)
DEFAULT_MODEL = Path(__file__).resolve().parent/'models'/'gesture_recognizer.task'
MODEL_URL = ('https://storage.googleapis.com/mediapipe-models/gesture_recognizer/'
             'gesture_recognizer/float16/1/gesture_recognizer.task')
MODEL_GESTURES = {'Pointing_Up':'1','Victory':'2','Open_Palm':'5',
                  'Thumb_Up':'6','ILoveYou':'7'}
MODEL_GESTURE_NAMES = {'Pointing_Up':'食指向上','Victory':'V 手势',
                       'Open_Palm':'张开手掌','Thumb_Up':'拇指向上',
                       'ILoveYou':'爱心手势','Closed_Fist':'握拳'}
LABELS = {'1':'一 · C4','2':'二 · D4','3':'三 · E4','4':'四 · F4',
          '5':'五 · G4','6':'六 · A4','7':'七 · B4',
          'fist':'握拳 · 止音','unknown':'未确认 · 止音'}
NOTES = ('C4','D4','E4','F4','G4','A4','B4')
CONNECTIONS = [(0,1),(1,2),(2,3),(3,4),(0,5),(5,6),(6,7),(7,8),
               (5,9),(9,10),(10,11),(11,12),(9,13),(13,14),(14,15),
               (15,16),(13,17),(0,17),(17,18),(18,19),(19,20)]


def _classify_geometry(landmarks):
    """Conservative extension gestures from normalized 3-D hand landmarks."""
    try:
        if len(landmarks) != 21:
            return 'unknown',0.
        p = [tuple(float(v) for v in point[:3]) for point in landmarks]
        if any(len(point) != 3 or not all(math.isfinite(v) for v in point) for point in p):
            return 'unknown',0.
    except (TypeError, ValueError, OverflowError):
        return 'unknown',0.

    def distance(a,b): return math.dist(p[a],p[b])

    def angle(a,b,c):
        u=[p[a][i]-p[b][i] for i in range(3)]
        v=[p[c][i]-p[b][i] for i in range(3)]
        norm=math.sqrt(sum(x*x for x in u)*sum(x*x for x in v))
        if norm<1e-12:return 0.
        return math.degrees(math.acos(max(-1.,min(1.,sum(x*y for x,y in zip(u,v))/norm))))

    palm=distance(5,17)
    if distance(0,9)<1e-6 or palm<1e-6:return 'unknown',0.

    def finger_state(mcp):
        bend=angle(mcp,mcp+1,mcp+3)
        radial=distance(0,mcp+3)/max(distance(0,mcp+1),1e-9)
        if bend>=148 and radial>1.06:
            return True,.74+.24*max(0.,min(1.,min((bend-148)/32,(radial-1.06)/.44)))
        if bend<=135 or radial<.98:
            margin=max((135-bend)/35,(.98-radial)/.32)
            return False,.74+.24*max(0.,min(1.,margin))
        return None,.35

    finger_evidence=[finger_state(mcp) for mcp in (5,9,13,17)]
    fingers=[state for state,_ in finger_evidence]
    # Pinch is checked before straight/fold classification: its first two
    # fingers are intentionally bent. Require tips away from the folded fist.
    pinch_error=max(distance(4,8),distance(4,12),distance(8,12))/palm
    pinch=pinch_error<.38
    axis=[(p[9][i]-p[0][i])/distance(0,9) for i in range(3)]
    # A pinch bends the first two fingers: tips need to be distal to their
    # knuckles, not farther from the wrist than their straightened PIP joints.
    raised=min(sum((p[tip][i]-p[mcp][i])*axis[i] for i in range(3))
               for tip,mcp in ((8,5),(12,9)))>.15*palm
    if pinch and raised and fingers[2:]==[False,False]:
        return '7',.76+.22*max(0.,1.-pinch_error/.38)
    if None in fingers:return 'unknown',min(score for state,score in finger_evidence)
    if fingers==[True,True,True,True]:
        # Four and five differ by abduction at the thumb base, not by whether
        # its distal joint is straight. The palm's transverse axis survives
        # camera mirroring, scale changes and 3-D hand rotation.
        abduction=sum((p[4][i]-p[5][i])*(p[5][i]-p[17][i])
                      for i in range(3))/(palm*palm)
        finger_score=min(score for _,score in finger_evidence)
        if abduction>=.28 and distance(4,5)>=.55*palm:
            return '5',min(finger_score,.74+.24*min(1.,(abduction-.28)/.7))
        if abduction<=.10 and distance(4,5)<1.2*palm:
            return '4',min(finger_score,.74+.24*min(1.,(.10-abduction)/.6))
        return 'unknown',.35
    thumb_angle=angle(2,3,4)
    spread=distance(4,5)/max(distance(2,5),1e-9)
    if thumb_angle>=150 and spread>1.35:
        thumb=True
        thumb_conf=.74+.24*max(0.,min(1.,min((thumb_angle-150)/25,(spread-1.35)/.6)))
    elif (thumb_angle<135 and distance(4,5)<1.1*palm) or spread<1.1:
        thumb=False
        thumb_conf=.74+.24*max(0.,min(1.,max((135-thumb_angle)/35,(1.1-spread)/.35)))
    else:
        # A relaxed thumb should not veto three clearly raised long fingers.
        if fingers==[True,True,True,False]:
            return '3',min(score for _,score in finger_evidence)
        return 'unknown',.35
    pattern=tuple(fingers)
    confidence=min(thumb_conf,*(score for _,score in finger_evidence))
    if not thumb:
        return ({(True,False,False,False):'1',(True,True,False,False):'2',
                 (True,True,True,False):'3',(True,True,True,True):'4',
                 (False,False,False,False):'fist'}.get(pattern,'unknown'),confidence)
    return ({(True,True,True,True):'5',(False,False,False,True):'6',
             (False,False,False,False):'6',(True,False,False,True):'7'}.get(pattern,'unknown'),confidence)


def _best_category(categories):
    """Accept MediaPipe Category objects or plain pairs in isolated tests."""
    best_name,best_score='None',0.
    for item in categories or ():
        if isinstance(item,dict):
            name=item.get('category_name',item.get('display_name','None'))
            score=item.get('score',0.)
        elif isinstance(item,(tuple,list)) and len(item)>=2:
            name,score=item[0],item[1]
        else:
            name=getattr(item,'category_name',None) or getattr(item,'display_name',None) or 'None'
            score=getattr(item,'score',0.)
        try:score=float(score)
        except (TypeError,ValueError,OverflowError):continue
        if math.isfinite(score) and score>best_score:
            best_name,best_score=str(name),score
    return best_name,max(0.,min(1.,best_score))


def classify_with_evidence(landmarks,categories=(),minimum_score=.72):
    """Combine Google's canned classifier with conservative custom 1..7 poses.

    MediaPipe aliases add familiar forms (thumb-up for A4 and I-love-you for
    B4). The existing counted/pinch poses remain available when the canned
    model has no strong conflicting label. Conflicts fail closed.
    """
    geometric,geometry_score=_classify_geometry(landmarks)
    category,model_score=_best_category(categories)
    # Custom counts and pinch poses overlap canned labels; resolve only
    # these explicit overlaps from the complete landmark shape.
    if geometry_score>=minimum_score and (geometric,category) in (
            ('3','Victory'),('4','Open_Palm'),('7','Closed_Fist')):
        return geometric,geometry_score,'关键点扩展手势'
    if category=='Closed_Fist' and model_score>=minimum_score:
        return 'fist',model_score,'MediaPipe · 握拳'
    mapped=MODEL_GESTURES.get(category) if model_score>=minimum_score else None
    if mapped:
        if mapped=='5' and geometric=='unknown':
            return 'unknown',geometry_score,'拇指位置未确认'
        if geometric in (mapped,'unknown'):
            score=model_score if geometric=='unknown' else .6*model_score+.4*geometry_score
            return mapped,score,f'MediaPipe · {MODEL_GESTURE_NAMES[category]}'
        return 'unknown',model_score,'模型与关键点不一致'
    if geometric in tuple('1234567') and geometry_score>=minimum_score:
        if category not in ('None','') and model_score>=minimum_score:
            return 'unknown',model_score,'模型与关键点不一致'
        return geometric,geometry_score,'关键点扩展手势'
    if geometric=='fist' and geometry_score>=minimum_score:
        return 'fist',geometry_score,'关键点 · 握拳'
    return 'unknown',max(model_score,geometry_score),'未确认'


def classify_gesture(landmarks,categories=()):
    """Compatibility wrapper returning only the gesture code."""
    return classify_with_evidence(landmarks,categories)[0]


class GestureStabilizer:
    """Vote with a consecutive-frame switch; invalid tracking stops at once."""
    def __init__(self,window=3,required=2,minimum_score=.48):
        if window<1 or not 1<=required<=window:raise ValueError('invalid vote window')
        self.samples=deque(maxlen=window);self.required=required
        self.minimum_score=minimum_score;self.stable='unknown';self.last_time=None

    def reset(self):
        self.samples.clear();self.stable='unknown';self.last_time=None

    def update(self,pose,confidence,tracking,now=None):
        if not tracking or pose in ('unknown','fist') or not math.isfinite(confidence) or confidence<self.minimum_score:
            self.reset()
            return pose if tracking and pose=='fist' else 'unknown',0.
        if now is not None and self.last_time is not None and (now<=self.last_time or now-self.last_time>.2):
            self.samples.clear();self.stable='unknown'
        self.last_time=now
        previous=self.samples[-1][0] if self.samples else None
        self.samples.append((pose,confidence))
        counts=Counter(name for name,_ in self.samples)
        winner,count=max(counts.items(),key=lambda pair:(pair[1],pair[0]))
        if count>=self.required and (self.required==1 or pose==previous) and pose==winner:self.stable=winner
        elif not any(name==self.stable for name,_ in self.samples):self.stable='unknown'
        if self.stable=='unknown':return 'unknown',0.
        scores=[score for name,score in self.samples if name==self.stable]
        return self.stable,sum(scores)/len(scores)


class AirKeyboardMapper:
    """Map mirrored preview x to seven notes with smoothing and lane hysteresis."""
    def __init__(self,smoothing=.35,hysteresis=.045):
        self.smoothing=smoothing;self.hysteresis=hysteresis;self.x=None;self.lane=None

    def reset(self):self.x=None;self.lane=None

    def update(self,x):
        if not math.isfinite(x):self.reset();return 0
        x=max(0.,min(1.,float(x)))
        self.x=x if self.x is None else self.smoothing*x+(1-self.smoothing)*self.x
        target=min(6,int(self.x*7))
        if self.lane is None:self.lane=target
        elif target>self.lane:
            boundary=(self.lane+1)/7+self.hysteresis
            if self.x>=boundary:self.lane+=1
        elif target<self.lane:
            boundary=self.lane/7-self.hysteresis
            if self.x<=boundary:self.lane-=1
        return self.lane+1


class ControlGestureTrigger:
    """One command per stable left-hand control pose; open palm rearms it."""
    COMMANDS={'Thumb_Up':'octave_up','Thumb_Down':'octave_down','Victory':'timbre_next'}
    def __init__(self,window=3,required=2,minimum_score=.76):
        self.window=window;self.required=required;self.minimum_score=minimum_score
        self.samples=deque(maxlen=window);self.armed=True;self.neutral_frames=0

    def reset(self):
        self.samples.clear();self.armed=True;self.neutral_frames=0

    def update(self,category,score,tracking=True):
        if not tracking:
            self.reset();return None
        try:score=float(score)
        except (TypeError,ValueError,OverflowError):score=0.
        if not math.isfinite(score):score=0.
        if category in self.COMMANDS and score>=self.minimum_score:
            self.neutral_frames=0;self.samples.append(category)
            if self.armed and self.samples.count(category)>=self.required:
                self.armed=False
                return self.COMMANDS[category]
            return None
        self.samples.clear()
        if category in ('None','Open_Palm','unknown') or score<.35:
            self.neutral_frames+=1
            if self.neutral_frames>=2:self.armed=True
        else:
            self.neutral_frames=0
        return None


class PinchPlucker:
    """Capture a lane on pinch, then emit one short note after a clean release."""
    def __init__(self,stable_frames=2,pulse_seconds=.12):
        self.stable_frames=stable_frames;self.pulse_seconds=pulse_seconds
        self.close_frames=0;self.open_frames=0;self.pinching=False
        self.selected_lane=0;self.pulse_note=0;self.pulse_until=0.;self.last_time=None

    def reset(self):
        self.close_frames=0;self.open_frames=0;self.pinching=False
        self.selected_lane=0;self.pulse_note=0;self.pulse_until=0.;self.last_time=None

    def update(self,pinched,lane,tracking,now):
        if not tracking or not math.isfinite(now):
            self.reset();return 0
        if self.last_time is not None and (now<=self.last_time or now-self.last_time>.25):
            self.reset()
        self.last_time=now
        lane=max(0,min(7,int(lane)))
        if pinched:
            self.open_frames=0;self.close_frames+=1
            if not self.pinching and self.close_frames>=self.stable_frames:
                self.pinching=True;self.selected_lane=lane
            elif self.pinching and lane:self.selected_lane=lane
        else:
            self.close_frames=0
            if self.pinching:
                self.open_frames+=1
                if self.open_frames>=self.stable_frames:
                    self.pulse_note=self.selected_lane
                    self.pulse_until=now+self.pulse_seconds
                    self.pinching=False;self.open_frames=0
            else:self.open_frames=0
        if now>=self.pulse_until:self.pulse_note=0
        return self.pulse_note


def _is_pinched(landmarks,threshold=.30):
    """Scale thumb-index tip distance by palm width for camera-distance tolerance."""
    try:
        if len(landmarks)!=21:return False
        p=[(float(q.x),float(q.y)) if hasattr(q,'x') else (float(q[0]),float(q[1])) for q in landmarks]
        if any(not all(math.isfinite(v) for v in q) for q in p):return False
        palm=math.dist(p[5],p[17])
        return palm>1e-5 and math.dist(p[4],p[8])/palm<=threshold
    except (TypeError,ValueError,IndexError,OverflowError):
        return False


class NoteGate:
    """150ms stable hold, one note-on per pose; every unsafe state releases.

    A valid pose change releases the old note immediately, then waits a full
    hold before the new note. Unknown/lost/multi-hand/gaps never sustain notes.
    Returned (index,velocity) pairs preserve off-before-on order.
    """
    def __init__(self,hold_seconds=.15,velocity=100):
        if not math.isfinite(hold_seconds) or hold_seconds<.1:
            raise ValueError('hold_seconds must be finite and >=0.1')
        self.hold_seconds=hold_seconds
        self.velocity=max(1,min(127,int(velocity)))
        self.enabled=False
        self.active_note=0
        self.candidate=None
        self.since=None
        self.last_time=None

    def release(self):
        events=[(0,0)] if self.active_note else []
        self.active_note=0
        self.candidate=None
        self.since=None
        return events

    def stop(self):
        self.enabled=False
        self.last_time=None
        return self.release()

    def set_enabled(self,enabled):
        if bool(enabled)!=self.enabled:
            events=self.release()
            self.enabled=bool(enabled)
            self.last_time=None
            return events
        return []

    def update(self,gesture,tracking,now):
        if not self.enabled or not tracking or not math.isfinite(now):
            self.last_time=None
            return self.release()
        events=[]
        if self.last_time is not None and (now<=self.last_time or now-self.last_time>.25):
            events=self.release()
        self.last_time=now
        note=int(gesture) if gesture in ('1','2','3','4','5','6','7') else 0
        if not note:return events+self.release()
        if note!=self.candidate:
            events+=self.release()
            self.candidate,self.since=note,now
            return events
        if note!=self.active_note and now-self.since>=self.hold_seconds:
            self.active_note=note
            events.append((note,self.velocity))
        return events


def emit(message):
    print(json.dumps(message,ensure_ascii=False,separators=(',',':')),flush=True)


def emit_notes(events):
    for index,velocity in events:
        emit({'type':'note','index':index,'velocity':velocity,'timestamp':time.monotonic()})


def load_runtime(model):
    runtime_cache=Path(__file__).resolve().parents[1]/'build/vision'
    runtime_cache.mkdir(parents=True,exist_ok=True)
    os.environ.setdefault('MPLCONFIGDIR',str(runtime_cache/'matplotlib'))
    import cv2
    import mediapipe as mp
    import numpy as np
    if not model.is_file():
        raise FileNotFoundError('缺少 Google MediaPipe Gesture Recognizer 模型：'
            f'{model}\n请从 {MODEL_URL} 下载 gesture_recognizer.task，'
            '并保存到 host_ui/models/gesture_recognizer.task。')
    options=mp.tasks.vision.GestureRecognizerOptions(
        base_options=mp.tasks.BaseOptions(model_asset_buffer=model.read_bytes()),
        running_mode=mp.tasks.vision.RunningMode.VIDEO,num_hands=2,
        min_hand_detection_confidence=.65,min_hand_presence_confidence=.65,
        min_tracking_confidence=.65)
    return cv2,mp,np,mp.tasks.vision.GestureRecognizer.create_from_options(options)


def read_controls(inbox,stop_event):
    try:
        for line in sys.stdin:
            try:
                message=json.loads(line)
                if not isinstance(message,dict):raise ValueError('控制消息必须是JSON对象')
                if message.get('type')=='stop':
                    stop_event.set()
                    return
                if message.get('type')=='enable' and isinstance(message.get('enabled'),bool):
                    inbox.put(message['enabled'])
                else:print('忽略未识别的控制消息',file=sys.stderr,flush=True)
            except (ValueError,TypeError) as exc:
                print(f'控制消息无效：{exc}',file=sys.stderr,flush=True)
    finally:
        stop_event.set()


def check(model):
    cv2,mp,np,recognizer=load_runtime(model)
    try:
        blank=mp.Image(image_format=mp.ImageFormat.SRGB,data=np.zeros((192,192,3),dtype=np.uint8))
        result=recognizer.recognize_for_video(blank,1)
        emit({'type':'check','ok':True,'python':sys.version.split()[0],
              'mediapipe':mp.__version__,'opencv':cv2.__version__,'numpy':np.__version__,
              'model':str(model),'model_sha256':hashlib.sha256(model.read_bytes()).hexdigest(),
              'recognizer':'GestureRecognizer','blank_hands':len(result.hand_landmarks),
              'camera_opened':False})
    finally:recognizer.close()


def _category_hint(category,score):
    if category in MODEL_GESTURE_NAMES and score>0:
        return f"MediaPipe {MODEL_GESTURE_NAMES[category]} {score:.0%}"
    return 'MediaPipe扩展手型'


def _handedness_name(categories):
    name,_=_best_category(categories)
    return name if name in ('Left','Right') else 'Unknown'


def draw_air_keyboard(frame,cv2,lane):
    """Draw seven non-blocking note lanes over the mirrored preview."""
    h,w=frame.shape[:2]
    overlay=frame.copy()
    for index in range(8):
        x=round(index*w/7)
        cv2.line(overlay,(x,0),(x,h),(110,185,205),1)
    cv2.addWeighted(overlay,.18,frame,.82,0,frame)
    for index,note in enumerate(NOTES):
        left=round(index*w/7)
        if lane==index+1:
            cv2.rectangle(frame,(left,0),(round((index+1)*w/7),28),(55,110,137),-1)
        cv2.putText(frame,note,(left+7,20),cv2.FONT_HERSHEY_SIMPLEX,.48,
                    (245,250,252) if lane==index+1 else (210,229,238),1,cv2.LINE_AA)


def run_camera(camera,model,fps,mode='gesture'):
    if mode not in ('gesture','air','dual'):raise ValueError('mode must be gesture, air, or dual')
    # Resolve in the same DirectShow index domain as CAP_DSHOW, before model
    # loading or video acquisition. None means a named physical PC camera.
    selected=resolve_camera(camera)
    cv2,mp,np,recognizer=load_runtime(model)
    capture=None
    stopped=threading.Event()
    controls=queue.SimpleQueue()
    gate=NoteGate()
    stabilizer=GestureStabilizer()
    air=AirKeyboardMapper()
    controller=ControlGestureTrigger()
    plucker=PinchPlucker()
    threading.Thread(target=read_controls,args=(controls,stopped),daemon=True).start()

    def drain_controls():
        while not controls.empty():emit_notes(gate.set_enabled(controls.get()))

    try:
        if stopped.is_set():return
        print(f'摄像头：{selected.name}（DirectShow {selected.index}）',file=sys.stderr,flush=True)
        capture=cv2.VideoCapture(selected.index,cv2.CAP_DSHOW if os.name=='nt' else cv2.CAP_ANY)
        if not capture.isOpened():raise RuntimeError(f'无法打开摄像头 {selected.name}（{selected.index}）')
        capture.set(cv2.CAP_PROP_FRAME_WIDTH,640)
        capture.set(cv2.CAP_PROP_FRAME_HEIGHT,480)
        capture.set(cv2.CAP_PROP_BUFFERSIZE,1)
        last_ms=-1
        while not stopped.is_set():
            started=time.monotonic()
            drain_controls()
            ok,frame=capture.read()
            if not ok:raise RuntimeError('摄像头读取失败，已停止手势控制')
            if stopped.is_set():break
            frame=cv2.flip(frame,1)
            if frame.shape[1]>640:
                frame=cv2.resize(frame,(640,round(frame.shape[0]*640/frame.shape[1])))
            rgb=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
            timestamp=max(last_ms+1,int(time.monotonic()*1000))
            last_ms=timestamp
            result=recognizer.recognize_for_video(mp.Image(image_format=mp.ImageFormat.SRGB,data=rgb),timestamp)
            pose='unknown'
            confidence=0.
            category='None';category_score=0.
            source='未确认'
            note_pose='unknown'
            lane=0
            dual_note=0
            now=time.monotonic()
            if mode=='dual':
                hands=getattr(result,'hand_landmarks',()) or ()
                detected=len(hands)==2
                labels=[]
                if detected:
                    handedness=getattr(result,'handedness',()) or ()
                    labels=[_handedness_name(handedness[i] if i<len(handedness) else ()) for i in range(2)]
                tracking=detected and sorted(labels)==['Left','Right']
                if tracking:
                    left_i=labels.index('Left');right_i=labels.index('Right')
                    gestures=getattr(result,'gestures',()) or ()
                    left_categories=gestures[left_i] if left_i<len(gestures) else ()
                    right_categories=gestures[right_i] if right_i<len(gestures) else ()
                    left_category,left_score=_best_category(left_categories)
                    category,category_score=_best_category(right_categories)
                    action=controller.update(left_category,left_score,True)
                    if action and gate.enabled:emit({'type':'control','command':action})
                    palm_x=sum(float(hands[right_i][i].x) for i in (0,5,9,13,17))/5
                    lane=air.update(palm_x)
                    pinched=_is_pinched(hands[right_i])
                    open_palm=category=='Open_Palm' and category_score>=.68
                    dual_note=plucker.update(pinched,lane,True,now)
                    pose='pinch' if pinched else 'open' if open_palm else 'unknown'
                    confidence=min(category_score,.95 if pinched else category_score)
                    source=f'右手拨弦 · {NOTES[lane-1]}' if lane else '右手张掌选择音区'
                else:
                    controller.reset();plucker.reset();air.reset()
                    if not detected:source='请让左右手同时完整入镜'
                    else:source='请左右手保持分开，确保手掌完整入镜'
            else:
                tracking=len(result.hand_landmarks)==1 and len(result.hand_world_landmarks)==1
                if tracking:
                    categories=result.gestures[0] if len(result.gestures)==1 and result.gestures else ()
                    category,category_score=_best_category(categories)
                    pose,confidence,source=classify_with_evidence(
                        [(p.x,p.y,p.z) for p in result.hand_world_landmarks[0]],categories)
                    if mode=='air':
                        open_palm=(category=='Open_Palm' and category_score>=.72 and pose=='5')
                        if open_palm:
                            palm_x=sum(result.hand_landmarks[0][i].x for i in (0,5,9,13,17))/5
                            lane=air.update(palm_x)
                            note_pose=str(lane)
                            confidence=min(confidence,category_score)
                            source=f'空中琴键 · {NOTES[lane-1]}'
                        else:
                            air.reset()
                            note_pose='unknown'
                            source='空中琴键需要张开手掌'
                    else:
                        note_pose=pose
                    pose,confidence=stabilizer.update(note_pose,confidence,tracking,now)
                else:
                    stabilizer.reset();air.reset()
            drain_controls()
            if stopped.is_set():break
            if mode=='dual':
                if not tracking or not gate.enabled:dual_note=0
            else:
                emit_notes(gate.update(pose,tracking,time.monotonic()))
            for landmarks in result.hand_landmarks:
                h,w=frame.shape[:2]
                coords=[(round(p.x*w),round(p.y*h)) for p in landmarks]
                for a,b in CONNECTIONS:cv2.line(frame,coords[a],coords[b],(180,220,60),2)
                for point in coords:cv2.circle(frame,point,3,(60,150,255),-1)
            if mode=='dual':
                label=f'右手捏合松开 · {NOTES[lane-1]}' if dual_note else f'左手控制 · 右手选音 {NOTES[lane-1] if lane else "—"}'
                if not tracking:label='双手模式 · 等待左右手'
                if tracking and confidence:label+=f' · {confidence:.0%}'
            elif pose in tuple('1234567'):
                label=f'{LABELS[pose]} · {NOTES[int(pose)-1]}'
            else:
                label=LABELS.get(pose,LABELS['unknown'])
            if mode=='air' and pose in tuple('1234567'):
                label=f'张开手掌 · 空中键盘 {NOTES[int(pose)-1]}'
            if mode!='dual' and tracking and pose in tuple('1234567'):
                label+=f' · {confidence:.0%}'
            elif mode!='dual' and not tracking:
                label='多手 · 止音' if result.hand_landmarks else '未检测到手 · 止音'
            if not gate.enabled:label+=' · 预览'
            if mode=='air':draw_air_keyboard(frame,cv2,int(pose) if pose in tuple('1234567') else 0)
            elif mode=='dual':draw_air_keyboard(frame,cv2,lane)
            ok,jpeg=cv2.imencode('.jpg',frame,[cv2.IMWRITE_JPEG_QUALITY,72])
            if not ok:raise RuntimeError('预览JPEG编码失败')
            emit({'type':'frame','jpeg':base64.b64encode(jpeg).decode('ascii'),
                  'gesture':label,'pose':pose,'recognition':source,'confidence':confidence,
                  'mode':mode,'category':category,'category_score':category_score,
                  'lane':lane,'tracking':tracking,
                  'note':dual_note if mode=='dual' else gate.active_note,'enabled':gate.enabled,
                  'camera_index':selected.index,'camera_name':selected.name})
            stopped.wait(max(0.,1./fps-(time.monotonic()-started)))
    finally:
        # Camera/inference/encoding errors and stdin EOF all release before exit.
        # Parent also releases on worker death as transport can fail independently.
        emit_notes(gate.stop())
        if capture is not None:capture.release()
        recognizer.close()


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
    parser=argparse.ArgumentParser(description='Opt-in MediaPipe gesture instrument worker')
    parser.add_argument('--check',action='store_true',help='Blank image check; never opens camera')
    parser.add_argument('--list-cameras',action='store_true',help='Read-only DirectShow metadata; never opens camera')
    parser.add_argument('--camera',type=int,default=None,help='Explicit device override; default auto-selects PC camera')
    parser.add_argument('--model',type=Path,default=DEFAULT_MODEL)
    parser.add_argument('--mode',choices=('gesture','air','dual'),default='gesture',
                        help='counted notes, palm keyboard, or two-hand controls and plucking')
    parser.add_argument('--fps',type=float,default=15)
    args=parser.parse_args()
    if (args.camera is not None and args.camera<0) or not 1<=args.fps<=30:
        parser.error('camera>=0; fps between 1 and 30')
    try:
        if args.check:check(args.model)
        elif args.list_cameras:
            from dataclasses import asdict
            devices=enumerate_dshow_cameras()
            emit({'type':'cameras','backend':'DirectShow',
                  'devices':[asdict(d) for d in devices],
                  'selected':asdict(choose_camera(devices,args.camera)),
                  'camera_opened':False})
        else:run_camera(args.camera,args.model,args.fps,args.mode)
    except (BrokenPipeError,KeyboardInterrupt):return 0
    except Exception as exc:
        print(f'{type(exc).__name__}: {exc}',file=sys.stderr,flush=True)
        emit({'type':'error','message':str(exc)})
        return 1
    return 0


if __name__=='__main__':raise SystemExit(main())
