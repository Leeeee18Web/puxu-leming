"""Preview-boundary regressions: no camera, sound, serial or live-model labels."""
import math
import unittest
from types import SimpleNamespace as NS
from dual_tracking import DualHandTracker, observations_from_result
from legacy_vision_tests import hand, POSES


def observed(points, category='None', score=.99, side='Left'):
    p=[NS(x=x,y=y,z=z) for x,y,z in points]
    result=NS(hand_landmarks=[p],hand_world_landmarks=[p],
              handedness=[[NS(category_name=side,score=.99)]],
              gestures=[[NS(category_name=category,score=score)]])
    return observations_from_result(result)[0]


def relaxed(points, mcp):
    p=list(points);x,y,z=p[mcp+1]
    p[mcp+2]=(x+.12*math.sin(math.radians(30)),y-.12*math.cos(math.radians(30)),z)
    p[mcp+3]=(p[mcp+2][0]+.10*math.sin(math.radians(45)),
              p[mcp+2][1]-.10*math.cos(math.radians(45)),z)
    return p


class FourFiveGeometryTests(unittest.TestCase):
    def test_open_thumb_base_with_curled_tip_remains_five(self):
        p=hand();p[4]=(.30,.55,0.)
        self.assertEqual(observed(p,'Open_Palm')['pose'],'5')

    def test_folded_thumb_base_with_exposed_tip_remains_four(self):
        p=hand(thumb=False);p[2:5]=[(.44,.64,0),(.40,.66,0),(.30,.66,0)]
        self.assertEqual(observed(p,'Open_Palm')['pose'],'4')

    def test_thumb_mcp_can_stay_outward_while_ip_folds_across_palm(self):
        p=hand(thumb=False);p[2:5]=[(.28,.63,0),(.40,.60,0),(.52,.66,0)]
        self.assertEqual(observed(p,'Open_Palm')['pose'],'4')

    def test_spread_middle_and_tip_support_five_with_less_lateral_root(self):
        p=hand();p[2]=(.36,.60,0)
        self.assertEqual(observed(p,'Open_Palm')['pose'],'5')

    def test_naturally_bent_little_finger_is_still_an_open_hand(self):
        for digit,base in [('4',hand(thumb=False)),('5',hand())]:
            with self.subTest(digit=digit):
                self.assertEqual(observed(relaxed(base,17),'Open_Palm')['pose'],digit)

    def test_two_relaxed_outer_fingers_do_not_veto_four_five(self):
        for digit,base in [('4',hand(thumb=False)),('5',hand())]:
            self.assertEqual(observed(relaxed(relaxed(base,13),17),'Open_Palm')['pose'],digit)

    def test_three_and_fist_are_not_promoted_to_four_five(self):
        for digit in '12367':
            with self.subTest(digit=digit):self.assertEqual(observed(POSES[digit])['pose'],digit)
        self.assertEqual(observed(hand((0,0,0,0),False),'Closed_Fist')['pose'],'fist')
        self.assertEqual(observed(POSES['3'],'Open_Palm')['pose'],'unknown')

    def test_thumb_too_close_to_index_root_remains_uncertain(self):
        p=hand();p[4]=(.3441,.55,0)
        self.assertEqual(observed(p,'Open_Palm')['pose'],'unknown')

    def test_long_finger_failure_is_not_reported_as_thumb_failure(self):
        p=hand();p[8]=(.47,.50,0)
        item=observed(p,'Open_Palm')
        self.assertEqual(item['pose'],'unknown')
        self.assertEqual(item.get('reason'),'model_conflict')
        self.assertNotIn('拇指',item['source'])

    def test_ambiguous_long_finger_has_a_distinct_soft_reason(self):
        p=hand();p[8]=(.39+.18*math.sin(math.radians(35)),
                            .40-.18*math.cos(math.radians(35)),0)
        self.assertEqual(observed(p,'Open_Palm').get('reason'),'long_fingers_uncertain')

    def test_closed_fist_is_not_hidden_by_ambiguous_thumb(self):
        p=hand();p[4]=(.3441,.55,0)
        self.assertEqual(observed(p,'Closed_Fist')['pose'],'fist')

    def test_original_pinch_alias_still_overrides_canned_fist(self):
        self.assertEqual(observed(POSES['7'],'Closed_Fist')['pose'],'7')

    def test_strong_other_model_label_precedes_soft_thumb_uncertainty(self):
        p=hand();p[4]=(.3441,.55,0)
        for category in ('Victory','Thumb_Up','Pointing_Up','ILoveYou'):
            self.assertEqual(observed(p,category).get('reason'),'model_conflict')

    def test_new_variants_survive_mirror_scale_and_rigid_rotation(self):
        five=hand();five[4]=(.30,.55,0)
        four=hand(thumb=False);four[2:5]=[(.44,.64,0),(.40,.66,0),(.30,.66,0)]
        variants=[('5',five),('4',four),('5',relaxed(hand(),17)),
                  ('4',relaxed(hand(thumb=False),17))]
        for digit,p in variants:
            for a in (0.,.8,2.4):
                for mirror in (-1,1):
                    q=[]
                    for x,y,z in p:
                        u=mirror*(x*math.cos(a)-y*math.sin(a))*.4
                        v=(x*math.sin(a)+y*math.cos(a))*.4
                        q.append((u+3,v*.6-z*.8-2,v*.8+z*.6+1))
                    self.assertEqual(observed(q,'Open_Palm')['pose'],digit)

    def test_invalid_or_degenerate_points_cannot_be_open_palm_rescued(self):
        for p in [[(0,0,0)]*21,[(float('nan'),0,0)]*21]:
            self.assertEqual(observed(p,'Open_Palm')['pose'],'unknown')


def item(pose, reason='',side='Left'):
    return dict(label=side,hand_score=.99,pose=pose,confidence=.9,reason=reason,index=0)


class FourFiveTimeTests(unittest.TestCase):
    def confirmed(self):
        t=DualHandTracker();t.update([item('4')],1.)
        self.assertEqual(t.update([item('4')],1.07)['Left']['digit'],4)
        return t

    def test_short_thumb_uncertainty_is_marked_provisional(self):
        t=self.confirmed()
        s=t.update([item('unknown','thumb_uncertain')],1.14)['Left']
        self.assertEqual(s['digit'],4);self.assertTrue(s.get('provisional'))
        self.assertNotEqual(s['status'],'已确认')

    def test_continuous_uncertainty_expires_without_reinforcing_old_digit(self):
        t=self.confirmed()
        t.update([item('unknown','thumb_uncertain')],1.14)
        s=t.update([item('unknown','thumb_uncertain')],1.29)['Left']
        self.assertEqual(s['digit'],0)

    def test_fist_and_identity_loss_clear_even_during_grace(self):
        for bad in [item('fist'),None,item('unknown','invalid_landmarks')]:
            t=self.confirmed();t.update([item('unknown','thumb_uncertain')],1.14)
            s=t.update([bad] if bad else [],1.17)['Left']
            self.assertEqual(s['digit'],0)

    def test_low_frame_rate_still_allows_two_consistent_observations(self):
        t=DualHandTracker();t.update([item('4')],1.)
        self.assertEqual(t.update([item('4')],1.21)['Left']['digit'],4)

    def test_clearly_folded_little_finger_cannot_coast_as_four(self):
        t=self.confirmed();o=observed(POSES['3'],'Open_Palm')
        self.assertEqual(t.update([o],1.14)['Left']['digit'],0)

    def test_clear_opposite_digit_switches_after_two_observations(self):
        t=self.confirmed();t.update([item('5')],1.14)
        s=t.update([item('5')],1.21)['Left']
        self.assertEqual(s['digit'],5);self.assertFalse(s.get('provisional',False))

    def test_soft_failure_on_left_keeps_right_independent(self):
        t=DualHandTracker()
        for now in (1.,1.07):t.update([item('4'),item('5',side='Right')],now)
        s=t.update([item('unknown','long_fingers_uncertain'),item('5',side='Right')],1.14)
        self.assertEqual((s['Left']['digit'],s['Right']['digit']),(4,5))
        self.assertTrue(s['Left'].get('provisional'));self.assertFalse(s['Right'].get('provisional',False))


if __name__=='__main__':unittest.main()
