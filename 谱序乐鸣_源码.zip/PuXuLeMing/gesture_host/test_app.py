import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import unittest
from types import SimpleNamespace
from PySide6.QtWidgets import QApplication
from app import MainWindow,PALETTE

class FakeLink:
 def __init__(self,port,events,**kwargs):self.port_name=port;self.events=events;self.notes=[];self.stops=0;self.closed=False
 def start(self):pass
 def set_note(self,*note):self.notes.append(note)
 def emergency_stop(self):self.stops+=1
 def disconnect(self):self.closed=True
 def join(self,*args):pass

class AppTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.qt=QApplication.instance() or QApplication([])
 def window(self):
  w=MainWindow(autostart=False,link_factory=FakeLink,ports_provider=lambda:[SimpleNamespace(device='COM12',description='USB serial')]);self.addCleanup(w.close);return w
 def frame(self,left=6,right=4,lp=None,rp=None):
  return dict(type='frame',jpeg='',detected_hands=2,hands={'Left':dict(present=True,digit=left,pose=lp or str(left),status='已确认'),'Right':dict(present=True,digit=right,pose=rp or str(right),status='已确认')})
 def connect(self,w):
  w.connect_board();w.on_link_event(dict(type='connected',port='COM12'))
  w.on_link_event(dict(type='status',capabilities=3,playable=True,firmware=0x5008,mode=1,pattern_mode=0))
 def test_no_camera_or_serial_on_offscreen_construction(self):
  w=self.window();self.assertIsNone(w.process);self.assertIsNone(w.worker);self.assertFalse(w.controller.linked)
  self.assertEqual(PALETTE['bg'],'#151617');self.assertEqual(PALETTE['gold'],'#d7b56d')
 def test_port_data_and_handshake_enable_controls(self):
  w=self.window();w.connect_board();self.assertEqual(w.worker.port_name,'COM12')
  w.on_camera_event(self.frame());self.assertEqual(w.worker.notes,[])
  w.on_link_event(dict(type='connected',port='COM12'));self.assertFalse(w.controller.linked)
  w.on_link_event(dict(type='status',capabilities=3,playable=True,firmware=0x5008));w.on_camera_event(self.frame())
  self.assertTrue(w.controller.linked);self.assertEqual(w.worker.notes[-1],(6,100));self.assertEqual(w.controller.sequence,(6,7,1,2))
 def test_fists_priority_and_correct_side_cards(self):
  w=self.window();self.connect(w);w.on_camera_event(self.frame());self.assertEqual((w.left.digit.text(),w.right.digit.text()),('6','4'))
  w.on_camera_event(self.frame(0,0,'fist','fist'));self.assertEqual(w.worker.stops,1);self.assertFalse(w.controller.playing)
 def test_right_fist_starts_song_once(self):
  w=self.window();self.connect(w);w.on_camera_event(self.frame(1,0,rp='fist'));starts=w.controller.starts
  w.on_camera_event(self.frame(1,0,rp='fist'));self.assertEqual(w.controller.starts,starts);self.assertEqual(w.controller.label,'小星星')
 def test_legacy_capability_does_not_arm_dual_performance(self):
  w=self.window();w.connect_board();w.on_link_event(dict(type='connected',port='COM12'));w.on_link_event(dict(type='status',capabilities=1,playable=True,firmware=0x5008))
  w.on_camera_event(self.frame());self.assertFalse(w.controller.linked);self.assertEqual(w.worker.notes,[])
 def test_old_disconnect_event_cannot_drop_a_new_connection(self):
  w=self.window();self.connect(w);old=w.worker;w.disconnect_board();w.connect_board();new=w.worker
  old.events.put(dict(type='disconnected'));w.tick();self.assertIs(w.worker,new)

if __name__=='__main__':unittest.main()
