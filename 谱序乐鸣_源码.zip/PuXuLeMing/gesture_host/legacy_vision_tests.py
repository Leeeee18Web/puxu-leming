"""Offline geometry and fail-safe note protocol; never acquires hardware."""
import io
import json
import math
import queue
import threading
import unittest
from contextlib import redirect_stdout, redirect_stderr
from unittest.mock import patch, Mock

from vision_worker import (AirKeyboardMapper,GestureStabilizer,NoteGate,
    ControlGestureTrigger,PinchPlucker,_is_pinched,classify_gesture,classify_with_evidence,
    emit,read_controls,run_camera,check)
from camera_source import CameraDevice, choose_camera, resolve_camera


def hand(fingers=(1, 1, 1, 1), thumb=True):
    points = [(.5, .9, 0.)] * 21
    points[1:5] = ([(.40,.72,0),(.28,.63,0),(.18,.54,0),(.08,.45,0)]
                   if thumb else [(.40,.72,0),(.40,.64,0),(.48,.59,0),(.52,.66,0)])
    for i, straight in enumerate(fingers):
        x = .39 + .085*i
        points[5+4*i:9+4*i] = [(x,.55,0),(x,.40,0),
            (x,.28 if straight else .48,0),(x,.15 if straight else .60,0)]
    return points


def seven():
    points = hand((0,0,0,0), False)
    points[2:5] = [(.34,.59,0),(.41,.43,0),(.47,.32,0)]
    points[6:9] = [(.40,.39,0),(.43,.32,0),(.45,.30,0)]
    points[10:13] = [(.48,.39,0),(.49,.32,0),(.49,.30,0)]
    return points


POSES = {'1':hand((1,0,0,0),False), '2':hand((1,1,0,0),False),
         '3':hand((1,1,1,0),False), '4':hand((1,1,1,1),False),
         '5':hand(), '6':hand((0,0,0,1)), '7':seven()}


class GeometryTests(unittest.TestCase):
    def test_all_notes_and_fist(self):
        for name, points in POSES.items():
            with self.subTest(pose=name):
                self.assertEqual(classify_gesture(points), name)
        self.assertEqual(classify_gesture(hand((0,0,0,0),False)), 'fist')

    def test_mirror_scale_and_3d_rotation(self):
        for expected, points in POSES.items():
            for angle in (0,.8,2.4):
                for sign in (-1,1):
                    # Rotate x/y then y/z; geometric distances/angles must survive.
                    transformed=[]
                    for x,y,z in points:
                        a=sign*(x*math.cos(angle)-y*math.sin(angle))*.4
                        b=(x*math.sin(angle)+y*math.cos(angle))*.4
                        transformed.append((a+3,b*.6-z*.8-2,b*.8+z*.6+1))
                    self.assertEqual(classify_gesture(transformed),expected)

    def test_invalid_degenerate_ambiguous_and_unmapped(self):
        ambiguous=hand((1,0,0,0),False)
        ambiguous[8]=(.39+.18*math.sin(math.radians(35)),
                      .40-.18*math.cos(math.radians(35)),0)
        for points in (None, [], [None]*21, [(0,0,0)]*21,
                       [(float('nan'),0,0)]*21, hand()[:20], ambiguous,
                       hand((0,0,1,0),False)):
            self.assertEqual(classify_gesture(points),'unknown')

    def test_loose_or_partial_pinch_is_unknown(self):
        loose=seven()
        loose[4]=(.1,.3,0)
        self.assertEqual(classify_gesture(loose),'unknown')
        partial=seven()
        partial[12]=(.48,.6,0)
        self.assertEqual(classify_gesture(partial),'unknown')

    def test_mediapipe_categories_confirm_aliases_and_reject_conflicts(self):
        self.assertEqual(classify_gesture(hand((0,0,0,0),True),
            [{'category_name':'Thumb_Up','score':.94}]),'6')
        self.assertEqual(classify_gesture(hand((1,0,0,1),True),
            [{'category_name':'ILoveYou','score':.94}]),'7')
        self.assertEqual(classify_gesture(POSES['1'],
            [{'category_name':'Open_Palm','score':.96}]),'unknown')
        self.assertEqual(classify_gesture(POSES['3'],
            [{'category_name':'None','score':.96}]),'3')
        self.assertEqual(classify_gesture(hand((0,0,0,0),False),
            [{'category_name':'Closed_Fist','score':.96}]),'fist')


class AccuracyRegressionTests(unittest.TestCase):
    def test_folded_across_palm_thumb_does_not_need_a_bent_ip_joint(self):
        points=hand((1,1,1,1),False)
        points[2:5]=[(.42,.62,0),(.47,.61,0),(.52,.60,0)]
        self.assertEqual(classify_gesture(points),'4')

    def test_abducted_thumb_can_be_naturally_bent_for_five(self):
        points=hand()
        points[3]=(.15,.58,0)
        self.assertEqual(classify_gesture(points),'5')

    def test_four_is_not_vetoed_by_canned_open_palm_label(self):
        self.assertEqual(classify_gesture(POSES['4'],[('Open_Palm',.96)]),'4')

    def test_four_five_keep_a_thumb_abduction_rejection_band(self):
        points=hand()
        points[4]=(.39-.18*.255,.55,0)
        self.assertEqual(classify_gesture(points),'unknown')
        self.assertEqual(classify_gesture(points,[('Open_Palm',.96)]),'unknown')

    def test_thumb_only_and_shaka_both_mean_six(self):
        for points in (hand((0,0,0,0),True), POSES['6']):
            self.assertEqual(classify_gesture(points),'6')

    def test_love_you_and_three_tip_pinch_both_mean_seven(self):
        for points in (hand((1,0,0,1),True), POSES['7']):
            self.assertEqual(classify_gesture(points),'7')

    def test_moderately_bent_ring_finger_still_means_three(self):
        points=hand((1,1,1,0),False)
        points[16]=(.56+.22*math.sin(math.radians(30)),
                    .40-.22*math.cos(math.radians(30)),0)
        self.assertEqual(classify_gesture(points),'3')

    def test_compact_pinch_is_not_rejected_by_its_own_confidence(self):
        points=seven()
        points[8]=(.43,.30,0);points[12]=(.51,.30,0)
        pose,score,_=classify_with_evidence(points)
        self.assertEqual(pose,'7');self.assertGreaterEqual(score,.72)

    def test_custom_three_is_not_vetoed_as_victory(self):
        self.assertEqual(classify_gesture(POSES['3'],[('Victory',.94)]),'3')

    def test_distal_three_tip_pinch_is_not_vetoed_as_fist(self):
        self.assertEqual(classify_gesture(POSES['7'],[('Closed_Fist',.94)]),'7')

    def test_actual_fist_and_incompatible_palm_still_reject_notes(self):
        self.assertEqual(classify_gesture(hand((0,0,0,0),False),[('Closed_Fist',.98)]),'fist')
        self.assertEqual(classify_gesture(POSES['1'],[('Open_Palm',.98)]),'unknown')

    def test_custom_shapes_survive_mirror_scale_and_rotation(self):
        three=hand((1,1,1,0),False)
        three[16]=(.56+.22*math.sin(math.radians(30)),
                   .40-.22*math.cos(math.radians(30)),0)
        four=hand((1,1,1,1),False)
        four[2:5]=[(.42,.62,0),(.47,.61,0),(.52,.60,0)]
        five=hand();five[3]=(.15,.58,0)
        poses=(('6',hand((0,0,0,0),True)),('7',hand((1,0,0,1),True)),
               ('3',three),('7',seven()),('4',four),('5',five))
        for expected,points in poses:
            for rotation in (0.,.8,2.4):
                for mirror in (-1,1):
                    transformed=[]
                    for x,y,z in points:
                        a=mirror*(x*math.cos(rotation)-y*math.sin(rotation))*.4
                        b=(x*math.sin(rotation)+y*math.cos(rotation))*.4
                        transformed.append((a+3,b*.6-z*.8-2,b*.8+z*.6+1))
                    self.assertEqual(classify_gesture(transformed),expected)

    def test_alternating_labels_do_not_switch_the_stable_note(self):
        smoother=GestureStabilizer()
        smoother.update('1',.9,True,0);smoother.update('1',.9,True,.06)
        for i,pose in enumerate(('2','1','2','1','2'),2):
            self.assertEqual(smoother.update(pose,.9,True,.06*i)[0],'1')
        self.assertEqual(smoother.update('2',.9,True,.42)[0],'2')


class StabilityTests(unittest.TestCase):
    def test_two_of_three_suppresses_single_frame_pose_jitter(self):
        smoother=GestureStabilizer()
        self.assertEqual(smoother.update('1',.9,True,0),('unknown',0.))
        self.assertEqual(smoother.update('1',.9,True,.06)[0],'1')
        self.assertEqual(smoother.update('2',.9,True,.12)[0],'1')
        self.assertEqual(smoother.update('1',.9,True,.18)[0],'1')
        self.assertEqual(smoother.update('2',.9,True,.24)[0],'1')
        self.assertEqual(smoother.update('2',.9,True,.30)[0],'2')

    def test_lost_hand_fist_low_score_and_stale_gap_reset_vote(self):
        for event in (('unknown',.9,True,.12),('fist',.9,True,.12),
                      ('1',.2,True,.12),('1',.9,False,.12)):
            smoother=GestureStabilizer()
            smoother.update('1',.9,True,0)
            self.assertEqual(smoother.update(*event)[0],'fist' if event[0]=='fist' and event[2] else 'unknown')
        smoother=GestureStabilizer()
        smoother.update('1',.9,True,0)
        self.assertEqual(smoother.update('1',.9,True,.25)[0],'unknown')

    def test_air_keyboard_smoothing_hysteresis_and_edges(self):
        mapper=AirKeyboardMapper()
        self.assertEqual(mapper.update(.02),1)
        self.assertEqual(mapper.update(.12),1)
        self.assertEqual(mapper.update(.8),1)
        for _ in range(20):note=mapper.update(.99)
        self.assertEqual(note,7)
        for _ in range(30):note=mapper.update(0.)
        self.assertEqual(note,1)
        self.assertEqual(mapper.update(float('nan')),0)


class TwoHandTests(unittest.TestCase):
    def test_control_gestures_are_single_shot_and_require_neutral_rearm(self):
        controls=ControlGestureTrigger()
        self.assertIsNone(controls.update('Thumb_Up',.95))
        self.assertEqual(controls.update('Thumb_Up',.95),'octave_up')
        self.assertIsNone(controls.update('Thumb_Up',.99))
        self.assertIsNone(controls.update('Open_Palm',.9))
        self.assertIsNone(controls.update('Open_Palm',.9))
        self.assertIsNone(controls.update('Victory',.8))
        self.assertEqual(controls.update('Victory',.8),'timbre_next')
        self.assertIsNone(controls.update('Thumb_Down',.99))

    def test_pinch_release_emits_one_lane_pulse(self):
        plucker=PinchPlucker()
        self.assertEqual(plucker.update(True,3,True,0.),0)
        self.assertEqual(plucker.update(True,3,True,.04),0)
        self.assertEqual(plucker.update(False,4,True,.08),0)
        self.assertEqual(plucker.update(False,4,True,.12),3)
        self.assertEqual(plucker.update(False,4,True,.20),3)
        self.assertEqual(plucker.update(False,4,True,.25),0)

    def test_pinch_geometry_is_palm_scale_normalized(self):
        points=hand()
        points[4]=points[8]
        self.assertTrue(_is_pinched(points))
        expanded=[(x*3,y*3,z) for x,y,z in points]
        self.assertTrue(_is_pinched(expanded))
        self.assertFalse(_is_pinched(hand()))


class GateTests(unittest.TestCase):
    def setUp(self):
        self.gate=NoteGate()

    def on(self,pose='1',start=0.):
        self.gate.set_enabled(True)
        self.assertEqual(self.gate.update(pose,True,start),[])
        self.assertEqual(self.gate.update(pose,True,start+.1),[])
        return self.gate.update(pose,True,start+.16)

    def test_opt_in_and_stable_hold(self):
        self.assertEqual(self.gate.update('1',True,0),[])
        self.assertEqual(self.gate.update('1',True,.2),[])
        self.assertEqual(self.on(),[(1,100)])
        self.assertEqual(self.gate.update('1',True,.3),[])
        self.assertEqual(self.gate.update('1',True,.4),[])

    def test_all_notes(self):
        for note in range(1,8):
            self.gate=NoteGate()
            self.assertEqual(self.on(str(note)),[(note,100)])

    def test_change_off_precedes_stable_new_on(self):
        self.on()
        self.assertEqual(self.gate.update('2',True,.2),[(0,0)])
        self.assertEqual(self.gate.update('2',True,.3),[])
        self.assertEqual(self.gate.update('2',True,.36),[(2,100)])
        self.assertEqual(self.gate.update('2',True,.4),[])

    def test_brief_poses_never_trigger(self):
        self.gate.set_enabled(True)
        self.assertEqual(self.gate.update('1',True,0),[])
        self.assertEqual(self.gate.update('2',True,.1),[])
        self.assertEqual(self.gate.update('3',True,.2),[])
        self.assertEqual(self.gate.active_note,0)

    def test_loss_unknown_fist_disable_and_stop_release(self):
        for pose,tracking in [('unknown',True),('fist',True),('1',False)]:
            self.gate=NoteGate()
            self.on()
            self.assertEqual(self.gate.update(pose,tracking,.2),[(0,0)])
            self.assertEqual(self.gate.update(pose,tracking,.3),[])
        self.gate=NoteGate()
        self.on()
        self.assertEqual(self.gate.set_enabled(False),[(0,0)])
        self.assertEqual(self.gate.set_enabled(False),[])
        self.assertEqual(self.on('1',1),[(1,100)])
        self.assertEqual(self.gate.stop(),[(0,0)])

    def test_gap_reverse_and_invalid_time_fail_closed(self):
        for now in (1.,.1,float('nan')):
            self.gate=NoteGate()
            self.on()
            self.assertEqual(self.gate.update('1',True,now),[(0,0)])
            self.assertEqual(self.gate.active_note,0)

    def test_reacquisition_requires_full_hold(self):
        self.on()
        self.gate.update('1',False,.2)
        self.assertEqual(self.gate.update('1',True,.21),[])
        self.assertEqual(self.gate.update('1',True,.31),[])
        self.assertEqual(self.gate.update('1',True,.38),[(1,100)])


class ProtocolTests(unittest.TestCase):
    def test_control_validation_and_eof_stop(self):
        inbox,stopped=queue.SimpleQueue(),threading.Event()
        data='[]\n{"type":"enable","enabled":"false"}\n{"type":"enable","enabled":true}\n'
        with patch('sys.stdin',io.StringIO(data)),redirect_stderr(io.StringIO()):
            read_controls(inbox,stopped)
        self.assertTrue(stopped.is_set())
        self.assertTrue(inbox.get_nowait())
        self.assertTrue(inbox.empty())

    def test_stop_ignores_later_enable(self):
        inbox,stopped=queue.SimpleQueue(),threading.Event()
        with patch('sys.stdin',io.StringIO('{"type":"stop"}\n{"type":"enable","enabled":true}\n')):
            read_controls(inbox,stopped)
        self.assertTrue(stopped.is_set())
        self.assertTrue(inbox.empty())

    def test_one_utf8_json_line(self):
        output=io.StringIO()
        message={'type':'frame','gesture':'六 · A4'}
        with redirect_stdout(output):emit(message)
        self.assertEqual(len(output.getvalue().splitlines()),1)
        self.assertEqual(json.loads(output.getvalue()),message)

    def test_camera_failure_releases_active_note_and_closes_resources(self):
        gate=NoteGate()
        gate.enabled=True
        gate.active_note=3
        cv2,mp,np,detector=Mock(),Mock(),Mock(),Mock()
        capture=cv2.VideoCapture.return_value
        capture.isOpened.return_value=True
        capture.read.side_effect=RuntimeError('synthetic capture error')
        output=io.StringIO()
        with patch('vision_worker.load_runtime',return_value=(cv2,mp,np,detector)), \
             patch('vision_worker.NoteGate',return_value=gate), \
             patch('vision_worker.threading.Thread'),redirect_stdout(output):
            with self.assertRaisesRegex(RuntimeError,'synthetic capture error'):
                run_camera(0,None,15)
        messages=[json.loads(line) for line in output.getvalue().splitlines()]
        self.assertEqual([(m['index'],m['velocity']) for m in messages],[(0,0)])
        capture.release.assert_called_once()
        detector.close.assert_called_once()


class CameraSelectionTests(unittest.TestCase):
    def test_realistic_dshow_order_prefers_fhd_to_phone(self):
        devices=[CameraDevice(0,'荣耀Magic8前置摄像头','phone-front'),
                 CameraDevice(1,'荣耀Magic8后置摄像头','phone-rear'),
                 CameraDevice(2,'FHD Camera','usb-physical')]
        self.assertEqual(choose_camera(devices).index,2)

    def test_device_index_is_preserved_not_list_position(self):
        self.assertEqual(choose_camera([CameraDevice(7,'FHD Camera','usb')]).index,7)

    def test_reordering_never_selects_phone(self):
        from itertools import permutations
        names=['HONOR Magic8','Phone Camera','Integrated Camera']
        for ordered in permutations(names):
            devices=[CameraDevice(i,name,'') for i,name in enumerate(ordered)]
            self.assertEqual(choose_camera(devices).name,'Integrated Camera')

    def test_known_computer_names_and_real_usb_fallback(self):
        for name in ('FHD Camera','Integrated Webcam','HP HD Camera','USB Video Device','Logitech Webcam C920','电脑摄像头'):
            with self.subTest(name=name):
                self.assertEqual(choose_camera([CameraDevice(3,name,'')]).index,3)

    def test_phone_virtual_and_ir_are_never_automatic(self):
        for name in ('荣耀Magic8前置','HONOR Camera','Magic8 Rear','iPhone Camera',
                     'DroidCam','Iriun Webcam','OBS Virtual Camera','ManyCam',
                     'Camo Camera','Phone Link','Integrated IR Camera'):
            with self.subTest(name=name),self.assertRaisesRegex(RuntimeError,'电脑摄像头'):
                choose_camera([CameraDevice(0,name,'')])

    def test_no_computer_does_not_fall_back_to_phone_or_unknown(self):
        for devices in ([],[CameraDevice(0,'陌生设备','')],
                        [CameraDevice(0,'手机摄像头',''),CameraDevice(1,'OBS Virtual Camera','')]):
            with self.assertRaisesRegex(RuntimeError,'电脑摄像头'):
                choose_camera(devices)

    def test_explicit_override_can_select_phone(self):
        devices=[CameraDevice(0,'HONOR Magic8',''),CameraDevice(2,'FHD Camera','')]
        self.assertEqual(choose_camera(devices,override=0).name,'HONOR Magic8')

    def test_explicit_override_need_not_enumerate(self):
        selected=choose_camera([],override=9)
        self.assertEqual(selected.index,9)
        self.assertEqual(selected.name,'指定摄像头 9')
        with patch('camera_source.enumerate_dshow_cameras') as enumerate_devices:
            self.assertEqual(resolve_camera(9).index,9)
        enumerate_devices.assert_not_called()

    def test_negative_or_boolean_override_rejected(self):
        for value in (-1,True,1.5,'0'):
            with self.assertRaises(ValueError):choose_camera([],override=value)

    def test_default_resolves_fresh_directshow_order(self):
        with patch('camera_source.enumerate_dshow_cameras',return_value=[
                CameraDevice(0,'Phone Camera',''),CameraDevice(1,'FHD Camera','')]) as enumerate_devices:
            self.assertEqual(resolve_camera().index,1)
        enumerate_devices.assert_called_once()

    def test_worker_passes_selected_index_to_capture(self):
        cv2,mp,np,detector=Mock(),Mock(),Mock(),Mock()
        capture=cv2.VideoCapture.return_value
        capture.isOpened.return_value=True
        capture.read.side_effect=RuntimeError('fixture end')
        with patch('vision_worker.resolve_camera',return_value=CameraDevice(4,'FHD Camera','')) as resolve, \
             patch('vision_worker.load_runtime',return_value=(cv2,mp,np,detector)), \
             patch('vision_worker.threading.Thread'),redirect_stderr(io.StringIO()):
            with self.assertRaisesRegex(RuntimeError,'fixture end'):run_camera(None,None,15)
        resolve.assert_called_once_with(None)
        cv2.VideoCapture.assert_called_once_with(4,cv2.CAP_DSHOW)
        capture.release.assert_called_once()

    def test_default_failure_never_loads_runtime_or_probes_camera(self):
        with patch('vision_worker.resolve_camera',side_effect=RuntimeError('未找到电脑摄像头')), \
             patch('vision_worker.load_runtime') as runtime:
            with self.assertRaisesRegex(RuntimeError,'电脑摄像头'):run_camera(None,None,15)
        runtime.assert_not_called()

    def test_cli_default_uses_automatic_selection(self):
        import vision_worker
        with patch('sys.argv',['vision_worker.py']),patch('vision_worker.run_camera') as run, \
             patch('sys.stdout',Mock()),patch('sys.stderr',Mock()):
            self.assertEqual(vision_worker.main(),0)
        self.assertIsNone(run.call_args.args[0])

    def test_cli_explicit_index_is_preserved(self):
        import vision_worker
        with patch('sys.argv',['vision_worker.py','--camera','0']), \
             patch('vision_worker.run_camera') as run,patch('sys.stdout',Mock()),patch('sys.stderr',Mock()):
            self.assertEqual(vision_worker.main(),0)
        self.assertEqual(run.call_args.args[0],0)

    def test_check_never_acquires_camera(self):
        from pathlib import Path
        cv2,mp,np,detector=Mock(),Mock(),Mock(),Mock()
        cv2.__version__,mp.__version__,np.__version__='fake','fake','fake'
        detector.recognize_for_video.return_value.hand_landmarks=[]
        model=Mock(spec=Path)
        model.read_bytes.return_value=b'fixture model'
        output=io.StringIO()
        with patch('vision_worker.load_runtime',return_value=(cv2,mp,np,detector)),redirect_stdout(output):
            check(model)
        cv2.VideoCapture.assert_not_called()
        message=json.loads(output.getvalue())
        self.assertFalse(message['camera_opened'])
        self.assertEqual(message['blank_hands'],0)
        self.assertEqual(message['recognizer'],'GestureRecognizer')
        detector.close.assert_called_once()


if __name__=='__main__':
    unittest.main(verbosity=2)
