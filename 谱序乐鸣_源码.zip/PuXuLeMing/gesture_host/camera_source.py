"""Read-only DirectShow camera metadata and conservative PC-camera default.

Enumerates VideoInputDeviceCategory monikers in their original order, exactly
the index domain used by OpenCV CAP_DSHOW. Does not bind an IBaseFilter, create
a capture graph, stream frames, probe VideoCapture indices, or import OpenCV.
"""
from __future__ import annotations

from dataclasses import dataclass
import os
import re


@dataclass(frozen=True)
class CameraDevice:
    index: int
    name: str
    path: str = ''


_EXCLUDED = ('荣耀', 'honor', 'magic', '手机', 'phone', 'android',
             'virtual', '虚拟', 'obs', 'droidcam', 'iriun', 'epoccam',
             'ivcam', 'manycam', 'camo', 'xsplit', 'snap camera', 'ndi',
             'infrared', 'depth camera', ' ir camera')


def _pc_rank(device):
    name=' '.join(device.name.casefold().split())
    if any(word in name for word in _EXCLUDED):return None
    if re.search(r'\bir\b',name):return None
    if name=='fhd camera':return 0
    if 'integrated' in name or 'built-in' in name or '内置' in name:return 1
    if 'fhd' in name or re.search(r'\bhd\b.*camera',name):return 2
    if any(word in name for word in ('webcam','truevision','easycamera','电脑摄像头')):return 3
    if name in ('usb video device','usb camera','usb2.0 camera','usb 2.0 camera','uvc camera'):return 4
    return None


def choose_camera(devices,override=None):
    """Choose a recognised physical PC camera; no implicit phone fallback.

    Explicit nonnegative --camera N remains an intentional override, including
    mobile/virtual cameras. This path does not require or perform enumeration.
    """
    if override is not None:
        if type(override) is not int or override<0:
            raise ValueError('camera override must be a nonnegative integer')
        return next((d for d in devices if d.index==override),
                    CameraDevice(override,f'指定摄像头 {override}'))
    candidates=[(rank,d.index,d) for d in devices if (rank:=_pc_rank(d)) is not None]
    if not candidates:
        raise RuntimeError('未找到可确认的电脑摄像头；不会自动改用手机或虚拟相机。'
                           '请连接电脑摄像头，或明确使用 --camera N 指定设备。')
    return min(candidates,key=lambda item:(item[0],item[1]))[2]


def enumerate_dshow_cameras():
    """Read FriendlyName/DevicePath through IPropertyBag, without opening video.

    Keep an entry even if its friendly name is unavailable; skipping such a
    moniker would shift later DirectShow indices. Unknown names are unselectable
    by the automatic policy. COM references and BSTR variants always release.
    """
    if os.name!='nt':
        raise RuntimeError('自动电脑摄像头选择需要Windows DirectShow；请用 --camera N 明确指定')
    import ctypes as ct
    import uuid

    class GUID(ct.Structure):
        _fields_=[('a',ct.c_uint32),('b',ct.c_uint16),('c',ct.c_uint16),('d',ct.c_ubyte*8)]

    class Value(ct.Union):
        # VARIANT contains a two-pointer BRECORD, including on 64-bit Windows.
        _fields_=[('bstr',ct.c_void_p),('record',ct.c_void_p*2),('integer',ct.c_int64)]

    class VARIANT(ct.Structure):
        _fields_=[('vt',ct.c_uint16),('r1',ct.c_uint16),('r2',ct.c_uint16),
                  ('r3',ct.c_uint16),('value',Value)]

    def guid(value):return GUID.from_buffer_copy(uuid.UUID(value).bytes_le)

    HRESULT=ct.c_long
    ole=ct.OleDLL('ole32')
    auto=ct.OleDLL('oleaut32')
    ole.CoInitializeEx.argtypes=[ct.c_void_p,ct.c_uint32]
    ole.CoInitializeEx.restype=HRESULT
    ole.CoUninitialize.argtypes=[]
    ole.CoUninitialize.restype=None
    ole.CoCreateInstance.argtypes=[ct.POINTER(GUID),ct.c_void_p,ct.c_uint32,
                                  ct.POINTER(GUID),ct.POINTER(ct.c_void_p)]
    ole.CoCreateInstance.restype=HRESULT
    auto.VariantClear.argtypes=[ct.POINTER(VARIANT)]
    auto.VariantClear.restype=HRESULT

    def invoke(pointer,slot,argtypes,*args):
        address=ct.cast(pointer,ct.POINTER(ct.POINTER(ct.c_void_p))).contents[slot]
        method=ct.WINFUNCTYPE(HRESULT,ct.c_void_p,*argtypes)(address)
        return method(pointer,*args)

    def require(result,operation):
        if result<0:raise RuntimeError(f'DirectShow {operation}失败 HRESULT=0x{result&0xffffffff:08X}')

    def release(pointer):
        if pointer:invoke(pointer,2,[])

    def read_property(bag,name):
        value=VARIANT()
        result=invoke(bag,3,[ct.c_wchar_p,ct.POINTER(VARIANT),ct.c_void_p],
                      name,ct.byref(value),None)
        try:
            if result<0 or value.vt!=8 or not value.value.bstr:return ''
            return ct.wstring_at(value.value.bstr)
        finally:auto.VariantClear(ct.byref(value))

    system=guid('62BE5D10-60EB-11D0-BD3B-00A0C911CE86')
    create_enum=guid('29840822-5B84-11D0-BD3B-00A0C911CE86')
    video=guid('860BB310-5D01-11D0-BD3B-00A0C911CE86')
    property_bag=guid('55272A00-42CB-11CE-8135-00AA004BB851')
    # OpenCV's DirectShow backend uses apartment-threaded COM too. Respect a
    # host thread already initialised to another apartment, without uninitialising it.
    result=ole.CoInitializeEx(None,2)
    initialised=result in (0,1)
    if not initialised and (result&0xffffffff)!=0x80010106:require(result,'CoInitializeEx')
    dev_enum=ct.c_void_p()
    enum=ct.c_void_p()
    try:
        require(ole.CoCreateInstance(ct.byref(system),None,1,ct.byref(create_enum),ct.byref(dev_enum)),
                'CoCreateInstance')
        result=invoke(dev_enum,3,[ct.POINTER(GUID),ct.POINTER(ct.c_void_p),ct.c_uint32],
                      ct.byref(video),ct.byref(enum),0)
        if result==1:return []
        require(result,'CreateClassEnumerator')
        devices=[]
        while True:
            moniker=ct.c_void_p()
            fetched=ct.c_ulong()
            result=invoke(enum,3,[ct.c_ulong,ct.POINTER(ct.c_void_p),ct.POINTER(ct.c_ulong)],
                          1,ct.byref(moniker),ct.byref(fetched))
            if result==1:break
            require(result,'IEnumMoniker.Next')
            if fetched.value!=1 or not moniker:
                raise RuntimeError('DirectShow枚举返回无效moniker')
            bag=ct.c_void_p()
            try:
                # IMoniker::BindToStorage (slot9), not BindToObject/IBaseFilter.
                require(invoke(moniker,9,[ct.c_void_p,ct.c_void_p,ct.POINTER(GUID),ct.POINTER(ct.c_void_p)],
                               None,None,ct.byref(property_bag),ct.byref(bag)),'BindToStorage')
                name=read_property(bag,'FriendlyName') or read_property(bag,'Description')
                devices.append(CameraDevice(len(devices),name,read_property(bag,'DevicePath')))
            finally:
                release(bag)
                release(moniker)
        return devices
    finally:
        release(enum)
        release(dev_enum)
        if initialised:ole.CoUninitialize()


def resolve_camera(override=None):
    """Default uses a fresh DirectShow enumeration; explicit index bypasses it."""
    return choose_camera([],override) if override is not None else choose_camera(enumerate_dshow_cameras())
