"""Bundled full Chinese font shared by the instrument interfaces."""
import os
from pathlib import Path
from PySide6.QtGui import QFont,QFontDatabase,QRawFont,QFontInfo,QFontMetrics
FONT_FAMILY='Instrument Sans SC'
BODY=14
SECONDARY=12
SECTION=16
TITLE=22
def initialize_fonts(application):
 directory=Path(os.environ.get('WINDIR',os.environ.get('SystemRoot','')))/'Fonts';loaded=[];source=None
 assets=Path(__file__).parent/'assets/fonts'
 for path in (assets/'InstrumentSansSC-Regular.ttf',):
  if path.is_file():
   index=QFontDatabase.addApplicationFont(str(path))
   if index>=0:
    loaded.extend(QFontDatabase.applicationFontFamilies(index));source=source or str(path)
 family=FONT_FAMILY if FONT_FAMILY in loaded else 'Microsoft YaHei UI'
 font=QFont(family);font.setPixelSize(BODY);font.setWeight(QFont.Weight.Normal)
 application.setFont(font);raw=QRawFont.fromFont(font);metrics=QFontMetrics(font)
 return dict(source=source,families=loaded,actual_family=QFontInfo(font).family(),font_valid=raw.isValid(),raw_weight=raw.weight(),requested_weight=int(font.weight()),chinese_glyph=raw.supportsCharacter('演'),latin_glyph=raw.supportsCharacter('A'),number_glyph=raw.supportsCharacter('7'),digit_widths={str(i):metrics.horizontalAdvance(str(i)) for i in range(10)})
