import unittest
from controller import PerformanceController,selected_notes,TWINKLE

def hands(left=1,right=1,left_pose=None,right_pose=None,provisional=False):
 return {'Left':dict(present=True,digit=left,pose=left_pose or str(left),provisional=provisional),'Right':dict(present=True,digit=right,pose=right_pose or str(right),provisional=False)}

class Sink:
 def __init__(self):self.events=[];self.current=0;self.onsets=[]
 def __call__(self,event):
  self.events.append(event)
  if event[0]=='stop':self.current=0
  elif event[0]=='note':
   if event[1] and event[1]!=self.current:self.onsets.append(event[1])
   self.current=event[1]

class SequenceTests(unittest.TestCase):
 def engine(self):
  sink=Sink();c=PerformanceController(sink,interval_ms=300);c.set_ready(True,True,0.);return c,sink
 def advance(self,c,start,end,state):
  for k in range(round((end-start)/.02)+1):
   t=start+k*.02;c.observe(state,t);c.tick(t)
 def test_all_49_pairs_and_wrap(self):
  for start in range(1,8):
   for count in range(1,8):self.assertEqual(selected_notes(start,count),tuple((start-1+i)%7+1 for i in range(count)))
  self.assertEqual(selected_notes(6,4),(6,7,1,2))
  for pair in [(0,1),(1,8),(True,3),(3,None)]:
   with self.assertRaises(ValueError):selected_notes(*pair)
 def test_one_shot_same_pair_does_not_repeat(self):
  c,s=self.engine();self.advance(c,0,3,hands(6,4));self.assertEqual(s.onsets,[6,7,1,2]);self.assertFalse(c.playing)
  self.advance(c,3.02,5,hands(6,4));self.assertEqual(s.onsets,[6,7,1,2])
  self.advance(c,5.02,6.5,hands(7,3));self.assertEqual(s.onsets,[6,7,1,2,7,1,2])
 def test_left_fist_wins_and_pulses_once(self):
  c,s=self.engine();c.observe(hands(6,4),0.);c.observe(hands(0,0,'fist','fist'),.05)
  self.assertFalse(c.playing);self.assertEqual(s.events[-1],('stop',))
  for k in range(1,20):c.observe(hands(0,0,'fist','fist'),.05+k*.02)
  self.assertEqual(s.events.count(('stop',)),1);self.assertNotEqual(c.label,'小星星')
 def test_right_fist_once_and_confirmed_digit_rearms(self):
  c,s=self.engine();f=hands(1,0,right_pose='fist');self.advance(c,0,18,f)
  self.assertEqual(s.onsets,[n for n,_ in TWINKLE]);self.assertFalse(c.playing)
  self.advance(c,18.02,20,f);self.assertEqual(len(s.onsets),42)
  c.observe(hands(1,1),20.1);c.observe(f,20.2);self.assertEqual(c.label,'小星星');self.assertTrue(c.playing)
 def test_unknown_frame_does_not_retrigger_unchanged_pair(self):
  c,s=self.engine();self.advance(c,0,1,hands(2,2));c.observe({},1.1);self.advance(c,1.2,2,hands(2,2));self.assertEqual(s.onsets,[2,3])
 def test_stale_camera_releases_only_this_source_and_cancels(self):
  c,s=self.engine();c.observe(hands(4,7),0.);c.tick(.7)
  self.assertFalse(c.playing);self.assertEqual(s.current,0);self.assertNotIn(('stop',),s.events)
 def test_no_sound_without_handshake_but_stop_works_when_mode_blocked(self):
  s=Sink();c=PerformanceController(s);c.observe(hands(1,7),0.);self.assertEqual(s.onsets,[])
  c.set_ready(True,False,.1);c.observe(hands(0,0,'fist','fist'),.2);self.assertEqual(s.events[-1],('stop',))
 def test_provisional_digits_cannot_start_new_group(self):
  c,s=self.engine();c.observe(hands(4,5,provisional=True),0.);self.assertFalse(c.playing);self.assertEqual(s.onsets,[])
 def test_note_gap_rearticulates_repeated_song_notes(self):
  c,s=self.engine();self.advance(c,0,.8,hands(1,0,right_pose='fist'));self.assertEqual(s.onsets[:3],[1,1,5])
 def test_song_keeps_playing_after_fist_is_released(self):
  c,s=self.engine();c.observe(hands(1,0,right_pose='fist'),0.)
  self.advance(c,.02,18,hands(1,5))
  self.assertEqual(s.onsets,[n for n,_ in TWINKLE]);self.assertFalse(c.playing)
  self.advance(c,18.02,19,hands(1,5));self.assertEqual(len(s.onsets),42)
 def test_left_fist_can_stop_immediately_after_new_handshake(self):
  s=Sink();c=PerformanceController(s);c.observe(hands(0,0,'fist','fist'),0.)
  c.set_ready(True,False,.1);c.observe(hands(0,0,'fist','fist'),.2);self.assertEqual(s.events[-1],('stop',))
 def test_large_time_jump_never_bursts_queued_notes(self):
  c,s=self.engine();c.observe(hands(1,7),0.);c.observe(hands(1,7),5.);c.tick(5.)
  self.assertLessEqual(len(s.onsets),2)

if __name__=='__main__':unittest.main()
