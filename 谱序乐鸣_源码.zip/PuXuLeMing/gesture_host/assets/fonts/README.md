# 界面字体

随附完整的 Instrument Sans SC Regular，覆盖界面中文、拉丁字母与数字；强调字重由 Qt 生成。当前界面与兼容界面共用本目录字体。原始版权与 SIL Open Font License 原文见 OFL.txt。
