import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import binascii,struct,time,unittest
from types import SimpleNamespace
from PySide6.QtWidgets import QApplication
from app import MainWindow
from gesture_link import GestureLink

class SerialPeer:
 def __init__(self,*args,**kw):self.pending=bytearray();self.writes=[];self.closed=False;self.kw=kw;self.paused=False;self.pause_on_note=None;self.delay=0.;self.ready_at=0.
 def write(self,raw):
  self.writes.append(bytes(raw));seq=struct.unpack_from('<H',raw,4)[0]
  payload=struct.pack('<HHHBBHHHBBBBHI',0x5008,3,seq,0,0,0,0,0,1,1,0,0,0,1234)
  body=struct.pack('<BBHH',2,0x27,seq,24)+payload
  self.pending.extend(b'GS'+body+struct.pack('<H',binascii.crc_hqx(body,0xffff)));self.ready_at=time.monotonic()+self.delay
  if raw[8]==1 and raw[9]==self.pause_on_note:self.paused=True
  return len(raw)
 def read(self,size):
  if self.pending and not self.paused and time.monotonic()>=self.ready_at:data=bytes(self.pending[:size]);del self.pending[:size];return data
  time.sleep(.002);return b''
 def close(self):self.closed=True

class ActualTransportIntegration(unittest.TestCase):
 def setup_window(self):
  QApplication.instance() or QApplication([]);peers=[]
  def sf(*args,**kw):p=SerialPeer(*args,**kw);peers.append(p);return p
  w=MainWindow(autostart=False,link_factory=lambda port,events:GestureLink(port,events,serial_factory=sf),ports_provider=lambda:[SimpleNamespace(device='TEST',description='peer')]);w.connect_board()
  until=time.monotonic()+1
  while time.monotonic()<until:
   w.tick();time.sleep(.005)
   if w.controller.linked and w.worker.last_note==(0,0) and w.worker.pending is None:break
  self.assertTrue(w.controller.linked);return w,peers[0]
 def frame(self,count=4,pose=None):return dict(type='frame',jpeg='',hands={'Left':dict(present=True,digit=6,pose='6'),'Right':dict(present=True,digit=count,pose=pose or str(count))})
 def test_same_start_rearticulates_after_pending_ack(self):
  w,p=self.setup_window()
  try:
   p.pause_on_note=6;w.on_camera_event(self.frame(4));until=time.monotonic()+.2
   while not p.paused and time.monotonic()<until:w.tick();time.sleep(.002)
   self.assertTrue(p.paused);first=next(i for i,b in enumerate(p.writes) if b[8]==1 and b[9]==6)
   w.on_camera_event(self.frame(3));p.pause_on_note=None;p.paused=False;until=time.monotonic()+.12
   while time.monotonic()<until:w.on_camera_event(self.frame(3));w.tick();time.sleep(.003)
   self.assertEqual([b[9] for b in p.writes[first+1:] if b[8]==1][:2],[0,6])
  finally:w.close()
 def test_repeated_song_note_survives_delayed_ack(self):
  w,p=self.setup_window()
  try:
   p.delay=.06;w.interval.setValue(100);f=self.frame(0,'fist');w.on_camera_event(f);until=time.monotonic()+.45
   while time.monotonic()<until:w.on_camera_event(f);w.tick();time.sleep(.005)
   self.assertEqual([b[9] for b in p.writes if b[8]==1 and b[9]][:2],[1,1])
  finally:w.close()
 def test_hard_stop_delayed_ack_invalidates_previous_same_pitch(self):
  w,p=self.setup_window()
  try:
   w.on_camera_event(self.frame(1));until=time.monotonic()+.2
   while w.worker.acknowledged_note!=6 and time.monotonic()<until:w.tick();time.sleep(.002)
   self.assertEqual(w.worker.acknowledged_note,6)
   p.delay=.12;w.interval.setValue(100);w.controller.stop(True)
   self.assertFalse(w.worker.note_acknowledged(6))
   w.on_camera_event(self.frame(2));until=time.monotonic()+2
   while w.controller.playing and time.monotonic()<until:w.on_camera_event(self.frame(2));w.tick();time.sleep(.003)
   stopidx=next(i for i,b in enumerate(p.writes) if b[8]==2)
   onsets=[];last=0
   for raw in p.writes[stopidx+1:]:
    if raw[8]==1:
     if raw[9] and raw[9]!=last:onsets.append(raw[9])
     last=raw[9]
   self.assertEqual(onsets,[6,7])
  finally:w.close()
 def test_complete_twinkle_with_ack_slower_than_note_interval(self):
  from controller import TWINKLE
  w,p=self.setup_window()
  try:
   p.delay=.12;w.interval.setValue(100);f=self.frame(0,'fist');w.on_camera_event(f);until=time.monotonic()+22
   while w.controller.playing and time.monotonic()<until:w.on_camera_event(f);w.tick();time.sleep(.003)
   self.assertFalse(w.controller.playing)
   onsets=[];last=0
   for raw in p.writes:
    if raw[8]==1:
     note=raw[9]
     if note and note!=last:onsets.append(note)
     last=note
   self.assertEqual(onsets,[n for n,_ in TWINKLE]);self.assertEqual(last,0)
  finally:w.close()
 def test_actual_ui_scheduler_worker_crc_ack_and_wrapped_notes(self):
  app=QApplication.instance() or QApplication([]);peers=[]
  def serial_factory(*args,**kw):p=SerialPeer(*args,**kw);peers.append(p);return p
  def link_factory(port,events):return GestureLink(port,events,serial_factory=serial_factory,initial_seq=0x7ffe)
  w=MainWindow(autostart=False,link_factory=link_factory,ports_provider=lambda:[SimpleNamespace(device='TEST',description='in-process protocol peer')])
  frame=dict(type='frame',jpeg='',detected_hands=2,hands={'Left':dict(present=True,digit=6,pose='6'),'Right':dict(present=True,digit=4,pose='4')})
  try:
   w.connect_board();until=time.monotonic()+1
   while not w.controller.linked and time.monotonic()<until:w.tick();time.sleep(.005)
   self.assertTrue(w.controller.linked);self.assertEqual(peers[0].kw['baudrate'],115200)
   w.interval.setValue(100);until=time.monotonic()+.8
   while time.monotonic()<until:w.on_camera_event(frame);w.tick();time.sleep(.01)
   self.assertEqual([raw[9] for raw in peers[0].writes if raw[8]==1 and raw[9]],[6,7,1,2])
   fist=dict(type='frame',jpeg='',hands={'Left':dict(present=True,digit=0,pose='fist'),'Right':dict(present=True,digit=0,pose='fist')})
   w.on_camera_event(fist);until=time.monotonic()+.2
   while not any(raw[8]==2 for raw in peers[0].writes) and time.monotonic()<until:w.tick();time.sleep(.005)
   self.assertEqual(sum(raw[8]==2 for raw in peers[0].writes),1)
   for raw in peers[0].writes:
    self.assertEqual(raw[:4],b'GS\x02\x26');self.assertEqual(raw[12:16],b'P8G1')
    self.assertEqual(struct.unpack_from('<H',raw,16)[0],binascii.crc_hqx(raw[2:16],0xffff))
  finally:w.close()
  self.assertTrue(peers[0].closed)

if __name__=='__main__':unittest.main()
