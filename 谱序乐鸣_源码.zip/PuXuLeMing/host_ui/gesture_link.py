"""Gesture-only GS2 transport. One serial owner, FPGA performs all synthesis."""
import binascii
import json
import queue
import secrets
import struct
import threading
import time

FIRMWARE=0x5008

def encode_command(seq, op, note=0, velocity=0):
    if op not in (0,1,2) or type(note) is not int or not 0<=note<=7 or not 0<=velocity<=127:
        raise ValueError('Invalid gesture command')
    if op in (0,2) and (note or velocity):raise ValueError('Poll/stop has no note')
    payload=bytes((op,note,velocity if note else 0,0))+b'P8G1'
    body=struct.pack('<BBHH',2,0x26,seq&0xffff,8)+payload
    return b'GS'+body+struct.pack('<H',binascii.crc_hqx(body,0xffff))

class Decoder:
    def __init__(self):self.buffer=bytearray();self.errors=0
    def feed(self,data):
        self.buffer.extend(data);frames=[]
        while True:
            pos=self.buffer.find(b'GS')
            if pos<0:
                if self.buffer and self.buffer!=b'G':self.errors+=1
                self.buffer[:]=self.buffer[-1:] if self.buffer[-1:]==b'G' else b''
                break
            if pos:self.errors+=1;del self.buffer[:pos]
            if len(self.buffer)<8:break
            version,kind,seq,size=struct.unpack_from('<BBHH',self.buffer,2)
            if (version,kind,size)!=(2,0x27,24):
                self.errors+=1;del self.buffer[0];continue
            if len(self.buffer)<34:break
            if binascii.crc_hqx(self.buffer[2:32],0xffff)!=struct.unpack_from('<H',self.buffer,32)[0]:
                self.errors+=1;del self.buffer[0];continue
            frames.append((seq,bytes(self.buffer[8:32])));del self.buffer[:34]
        return frames

def parse_status(payload):
    if len(payload)!=24:raise ValueError('乐器应答长度异常，请重新连接')
    firmware,caps,ack,result,flags,count,record_ms,play_ms,mode,page,gates,note,errors,uptime=struct.unpack('<HHHBBHHHBBBBHI',payload)
    if firmware==0:
        raise ValueError('乐器应答内容异常，请加载 impl/pnr/ProjectIntegratedFinal.fs 后连接')
    if firmware!=FIRMWARE or caps&1==0:
        raise ValueError(f'当前码流协议 {firmware:04X} 不支持手势接口，请加载 impl/pnr/ProjectIntegratedFinal.fs')
    return dict(firmware=firmware,capabilities=caps,ack=ack,result=result,
                gates=gates,note=note,mode=mode,page=page,uptime_ms=uptime,link_errors=errors,
                muted=bool(flags&1),pattern_mode=(flags>>1)&3,playable=mode!=2 and flags&7==0)

class GestureLink(threading.Thread):
    def __init__(self,port_name,events,serial_factory=None,handshake_timeout=1.5,initial_seq=None,trace_path=None):
        super().__init__(daemon=True,name='Gesture serial')
        self.port_name,self.events=port_name,events
        self.serial_factory=serial_factory;self.handshake_timeout=handshake_timeout
        self.seq=secrets.randbelow(65536) if initial_seq is None else initial_seq
        self.trace_path=trace_path;self.trace_file=None;self.port=None
        self.connected=False;self.playable=True;self.capabilities=0;self.stop_pending=False;self.closing=threading.Event();self.lock=threading.Lock()
        self.requested=(0,0,0.);self.pending=None;self.last_note=None
        self.last_note_at=-100.;self.last_send=-100.;self.decoder=Decoder()
    def emit(self,kind,**values):self.events.put(dict(type=kind,**values))
    def trace(self,kind,**values):
        if self.trace_file:
            self.trace_file.write(json.dumps(dict(t=time.monotonic(),type=kind,**values),ensure_ascii=False)+'\n')
            self.trace_file.flush()
    def set_note(self,note,velocity=100):
        encode_command(0,1,note,velocity)
        with self.lock:self.requested=(note,velocity if note else 0,time.monotonic()+.5)
    def disconnect(self):self.set_note(0,0);self.closing.set()
    def emergency_stop(self):
        with self.lock:
            self.requested=(0,0,0.);self.stop_pending=True
    def send(self,op,note=0,velocity=0):
        seq=self.seq;self.seq=(seq+1)&65535;raw=encode_command(seq,op,note,velocity)
        self.trace('tx',raw=raw.hex(),seq=seq,op=op,note=note)
        if self.port.write(raw)!=len(raw):raise OSError('串口指令未完整发送，请重新连接')
        self.pending=(seq,time.monotonic());self.last_send=time.monotonic()
        if op==1:self.last_note=(note,velocity);self.last_note_at=self.last_send
        elif op==2:self.last_note=(0,0);self.last_note_at=self.last_send
    def run(self):
        try:
            if self.trace_path:
                self.trace_path.parent.mkdir(parents=True,exist_ok=True)
                self.trace_file=self.trace_path.open('w',encoding='utf-8')
            if self.serial_factory is None:
                import serial
                self.serial_factory=serial.Serial
            self.port=self.serial_factory(self.port_name,baudrate=115200,timeout=.02,write_timeout=.3)
            started=time.monotonic();last_response=started;closing_until=None
            self.send(0)
            while True:
                if self.closing.is_set() and closing_until is None:closing_until=time.monotonic()+.3
                raw=self.port.read(4096)
                if raw:self.trace('rx',raw=raw.hex())
                for seq,payload in self.decoder.feed(raw):
                    ack=struct.unpack_from('<H',payload,4)[0]
                    # Identity is meaningful only for our current transaction.
                    if self.pending is None or seq!=self.pending[0] or ack!=seq:
                        self.trace('unmatched_status',seq=seq,ack=ack,payload=payload.hex());continue
                    status=parse_status(payload);self.trace('status',**status)
                    self.pending=None;last_response=time.monotonic()
                    if not self.connected:
                        self.connected=True;self.emit('connected',port=self.port_name)
                    self.capabilities=status['capabilities'];self.playable=status['playable'];self.emit('status',**status)
                    if status['result']==2:self.last_note=None
                    elif status['result']==3:self.last_note=None
                    elif status['result']:raise RuntimeError('乐器未接受手势指令，请重新连接')
                now=time.monotonic()
                if closing_until is not None:
                    if self.pending is None:
                        if self.last_note==(0,0) and self.last_note_at>=closing_until-.3:break
                        self.send(1,0,0)
                    if now>=closing_until:break
                    continue
                if not self.connected and now-started>self.handshake_timeout:
                    raise TimeoutError('串口已打开，但乐器未回复。请加载 impl/pnr/ProjectIntegratedFinal.fs 后连接')
                if self.connected and now-last_response>1.2:raise TimeoutError('乐器连接已中断，手势已止音')
                with self.lock:
                    urgent=self.stop_pending and self.connected
                    if urgent:self.stop_pending=False
                if urgent:
                    if self.capabilities&2==0:raise RuntimeError('当前码流没有硬止音能力，请加载 impl/pnr/ProjectIntegratedFinal.fs')
                    # The serial worker remains the only writer. A matching stop
                    # ACK replaces any older pending note transaction.
                    self.send(2);continue
                if self.pending:
                    if self.connected and now-self.pending[1]>.7:raise TimeoutError('乐器应答超时，手势已止音')
                    continue
                with self.lock:note,velocity,until=self.requested
                desired=(note,velocity) if now<until and self.playable else (0,0)
                if self.last_note!=desired or (desired[0] and now-self.last_note_at>=.15):self.send(1,*desired)
                elif now-self.last_send>=.2:self.send(0)
        except Exception as exc:
            self.trace('error',message=str(exc));self.emit('error',message=str(exc))
        finally:
            if self.port:
                try:self.send(1,0,0)
                except Exception:pass
                self.port.close()
            self.connected=False
            if self.trace_file:self.trace_file.close()
            self.emit('disconnected')
