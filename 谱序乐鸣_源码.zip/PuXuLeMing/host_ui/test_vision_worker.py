"""Offline geometry and fail-safe note protocol; never acquires hardware."""
import io
import json
import math
import queue
import threading
import unittest
from contextlib import redirect_stdout, redirect_stderr
from unittest.mock import patch, Mock

from vision_worker import NoteGate, classify_gesture, emit, read_controls, run_camera, check
from camera_source import CameraDevice, choose_camera, resolve_camera


def hand(fingers=(1, 1, 1, 1), thumb=True):
    points = [(.5, .9, 0.)] * 21
    points[1:5] = ([(.40,.72,0),(.28,.63,0),(.18,.54,0),(.08,.45,0)]
                   if thumb else [(.40,.72,0),(.40,.64,0),(.48,.59,0),(.52,.66,0)])
    for i, straight in enumerate(fingers):
        x = .39 + .085*i
        points[5+4*i:9+4*i] = [(x,.55,0),(x,.40,0),
            (x,.28 if straight else .48,0),(x,.15 if straight else .60,0)]
    return points


def seven():
    points = hand((0,0,0,0), False)
    points[2:5] = [(.34,.59,0),(.41,.43,0),(.47,.32,0)]
    points[6:9] = [(.40,.39,0),(.43,.32,0),(.45,.30,0)]
    points[10:13] = [(.48,.39,0),(.49,.32,0),(.49,.30,0)]
    return points


POSES = {'1':hand((1,0,0,0),False), '2':hand((1,1,0,0),False),
         '3':hand((1,1,1,0),False), '4':hand((1,1,1,1),False),
         '5':hand(), '6':hand((0,0,0,1)), '7':seven()}


class GeometryTests(unittest.TestCase):
    def test_all_notes_and_fist(self):
        for name, points in POSES.items():
            with self.subTest(pose=name):
                self.assertEqual(classify_gesture(points), name)
        self.assertEqual(classify_gesture(hand((0,0,0,0),False)), 'fist')

    def test_mirror_scale_and_3d_rotation(self):
        for expected, points in POSES.items():
            for angle in (0,.8,2.4):
                for sign in (-1,1):
                    # Rotate x/y then y/z; geometric distances/angles must survive.
                    transformed=[]
                    for x,y,z in points:
                        a=sign*(x*math.cos(angle)-y*math.sin(angle))*.4
                        b=(x*math.sin(angle)+y*math.cos(angle))*.4
                        transformed.append((a+3,b*.6-z*.8-2,b*.8+z*.6+1))
                    self.assertEqual(classify_gesture(transformed),expected)

    def test_invalid_degenerate_ambiguous_and_unmapped(self):
        ambiguous=hand((1,0,0,0),False)
        ambiguous[8]=(.39+.18*math.sin(math.radians(35)),
                      .40-.18*math.cos(math.radians(35)),0)
        for points in (None, [], [None]*21, [(0,0,0)]*21,
                       [(float('nan'),0,0)]*21, hand()[:20], ambiguous,
                       hand((0,0,1,0),False),hand((0,0,0,0),True)):
            self.assertEqual(classify_gesture(points),'unknown')

    def test_loose_or_partial_pinch_is_unknown(self):
        loose=seven()
        loose[4]=(.1,.3,0)
        self.assertEqual(classify_gesture(loose),'unknown')
        partial=seven()
        partial[12]=(.48,.6,0)
        self.assertEqual(classify_gesture(partial),'unknown')


class GateTests(unittest.TestCase):
    def setUp(self):
        self.gate=NoteGate()

    def on(self,pose='1',start=0.):
        self.gate.set_enabled(True)
        self.assertEqual(self.gate.update(pose,True,start),[])
        self.assertEqual(self.gate.update(pose,True,start+.1),[])
        return self.gate.update(pose,True,start+.16)

    def test_opt_in_and_stable_hold(self):
        self.assertEqual(self.gate.update('1',True,0),[])
        self.assertEqual(self.gate.update('1',True,.2),[])
        self.assertEqual(self.on(),[(1,100)])
        self.assertEqual(self.gate.update('1',True,.3),[])
        self.assertEqual(self.gate.update('1',True,.4),[])

    def test_all_notes(self):
        for note in range(1,8):
            self.gate=NoteGate()
            self.assertEqual(self.on(str(note)),[(note,100)])

    def test_change_off_precedes_stable_new_on(self):
        self.on()
        self.assertEqual(self.gate.update('2',True,.2),[(0,0)])
        self.assertEqual(self.gate.update('2',True,.3),[])
        self.assertEqual(self.gate.update('2',True,.36),[(2,100)])
        self.assertEqual(self.gate.update('2',True,.4),[])

    def test_brief_poses_never_trigger(self):
        self.gate.set_enabled(True)
        self.assertEqual(self.gate.update('1',True,0),[])
        self.assertEqual(self.gate.update('2',True,.1),[])
        self.assertEqual(self.gate.update('3',True,.2),[])
        self.assertEqual(self.gate.active_note,0)

    def test_loss_unknown_fist_disable_and_stop_release(self):
        for pose,tracking in [('unknown',True),('fist',True),('1',False)]:
            self.gate=NoteGate()
            self.on()
            self.assertEqual(self.gate.update(pose,tracking,.2),[(0,0)])
            self.assertEqual(self.gate.update(pose,tracking,.3),[])
        self.gate=NoteGate()
        self.on()
        self.assertEqual(self.gate.set_enabled(False),[(0,0)])
        self.assertEqual(self.gate.set_enabled(False),[])
        self.assertEqual(self.on('1',1),[(1,100)])
        self.assertEqual(self.gate.stop(),[(0,0)])

    def test_gap_reverse_and_invalid_time_fail_closed(self):
        for now in (1.,.1,float('nan')):
            self.gate=NoteGate()
            self.on()
            self.assertEqual(self.gate.update('1',True,now),[(0,0)])
            self.assertEqual(self.gate.active_note,0)

    def test_reacquisition_requires_full_hold(self):
        self.on()
        self.gate.update('1',False,.2)
        self.assertEqual(self.gate.update('1',True,.21),[])
        self.assertEqual(self.gate.update('1',True,.31),[])
        self.assertEqual(self.gate.update('1',True,.38),[(1,100)])


class ProtocolTests(unittest.TestCase):
    def test_control_validation_and_eof_stop(self):
        inbox,stopped=queue.SimpleQueue(),threading.Event()
        data='[]\n{"type":"enable","enabled":"false"}\n{"type":"enable","enabled":true}\n'
        with patch('sys.stdin',io.StringIO(data)),redirect_stderr(io.StringIO()):
            read_controls(inbox,stopped)
        self.assertTrue(stopped.is_set())
        self.assertTrue(inbox.get_nowait())
        self.assertTrue(inbox.empty())

    def test_stop_ignores_later_enable(self):
        inbox,stopped=queue.SimpleQueue(),threading.Event()
        with patch('sys.stdin',io.StringIO('{"type":"stop"}\n{"type":"enable","enabled":true}\n')):
            read_controls(inbox,stopped)
        self.assertTrue(stopped.is_set())
        self.assertTrue(inbox.empty())

    def test_one_utf8_json_line(self):
        output=io.StringIO()
        message={'type':'frame','gesture':'六 · A4'}
        with redirect_stdout(output):emit(message)
        self.assertEqual(len(output.getvalue().splitlines()),1)
        self.assertEqual(json.loads(output.getvalue()),message)

    def test_camera_failure_releases_active_note_and_closes_resources(self):
        gate=NoteGate()
        gate.enabled=True
        gate.active_note=3
        cv2,mp,np,detector=Mock(),Mock(),Mock(),Mock()
        capture=cv2.VideoCapture.return_value
        capture.isOpened.return_value=True
        capture.read.side_effect=RuntimeError('synthetic capture error')
        output=io.StringIO()
        with patch('vision_worker.load_runtime',return_value=(cv2,mp,np,detector)), \
             patch('vision_worker.NoteGate',return_value=gate), \
             patch('vision_worker.threading.Thread'),redirect_stdout(output):
            with self.assertRaisesRegex(RuntimeError,'synthetic capture error'):
                run_camera(0,None,15)
        messages=[json.loads(line) for line in output.getvalue().splitlines()]
        self.assertEqual([(m['index'],m['velocity']) for m in messages],[(0,0)])
        capture.release.assert_called_once()
        detector.close.assert_called_once()


class CameraSelectionTests(unittest.TestCase):
    def test_realistic_dshow_order_prefers_fhd_to_phone(self):
        devices=[CameraDevice(0,'荣耀Magic8前置摄像头','phone-front'),
                 CameraDevice(1,'荣耀Magic8后置摄像头','phone-rear'),
                 CameraDevice(2,'FHD Camera','usb-physical')]
        self.assertEqual(choose_camera(devices).index,2)

    def test_device_index_is_preserved_not_list_position(self):
        self.assertEqual(choose_camera([CameraDevice(7,'FHD Camera','usb')]).index,7)

    def test_reordering_never_selects_phone(self):
        from itertools import permutations
        names=['HONOR Magic8','Phone Camera','Integrated Camera']
        for ordered in permutations(names):
            devices=[CameraDevice(i,name,'') for i,name in enumerate(ordered)]
            self.assertEqual(choose_camera(devices).name,'Integrated Camera')

    def test_known_computer_names_and_real_usb_fallback(self):
        for name in ('FHD Camera','Integrated Webcam','HP HD Camera','USB Video Device','Logitech Webcam C920','电脑摄像头'):
            with self.subTest(name=name):
                self.assertEqual(choose_camera([CameraDevice(3,name,'')]).index,3)

    def test_phone_virtual_and_ir_are_never_automatic(self):
        for name in ('荣耀Magic8前置','HONOR Camera','Magic8 Rear','iPhone Camera',
                     'DroidCam','Iriun Webcam','OBS Virtual Camera','ManyCam',
                     'Camo Camera','Phone Link','Integrated IR Camera'):
            with self.subTest(name=name),self.assertRaisesRegex(RuntimeError,'电脑摄像头'):
                choose_camera([CameraDevice(0,name,'')])

    def test_no_computer_does_not_fall_back_to_phone_or_unknown(self):
        for devices in ([],[CameraDevice(0,'陌生设备','')],
                        [CameraDevice(0,'手机摄像头',''),CameraDevice(1,'OBS Virtual Camera','')]):
            with self.assertRaisesRegex(RuntimeError,'电脑摄像头'):
                choose_camera(devices)

    def test_explicit_override_can_select_phone(self):
        devices=[CameraDevice(0,'HONOR Magic8',''),CameraDevice(2,'FHD Camera','')]
        self.assertEqual(choose_camera(devices,override=0).name,'HONOR Magic8')

    def test_explicit_override_need_not_enumerate(self):
        selected=choose_camera([],override=9)
        self.assertEqual(selected.index,9)
        self.assertEqual(selected.name,'指定摄像头 9')
        with patch('camera_source.enumerate_dshow_cameras') as enumerate_devices:
            self.assertEqual(resolve_camera(9).index,9)
        enumerate_devices.assert_not_called()

    def test_negative_or_boolean_override_rejected(self):
        for value in (-1,True,1.5,'0'):
            with self.assertRaises(ValueError):choose_camera([],override=value)

    def test_default_resolves_fresh_directshow_order(self):
        with patch('camera_source.enumerate_dshow_cameras',return_value=[
                CameraDevice(0,'Phone Camera',''),CameraDevice(1,'FHD Camera','')]) as enumerate_devices:
            self.assertEqual(resolve_camera().index,1)
        enumerate_devices.assert_called_once()

    def test_worker_passes_selected_index_to_capture(self):
        cv2,mp,np,detector=Mock(),Mock(),Mock(),Mock()
        capture=cv2.VideoCapture.return_value
        capture.isOpened.return_value=True
        capture.read.side_effect=RuntimeError('fixture end')
        with patch('vision_worker.resolve_camera',return_value=CameraDevice(4,'FHD Camera','')) as resolve, \
             patch('vision_worker.load_runtime',return_value=(cv2,mp,np,detector)), \
             patch('vision_worker.threading.Thread'),redirect_stderr(io.StringIO()):
            with self.assertRaisesRegex(RuntimeError,'fixture end'):run_camera(None,None,15)
        resolve.assert_called_once_with(None)
        cv2.VideoCapture.assert_called_once_with(4,cv2.CAP_DSHOW)
        capture.release.assert_called_once()

    def test_default_failure_never_loads_runtime_or_probes_camera(self):
        with patch('vision_worker.resolve_camera',side_effect=RuntimeError('未找到电脑摄像头')), \
             patch('vision_worker.load_runtime') as runtime:
            with self.assertRaisesRegex(RuntimeError,'电脑摄像头'):run_camera(None,None,15)
        runtime.assert_not_called()

    def test_cli_default_uses_automatic_selection(self):
        import vision_worker
        with patch('sys.argv',['vision_worker.py']),patch('vision_worker.run_camera') as run, \
             patch('sys.stdout',Mock()),patch('sys.stderr',Mock()):
            self.assertEqual(vision_worker.main(),0)
        self.assertIsNone(run.call_args.args[0])

    def test_cli_explicit_index_is_preserved(self):
        import vision_worker
        with patch('sys.argv',['vision_worker.py','--camera','0']), \
             patch('vision_worker.run_camera') as run,patch('sys.stdout',Mock()),patch('sys.stderr',Mock()):
            self.assertEqual(vision_worker.main(),0)
        self.assertEqual(run.call_args.args[0],0)

    def test_check_never_acquires_camera(self):
        from pathlib import Path
        cv2,mp,np,detector=Mock(),Mock(),Mock(),Mock()
        cv2.__version__,mp.__version__,np.__version__='fake','fake','fake'
        detector.detect_for_video.return_value.hand_landmarks=[]
        model=Mock(spec=Path)
        model.read_bytes.return_value=b'fixture model'
        output=io.StringIO()
        with patch('vision_worker.load_runtime',return_value=(cv2,mp,np,detector)),redirect_stdout(output):
            check(model)
        cv2.VideoCapture.assert_not_called()
        message=json.loads(output.getvalue())
        self.assertFalse(message['camera_opened'])
        self.assertEqual(message['blank_hands'],0)
        detector.close.assert_called_once()


if __name__=='__main__':
    unittest.main(verbosity=2)
