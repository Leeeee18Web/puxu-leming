"""Single-purpose gesture instrument UI. Device acquisition is always opt-in."""
import base64
import datetime
import json
from pathlib import Path
import queue
import re
import time
from PySide6.QtCore import QProcess,QTimer,Qt,QRectF
from PySide6.QtGui import QColor,QImage,QPainter,QPixmap
from PySide6.QtWidgets import (QCheckBox,QComboBox,QFrame,QHBoxLayout,QLabel,QMainWindow,
    QPushButton,QSizePolicy,QVBoxLayout,QWidget)
from gesture_link import GestureLink
from theme import STYLE

ROOT=Path(__file__).resolve().parents[1]
VISION_PYTHON=Path(sys.executable)
NOTES=('C4','D4','E4','F4','G4','A4','B4')
POSES=('只伸食指','食指、中指伸直','食指、中指、无名指伸直','四指伸直，拇指收起',
       '五指张开','拇指、小指伸出','拇指、食指、中指指尖捏合')

def scan_serial_ports():
    from serial.tools import list_ports
    return list(list_ports.comports())

class PortSelector(QComboBox):
    def __init__(self):
        super().__init__();self.setEditable(True);self.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
        self.lineEdit().setPlaceholderText('选择串口 / 输入 COM 端口')
        self.setMinimumContentsLength(16);self.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Fixed)
    def device_name(self):
        i=self.currentIndex();s=self.currentText().strip()
        return (self.itemData(i) or '') if i>=0 and s==self.itemText(i) else s

class CameraView(QWidget):
    def __init__(self):
        super().__init__();self.image=QImage();self.caption='摄像头已关闭'
        self.setMinimumSize(400,300);self.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Expanding)
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor('#142d3b'));p.drawRoundedRect(self.rect(),10,10)
        if not self.image.isNull():
            size=self.image.size().scaled(self.size(),Qt.AspectRatioMode.KeepAspectRatio)
            r=QRectF((self.width()-size.width())/2,(self.height()-size.height())/2,size.width(),size.height())
            p.drawImage(r,self.image)
        else:
            p.setPen(QColor('#a3b9c6'));p.drawText(self.rect(),Qt.AlignmentFlag.AlignCenter,self.caption)
    def clear(self,caption='摄像头已关闭'):self.image=QImage();self.caption=caption;self.update()
    def set_frame(self,data):
        img=QImage.fromData(data)
        if not img.isNull():self.image=img;self.update()

class MainWindow(QMainWindow):
    def __init__(self,port_scanner=scan_serial_ports,worker_factory=GestureLink):
        super().__init__();self.setWindowTitle('Project8 · 手势演奏')
        self.resize(1100,770);self.setMinimumSize(940,710);self.setStyleSheet(STYLE)
        self.port_scanner,self.worker_factory=port_scanner,worker_factory
        self.worker=None;self.connected=False;self.events=queue.Queue();self.port_snapshot=None
        self.vision=None;self.vision_buffer=bytearray();self.last_frame=0.;self.camera_stopping=False
        self.camera_failed=False;self.closing=False;self.frame_stale=False;self.current_note=0
        root=QWidget();root.setObjectName('root');self.setCentralWidget(root)
        layout=QVBoxLayout(root);layout.setContentsMargins(24,20,24,18);layout.setSpacing(16)
        heading=QHBoxLayout();title=QLabel('手势演奏');title.setObjectName('title');heading.addWidget(title)
        subtitle=QLabel('Project8 / Tang Mega 138K');subtitle.setObjectName('subtle');heading.addWidget(subtitle);heading.addStretch()
        self.camera_button=QPushButton('开启摄像头');self.camera_button.setObjectName('camera')
        self.camera_button.clicked.connect(self.toggle_camera);heading.addWidget(self.camera_button);layout.addLayout(heading)
        connection=QFrame();connection.setObjectName('connection');row=QHBoxLayout(connection);row.setContentsMargins(14,12,14,12)
        self.port=PortSelector();row.addWidget(self.port,1)
        self.refresh_button=QPushButton('刷新');self.refresh_button.clicked.connect(lambda:self.refresh_ports(True));row.addWidget(self.refresh_button)
        self.connect_button=QPushButton('连接乐器');self.connect_button.setObjectName('primary');self.connect_button.clicked.connect(self.toggle_connection);row.addWidget(self.connect_button)
        self.link_status=QLabel('未连接');self.link_status.setObjectName('subtle');self.link_status.setMinimumWidth(70);row.addWidget(self.link_status)
        layout.addWidget(connection)
        content=QHBoxLayout();content.setSpacing(18);self.preview=CameraView();content.addWidget(self.preview,1)
        result=QFrame();result.setObjectName('result');result.setFixedWidth(244)
        side=QVBoxLayout(result);side.setContentsMargins(24,22,24,22);side.setSpacing(10)
        caption=QLabel('识别结果');caption.setObjectName('subtle');side.addWidget(caption)
        self.digit=QLabel('—');self.digit.setObjectName('digit');self.digit.setFixedHeight(98);side.addWidget(self.digit)
        self.pitch=QLabel('等待手势');self.pitch.setObjectName('pitch');side.addWidget(self.pitch)
        side.addStretch(1)
        self.sound=QCheckBox('手势发声');self.sound.setChecked(True);self.sound.setEnabled(False)
        self.sound.toggled.connect(self.sound_changed);side.addWidget(self.sound)
        self.mute_button=QPushButton('止音');self.mute_button.clicked.connect(self.mute);self.mute_button.setEnabled(False);side.addWidget(self.mute_button)
        content.addWidget(result);layout.addLayout(content,1)
        foot=QHBoxLayout();self.vision_status=QLabel('开启摄像头即可查看识别');self.vision_status.setObjectName('subtle');foot.addWidget(self.vision_status,1)
        hint=QLabel('握拳或移开手即止音');hint.setObjectName('subtle');foot.addWidget(hint);layout.addLayout(foot)
        guide=QFrame();guide.setObjectName('guide');keys=QHBoxLayout(guide);keys.setContentsMargins(14,13,14,13);keys.setSpacing(16)
        self.guide_labels=[]
        for i in range(7):
            col=QVBoxLayout();col.setSpacing(5)
            note=QLabel(f'{i+1}   {NOTES[i]}');note.setObjectName('guideNote');col.addWidget(note)
            short=('只伸食指','食指、中指伸直','食指、中指、无名指','四指伸直，拇指收起','五指张开','拇指、小指伸出','拇指、食指、中指捏合')[i]
            desc=QLabel(short);desc.setToolTip(POSES[i]);desc.setObjectName('guidePose');desc.setWordWrap(True);desc.setMinimumHeight(42);col.addWidget(desc)
            keys.addLayout(col,1);self.guide_labels.append(note)
        layout.addWidget(guide)
        self.message=QLabel('');self.message.setObjectName('message');self.message.setWordWrap(True);self.message.setMinimumHeight(20);layout.addWidget(self.message)
        self.refresh_ports()
        self.timer=QTimer(self);self.timer.timeout.connect(self.tick);self.timer.start(30)
        self.port_timer=QTimer(self);self.port_timer.timeout.connect(self.refresh_ports);self.port_timer.start(1500)
    def refresh_ports(self,force=False):
        if self.worker:return
        try:ports=self.port_scanner()
        except Exception as exc:self.message.setText(f'串口枚举失败：{exc}');return
        snapshot=[(p.device,p.description) for p in ports]
        if not force and snapshot==self.port_snapshot:return
        previous=self.port.device_name();self.port_snapshot=snapshot
        self.port.blockSignals(True);self.port.clear()
        for device,description in snapshot:self.port.addItem(f'{device} · {description}',device)
        index=self.port.findData(previous)
        if index>=0:self.port.setCurrentIndex(index)
        elif previous:self.port.setEditText(previous)
        self.port.blockSignals(False)
        if force:self.message.setText(f'找到 {len(ports)} 个串口' if ports else '未发现串口，请连接开发板 USB 串口')
    def toggle_connection(self):
        if self.worker:
            self.release();self.worker.disconnect();self.connect_button.setEnabled(False);self.link_status.setText('断开中');return
        name=self.port.device_name().strip().upper()
        if not re.fullmatch(r'COM[1-9][0-9]*',name):self.message.setText('请选择开发板的 COM 串口');return
        self.message.setText('正在等待乐器应答…');self.link_status.setText('连接中')
        self.port.setEnabled(False);self.refresh_button.setEnabled(False);self.connect_button.setEnabled(False)
        stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
        trace=Path(__file__).resolve().parents[1]/'build/host_traces'/(stamp+'.jsonl')
        self.worker=self.worker_factory(name,self.events,trace_path=trace);self.worker.start()
    def release(self):
        if self.worker:self.worker.set_note(0,0)
    def sound_changed(self,enabled):
        if not enabled:self.release()
    def mute(self):self.sound.setChecked(False);self.release()
    def toggle_camera(self):
        if self.vision:
            self.stop_camera();return
        if not VISION_PYTHON.is_file():self.vision_status.setText('手势识别运行环境缺失');return
        self.camera_failed=False;self.camera_stopping=False;self.frame_stale=False;self.last_frame=0.
        self.vision_buffer.clear();self.preview.clear('正在打开电脑摄像头…')
        process=QProcess(self);self.vision=process
        process.setProgram(str(VISION_PYTHON));process.setArguments(['-B',str(Path(__file__).with_name('vision_worker.py'))])
        process.setWorkingDirectory(str(ROOT))
        process.readyReadStandardOutput.connect(self.read_vision)
        process.readyReadStandardError.connect(lambda:process.readAllStandardError())
        process.started.connect(lambda:process.write(b'{"type":"enable","enabled":true}\n'))
        process.finished.connect(lambda *args:self.camera_finished(process))
        process.errorOccurred.connect(lambda error:self.camera_error(process))
        self.camera_button.setText('关闭摄像头');self.vision_status.setText('正在打开电脑摄像头…');process.start()
    def camera_error(self,process):
        if self.vision is not process:return
        if self.closing or self.camera_stopping:
            self.release();return
        message='摄像头进程无法启动' if process.error()==QProcess.ProcessError.FailedToStart else '摄像头识别进程中断，已止音'
        self.on_vision_event(dict(type='error',message=message))
        if process.state()==QProcess.ProcessState.NotRunning:self.camera_finished(process)
    def stop_camera(self):
        self.release()
        if not self.vision:return
        self.camera_stopping=True;self.camera_button.setEnabled(False)
        process=self.vision
        if process.state()!=QProcess.ProcessState.NotRunning:process.write(b'{"type":"stop"}\n')
        QTimer.singleShot(1200,lambda:self.force_camera_stop(process))
    def force_camera_stop(self,process):
        if self.vision is process and process.state()!=QProcess.ProcessState.NotRunning:process.kill()
    def camera_finished(self,process):
        if self.vision is not process:return
        self.release();self.vision=None;self.last_frame=0.;self.current_note=0
        self.camera_button.setText('开启摄像头');self.camera_button.setEnabled(True)
        self.preview.clear();self.show_note(0)
        if not self.camera_failed:self.vision_status.setText('摄像头已关闭')
        process.deleteLater()
    def read_vision(self):
        if not self.vision:return
        self.vision_buffer.extend(bytes(self.vision.readAllStandardOutput()))
        if len(self.vision_buffer)>2_000_000:
            self.on_vision_event(dict(type='error',message='摄像头数据异常'));self.stop_camera();return
        while b'\n' in self.vision_buffer:
            line,_,tail=self.vision_buffer.partition(b'\n');self.vision_buffer[:]=tail
            try:event=json.loads(line)
            except (ValueError,UnicodeDecodeError):
                self.on_vision_event(dict(type='error',message='摄像头数据无法解析'));self.stop_camera();return
            self.on_vision_event(event)
    def show_note(self,note):
        self.current_note=note;self.digit.setText(str(note) if note else '—')
        self.pitch.setText(NOTES[note-1] if note else '等待手势')
        for i,label in enumerate(self.guide_labels):
            label.setStyleSheet('color:#936b15;' if i+1==note else '')
    def on_vision_event(self,event):
        kind=event.get('type')
        if kind=='frame':
            self.last_frame=time.monotonic();self.frame_stale=False
            note=event.get('note',0) if event.get('tracking') and event.get('enabled') else 0
            note=note if type(note) is int and 0<=note<=7 else 0
            self.show_note(note)
            if self.worker:
                self.worker.set_note(note,100 if note else 0) if self.connected and self.sound.isChecked() else self.release()
            if event.get('jpeg'):
                try:self.preview.set_frame(base64.b64decode(event['jpeg'],validate=True))
                except (ValueError,TypeError):self.release();return
            if note:self.vision_status.setText('手势已确认' if self.connected and self.sound.isChecked() else '正在识别')
            elif event.get('tracking'):self.vision_status.setText('保持手势片刻' if event.get('pose') in tuple('1234567') else '手势未确认')
            else:self.vision_status.setText('请让一只手完整入镜')
        elif kind=='error':
            self.release();self.camera_failed=True;self.show_note(0)
            self.vision_status.setText(str(event.get('message','摄像头读取失败')))
            if self.vision and not self.camera_stopping:self.stop_camera()
        # Note events are deliberately ignored; only a fresh, displayed frame
        # can renew sound. UI/camera failure cannot sustain a queued old note.
    def check_freshness(self):
        if self.last_frame and time.monotonic()-self.last_frame>.5:
            self.release()
            if not self.frame_stale:
                self.frame_stale=True;self.show_note(0);self.vision_status.setText('画面已中断，手势止音')
    def tick(self):
        while True:
            try:event=self.events.get_nowait()
            except queue.Empty:break
            kind=event['type']
            if kind=='connected':
                self.connected=True;self.link_status.setText('已连接');self.message.setText('')
                self.sound.setEnabled(True);self.mute_button.setEnabled(True)
                self.connect_button.setText('断开乐器');self.connect_button.setEnabled(True)
            elif kind=='status':
                if event['muted']:self.message.setText('P8 当前已静音，请在显示屏取消静音')
                elif event['mode']==2:self.message.setText('P8 正在自动演奏，切回演奏后即可使用手势')
                elif event['pattern_mode']:self.message.setText('P8 当前为选音模式，切回直弹后即可使用手势')
                else:self.message.setText('')
            elif kind=='error':self.message.setText(event['message'])
            elif kind=='disconnected':
                self.connected=False;self.worker=None;self.sound.setEnabled(False);self.mute_button.setEnabled(False)
                self.link_status.setText('未连接');self.connect_button.setText('连接乐器');self.connect_button.setEnabled(True)
                self.port.setEnabled(True);self.refresh_button.setEnabled(True)
        self.check_freshness()
    def closeEvent(self,event):
        self.closing=True;self.timer.stop();self.port_timer.stop();self.release()
        if self.vision:
            self.vision.write(b'{"type":"stop"}\n')
            if not self.vision.waitForFinished(1000):self.vision.kill();self.vision.waitForFinished(500)
        if self.worker:self.worker.disconnect();self.worker.join(1)
        event.accept()
