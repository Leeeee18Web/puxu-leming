import queue,struct,time,unittest
from gesture_link import GestureLink
from test_gesture_host import Peer,reply

class StopPeer(Peer):
 def write(self,data):
  self.writes.append(bytes(data));seq=struct.unpack_from('<H',data,4)[0]
  self.pending.extend(reply(seq,caps=3));return len(data)

class StopTransportTests(unittest.TestCase):
 def test_stop_api_and_real_worker_send_capability_checked_opcode(self):
  peers=[];events=queue.Queue()
  def factory(*args,**kw):p=StopPeer(*args,**kw);peers.append(p);return p
  worker=GestureLink('TEST',events,serial_factory=factory)
  self.assertTrue(callable(getattr(worker,'emergency_stop',None)), 'thread-safe emergency_stop is required')
  worker.start()
  try:
   until=time.monotonic()+1
   while not worker.connected and time.monotonic()<until:time.sleep(.005)
   self.assertTrue(worker.connected)
   worker.set_note(6,100);time.sleep(.03);worker.emergency_stop();time.sleep(.05)
   packets=peers[0].writes
   stop=[p for p in packets if p[8]==2]
   self.assertEqual(len(stop),1);self.assertEqual(stop[0][9:12],bytes(3))
   after=packets[packets.index(stop[0])+1:]
   self.assertFalse(any(p[8]==1 and p[9] for p in after), 'a stale note must not return after stop')
  finally:worker.disconnect();worker.join(1)

if __name__=='__main__':unittest.main()
