import argparse
import json
import os
from pathlib import Path
import sys

def main():
    parser=argparse.ArgumentParser(description='手势演奏 / Tang Mega 138K')
    parser.add_argument('--check',action='store_true')
    parser.add_argument('--self-test',action='store_true')
    parser.add_argument('--screenshot',type=Path)
    options=parser.parse_args()
    if options.self_test:
        import unittest
        suite=unittest.defaultTestLoader.loadTestsFromNames(['test_gesture_host','test_vision_worker'])
        return 0 if unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful() else 1
    if options.check or options.screenshot:os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
    from PySide6.QtWidgets import QApplication
    from PySide6.QtCore import QTimer
    from app import MainWindow
    from fonts import initialize_fonts
    application=QApplication(sys.argv[:1]);fonts=initialize_fonts(application)
    window=MainWindow()
    if options.check:
        print(json.dumps(dict(passed=True,fonts=fonts,serial_opened=False,camera_opened=False),ensure_ascii=False))
        window.close();return 0
    window.show()
    if options.screenshot:
        def capture():
            options.screenshot.parent.mkdir(parents=True,exist_ok=True)
            window.grab().save(str(options.screenshot));window.close();application.quit()
        QTimer.singleShot(150,capture)
    return application.exec()

if __name__=='__main__':raise SystemExit(main())
