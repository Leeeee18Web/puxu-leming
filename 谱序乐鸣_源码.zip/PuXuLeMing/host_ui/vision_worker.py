"""Opt-in hand notes; no serial access or PC audio synthesis.

stdin JSONL: {"type":"enable","enabled":true/false}, {"type":"stop"}.
stdout JSONL: frame/jpeg/gesture/tracking, note/index/velocity/timestamp, error.
Only the parent app sends notes to the FPGA. --check never opens a camera.
World-coordinate distances/angles preserve the Project3 mirror/rotation policy.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import math
import os
from pathlib import Path
import queue
import sys
import threading
import time

from camera_source import resolve_camera, enumerate_dshow_cameras, choose_camera

DEFAULT_PYTHON = Path(sys.executable)
DEFAULT_MODEL = Path(__file__).parent/'models/hand_landmarker.task'
LABELS = {'1':'一 · C4','2':'二 · D4','3':'三 · E4','4':'四 · F4',
          '5':'五 · G4','6':'六 · A4','7':'七 · B4',
          'fist':'握拳 · 止音','unknown':'未确认 · 止音'}
CONNECTIONS = [(0,1),(1,2),(2,3),(3,4),(0,5),(5,6),(6,7),(7,8),
               (5,9),(9,10),(10,11),(11,12),(9,13),(13,14),(14,15),
               (15,16),(13,17),(0,17),(17,18),(18,19),(19,20)]


def classify_gesture(landmarks):
    """Conservative 1..7 geometry, fist/unknown stop; not a learned classifier.

    Chinese 6 = thumb+pinky. Chinese 7 = thumb/index/middle tips pinched,
    ring/pinky folded. Bent/ambiguous fingers fail closed. Use 21 world xyzs.
    """
    try:
        if len(landmarks) != 21:
            return 'unknown'
        p = [tuple(float(v) for v in point[:3]) for point in landmarks]
        if any(len(point) != 3 or not all(math.isfinite(v) for v in point) for point in p):
            return 'unknown'
    except (TypeError, ValueError, OverflowError):
        return 'unknown'

    def distance(a,b): return math.dist(p[a],p[b])

    def angle(a,b,c):
        u=[p[a][i]-p[b][i] for i in range(3)]
        v=[p[c][i]-p[b][i] for i in range(3)]
        norm=math.sqrt(sum(x*x for x in u)*sum(x*x for x in v))
        if norm<1e-12:return 0.
        return math.degrees(math.acos(max(-1.,min(1.,sum(x*y for x,y in zip(u,v))/norm))))

    palm=distance(5,17)
    if distance(0,9)<1e-6 or palm<1e-6:return 'unknown'

    def finger_state(mcp):
        bend=angle(mcp,mcp+1,mcp+3)
        radial=distance(0,mcp+3)/max(distance(0,mcp+1),1e-9)
        if bend>=155 and radial>1.12:return True
        if bend<=135 or radial<.98:return False
        return None

    fingers=[finger_state(mcp) for mcp in (5,9,13,17)]
    # Pinch is checked before straight/fold classification: its first two
    # fingers are intentionally bent. Require tips away from the folded fist.
    pinch=max(distance(4,8),distance(4,12),distance(8,12))<palm*.38
    raised=(distance(0,8)>distance(0,6)*.98 and distance(0,12)>distance(0,10)*.98)
    if pinch and raised and fingers[2:]==[False,False]:return '7'
    if None in fingers:return 'unknown'
    thumb_angle=angle(2,3,4)
    spread=distance(4,5)/max(distance(2,5),1e-9)
    if thumb_angle>=150 and spread>1.35:thumb=True
    elif thumb_angle<135 or spread<1.1:thumb=False
    else:return 'unknown'
    pattern=tuple(fingers)
    if not thumb:
        return {(True,False,False,False):'1',(True,True,False,False):'2',
                (True,True,True,False):'3',(True,True,True,True):'4',
                (False,False,False,False):'fist'}.get(pattern,'unknown')
    return {(True,True,True,True):'5',(False,False,False,True):'6'}.get(pattern,'unknown')


class NoteGate:
    """150ms stable hold, one note-on per pose; every unsafe state releases.

    A valid pose change releases the old note immediately, then waits a full
    hold before the new note. Unknown/lost/multi-hand/gaps never sustain notes.
    Returned (index,velocity) pairs preserve off-before-on order.
    """
    def __init__(self,hold_seconds=.15,velocity=100):
        if not math.isfinite(hold_seconds) or hold_seconds<.1:
            raise ValueError('hold_seconds must be finite and >=0.1')
        self.hold_seconds=hold_seconds
        self.velocity=max(1,min(127,int(velocity)))
        self.enabled=False
        self.active_note=0
        self.candidate=None
        self.since=None
        self.last_time=None

    def release(self):
        events=[(0,0)] if self.active_note else []
        self.active_note=0
        self.candidate=None
        self.since=None
        return events

    def stop(self):
        self.enabled=False
        self.last_time=None
        return self.release()

    def set_enabled(self,enabled):
        if bool(enabled)!=self.enabled:
            events=self.release()
            self.enabled=bool(enabled)
            self.last_time=None
            return events
        return []

    def update(self,gesture,tracking,now):
        if not self.enabled or not tracking or not math.isfinite(now):
            self.last_time=None
            return self.release()
        events=[]
        if self.last_time is not None and (now<=self.last_time or now-self.last_time>.25):
            events=self.release()
        self.last_time=now
        note=int(gesture) if gesture in ('1','2','3','4','5','6','7') else 0
        if not note:return events+self.release()
        if note!=self.candidate:
            events+=self.release()
            self.candidate,self.since=note,now
            return events
        if note!=self.active_note and now-self.since>=self.hold_seconds:
            self.active_note=note
            events.append((note,self.velocity))
        return events


def emit(message):
    print(json.dumps(message,ensure_ascii=False,separators=(',',':')),flush=True)


def emit_notes(events):
    for index,velocity in events:
        emit({'type':'note','index':index,'velocity':velocity,'timestamp':time.monotonic()})


def load_runtime(model):
    runtime_cache=Path(__file__).resolve().parents[1]/'build/vision_legacy'
    runtime_cache.mkdir(parents=True,exist_ok=True)
    os.environ.setdefault('MPLCONFIGDIR',str(runtime_cache/'matplotlib'))
    import cv2
    import mediapipe as mp
    import numpy as np
    if not model.is_file():raise FileNotFoundError(f'模型不存在：{model}')
    options=mp.tasks.vision.HandLandmarkerOptions(
        base_options=mp.tasks.BaseOptions(model_asset_path=str(model)),
        running_mode=mp.tasks.vision.RunningMode.VIDEO,num_hands=2,
        min_hand_detection_confidence=.65,min_hand_presence_confidence=.65,
        min_tracking_confidence=.65)
    return cv2,mp,np,mp.tasks.vision.HandLandmarker.create_from_options(options)


def read_controls(inbox,stop_event):
    try:
        for line in sys.stdin:
            try:
                message=json.loads(line)
                if not isinstance(message,dict):raise ValueError('控制消息必须是JSON对象')
                if message.get('type')=='stop':
                    stop_event.set()
                    return
                if message.get('type')=='enable' and isinstance(message.get('enabled'),bool):
                    inbox.put(message['enabled'])
                else:print('忽略未识别的控制消息',file=sys.stderr,flush=True)
            except (ValueError,TypeError) as exc:
                print(f'控制消息无效：{exc}',file=sys.stderr,flush=True)
    finally:
        stop_event.set()


def check(model):
    cv2,mp,np,detector=load_runtime(model)
    try:
        blank=mp.Image(image_format=mp.ImageFormat.SRGB,data=np.zeros((192,192,3),dtype=np.uint8))
        result=detector.detect_for_video(blank,1)
        emit({'type':'check','ok':True,'python':sys.version.split()[0],
              'mediapipe':mp.__version__,'opencv':cv2.__version__,'numpy':np.__version__,
              'model':str(model),'model_sha256':hashlib.sha256(model.read_bytes()).hexdigest(),
              'blank_hands':len(result.hand_landmarks),'camera_opened':False})
    finally:detector.close()


def run_camera(camera,model,fps):
    # Resolve in the same DirectShow index domain as CAP_DSHOW, before model
    # loading or video acquisition. None means a named physical PC camera.
    selected=resolve_camera(camera)
    cv2,mp,np,detector=load_runtime(model)
    capture=None
    stopped=threading.Event()
    controls=queue.SimpleQueue()
    gate=NoteGate()
    threading.Thread(target=read_controls,args=(controls,stopped),daemon=True).start()

    def drain_controls():
        while not controls.empty():emit_notes(gate.set_enabled(controls.get()))

    try:
        if stopped.is_set():return
        print(f'摄像头：{selected.name}（DirectShow {selected.index}）',file=sys.stderr,flush=True)
        capture=cv2.VideoCapture(selected.index,cv2.CAP_DSHOW if os.name=='nt' else cv2.CAP_ANY)
        if not capture.isOpened():raise RuntimeError(f'无法打开摄像头 {selected.name}（{selected.index}）')
        capture.set(cv2.CAP_PROP_FRAME_WIDTH,640)
        capture.set(cv2.CAP_PROP_FRAME_HEIGHT,480)
        capture.set(cv2.CAP_PROP_BUFFERSIZE,1)
        last_ms=-1
        while not stopped.is_set():
            started=time.monotonic()
            drain_controls()
            ok,frame=capture.read()
            if not ok:raise RuntimeError('摄像头读取失败，已停止手势控制')
            if stopped.is_set():break
            frame=cv2.flip(frame,1)
            if frame.shape[1]>640:
                frame=cv2.resize(frame,(640,round(frame.shape[0]*640/frame.shape[1])))
            rgb=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
            timestamp=max(last_ms+1,int(time.monotonic()*1000))
            last_ms=timestamp
            result=detector.detect_for_video(mp.Image(image_format=mp.ImageFormat.SRGB,data=rgb),timestamp)
            tracking=len(result.hand_landmarks)==1 and len(result.hand_world_landmarks)==1
            pose='unknown'
            if tracking:
                pose=classify_gesture([(p.x,p.y,p.z) for p in result.hand_world_landmarks[0]])
            drain_controls()
            if stopped.is_set():break
            emit_notes(gate.update(pose,tracking,time.monotonic()))
            for landmarks in result.hand_landmarks:
                h,w=frame.shape[:2]
                coords=[(round(p.x*w),round(p.y*h)) for p in landmarks]
                for a,b in CONNECTIONS:cv2.line(frame,coords[a],coords[b],(180,220,60),2)
                for point in coords:cv2.circle(frame,point,3,(60,150,255),-1)
            label=LABELS[pose] if tracking else ('多手 · 止音' if result.hand_landmarks else '未检测到手 · 止音')
            if not gate.enabled:label+=' · 预览'
            ok,jpeg=cv2.imencode('.jpg',frame,[cv2.IMWRITE_JPEG_QUALITY,72])
            if not ok:raise RuntimeError('预览JPEG编码失败')
            emit({'type':'frame','jpeg':base64.b64encode(jpeg).decode('ascii'),
                  'gesture':label,'pose':pose,'tracking':tracking,
                  'note':gate.active_note,'enabled':gate.enabled,
                  'camera_index':selected.index,'camera_name':selected.name})
            stopped.wait(max(0.,1./fps-(time.monotonic()-started)))
    finally:
        # Camera/inference/encoding errors and stdin EOF all release before exit.
        # Parent also releases on worker death as transport can fail independently.
        emit_notes(gate.stop())
        if capture is not None:capture.release()
        detector.close()


def main():
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')
    parser=argparse.ArgumentParser(description='Opt-in 1..7 hand note worker')
    parser.add_argument('--check',action='store_true',help='Blank image check; never opens camera')
    parser.add_argument('--list-cameras',action='store_true',help='Read-only DirectShow metadata; never opens camera')
    parser.add_argument('--camera',type=int,default=None,help='Explicit device override; default auto-selects PC camera')
    parser.add_argument('--model',type=Path,default=DEFAULT_MODEL)
    parser.add_argument('--fps',type=float,default=15)
    args=parser.parse_args()
    if (args.camera is not None and args.camera<0) or not 1<=args.fps<=30:
        parser.error('camera>=0; fps between 1 and 30')
    try:
        if args.check:check(args.model)
        elif args.list_cameras:
            from dataclasses import asdict
            devices=enumerate_dshow_cameras()
            emit({'type':'cameras','backend':'DirectShow',
                  'devices':[asdict(d) for d in devices],
                  'selected':asdict(choose_camera(devices,args.camera)),
                  'camera_opened':False})
        else:run_camera(args.camera,args.model,args.fps)
    except (BrokenPipeError,KeyboardInterrupt):return 0
    except Exception as exc:
        print(f'{type(exc).__name__}: {exc}',file=sys.stderr,flush=True)
        emit({'type':'error','message':str(exc)})
        return 1
    return 0


if __name__=='__main__':raise SystemExit(main())
