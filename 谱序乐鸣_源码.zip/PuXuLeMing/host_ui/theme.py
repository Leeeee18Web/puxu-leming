STYLE='''
QMainWindow, QWidget#root { background:#f3f6f9; color:#203647; }
QWidget { font-family:"Instrument Sans SC"; font-size:14px; color:#203647; }
QLabel#title { font-size:26px; font-weight:600; }
QLabel#subtle { color:#718391; font-size:13px; }
QFrame#connection { background:#e5edf3; border-radius:10px; }
QComboBox { background:white; border:1px solid #cad7e1; border-radius:6px; padding:9px 12px; min-height:20px; }
QComboBox:focus { border:1px solid #3f6c89; }
QComboBox::drop-down { border:0; width:26px; }
QPushButton { background:white; border:1px solid #c6d4de; border-radius:6px; padding:10px 18px; min-height:20px; }
QPushButton:hover { border-color:#3f6c89; background:#f9fcff; }
QPushButton:pressed { background:#dce8f0; }
QPushButton:focus { border:2px solid #3f6c89; padding:9px 17px; }
QPushButton:disabled { background:#eef2f5; color:#9dabb6; border-color:#dce4ea; }
QPushButton#primary { background:#3f6c89; color:white; border-color:#3f6c89; }
QPushButton#primary:hover { background:#335e7b; }
QPushButton#camera { background:#203b4c; border-color:#203b4c; color:white; }
QPushButton#camera:hover { background:#2d5066; }
QFrame#result { background:white; border:1px solid #dbe3e9; border-radius:10px; }
QLabel#digit { font-size:64px; font-weight:600; color:#2e5872; }
QLabel#pitch { font-size:23px; font-weight:600; }
QLabel#pose { color:#566e7f; font-size:14px; }
QCheckBox { spacing:9px; }
QCheckBox::indicator { width:19px; height:19px; border:1px solid #aabcc9; border-radius:4px; background:white; }
QCheckBox::indicator:checked { background:#3f6c89; border:4px solid #bdd0de; }
QCheckBox:disabled { color:#a1afb9; }
QFrame#guide { background:#e9eff4; border-radius:8px; }
QLabel#guideNote { font-size:17px; font-weight:600; }
QLabel#guidePose { color:#657d8e; font-size:12px; }
QLabel#message { color:#566e7f; font-size:13px; }
'''
